
package com.wb.wol_web.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class SetUpRecurringPaymentPage extends ObjectBase {

	PendingPaymentsPage pendingPaymentsPage = new PendingPaymentsPage();
	AddOrMangeWebsterAccountsPage manageWebsteraccount = new AddOrMangeWebsterAccountsPage();
	public String recurringConfirmNumber = "";
	public WebElement deletePendingPayment = null;
	public String accountName = "";

	public SetUpRecurringPaymentPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "make_duplicate_impl")
	protected WebElement btnDuplicateBills;

	@FindBy(xpath = "//*[contains(@data-wbst-message-key,'eu.setuppaymentrecurr') ]")
	protected WebElement txtPageTitle;

	@FindBy(xpath = "//table//tr[@class='table_row_alternate']/td[4]")
	protected WebElement txtConfirmationNumber;

	@FindBy(xpath = "//select[@id='account_id']")
	protected WebElement lstFromAccount;

	@FindAll(@FindBy(xpath = "//select[@id='account_id']/option"))
	protected List<WebElement> lstFromAccountOptions;

	@FindAll(@FindBy(xpath = "//tbody[@class='js-payee-list']/tr[contains(@id,'id')]"))
	protected List<WebElement> payeeTableRows;

	@FindBy(id = "recurrPymtAction")
	protected WebElement btnSetUpPayment;

	@FindBy(id = "btnCancel")
	protected WebElement btnCacel;

	@FindBy(xpath = "//tr[@class='table_row_alternate']")
	protected WebElement tableConfirmation;

	@FindBy(xpath = "//button[contains(text(),'Continue')]")
	protected WebElement btnContinue;

	@FindBy(xpath = "//div[@class='lightbox-wrap is-visible is-top']//button[@aria-label='Close the dialog']")
	protected WebElement btnLightboxClose;

	@FindBy(xpath = "//div[@class='lightbox-wrap is-visible is-top']//div[@aria-labelledby='lightboxTitle0']")
	protected WebElement alertLightBox;

	@FindBy(id = "electronic_notice")
	protected WebElement noticeCheckBox;

	@FindAll(@FindBy(xpath = "//table[@class='table_bg']//tr//a/ancestor::tr[contains(@class,'table_row')]"))
	protected List<WebElement> pendingPaymentsRows;

	@FindAll(@FindBy(xpath = "//tbody[@data-designation='B']/tr[contains(@id,'id')]/td[1]/a"))
	protected List<WebElement> businessPayeeRows;

	@FindAll(@FindBy(xpath = "//tbody[@data-designation='P']/tr[contains(@id,'id')]/td[1]/a"))
	protected List<WebElement> personalPayeeRows;

	@FindBy(id = "cancelNoBtn")
	protected WebElement btnNoCancel;

	@FindBy(id = "cancelYesBtn")
	protected WebElement btnYesCancel;

	@FindBy(xpath = "//div[@class='errorIndicator']//p")
	protected WebElement ErrorMsg;

	/**
	 * To check the page Title in Recurring Payment Functionality
	 * 
	 * @Author:Sneha K
	 * @Created on: May 1st 2019
	 * @Modified on:
	 * @param pageHeading
	 * @return
	 */
	public boolean checkPageTitleForRecurringPayment(String pageHeading) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(20);
			waits.waitUntilElementIsPresent(txtPageTitle);
			if (wolWebUtil.verifyText(txtPageTitle, pageHeading)) {
				LogUtility.logInfo("---> checkPageTitleForRecurringPayment <---",
						"Heading verified Successfully " + pageHeading);
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logError("--->checkPageTitleForRecurringPayment<---", e.getMessage());
		}
		return status;
	}

	/**
	 * To enter all the details for recurring payment
	 * 
	 * @param paymentDetails
	 * @throws Exception
	 * @Author:Sneha K
	 * @Created on: May 1st 2019
	 * @Modified on:
	 */
	public void enterPaymentDetails(List<String> paymentDetails, String paymentType) throws Exception {
		WebElement rowToProcess = null;
		String colValue = null;
		waits.waitForPageToLoad(3);
		try {
			outerloop: for (WebElement eachRow : payeeTableRows) {
				for (WebElement nicknameEle : eachRow.findElements(By.tagName("td"))) {
					try {
						colValue = webActions.getText(nicknameEle);
						if (colValue.contains(paymentType)) {
							rowToProcess = eachRow;
							break outerloop;
						}
					} catch (Exception e) {
						continue;
					}
				}
			}
			int i = 1;
			accountName = "";
			for (WebElement ele : rowToProcess.findElements(By.tagName("td"))) {
				if (i == 1) {
					accountName = webActions.getText(ele).split("\n")[0];
				}
				if (i == 4) {
					if (paymentDetails.get(0).equals("null"))
						webActions.selectDropDownByText(ele.findElement(By.tagName("select")), "Select");
					else
						webActions.selectDropDownByText(ele.findElement(By.tagName("select")), paymentDetails.get(0));
				}
				if (i == 5) {
					if (paymentDetails.get(1).equals("null"))
						webActions.clearValue(ele.findElement(By.tagName("input")));
					else
						webActions.setValue(ele.findElement(By.tagName("input")), paymentDetails.get(1));
				} else if (i == 6) {
					if (paymentDetails.get(2).equals("null"))
						webActions.clearValue(ele.findElement(By.tagName("input")));
					else
						webActions.setValue(ele.findElement(By.tagName("input")), paymentDetails.get(2));
				}

				i++;
			}
			LogUtility.logInfo("---> enterPaymentDetails <---", "Entered the details " + paymentDetails);
		} catch (Exception e) {
			LogUtility.logError("--->enterPaymentDetails<---", e.getMessage());
			throw new Exception("Failed in entering details " + e.getLocalizedMessage());
		}

	}

	/**
	 * @param btnName
	 * @Author:Sneha K
	 * @Created on: May 1st 2019
	 */
	public boolean clickOnTheButton(String btnName) {
		WebElement eleToClick = null;
		boolean status = false;
		try {
			switch (btnName) {
			case "Continue":
				eleToClick = btnContinue;
				break;
			case "SetUpPayment":
				eleToClick = btnSetUpPayment;
				break;
			case "Cancel":
				eleToClick = btnCacel;
				break;
			default:
				LogUtility.logInfo("---> clickOnTheButton <---", "Invalid button " + btnName);
			}
			if (waits.waitUntilElementIsPresent(eleToClick)) {
				status = true;
				webActions.clickElement(eleToClick);
				LogUtility.logInfo("---> clickOnTheButton <---", "clicked on the button " + btnName);
			}
			waits.waitForPageToLoad(4);
		} catch (Exception e) {
			LogUtility.logError("--->clickOnTheButton<---", e.getMessage());

		}
		return status;
	}

	public void checkForLightBox() throws Exception {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(alertLightBox, 5)) {
				webActions.clickElement(noticeCheckBox);
				webActions.clickElement(btnLightboxClose);
				waits.waitForPageToLoad(5);
				LogUtility.logInfo("---> checkForLightBox <---", "clicked on the close dialog box ");
			}
		} catch (Exception e) {
			LogUtility.logError("--->checkForLightBox<---", e.getMessage());
			throw new Exception("Exception while closing the notice dialog box " + e.getMessage());
		}
	}

	/**
	 * To get the confirmation details
	 * 
	 * @Author:Sneha K
	 * @Created on: May 2nd 2019
	 */
	public String getThePaymentConfirmationDetails() {
		try {
			recurringConfirmNumber = webActions.getText(txtConfirmationNumber).split("\n")[1];
			pendingPaymentsPage.confirmationNumber = recurringConfirmNumber;
			setValueInRuntimeDataMap("RecurringConfirmationNumber", recurringConfirmNumber);
			LogUtility.logInfo("---> getThePaymentConfirmationDetails <---", "Details are " + recurringConfirmNumber);
			return recurringConfirmNumber;
		} catch (Exception e) {
			LogUtility.logError("--->getThePaymentConfirmationDetails<---", e.getMessage());
		}
		return recurringConfirmNumber;
	}

	/**
	 * To can or accept the cancel button
	 * 
	 * @param yesOrNo
	 * @throws Exception
	 * @Author:Sneha K
	 * @Created on: May 6th 2019
	 */
	public void ClickOnCancelPopup(String yesOrNo) throws Exception {
		try {
			waits.waitForPageToLoad(3);
			if (yesOrNo.equals("Yes")) {
				webActions.clickElement(btnYesCancel);
			} else {
				webActions.clickElement(btnNoCancel);
			}
			LogUtility.logInfo("---> ClickOnCancelPopup <---",
					"Clicked on the " + yesOrNo + " button from cancel popup");
			waits.waitForPageToLoad(5);
		} catch (Exception e) {
			LogUtility.logError("--->ClickOnCancelPopup<---", e.getMessage());
			throw new Exception("Exception while clickng on " + yesOrNo + " button in cancel popup");
		}

	}

	/**
	 * To get the Account Number from which the payment is made
	 * 
	 * @param yesOrNo
	 * @Author:Sneha K
	 * @Created on: May 6th 2019
	 */
	public String getTheAccountNumber() {
		String accountNumber = null;
		try {
			waits.waitForPageToLoad(3);
			webActions.clickElement(lstFromAccount);
			String defaultselected = wolWebUtil.getDefaultValueForSelect(lstFromAccount);
			for (WebElement element : lstFromAccountOptions) {
				accountNumber = webActions.getText(element);
				if (!accountNumber.equals(defaultselected)) {
					webActions.clickElement(element);
					manageWebsteraccount.accountNumber = accountNumber;
					break;
				}
			}
			LogUtility.logInfo("---> getTheAccountNumber <---",
					"Got the AccountNumber" + AddOrMangeWebsterAccountsPage.accountNumber);
			waits.waitForPageToLoad(5);
		} catch (Exception e) {
			LogUtility.logError("--->getTheAccountNumber<---", e.getMessage());
		}
		return accountNumber;
	}

	/**
	 * Ti check the error messages are as expected
	 * 
	 * @param         errorMsg=== replaces the payeename in the message with actual
	 *                name from received from the function "enterPaymentDetails"
	 * @param msgType
	 * @return
	 */
	public boolean invalidDataEntryCheck(String errorMsg, String msgType) {
		boolean status = false;
		try {
			errorMsg = errorMsg.replace("{Payeename}", accountName);
			if (errorMsg.equals(webActions.getText(ErrorMsg))) {
				status = true;
				LogUtility.logError("--->invalidDataEntryCheck<---", "Found the error message " + errorMsg);
			}
		} catch (Exception e) {
			LogUtility.logError("--->invalidDataEntryCheck<---", e.getMessage());
		}
		return status;
	}

	/**
	 * To check if the current payment is duplicate or not
	 * 
	 * @param paymentDetails
	 * @throws Exception
	 * @Author:Sneha K
	 * @Created on: May 1st 2019
	 * @Modified on:
	 */
	public boolean checkForDuplicateBills() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnDuplicateBills)) {
				webActions.clickElement(btnDuplicateBills);
				status = true;
				LogUtility.logInfo("--->checkForDuplicateBills<---", "Duplicate bills are present");
			}
		} catch (Exception e) {
			LogUtility.logError("--->checkForDuplicateBills<---", e.getMessage());
		}
		return status;
	}

}
