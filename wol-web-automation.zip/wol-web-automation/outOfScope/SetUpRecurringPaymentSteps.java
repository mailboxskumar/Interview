package com.wb.wol_web.steps;

import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.PendingPaymentsPage;
import com.wb.wol_web.pages.SetUpRecurringPaymentPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class SetUpRecurringPaymentSteps extends ObjectBase {

	SetUpRecurringPaymentPage setUpRecurringPaymentPage = new SetUpRecurringPaymentPage();
	PendingPaymentsPage pendingPaymentsPage = new PendingPaymentsPage();

	@Then("^I should navigate to \"([^\"]*)\" page in recurring payments functionality$")
	public void i_should_navigate_toPage_in_recurring_payment_flow(String pageHeading) {
		if (setUpRecurringPaymentPage.checkPageTitleForRecurringPayment(pageHeading))
			reportPass("Reached the Page " + pageHeading);
		else {
			reportHardFail("Page is not found " + pageHeading);
		}

	}

	@When("^I enter the following details for recurring payment for \"([^\"]*)\" payment$")
	public void i_enter_the_following_details_for_recurring_payment(String paymentType, DataTable details)
			throws Throwable {
		List<String> paymentDetail = details.asList(String.class);
		try {
			setUpRecurringPaymentPage.enterPaymentDetails(paymentDetail, paymentType);
		} catch (Exception e) {
			reportHardFail("Failed to enter the following details for payment" + paymentDetail);
		}

	}

	@And("^I click on \"([^\"]*)\" button in recurring payments functionality$")
	public void i_click_on_button_in_recurring_payments_functionality(String btnName) throws Throwable {
		if (setUpRecurringPaymentPage.clickOnTheButton(btnName)) {
			reportPass("Clicked on the button " + btnName);
		} else {
			reportHardFail("Failed to click on the button" + btnName);
		}
		setUpRecurringPaymentPage.checkForDuplicateBills();

	}

	@And("^I get the recurring payment confirmation details$")
	public void i_get_the_payment_confirmation_details() throws Throwable {

		if (!setUpRecurringPaymentPage.getThePaymentConfirmationDetails().equals(""))
			reportPass("Confirmation Details are " + setUpRecurringPaymentPage.getThePaymentConfirmationDetails());
		else
			reportFail("Failed to get confirmation details");

	}

	@Then("^I check for the electronic notice dialog box$")
	public void i_check_for_the_electronic_notice_dialog_box() throws Throwable {
		try {
			setUpRecurringPaymentPage.checkForLightBox();
		} catch (Exception e) {
			reportFail("Failed to close the notice diaolg box");
		}
	}

	@Then("^Check the payment details are displayed in Pending Payments page$")
	public void check_the_payment_details_are_displayed_in_pending_payments_page() {
		if (pendingPaymentsPage.deletePendingPayments(false, "RecurringConfirmationNumber"))
			reportPass("Confirmation details are found in Pending Payments Page");
		else {
			reportFail("Confirmation details are not found in Pending Payments Page");
		}
	}

	@And("^I should get the popup and click on \"([^\"]*)\" button$")
	public void I_shouild_get_the_cancel_popup(String yesOrNo) {
		try {
			setUpRecurringPaymentPage.ClickOnCancelPopup(yesOrNo);
		} catch (Exception e) {
			reportFail("Failed to cancel the popup");
		}
	}

	@And("^I get the selected account from which the payment is to be made$")
	public void getAccountNumber() {
		String accountSelected = setUpRecurringPaymentPage.getTheAccountNumber();
		if (!accountSelected.equals("")) {
			reportPass("Payment is made from the account " + accountSelected);
		} else {
			reportFail("Failed to get the account from which the payment is made");
		}
	}

	@Then("^I should get the error message as \"([^\"]*)\" for \"([^\"]*)\" in recurring payment$")
	public void check_for_error_message(String msg, String msgType) throws InterruptedException {

		if (setUpRecurringPaymentPage.invalidDataEntryCheck(msg, msgType))
			reportPass("Error message " + msg + " is found");
		else {
			reportFail("Error message " + msg + " is not found");
		}
	}
}
