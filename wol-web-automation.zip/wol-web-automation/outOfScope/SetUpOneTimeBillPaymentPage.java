
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class SetUpOneTimeBillPaymentPage extends ObjectBase {

	public String confirmationNumber = "";

	public SetUpOneTimeBillPaymentPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "cancelButton")

	protected WebElement btnCancel;

	@FindBy(id = "payees_table__filter__input")
	protected WebElement selShowOnly;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle7']")

	protected WebElement canceldialogBox;

	@FindBy(id = "doNotCancelButton")

	protected WebElement btnNo;

	@FindBy(id = "billpay-payment-verification__pageTitle")
	protected WebElement lblVerification;

	@FindBy(css = "billpay-payment-confirmation__pageTitle")
	protected WebElement lblConfirmation;

	@FindBy(css = "div.pageHeaderBlock > h3")
	protected WebElement lblAlertConfirmation;

	// @FindBy(xpath = "//h3[@id='page_title']/span[@style='']")
	@FindBy(css = "h3#page_title")
	protected WebElement lblUpdatePayee;

	@FindBy(xpath = "(//p[contains(@id,'paymentDate') and @class=' error-message-text'])[1]")
	protected WebElement lblInvalidDateMsg;

	@FindBy(xpath = "(//p[contains(@id,'paymentAmount') and @class=' error-message-text'])[1]")
	protected WebElement lblInvalidAmountMsg;

	@FindBy(xpath = "//*[@data-wbst-message-key='ts-auth-error.msg']")

	protected WebElement lblUnauthorizedUser;

	@FindBy(xpath = "//*[@id='error-no-billpay-account__pageErrors__error-no-billpay-account__pageError__body']")

	protected WebElement lblNoBillPayAccountMsg;

	@FindBy(xpath = "//*[@data-wbst-message-key='payee.updateBrochureMessage']")

	protected WebElement lblUpdatePayeeMsg;

	@FindBy(id = "billpay-payment-confirmation__pageAffirmativeNotice__body")
	protected WebElement lblConfirmationMsg;

	@FindBy(xpath = "//span[@aria-label='Confirmation Number'")
	protected WebElement confirmationNumberCell;;

	@FindBy(id = "payees_table__emptyListMessage")
	protected WebElement lblNoPayeeMsg;

	@FindBy(id = "payees_table__filterByText__input")
	protected WebElement txtBoxPayeeFilter;

	@FindBy(xpath = "(//li[@data-mm-hidden='false']//a)[1]")
	protected WebElement lnkPayeeDetails;

	@FindBy(id = "confirmCancelButton")

	protected WebElement btnYes;

	@FindBy(xpath = "//*[text()='Continue']")
	protected WebElement btnContinue;

	@FindBy(id = "payFromAccount__input")
	protected WebElement lstAccountType;

	@FindBy(xpath = "//*[text()='Edit']")
	protected WebElement btnEdit;

	@FindBy(css = "td> select")
	protected WebElement lstAlertsDaysBefore;

	@FindBy(css = "td > input[type=checkbox]")
	protected WebElement chkAcceptAlert;

	@FindBy(id = "duplicatePaymentChooser__option1__input")
	protected WebElement chkDuplicatePayments;

	@FindBy(id = "billpay-payment__pageErrors__billPayPayment__error__duplicatePayments__body")
	protected WebElement txtDuplicatePayments;

	@FindBy(id = "alertConfirm")
	protected WebElement btnAcceptAlert;

	@FindAll(@FindBy(xpath = "//select[@id='payFromAccount__input']/optgroup[@label='Personal Accounts']/option"))
	public List<WebElement> lstPersonalPayFromList;

	@FindAll(@FindBy(xpath = "//select[@id='payFromAccount__input']/optgroup[@label='Business Accounts']/option"))
	public List<WebElement> lstBusinessPayFromList;

	@FindAll(@FindBy(xpath = "//ul[@id='payees_table__body' ]//li[@data-mm-hidden='false']"))
	public List<WebElement> PayeeList;

	@FindBy(xpath = "(//li[@data-mm-hidden='false']//input[contains(@id,'paymentDate')])[1]")
	protected WebElement txtDate;

	@FindBy(xpath = "(//li[@data-mm-hidden='false']//input[contains(@id,'paymentAmount')])[1]")
	protected WebElement txtAmount;

	@FindBy(xpath = "(//li[@data-mm-hidden='false']//input[contains(@id,'paymentMemo')])[1]")
	protected WebElement txtMemo;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']//input[contains(@id,'paymentAmount')])[1]")
	protected WebElement txtPersonalPayeeAmount;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']//select[contains(@id,'paymentFrequency')])[1]")
	protected WebElement selPersonalPaymentFreq;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']//select[contains(@id,'paymentFrequency')])[1]")
	protected WebElement selBusinessPaymentFreq;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']//select[contains(@id,'numberOfPayments')])[1]")
	protected WebElement inputPersonalNumPay;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']//input[contains(@id,'numberOfPayments')])[1]")
	protected WebElement inputBusinessNumPay;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']//input[contains(@id,'paymentMemo')])[1]")
	protected WebElement txtPersonalPayeeMemo;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']//input[contains(@id,'paymentAmount')])[1]")
	protected WebElement txtBusinessPayeeAmount;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']//input[contains(@id,'paymentMemo')])[1]")
	protected WebElement txtBusinessPayeeMemo;

//	@FindBy(xpath="(//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']//input[contains(@id,'paymentMemo')])[1]")

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']/span"))
	protected List<WebElement> lstPersonalPayees;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']/span"))
	protected List<WebElement> lstBusinessPayees;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']/span"))
	protected List<WebElement> lstPayees;

	/**
	 * To Click on the cancel button
	 * 
	 * @throws Exception
	 */
	public void clickOnCancelButton() throws Exception {
		try {
			waits.waitUntilElementIsPresent(btnCancel, 4);
			webActions.clickElement(btnCancel);
			LogUtility.logInfo("---> clickOnCancelButton <---", "Clicked on Cancel button");
		} catch (Exception e) {
			LogUtility.logError("---> clickOnCancelButton <---", e.getMessage());
			throw new Exception("Exception while clicking on cancel button" + e.getMessage());
		}
	}

	/**
	 * To select the given value in PayFrom dropdown
	 * 
	 * @throws Exception
	 */
	public void selectFromShowOnlyDropdown(String text) throws Exception {
		try {
			waits.waitForPageToLoad(20);
			waits.waitUntilElementIsPresent(selShowOnly);
			wolWebUtil.scrollToElement(selShowOnly);
			webActions.selectDropDownByText(selShowOnly, text);
			LogUtility.logInfo("---> selectFromShowOnlyDropdown <---", "Selected " + text + " from show only dropdown");
		} catch (Exception e) {
			LogUtility.logError("---> selectFromShowOnlyDropdown <---", e.getMessage());
			throw new Exception("Exception while selecting from showonly dropdown " + e.getMessage());
		}
	}

	/**
	 * To check whether the dialog box appears on clicking Cancel button
	 */
	public boolean checkForCloseDialogBox() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(canceldialogBox, 3)) {
				status = true;
				LogUtility.logInfo("---> checkForCloseDialogBox <---", "Dialog box is displayed");
			}
		} catch (Exception e) {
			LogUtility.logError("---> checkForCloseDialogBox <---", e.getMessage());

		}
		return status;
	}

	/**
	 * To check the page heading is as expected as the given value
	 * 
	 * @param pagename
	 * @param heading
	 * @return
	 */
	public boolean checkforPageHeading(String pagename, String heading) {
		boolean status = false;
		WebElement eleToGetText = null;
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			switch (pagename) {
			case "Confirmation":
				eleToGetText = lblConfirmation;
				break;
			case "Verification":
				eleToGetText = lblVerification;
				break;
			case "AlertConfirmation":
				eleToGetText = lblAlertConfirmation;
				break;
			case "UpdatePayee":
				eleToGetText = lblUpdatePayee;
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText);
			if (webActions.getText(eleToGetText).equals(heading)) {
				LogUtility.logInfo("---> checkforPageHeading <---", "Heading " + heading + " is displayed");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> checkforPageHeading <---", e.getMessage());
		}
		return status;
	}

	/**
	 * To check the maximum allowed length for Memo
	 * 
	 * @return
	 */
	public boolean checkPaymentMemoMaxSize() {
		boolean status = false;
		try {
			String value = webActions.getAttributeValue(txtMemo, "value");
			if (value.length() == 20) {
				LogUtility.logInfo("---> checkPaymentMemoMaxSize <---", "Max length for Payment Memo is 20");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> checkPaymentMemoMaxSize <---", e.getMessage());
		}
		return status;
	}

	/**
	 * To enter the payee Type in Filter text box
	 */
	public boolean enterPayeeTypeinTextFilter(String payeeType) {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(txtBoxPayeeFilter)) {
				status = true;

				webActions.setValue(txtBoxPayeeFilter, payeeType);
				LogUtility.logInfo("---> enterPayeeTypeinTextFilter <---", "Entered " + payeeType + " in textbox");
			}
		} catch (Exception e) {
			LogUtility.logError("---> enterPayeeTypeinTextFilter <---", e.getMessage());
		}
		return status;
	}

	/**
	 * To click on the PayeeDetails link
	 */
	public boolean clickOnPayeeDetailsLink(String PayeeType) {
		boolean status = true;
		try {
			if (waits.waitUntilElementIsPresent(txtBoxPayeeFilter)) {
				wolWebUtil.scrollToElement(lnkPayeeDetails);
				webActions.clickElement(lnkPayeeDetails);
				if (wolWebUtil.isAlertPresent()) {
					alerts.acceptAlert();
				}
				status = true;
			}
			LogUtility.logInfo("---> clickOnPayeeDetailsLink <---", "Clicked on Payee Details link");
		} catch (Exception e) {
			LogUtility.logError("---> clickOnPayeeDetailsLink <---", e.getMessage());
		}
		return status;
	}

	/**
	 * TO accept the alert if present
	 * 
	 * @param actionType
	 */
	public void acceptAalert(String actionType) {

		if (actionType.equalsIgnoreCase("Leave"))
			if (alerts.isAlertPresent())
				alerts.acceptAlert();
	}

	/**
	 * To get the confirmation number for Successful payment
	 */
	public void getConfirmationNumber() {

		waits.waitUntilElementIsPresent(confirmationNumberCell);
		confirmationNumber = webActions.getText(confirmationNumberCell);
	}

	/**
	 * To check if the message is present in the page
	 */
	public boolean checkfortheMessage(String messageType, String message) {
		WebElement eleToGetText = null;
		boolean status = false;
		try {
			switch (messageType) {
			case "Confirmation":
				eleToGetText = lblConfirmationMsg;
				break;
			case "NoPayees":
				eleToGetText = lblNoPayeeMsg;
				break;
			case "InvalidDate":
				eleToGetText = lblInvalidDateMsg;
				break;
			case "InvalidAmount":
				eleToGetText = lblInvalidAmountMsg;
				break;
			case "Unauthorizeduser":
				eleToGetText = lblUnauthorizedUser;
				break;
			case "NoBillPayAccounts":
				eleToGetText = lblNoBillPayAccountMsg;
				break;
			case "PayeeUpdate":
				eleToGetText = lblUpdatePayeeMsg;
				break;
			default:
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText, 3);
			if (webActions.getText(eleToGetText).equals(message)) {
				LogUtility.logInfo("---> checkfortheMessage <---", "Message " + message + " is displayed");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> checkfortheMessage <---", e.getMessage());
		}
		return status;
	}

	/**
	 * To click on the yes/No button from dialog box
	 * 
	 * @throws Exception
	 */
	public boolean clickFromDialogBox(String yesOrNo) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(5);
			if (yesOrNo.equalsIgnoreCase("No")) {
				if (waits.waitUntilElementIsPresent(btnNo)) {
					status = true;
					btnNo.click();
				}

			} else {
				if (waits.waitUntilElementIsPresent(btnYes)) {
					status = true;
					btnYes.click();
				}
			}
			waits.waitForPageToLoad(5);
			LogUtility.logInfo("---> clickFromDialogBox <---", "Clicked on " + yesOrNo + " button");
		} catch (Exception e) {
			LogUtility.logError("---> clickFromDialogBox <---", e.getMessage());
		}
		return status;
	}

	/**
	 * To click on the Payee and check for the labels in payment details
	 */
	public Map<String, String> clickonthePayeeFromList(String payeename) throws InterruptedException {
		HashMap<String, String> mapstatus = new HashMap<>();
		List<WebElement> payeeList = new ArrayList<>();
		try {
			if (payeename.equals("PERSONAL")) {
				webActions.clickElement(lstPersonalPayees.get(1));
				payeeList = lstPersonalPayees;
			} else if (payeename.equals("BUSINESS")) {
				webActions.clickElement(lstBusinessPayees.get(1));
				payeeList = lstBusinessPayees;
			} else {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", lstPayees.get(0));
				lstPayees.get(0).click();
				payeeList = lstPayees;
			}
			for (WebElement payeeDetailsEle : payeeList) {
				mapstatus.put(payeeDetailsEle.getAttribute("aria-label"), payeeDetailsEle.getText());
				if (payeeDetailsEle.getAttribute("aria-label").equals("Additional Details"))
					break;
			}
			LogUtility.logInfo("---> clickonthePayeeFromList <---", "Checked all the labels for a payment");
		} catch (Exception e) {
			LogUtility.logError("---> clickonthePayeeFromList <---", e.getMessage());
		}
		return mapstatus;
	}

	/**
	 * To enter the payment details and filter the payees using payeetype
	 * 
	 * @throws Exception
	 */
	public void enterPaymentDetails(List<String> Details, String Payeetype) throws Exception {
		try {
			if (Payeetype.equals("PERSONAL")) {
				webActions.setValue(txtPersonalPayeeAmount, Details.get(1));
				webActions.setValue(txtPersonalPayeeMemo, Details.get(2));
			} else if (Payeetype.equals("BUSINESS")) {
				webActions.setValue(txtBusinessPayeeAmount, Details.get(1));
				webActions.setValue(txtBusinessPayeeMemo, Details.get(2));
			} else {
				if (!Details.get(0).equalsIgnoreCase("Today")) {
					webActions.setValue(txtDate, Details.get(0));
				}
				webActions.setValue(txtAmount, Details.get(1));
				webActions.setValue(txtMemo, Details.get(2));
			}
			LogUtility.logInfo("---> enterPaymentDetails <---", "Entered the payment details " + Details);
		} catch (Exception e) {
			LogUtility.logError("---> enterPaymentDetails  <---", e.getMessage());
			throw new Exception(" Exception while entering details " + e.getMessage());
		}
	}

	/**
	 * To click on the Continue button
	 */
	public void clickOnContinue() {
		try {
			webActions.clickElement(btnContinue);
			LogUtility.logInfo("---> clickOnContinue <---", "Clicked on continue button");
		} catch (Exception e) {
			LogUtility.logError("---> clickOnContinue <---", e.getMessage());
		}
	}

	/**
	 * To select from the showonly filter dropdown accountType -- filters using this
	 * payeeType (check/Electronic/All/Shortlist)
	 */
	public void selectFromPayFromDropDownlist(String accountType, String dropdown) {
		try {
			webActions.clickElement(lstAccountType);
			List<WebElement> list = new ArrayList<>();
			if (accountType.equals("Personal Accounts"))
				list = lstPersonalPayFromList;
			else
				list = lstBusinessPayFromList;
			list.get(0).click();
			LogUtility.logInfo("---> selectFromPayFromDropDownlist <---",
					"Selected from  PayFrom dropdown " + accountType);
		} catch (Exception e) {
			LogUtility.logError("---> selectFromPayFromDropDownlist <---", e.getMessage());
		}
	}

	/**
	 * To click on the Edit button in verification page
	 * 
	 * @throws Exception
	 */
	public boolean clickOnEditButton() throws Exception {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnEdit)) {
				status = true;
				webActions.clickElement(btnEdit);
				LogUtility.logInfo("---> clickOnEditButton <---", "Clicked on Edit button");
			}
		} catch (Exception e) {
			LogUtility.logError("---> clickOnEditButton <---", e.getMessage());
		}
		return status;
	}

	/**
	 * To select no of days before alert should start
	 * 
	 * @param days
	 */
	public boolean selectFromDaysBeforeAlertDropdown(String days) {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(lstAlertsDaysBefore)) {
				webActions.selectDropDownByText(lstAlertsDaysBefore, days + " Days");
				status = true;
				LogUtility.logInfo("---> selectFromDaysBeforeAlertDropdown <---",
						"Selected " + days + " Days from Alerts Page dropdown");
			}
		} catch (Exception e) {
			LogUtility.logError("---> selectFromDaysBeforeAlertDropdown <---", e.getMessage());
		}
		return status;
	}

	/**
	 * To accept the alert box if exists
	 */
	public void acceptAlertCheckbox() {
		try {
			webActions.clickElement(chkAcceptAlert);
			webActions.clickElement(btnAcceptAlert);
			LogUtility.logInfo("---> acceptAlertCheckbox <---",
					"Accepted the delivery alert and clicked on setup alert");
		} catch (Exception e) {
			LogUtility.logError("---> acceptAlertCheckbox <---", e.getMessage());
		}
	}

	public void checkAndClicklickOnPayDuplicatePayments(String duplicateText) {
		try {
			if (webActions.getText(txtDuplicatePayments).equals(duplicateText)) {
				webActions.clickElement(chkDuplicatePayments);
				LogUtility.logInfo("---> checkAndClicklickOnPayDuplicatePayments <---",
						"Checked the duplicate payments box");
			}
		} catch (Exception e) {
			LogUtility.logError("---> checkAndClicklickOnPayDuplicatePayments <---", e.getMessage());

		}

	}

}