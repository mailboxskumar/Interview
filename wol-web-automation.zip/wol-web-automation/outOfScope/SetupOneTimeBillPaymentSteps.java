package com.wb.wol_web.steps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.SetUpOneTimeBillPaymentPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class SetupOneTimeBillPaymentSteps extends ObjectBase {

	SetUpOneTimeBillPaymentPage setupBillPage = new SetUpOneTimeBillPaymentPage();

	@Then("^I select the type of payment as \"([^\"]*)\" from Showonly dropdown$")
	public void i_select_the_type_of_payment_as_from_Showonly_dropdown(String paymentType) throws Throwable {
		try {
			setupBillPage.selectFromShowOnlyDropdown(paymentType);
			reportPass(paymentType + " is selected from  ShowOnly dropdown");
		} catch (Exception e) {
			reportFail("Failed to select the type of payment");
		}
	}

	@When("^I click on cancel button$")
	public void i_click_on_cancel_button() throws Throwable {
		try {
			setupBillPage.clickOnCancelButton();
			reportPass("clicked on cancel button at the bottom of the page");
		} catch (Exception e) {
			reportFail("Failed to click on cancel button");
		}
	}

	@Then("^I should see a pop up with Yes or No buttons$")
	public void i_should_see_a_pop_up_with_Yes_or_No_buttons() throws Throwable {

		if (setupBillPage.checkForCloseDialogBox()) {
			reportPass("Dialog box for cancel button is displayed");
		} else {
			reportFail("Dialog box for cancel button is not displayed");
		}
	}

	@When("^I click on \"([^\"]*)\" button from popup$")
	public void i_click_on_No_button_from_popup(String btnType) throws Throwable {
		if (setupBillPage.clickFromDialogBox(btnType)) {
			reportPass(btnType + " is clicked from cancel dialog box ");
		} else {
			reportFail(btnType + " is not clicked from cancel dialog box ");
		}
	}

	@Then("^I click on the \"([^\"]*)\" payee and check for the below labels$")
	public void i_should_see_below_UI_labels(String payeename, DataTable tablelist) throws Throwable {
		Map<String, String> map = new HashMap<>();
		List<String> detailsLabels = tablelist.asList(String.class);
		try {
			map = setupBillPage.clickonthePayeeFromList(payeename);
			String reportMsg = "";
			for (String eachLabel : detailsLabels) {
				if (map.containsKey(eachLabel)) {
					reportMsg = reportMsg + eachLabel + ",";
				}
			}
			reportPass("Following Labels are present in the payee details" + "\n" + reportMsg);
		} catch (Exception e) {
			reportFail("Labels are missing in payees details");
		}
	}

	@Then("^I enter DeliveryDate,Amount and Payment memo for \"([^\"]*)\" payee$")
	public void i_enter_DeliveryDate_Amount_and_Payment_memo(String payeeType, DataTable paymentDetails)
			throws Throwable {
		List<String> details = paymentDetails.asList(String.class);
		try {
			setupBillPage.enterPaymentDetails(details, payeeType);
			reportPass("Entered the details " + details);
		} catch (Exception e) {
			reportHardFail("Failed to enter details of the payment");
		}
	}

	@Then("^Check if the payment memo is taking only twenty characters$")
	public void check_memo_size() {
		if (setupBillPage.checkPaymentMemoMaxSize())
			reportPass("Maximum length allowed for Payment Memo is 20");
		else
			reportFail("Maximum length allowed for Payment Memo is not 20");
	}

	@Then("^I should navigate to Payment \"([^\"]*)\" page and check for the heading \"([^\"]*)\"$")
	public void check_the_payment_page_and_heading(String pagename, String heading) {
		if (setupBillPage.checkforPageHeading(pagename, heading)) {
			reportPass("Heading " + heading + " is found");
		} else {
			reportFail("heading " + heading + "  is not found");
		}
	}

	@Then("^Check for the \"([^\"]*)\" message as \"([^\"]*)\"$")
	public void check_for_the_message(String pagename, String mesage) throws Throwable {
		if (setupBillPage.checkfortheMessage(pagename, mesage)) {
			reportPass("Message " + mesage + " is found");
		} else {
			reportFail("Message " + mesage + "  is not found");
		}
	}

	@Then("^I enter \"([^\"]*)\" in search box to get \"([^\"]*)\" payees$")
	public void i_enter_in_search_box_to_get_Electronic_payees(String payeeType, String arg2) throws Throwable {
		if (!setupBillPage.enterPayeeTypeinTextFilter(payeeType)) {
			reportFail("Failed to enter " + payeeType + " in search box");
		}
	}

	@Then("^I accept the alert to \"([^\"]*)\" the page$")
	public void accept_the_alert(String acceptOrNot) {
		setupBillPage.acceptAalert(acceptOrNot);
	}

	@When("^I click on Edit button in Verification Page$")
	public void i_click_on_Edit_button_in_Verification_Page() throws Throwable {
		if (!setupBillPage.clickOnEditButton()) {
			reportFail("Falied to click on edit button");
		}
	}

	@Then("^I select no of days  prior to delivery date the alerts should start as \"([^\"]*)\"$")
	public void i_select_no_of_days_prior_to_delivery_date_the_alerts_should_start_as(String days) throws Throwable {
		if (!setupBillPage.selectFromDaysBeforeAlertDropdown(days)) {
			reportFail("Falied to select " + days + " days from delviery date dropdown");
		}
	}

	@Then("^I click on when payment is delivered checkbox and SetupAlerts button$")
	public void i_click_on_when_payment_is_delivered_checkbox_and_SetupAlerts_button() throws Throwable {
		setupBillPage.acceptAlertCheckbox();
	}

	@Then("^I select the \"([^\"]*)\" from \"([^\"]*)\" dropdown for comingled user$")
	public void i_select_the_account_from_dropdown_for_comingled_user(String accountType, String Paydropdown)
			throws Throwable {
		setupBillPage.selectFromPayFromDropDownlist(accountType, Paydropdown);
	}

	@Then("^I should get duplicate payment error message \"([^\"]*)\" and click on payduplicate payment check box$")
	public void check_for_duplicate_payments(String msg) {
		setupBillPage.checkAndClicklickOnPayDuplicatePayments(msg);

	}

}
