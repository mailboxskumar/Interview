package com.wb.wol_web.steps;

import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddressPhoneChangePage;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddressPhoneChangeSteps extends ObjectBase {

	AddressPhoneChangePage addressPhoneChangePage = new AddressPhoneChangePage();
	CommonPage commonpage = new CommonPage();
	public List<String> listValues = null;
	public String emailAddress = "";
	public String message = "";

	@Then("I verify the label {string} in {string} Page")
	public void i_verify_the_label_in_Page(String labelName, String pageName) {
		if (addressPhoneChangePage.checkLabels(labelName))
			reportPass("Label: " + labelName + " is displayed in page: " + pageName);
		else
			reportFail("Label: " + labelName + " is not displayed in page: " + pageName);
	}

	@Then("I verify the button {string} in {string} Page")
	public void i_verify_the_button_in_Page(String btnName, String pageName) {
		if (addressPhoneChangePage.checkButtons(btnName))
			reportPass("Button: " + btnName + " is displayed in page: " + pageName);
		else
			reportFail("Button: " + btnName + " is not displayed in page: " + pageName);
	}

	@Then("I click on {string} button in {string} page")
	public void i_click_on_button_in(String btnName, String pageName) {
		if (addressPhoneChangePage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked in page: " + pageName);
		else
			reportFail("Button: " + btnName + " is not clicked in page: " + pageName);
	}

	@Then("I click on {string} link in {string} page")
	public void i_click_on_link_in(String linkName, String pageName) {
		if (addressPhoneChangePage.clickOnButton(linkName))
			reportPass("Link: " + linkName + " is clicked in page: " + pageName);
		else
			reportFail("Link: " + linkName + " is not clicked in page: " + pageName);
	}

	@When("I click on {string} button of popup")
	public void i_click_on_button_of_popup(String btnName) {
		if (addressPhoneChangePage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked in popup ");
		else
			reportFail("Button: " + btnName + " is not clicked in popup ");
	}

	@Then("I click on the label {string} in {string} Page")
	public void i_click_on_the_label_in_Page(String labelName, String pageName) {
		if (addressPhoneChangePage.clickOnButton(labelName))
			reportPass("Label: " + labelName + " is clicked in page: " + pageName);
		else
			reportFail("Label: " + labelName + " is not clicked in page: " + pageName);
	}

	@Then("I should see labels and enter values for {string}")
	public void i_should_see_labels_and_enter_values_for(String headerName) {
		listValues = addressPhoneChangePage.checkLabelsAndEnterValues(jsonDataParser.getTestDataMap(), headerName);
		if (listValues.size() > 0)
			reportPass("Labels: " + testDataMap.keySet().toString() + "Data: " + listValues.toString()
					+ " entered respectively under header: " + headerName);
		else
			reportFail(testDataMap.values().toString() + " values not entered under header: " + headerName);
	}

	@Then("I verify the text displayed as {string} in Unauthorized User Access page")
	public void i_verify_the_text_displayed_as_in_Unauthorized_User_Access_page(String message) {
		if (addressPhoneChangePage.checkAccessMessage(message))
			reportPass("Message: " + message + " is displayed in Unauthorized user access page");
		else
			reportHardFail("Message: " + message + " is not displayed in Unauthorized user access page");
	}

	@Then("I check the entered displayed correctly of label {string}")
	public void i_check_the_entered_displayed_correctly_of_label(String labelName) {
		if (addressPhoneChangePage.checkForData(listValues, labelName))
			reportPass("Values: " + listValues.toString() + " is displayed of label: " + labelName);
		else
			reportFail("Values: " + listValues.toString() + " is not displayed of label: " + labelName);
	}

	@Then("I should see confirmation message in Address Phone change")
	public void i_should_see_confirmation_message_as() {
		message = jsonDataParser.getTestDataMap().get("Message");
		if (addressPhoneChangePage.checkConfirmationMessage(message))
			reportPass("Message: " + message + " is displayed ");
		else
			reportHardFail("Message: " + message + " is not displayed");
	}

	@Then("I verify the {string} of details in AddressPhoneChange page")
	public void i_verify_the_of_details_in_AddressPhoneChange_page(String headerName) {
		Map<String, String> QuickLinksMap = jsonDataParser.getTestDataMap();
		List<String> listQuickLinks = addressPhoneChangePage.checkForDetails(headerName, QuickLinksMap);
		if (listQuickLinks.size() == 0)
			reportPass("Labels: " + QuickLinksMap.values().toString() + " are displayed");
		else
			reportFail("some detalis in " + listQuickLinks.toString() + " is not displayed");
	}

	@Then("I select the {string} account as seasonal mailing account")
	public void i_select_the_first_account_as_seasonal_mailing_account(String account) {
		if (addressPhoneChangePage.clickOnSeasonalAccountCheckbox(account))
			reportPass("First Account checkbox is checked");
		else
			reportFail("First Account checkbox is not checked");
	}

	@Then("I select the {string} account as Alternate mailing account")
	public void i_select_the_account_as_Alternate_mailing_account(String account) {
		if (addressPhoneChangePage.clickOnMailAccountCheckbox(account))
			reportPass(account + " Account checkbox is checked");
		else
			reportFail(account + " Account checkbox is not checked");

	}

	@Then("I should see the alert box with {string} message")
	public void i_should_see_the_alert_box_with_message_as(String textType) {
		message = addressPhoneChangePage.checkMessageText(textType, jsonDataParser.getTestDataMap());
		if (message != null)
			reportPass("Message: " + message + " is displayed");
		else
			reportHardFail("Update message is not displayed");
	}

	@Then("I verify the button {string} in popup")
	public void i_verify_the_button_in_popup(String name) {
		if (addressPhoneChangePage.verifyDisplayPopup(name))
			reportPass("Button: " + name + " is displayed in popup ");
		else
			reportFail("Button: " + name + " is not displayed in popup ");
	}

	@Then("I verify the label {string} in popup")
	public void i_verify_the_label_in_popup(String name) {
		if (addressPhoneChangePage.verifyDisplayPopup(name))
			reportPass("Label: " + name + " is displayed in popup ");
		else
			reportFail("Label: " + name + " is not displayed in popup ");
	}

	@Then("I should see error text at email fields")
	public void i_should_see_error_text_at_email_fields() {
		testDataMap = jsonDataParser.getTestDataMap();
		List<String> listErrorText = addressPhoneChangePage.checkForMessages(testDataMap);
		if (listErrorText.size() == 0)
			reportPass("Messages: " + testDataMap.values().toString() + " are displayed");
		else
			reportFail("Message(s) in " + listErrorText.toString() + " is(are) not displayed");

	}

	@Then("I enter random mail address in New Email Address field")
	public void i_enter_random_mail_address_in_New_Email_Address_field() {
		emailAddress = addressPhoneChangePage.enterRandomMailInNewEmail();
		if (emailAddress.length() != 0)
			reportPass("Mail: " + emailAddress + " is displayed ");
		else
			reportFail("Mail: " + emailAddress + " is not displayed");
	}

	@Then("I enter same random mail address in Verify New Email Address field")
	public void i_enter_same_random_mail_address_in_Verify_New_Email_Address_field() {
		if (addressPhoneChangePage.enterRandomMailInVerifyNewEmail(emailAddress))
			reportPass("Mail: " + emailAddress + " is displayed ");
		else
			reportFail("Mail: " + emailAddress + " is not displayed");
	}

	@Then("I should see updated email address")
	public void i_should_see_updated_email_address() {
		if (addressPhoneChangePage.checkUpdatedEmail(emailAddress))
			reportPass("Mail: " + emailAddress + " is displayed ");
		else
			reportFail("Mail: " + emailAddress + " is not displayed");
	}

	@When("I click on {string} link in nextsteps of {string} page")
	public void i_click_on_link_in_nextsteps_of_page(String linkName, String pageName) {
		if (addressPhoneChangePage.clickOnNextLinksInPage(linkName, pageName))
			reportPass("Link: " + linkName + " is clicked in page: " + pageName);
		else
			reportFail("Link: " + linkName + " is not clicked in page: " + pageName);
	}

	@Then("I should see the {string} message in Address Phone change")
	public void i_should_see_the_message_as(String textType) {
		message = jsonDataParser.getTestDataMap().get("Message");
		if (addressPhoneChangePage.checkMessageSmallTalkText(textType, message))
			reportPass("Message: " + message + " is displayed ");
		else
			reportHardFail("Message: " + message + " is not displayed");
	}

	@Then("I click on small talk {string} link")
	public void i_click_on_small_talk_link(String linkName) {
		if (addressPhoneChangePage.clickOnSmallTalkHereLink(linkName))
			reportPass("Link: " + linkName + " is clicked in small talk message ");
		else
			reportFail("Link: " + linkName + " is not clicked in small talk message ");
	}

	@Then("I enter username as {string} in Manager Audit Trail Search page of Webcom application")
	public void i_enter_username_as_in_Manager_Audit_Trail_Search_page_of_Webcom_application(String userKey) {
		String userName = WOLTestBase.envProps.getProperty(userKey);
		boolean flag = commonpage.enterUserName(userName);
		if (flag)
			reportPass("Entered the username {" + userName + "}");
		else
			reportHardFail(
					"Incorrect username entered, Terminating execution. Please verify the username and re-execute the script.");
	}

	@Then("I click on View link to verify the phone numbers in {string} page")
	public void i_click_on_View_link_to_verify_the_phone_numbers_in_page(String pageName) {
		if (addressPhoneChangePage.checkPhoneNumbers(listValues, pageName))
			reportPass("Phone Numbers: " + listValues.toString() + " is displayed ");
		else
			reportHardFail("Updated Phone numbers are not displayed");
	}

}
