package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.TaxFormsPage;

import cucumber.api.java.en.When;

public class TaxFormsSteps extends ObjectBase {

	TaxFormsPage taxFormsPage = new TaxFormsPage();
	String data = "";

	@When("I Enter the value in {string} field")
	public void i_Enter_the_value_in_field(String labelName) {
		data = jsonDataParser.getTestDataMap().get(labelName);
		if (taxFormsPage.enterDataInField(data, labelName))
			reportPass("Input value: " + data + " is entered in Field: " + labelName + " in taxforms page");
		else
			reportFail("Input value is not entered at Field: " + labelName + " in taxforms page");
	}

	@When("I Enter the {string} value in {string} field")
	public void i_Enter_the_value_in_field(String value, String labelName) {
		data = jsonDataParser.getTestDataMap().get(value);
		if (taxFormsPage.enterDataInField(data, labelName))
			reportPass("Input value: " + data + " is entered in Field: " + labelName + " in taxforms page");
		else
			reportFail("Input value is not entered at Field: " + labelName + " in taxforms page");
	}

	@When("I select the value in {string} field")
	public void i_select_the_value_in_field(String labelName) {
		data = jsonDataParser.getTestDataMap().get(labelName);
		if (taxFormsPage.selectDataInField(data, labelName))
			reportPass("Input value : " + data + " is selected in Field: " + labelName + " in taxforms page");
		else
			reportFail("Input value is not selected at Field: " + labelName + " in taxforms page");
	}

	@When("I click on {string} button in Taxforms")
	public void i_click_on_button_in_Taxforms(String btnName) {
		if (taxFormsPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@When("I verify the {string} message in taxforms")
	public void i_verify_the_message_in_taxforms(String labelName) {
		data = jsonDataParser.getTestDataMap().get(labelName);
		if (taxFormsPage.verifyMessage(data, labelName))
			reportPass("Message: " + data + " is displayed");
		else
			reportFail("Message: " + data + " is not displayed");
	}

	@When("I clear the value in {string} field")
	public void i_clear_the_value_in_field(String fieldName) {
		if (taxFormsPage.clearValuesInFields(fieldName))
			reportPass("Field Name: " + fieldName + " is cleared");
		else
			reportFail("Field Name: " + fieldName + " is not cleared");
	}

	@When("I verify the Taxforms is displayed")
	public void i_verify_the_Taxforms_is_displayed() {
		if (taxFormsPage.verifyTaxForms())
			reportPass("Tax Forms table is displayed");
		else
			reportFail("Tax Forms table is not displayed");
	}

	@When("I click on {string} link in Taxforms")
	public void i_click_on_link_in_Taxforms(String linkName) {
		if (taxFormsPage.clickOnButton(linkName))
			reportPass("Link: " + linkName + " is clicked");
		else
			reportFail("Link: " + linkName + " is not clicked");
	}

	@When("I verify the labels are displayed")
	public void i_verify_the_labels_are_displayed() {
		testDataMap = jsonDataParser.getTestDataMap();
		if (taxFormsPage.verifyLabels(testDataMap))
			reportPass("Labels: " + testDataMap.values().toString() + " is displayed in taxforms page");
		else
			reportFail("Labels: " + testDataMap.values().toString() + " is not displayed in taxforms page");
	}
}