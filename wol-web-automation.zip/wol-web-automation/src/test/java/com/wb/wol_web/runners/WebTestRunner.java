package com.wb.wol_web.runners;

import com.wb.java_af.testbases.CucumberTestBase;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = { "src/test/resources/features/web" }, glue = "com.wb.wol_web.steps", plugin = { "pretty",
		"json:target/cucumber-reports/CucumberTestReport.json",
		"rerun:target/cucumber-reports/rerun.txt" }, monochrome = true, strict = false, dryRun = false)

public class WebTestRunner extends CucumberTestBase {
}