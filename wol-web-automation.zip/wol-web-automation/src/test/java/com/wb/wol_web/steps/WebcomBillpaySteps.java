package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.WebcomBillPayPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WebcomBillpaySteps extends ObjectBase {

	WebcomBillPayPage webcomBillPayPage = new WebcomBillPayPage();

	@Then("I should goto WOL application and should display {string}")
	public void i_should_goto_WOL_application_and_should_display(String pgTitle) {
		if (webcomBillPayPage.verifyWolBillPayPageTitle(pgTitle))
			reportPass("CSR Admin navigated to WOL { " + pgTitle + " } page successfully");
		else
			reportHardFail("CSR Admin failed to navigated WOL { " + pgTitle + " } page");
	}

	@Then("I should go to Pass application and should show {string}")
	public void i_should_go_to_Pass_application_and_should_show(String pgTitle) {
		if (webcomBillPayPage.verifyPassApplicationTitle(pgTitle))
			reportPass("CSR Admin navigated to Payveris application and verified { " + pgTitle + " } successfully");
		else
			reportFail("CSR Admin failed to navigated { " + pgTitle + " }  application");
	}

	@Then("I should see {string} in pass aaplication")
	public void i_should_see_in_pass_aaplication(String txtToVerify) {
		if (webcomBillPayPage.verifySubmitResearchText(txtToVerify))
			reportPass(
					"CSR Admin navigated to Payveris application and verified{ " + txtToVerify + " } text successfully");
		else
			reportFail("CSR Admin failed to verify { " + txtToVerify + " } in Payveris application");
	}

	@Then("I should navigate to unauthorized access page with title {string}")
	public void i_should_navigate_to_unauthorized_access_page_with_title(String pgTitle) {
		if (webcomBillPayPage.verifyUnauthUserAccessTitle(pgTitle))
			reportPass("CSR admin navigated to { " + pgTitle + "} page in WOL application");
		else 
			reportFail("CSR admin Failed to navigate { "+ pgTitle +" } page ");
		
	}
	
	@Then("I should see unautorized access message in WOL page")
	public void i_should_see_unautorized_access_message_in_WOL_page() {
	   if (webcomBillPayPage.verifyUnauthUserAccessMag(testDataMap))
		   reportPass("Verified unauthorized user access message { "+testDataMap.get("UnAuthMessage")+" } is displayed successfully in WOL application");
	   else
		   reportFail("Failed to verify { "+testDataMap.get("UnAuthMessage")+" } Message in WOL application");
	}

	@Then("I click on any status {string} edit link in manage nan-webster accounts page")
	public void i_click_on_any_status_edit_link_in_manage_nan_webster_accounts_page(String editText) { 
	    if (webcomBillPayPage.clickOnEditIconInExtAcctPage(editText))
	    	reportPass("Clicked on the edit icon in { Manage Non-Webster Transfer Accounts } page successfully");
	    else 
	    	reportFail("Failed to click on edit icon in { Manage Non-Webster Transfer Accounts } page");
	}
	
	@When("I click on any delivery date link in manage pending payments page")
	public void i_click_on_any_delivery_date_link_in_manage_pending_payments_page() {
	   if (webcomBillPayPage.clickOnDeliveryDateLinkInMngPendPmtsPage())
		   reportPass("Clicked on the Delivery date in { Manage Pending Payments } page");
	   else
		   reportFail("Failed to click on delivery date in { Manage Pending Payments } page");		   
	}

	@When("I select the payment alert options")
	public void i_select_the_payment_alert_options() {
		if (webcomBillPayPage.selectPmtAlertOptions())
			reportPass("Selected the { When Payment id delivered } check box successfully");
		else
			reportFail("Failed to select { When payment is delivered } check box");    
	}

	@Then("I click on pmtupdate button")
	public void i_click_on_pmtupdate_button() {
		if (webcomBillPayPage.clickPmtUpdate())
			reportPass("Clicked on the { Update } button successfully");
		else
			reportFail("Failed to click on { Update } button");
	    
	}
}
