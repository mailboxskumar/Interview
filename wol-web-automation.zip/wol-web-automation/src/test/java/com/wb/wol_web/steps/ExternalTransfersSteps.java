package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.ExternalTransfersPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class ExternalTransfersSteps extends ObjectBase {

	ExternalTransfersPage externalTransfersPage = new ExternalTransfersPage();

	@Then("^I should see all the entered details$")
	public void i_should_see_all_the_entered_details() throws Throwable {
		externalTransfersPage.getEnteredDetails();
	}

	@Then("^I should be in \"([^\"]*)\" page in External Transfer functionality$")
	public void i_should_be_in_something_page_in_external_transfer_functionality(String message) throws Throwable {
		if (externalTransfersPage.verifyExternalTransfersPageTitle(message))
			reportPass("The Page: " + message + " is successfully displayed");
		else
			reportHardFail("The Page: " + message + " is not displayed");
	}

	@When("^I enter transfer details retrieved from json to set up external Transfer$")
	public void i_Entered_required_details_to_set_up_Transfer_in_Transfer_Between_Webster_Accounts_Page_from_json()
			throws Throwable {
		List<Map<String, String>> transferDetails = new ArrayList<Map<String, String>>();
		transferDetails.add(jsonDataParser.getTestDataMap());
		externalTransfersPage.selectTransferFromAcct(transferDetails);
		externalTransfersPage.selectTransferToAcct(transferDetails);
		externalTransfersPage.selectTransferType(transferDetails);
		externalTransfersPage.selectRecurringDetails(transferDetails);
		if (externalTransfersPage.enterAmount(transferDetails))
			reportPass("Entered All the required Transfer Details " + transferDetails);
		else
			reportFail("Failed to enter Transfer Details");
	}

	@When("^I click On Edit Button in External Transfer$")
	public void i_click_on_edit_button_in_external_transfer() throws Throwable {
		if (externalTransfersPage.clickEditTransfer())
			reportPass("Clicked on Edit button in external Transfers Page");
		else
			reportFail("Failed to Click on Edit button");
	}

	@When("^I click on Disclosure Link$")
	public void i_click_on_disclosure_link() throws Throwable {
		if (externalTransfersPage.clickTransferDisclosure())
			reportPass("Clicked on External Transfer Disclosure Link");
		else
			reportFail("Failed to click External Transfer Disclosure Link");
	}

	@Then("^I should see the Disclosure Lightbox Details$")
	public void i_should_see_the_disclosure_lightbox_details() throws Throwable {
		externalTransfersPage.getDisclosureDetails();
	}

	@When("^I check for the print button in Disclosure Lightbox$")
	public void i_check_button_of_disclosure_lightbox() throws Throwable {
		if (externalTransfersPage.checkDisclosurePrintButton()) {
			reportPass("print button is displayed in the  disclosure");
		} else {
			reportFail("Failed to check print button of Disclosure");
		}
	}

	@When("^I  Close button of Disclosure Lightbox$")
	public void i_close_button_of_disclosure_lightbox() throws Throwable {
		try {
			externalTransfersPage.clickDisclosureCloseButton();
			reportPass("Clicked on Close button of Disclosure");
		} catch (Exception e) {
			reportFail("Failed to click on Close button of Disclosure");
		}
	}

	@Then("I click on the cancel button in print dialog box")
	public void i_click_on_the_cancel_button_in_print_dialog_box() {
		if (externalTransfersPage.clickOnCanceltButtonInPrint()) {
			reportPass("Clicked on cancel in print dialob box");
		} else {
			reportFail("Failed to click on cancel button of print dialog");
		}

	}

	@And("^I click on Transfer button to set up external Transfer$")
	public void i_click_on_transfer_button_to_set_up_external_transfer() throws Throwable {
		try {
			externalTransfersPage.clickContinueToTransfer();
			reportPass("Clicked on Transfer button in External Transfer");
		} catch (Exception e) {
			reportHardFail("Failed to click on Transfer Button");
		}
	}

	@When("^I enter Transfer Details to set up external Transfer$")
	public void i_Entered_required_details_to_set_up_Transfer_in_Transfer_Between_Webster_Accounts_Page(DataTable table)
			throws Throwable {
		List<Map<String, String>> jsonDetails = table.asMaps(String.class, String.class);
		List<Map<String, String>> transferDetails = new ArrayList<Map<String, String>>();

		Map<String, String> map = new HashMap<String, String>();

		map = jsonDataParser.parseJsonTestData(WOLTestBase.props.getProperty("externaltransfers.json.file.name"),
				jsonDetails.get(0).get("PaymentDetails"));
		transferDetails.add(map);

		externalTransfersPage.selectTransferFromAcct(transferDetails);
		externalTransfersPage.selectTransferToAcct(transferDetails);
		externalTransfersPage.selectTransferType(transferDetails);
		if (transferDetails.get(0).get("transferType").equals("R"))
			externalTransfersPage.selectRecurringDetails(transferDetails);
		if (externalTransfersPage.enterAmount(transferDetails))
			reportPass("Entered All the required Transfer Details " + transferDetails);
		else
			reportFail("Failed to enter Transfer Details");
	}

	@And("^I should see all the entered details in Verification page$")
	public void i_should_see_all_the_entered_details_in_verification_page() throws Throwable {
		if (externalTransfersPage.validateVerificationDetails())
			reportPass("External Transfer Verification matched with entered details are : " + wolWebUtil.returnMap
					+ "  successfully displayed");
		else {
			reportFail("External Transfer Verification details are   not displayed");
		}
	}

	@And("^I should see all the entered details in Confirmation page$")
	public void i_should_see_all_the_entered_details_in_confirmation_page() throws Throwable {
		if (externalTransfersPage.validateConfirmationDetails())
			reportPass("External Transfer Confirmation matched with entered details are : " + wolWebUtil.returnMap
					+ "  successfully displayed");
		else {
			reportFail("External Transfer Confirmation details are   not displayed");
		}
	}

	@And("^I should see details in Verification page$")
	public void i_should_see_details_in_verification_page() throws Throwable {
		externalTransfersPage.getTransferCnfrmDetails();
	}

	@And("^I should see details in Confirmation page$")
	public void i_should_see_details_in_confirmation_page() throws Throwable {
		externalTransfersPage.getTransferCnfrmDetails();
	}

	@When("^I should get confirmation number from external Transfer$")
	public void i_should_get_confirmation_number_from_external_transfer() throws Throwable {
		try {
			externalTransfersPage.getTransferConfirmationNumber();
			reportPass("External Transfer Confirmation number is: " + externalTransfersPage.confirmNumber);
		} catch (Exception e) {
			reportHardFail("Failed to get confirmation number");
		}
	}

	@When("^I click on Date Link of the external confirmation number in Pending Transfers Page$")
	public void i_click_on_date_link_of_the_external_confirmation_number_in_pending_transfers_page() throws Throwable {
		try {
			externalTransfersPage.clickDateLinkinTableByValue();
			reportPass("Clicked on Date link of pending Non-webster Transfer");
		} catch (Exception e) {
			reportFail("Failed to click on Date link of pending Non-webster Transfer");
		}

	}

	@When("^I click on delete link of the external confirmation number in Pending Transfers Page$")
	public void i_click_on_delete_link_of_the_external_confirmation_number_in_pending_transfers_page()
			throws Throwable {
		try {
			externalTransfersPage.clickDeleteLinkinTableByValue();
			reportPass("Clicked on delete link of pending Non-webster Transfer");
		} catch (Exception e) {
			reportFail("Failed to delete on Date link of pending Non-webster Transfer");
		}

	}

	@And("^I should see the message \"([^\"]*)\"$")
	public void i_should_see_the_message_something(String messageContent) throws Throwable {
		String message = jsonDataParser.getTestDataMap().get(messageContent);
		if (externalTransfersPage.verifyMsg(message))
			reportPass("The  message: {" + message + "} is successfully displayed");
		else
			reportFail("The  message: " + message + " is not displayed");
	}

	@And("^I should see the Note content \"([^\"]*)\"$")
	public void i_should_see_the_note_content_something(String message) throws Throwable {
		if (externalTransfersPage.verifyNoteMsg(message))
			reportPass("The Note content {" + jsonDataParser.getTestDataMap().get(message)
					+ "} is successfully displayed");
		else
			reportFail("The Note content {" + jsonDataParser.getTestDataMap().get(message) + "} is not displayed");
	}

	@And("^I should see the Note content \"([^\"]*)\" in confirmation page$")
	public void i_should_see_the_note_content_something_in_confirmation_page(String message) throws Throwable {
		if (externalTransfersPage.verifyNoteMsgConfirmation(message))
			reportPass("The Note content {" + testDataMap.get(message) + "} is successfully displayed");
		else
			reportFail("The Note content {" + testDataMap.get(message) + "} is not displayed");
	}

	@When("I click on the cancel button and click on the {string} button from dialog box")
	public void i_click_on_the_cancel_button_and_click_on_the_button_from_dialog_box(String btnType) {
		externalTransfersPage.clickOnCancel();
		if (externalTransfersPage.clickOnCancelYesOrNo(btnType))
			reportPass("Clicked on cancel and selected " + btnType + " option");
		else
			reportFail("Failed to click on cancel and selected " + btnType + " option");
	}

	@Then("^I should see error message \"([^\"]*)\" in External Transfer functionality page$")
	public void i_should_see_error_message_something_in_external_transfer_functionality_page(String message)
			throws Throwable {
		if (externalTransfersPage.verifyExtTransferErrorMessage(message))
			reportPass("The error message: " + message + " is successfully displayed");
		else
			reportFail("The error message: " + message + " is not displayed");
	}

	@Then("^I should get the error message \"([^\"]*)\" in External Transfer functionality page$")
	public void i_should_get_error_message_something_in_external_transfer_functionality_page(String message1)
			throws Throwable {
		String message = jsonDataParser.getTestDataMap().get(message1);
		if (externalTransfersPage.verifyExtTransferErrorMessageList(message))
			reportPass("The error message: " + message + " is successfully displayed");
		else
			reportFail("The error message: " + message + " is not displayed");
	}

	@When("I enter invalid data {string} in date field")
	public void i_enter_invalid_data_in_date_field(String date) {
		String invalidDate = jsonDataParser.getTestDataMap().get(date);
		if (externalTransfersPage.enterInvalidDate(invalidDate))
			reportPass("Entered invalid date " + invalidDate);
		else
			reportHardFail("Failed to enter invalid date " + invalidDate);

	}

	@Then("I should get the error message {string} in external transfer functionality")
	public void i_should_get_the_error_message_in_external_transfer_functionality(String errorMsg) {
		String msg = jsonDataParser.getTestDataMap().get(errorMsg);
		if (externalTransfersPage.checkForErrorMessage(msg))
			reportPass("The error message {" + msg + "} is found");
		else
			reportFail("The error message {" + msg + "} is not found");

	}

	@Then("I should get the message {string} for {string} in the external transfer functionality")
	public void i_should_get_the_message_for_in_the_external_transfer_functionality(String msg, String type) {
		if (externalTransfersPage.checkForTheMessages(msg, type))
			reportPass("The message {" + msg + "} is found");
		else
			reportFail("The  message {" + msg + "} is not found");

	}

	@When("I change the transfer type to {string}")
	public void i_change_the_transfer_type_to(String type) {

		List<Map<String, String>> transferDetails = new ArrayList<Map<String, String>>();
		Map<String, String> map = new HashMap<String, String>();
		try {
			if (type.equals("Recurring"))
				map.put("transferType", "R");
			else
				map.put("transferType", "O");
			transferDetails.add(map);
			externalTransfersPage.selectTransferType(transferDetails);
			reportPass("Selected the transfer type " + type);
		} catch (Exception e) {
			reportFail("Failed to select the transfer type");

		}

	}

	@Then("I should see Frequency and number of transfers labels")
	public void i_should_see_Frequency_and_number_of_transfers_labels() {

		if (externalTransfersPage.checkForFrequencyAndNoOfTransfers())
			reportPass("Frequency and number of transfers labels are found");
		else
			reportFail("Frequency and number of transfers labels are  not found");

	}

	@Then("I should not see Frequency and number of transfers labels")
	public void i_should_not_see_Frequency_and_number_of_transfers_labels() {

		if (!externalTransfersPage.checkForFrequencyAndNoOfTransfers())
			reportPass("Frequency and number of transfers labels are not found");
		else
			reportFail("Frequency and number of transfers labels are found");

	}

	@Then("I enter the following values as the data")
	public void i_enter_the_following_values_as_the_data(DataTable dataTable) {
		try {
			List<Map<String, String>> jsonDetails = dataTable.asMaps(String.class, String.class);
			List<Map<String, String>> transferDetails = new ArrayList<Map<String, String>>();

			Map<String, String> map = new HashMap<String, String>();
			map = jsonDataParser.parseJsonTestData("ExternalTransfers.json", jsonDetails.get(0).get("PaymentDetails"));
			transferDetails.add(map);

			externalTransfersPage.selectRecurringDetails(transferDetails);
		} catch (Exception e) {
			reportFail("Failed to enter the recurring account details");
		}

	}

	@Then("I click on continue button in manage transfers functionality")
	public void i_click_on_continue_button_in_manage_transfers_functionality() {
		if (externalTransfersPage.clickOnContinueInManageTransfers())
			reportPass("Clicked on the continue button");

		else
			reportFail("Failed to click on the continue button");

	}

	@Then("I click on update button in manage transfers functionality")
	public void i_click_on_update_button_in_manage_transfers_functionality() {
		if (externalTransfersPage.clickOnContinueInManageTransfers())
			reportPass("Clicked on the continue button");

		else
			reportFail("Failed to click on the continue button");

	}

	@Then("I should see that transfer type {string} is pre selected")
	public void i_should_see_that_transfer_type_is_pre_selected(String transfertype) {
		if (externalTransfersPage.checkIfPreselected(transfertype))
			reportPass("Transfer type " + transfertype + " is pre selected");

		else
			reportFail("Transfer type " + transfertype + " is not pre selected");
	}

	@When("I enter a future date {string} days from today in date field")
	public void i_enter_a_future_date_days_from_today_in_date_field(String days) {
		try {
			externalTransfersPage.enterTransferDate(Integer.parseInt(days));
			reportPass("Entered the future date " + days + " days from now");
		} catch (NumberFormatException e) {
			reportHardFail("Failed to enter the future date ");
		}
	}

	@Then("I should get the {string} block in main webcom page")
	public void i_should_get_the_block_in_main_webcom_page(String messageTitle) {
		if (externalTransfersPage.verifySearchOptionsTitle(messageTitle)) {
			reportPass("Title {" + messageTitle + "} is found");
		} else {
			reportFail("Title {" + messageTitle + "} is not found");
		}
	}

	@When("I select the transactions type as {string}")
	public void i_select_the_transactions_type_as(String type) {
		if (externalTransfersPage.clickOnTransferTypeInWebcom(type)) {
			reportPass("Clicked on the transcation type " + type);
		} else {
			reportHardFail("Failed to click on the transcation type " + type);
		}
	}

	@When("I enter the  from and to dates which filter the transactions")
	public void i_enter_the_from_and_to_dates_which_filter_the_transactions() {
		try {
			String dates = externalTransfersPage.enterToAndFromDateValuesInWebcom();
			reportPass("Entered the dates " + dates + " in the filters");
		} catch (Exception e) {
			reportFail("Failed to enter from and to dates ");
		}
	}

	@And("I click on search button in webcom main page")
	public void i_click_on_buton_webcom() {
		if (externalTransfersPage.clickOnSearchButtonInWebcom()) {
			reportPass("Clicked on the search button in webcom main page");
		} else {
			reportFail("Failed to click on the search button in webcom main page");
		}
	}

	@Then("I check if the list of transactions displayed are in the same range of dates given")
	public void i_check_if_the_list_of_transactions_displayed_are_in_the_same_range_of_dates_given() {
		String outdates = externalTransfersPage.compareDatesInWebcomSearch();
		if (outdates.equals("")) {
			reportPass("All the listed trnasactions are in the range ");
		} else {
			reportFail("The trnasactions with theses are not in the range" + outdates);
		}
	}

	@Then("I should get details in delete verification page")
	public void i_should_get_details_in_delete_verification_page() {
		externalTransfersPage.getTransferCnfrmDetails();
	}

	@Then("I should see all the entered details in delete verification page")
	public void i_should_see_all_the_entered_details_in_delete_verification_page() {

	}

	@Then("I click on the delete button")
	public void i_clik_on_the_delete_button() {
		if (externalTransfersPage.clickOnDelete()) {
			reportPass("Clicked on the delete button");
		} else {
			reportFail("Failed to click on the delete button");

		}
	}

	@Then("I check if the buttons {string} are displayed")
	public void i_check_if_the_buttons_are_displayed(String buttons) {
		String actualButtonsDisp = externalTransfersPage.checkForTheButtonsExistence(buttons);
		if (actualButtonsDisp.replaceAll(",", "").equals(buttons.replaceAll(",", ""))) {
			reportPass("All the buttons {" + buttons + "} are displayed in the page");
		} else {
			reportFail("Buttons displayed in the page are {" + actualButtonsDisp + "}");
		}
	}

	@Then("I check the prepopulated data is same as the data entered before")
	public void i_check_the_prepopulated_data_is_same_as_the_data_entered_before() {
		externalTransfersPage.getUpdatedDetails();
		if (externalTransfersPage.validateUpdatedDetails())
			reportPass("Data prepopulated upon clicking edit button are same as the  with details changed : "
					+ wolWebUtil.returnMap);
		else {
			reportFail("External Transfer prepopulated details are not same");
		}
	}

	@Then("I get the selected account from which the transfer is made")
	public void i_get_the_selected_account_from_which_the_transfer_is_made() {
		String accountSelected = externalTransfersPage.getFromAccount();
		if (!accountSelected.equals("")) {
			reportPass("Transfer is made from the account " + accountSelected);
		} else {
			reportFail("Failed to get the account from which the transfer is made");
		}
	}

	@When("I enter the date value as {string}")
	public void i_enter_the_date_value_as(String date) {
		try {
			externalTransfersPage.enterTheDate(date);
			if (date.equals("Empty"))
				reportPass("Cleared the date value");
			else if (date.equals("Past Date"))
				reportPass("Entered the past value in the date column");
			else
				reportPass("Entered the invalid date value : *^()");
		} catch (Exception e) {
			reportFail("Failed to enter the date value in external transfer payment details");
		}
	}

}