package com.wb.wol_web.steps;

import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.pages.SetUpTaxPaymentsPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class SetupTaxPaymentsSteps extends ObjectBase {

	SetUpTaxPaymentsPage taxPaymentsPage = new SetUpTaxPaymentsPage();

	@Then("^I should be in Txpmt \"([^\"]*)\" page$")
	public void i_should_be_in_Txpmt_page(String txPmtTtlVerify) throws Throwable {
		if (taxPaymentsPage.verifyTaxPaymentTtl(txPmtTtlVerify) == true)

			reportPass(txPmtTtlVerify + " is Displaying Successfully");
		else
			reportFail(txPmtTtlVerify + " is not Displaying");
	}

	@When("^User Entered required fields like \"([^\"]*)\" and Click on Continue Button$")
	public void user_Entered_required_fields_like_and_Click_on_Continue_Button(String payeeNameKey) throws Throwable {
		try {
			String txtPayeeName = jsonDataParser.getTestDataMap().get(payeeNameKey);
			taxPaymentsPage.inputTaxPaymentDetails(txtPayeeName, jsonDataParser.getTestDataMap());
			reportPass("User Entered All Tax Payments Details Successfully for the State : " + txtPayeeName);
		} catch (Exception e) {
			reportHardFail("Unable to enter the required values in Tax Payments page");
		}
	}

	@Then("^User should Navigate to TaxPmtVer \"([^\"]*)\" Page$")
	public void user_should_Navigate_to_TaxPmtVer_Page(String pgTtlTxPmtVeri) throws Throwable {
		if (taxPaymentsPage.verifyTaxPaymentVerificationPage(pgTtlTxPmtVeri) == true)
			reportPass("User navigated to " + pgTtlTxPmtVeri + " Page successfully");
		else
			reportFail("User Not Navigated to " + pgTtlTxPmtVeri + "Page");
	}

	@Then("^Get provided tax payment values$")
	public void get_provided_tax_payment_values() throws Throwable {
		try {
			taxPaymentsPage.getGivenTaxPaymentValues();
			reportPass("Successfully retrieved the given values from the application in Tax Payments creation page");
		} catch (Exception e) {
			reportFail("Unable to get the value from the application");
		}
	}

	@Then("^User Click on Edit Button in Tax Payment Verification Page$")
	public void user_Click_on_Edit_Button_in_Tax_Payment_Verification_Page() throws Throwable {
		try {
			taxPaymentsPage.clickEditonTaxPayment();
			reportPass("User clicked on { Edit } button successfully in Tax Payment verification page");
		} catch (Exception e) {
			reportHardFail("Unable to click on { Edit } button");
		}
	}

	@Then("^User Click on Continue Button in Tax Payment Page$")
	public void user_Click_on_Continue_Button_in_Tax_Payment_Page() throws Throwable {
		if (taxPaymentsPage.clickContinueTaxPayment())
			reportPass("User clicked on { Continue } button successfully in Tax Payments creation page");
		else
			reportHardFail("User unable to click on Continue button");
	}

	@Then("^User Click on Cancel Button in TaxPmt Verification Page$")
	public void user_Click_on_Cancel_Button_in_TaxPmt_Verification_Page() throws Throwable {
		try {
			taxPaymentsPage.clickCancelButtonTaxPayment();
			reportPass("User clicked on { Cancel } button successfully in tax payments verification page");
		} catch (Exception e) {
			reportFail("Unable to click on { Cancel } button");
		}
	}

	@Then("^User Click on No Button in Lightbox under TaxPmt Verification Page$")
	public void user_Click_on_No_Button_in_Lightbox_under_TaxPmt_Verification_Page() throws Throwable {
		try {
			taxPaymentsPage.clickNoButtonTaxPaymentLgtBox();
			reportPass("User clicked on { No } button successfully in the light box");
		} catch (Exception e) {
			reportFail("User unable to click on No button");
		}
	}

	@Then("^User Click on Yes Button in Lightbox under TaxPmt Verification Page$")
	public void user_Click_on_Yes_Button_in_Lightbox_under_TaxPmt_Verification_Page() throws Throwable {
		try {
			taxPaymentsPage.clickYesButtonTaxPaymentLgtBox();
			reportPass("User clicked on { Yes } button successfully in the light box");
		} catch (Exception e) {
			reportFail(" User unable to click on { Yes } button in light box");
		}
	}

	@When("^User Click on Setup Payment Button in Tax Payment Verification Page$")
	public void user_Click_on_Setup_Payment_Button_in_Tax_Payment_Verification_Page() throws Throwable {
		if (taxPaymentsPage.clickSetUpPaymentButton())
			reportPass("User clicked { Setup Payment } button successfully");
		else
			reportHardFail("Unable to click on { Setup Payment } button");
	}

	@Then("^User should Navigate to TaxPmtConf \"([^\"]*)\" Page$")
	public void user_should_Navigate_to_TaxPmtConf_Page(String pgTtlConfirm) throws Throwable {
		if (taxPaymentsPage.verifyTaxConfirmPage(pgTtlConfirm))
			reportPass("User navigated to { " + pgTtlConfirm + " }Page successfully");
		else
			reportFail("User failed to navigate " + pgTtlConfirm + "Page");
	}

	@Then("^Verify field values in tax payment confirmation page$")
	public void verify_field_values_in_tax_payment_confirmation_page() throws Throwable {
		try {
			taxPaymentsPage.getTaxPaymentConfirmDetails();
			reportPass("User verified confirmation details{ " + taxPaymentsPage.confirmTaxDetails
					+ " } tax payment confirmation page Page");
		} catch (Exception e) {
			reportFail("User unable to see all the field in confirmation page");
		}
	}

	@Then("^Verify confirmation details in tax payment confirmation page$")
	public void verify_confirmation_details_in_tax_payment_confirmation_page() {
		if (taxPaymentsPage.verifyTaxPaymentConfirmationDetails() == true)
			reportPass("User verified all the values in { Tax Payment Confirmation } page successfully");
		else
			reportFail("Faild to verify confirmation details with given value");
	}

	@Then("^Get Tax Payment Confirmation No$")
	public void get_Tax_Payment_Confirmation_No() throws Throwable {
		if (!taxPaymentsPage.getTaxConfirmationNo().isEmpty())
			reportPass(" Tax Payment Confirmation No { " + taxPaymentsPage.taxConfirmNo + " } retrieved successfully");
		else
			reportHardFail("Unable to retrieve the Confirmation Numnber");
	}

	@Then("^I should be in PendingPmt \"([^\"]*)\" page$")
	public void i_should_be_in_PendingPmt_page(String pgTtlPenPmt) throws Throwable {
		if (taxPaymentsPage.verifyPendingPaymentsPageTtl(pgTtlPenPmt))
			reportPass("User navigated to { " + pgTtlPenPmt + " } page successfully");
		else
			reportFail("User failed to navigate { " + pgTtlPenPmt + " } page");
	}

	@Then("^Verify Scheduled Tax Payment with confirmation no$")
	public void verify_Scheduled_Tax_Payment_with_confirmation_no() throws Throwable {
		if (taxPaymentsPage.verifyTaxPmtConfirmationNoInPendingPayments())
			reportPass("Tax payment confirmation number { " + taxPaymentsPage.taxConfirmNo
					+ " } verified successfully in pending payments page");
		else
			reportFail("Faild to verify Tax paymentconfirmation number in Pending Payments page");
	}

	@When("^^User Entered Invalid values for payee name starts with \"([^\"]*)\" and Click on Continue Button$$")
	public void user_Entered_Invalid_values_for_payee_name_starts_with_and_Click_on_Continue_Button(String payeeNameKey)
			throws Throwable {
		try {
			String txtPayeeName = jsonDataParser.getTestDataMap().get(payeeNameKey);
			taxPaymentsPage.inputInvalidTaxPaymentDetails(txtPayeeName, jsonDataParser.getTestDataMap());
			reportPass("Entered all the values provided by user in Tax Payments creation page");
		} catch (Exception e) {
			reportHardFail("Unable to enter Invalid Values");
		}
	}

	@Then("^Verify Tax Period End Date error Message is \"([^\"]*)\"$")
	public void verify_Tax_Period_End_Date_error_Message_is(String taxEndDtErrMsg) throws Throwable {
		if (taxPaymentsPage.verifyTaxEndDatetErrMsg(taxEndDtErrMsg))
			reportPass("The error message {" + taxEndDtErrMsg + " }is successfully displayed");
		else
			reportFail("The error message { " + taxEndDtErrMsg + " } is not displayed");
	}

	@Then("^Verify Tax Period End Date error Message is \"([^\"]*)\" for 10 Years Before Date$")
	public void verify_Tax_Period_End_Date_error_Message_is_for_10_Years_Before_Date(String taxEndDtErrMsg)
			throws Throwable {
		if (taxPaymentsPage.verifyTaxEndDateErrMsgFor10YearsBefore(taxEndDtErrMsg))
			reportPass(" The error message {" + taxPaymentsPage.taxEndDateErrMsgFor10YearsBefore
					+ " } is successfully displayed");
		else
			reportFail(
					"The error message { " + taxPaymentsPage.taxEndDateErrMsgFor10YearsBefore + " } is not displayed");
	}

	@Then("^Verify Tax Amount error Message is \"([^\"]*)\" when Amount empty$")
	public void verify_Tax_Amount_error_Message_is_when_Amount_empty(String taxAmountErrMsg) throws Throwable {
		if (taxPaymentsPage.verifyTaxAmountErrMsg(taxAmountErrMsg))
			reportPass(" The error message { " + taxAmountErrMsg + " } is successfully displayed");
		else
			reportFail("The error message { " + taxAmountErrMsg + " } is not displayed");

	}

	@Then("^Verify Tax Amount error Message is \"([^\"]*)\" when given negative value$")
	public void verify_Tax_Amount_error_Message_is_when_given_negative_value(String taxAmountErrMsg) throws Throwable {
		if (taxPaymentsPage.verifyTaxAmountErrMsg(taxAmountErrMsg))
			reportPass(" The error message { " + taxAmountErrMsg + " } is successfully displayed");
		else
			reportFail("The error message { " + taxAmountErrMsg + " } is not displayed");
	}

	@Then("^Verify Tax Amount error Message is \"([^\"]*)\" when given alphanumeric value$")
	public void verify_Tax_Amount_error_Message_is_when_given_alphanumeric_value(String taxAmountErrMsg)
			throws Throwable {
		if (taxPaymentsPage.verifyTaxAmountErrMsg(taxAmountErrMsg))
			reportPass(" The error message { " + taxAmountErrMsg + " } is successfully displayed");
		else
			reportFail("The error message { " + taxAmountErrMsg + " } is not displayed");
	}

	@Then("^Verify Tax Amount error Message is \"([^\"]*)\" when given huge amount$")
	public void verify_Tax_Amount_error_Message_is_when_given_huge_amount(String taxAmountErrMsg) throws Throwable {
		if (taxPaymentsPage.verifyTaxAmountErrMsgForHugeAmount(taxAmountErrMsg))
			reportPass(" The error message { " + taxPaymentsPage.taxAmountErrMsgForHugeAmount
					+ " } is successfully displayed");
		else
			reportFail("The error message { " + taxPaymentsPage.taxAmountErrMsgForHugeAmount + " } is not displayed");
	}

	@Then("Verify Tax Payer Name Error Massage is {string}")
	public void verify_Tax_Payer_Name_Error_Massage_is(String taxPayerNameErrMsg) {
		if (taxPaymentsPage.verifyTaxPayerNameErrMsg(taxPayerNameErrMsg))
			reportPass("The error message { " + taxPayerNameErrMsg + " } is successfully displayed");
		else
			reportFail("The error message { " + taxPayerNameErrMsg + " } is not displayed");
	}

	@Then("Verify Access Code Error Massage is {string}")
	public void verify_Access_Code_Error_Massage_is(String accessCodeErrMsg) {
		if (taxPaymentsPage.verifyAccessCodeErrMsg(accessCodeErrMsg))
			reportPass("The error message { " + accessCodeErrMsg + " } is successfully displayed");
		else
			reportFail("The error message { " + accessCodeErrMsg + " } is not displayed");
	}

	@Then("Select valid Account {string} from Select an Account dropdown")
	public void select_valid_Account_from_Select_an_Account_dropdown(String lstSelectAccount) {
		lstSelectAccount = jsonDataParser.getTestDataMap().get("accountNumber");
		if (taxPaymentsPage.selectAccountForTaxPayment(lstSelectAccount))
			reportPass("Account selected successfully in Tax Payments creation page");
		else
			reportHardFail(" Account not selected from the dropdown");
	}

	@Then("Verify Error Message {string} for customer not having tax payees")
	public void verify_Error_Message_for_customer_not_having_tax_payees(String verNoPayeeErrMsg) {
		verNoPayeeErrMsg = jsonDataParser.getTestDataMap().get("errorMessage");
		if (taxPaymentsPage.verifyNoTaxPayeeErrorMessage(verNoPayeeErrMsg))
			reportPass("The Error Message { " + verNoPayeeErrMsg + " } is successfully displayed");
		else
			reportFail("The Error Message { " + verNoPayeeErrMsg + " } is not displayed");
	}

	@Then("Verify Tax Period End Date error Message for Wrong Date")
	public void verify_Tax_Period_End_Date_error_Message_for_Wrong_Date() throws Throwable {
		if (taxPaymentsPage.verifyTaxEndDateErrMsgForWrongDate())
			reportPass(" The error message { " + taxPaymentsPage.taxEndDateErrMsgForWrongDate
					+ " }is successfully dsipalyed");
		else
			reportFail("The error message { " + taxPaymentsPage.taxEndDateErrMsgForWrongDate + " } is not displayed");
	}

	@Then("I enter test data from {string} {string} and verify invalid error messages for payee name")
	public void i_enter_test_data_from_and_verify_invalid_error_messages_for_payee_name(String fileName,
			String testCaseName, io.cucumber.datatable.DataTable dataTable) throws InterruptedException {
		try {
			List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);
			for (int i = 0; i < details.size(); i++) {
				jsonDataParser.parseJsonTestData(fileName, testCaseName, details.get(i).get("TestSet"));
				String txtPayeeName = jsonDataParser.getTestDataMap().get("payeeName");
				taxPaymentsPage.inputInvalidTaxPaymentDetails(txtPayeeName, jsonDataParser.getTestDataMap());
				reportPass("Entered all the values provided by user in Tax Payments creation page");
				String message = jsonDataParser.getTestDataMap().get("ErrorMessage");
				if (message.contains("ValueToReplace")) {
					if (taxPaymentsPage.verifyTaxAmountErrMsgForHugeAmount(message))
						reportPass(" The error message { " + taxPaymentsPage.taxAmountErrMsgForHugeAmount
								+ " } is successfully displayed");
					else
						reportFail("The error message { " + taxPaymentsPage.taxAmountErrMsgForHugeAmount
								+ " } is not displayed");
				} else {
					if (taxPaymentsPage.verifyTaxPaymentsErrMsg(message))
						reportPass(" The error message { " + message + " } is successfully displayed");
					else
						reportFail("The error message { " + message + " } is not displayed");
				}
				new CommonPage().selectFromTheMenu(jsonDataParser.getTestDataMap().get("menu"),
						jsonDataParser.getTestDataMap().get("subMenu"));
				reportPass("Clicked the link " + jsonDataParser.getTestDataMap().get("subMenu") + " from "
						+ jsonDataParser.getTestDataMap().get("menu") + " Menu");
				if (taxPaymentsPage.verifyTaxPaymentTtl(jsonDataParser.getTestDataMap().get("pageTitle")) == true)

					reportPass(jsonDataParser.getTestDataMap().get("pageTitle") + " is Displaying Successfully");
				else
					reportFail(jsonDataParser.getTestDataMap().get("pageTitle") + " is not Displaying");
			}
		} catch (Exception e) {
			reportHardFail("Unable to enter Invalid Values");
		}

	}

	@Then("I select tax payee {string} in tax payments page")
	public void i_select_in_tax_payments_page(String payeeNameKey) {
		try {
			String txtPayeeName = jsonDataParser.getTestDataMap().get(payeeNameKey);
			taxPaymentsPage.selectTaxPayeeName(txtPayeeName);
			reportPass("User Entered All Tax Payments Details Successfully for the State : " + txtPayeeName);
		} catch (Exception e) {
			reportHardFail("Unable to enter the required values in Tax Payments page");
		}

	}

	@Then("Get current system month name")
	public void get_current_system_month_name() {
		try {
			taxPaymentsPage.getCurrentMonthName();
			reportPass("Retrieved current system month name { " + taxPaymentsPage.currentMonthName + " } successfully");
		} catch (Exception e) {
			reportFail("Failed to retrieve current system month name");
		}
	}

	@Then("Click on calender widget next to tax period end date")
	public void click_on_calender_widget_next_to_tax_period_end_date() {
		try {
			taxPaymentsPage.clickTaxEndDateCalender();
			reportPass("Clicked on tax period end date calender widget successfully");
		} catch (Exception e) {
			reportHardFail("Unable to click tax period end date calender widget");
		}
	}

	@Then("Get the current month name from calender widget")
	public void get_the_current_month_name_from_calender_widget() {
		try {
			taxPaymentsPage.getMonthNameFromCalenderWidget();
			reportPass(" Retrieved month name from calender widget{ " + taxPaymentsPage.calWidgetMonthName + " }");

		} catch (Exception e) {
			reportFail("Unable to retrieve the month name from calender widget");
		}
	}

	@Then("Compare tax period end date months")
	public void compare_tax_period_end_date_months() {
		if (taxPaymentsPage.compareTaxEndDateCurrnetMonths())
			reportPass("Given month is equal to calender widget month");
		else
			reportFail("Given month is not equal to calender widget month");
	}

	@Then("Enter tax period end date {string} in tax payment page")
	public void enter_tax_period_end_date_in_tax_payment_page(String taxPeriodEndDateKey) {
		try {
			String taxEndDate = jsonDataParser.getTestDataMap().get(taxPeriodEndDateKey);
			taxPaymentsPage.enterTaxPeriodEndDate(taxEndDate);
			reportPass("Entered tax end date successfully");
		} catch (Exception e) {
			reportFail("Failed to enter tax period end date in setup tax payments page");
		}
	}

	@Then("Compare the given month {string} with calender month")
	public void compare_the_given_month_with_calender_month(String monthKey) {
		String month = jsonDataParser.getTestDataMap().get(monthKey);
		if (taxPaymentsPage.compareGivenMonthWithWidgetMonth(month))
			reportPass("Given month is equal to calender widget month");
		else
			reportFail("Given month is not equal to calender widget month");
	}

}
