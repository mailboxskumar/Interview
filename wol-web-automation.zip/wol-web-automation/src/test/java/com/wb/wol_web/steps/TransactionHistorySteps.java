package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.TransactionHistoryPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class TransactionHistorySteps extends ObjectBase {

	TransactionHistoryPage transHistPage = new TransactionHistoryPage();
	List<String> listValues;
	@Then("^I Verify the \"([^\"]*)\" page$")
	public void i_Verify_the_page(String message) throws Throwable {
		if (transHistPage.verifyTransHistoryPage(message))
			reportPass(message + " Page is displayed");
		else
			reportHardFail(message + " Page is not displayed");
	}

	@When("^I click on Accounts dropdown list$")
	public void i_click_on_Accounts_dropdown_list() throws Throwable {
		if (transHistPage.clickOnAccList())
			reportPass("Account list is selected");
		else
			reportFail("Account list is not selected");
	}

	@When("^I select the \"([^\"]*)\" Account option$")
	public void i_select_the_Account_option(String account) throws Throwable {
		account =jsonDataParser.getTestDataMap().get(account);
		if (transHistPage.selectAccFromDropdown(account))
			reportPass(account + " is selected from Accounts dropdown");
		else
			reportFail(jsonDataParser.getTestDataMap().get(account) + " Account is not selected from Accounts dropdown");
	}

	@Then("^I verify the \"([^\"]*)\" label$")
	public void i_verify_the_label(String label) throws Throwable {
		if (transHistPage.verifyDateRangeLable(jsonDataParser.getTestDataMap().get(label)))
			reportPass("The Label :" + jsonDataParser.getTestDataMap().get(label) + " is displaying successfully");
		else
			reportFail("The Label :" + jsonDataParser.getTestDataMap().get(label) + " is not displaying");
	}

	@Then("^I verify the Date Range drop down values$")
	public void i_verify_the_Date_Range_drop_down_values() throws Throwable {
		listValues=new ArrayList<String>();
		listValues.addAll(jsonDataParser.getTestDataMap().values());
		if (transHistPage.verifyDropdownValues(listValues))
			reportPass(listValues.toString() + " Values are in the Date Range dropdown");
		else
			reportFail(listValues.toString() + " Values are not in the Date Range dropdown");
	}

	@When("^Again click on Date Range drop down without selecting any option$")
	public void again_click_on_Date_Range_drop_down_without_selecting_any_option() throws Throwable {
		if (transHistPage.clickOnDateRangeOption())
			reportPass("Date Range is clicked");
		else
			reportFail("Unable to click on Date Range");
	}

	@When("^I select \"([^\"]*)\" option$")
	public void i_select_option(String customRange) throws Throwable {
		if (transHistPage.selectCustomRange(jsonDataParser.getTestDataMap().get(customRange)))
			reportPass(jsonDataParser.getTestDataMap().get(customRange) + " is selected from Date Range dropdown");
		else
			reportFail(jsonDataParser.getTestDataMap().get(customRange) + " is not selected from Date Range dropdown");
	}

	@When("^I Enter \"([^\"]*)\" days back for from date field$")
	public void i_Enter_days_back_for_from_date_field(String fromDate) throws Throwable {
		if (!transHistPage.enterFromDate(jsonDataParser.getTestDataMap().get(fromDate)).equals(""))
			reportPass("From Date " + transHistPage.enterFromDate(jsonDataParser.getTestDataMap().get(fromDate)) + " is entered");
		else
			reportFail("From Date " + transHistPage.enterFromDate((jsonDataParser.getTestDataMap().get(fromDate))) + " is not entered");
	}

	@When("^I Enter \"([^\"]*)\" days back for to date field$")
	public void i_Enter_days_back_for_to_date_field(String toDate) throws Throwable {
		if (!transHistPage.enterToDate(jsonDataParser.getTestDataMap().get(toDate)).equals(""))
			reportPass("To Date " + transHistPage.enterToDate(jsonDataParser.getTestDataMap().get(toDate)) + " is entered");
		else
			reportFail("To Date " + transHistPage.enterToDate(jsonDataParser.getTestDataMap().get(toDate)) + " is not entered");
	}

	@When("^I click on Update button$")
	public void i_click_on_Update_button() throws Throwable {
		if (transHistPage.clickOnUpdate())
			reportPass("Update button is clicked");
		else
			reportFail("Unable to click on Update button");
	}

	@When("^I select Previous Statement$")
	public void i_select_Previous_Statement() throws Throwable {
		if (transHistPage.selectAccStmt())
			reportPass("Previous Statement option selected from Date Range dropdown");
		else
			reportFail("Unable to select the Previous Statement option from Date Range dropdown");
	}

	@Then("^I Verify \"([^\"]*)\" page should display$")
	public void i_Verify_page_should_display(String loanAccStmts) throws Throwable {
		if (transHistPage.verifyAccStmtsPage(loanAccStmts))
			reportPass(loanAccStmts + " Page is displayed");
		else
			reportFail(loanAccStmts + " Page is not displayed");
	}

	@Then("^From date field is grayed out$")
	public void from_date_field_is_grayed_out() throws Throwable {
		if (transHistPage.fromDateDisabled())
			reportPass("From Date is Disabled");
		else
			reportFail("From date is Enabled");
	}

	@Then("^To date field is grayed out$")
	public void to_date_field_is_grayed_out() throws Throwable {
		if (transHistPage.toDateDisabled())
			reportPass("To Date is Disabled");
		else
			reportFail("To date is Enabled");
	}

	@Then("^I verify the From Date error message as \"([^\"]*)\"$")
	public void i_verify_the_From_Date_error_message_as(String fromDateErrMsg) throws Throwable {
		if (transHistPage.verifyFromDateErrorMsg(jsonDataParser.getTestDataMap().get(fromDateErrMsg)))
			reportPass("From Date error :" + jsonDataParser.getTestDataMap().get(fromDateErrMsg) + " is displaying successfully");
		else
			reportFail("From Date error :" + jsonDataParser.getTestDataMap().get(fromDateErrMsg) + " is not displaying");
	}

	@Then("^I verify the To Date error message as \"([^\"]*)\"$")
	public void i_verify_the_To_Date_error_message_as(String toDateErrMsg) throws Throwable {
		if (transHistPage.verifyToDateErrorMsg(jsonDataParser.getTestDataMap().get(toDateErrMsg)))
			reportPass("To Date error :" + jsonDataParser.getTestDataMap().get(toDateErrMsg) + " is displaying successfully");
		else
			reportFail("To Date error :" + jsonDataParser.getTestDataMap().get(toDateErrMsg) + " is not displaying");
	}

	@Then("^I verify the \"([^\"]*)\" value not displayed in the List$")
	public void i_verify_the_value_not_displayed_in_the_List(String value) throws Throwable {
		if(transHistPage.valueNotInDropdown(jsonDataParser.getTestDataMap().get(value)))
			reportPass("Value :" + jsonDataParser.getTestDataMap().get(value) + " is not displaying in the Date Range dropdown");
		else
			reportFail("Value :" + jsonDataParser.getTestDataMap().get(value) + " is displaying in the Date Range dropdown");
	}

	@Then("^I verify the Date range$")
	public void i_verify_the_Date_range() throws Throwable {
		if (transHistPage.verifyDateInRange())
			reportPass("Date Range verified Successfully");
		else
			reportFail("Date Range not verified Successfully");
	}

	@Then("^I verify the Banner Image should display$")
	public void i_verify_the_Banner_Image_should_display() throws Throwable {
		if (transHistPage.bannerDisplayed())
			reportPass("Banner Image displayed");
		else
			reportFail("Banner Image not displayed");
	}

	@When("^I get the from date, To date and verify the Date Range values in the list$")
	public void i_get_the_from_date_To_date_and_verify_the_Date_Range_values_in_the_list() throws Throwable {
		if (transHistPage.verifyDateInRangeStatement())
			reportPass("Date Range verified Successfully");
		else
			reportFail("Date Range not verified Successfully");
	}

	@Then("I verify the ShowOnly dropdown values")
	public void i_verify_the_ShowOnly_dropdown_values() {
		listValues.addAll(jsonDataParser.getTestDataMap().values());
		if (transHistPage.verifyValuesInList(listValues))
			reportPass(listValues + " in the Show Only dropdown");
		else
			reportFail(listValues + " not in the Show Only dropdown");
	}
	
	@When("^I select the \"([^\"]*)\" option$")
	public void i_select_the_option(String filterType) throws Throwable {
		if (transHistPage.selectTypeFilter(jsonDataParser.getTestDataMap().get(filterType)))
			reportPass(jsonDataParser.getTestDataMap().get(filterType) + " Filter type selected");
		else
			reportFail(jsonDataParser.getTestDataMap().get(filterType) + " Filter type not selected");
	}

	@Then("^I verify the \"([^\"]*)\" type in the list$")
	public void i_verify_the_type_in_the_list(String filteroption) throws Throwable {
		if (transHistPage.verifyFilterDataInTheList(jsonDataParser.getTestDataMap().get(filteroption)))
			reportPass(jsonDataParser.getTestDataMap().get(filteroption) + " displayed Successfully");
		else
			reportFail(jsonDataParser.getTestDataMap().get(filteroption) + " not in the Show Only dropdown");
	}

	@When("Enter {string} text in search bar")
	public void enter_text_in_search_bar(String searchData) {
		if (transHistPage.enterValueInSearchBar(searchData))
			reportPass(searchData + " is entered");
		else
			reportFail(searchData + " is not entered");
	}

	@Then("I verify the {string} balance in the list")
	public void i_verify_the_balance_in_the_list(String balance) {
		if (transHistPage.verifyBalanceInTheList(balance))
			reportPass(balance + " verified in Posted transction table");
		else
			reportFail(balance + " not in the Posted transction table");
	}

	@Then("verify the first account selected automatically")
	public void verify_the_first_account_selected_automatically() {
		if (transHistPage.verifyFirstAccSelected())
			reportPass("First Account selected Automatically in Account dropdown");
		else
			reportFail("First Account not selected Automatically in Account dropdown");
	}

	@When("I select the Un-enrolled account")
	public void i_select_the_Un_enrolled_account() {
		if (transHistPage.clickOnAccount())
			reportPass("Un-Enroll Account is selected");
		else
			reportFail("Un-Enroll Account is not selected");
	}

	@When("I click on {string} link and get the Transaction amount")
	public void i_click_on_link_and_get_the_Transaction_amount(String depositLink) {
		if (transHistPage.clickOnImageLink(depositLink))
			reportPass(depositLink + "  Image selected");
		else
			reportFail(depositLink + "  Image not selected");
	}

	@Then("I verify the {string} text in Deposit Details page")
	public void i_verify_the_text_in_Deposit_Details_page(String depositPageTitle) {
		if (transHistPage.verifyDepositPageTitle(jsonDataParser.getTestDataMap().get(depositPageTitle)))
			reportPass(jsonDataParser.getTestDataMap().get(depositPageTitle) + " Page is displayed");
		else {
			reportFail(jsonDataParser.getTestDataMap().get(depositPageTitle) + " Page is not displayed");
		}
	}

	@Then("I veriy the {string} message")
	public void i_veriy_the_message(String depositDetailsMsg) {
		if (transHistPage.verifyDepositDetailsPageMsg(jsonDataParser.getTestDataMap().get(depositDetailsMsg)))
			reportPass(jsonDataParser.getTestDataMap().get(depositDetailsMsg) + " is displayed");
		else
			reportFail(jsonDataParser.getTestDataMap().get(depositDetailsMsg) + " is not displayed");
	}

	@Then("I verify the Print button is present")
	public void i_verify_the_Print_button_is_present() {
		if (transHistPage.isPrintBtnPresent())
			reportPass("Print button is Present");
		else
			reportFail("Print button is not Present");
	}

	@Then("I verify the Back button is present")
	public void i_verify_the_Back_button_is_present() {
		if (transHistPage.isBackBtnPresent())
			reportPass("Back button is Present");
		else
			reportFail("Back button is not Present");
	}

	@Then("I verify the Transaction Amount is displayed")
	public void i_verify_the_Transaction_Amount_is_displayed() {
		if (transHistPage.verifyTransAmt())
			reportPass("Transaction Amount is Matched");
		else
			reportFail("Transaction Amount is not Matched");
	}

	@Then("I verify the Transaction date is displayed")
	public void i_verify_the_Transaction_date_is_displayed() {
		if (transHistPage.verifyTransDate())
			reportPass("Transaction Date is Matched");
		else
			reportFail("Transaction Date is not Matched");
	}

	@When("I click on ticket front side image and verify the image")
	public void i_click_on_ticket_front_side_image_and_verify_the_image() {
		if (transHistPage.isImageFrontSideDisplay())
			reportPass("Front side Image displayed");
		else
			reportFail("Front side Image is not displayed");
	}

	@When("I click on ticket back side image and verify the image")
	public void i_click_on_ticket_back_side_image_and_verify_the_image() {
		if (transHistPage.isImageBackSideDisplay())
			reportPass("Back side Image displayed");
		else
			reportFail("Back side Image is not displayed");
	}

	@Then("I verify the Print icon in Front side Image")
	public void i_verify_the_Print_icon_in_Front_side_Image() {
		if (transHistPage.isPrintIconDisplayFrontImg())
			reportPass("Print icon is displayed in Front side image");
		else
			reportFail("Print icon is not displayed in Front side image");
	}

	@When("I click on Close icon in Front side Image")
	public void i_click_on_Close_icon__in_Front_side_Image() {
		if (transHistPage.clickonCloseBtnFrontImg())
			reportPass("Click on Close button in Front side Image");
		else
			reportFail("Unable to click on Close button in Front side Image");
	}

	@Then("I verify the Print icon in Back side Image")
	public void i_verify_the_Print_icon_in_Back_side_Image() {
		if (transHistPage.isPrintIconDisplayBackSideImg())
			reportPass("Print icon is displayed in Back side image");
		else
			reportFail("Print icon is not displayed in Back side image");
	}

	@When("I click on Close icon in Back side Image")
	public void i_click_on_Close_icon__in_Back_side_Image() {
		if (transHistPage.clickonCloseBtnBackSideImg())
			reportPass("Clicked on Close button in Back side Image");
		else
			reportFail("Unable to click on Close button in Back side Image");
	}

	@When("I click on Back button")
	public void i_click_on_Back_button() {
		if (transHistPage.clickonBackBtn())
			reportPass("Clicked on Back to Previous Page button");
		else
			reportFail("Unable to click on Back to Previous Page button");
	}

	@Then("I verify the Account number format as {string}")
	public void i_verify_the_Account_number_format_as(String accFormat) {
		if (transHistPage.verifyAccNumberFormat(jsonDataParser.getTestDataMap().get(accFormat)))
			reportPass(jsonDataParser.getTestDataMap().get(accFormat) + " is displayed in Transaction History Page");
		else
			reportFail(jsonDataParser.getTestDataMap().get(accFormat) + " Account is not displayed in Transaction History Page");
	}

	@When("I select the statement")
	public void i_select_the_statement() {
		if (transHistPage.selectAccStmt())
			reportPass("Account Statement selected from Date Range dropdown");
		else
			reportFail("Unable to select Account Statement from Date Range dropdown");
	}

	@When("I click on {string} link and get the Transaction amount, Date cleared")
	public void i_click_on_link_and_get_the_Transaction_amount_Date_cleared(String checkWithDrawalLink) {
		if (transHistPage.clickOnImageLink(checkWithDrawalLink))
			reportPass(checkWithDrawalLink + " WithDraw Image selected");
		else
			reportFail(checkWithDrawalLink + " WithDraw Image not selected");
	}

	@Then("I verify the Check Number is displayed")
	public void i_verify_the_Check_Number_is_displayed() {
		if (transHistPage.verifyCheckNumber())
			reportPass("CheckNumber is displayed");
		else
			reportFail("CheckNumber is not displayed");
	}

	@Then("I verify the {string} in Check Withdrawal page")
	public void i_verify_the_in_Check_Withdrawal_page(String chkWithDrawalMsg) {
		if (transHistPage.verifyChkWithDrawalMsg(chkWithDrawalMsg))
			reportPass(chkWithDrawalMsg + " message is displayed");
		else
			reportFail(chkWithDrawalMsg + " message is not displayed");
	}

	@Then("I verify the {string}")
	public void i_verify_the(String accNumber) {
		if (transHistPage.verifyAccDetails(jsonDataParser.getTestDataMap().get(accNumber)))
			reportPass("Account Number " + jsonDataParser.getTestDataMap().get(accNumber) + " is displayed");
		else
			reportFail("Account Number " + jsonDataParser.getTestDataMap().get(accNumber) + " is not displayed");
	}

	@Then("I verify the balance {string}  in the table")
	public void i_verify_the_balance_in_the_table(String balance) {
		if (transHistPage.verifyTrnBalance(jsonDataParser.getTestDataMap().get(balance)))
			reportPass(jsonDataParser.getTestDataMap().get(balance) + " verified in Loan statements table ");
		else
			reportFail(jsonDataParser.getTestDataMap().get(balance) + " not in the Loan statements table");
	}

	@Then("I retrieve the Transaction details")
	public void i_retrieve_the_Transaction_details() {
		if (transHistPage.retrieveTrnDetails())
			reportPass("Transaction details displayed");
		else
			reportFail("Unable to display Transaction details");
	}

	@When("I click on {string} option Action Menu")
	public void i_click_on_option_Action_link(String actionMenu) {
		if (transHistPage.clickOnActionMenu(actionMenu))
			reportPass(actionMenu + " Menu clicked");
		else
			reportFail(actionMenu + " Unable to click on Menu");
	}

	@When("I get the from date and To date")
	public void i_get_the_from_date_and_To_date() {
		if (transHistPage.captureFrmDateTodate())
			reportPass("From date and To date values captured");
		else
			reportFail("Unable to capture From date and To date values");
	}

	@When("Click on Advance Search button")
	public void click_on_Advance_Search_button() {
		if (transHistPage.clickOnAdvSearch())
			reportPass("Advance Search clicked");
		else
			reportFail("Unable to click on Advance Search");
	}

	@Then("I verify the webster account as {string} selected")
	public void i_verify_the_webster_account_as_selected(String account) {
		if (transHistPage.verifyDefaultAccFrmDropDown(jsonDataParser.getTestDataMap().get(account)))
			reportPass(jsonDataParser.getTestDataMap().get(account) + "  account is selected in Account dropdown");
		else
			reportFail(jsonDataParser.getTestDataMap().get(account) + "  account is not selected in Account dropdown");
	}

	@Then("I verify the From date and To date")
	public void i_verify_the_From_date_and_To_date() {
		if (transHistPage.verifyFrmToDates())
			reportPass("From and To dates Matched");
		else
			reportFail("From and To dates not Matched");
	}

	@Then("I verify the Transaction Type as {string}")
	public void i_verify_the_Transaction_Type_as(String trnType) {
		if (transHistPage.verifyDefaultTranTypeFrmDropDown(jsonDataParser.getTestDataMap().get(trnType)))
			reportPass(jsonDataParser.getTestDataMap().get(trnType) + "  is selected in Transaction type dropdown");
		else
			reportFail(jsonDataParser.getTestDataMap().get(trnType) + "  is not selected in Transaction type dropdown");
	}

	@Then("I verify the {string} Account number")
	public void i_verify_the_Account_number(String accNumber) {
		if (transHistPage.verifyAccNumber(accNumber))
			reportPass("Account Number " + accNumber + " is displayed");
		else
			reportFail("Account Number " + accNumber + " is not displayed");
	}

	@When("I capture the Posted Transaction details")
	public void i_capture_the_Posted_Transaction_details() {
		if (!transHistPage.capturePostedTransDetails().equals(""))
			reportPass("Transaction Details  " + transHistPage.capturePostedTransDetails() + " captured");
		else
			reportFail("Transaction Details " + transHistPage.capturePostedTransDetails() + " not captured");

	}

	@Then("I verify the previous transaction details or {string} message")
	public void i_verify_the_previous_transaction_details_or_message(String message) {
		if (transHistPage.verifyPostedTransDetails(jsonDataParser.getTestDataMap().get(message)))
			reportPass("Previuos transaction details displayed as " + transHistPage.capturePostedTransDetails());
		else
			reportFail("Previuos transaction details not displayed as " + transHistPage.capturePostedTransDetails());
	}

	@When("I select the {string} Checking Account")
	public void i_select_the_Checking_Account(String checkingAccount) {
		if (transHistPage.selectAccFromDropdown(checkingAccount))
			reportPass("Checking Account " + checkingAccount + " is selected from Accounts dropdown");
		else
			reportFail("Checking Account " + checkingAccount + " is not selected from Accounts dropdown");
	}

	@Then("From date field should be disabled")
	public void from_date_field_should_be_disabled() {
		if (transHistPage.fromDateDisabled())
			reportPass("From Date field is Disabled");
		else
			reportFail("From date field is Enabled");
	}

	@Then("To date field should be disabled")
	public void to_date_field_should_be_disabled() {
		if (transHistPage.toDateDisabled())
			reportPass("To Date field is Disabled");
		else
			reportFail("To date field is Enabled");
	}

	@Then("Date Range drop down should be active")
	public void date_Range_drop_down_should_be_active() {
		if (transHistPage.verifyDateRangeField())
			reportPass("Date Range field should be active");
		else
			reportFail("Date Range field should not be active");
	}

	@When("I select the {string} Saving Account")
	public void i_select_the_Saving_Account(String savingAccount) {
		if (transHistPage.selectAccFromDropdown(savingAccount))
			reportPass("Saving Account " + savingAccount + " is selected from Accounts dropdown");
		else
			reportFail("Saving Account " + savingAccount + " is not selected from Accounts dropdown");
	}

	@When("I select the {string} Loan Account")
	public void i_select_the_Loan_Account(String loanAcount) {
		if (transHistPage.selectAccFromDropdown(loanAcount))
			reportPass("Loan Account " + loanAcount + " is selected from Accounts dropdown");
		else
			reportFail("Loan Account " + loanAcount + " is not selected from Accounts dropdown");
	}

	@When("I click on From date Calendar icon")
	public void i_click_on_From_date_Calendar_icon() {
		if (transHistPage.clickOnFromDateCalendarIcon())
			reportPass("Clicked on From Date Calendar Icon");
		else
			reportFail("Unable to click on From Date Calendar Icon");
	}

	@Then("I verify the from date calendar icon should display")
	public void i_verify_the_from_date_calendar_icon_should_display() {
		if (transHistPage.verifyFromDateCalendarIcon())
			reportPass("From Date Calendar Icon displayed");
		else
			reportFail("From Date Calendar Icon not displayed");
	}

	@When("I click on To date Calendar icon")
	public void i_click_on_To_date_Calendar_icon() {
		if (transHistPage.clickOnToDateCalendarIcon())
			reportPass("Clicked on To Date Calendar Icon");
		else
			reportFail("Unable to click on To Date Calendar Icon");
	}

	@Then("I verify the To date calendar icon should display")
	public void i_verify_the_To_date_calendar_icon_should_display() {
		if (transHistPage.verifyToDateCalendarIcon())
			reportPass("To Date Calendar Icon displayed");
		else
			reportFail("To Date Calendar Icon not displayed");
	}

	@When("I select the Enrolled account")
	public void i_select_the_Enrolled_account() {
		if (transHistPage.clickOnAccount())
			reportPass("Enroll Account is selected");
		else
			reportFail("Enroll Account is not selected");
	}

	@Then("I verify the Check or Amount search option should be available")
	public void i_verify_the_Check_or_Amount_search_option_should_be_available() {
		if (transHistPage.verifySearchTextBox())
			reportPass("Check or Amount Search option displayed");
		else
			reportFail("Check or Amount Search option not displayed");
	}

	@Then("I verify the Description as {string}")
	public void i_verify_the_Description_as(String description) {
		if (transHistPage.verifyTextDescription(jsonDataParser.getTestDataMap().get(description)))
			reportPass("Description displayed as " + jsonDataParser.getTestDataMap().get(description));
		else
			reportFail("Description not displayed as " + jsonDataParser.getTestDataMap().get(description));
	}

	@Then("I verify the Transaction Amount")
	public void i_verify_the_Deposit_Amount() {
		if (transHistPage.verifyTransAmtInTable())
			reportPass("Transaction Amount Matched");
		else
			reportFail("Transaction Amount not Matched");
	}

	@When("I enter Amount in Search Deposit text box")
	public void i_enter_Amount_in_Search_Deposit_text_box() {
		if (!transHistPage.enterTransactionAmount().equals(""))
			reportPass("Transaction Amount is displayed" + transHistPage.enterTransactionAmount());
		else
			reportFail("Transaction Amount is not displayed" + transHistPage.enterTransactionAmount());
	}

	@Then("I veriy the {string} enroll message")
	public void i_veriy_the_enroll_message(String depositMessage) {
		if (transHistPage.verifyEnrollAccDepositText(jsonDataParser.getTestDataMap().get(depositMessage)))
			reportPass("Deposit details Enroll Account message displayed as " + jsonDataParser.getTestDataMap().get(depositMessage));
		else
			reportFail("Deposit details Enroll Account message not displayed as " + jsonDataParser.getTestDataMap().get(depositMessage));
	}

	@When("I click on deposit front side image")
	public void i_click_on_deposit_front_side_image() {
		if (transHistPage.isDepositImageFrontSideDisplay())
			reportPass("Front side Image displayed");
		else
			reportFail("Front side Image is not displayed");
	}

	@When("I enter invalid Amount {string} in Search Deposit text box")
	public void i_enter_invalid_Amount_in_Search_Deposit_text_box(String amount) {
		if (transHistPage.enterInvalidTransactionAmount(jsonDataParser.getTestDataMap().get(amount)))
			reportPass("Invalid Transaction " + jsonDataParser.getTestDataMap().get(amount) + " Amount entered");
		else
			reportFail("Invalid Transaction " + jsonDataParser.getTestDataMap().get(amount) + " Amount not entered");
	}

	@Then("I verify the empty table should display")
	public void i_verify_the_empty_table_should_display() {
		if (transHistPage.verifyEmptyTable())
			reportPass("No results displayed");
		else
			reportFail("Transaction details displayed");
	}

	@When("I click on Opt in to View Deposit Details icon")
	public void i_click_on_Opt_in_to_View_Deposit_Details_icon() {
		if (transHistPage.clickOnOptInDepositDetailsIcon())
			reportPass("Clicked on OptIn View Deposit Details Icon");
		else
			reportFail("Unable to click on OptIn View Deposit Details Icon");
	}

	@When("I click on Opt out to View Deposit Details icon")
	public void i_click_on_Opt_out_to_View_Deposit_Details_icon() {
		if (transHistPage.clickOnOptOutDepositDetailsIcon())
			reportPass("Clicked on OptOut View Deposit Details Icon");
		else
			reportFail("Unable to click on OptOut View Deposit Details Icon");
	}

	@When("I get the statement Date Range")
	public void i_get_the_statement_Date_Range() {
		if (!transHistPage.captureStmtDateRange().equals(""))
			reportPass(" Date Range " + transHistPage.captureStmtDateRange() + " is captured");
		else
			reportFail("From Date " + transHistPage.captureStmtDateRange() + " is not captured");
	}

	@When("I select the Loan Account")
	public void i_select_the_Loan_Account() {
		if (transHistPage.selectAccFromDropdown(jsonDataParser.getTestDataMap().get("Loan Account Number")))
			reportPass("Loan Account " + (jsonDataParser.getTestDataMap().get("Loan Account Number")) + " selected");
		else
			reportFail("Loan Account " + (jsonDataParser.getTestDataMap().get("Loan Account Number")) + " not selected");
	}

	@When("I click on Back to Previuos Page button")
	public void i_click_on_Back_to_Previuos_Page_button() {
		if (transHistPage.clickOnBackToPreviousPageButton())
			reportPass("Click on Back to Previous Page button");
		else
			reportFail("Unable to click on Back to Previous Page button");
	}

	@Then("I verify the Account section should display")
	public void i_verify_the_Account_section_should_display() {
		if (transHistPage.clickOnAccList())
			reportPass("Account section displayed in Transaction History Page");
		else
			reportFail("Unable to display Account in Transaction History Page");
	}

	@Then("I verify the Available Balance should display")
	public void i_verify_the_Available_Balance_should_display() {
		if (!transHistPage.verifyAvailableBalance().equals(""))
			reportPass(" Available Balance " + transHistPage.availableBalance + " is displayed");
		else
			reportFail(" Available Balance " + transHistPage.availableBalance + " not displayed");
	}

	@Then("I verify the Posted Transaction table below column names")
	public void i_verify_the_Posted_Transaction_table_below_column_names() {
		listValues =new ArrayList<String>();
		listValues.addAll(jsonDataParser.getTestDataMap().values());
		if (transHistPage.verifyPostedTransTableHeaders(listValues))
			reportPass(" All Headers are displayed in the Posted Transaction table");
		else
			reportFail("Unable to display the Headers in the Posted Transaction table");
	}

	@Then("I verify the Print Icon should display")
	public void i_verify_the_Print_Icon_should_display() {
		if (transHistPage.verifyPrintTransactionIcon())
			reportPass("Print Icon displayed in Transaction History Page");
		else
			reportFail("Unable to display the Print Icon in Transaction History Page");
	}

	@Then("I verify the Back to Top button should display")
	public void i_verify_the_Back_to_Top_button_should_display() {
		if (transHistPage.verifyBackToTopButton())
			reportPass("Back To Top button displayed in Transaction History Page");
		else
			reportFail("Unable to display the Back To Top button in Transaction History Page");
	}

	@Then("I verify the Advance Search button should display")
	public void i_verify_the_Advance_Search_button_should_display() {
		if (transHistPage.verifyBackToTopButton())
			reportPass("Advance Search button displayed in Transaction History Page");
		else
			reportFail("Unable to display the Advance Search button in Transaction History Page");
	}

	@Then("I verify the Posted Transaction table below column values")
	public void i_verify_the_Posted_Transaction_table_below_column_values() {
		listValues=new ArrayList<String>();
		listValues.addAll(jsonDataParser.getTestDataMap().values());
		if (transHistPage.verifyPostedTransTableValues(listValues))
			reportPass("Verified values in Posted Transaction table");
		else
			reportFail("Unable to verify values in Posted Transaction table");
	}

	@When("I select the Credit Card account")
	public void i_select_the_Credit_Card_account() {
		if (transHistPage.clickOnAccList())
			reportPass("Credit card Account selected");
		else
			reportFail("Unable to select the Credit card Account");
	}

	@When("I select the Loan account")
	public void i_select_the_Loan_account() {
		if (transHistPage.clickOnAccList())
			reportPass("Loan Account selected");
		else
			reportFail("Unable to select the Loan Account");
	}

	@Then("I verify Print button is present")
	public void i_verify_Print_button_is_present() {
		if (transHistPage.verifyPrintButton())
			reportPass("Print button is displayed");
		else
			reportFail("Unable to display the Print button");
	}

	@Then("I verify Back button is present")
	public void i_verify_Back_button_is_present() {
		if (transHistPage.verifyBackButton())
			reportPass("Back button is displayed");
		else
			reportFail("Unable to display the Back button");
	}

	@Then("I verify Account number format as {string}")
	public void i_verify_Account_number_format_as(String accFormat) {
		if (transHistPage.verifyAccountNumber(jsonDataParser.getTestDataMap().get(accFormat)))
			reportPass(jsonDataParser.getTestDataMap().get(accFormat) + " is displayed in Transaction History Page");
		else
			reportFail(jsonDataParser.getTestDataMap().get(accFormat) + " Account is not displayed in Transaction History Page");
	}

	@Then("I verify Transaction Amount is displayed")
	public void i_verify_Transaction_Amount_is_displayed() {
		if (transHistPage.verifyTransactionAmt())
			reportPass("Transaction Amount is Matched");
		else
			reportFail("Transaction Amount is not Matched");
	}

	@Then("I verify Transaction date is displayed")
	public void i_verify_Transaction_date_is_displayed() {
		if (transHistPage.verifyTransactionDate())
			reportPass("Transaction Date is Matched");
		else
			reportFail("Transaction Date is not Matched");
	}

	@When("I select the Multiple Check Images account")
	public void i_select_the_Multiple_Check_Images_account() {
		if (transHistPage.selectAccFromDropdown(jsonDataParser.getTestDataMap().get("Account")))
			reportPass(jsonDataParser.getTestDataMap().get("Account") + " is selected from Accounts dropdown");
		else
			reportFail(jsonDataParser.getTestDataMap().get("Account") + " is not selected from Accounts dropdown");
	}

	@When("I Enter from date")
	public void i_Enter_from_date() {
		if (transHistPage.enterTransFromDate())
			reportPass("From Date " + jsonDataParser.getTestDataMap().get("FromToDate") + " is entered");
		else
			reportFail("From Date " + jsonDataParser.getTestDataMap().get("FromToDate") + " is not entered");
	}

	@When("I Enter to date")
	public void i_Enter_to_date() {
		if (transHistPage.enterTransToDate())
			reportPass("To Date " + jsonDataParser.getTestDataMap().get("FromToDate") + " is entered");
		else
			reportFail("To Date " + jsonDataParser.getTestDataMap().get("FromToDate") + " is not entered");
	}

	@When("I click on {string} {string} image link and get the Transaction amount")
	public void i_click_on_image_link_and_get_the_Transaction_amount(String value1, String value2) {
		if (transHistPage.clickOnDuplicateImagesLink(value1, value2))
			reportPass("Clicked on " + value2 + "  " + value1 + " link");
		else
			reportFail("Unable to Click on " + value2 + "  " + value1 + " link");
	}

	@Then("I verify Image Account number")
	public void i_verify_Image_Account_number() {
		if (transHistPage.verifyDuplicateAccNumber())
			reportPass(jsonDataParser.getTestDataMap().get("Account") + " is displayed in Transaction History Page");
		else
			reportFail(jsonDataParser.getTestDataMap().get("Account") + " Account is not displayed in Transaction History Page");
	}

	@Then("I verify First Transaction Amount")
	public void i_verify_First_Transaction_Amount() {
		if (transHistPage.verifyDuplicateTransAmt())
			reportPass("First Transaction Amount " + (jsonDataParser.getTestDataMap().get("TransAmount")) + " is displayed");
		else
			reportFail("First Transaction Amount " + (jsonDataParser.getTestDataMap().get("TransAmount")) + " is not displayed");
	}

	@Then("I verify First Transaction date")
	public void i_verify_First_Transaction_date() {
		if (transHistPage.verifyDuplicateTransDate())
			reportPass("First Transaction Date " + (testDataMap.get("TransDate")) + " is displayed");
		else
			reportFail("First Transaction Date " + (testDataMap.get("TransDate")) + " is not displayed");
	}

	@When("I click on deposit back side image")
	public void i_click_on_deposit_back_side_image() {
		if (transHistPage.isDepositImageBackSideDisplay())
			reportPass("Back side Image displayed");
		else
			reportFail("Back side Image is not displayed");
	}

	@When("I click on Close icon in back side Image")
	public void i_click_on_Close_icon_in_back_side_Image() {
		if (transHistPage.clickonCloseBtnFrontImg())
			reportPass("Click on Close button in Back side Image");
		else
			reportFail("Unable to click on Close button in Back side Image");
	}

	@Then("I verify Duplicate Transaction Amount")
	public void i_verify_Duplicate_Transaction_Amount() {
		if (transHistPage.verifyDuplicateTransAmt())
			reportPass("Duplicate Transaction Amount " + (testDataMap.get("TransAmount")) + " is displayed");
		else
			reportFail("Duplicate Transaction Amount " + (testDataMap.get("TransAmount")) + " is not displayed");
	}

	@Then("I verify Duplicate Transaction date")
	public void i_verify_Duplicate_Transaction_date() {
		if (transHistPage.verifyDuplicateTransDate())
			reportPass("Duplicate Transaction Date " + (testDataMap.get("TransDate")) + " is displayed");
		else
			reportFail("Duplicate Transaction Date " + (testDataMap.get("TransDate")) + " is not displayed");
	}

	@When("I Enter {string} amount in search bar")
	public void i_Enter_amount_in_search_bar(String amount) {
		if (transHistPage.enterValueInSearchBar(jsonDataParser.getTestDataMap().get("TransAmount")))
			reportPass(jsonDataParser.getTestDataMap().get("TransAmount") + " amount is entered");
		else
			reportFail(jsonDataParser.getTestDataMap().get("TransAmount") + " amount is not entered");
	}

	@Then("I verify the Deposit details should not display")
	public void i_verify_the_Deposit_details_should_not_display() {
		if (transHistPage.depositTicketNotPresent())
			reportPass("DEPOSIT/CHECK Ticket is not displayed for Loan Accounts");
		else
			reportFail("DEPOSIT/CHECK Ticket is displayed for Loan Accounts");
	}

	@When("I click on More transactions button")
	public void i_click_on_More_transactions_button() {
		if (transHistPage.clickOnMoreTransactions())
			reportPass("Clicked on More Transactions button in Transaction History page");
		else
			reportFail("Unable to click on More Transactions button in Transaction History page");
	}

	@When("I click on Check image")
	public void i_click_on_Check_image() {
		if (transHistPage.clickOnCheckImageIcon())
			reportPass("Clicked on Check Image Icon");
		else
			reportFail("Unable to click on Check Image Icon");
	}

	@Then("I verify the Print icon in Check Image")
	public void i_verify_the_Print_icon_in_Check_Image() {
		if (transHistPage.checkImagePrintButton())
			reportPass("Print button is Presented on Check Image");
		else
			reportFail("Print button is not Present on Check Image");
	}

	@Then("I verify the Sort By options in the dropdown list")
	public void i_verify_the_Sort_By_options_in_the_dropdown_list() {
		if (transHistPage.verifySortByOptions())
			reportPass("All options were present in the List");
		else
			reportFail("All options were not present in the List");
	}

	@Then("I verify the {string} {string} order")
	public void i_verify_the_order(String paymentType, String order) {
		if (transHistPage.verifySortingOrder(paymentType, order))
			reportPass(paymentType + " amounts were displayed in " + order + " order");
		else
			reportFail(paymentType + " amounts were not displayed in " + order + " order");
	}

	@When("I select the {string} sorted option")
	public void i_select_the_sorted_option(String option) {
		if (transHistPage.selectSortedValue(jsonDataParser.getTestDataMap().get(option)))
			reportPass("Select the {" + jsonDataParser.getTestDataMap().get(option) + " in the Sort By dropdown list");
		else
			reportFail("Unable to select the {" + jsonDataParser.getTestDataMap().get(option) + " in the Sort By dropdown list");
	}
}
