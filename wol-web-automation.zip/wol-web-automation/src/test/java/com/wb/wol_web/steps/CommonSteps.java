package com.wb.wol_web.steps;

import java.util.Map;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CommonSteps extends ObjectBase {

	CommonPage commonpage = new CommonPage();
	public String fileName = "";
	public String testCaseName = "";

	@Given("I load testdata from: {string}, {string}")
	public void i_load_testdata_from(String fileName, String testCaseName) throws Exception {
		jsonDataParser.parseJsonTestData(fileName, testCaseName);
	}

	@Given("I load multiple testdata from: {string}, {string}, {string}")
	public void i_load_multiple_testdata_from(String fileName, String testCaseName, String testDataName)
			throws Exception {
		testDataMap = jsonDataParser.parseJsonTestData(fileName, testCaseName, testDataName);
	}

	@Given("I load Environment specific testdata from: {string}, {string}, {string}")
	public void i_load_Environment_specific_testdata_from(String fileName, String testCaseName, String environmentName)
			throws Exception {
		if (environmentName.equalsIgnoreCase("pom.xml"))
			environmentName = System.getProperty("environment");
		jsonDataParser.parseJsonTestDataByEnvironment(fileName, testCaseName, environmentName);

	}

	@Given("I load Environment specific multiple testdata from: {string}, {string}, {string}, {string}")
	public void i_load_Environment_specific_multiple_testdata_from(String fileName, String testCaseName,
			String environmentName, String testDataName) throws Exception {
		if (environmentName.equalsIgnoreCase("pom.xml"))
			environmentName = System.getProperty("environment");
		jsonDataParser.parseJsonTestDataByEnvironment(fileName, testCaseName, environmentName, testDataName);
	}

	@Given("^As a user I load WOL Homepage again$")
	public void as_a_User_I_am_in_WOL_Homepage_again() throws Throwable {
		commonpage.loadURL();
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		if (commonpage.isYourAccountDisplayed())
			reportPass("Navigated again to:{ " + System.getProperty("environment") + " } environment URL in: { "
					+ browserName + " } browser and version: {" + browserVersion + "}");
		else
			reportHardFail("ERROR : There is some issue in loading { " + System.getProperty("environment")
					+ " } URL or Exception in Code.");

	}

	@Given("As a User I am in WOL Homepage")
	public void as_a_User_I_am_in_WOL_Homepage() throws Exception {
		commonpage.loadURL();
		waits.waitForDOMready();
		waits.waitForPageReadyState();

		if (commonpage.isUserNameDisplayed())
			reportPass("Navigated to:{ " + System.getProperty("environment") + " } environment URL in: { " + browserName
					+ " } browser and version: {" + browserVersion + "}");
		else
			reportHardFail("ERROR : There is some issue in loading { " + System.getProperty("environment")
					+ " } URL or Exception in Code. Please check and re-execute the script.");
	}

	@When("^I Enter username \"([^\"]*)\"$")
	public void i_Enter_username(String userKey) throws Throwable {
		String userName = WOLTestBase.envProps.getProperty(userKey);
		boolean flag = commonpage.enterUserName(userName);
		if (flag)
			reportPass("Entered the username {" + userName + "}");
		else
			reportHardFail(
					"Incorrect username entered, Terminating execution. Please verify the username and re-execute the script.");
	}

	@Then("^I should see \"([^\"]*)\" page$")
	public void check_the_page_for_addNewPayees(String title) {
		if (commonpage.checkTheTitle(title)) {
			reportPass("Reached Add a New Payee page");
		} else {
			reportFail("Add a New Payee page is not found");
		}
	}

	@When("^I Click on Go Button$")
	public void i_Click_on_Go_Button() {
		try {
			commonpage.clickOnGoButton();
			reportPass("Clicked on Go Button");
		} catch (Exception e) {
			LogUtility.logException("clickOnGoButton", "Unable to Click on Go Button", e, LoggingLevel.ERROR, true);
			reportHardFail("Unable to Click on Go Button.");
		}
	}

	@When("^I click on Sign Out Link$")
	public void i_signout_from_the_account() throws Throwable {
		try {
			commonpage.signOut();
			reportPass("Clicked on SignOut Link");
		} catch (Exception e) {
			LogUtility.logException("signOut", "Unable to Click on SignOut Link", e, LoggingLevel.ERROR, true);
			reportFail("Unable to Click on SignOut Link.");
		}
	}

	@Then("^I should be in Unauthorized User Access page$")
	public void i_should_be_in_Unauthorized_User_Access_page() throws Throwable {
		if (commonpage.checkTheUnathorizedUserAccessPage("Unauthorized User Access")) {
			reportPass("Reached the Unauthorized User Access page");
		} else {
			reportFail("Page Unauthorized User Access is not found");
		}
	}

	@Then("^user navigate to Authentication page$")
	public void user_navigate_to_Authentication_page() throws Throwable {
		if (commonpage.verifyUserNameLabel())
			reportPass("Reached the RSA page");
		else
			reportHardFail("Failed to Reach RSA page");
	}

	@When("^User enters required details in Security Pages$")
	public void user_enters_required_details_in_Security_Pages() throws Throwable {
		try {
			fileName = WOLTestBase.props.getProperty("common.json.file.name");
			testCaseName = WOLTestBase.props.getProperty("common.json.test.name");
			Map<String, String> commonTestDataMap = jsonDataParser.parseJsonTestData(fileName, testCaseName);
			commonpage.navigateAllSecurityPages(commonTestDataMap);
		} catch (Exception e) {
			reportHardFail("Failed to log into WOL application");
		}
	}
	@When("^User enters required details in Security Pages For Login$")
	public void user_enters_required_details_in_Security_Pages_For_Login() throws Throwable {
		try {
			Map<String, String> commonTestDataMap = jsonDataParser.getTestDataMap();
			commonpage.navigateAllSecurityPages(commonTestDataMap);
		} catch (Exception e) {
			reportHardFail("Failed to log into WOL application");
		}
	}

	@When("^I click on summary tab$")
	public void i_click_on_summary_tab() throws Throwable {
		try {
			commonpage.clickOnSummaryTab();
		} catch (Exception e) {
			LogUtility.logException("clickOnSummaryTab", "Failed to click on Summary tab", e, LoggingLevel.ERROR, true);
			reportHardFail("Failed to click on Summary tab");
		}
	}

	@Then("^User should see Summary page$")
	public void user_should_see_Summary_page() throws Throwable {
		try {
			if (commonpage.waitForSummaryPage())
				reportPass("Reached summary page");
			else
				reportHardFail("Failed to reach summary page");

		} catch (Exception e) {
			LogUtility.logException("waitForSummaryPage", "Failed to reach summary page", e, LoggingLevel.ERROR, true);

		}
	}

	@When("^I click on \"([^\"]*)\" link under \"([^\"]*)\" Menu$")
	public void i_click_on_link_under_Menu(String SubMenu, String Menu) throws Throwable {
		commonpage.selectFromTheMenu(Menu, SubMenu);
		reportPass("Clicked the link " + SubMenu + " from " + Menu + " Menu");
	}

	@When("^I click on \"([^\"]*)\" link$")
	public void i_click_on_link(String link) throws Throwable {
		commonpage.clickOnLink(link);
	}

	@Then("^Verify if the link \"([^\"]*)\" is present in the page$")
	public void verify_if_the_link_is_present_in_the_page(String link) throws Throwable {
		commonpage.checkForLinkInAPage(link);
	}

	@Then("^I should be in \"([^\"]*)\" page$")
	public void i_should_be_in_page(String title) {
		if (commonpage.checkThePageHeading(title)) {
			reportPass("Reached the " + title + " page");
		} else {
			reportFail("Page " + title + " is not found");
		}
	}

	@And("^I refresh the page$")
	public void pageRefresh() {
		driver.navigate().refresh();
	}

	@When("^I navigate back to the previous page$")
	public void pageNavigateBack() {
		waits.waitForPageReadyState();
		driver.navigate().back();
	}

	@Then("^Sign Out message \"([^\"]*)\" should be displayed$")
	public void sign_out_message_something_should_be_displayed(String message) throws Throwable {
		if (commonpage.verifySignOutTxt(message) == true)
			reportPass("The Sign Out message: " + message + " is displaying successfully");
		else
			reportFail("The Sign Out message: " + message + " is not displaying");
	}

	@Then("^I should be in Set Up A Payment Alert page$")
	public void check_alert_page_title() {
		if (commonpage.checkAlertsPageTitle())
			reportPass("Reached Alerts page ");
	}

	@Then("^I get the username from the customer profile icon$")
	public void get_the_username() {
		try {
			commonpage.getTheUserName();
		} catch (Exception e) {
			LogUtility.logException("getTheUserName", "Failed to get the user name from customer profile icon", e,
					LoggingLevel.ERROR, true);
			reportHardFail("Failed to get the user name from customer profile icon");
		}
	}

	@Then("I should be in the {string} page")
	public void i_should_be_in_the_page(String pageName) {
		if (commonpage.checkPageTitle(pageName))
			reportPass("Redirected to " + pageName + " page");
		else
			reportHardFail("Not Redirected to " + pageName + " page");
	}

	@Then("^I click on the message count from customer profile$")
	public void click_on_message_count() throws Exception {
		if (commonpage.clickOnMessageFromCustomerIcon())
			reportPass("Clicked on the message icon from customer profile");
		else
			reportFail("Failed to click on the message icon from customer profile");
	}

	@Then("I switch to the {string} index frame")
	public void i_switch_to_the_index_frame(String index) {
		if (commonpage.switchToFrameByIndex(index))
			reportPass("Switched to " + index + " frame in page");
		else
			reportHardFail("Not switched to " + index + " frame in page");
	}

	@Then("I switch back to default")
	public void i_switch_back_to_default() {
		if (commonpage.switchToDefaultContent())
			reportPass("Switched to default content in page");
		else
			reportHardFail("Not switched to default content in page");
	}

	@Then("I click on Accounts Tab Menu")
	public void i_click_on_Accounts_Tab_Menu() {
		if (commonpage.clickOnAccountsTab())
			reportPass("Click on AccountsTab");
		else
			reportHardFail("Failed to click on Account tab");
	}

	@Then("I should not see {string} link under Accounts Tab")
	public void i_should_not_see_link_under_Accounts_Tab(String subLinkName) {
		if (!commonpage.verifySubLinkUndertAccountsTab(subLinkName))
			reportPass("Sub Menu: " + subLinkName + " is not displayed");
		else
			reportHardFail("Sub Menu: " + subLinkName + " is displayed");
	}

	@When("I switch to child window")
	public void i_switch_to_child_window() {
		if (commonpage.switchToChildWindow())
			reportPass("Switched to Child Window");
		else
			reportHardFail("Failed in switch to Child Window");
	}

	@When("I switch back to main window")
	public void i_switch_back_to_main_window() {
		if (commonpage.switchToParentWindow())
			reportPass("Switched to Parent Window");
		else
			reportHardFail("Failed in switch to parent Window");
	}

}
