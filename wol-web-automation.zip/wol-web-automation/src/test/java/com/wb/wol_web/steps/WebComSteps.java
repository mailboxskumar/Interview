package com.wb.wol_web.steps;

import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.WebcomPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

/**
 * @author: Ravi kumar Maddula
 *
 */

public class WebComSteps extends ObjectBase {

	WebcomPage webcompage = new WebcomPage();

	@Then("I enter {string} in to username field from Customer Search page")
	public void i_enter_in_to_username_field_from_Customer_Search_page(String userKey) {
		String userName = WOLTestBase.envProps.getProperty(userKey);
		if (webcompage.enterUserName(userName)) {
			reportPass("Entered User Name " + userName + " successfully");
		} else {
			reportFail("Failed to enter User Name");
		}
	}
	
	@Then("I enter {string} in username field from Customer Search page")
	public void i_enter_in_username_field_from_Customer_Search_page(String userName) {
		if (webcompage.enterUserName(userName)) {
			reportPass("Entered User Name " + userName + " successfully");
		} else {
			reportFail("Failed to enter User Name");
		}
	}

	@Then("Click on Show Details button")
	public void click_on_Show_Details_button() {
		if (webcompage.clickShowDetails()) {
			reportPass("Clicked on Show Details button successfully");
		} else {
			reportFail("Failed to click on Show Details button");
		}
	}

	@Then("Select {string} option from Transaction Name drop down")
	public void select_option_from_Transaction_Name_drop_down(String selectValue) {
		if (webcompage.selectTransactionName(selectValue)) {
			reportPass("Selected " + selectValue + " option successfully from Transaction type drop-down");
		} else {
			reportFail("Failed to select " + selectValue + " option from drop-down");
		}
	}

	@Then("Verify records count from Manager Audit Trail Details page")
	public void verify_records_count_from_Manager_Audit_Trail_Details_page() {
		if (webcompage.auditTrailDetails()) {
			reportPass("Audit Trail records are available");
		} else {
			reportFail("Audit Trail records are not available");
		}
	}

	@Then("Click on view link from records table")
	public void click_on_view_link_from_records_table() {
		if (webcompage.clickOnViewLink()) {
			reportPass("Clicked on View link successfully");
		} else {
			reportFail("Failed to click on View link");
		}
	}

	@Then("Verify user information table")
	public void verify_user_information_table() {
		if (webcompage.verifyInformationTable()) {
			reportPass("Verified New Information table of the user");
		} else {
			reportFail("Failed to verify New Information table of the user");
		}
	}

	@Then("I clicked on {string} link in left side menu")
	public void i_clicked_on_link_in_left_side_menu(String linkName) {
		if (webcompage.clickLeftMenu(linkName)) {
			reportPass("Clicked on " + linkName + " link successfully");
		} else {
			reportFail("Failed to click on " + linkName + "link");
		}
	}

	@Then("I clicked on {string} link in left side sub menu")
	public void i_clicked_on_link_in_left_side_sub_menu(String linkName) {
		if (webcompage.clickLeftSubMenu(linkName)) {
			reportPass("Clicked on " + linkName + " Sub-Menu link successfully");
		} else {
			reportFail("Failed to click on " + linkName + " Sub-Menu Link");
		}
	}

	@Then("I enter {string} in to userid field from Manage Audit Trail Search")
	public void i_enter_in_to_userid_field_from_Manage_Audit_Trail_Search(String userId) {
		if (webcompage.enterUserID(userId)) {
			reportPass("Entered " + userId + " into User ID field successfully");
		} else {
			reportFail("Failed to enter" + userId + " into User ID field");
		}
	}

	@Then("I Update Email id {string} on customer details")
	public void i_update_email_id_on_customer_details(String emailId) {
		if (webcompage.updateEmail(emailId)) {
			reportPass("Entered " + emailId + " into Email ID field successfully");
		} else {
			reportFail("Failed to enter" + emailId + " into Email ID field");
		}
	}

	@Then("Click on save button")
	public void click_on_save_button() {
		if (webcompage.clickSaveButton()) {
			reportPass("Clicked on Save button successfully");
		} else {
			reportFail("Failed to click on Save button");
		}
	}

	@Then("Verify {string} message from customer details page")
	public void verify_message_from_customer_details_page(String message) {
		if (webcompage.verifyUpdateMessage(message)) {
			reportPass(webcompage.fieldValue + " updated successfully and displayed message " + message);
		} else {
			reportFail("Failed to verify message in Customer Details page");
		}
	}

	@Then("I enter {string} in to account number field")
	public void i_enter_in_to_account_number_field(String acctNumber) {
		if (webcompage.enterAcctNumber(acctNumber)) {
			reportPass("Entered account number " + acctNumber + " into Account Number field successfully");
		} else {
			reportFail("Failed to enter" + acctNumber + " into Account Number field");
		}
	}

	@Then("Verify customer details fields from Customer Details page")
	public void verify_customer_details_fields_from_Customer_Details_page() {
		if (webcompage.verifyDetails()) {
			reportPass("Verified Customer Details successfully");
		} else {
			reportFail("Failed to verify Customer Details");
		}
	}

	@Then("I enter {string} in to last name field")
	public void i_enter_in_to_last_name_field(String lName) {
		if (webcompage.enterLastName(lName)) {
			reportPass("Entered last name " + lName + " successfully");
		} else {
			reportFail("Failed to enter Last Name into Last Name field");
		}
	}

	@When("I see {string} page click on customer details from page")
	public void i_see_page_click_on_customer_details_from_page(String pageTitle) {
		webcompage.customerDetails(pageTitle);
	}

	@Then("Verify customer last name from Customer Details page")
	public void verify_customer_last_name_from_Customer_Details_page() {
		if (webcompage.verifyLastName()) {
			reportPass("Verified Last Name " + webcompage.customerLastName + " successfully");
		} else {
			reportFail("Failed to verify Last Name in Customer Details");
		}
	}

	@Then("I enter {string} in to SSN\\/TIN field")
	public void i_enter_in_to_SSN_TIN_field(String ssnValue) {
		if (webcompage.enterSsnValue(ssnValue)) {
			reportPass("Entered value " + ssnValue + " into SSN/TIN field successfully");
		} else {
			reportFail("Failed to enter value into SSN/TIN search field");
		}
	}

	@Then("Verify customer SSN from Customer Details page")
	public void verify_customer_SSN_from_Customer_Details_page() {
		if (webcompage.verifySsnValue()) {
			reportPass("verified SSN value " + webcompage.customerSsn + " successfully");
		} else {
			reportFail("Failed to verify SSN value in Customer Details");
		}
	}

	@Then("Update SSN value {string}of the customer from customer details page")
	public void update_SSN_value_of_the_customer_from_customer_details_page(String ssnVNewValue) {
		if (webcompage.updateSsnValue(ssnVNewValue)) {
			reportPass("Updated SSN value " + ssnVNewValue + " successfully");
		} else {
			reportFail("Failed to update SSN value in Customer Details");
		}
	}

	@Then("I enter {string} in to Business Name field")
	public void i_enter_in_to_Business_Name_field(String businessName) {
		if (webcompage.enterBusinessName(businessName)) {
			reportPass("Entered Business Name " + businessName + " successfully");
		} else {
			reportFail("Failed to enter Business Name into search field");
		}
	}

	@Then("Verify column names from summary table")
	public void verify_column_names_from_summary_table(DataTable values) {
		List<String> selectValues = values.asList(String.class);
		if (webcompage.verifyColumnNames(selectValues)) {
			reportPass("Verified Column names successfully");
		} else {
			reportFail("Failed to verify Column names");
		}
	}

	@Then("Click on authorized access button from the table")
	public void click_on_authorized_access_button_from_the_table() {
		if (webcompage.clickAuthorizedAccess()) {
			reportPass("Clicked on Authorized Access button successfully");
		} else {
			reportFail("Failed to click on Authorized Access button");
		}
	}

	@Then("Verify Business details section from Manage Authorized Access page")
	public void verify_Business_details_section_from_Manage_Authorized_Access_page() {
		if (webcompage.verifyBusinessDetails()) {
			reportPass("Verified Business Details section successfully");
		} else {
			reportFail("Failed to verify Business Details section");
		}
	}

	@Then("Verify Customer details section from Manage Authorized Access page")
	public void verify_Customer_details_section_from_Manage_Authorized_Access_page() {
		if (webcompage.verifyCustomerDetails()) {
			reportPass("Verified Customer Details section successfully");
		} else {
			reportFail("Failed to verify Customer Details section");
		}
	}

	@Then("Verify customer business information from Webster Account Summary")
	public void verify_customer_business_information_from_Webster_Account_Summary() {
		if (webcompage.verifyBusinessInfo()) {
			reportPass("Verified Customer Business Information section successfully");
		} else {
			reportFail("Failed to verify Customer Business Information section");
		}
	}

	@Then("Verify statement period drop down to check dates in descending order")
	public void verify_statement_period_drop_down_to_check_dates_in_descending_order() {
		if (webcompage.verifyStatementPeriod()) {
			reportPass("Verified Statement Period drop-down successfully");
		} else {
			reportFail("Failed to verify Statement Period drop-down");
		}
	}

	@Then("Enter account number {string} in to account number field")
	public void enter_account_number_in_to_account_number_field(String acctNumber) {
		if (webcompage.enterStatementAcctNumber(acctNumber)) {
			reportPass("Entered Account Number " + acctNumber + " successfully");
		} else {
			reportFail("Failed to enter Account Number");
		}
	}

	@Then("Enter account number {string} in to ITR tax ID field")
	public void enter_account_number_in_to_ITR_tax_ID_field(String taxID) {
		if (webcompage.enterStatementITRTaxID(taxID)) {
			reportPass("Entered ITR Tax ID " + taxID + " successfully");
		} else {
			reportFail("Failed to enter ITR Tax ID");
		}
	}

	@Then("I click on search button")
	public void i_click_on_search_button() {
		if (webcompage.searchButtonClick()) {
			reportPass("Clicked on Search button successfully");
		} else {
			reportFail("Failed to click on Search button");
		}
	}

	@Then("Click on View statement button from the list")
	public void click_on_View_statement_button_from_the_list() {
		if (webcompage.clickViewStatement()) {
			reportPass("Clicked on View Statement button successfully");
		} else {
			reportFail("Failed to click on View Statement button");
		}
	}

	@Then("Verify {string} header of the statement")
	public void verify_header_of_the_statement(String header) {
		if (webcompage.verifyHeader(header)) {
			reportPass("Verified Statement Header successfully");
		} else {
			reportFail("Failed to verify Statement Header");
		}
	}

	@Then("Click on Print preview button from the list")
	public void click_on_Print_preview_button_from_the_list() {
		if (webcompage.clickPrintPreview()) {
			reportPass("Clicked on Print Preview button successfully");
		} else {
			reportFail("Failed to click on Print Preview button");
		}
	}

	@Then("Verify {string} page title of print preview page")
	public void verify_page_title_of_print_preview_page(String pageTitle) {
		if (webcompage.verifyPreviewPageTitle(pageTitle)) {
			reportPass("Verified Print Preview page title successfully");
		} else {
			reportHardFail("Failed to verify Print Preview page title");
		}
	}

	@Then("Verify check images are present in statement")
	public void verify_check_images_are_present_in_statement() {
		if (webcompage.verifyCheckImage()) {
			reportPass("Check Image present in Statement and clicked on Check Image successfully");
		} else {
			reportFail("Failed to verify Check Image");
		}
	}

	@Then("click on image and verify image opened in popup")
	public void click_on_image_and_verify_image_opened_in_popup() {
		if (webcompage.verifyImagePopUp()) {
			reportPass("Check Image opened in popup successfully");
		} else {
			reportFail("Failed to verify Check Image popup");
		}

	}

	@Then("Verify NSF fee cycle to date should display {string}")
	public void verify_NSF_fee_cycle_to_date_should_display(String string) {
		if (webcompage.verifyCycleToDate()) {
			reportPass("Verified cycle-to-date NSF fee displayed successfully");
		} else {
			reportFail("Failed to verify cycle-to-date NSF fee $0.00");
		}
	}

	@Then("Verify NSF fee year to date should display {string}")
	public void verify_NSF_fee_year_to_date_should_display(String string) {
		if (webcompage.verifyYearToDate()) {
			reportPass("Verified cycle-to-date NSF fee displayed successfully");
		} else {
			reportFail("Failed to verify cycle-to-date NSF fee $0.00");
		}
	}

	@Then("Select By date option from the print options")
	public void select_By_date_option_from_the_print_options() {
		if (webcompage.selectByDate()) {
			reportPass("Selected by date radio option successfully");
		} else {
			reportFail("Failed to select by date option");
		}
	}

	@Then("Select By category option from the print options")
	public void select_By_category_option_from_the_print_options() {
		if (webcompage.selectByCategory()) {
			reportPass("Selected by Category radio option successfully");
		} else {
			reportFail("Failed to select by Category option");
		}
	}

	@Then("Verify date is displayed on the statement")
	public void verify_date_is_displayed_on_the_statement() {
		if (webcompage.verifyDate()) {
			reportPass("Verified date successfully and displayed date is - " + webcompage.cycleDateVal);
		} else {
			reportFail("Failed to capture date from Statement");
		}
	}

	@Then("Verify name and address displayed on the statement")
	public void verify_name_and_address_displayed_on_the_statement() {
		if (webcompage.verifyNameAndAddress()) {
			reportPass("Verified Name and Address section successfully from Statement");
		} else {
			reportFail("Failed to verify Name and Address section from Statement");
		}
	}

	@Then("Verify Detailed Account Activity text from the statement")
	public void verify_text_from_the_statement() {
		if (webcompage.verifyAccountActivity()) {
			reportPass(
					"Verified Account Activity text successfully and displayed text as - " + webcompage.activityAcct);
		} else {
			reportFail("Failed to capture detailed Activity text from Statement");
		}
	}

	@Then("Verify Customer service information section from the statement")
	public void verify_Customer_service_information_section_from_the_statement() {
		if (webcompage.verifyCustomerService()) {
			reportPass("Verified Customer Service section successfully from Statement");
		} else {
			reportFail("Failed to verify Customer Service section from Statement");
		}
	}

	@Then("verify account number from the statement")
	public void verify_account_number_from_the_statement() {
		if (webcompage.verifyAccountNumber()) {
			reportPass(
					"Verified Account Number successfully from Statement and displayed as " + webcompage.acctNumberVal);
		} else {
			reportFail("Failed to verify Account Number from Statement");
		}
	}

	@Then("Verify Summary section from the statement")
	public void verify_Summary_section_from_the_statement() {
		if (webcompage.verifySummary()) {
			reportPass("Verified Summary section successfully from Statement");
		} else {
			reportFail("Failed to verify Summary section from Statement");
		}
	}

	@Then("Verify Interest sections from the statement")
	public void verify_Interest_sections_from_the_statement() {
		if (webcompage.verifyInterest()) {
			reportPass("Verified Interest section successfully from Statement");
		} else {
			reportFail("Failed to verify Interest section from Statement");
		}
	}

	@Then("Verify Transactions table from the statement")
	public void verify_Transactions_table_from_the_statement() {
		if (webcompage.verifyTansactions()) {
			reportPass("Verified Transactions table successfully from Statement");
		} else {
			reportFail("Failed to verify Transactions table from Statement");
		}
	}

	@Then("Verify Checks paid table from the statement")
	public void verify_Checks_paid_table_from_the_statement() {
		if (webcompage.verifyChecksPaid()) {
			reportPass("Verified Checks Paid table successfully from Statement");
		} else {
			reportFail("Failed to verify Checks Paid table from Statement");
		}
	}

	@Then("Verify Fee summary table from the statement")
	public void verify_Fee_summary_table_from_the_statement() {
		if (webcompage.verifyFeeSummary()) {
			reportPass("Verified Fee Summary table successfully from Statement");
		} else {
			reportFail("Failed to verify Fee Summary table from Statement");
		}
	}

	@Then("I see {string} page of Webcom application")
	public void i_see_page_of_Webcom_application(String string) {
		if (webcompage.verifyTitle(string)) {
			reportPass("verified Customer Statement page title successfully");
		} else {
			reportHardFail("Failed to verify Customer Statement title");
		}
	}

	@Then("Verify page header {string} of the search results page")
	public void verify_page_header_of_the_search_results_page(String string) {
		if (webcompage.verifyPageTitle(string)) {
			reportPass("verified Customer Statement List page title successfully");
		} else {
			reportHardFail("Failed to verify Customer Statement List title");
		}
	}

	@Then("Verify customer role is {string} and make admin disable from customer details table")
	public void verify_customer_role_is_and_make_admin_disable_from_customer_details_table(String customerRole) {
		if (webcompage.verifyCustomerRole(customerRole)) {
			reportPass("verified successfully Customer Role and make Admin checkbox is disabled ");
		} else {
			reportHardFail("Failed to verify Customer Role and make Admin checkbox is disabled");
		}
	}

	@Then("Click on user name from customer details section")
	public void click_on_user_name_from_customer_details_section() {
		if (webcompage.clickUsername()) {
			reportPass("clicked on User Name successfully");
		} else {
			reportHardFail("Failed to click on User Name");
		}
	}

	@Then("I enter {string} in to Company ID field")
	public void i_enter_in_to_Company_ID_field(String companyId) {
		if (webcompage.enterCompanyId(companyId)) {
			reportPass("Entered Company ID " + companyId + " successfully");
		} else {
			reportFail("Failed to enter Company ID into search field");
		}
	}

	@Then("Click on Manage users link from Customer details page")
	public void click_on_Manage_users_link_from_Customer_details_page() {
		if (webcompage.clickManageUsers()) {
			reportPass("Clicked on Manage Users link successfully");
		} else {
			reportFail("Failed to click on Manage Users link");
		}
	}

	@Then("Verify company id from business details section")
	public void verify_company_id_from_business_details_section() {
		if (webcompage.verifyCompanyId()) {
			reportPass("Verified Company ID successfully");
		} else {
			reportFail("Failed to verify Company ID");
		}
	}

	@Then("Verify Customer info section should not present")
	public void verify_Customer_info_section_should_not_present() {
		if (webcompage.verifyCompanyInfoAbsence()) {
			reportPass("Company Information not available and verification successful");
		} else {
			reportFail("Failed to verify absence of Company Information section");
		}
	}

	@Then("Verify Customer info section should be present")
	public void verify_Customer_info_section_should_be_present() {
		if (webcompage.verifyCompanyInfoPresence()) {
			reportPass("Verified Company Information section successfully");
		} else {
			reportFail("Failed to verify presence of Company Information");
		}
	}

	@Then("I should go to wol application paymeny history page and should show {string}")
	public void i_should_go_to_wol_application_paymeny_history_page_and_should_show(String title) {
		if (webcompage.verifyPaymentHistory(title)) {
			reportPass("Verified Payment History successfully and switched to Main page");
		} else {
			reportFail("Failed to verify Payment History and failed to switch to Main page");
		}
	}

	@Then("Verify userID field should contain default value")
	public void verify_userID_field_should_contain_default_value() {
		if (webcompage.verifyDefaultValue()) {
			reportPass("Verified default value successfully and displayed value is " + webcompage.defaultValue);
		} else {
			reportFail("Failed to verify default value for User ID field");
		}
	}

	@Then("Verify column names from table")
	public void verify_column_names_from_table(DataTable values) {
		List<String> colValues = values.asList(String.class);
		if (webcompage.verifyColumnHeaders(colValues)) {
			reportPass("Verified Column names successfully");
		} else {
			reportFail("Failed to verify Column names");
		}
	}

	@Then("I click on customer details link from Manager Audit Trail Details page")
	public void i_click_on_customer_details_link_from_Manager_Audit_Trail_Details_page() {
		if (webcompage.clickCustomerDetails()) {
			reportPass("Clicked on Customer Details link successfully");
		} else {
			reportFail("Failed to click on on Customer Details link");
		}
	}

	@Then("I click on browser back button")
	public void i_click_on_browser_back_button() {
		if (webcompage.clickBrowserBack()) {
			reportPass("Navigated to browser back successfully");
		} else {
			reportFail("Failed to Navigate the browser back");
		}
	}

	@Then("I click on start new search link from Manager Audit Trail Details page")
	public void i_click_on_start_new_search_link_from_Manager_Audit_Trail_Details_page() {
		if (webcompage.clickNewSearchLink()) {
			reportPass("Clicked on New Search link successfully");
		} else {
			reportFail("Failed to click on New Search link");
		}
	}

	@Then("I click on modify search link from Manager Audit Trail Details page")
	public void i_click_on_modify_search_link_from_Manager_Audit_Trail_Details_page() {
		if (webcompage.clickModifySearch()) {
			reportPass("Clicked on Modify Search link successfully");
		} else {
			reportFail("Failed to click on Modify Search link");
		}
	}

	@Then("Verify add new user confirmation text from the table")
	public void verify_add_new_user_confirmation_text_from_the_table() {
		if (webcompage.verifyConfirmationText()) {
			reportPass("Verified Confirmation text successfully");
		} else {
			reportFail("Failed to verify new User Confirmation text");
		}
	}

	@Then("Verify branch number iput box, search button, clear button and add new branch button")
	public void verify_branch_number_iput_box_search_button_clear_button_and_add_new_branch_button() {
		if (webcompage.verifyButtons()) {
			reportPass("Verified Branch Number Input, Search, Clear and Add New branch buttons successfully");
		} else {
			reportFail("Failed to verify Branch Number Input, Search, Clear and Add New branch buttons");
		}
	}

	@Then("Click on search button with out any data in branch number input box")
	public void click_on_search_button_with_out_any_data_in_branch_number_input_box() {
		if (webcompage.clickSearch()) {
			reportPass("Performed Search without any data in Branch Number is successful");
		} else {
			reportFail("Failed to perform Search action without any data in Branch Number");
		}
	}

	@Then("Verify column names from branches table")
	public void verify_column_names_from_branches_table(DataTable values) {
		List<String> colValues = values.asList(String.class);
		if (webcompage.verifyBranchHeaders(colValues)) {
			reportPass("Verified Branches table column names successfully");
		} else {
			reportFail("Failed to verify Branches table column names");
		}
	}

	@When("Enter invalid branch number as {string} and search")
	public void enter_invalid_branch_number_as_and_search(String invalidId) {
		if (webcompage.invalidBranchId(invalidId)) {
			reportPass("With Invalid Branch Number performed search successfully");
		} else {
			reportFail("Failed to perform Search action with Invalid Branch Number");
		}
	}

	@Then("Validate displayed message {string}")
	public void validate_displayed_message(String errorMessage) {
		if (webcompage.verifyInvalidBranchError(errorMessage)) {
			reportPass("Validated displayed message successfully and error is " + errorMessage);
		} else {
			reportFail("Failed to validate Displayed message");
		}
	}

	@Then("Enter valid branch number {string} and search")
	public void enter_valid_branch_number_and_search(String branchId) {
		if (webcompage.validBranchSearch(branchId)) {
			reportPass("With valid branch number performed search successfully");
		} else {
			reportFail("Failed to perform Search action with Valid Branch Number");
		}
	}

	@Then("I click on clear button to clear the data from page")
	public void i_click_on_clear_button_to_clear_the_data_from_page() {
		if (webcompage.clickClearButton()) {
			reportPass("Clicked on Clear button and data cleared successfully");
		} else {
			reportFail("Failed to click on Clear button");
		}
	}

	@Then("I click on add new branch button")
	public void i_click_on_add_new_branch_button() {
		if (webcompage.clickAddNew()) {
			reportPass("Clicked on Add New button successfully");
		} else {
			reportFail("Failed to click on Add New button");
		}
	}

	@Then("Verify Branch number,Routing number,Is commercial and description input boxes")
	public void verify_Branch_number_Routing_number_Is_commercial_and_description_input_boxes() {
		if (webcompage.verifyAddNewFields()) {
			reportPass("Verified Branch Number, Routing Number, Is Commercial and Description Input boxes successfully");
		} else {
			reportFail("Failed to verify Branch Number, Routing Number, Is Commercial and Description Input boxes");
		}
	}

	@Then("Enter branch number {string} and routing number {string} and description {string} click on add button")
	public void enter_branch_number_and_routing_number_and_description_click_on_add_button(String branchId,
			String routingNumber, String description) {
		if (webcompage.enterDataIntoFields(branchId, routingNumber, description)) {
			reportPass("Entered data into Branch Number, Routing Number and Description Input boxes successfully");
		} else {
			reportFail(
					"Failed to enter data into Branch Number, Routing Number and Description Input boxes");
		}
	}

	@Then("Verify displayed message {string}")
	public void verify_displayed_message(String errorMessage) {
		if (webcompage.verifyDuplicateError(errorMessage)) {
			reportPass("Verified message successfully and message is " + errorMessage);
		} else {
			reportFail("Failed to verify displayed message");
		}
	}

	@Then("I click on up and down arrows from Branch number column to check Ascending and Descending")
	public void i_click_on_up_and_down_arrows_from_Branch_number_column_to_check_Ascending_and_Descending() {
		if (webcompage.verifyBranchNumberSort()) {
			reportPass("Verified Branch Number column records sorting successfully");
		} else {
			reportFail("Failed to verify Branch Number column records sorting");
		}
	}

	@Then("I click on up and down arrows from routing number column to check Ascending and Descending")
	public void i_click_on_up_and_down_arrows_from_routing_number_column_to_check_Ascending_and_Descending() {
		if (webcompage.verifyRoutingNumberSort()) {
			reportPass("Verified Routing Number column records sorting successfully");
		} else {
			reportFail("Failed to verify Routing Number column records sorting");
		}
	}

	@Then("I click on up and down arrows from description column to check Ascending and Descending")
	public void i_click_on_up_and_down_arrows_from_description_column_to_check_Ascending_and_Descending() {
		if (webcompage.verifyDescriptionSort()) {
			reportPass("Verified Description column records sorting successfully");
		} else {
			reportFail("Failed to verify Description column records sorting");
		}
	}

	@Then("I click on menu back button")
	public void i_click_on_menu_back_button() {
		if (webcompage.clickMenuBack()) {
			reportPass("Clicked on Back link from Menu successfully");
		} else {
			reportFail("Failed to click on Back link from Menu");
		}
	}

	@Then("I click on delete link to delete added branch")
	public void i_click_on_delete_link_to_delete_added_branch() {
		if (webcompage.clickDeleteLink()) {
			reportPass("Clicked on Delete link successfully");
		} else {
			reportFail("Failed to click on Delete link");
		}
	}

	@Then("I Get the default value from email field from customer details page")
	public void i_Get_the_default_value_from_email_field_from_customer_details_page() {
		if (webcompage.getDefaultValue()) {
			reportPass("Collected default value successfully and default email is " + webcompage.defaultEmail);
		} else {
			reportFail("Failed to get default value from field");
		}
	}

	@Then("Click on Reset button")
	public void click_on_Reset_button() {
		if (webcompage.clickReset()) {
			reportPass("Clicked on Reset button successfully");
		} else {
			reportFail("Failed to click on Reset button");
		}
	}

	@Then("Verify Email value not updated after clicked on reset button")
	public void verify_Email_value_not_updated_after_clicked_on_reset_button() {
		if (webcompage.verifyUpdatedValue()) {
			reportPass("Email ID not updated, after clicked on Reset button successfully");
		} else {
			reportFail("Failed to verify updated Email ID after cliked on Reset button");
		}
	}

	@Then("Verify {string} message on customer details page")
	public void verify_message_on_customer_details_page(String message) {
		if (webcompage.verifyMessage(message)) {
			reportPass("Verified message successfully and message is " + webcompage.messagePageLevel);
		} else {
			reportFail("Failed to verify Page Level message");
		}
	}

	@Then("Verify state field showing existing state data")
	public void verify_state_field_showing_existing_state_data() {
		if (webcompage.verifyStateValue()) {
			reportPass("Verified State drop-down value successfully and displayed value is " + webcompage.defaultState);
		} else {
			reportFail("Failed to verify State existing value");
		}
	}

	@Then("Verify license state field existing default state data")
	public void verify_license_state_field_existing_default_state_data() {
		if (webcompage.verifyLicenseStateValue()) {
			reportPass("Verified License State drop-down value successfully and displayed value is "
					+ webcompage.defaultLicenseState);
		} else {
			reportFail("Failed to verify License State existing value");
		}
	}

	@Then("Select {string} from state drop down")
	public void select_from_state_drop_down(String state) {
		if (webcompage.selectStateValue(state)) {
			reportPass("Selected state drop-down value successfully and displayed value is " + state);
		} else {
			reportFail("Failed to select State value");
		}
	}

	@Then("Select {string} from license state drop down")
	public void select_from_license_state_drop_down(String licenseState) {
		if (webcompage.selectLicenseStateValue(licenseState)) {
			reportPass("Selected License State drop-down value successfully and displayed value is " + licenseState);
		} else {
			reportFail("Failed to select License State value");
		}
	}

	@Then("Verify state and license state fields are showing previous data")
	public void verify_state_and_license_state_fields_are_showing_previous_data() {
		if (webcompage.verifyStateDefaultValues()) {
			reportPass("Verified License State and State drop-down values successfully and displayed State value as: "
					+ webcompage.defaultState + "and License state as: " + webcompage.defaultLicenseState);
		} else {
			reportFail("Failed to verify default License State and State values");
		}
	}

	@Then("Verify {string} and {string} and {string} fields text")
	public void verify_and_and_fields_text(String lastName, String logIn, String userId) {
		if (webcompage.verifyFieldValues(lastName, logIn, userId)) {
			reportPass("Verified Last Name, User Login and User ID field text successfully");
		} else {
			reportFail("Failed to verify Last Name, User Login and User ID field text");
		}
	}

	@Then("Verify {string} text from the filters section")
	public void verify_text_from_the_filters_section(String string) {
		if (webcompage.verifyShowDetails(string)) {
			reportPass("Verified Show Details to view all User's text successfully");
		} else {
			reportFail("Failed to verify Show Details to view all User's text");
		}
	}

	@Then("Click on show details button from page")
	public void click_on_show_details_button_from_page() {
		if (webcompage.clickShowDetailsUnlockUsers()) {
			reportPass("Clicked on Show Details button successfully");
		} else {
			reportFail("Failed to click on Show Details button");
		}
	}

	@Then("Verify {string} and {string} column names from user's table")
	public void verify_and_column_names_from_user_s_table(String userId, String userName) {
		if (webcompage.verifyUserTableColumnNames(userId, userName)) {
			reportPass("Verified " + userId + " and " + userName + " column names successfully");
		} else {
			reportFail("Failed to verify " + userId + " and " + userName + " column names");
		}
	}

	@Then("Verify sub menu list values")
	public void verify_sub_menu_list_values(DataTable values) {
		List<String> colValues = values.asList(String.class);
		if (webcompage.verifySubMenuListValues(colValues)) {
			reportPass("Verified Sub-Menu List values successfully");
		} else {
			reportFail("Failed to Verify Sub-Menu List values");
		}
	}

	@Then("Select {string} from choose profile drop down")
	public void select_from_choose_profile_drop_down(String profile) {
		if (webcompage.selectProfile(profile)) {
			reportPass("Selected " + profile + " -profile from choose profile drop-down successfully");
		} else {
			reportFail("Failed to select Profile from choose Profile drop-down");
		}
	}

	@Then("Select {string} from choose activity drop down")
	public void select_from_choose_activity_drop_down(String activity) {
		if (webcompage.selectActivity(activity)) {
			reportPass("Selected " + activity + " -activity from choose activity drop-down successfully");
		} else {
			reportFail("Failed to select Activity from choose Activity drop-down");
		}
	}

	@Then("Select {string} from choose activity drop down from filter")
	public void select_from_choose_activity_drop_down_from_filter(String activity) {
		if (webcompage.selectFilterActivity(activity)) {
			reportPass("Selected " + activity + " -activity from choose Activity drop-down successfully");
		} else {
			reportFail("Failed to select Activity from choose Activity drop-down");
		}
	}

	@Then("Enter last name as {string} in to user last name text box")
	public void enter_last_name_as_in_to_user_last_name_text_box(String lastName) {
		if (webcompage.enterLastNameFilter(lastName)) {
			reportPass("Entered Last Name into Last Name field successfully");
		} else {
			reportFail("Failed to enter Last Name");
		}
	}

	@Then("Click on view\\/modify link from the users page")
	public void click_on_view_modify_link_from_the_users_page() {
		if (webcompage.clickViewModify()) {
			reportPass("Clicked on View/ Modify link successfully");
		} else {
			reportFail("Failed to click on View/ Modify link");
		}
	}

	@Then("Verify current status {string} from user table")
	public void verify_current_status_from_user_table(String status) {
		if (webcompage.verifyUserStatus(status)) {
			reportPass("Verified User Status " + status + " successfully");
		} else {
			reportFail("Failed to verify User Status");
		}
	}

	@Then("Verify {string} link is not present in the list menu")
	public void verify_link_is_not_present_in_the_list_menu(String string) {
		if (webcompage.verifySubMenuLinkUnlock(string)) {
			reportHardFail("Failed to verify Unlock link and link is present");
		} else {
			reportPass("Verified Sub-Menu and Unlock link is not present ");
		}
	}

	@Then("Verify {string} value from {string} column of history table")
	public void verify_value_from_column_of_history_table(String value, String columnName) {
		if (webcompage.verifyValueFromHistoryTable(value, columnName)) {
			reportPass("Verified " + value + " from " + columnName + " column successfully");
		} else {
			reportFail("Failed to verify " + value + " from " + columnName + " column");
		}
	}

	@Then("Verify showing {string} text from history table")
	public void verify_showing_text_from_history_table(String string) {
		if (webcompage.verifyRecordsCount(string)) {
			reportPass("Verified Records Count message successfully");
		} else {
			reportFail("Failed to verify Records Count message from History table");
		}
	}

	@Then("Verify showing Next and Last pagination links prsence")
	public void verify_showing_Next_and_Last_pagination_links_prsence() {
		if (webcompage.verifyNextLastLinks()) {
			reportPass("Verified Next and Last pagination links successfully");
		} else {
			reportFail("Failed to verify Next and Last pagination links");
		}
	}

	@Then("Select {string} option from Product Category drop down")
	public void select_option_from_Product_Category_drop_down(String selectValue) {
		if (webcompage.selectProductCategory(selectValue)) {
			reportPass("Selected value is: " + selectValue + " from Product Category");
		} else {
			reportFail("Failed to select value: " + selectValue + " from Product Category");
		}
	}

	@Then("Click on Search button")
	public void click_on_Search_button() {
		if (webcompage.searchButtonClick())
			reportPass("Search button is clicked");
		else
			reportFail("Search button is not clicked");
	}

	@Then("I clear data for {string} field in {string} page")
	public void i_clear_data_for_field_in_page(String fieldName, String pageName) {
		if (webcompage.clearValue(fieldName))
			reportPass("Cleared value for: " + fieldName + " from page: " + pageName);
		else
			reportFail("Unable to clear value for: " + fieldName + " from page: " + pageName);
	}

	@Then("Verify {string} column showing value {string}")
	public void verify_column_showing_value(String column, String value) {
		if (webcompage.verifyTextInColumnCells(column, value)) {
			reportPass("Verified " + value + " successfully and present in " + column + " column");
		} else {
			reportFail("Failed to verify " + value + " in the " + column + " column");
		}
	}

	@Then("Verify {string} link presence in Webcom Options")
	public void verify_link_presence_in_Webcom_Options(String string) {
		if (webcompage.verifyPassMarkLinkPresence(string)) {
			reportPass("Verified " + string + " link successfully");
		} else {
			reportFail("Failed to verify " + string + " link");
		}
	}

	@Then("Delete {string} RSA user from the list")
	public void delete_RSA_user_from_the_list(String string) {
		if (webcompage.deleteRsaUser(string)) {
			reportPass("Deleted RSA User " + string + " successfully");
		} else {
			reportFail("Failed to delete RSA User");
		}
	}

	@Then("Verify delete message {string} from page")
	public void verify_delete_message_from_page(String string) {
		if (webcompage.verifyDeleteMessage(string)) {
			reportPass("Verified " + string + " message successfully");
		} else {
			reportFail("Failed to verify " + string + " message");
		}
	}

	@Then("Verify {string} link not present in Webcom Options")
	public void verify_link_not_present_in_Webcom_Options(String string) {
		if (webcompage.verifyPassMarkLinkNotPresent(string)) {
			reportPass("successfully verified " + string + " link not present");
		} else {
			reportFail("Failed to verify " + string + " link absence");
		}
	}

	@Then("Select user {string} from the RSA User list")
	public void select_user_from_the_RSA_User_list(String string) {
		if (webcompage.selectRsaUser(string)) {
			reportPass("selected " + string + " RSA User successfully");
		} else {
			reportFail("Failed to select RSA user from the list");
		}
	}

	@Then("Click on add RSA user button from webcom page")
	public void click_on_add_RSA_user_button_from_webcom_page() {
		if (webcompage.clickAddRsaUser()) {
			reportPass("Clicked on Add RSA user button successfully");
		} else {
			reportFail("Failed to click on Add RSA User button");
		}
	}

	@Then("Verify Add message {string} from page")
	public void verify_Add_message_from_page(String string) {
		if (webcompage.verifyAddMessage(string)) {
			reportPass("Verified " + string + " message successfully");
		} else {
			reportFail("Failed to verify " + string + " message");
		}
	}

	@Then("Verify {string} drop down field display")
	public void verify_drop_down_field_display(String string) {
		if (webcompage.verifyProductCategory(string)) {
			reportPass("Verified Product Category field successfully");
		} else {
			reportFail("Failed to verify Product Category field");
		}
	}

	@Then("Verify {string} list box field display")
	public void verify_list_box_field_display(String string) {
		if (webcompage.verifyProductName(string)) {
			reportPass("Verified Product Name field successfully");
		} else {
			reportFail("Failed to verify Product Name field");
		}
	}

	@Then("Verify {string} list field display")
	public void verify_list_field_display(String string) {
		if (webcompage.verifyApplCode(string)) {
			reportPass("Verified Application Code field successfully");
		} else {
			reportFail("Failed to verify Application Code field");
		}
	}

	@Then("Verify {string} drop down display")
	public void verify_drop_down_display(String string) {
		if (webcompage.verifyAccountType(string)) {
			reportPass("Verified Account Type field successfully");
		} else {
			reportFail("Failed to verify Account Type field");
		}
	}

	@Then("Verify {string} field display")
	public void verify_field_display(String string) {
		if (webcompage.verifyProductStatus(string)) {
			reportPass("Verified Product Status field successfully");
		} else {
			reportFail("Failed to verify Product Status field");
		}
	}

	@Then("Verify {string} list box field displayed")
	public void verify_list_box_field_displayed(String string) {
		if (webcompage.verifyRequestStatus(string)) {
			reportPass("Verified Request Status field successfully");
		} else {
			reportFail("Failed to verify Request Status field");
		}
	}

	@Then("Verify {string} option list box field display")
	public void verify_option_list_box_field_display(String string) {
		if (webcompage.verifyRecomProduct(string)) {
			reportPass("Verified Recommended Product field successfully");
		} else {
			reportFail("Failed to verify Recommended Product field");
		}
	}

	@Then("Verify {string} button display")
	public void verify_button_display(String string) {
		if (webcompage.verifySearchButton(string)) {
			reportPass("Verified Search button successfully");
		} else {
			reportFail("Failed to verify Search button");
		}
	}

	@Then("Verify {string} button display or not")
	public void verify_button_display_or_not(String string) {
		if (webcompage.verifyClearButton(string)) {
			reportPass("Verified Clear button successfully");
		} else {
			reportFail("Failed to verify Clear button");
		}
	}

	@Then("Select {string} value from Recommended Product list")
	public void select_value_from_Recommended_Product_list(String string) {
		if (webcompage.selectRecommProduct(string)) {
			reportPass("Selected " + string + " as Recommended Product successfully");
		} else {
			reportFail("Failed to select Recommended Product from the list");
		}
	}

	@Then("Click on search button")
	public void click_on_search_button() {
		if (webcompage.searchClick()) {
			reportPass("clicked on Search button successfully");
		} else {
			reportFail("Failed to click on Search button");
		}
	}

	@Then("Verify {string} from product short name column")
	public void verify_from_product_short_name_column(String string) {
		if (webcompage.verifyProductShortName(string)) {
			reportPass("Verified " + string + " Product Short Name from result table successfully");
		} else {
			reportFail("Failed to verify Product Short Name from the result table");
		}
	}

	@Then("Verify {string} from  account type column")
	public void verify_from_account_type_column(String string) {
		if (webcompage.verifyTypeOfAccount(string)) {
			reportPass("Verified " + string + " Account Type from Result table successfully");
		} else {
			reportFail("Failed to verify Account Type from the Result table");
		}
	}

	@Then("Verify {string} label from APPROVE SETUP PRODUCT for WEB BANKING page")
	public void verify_label_from_APPROVE_SETUP_PRODUCT_for_WEB_BANKING_page(String string) {
		if (webcompage.verifyRecommendedProductLabel(string)) {
			reportPass("Verified " + string + " label successfully");
		} else {
			reportFail("Failed to verify Recommended Product Label");
		}
	}

	@Then("Verify Recommended product Yes option")
	public void verify_Recommended_product_Yes_option() {
		if (webcompage.verifyRecommendedProductYes()) {
			reportPass("Verified Recommended Product Yes option successfully");
		} else {
			reportFail("Failed to verify Recommended Product Yes option");
		}
	}

	@Then("Verify Recommended product No option")
	public void verify_Recommended_product_No_option() {
		if (webcompage.verifyRecommendedProductNo()) {
			reportPass("Verified Recommended Product No option successfully");
		} else {
			reportFail("Failed to verify Recommended Product No option");
		}
	}

	@Then("Select {string} value from Product category list")
	public void select_value_from_Product_category_list(String string) {
		if (webcompage.selectProdCategory(string)) {
			reportPass("Selected Product Category " + string + " successfully");
		} else {
			reportFail("Failed to select Product Category");
		}
	}

	@Then("Select Yes option from Recommended product option")
	public void select_Yes_option_from_Recommended_product_option() {
		if (webcompage.selectYesOption()) {
			reportPass("Selected Recommended Product Yes option successfully");
		} else {
			reportFail("Failed to select Recommended Product Yes option");
		}
	}

	@Then("Click on Update Button")
	public void click_on_Update_Button() {
		if (webcompage.clickButtonUpdate()) {
			reportPass("Clicked on Update button successfully");
		} else {
			reportFail("Failed to click on Update button");
		}
	}

	@Then("Verify {string} error message")
	public void verify_error_message(String string) {
		if (webcompage.verifyRecommProductError(string)) {
			reportPass("Verified Error successfully and displayed as " + webcompage.errorMessage);
		} else {
			reportFail("Failed to verify Error message");
		}
	}

	@Then("Sort the account type column")
	public void sort_the_account_type_column() {
		if (webcompage.clickSort()) {
			reportPass("Clicked on Sort button successfully");
		} else {
			reportFail("Failed to click on Sort button");
		}
	}

	@Then("Verify {string} option on customer details page")
	public void verify_option_on_customer_details_page(String string) {
		if (webcompage.verifyApplyEligibilityRules(string)) {
			reportPass("Verified Apply Eligibility Rules option successfully");
		} else {
			reportFail("Failed to verify Apply Eligibility Rules option");
		}
	}

	@Then("Verify sub menu list values from customer Maintenance")
	public void verify_sub_menu_list_values_from_customer_Maintenance(DataTable values) {
		List<String> colValues = values.asList(String.class);
		if (webcompage.verifySubMenuValues(colValues)) {
			reportPass("Verified Sub-Menu List values successfully");
		} else {
			reportFail("Failed to Verify Sub-Menu List values");
		}
	}

	@Then("Collect Source column value and verify {string} order")
	public void collect_source_column_value_and_verify_order(String string) {
		if (webcompage.verifySourceColumnSort(string)) {
			reportPass("Verified Source Column values successfully and present in sorted order");
		} else {
			reportFail("Failed to verify Source Column values order");
		}
	}

	@Then("Collect Activity column value and verify {string} order")
	public void collect_Activity_column_value_and_verify_order(String string) {
		if (webcompage.verifyActivityColumnSort(string)) {
			reportPass("Verified Activity Column values successfully and present in sorted order");
		} else {
			reportFail("Failed to verify Activity Column values order");
		}
	}

	@Then("Collect Description column value and verify {string} order")
	public void collect_Description_column_value_and_verify_order(String string) {
		if (webcompage.verifyDescriptionColumnSort(string)) {
			reportPass("Verified Description Column values successfully and present in sorted order");
		} else {
			reportFail("Failed to verify Description Column values order");
		}
	}

}
