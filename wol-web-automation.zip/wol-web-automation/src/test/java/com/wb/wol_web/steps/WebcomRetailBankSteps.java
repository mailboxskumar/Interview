package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.WebcomPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WebcomRetailBankSteps extends ObjectBase {

	WebcomPage webcomPage = new WebcomPage();
	List<String> selectValues ;

	@When("^As a Admin user I logged into Webcom$")
	public void as_a_admin_user_i_logged_into_webcom() throws Throwable {
		if (webcomPage.loginWebcom())
			reportPass("Logged into Webcom Application");
		else
			reportFail("Failed to Logged into Webcom");
	}

	@When("^I click on \"([^\"]*)\" link in Webcom Options$")
	public void i_click_on_something_link_in_retailbank_activities_options(String linkText) throws Throwable {
		try {
			webcomPage.selectLinkFromTheMenuWebcom(linkText);
			reportPass("Clicked on Link " + linkText);
		} catch (Exception e) {
			reportFail("Failed to click on Link" + linkText);
		}
	}

	@Then("^I should be in \"([^\"]*)\" page of Webcom application$")
	public void i_should_be_in_something_page_of_webcom_application(String message) throws Throwable {
		if (webcomPage.verifyPageHeader(message))
			reportPass("The Page Header: {" + message + "} is  successfully displayed");
		else {
			reportFail("The Page Header: {" + message + "} is not displayed");
		}
	}

	@When("I select appl code and application type in Product Maintenance List page")
	public void i_select_appl_code_as_something_in_product_maintenance_list_page() throws Throwable {
		try {
			String value = jsonDataParser.getTestDataMap().get("Appl Code");
			String type = jsonDataParser.getTestDataMap().get("Appl Type");
			webcomPage.selectApplicationCode(value, type);
			reportPass("Selected application code as {" + value + "}");
		} catch (Exception e) {
			reportFail("Failed to select application code");
		}
	}

	@And("^I click on Search button in Product Maintenance List page$")
	public void i_click_on_search_button_in_product_maintenance_list_page() throws Throwable {
		try {
			webcomPage.clickSearchButton();
			reportPass("Clicked on Search Button");
		} catch (Exception e) {
			reportFail("Failed to click on Search button");
		}
	}

	@And("^I click on View link for the product")
	public void i_click_on_view_link_for_the_product_something() throws Throwable {
		try {
			String value = jsonDataParser.getTestDataMap().get("Appl Type");
			webcomPage.clickProductApproveView(value);
			reportPass("Clicked on View Link for the Account type " + value);
		} catch (Exception e) {
			reportFail("Failed to click on view Link");
		}
	}

	@When("^I Select Transfer eligibility of From radio button and To radio buttons$")
	public void i_select_transfer_eligibility_of_from_something_radio_button_and_to_something_radio_buttons_as_no()
			throws Throwable {
		try {
			webcomPage.selectTransferEligibility(jsonDataParser.getTestDataMap().get("From"));
			webcomPage.selectTransferEligibility(jsonDataParser.getTestDataMap().get("To"));
			reportPass("Selected Transfer From & Transfer To radio buttons");
		} catch (Exception e) {
			reportFail("Failed to Select Transfer From & Transfer To radio buttons");
		}
	}

	@And("^I Click on Update button in Set Up product page$")
	public void i_click_on_update_button_in_set_up_product_page() throws Throwable {
		try {
			webcomPage.clickUpdateButton();
			reportPass("Clicked on Update Button");
		} catch (Exception e) {
			reportFail("Failed to click on update button");
		}
	}

	@Then("^I should see the confirmation message \"([^\"]*)\" in Set Up product page$")
	public void i_should_see_the_confirmation_message_something_in_set_up_product_page(String message)
			throws Throwable {
		if (webcomPage.verifyConfirmMsg(message))
			reportPass("The Confirmation message: {" + message + "} is  successfully displayed");
		else {
			reportFail("The Confirmation message: {" + message + "} is not displayed");
		}
	}

	@When("^I click on Logout Link in Webcom application$")
	public void i_click_on_logout_link_in_webcom_application() throws Throwable {
		if (webcomPage.clickLogOut())
			reportPass("Clicked on Logout Link in Webcom Application");
		else
			reportFail("Failed to click on Logout From Webcom");
	}

	@When("^I search customer by field name \"([^\"]*)\" with value of \"([^\"]*)\"$")
	public void i_search_customer_by_field_name_something_with_value_of_something(String searchBy, String userKey)
			throws Throwable {
		try {
			String searchValue = WOLTestBase.envProps.getProperty(userKey);
			if (searchValue.equalsIgnoreCase("enrollment"))
				searchValue = getValueFromRuntimeDataMap("enrollmentUser");
			webcomPage.searchCustomer(searchBy, searchValue);
			reportPass("Searched customer: {" + searchValue + "} details successfully");
		} catch (Exception e) {
			reportHardFail("Failed to Retrieve Customer Details");
		}
	}

	@And("^I click on Ok button in alert pop up$")
	public void i_click_on_ok_button_in_alert_pop_up() throws Throwable {
		try {
			webcomPage.acceptAlert();
			reportPass("Clicked on Ok button in Reset Password alert popup");
		} catch (Exception e) {
			reportFail("Failed to accept alert");
		}
	}

	@Then("^I should get Reset Password value$")
	public void i_should_get_reset_password_value() throws Throwable {

		if (webcomPage.getResetPasswordValue()) {
			reportPass("Retrieved Reset Password value is: {" + runtimeDataMap.get("resetPassword-webcom") + "}");
		} else
			reportFail("Failed to retrieve reset password value");
	}

	@When("I delete the customer by {string} With the value")
	public void i_delete_the_customer_by_With_the_value(String deleteBy) {
		try {
			String value = null;
			if (deleteBy.equalsIgnoreCase("TIN"))
				value = jsonDataParser.getTestDataMap().get("Taxpayer ID#");
			else
				value = jsonDataParser.getTestDataMap().get("CIF");
			webcomPage.deleteCustomer(deleteBy, value);
			reportPass("Deleted customer having {" + deleteBy + "} having value of {" + value
					+ "} in Delete customer in Test environment page");
		} catch (Exception e) {
			reportFail("Failed to delete customer");
		}
	}

	@When("^I delete the customer by \"([^\"]*)\" having the value of \"([^\"]*)\"$")
	public void i_delete_the_customer_by_something_having_the_value_of_something(String deleteBy, String deleteValue)
			throws Throwable {
		try {
			webcomPage.deleteCustomer(deleteBy, deleteValue);
			reportPass("Deleted customer having {" + deleteBy + "} having value of {" + deleteValue
					+ "} in Delete customer in Test environment page");
		} catch (Exception e) {
			reportFail("Failed to delete customer");
		}
	}

	@When("^I delete the customer by \"([^\"]*)\" having the value $")
	public void i_delete_the_customer_by_something_having_the_value_of_something(String deleteBy) throws Throwable {
		try {
			webcomPage.deleteCustomer(deleteBy, jsonDataParser.getTestDataMap().get("CIF"));
			reportPass("Deleted customer having {" + deleteBy + "} having value of {"
					+ jsonDataParser.getTestDataMap().get("CIF") + "} in Delete customer in Test environment page");
		} catch (Exception e) {
			reportFail("Failed to delete customer");
		}
	}

	@Then("^I should see the confirmation message \"([^\"]*)\" in Delete customer in tet environment page$")
	public void i_should_see_the_confirmation_message_something_in_delete_customer_in_tet_environment_page(
			String message) throws Throwable {
		if (webcomPage.verifyDeleteConfirmMsg(message))
			reportPass("The Confirmation message: {" + message + "} is  successfully displayed");
		else {
			reportFail("The Confirmation message: {" + message + "} is not displayed");
		}
	}

	@Then("^I should see the Inactivation confirmation message")
	public void i_should_see_the_inactivation_confirmation_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("Inactive Msg");
		if (webcomPage.verifyInactiveConfirmMsg(message))
			reportPass("The Confirmation message: {" + wolWebUtil.containsText + "} is  successfully displayed");
		else {
			reportFail("The Confirmation message: {" + message + "} is not displayed");
		}
	}

	@Then("^I should see the Activaation confirmation message")
	public void i_should_see_the_activaation_confirmation_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("Active Msg");
		if (webcomPage.verifyActiveConfirmMsg(message))
			reportPass("The Confirmation message: {" + wolWebUtil.containsText + "} is  successfully displayed");
		else {
			reportFail("The Confirmation message: {" + message + "} is not displayed");
		}
	}

	@When("I select the customer channel type as {string}")
	public void i_select_the_customer_channel_type_as(String channel) {
		try {
			webcomPage.selectCustomerChannel(channel);
			reportPass("Selected customer channel type as {" + channel + "} in Enroll new customer page");
		} catch (Exception e) {
			reportFail("Failed to select customer channel type in Enroll new customer page");
		}
	}

	@When("I enter Personal CIF {string} and update details")
	public void i_enter_Personal_CIF_and_update_details(String personalCIF) {
		if (webcomPage.updatePersonalDetails(personalCIF))
			reportPass("Updated Personal CIF {" + personalCIF
					+ "}  and Updated personal Details in Enroll new cutomer page");
		else
			reportFail("Failed to enter Personal CIF number in Enroll new cutomer page");
	}

	@When("I enter Personal CIF and update details")
	public void i_enter_Personal_CIF_and_update_details() {
		if (webcomPage.updatePersonalDetails(jsonDataParser.getTestDataMap().get("CIF")))
			reportPass("Updated Personal CIF {" + jsonDataParser.getTestDataMap().get("CIF")
					+ "}  and Updated personal Details in Enroll new cutomer page");
		else
			reportFail("Failed to enter Personal CIF number in Enroll new cutomer page");
	}

	@When("I enter Business CIF {string} and update details")
	public void i_enter_Business_CIF_and_update_details(String businessCIF) {
		if (webcomPage.updateBusinessDetails(businessCIF))
			reportPass("Updated Business CIF {" + businessCIF
					+ "}  and Updated Business Details in Enroll new customer page");
		else
			reportFail("Failed to enter Business CIF number in Enroll new customer page");
	}

	@When("I update the email ID {string}")
	public void i_update_the_email_ID(String email) {
		if (webcomPage.enterEmail(email))
			reportPass("Updated Email ID {" + email + "}   in Enroll new customer page");
		else
			reportFail("Failed to enter Email in Enroll new customer page");
	}

	@When("I click on Create button")
	public void i_click_on_Create_button() {
		try {
			webcomPage.clickCreateButton();
			reportPass("Clicked on Create button in Enroll new customer page");
		} catch (Exception e) {
			reportFail("Failed to click on Create button");
		}

	}

	@When("I click on Process button")
	public void i_click_on_Process_button() {
		try {
			webcomPage.clickProcessButton();
			reportPass("Clicked on Process button in Enroll new customer page");
		} catch (Exception e) {
			reportFail("Failed to click on Process button");
		}
	}

	@Then("I should get the username value")
	public void i_should_get_the_username_value() {
		if (webcomPage.getUsername())
			reportPass("Retrieved Username value {" + runtimeDataMap.get("newCustomer-webcom")
					+ "} from Enroll new customer Page");
		else
			reportFail("Failed to retriev username value from Enroll new customer Page");
	}

	@Then("I should get the First Login Password value from the confirmation message")
	public void i_should_get_the_First_Login_Password_value_from_the_confirmation_message() {
		if (webcomPage.getLoginPassword())
			reportPass("Retrieved password value {" + runtimeDataMap.get("firstPassword-webcom")
					+ "} from Enroll new customer Page");
		else
			reportFail("Failed to retriev password value from Enroll new customer Page");
	}

	@Then("I get the CIF number for the {string} user")
	public void i_get_the_CIF_number_for_the_user(String userType) {
		String cif = webcomPage.getCIFNumber(userType);
		if (!cif.equals("")) {
			reportPass("CIF number is successfully retrieved " + cif);
		} else {
			reportFail("CIF number is not retrieved ");
		}
	}

	@Then("I should get the message {string} in webcom")
	public void i_should_get_the_message_in_webcom(String message) {
		if (webcomPage.checkForTheMessage(jsonDataParser.getTestDataMap().get(message)))
			reportPass("The Confirmation message: {" + jsonDataParser.getTestDataMap().get(message) + "} is  successfully displayed");
		else {
			reportHardFail("The Confirmation message: {" + jsonDataParser.getTestDataMap().get(message) + "} is not displayed");
		}
	}

	@Then("I enter the retrieved CIF value in related record CIF input box")
	public void i_enter_the_retrieved_CIF_value_in_related_record_CIF_input_box() {
		if (webcomPage.enterCIFNumber())
			reportPass("CIF Number is entered ");
		else {
			reportHardFail("Failed to enter CIF number");
		}
	}

	@Then("I click on the save button")
	public void i_click_on_the_save_button() {
		if (webcomPage.clickOnSaveButton())
			reportPass("Clicked on the save button");
		else {
			reportHardFail("Failed to Click on the save button");
		}
	}

	@When("I click on Customer ID Link")
	public void i_click_on_Customer_ID_Link() {
		if (webcomPage.clickCustomerID())
			reportPass("Clicked on Customer ID link in Enroll New Customer Page");
		else
			reportFail("Failed to Clicked on Customer ID link in Enroll New Customer Page");
	}

	@When("I should see the appropriate DOB value")
	public void i_should_see_the_appropriate_DOB_value() {
		if (webcomPage.verifyEquifaxDOBValue())
			reportPass("The DOB value {" + testDataMap.get("Date of Birth")
					+ "} is successfully Displayed in Equifax Authentication Queue Page");
		else if (webcomPage.verifyEnrollmentDOBValue())
			reportPass("The DOB value {" + testDataMap.get("Date of Birth")
					+ "} is successfully Displayed in Enrollment Queue Page");
		else
			reportFail("The DOB value {" + testDataMap.get("Date of Birth")
					+ "} is not Displayed in Equifax Authentication Queue Page");
	}

	@When("I should see the correct Pass Reason Codes")
	public void i_should_see_the_correct_Pass_Reason_Codes() {
		if (webcomPage.verifyEquifaxReasonCodes())
			reportPass("The Reason Code is successfully Displayed in Equifax Authentication Queue Page");
		else
			reportFail("The Reason Code is not Displayed in Equifax Authentication Queue Page");
	}

	@When("I should see the correct Fail Reason Codes")
	public void i_should_see_the_correct_Fail_Reason_Codes() {
		if (webcomPage.verifyEquifaxFailReasonCodes())
			reportPass("The Reason Code is successfully Displayed in Equifax Authentication Queue Page");
		else
			reportFail("The Reason Code is not Displayed in Equifax Authentication Queue Page");
	}

	@When("I select the Product name as {string} in Product Maintenance List page")
	public void i_select_the_Product_name_as_in_Product_Maintenance_List_page(String productType) {
		if (webcomPage.selectProductType(productType))
			reportPass("Product Type selected as " + productType);
		else {
			reportHardFail("Unable to select the Product Type as " + productType);
		}
	}

	@Then("I verify the Product name as {string} in Product Maintenance List page")
	public void i_verify_the_Product_name_as_in_Product_Maintenance_List_page(String productType) {
		if (webcomPage.verifyProductType(productType))
			reportPass("Product Type displayed as " + productType);
		else {
			reportHardFail("Unable to display the Product Type as " + productType);
		}
	}

	@When("I update the value of the label View Deposit Details as No")
	public void i_update_the_value_of_the_label_View_Deposit_Details_as_No() {
		if (webcomPage.selectNoForDepositDetails())
			reportPass("Select the No option for View Deposit Details");
		else
			reportFail("Unable to select the No option for View Deposit Details");
	}

	@Then("I verify the message as {string}")
	public void i_verify_the_message_as(String message) {
		if (webcomPage.verifyProductUpdateMessage(jsonDataParser.getTestDataMap().get(message)))
			reportPass("Product Type {" + jsonDataParser.getTestDataMap().get(message) + "} displayed");
		else {
			reportHardFail("Unable to display the {" + jsonDataParser.getTestDataMap().get(message) + "}");
		}
	}

	@When("I update the value of the label View Deposit Details as Yes")
	public void i_update_the_value_of_the_label_View_Deposit_Details_as_Yes() {
		if (webcomPage.selectYesForDepositDetails())
			reportPass("Select the Yes option for View Deposit Details ");
		else
			reportFail("Unable to select the Yes option for View Deposit Details");
	}

	@Then("I verify the {string} field {string} should display for Webster {string}")
	public void i_verify_the_field_should_display_for_Webster(String depositDetails, String value, String account) {
		if (webcomPage.verifyViewDepositDetailsFieldAndValue(jsonDataParser.getTestDataMap().get(depositDetails), value, jsonDataParser.getTestDataMap().get(account)))
			reportPass(jsonDataParser.getTestDataMap().get(depositDetails) + " field displayed with " + value + " for " + jsonDataParser.getTestDataMap().get(account) + " account");
		else
			reportFail(jsonDataParser.getTestDataMap().get(depositDetails) + " field not displayed with " + value + " for " + jsonDataParser.getTestDataMap().get(account) + " account");
	}

	@Then("Verify column names from Deposit details page")
	public void verify_column_names_from_Deposit_details_page() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyHeader1ColumnNamesInDepositDetails(selectValues))
			reportPass("Verified First Header column names successfully");
		else
			reportFail("Failed to Verify column names");
	}

	@Then("I verify the Instructions message as {string}")
	public void i_verify_the_Instructions_message_as(String message) {
		if (webcomPage.verifyInstructionsMessage(jsonDataParser.getTestDataMap().get(message)))
			reportPass("{" + (jsonDataParser.getTestDataMap().get(message)) + "} message is displayed");
		else
			reportFail("Unable to display " + "{" + (jsonDataParser.getTestDataMap().get(message)) + "} message");
	}

	@Then("I verify the Deposit details header message as {string}")
	public void i_verify_the_Deposit_details_header_message_as(String message) {
		if (webcomPage.verifyDepositDetailsHeaderMessage(jsonDataParser.getTestDataMap().get(message)))
			reportPass("{" + jsonDataParser.getTestDataMap().get(message) + "} message is displayed");
		else
			reportFail("Unable to display {" + jsonDataParser.getTestDataMap().get(message) + "} message");
	}

	@Then("Verify second header column names from Deposit details page")
	public void verify_second_header_column_names_from_Deposit_details_page() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyHeader2ColumnNamesInDepositDetails(selectValues))
			reportPass("Verified Second Header column names successfully");
		else
			reportFail("Failed to Verify Second Header column names");
	}

	@Then("I verify the below buttons should be displayed in top of the Page")
	public void i_verify_the_below_buttons_should_be_displayed_in_top_of_the_Page() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyTopLinksInAuditTrailPage(selectValues))
			reportPass("Verified Links successfully in Top of the Page");
		else
			reportFail("Failed to Verify Links in Top of the Page");
	}

	@Then("I verify the {string} count should display in top of the Page")
	public void i_verify_the_count_should_display_in_top_of_the_Page(String text) {
		if (webcomPage.verifyTotalRecordsTextInTopPage(jsonDataParser.getTestDataMap().get(text)))
			reportPass(webcomPage.totalRecodsCount + "  is displayed in Top of the Page");
		else
			reportFail(webcomPage.totalRecodsCount + "  is not displayed in Top of the Page");
	}

	@Then("I verify the below column names should be displayed")
	public void i_verify_the_below_column_names_should_be_displayed() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyColumnNamesInAuditTrailPage(selectValues))
			reportPass("Verified Audit Trail Column names successfully");
		else
			reportFail("Failed to Verify Audit Trail Column names");
	}

	@Then("I verify the below column values should be displayed")
	public void i_verify_the_below_column_values_should_be_displayed() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyColumnValuesInAuditTrailPage(selectValues))
			reportPass("Verified Audit Trail Column Values successfully");
		else
			reportFail("Failed to Verify Audit Trail Column Values");
	}

	@Then("I verify the {string} count should display in bottom of the Page")
	public void i_verify_the_count_should_display_in_bottom_of_the_Page(String text) {
		if (webcomPage.verifyTotalRecordsTextInBottomPage(jsonDataParser.getTestDataMap().get(text)))
			reportPass(webcomPage.totalRecodsCount + "  is displayed in Bottom of the Page");
		else
			reportFail(webcomPage.totalRecodsCount + "  is not displayed in Bottom of the Page");
	}

	@Then("I verify the below buttons should be displayed in bottom of the Page")
	public void i_verify_the_below_buttons_should_be_displayed_in_bottom_of_the_Page() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyBottomLinksInAuditTrailPage(selectValues))
			reportPass("Verified Links successfully in Bottom of the Page");
		else
			reportFail("Failed to Verify Links in Bottom of the Page");
	}

	@Then("I verify the transaction date in Transaction table")
	public void i_verify_the_transaction_date_in_Transaction_table() {
		if (webcomPage.verifyTransactioDateInAuditTrailPage())
			reportPass("Transaction date " + webcomPage.auditTrailTransDate + " is displayed");
		else
			reportFail("Transaction date " + webcomPage.auditTrailTransDate + " is not displayed");
	}

	@Then("I verify the below column names should be displayed in the transaction table")
	public void i_verify_the_below_column_names_should_be_displayed_in_the_transaction_table() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyColumnNamesInDepositDetailsPage(selectValues))
			reportPass("Verified Transaction table Column names successfully");
		else
			reportFail("Failed to Verify Transaction table Column names");
	}

	@Then("I verify the below column values should be displayed in the transaction table")
	public void i_verify_the_below_column_values_should_be_displayed_in_the_transaction_table() {
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyColumnValuesInDepositDetailsPage(selectValues))
			reportPass("Verified Transaction table Column values successfully");
		else
			reportFail("Failed to Verify Transaction table Column values");
	}

	@Then("I verify the below column names should be displayed in the Accounts table")
	public void i_verify_the_below_column_names_should_be_displayed_in_the_Accounts_table() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyColumnValuesInDepositDetailsPage(selectValues))
			reportPass("Verified Accounts table Columns successfully");
		else
			reportFail("Failed to Verify Accounts table Columns");
	}

	@Then("I verify the below column values should be displayed in the Accounts table")
	public void i_verify_the_below_column_values_should_be_displayed_in_the_Accounts_table() {
		selectValues =  new ArrayList<String>();
		selectValues.addAll(jsonDataParser.getTestDataMap().values());
		if (webcomPage.verifyAccsColumnValuesInDepositDetailsPage(selectValues))
			reportPass("Verified Accounts table Column values successfully");
		else
			reportFail("Failed to Verify Accounts table Column values");
	}

	@Then("I verify the {string} is {string} in Webcom View Deposit Details Preferences page")
	public void i_verify_the_is_in_Webcom_View_Deposit_Details_Preferences_page(String account, String status) {
		if (webcomPage.verifyAccountEnrolledOrUnEnrolledInWebcom(jsonDataParser.getTestDataMap().get(account), status))
			reportPass(jsonDataParser.getTestDataMap().get(account) + " account is " + status + " in Webcom Deposit details page");
		else
			reportFail(jsonDataParser.getTestDataMap().get(account) + " account is not in " + status + " in Webcom Deposit details page");
	}

	@Then("I verify the {string} is {string} in Webcom Deposit Details page")
	public void i_verify_the_is_in_Webcom_Deposit_Details_page(String account, String status) {
		if (webcomPage.verifyAccountCheckBoxStatusInWebcom((jsonDataParser.getTestDataMap().get(account)), status))
			reportPass(jsonDataParser.getTestDataMap().get(account) + " account is " + status + " in Webcom Deposit details page");
		else
			reportFail(jsonDataParser.getTestDataMap().get(account) + " account is not in " + status + " in Webcom Deposit details page");
	}

	@When("I click on update button in Webcom Deposit details page")
	public void i_click_on_update_button_in_Webcom_Deposit_details_page() {
		if (webcomPage.clickOnUpdateButton())
			reportPass("Clicked on Update button in Webcom Deposit details page");
		else
			reportFail("Unable to click on Update button in Webcom Deposit details page");
	}

	@When("I Update SSN for the user")
	public void i_Update_SSN_for_the_user() {
		if (webcomPage.enterSsnValue(jsonDataParser.getTestDataMap().get("SSN")))
			reportPass("Entered SSN Value in Customer Details Page");
		else
			reportFail("Failed to Enter SSN Value in Customer Details Page");
		webcomPage.clickSaveButton();

	}

	@Then("I should see the newly added user")
	public void i_should_see_the_newly_added_user() {
		if (webcomPage.verifyUserAuth(jsonDataParser.getTestDataMap().get("SSN")))
			reportPass("The newly added user existed in Manage Authorized Access page");
		else
			reportFail("The newly added user is not existed in Manage Authorized Access page");
	}

	@When("I get user name in manual Add account page")
	public void i_get_user_name_in_manual_Add_account_page() {
		try {
			webcomPage.getUserName(getValueFromRuntimeDataMap("addNewWOLUser"));
			reportPass("Retrieved the user details in Manual Add Account page");
		} catch (Exception e) {
			reportFail("Failed to Retrieve the user details in Manual Add Account page");
		}

	}

	@When("I get user name in manual Add account page for enrollment in webcom")
	public void i_get_user_name_in_manual_Add_account_page_Webcom() {
		try {
			webcomPage.getUserName(getValueFromRuntimeDataMap("newCustomer-webcom"));
			reportPass("Retrieved the user details in Manual Add Account page");
		} catch (Exception e) {
			reportFail("Failed to Retrieve the user details in Manual Add Account page");
		}

	}

	@When("I get user name in manual Add account page for enrollment")
	public void i_get_user_name_in_manual_Add_account_page_enrollment() {
		try {
			webcomPage.getUserName(getValueFromRuntimeDataMap("enrollmentUser"));
			reportPass("Retrieved the user details in Manual Add Account page");
		} catch (Exception e) {
			reportFail("Failed to Retrieve the user details in Manual Add Account page");
		}

	}

	@When("I should see the account relationship code as {string} for the account number")
	public void i_should_see_the_account_relationship_code_as_for_the_account_number(String code) {
		if (webcomPage.verifyRelationshipCode(code, jsonDataParser.getTestDataMap().get("Account Number")))
			reportPass("The account number {" + jsonDataParser.getTestDataMap().get("Account Number")
					+ "} is added with the signor relationship code {" + code + "}");
		else
			reportFail("The account number {" + jsonDataParser.getTestDataMap().get("Account Number")
					+ "} is not added with the signor relationship code {" + code + "}");
	}

	@Then("I verify the confirmation message as {string}")
	public void i_verify_the_confirmation_message_as(String message) {
		if (webcomPage.verifyDepositDetailsMsg(jsonDataParser.getTestDataMap().get(message)))
			reportPass("Confirmation {" + jsonDataParser.getTestDataMap().get(message) + "} message displayed");
		else {
			reportHardFail("Unable to display the {" + jsonDataParser.getTestDataMap().get(message) + "} message");
		}
	}

	@Then("I verify the Statement Period as {string}")
	public void i_verify_the_Statement_Period_as(String noDates) {
		if (webcomPage.verifyStmtPeriodDateRange(noDates))
			reportPass("Statement Range {" + noDates + "} is displayed");
		else {
			reportFail("Unable to display the {" + noDates + "}");
		}
	}

	@When("I click on View Selected Statement button")
	public void i_click_on_View_Selected_Statement_button() {
		if (webcomPage.clickOnStmtButton())
			reportPass("Clicked on View Selected Statement Button");
		else {
			reportFail("Failed to click on View Selected Statement button");
		}
	}

	@Then("I verify the {string} text should display in Statements Page")
	public void i_verify_the_text_should_display_in_Statements_Page(String message) {
		if (webcomPage.verifyAccStmtImportantMsg(message))
			reportPass("Important {" + message + "} message displayed");
		else {
			reportFail("Unable to display the {" + message + "} message");
		}
	}

	@Then("I verify the {string} important message should display")
	public void i_verify_the_important_message_should_display(String message) {
		if (webcomPage.verifyAccNoStmtMsg(message))
			reportPass("{" + message + "} message displayed");
		else {
			reportFail("Unable to display the {" + message + "} message");
		}
	}

	@Then("I verify the {string} section displayed")
	public void i_verify_the_section_displayed(String message) {
		if (webcomPage.verifyAccNoStmtImpSection(message))
			reportPass("{" + message + "} message displayed");
		else {
			reportFail("Unable to display the {" + message + "} message");
		}
	}

	@When("I select the N\\/A Account in statement page")
	public void i_select_the_N_A_Account_in_statement_page() {
		if (webcomPage.selectAccFromDropdownList())
			reportPass("Account Number " + (testDataMap.get("SelectN/AAccount")) + " is selected");
		else
			reportFail("Account Number " + (testDataMap.get("SelectN/AAccount")) + " is not selected");
	}

	@When("I enter Title of the message")
	public void i_enter_Title_of_the_message() {
		if (!webcomPage.enterEmergencyMsgTitle().equals(""))
			reportPass("Message title { " + (testDataMap.get("EmergencyMessageTitle")) + " } is entered");
		else
			reportFail("Message title { " + (testDataMap.get("EmergencyMessageTitle")) + " } is not entered");
	}

	@When("I enter the message body")
	public void i_enter_the_message_body() {
		if (!webcomPage.enterEmergencyMsgBody().equals(""))
			reportPass("Message body { " + (testDataMap.get("EmergencyMessageBody")) + " } is entered");
		else
			reportFail("Message body { " + (testDataMap.get("EmergencyMessageBody")) + " }is not entered");
	}

	@When("I enter Start date")
	public void i_enter_Start_date() {
		if (webcomPage.enterMessageStartDate())
			reportPass("Start date is entered");
		else
			reportFail("Start date is not entered");
	}

	@When("I enter End date")
	public void i_enter_End_date() {
		if (webcomPage.enterMessageEndDate())
			reportPass("End date is entered");
		else
			reportFail("End date is not entered");
	}

	@When("I select the Target as Private option")
	public void i_select_the_Target_as_Private_option() {
		if (webcomPage.clickOnPrivateChkBox())
			reportPass("Private option selected");
		else
			reportFail("Unable to select the Private option");
	}

	@When("I click on Submit button")
	public void i_click_on_Submit_button() {
		if (webcomPage.clickOnStmtButton())
			reportPass("Clicked on Submit Button");
		else
			reportFail("Failed to click on Submit button");
	}

	@When("I capture the Account number and click on the Account number link")
	public void i_capture_the_Account_number_and_click_on_the_Account_number_link() {
		if (!webcomPage.captureAccountNumber().equals(""))
			reportPass("Account number { " + webcomPage.accountNumber + " } captured and clicked on { "
					+ webcomPage.accountNumber + " } Account number link");
		else
			reportFail("Account number { " + webcomPage.accountNumber + " } not captured and unable to click on { "
					+ webcomPage.accountNumber + " } Account number link");
	}

	@Then("I verify the Account number")
	public void i_verify_the_Account_number() {
		if (webcomPage.verifyAccountDetails())
			reportPass("Account number { " + webcomPage.accountNumber + " } is displayed");
		else
			reportFail("Message body { " + webcomPage.accountNumber + " } is not displayed");
	}

	@Then("I verify the Current balance")
	public void i_verify_the_Current_balance() {
		if (webcomPage.verifyCurrentBalance())
			reportPass("Current Balance { " + webcomPage.currentBalance + " } is displayed");
		else
			reportFail("Current Balance { " + webcomPage.currentBalance + " } is not displayed");
	}

	@Then("I verify the Available balance")
	public void i_verify_the_Available_balance() {
		if (webcomPage.verifyAvailableBalance())
			reportPass("Available Balance { " + webcomPage.availableBalance + " } is displayed");
		else
			reportFail("Available Balance { " + webcomPage.availableBalance + " } is not displayed");
	}

}
