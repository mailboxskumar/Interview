package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.pages.EnrollmentPage;
import com.wb.wol_web.pages.WebcomPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EnrollmentSteps extends ObjectBase {

	EnrollmentPage enrollmentPage = new EnrollmentPage();
	WebcomPage webcomPage = new WebcomPage();

	@When("^I click on Enroll link in WOL Homepage$")
	public void i_click_on_enroll_link_in_wol_homepage() {
		try {
			enrollmentPage.clickOnEnrollLink();
			reportPass("Clicked on Enroll Link");
		} catch (Exception e) {
			reportHardFail("Failed to click on Enroll Link");
		}
	}

	@When("^I select \"([^\"]*)\" as a enrollment channel$")
	public void i_select_something_as_a_enrollment_channel(String profileType) {
		try {
			enrollmentPage.clickOnProfileType(profileType);
			reportPass("Selected profile type as a " + profileType);
		} catch (Exception e) {
			reportFail("Failed to select profile type");
		}
	}

	@When("^I enter Personal Information$")
	public void i_enter_personal_information() throws Exception {
		if (enrollmentPage.enterUserPersonalInfo(jsonDataParser.getTestDataMap()))
			reportPass("Entered personal Information of a user to enroll into Webster Online Banking");
		else
			reportFail("Failed to enter personal Information of a user to enroll into Webster Online Banking");
	}

	@When("^I click on continue button in enrollment functionality$")
	public void i_click_on_continue_button_in_enrollment_functionality() {
		try {
			enrollmentPage.clickOnContinueButton();
			reportPass("Clicked on Continue button");
		} catch (Exception e) {
			reportHardFail("Failed to click on Continue button");
		}
	}

	@When("^I select all the answers for questionnaire$")
	public void i_select_all_the_answers_for_questionnaire() throws Exception {
		try {
			enrollmentPage.selectEmulatorQuestions(jsonDataParser.getTestDataMap());
			reportPass("Selected answers for emulator questions of a user to enroll into Webster Online Banking");
		} catch (Exception e) {
			reportFail("Failed to select emulator questions");
		}
	}

	@When("^I enter user credentials to enroll$")
	public void i_enter_user_credentials_to_enroll() throws Exception {
		if (enrollmentPage.enterUserCredentails(jsonDataParser.getTestDataMap()))
			reportPass("Entered credentials of a user to enroll into Webster Online Banking");
		else
			reportFail("Failed to enter User credentials");
	}

	@When("^I select all the disclosures$")
	public void i_select_all_the_disclosures() throws Exception {
		if (enrollmentPage.selectDisclosures())
			reportPass("Selected all the disclosures to enroll a user");
		else
			reportFail("Failed to select disclosures");
	}

	@Then("^I should navigate to \"([^\"]*)\" Page in enrollment functionality$")
	public void i_should_navigate_to_something_page_in_enrollment_functionality(String message) throws Exception {
		if (enrollmentPage.verifyEnrollmentPageTitles(message))
			reportPass("The Page : {" + message + "} is successfully displayed");
		else
			reportFail("The Page : {" + message + "} is not displayed");
	}

	@And("^I enter Driving License information$")
	public void i_enter_driving_license_information() throws Throwable {
		if (enrollmentPage.enterUserDriverLicenseInfo(jsonDataParser.getTestDataMap()))
			reportPass("Entered Driver License Information of a user to enroll into Webster Online Banking");
		else
			reportFail("Failed to enter driver license information");
	}

	@And("^I should see all the entered details in verification page$")
	public void i_should_see_all_the_entered_details_in_verification_page() throws Exception {
		enrollmentPage.getEnrollmentDetails();
		if (enrollmentPage.verifyEnrollmentDetails())
			reportPass("The Entered Details are {" + enrollmentPage.enrollDetails + "} successfully displayed ");
		else
			reportFail("The Entered Details are {" + enrollmentPage.enrollDetails + "} not displayed ");
	}

	@And("^I should see the Enrollment confirmation message \"([^\"]*)\"$")
	public void i_should_see_the_enrollment_confirmation_message_something(String message) throws Exception {
		if (enrollmentPage.verifyEnrollmentConfirmationMsg(message))
			reportPass("The confirmation message : {" + message + "} is successfully displayed");
		else
			reportFail("The confirmation message : {" + message + "} is not displayed");
	}

	@And("^I should see all the details of the Enrollment confirmation$")
	public void i_should_see_all_the_details_of_the_enrollment_confirmation() throws Exception {
		enrollmentPage.getEnrollmentDetails();
	}

	@And("^I enter Account information$")
	public void i_enter_account_information() throws Exception {
		try {
			enrollmentPage.enterUserAccountInfo(jsonDataParser.getTestDataMap());
			reportPass("Entered Account Information of a user to enroll into Webster Online Banking");
		} catch (Exception e) {
			reportFail("Failed to enter account information");
		}
	}

	@When("^I entered all the business information$")
	public void i_entered_all_the_business_information() throws Exception {
		if (enrollmentPage.enterBusinessInformation(jsonDataParser.getTestDataMap()))
			reportPass("Entered Business Information of a user to enroll");
		else
			reportFail("Failed to enter Business information ");
	}

	@When("I click on View Account Balances Link")
	public void i_click_on_View_Account_Balances_Link() {
		if (enrollmentPage.clickOnAcctBalancesLink())
			reportPass("Clicked on View Account Balances Link");
		else
			reportFail("Failed to Click on View Account Balances Link");
	}

	@When("I Enter newly Enrolled username")
	public void i_Enter_newly_Enrolled_username() {
		if (enrollmentPage.enterUserName())
			reportPass("Entered newly enrolled username {" + enrollmentPage.user + "}");
		else
			reportFail("Failed to enter newly entered username");
	}

	@Then("I should see the warning message")
	public void i_should_see_the_warning_message() {
		if (enrollmentPage.verifyWarningMessage(jsonDataParser.getTestDataMap()))
			reportPass(
					"The message : {" + jsonDataParser.getTestDataMap().get("Message") + "} is successfully displayed");
		else
			reportFail("The message : {" + jsonDataParser.getTestDataMap().get("Message") + "} is not displayed");
	}

	@When("I click Here Link")
	public void i_click_Here_Link() {
		try {
			enrollmentPage.clickOnHereLink();
			reportPass("Clicked on Click Here Link");
		} catch (Exception e) {
			reportFail("Failed to Click on Click Here Link");
		}
	}

	@Then("I should be in Business Checking Accounts Page")
	public void i_should_be_in_Business_Checking_Accounts_Page() {
		if (enrollmentPage.verifyPageHeader(jsonDataParser.getTestDataMap()))
			reportPass("The Page : {" + jsonDataParser.getTestDataMap().get("Title") + "} is successfully displayed");
		else
			reportFail("The Page : {" + jsonDataParser.getTestDataMap().get("Title") + "} is not displayed");
	}

	@Then("I should see the error message in Enter Personal Information Page")
	public void i_should_see_the_error_message_in_Enter_Personal_Information_Page() {
		if (enrollmentPage.verifyEnrollmentErrMessage(jsonDataParser.getTestDataMap()))
			reportPass("The Error message : {" + jsonDataParser.getTestDataMap().get("Message")
					+ "} is successfully displayed");
		else
			reportFail("The Error message : {" + jsonDataParser.getTestDataMap().get("Message") + "} is not displayed");
	}

	@Then("I should see the Page Level Error Message in Enter Personal Information Page")
	public void i_should_see_the_Page_Level_Error_Message_in_Enter_Personal_Information_Page() {
		if (enrollmentPage.verifyPageErrMessage(jsonDataParser.getTestDataMap()))
			reportPass("The Error message : {" + jsonDataParser.getTestDataMap().get("Page Error")
					+ "} is successfully displayed");
		else
			reportFail(
					"The Error message : {" + jsonDataParser.getTestDataMap().get("Page Error") + "} is not displayed");
	}

	@Then("I should see the Existing User error message in Enter Personal Information Page")
	public void i_should_see_the_Existing_User_error_message_in_Enter_Personal_Information_Page() {
		if (enrollmentPage.verifyAlreadyEnrollErrMessage(jsonDataParser.getTestDataMap()))
			reportPass("The Existing User Error message : {" + jsonDataParser.getTestDataMap().get("Message")
					+ "} is successfully displayed");
		else
			reportFail("The Existing User Error message : {" + jsonDataParser.getTestDataMap().get("Message")
					+ "} is not displayed");
	}

	@Then("I should see the step Names in Enter Personal Information Page")
	public void i_should_see_the_step_Names_in_Enter_Personal_Information_Page() {
		if (enrollmentPage.verifyStepNames(jsonDataParser.getTestDataMap()))
			reportPass("The Step Names : {" + jsonDataParser.getTestDataMap().get("Step Name")
					+ "} is successfully displayed");
		else
			reportFail("The Step Names : {" + jsonDataParser.getTestDataMap().get("Step Name") + "} is not displayed");
	}

	@Then("I should see the Note Messages in Enter Personal Information Page")
	public void i_should_see_the_Note_Messages_in_Enter_Personal_Information_Page() {
		if (enrollmentPage.verifyStepNames(jsonDataParser.getTestDataMap()))
			reportPass("The Note contents : {" + jsonDataParser.getTestDataMap().get("Note")
					+ "} is successfully displayed");
		else
			reportFail("The Note Contents : {" + jsonDataParser.getTestDataMap().get("Note") + "} is not displayed");
	}

	@Then("I should see the Note Messages in Authrorize Identity Check Page")
	public void i_should_see_the_Note_Messages_in_Authrorize_Identity_Check_Page() {
		if (enrollmentPage.verifyAuthNote(jsonDataParser.getTestDataMap()))
			reportPass("The Note content : {" + jsonDataParser.getTestDataMap().get("Note")
					+ "} is successfully displayed in Authrorize Identity Check Page");
		else
			reportFail("The Note Content : {" + jsonDataParser.getTestDataMap().get("Note")
					+ "} is not displayed in Authrorize Identity Check Page");
	}

	@Then("I should see the content message one in Authrorize Identity Check Page")
	public void i_should_see_the_content_message_one_in_Authrorize_Identity_Check_Page() {
		if (enrollmentPage.verifyAuthContentMsgOne(jsonDataParser.getTestDataMap()))
			reportPass("The content : {" + jsonDataParser.getTestDataMap().get("Content One")
					+ "} is successfully displayed in Authrorize Identity Check Page");
		else
			reportFail("The Content : {" + jsonDataParser.getTestDataMap().get("Content One")
					+ "} is not displayed in Authrorize Identity Check Page");
	}

	@Then("I should see the content message two in Authrorize Identity Check Page")
	public void i_should_see_the_content_message_two_in_Authrorize_Identity_Check_Page() {
		if (enrollmentPage.verifyAuthContentMsgTwo(jsonDataParser.getTestDataMap()))
			reportPass("The content : {" + jsonDataParser.getTestDataMap().get("Content Two")
					+ "} is successfully displayed in Authrorize Identity Check Page");
		else
			reportFail("The Content : {" + jsonDataParser.getTestDataMap().get("Content Two")
					+ "} is not displayed in Authrorize Identity Check Page");
	}

	@Then("I should see the content in Verify Information Page")
	public void i_should_see_the_content_in_Verify_Information_Page() {
		if (enrollmentPage.verifyInfoContentMsg(jsonDataParser.getTestDataMap()))
			reportPass("The content : {" + jsonDataParser.getTestDataMap().get("Verify Content")
					+ "} is successfully displayed in Verify Information Page");
		else
			reportFail("The Content : {" + jsonDataParser.getTestDataMap().get("Verify Content")
					+ "} is not displayed in Verify Information Page");
	}

	@Then("I Should see the content in Customer Authentication Page")
	public void i_Should_see_the_content_in_Customer_Authentication_Page() {
		if (enrollmentPage.verifyCustAuthContentMsg(jsonDataParser.getTestDataMap()))
			reportPass("The content : {" + jsonDataParser.getTestDataMap().get("Content")
					+ "} is successfully displayed in Customer Authentication Page");
		else
			reportFail("The Content : {" + jsonDataParser.getTestDataMap().get("Content")
					+ "} is not displayed in Customer Authentication Page");
	}

	@When("I click on OK Link")
	public void i_click_on_OK_Link() {
		try {
			enrollmentPage.clickOnOKLink();
			reportPass("Clicked on Ok Link in Customer Authentication Page");
		} catch (Exception e) {
			reportFail("Failed to click on OK Link in Customer Authentication Page");
		}
	}

	@Then("I should navigate to WOL HomePage")
	public void i_should_navigate_to_WOL_HomePage() {
		if (new CommonPage().isUserNameDisplayed())
			reportPass("Navigated to:{ " + System.getProperty("environment") + " } environment URL in: { " + browserName
					+ " } browser");
		else
			reportHardFail("ERROR : There is some issue in loading { " + System.getProperty("environment")
					+ " } url or Exception in Code. Please check and re-run the script.");
	}

	@Then("I should see the All the error message in Enter Personal Information Page")
	public void i_should_see_the_All_the_error_message_in_Enter_Personal_Information_Page() {
		if (enrollmentPage.verifyMissingInfoErrMsgs(jsonDataParser.getTestDataMap()))
			reportPass("The Error Messages : {" + jsonDataParser.getTestDataMap().get("Message")
					+ "} is successfully displayed");
		else
			reportFail(
					"The Error Messages : {" + jsonDataParser.getTestDataMap().get("Message") + "} is not displayed");
	}

	@Then("I should see the error message in Complete Identity Questionnaire page")
	public void i_should_see_the_error_message_in_Complete_Identity_Questionnaire_page() {
		if (enrollmentPage.verifyQuestionnaireErr(jsonDataParser.getTestDataMap()))
			reportPass("The Error Message : {" + jsonDataParser.getTestDataMap().get("Questionnaire")
					+ "} is successfully displayed");
		else
			reportFail("The Error Message : {" + jsonDataParser.getTestDataMap().get("Questionnaire")
					+ "} is not displayed");
	}

	@When("I click on Edit button in verify Information Page")
	public void i_click_on_Edit_button_in_verify_Information_Page() {
		try {
			enrollmentPage.clickOnEditLink();
			reportPass("Clicked on Edit Link in Verify Information Page");
		} catch (Exception e) {
			reportFail("Failed to click on Edit Link in Verify Information Page");
		}
	}

	@Then("I should see the tooltip message in enrollment functionality")
	public void i_should_see_the_tooltip_message_in_enrollment_functionality() {
		if (enrollmentPage.verifyPasswordTooltip(jsonDataParser.getTestDataMap()))
			reportPass("The Tooltip Message : {" + jsonDataParser.getTestDataMap().get("Tooltip")
					+ "} is successfully displayed");
		else
			reportFail(
					"The Tooltip Message : {" + jsonDataParser.getTestDataMap().get("Tooltip") + "} is not displayed");
	}

	@Then("I should see the contents in Agree to Disclosures page")
	public void i_should_see_the_contents_in_Agree_to_Disclosures_page() {
		if (enrollmentPage.verifyInfoContentMsgs(jsonDataParser.getTestDataMap()))
			reportPass("The Content : {" + jsonDataParser.getTestDataMap().get("Verify Content")
					+ "} is successfully displayed");
		else
			reportFail(
					"The Content : {" + jsonDataParser.getTestDataMap().get("Verify Content") + "} is not displayed");
	}

	@Then("I should see the Note Message in Re-Enter your Business Account Information Page")
	public void i_should_see_the_Note_Message_in_Re_Enter_your_Business_Account_Information_Page() {
		if (enrollmentPage.verifyReEnterAccountNote(jsonDataParser.getTestDataMap()))
			reportPass("The Note content : {" + jsonDataParser.getTestDataMap().get("Note")
					+ "} is successfully displayed");
		else
			reportFail("The Note Content : {" + jsonDataParser.getTestDataMap().get("Note") + "} is not displayed");
	}

	@When("I click on Return Link")
	public void i_click_on_Return_Link() {
		try {
			enrollmentPage.clickOnReturnLink();
			reportPass("Clicked on Return to WebsterOnline Services Link ");
		} catch (Exception e) {
			reportFail("Failed to click on Return to WebsterOnline Services Link ");
		}
	}

	@Then("I should see the Note Message in Start Page")
	public void i_should_see_the_Note_Message_in_Start_Page() {
		if (enrollmentPage.verifyStartPageNote(jsonDataParser.getTestDataMap()))
			reportPass("The Content : {" + jsonDataParser.getTestDataMap().get("Note") + "} is successfully displayed");
		else
			reportFail("The Content : {" + jsonDataParser.getTestDataMap().get("Note") + "} is not displayed");
	}

	@When("I should see the SSN value as {string}")
	public void i_should_see_the_SSN_value_as(String ssn) {
		if (ssn.equalsIgnoreCase(""))
			ssn = enrollmentPage.ssn;
		if (webcomPage.verifyEquifaxSSNValue(ssn))
			reportPass("The SSN value {" + ssn + "} is successfully Displayed in Equifax Authentication Queue Page");
		else if (webcomPage.verifyEnrollmentSSNValue(ssn))
			reportPass("The SSN value {" + ssn + "} is successfully Displayed in Enrollment Queue Page");
		else
			reportFail("The SSN value {" + ssn + "} is not Displayed in Equifax Authentication Queue Page");
	}

	@When("I click on view Link for the value of SSN {string}")
	public void i_click_on_view_Link_for_the_value_of_SSN(String ssn) {
		try {
			if (ssn.equalsIgnoreCase(""))
				ssn = enrollmentPage.ssn;
			webcomPage.clickEnrollmentView(ssn);
			reportPass("Clicked on View link in Equifax Authentication Queue Page");
		} catch (Exception e) {
			reportFail("Failed to click on View link in Equifax Authentication Queue Page");
		}
	}

}
