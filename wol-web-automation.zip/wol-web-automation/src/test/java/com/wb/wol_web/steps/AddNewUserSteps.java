package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddNewUserPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddNewUserSteps extends ObjectBase {

	AddNewUserPage addNewUserPage = new AddNewUserPage();

	@Then("I should be in {string} page in Authorized Access functionality")
	public void i_should_be_in_page_in_Authorized_Access_functionality(String message) {
		if (addNewUserPage.verifyPageTitle(message))
			reportPass("The Page : {" + message + "} is successfully displayed");
		else
			reportFail("The Page : {" + message + "} is not displayed");
	}

	@Then("I should not see the Authorized Access Agreement")
	public void i_should_not_see_the_Authorized_Access_Agreement() {
		if (!addNewUserPage.verifyDisclosure())
			reportPass("The Authorized Access Agreement Disclosure Link is not displayed");
		else
			reportFail("The Authorized Access Agreement Disclosure Link is displayed");
	}

	@Then("I should see the Authorized Access Agreement")
	public void i_should_see_the_Authorized_Access_Agreement() {
		if (addNewUserPage.verifyDisclosure())
			reportPass("The Authorized Access Agreement Disclosure Link is successfully displayed");
		else
			reportFail("The Authorized Access Agreement Disclosure Link is not displayed");
	}

	@When("I click on continue button in Authorized Access functionality")
	public void i_click_on_continue_button_in_Authorized_Access_functionality() {
		if (addNewUserPage.clickOnContinueButton())
			reportPass("Clicked on continue button");
		else
			reportHardFail("Failed to click on continue button");
	}

	@Then("I should see the Page level error in Authorized Access functionality")
	public void i_should_see_the_Page_level_error_in_Authorized_Access_functionality() {
		if (addNewUserPage.verifyPageLevelErrorMsg(jsonDataParser.getTestDataMap()))
			reportPass("The Page Level error message : {" + jsonDataParser.getTestDataMap().get("Page Error")
					+ "} is successfully displayed");
		else
			reportFail("The Page Level error message : {" + jsonDataParser.getTestDataMap().get("Page Error")
					+ "} is not displayed");
	}

	@Then("I should see the Disclosure not accepted error message")
	public void i_should_see_the_Disclosure_not_accepted_error_message() {
		if (addNewUserPage.verifyErrorMsg(jsonDataParser.getTestDataMap()))
			reportPass("The Error message : {" + jsonDataParser.getTestDataMap().get("Error")
					+ "} is successfully displayed");
		else
			reportFail("The Error message : {" + jsonDataParser.getTestDataMap().get("Error") + "} is not displayed");
	}

	@When("I select Authorized access agreement")
	public void i_select_Authorized_access_agreement() {
		try {
			addNewUserPage.selectDisclosure();
			reportPass("Selected Authorized Access Agreement Disclosure");
		} catch (Exception e) {
			reportFail("Failed to Select Authorized Access Agreement Disclosure");
		}
	}

	@When("I enter all the data to add new user")
	public void i_enter_all_the_data_to_add_new_user() {
		if (addNewUserPage.enterDataForAllFields(jsonDataParser.getTestDataMap()))
			reportPass("Entered all the details in Add New User Page");
		else
			reportFail("Failed to enter the required details in Add New User Page");
	}

	@Then("I should see the Accounts are displayed Seperately")
	public void i_should_see_the_Accounts_are_displayed_Seperately() {
		if (addNewUserPage.verifyLabelNames(jsonDataParser.getTestDataMap()))
			reportPass(
					"The Accounts : {" + jsonDataParser.getTestDataMap().get("Labels") + "} are  displayed Seperately");
		else
			reportFail("The Accounts : {" + jsonDataParser.getTestDataMap().get("Labels")
					+ "} are  not displayed Seperately");
	}

	@When("I enter the username to add new user")
	public void i_enter_the_username_to_add_new_user() {
		if (addNewUserPage.enterUserNameForSupportUser(jsonDataParser.getTestDataMap()))
			reportPass("Entered Username {" + addNewUserPage.addNewUser + "} in Add New User Page");
		else
			reportHardFail("Failed to enter Username {" + addNewUserPage.addNewUser + "} in Add New User Page");
	}

	@Then("Business accounts should be  auto selected")
	public void business_accounts_should_be_auto_selected() {
		if (addNewUserPage.verifyBusinessAccountsSelection())
			reportPass("Business accounts are auto selected");
		else
			reportFail("Business accounts are not auto selected");
	}

	@Then("Personal accounts should not be  auto selected")
	public void personal_accounts_should_not_be_auto_selected() {
		if (addNewUserPage.verifyPersonalAccountsSelection())
			reportPass("Personal accounts are not auto selected");
		else
			reportFail("Personal accounts are auto selected");
	}

	@When("I select {int} Personal account")
	public void i_select_Personal_account(Integer number) {
		try {
			addNewUserPage.selectPersonalAccts(number);
			reportPass("Selected Personal Accounts");
		} catch (Exception e) {
			reportHardFail("Failed to select Personal Accounts");
		}
	}

	@Then("I should see consent message")
	public void i_should_see_consent_message() {
		if (addNewUserPage.verifyConsentFormNote((jsonDataParser.getTestDataMap())))
			reportPass(
					"The Content : {" + jsonDataParser.getTestDataMap().get("Consent") + "} is successfully displayed");
		else
			reportFail("The Content : {" + jsonDataParser.getTestDataMap().get("Consent") + "} is not displayed");
	}

	@When("I click on close button in Authorized Access functionality")
	public void i_click_on_close_button_in_Authorized_Access_functionality() {
		try {
			addNewUserPage.clickCloseButton();
			reportPass("Clicked on Close Button");
		} catch (Exception e) {
			reportFail("Failed to click on Close Button");
		}
	}

	@When("I click on I do not consent  in Authorized Access functionality")
	public void i_click_on_I_do_not_consent_in_Authorized_Access_functionality() {
		try {
			addNewUserPage.clickDoNotConsentLink();
			reportPass("Clicked on I do not consent");
		} catch (Exception e) {
			reportFail("Failed to click on I do not consent");
		}
	}

	@Then("I shoud see the Personal account as deselect")
	public void i_shoud_see_the_Personal_account_as_deselect() {
		if (addNewUserPage.verifyPersonalAccountsSelection())
			reportPass("Personal accounts are deselected");
		else
			reportFail("Personal accounts are not deselected");
	}

	@When("I click on I Consent  in Authorized Access functionality")
	public void i_click_on_I_Consent_in_Authorized_Access_functionality() {
		try {
			addNewUserPage.clickIConsentLink();
			reportPass("Clicked on I Consent Link");
		} catch (Exception e) {
			reportFail("Failed to click on I Consent Link");
		}
	}

	@When("I click on Authorized Access Agreement link then I should see the disclosure content lightbox")
	public void i_click_on_Authorized_Access_Agreement_link_then_I_should_see_the_disclosure_content_lightbox() {
		if (addNewUserPage.clickAgreementLink())
			reportPass("Clicked on Authorized Access Agreement link and Disclosure lightbox is successfully displayed");
		else
			reportFail("Failed to click on Authorized Access Agreement link");
	}

	@When("I click on user name of the {string} in Manage User Access Page")
	public void i_click_on_user_name_of_the_in_Manage_User_Access_Page(String value) {
		try {
			addNewUserPage.clickUserName(value);
			reportPass("Clicked on Username link in Manage users page");
		} catch (Exception e) {
			reportFail("Failed to click on Username link in Manage users page");
		}
	}

	@When("I select role id as {string} in Manage User Access Page")
	public void i_select_role_id_as_in_Manage_User_Access_Page(String role) {
		try {
			addNewUserPage.selectRole(role);
			reportPass("Selected user role in manage user access page");
		} catch (Exception e) {
			reportFail("Failed to Select user role in manage user access page");
		}
	}

	@Then("I clicked on Consent Link in Manage User Access")
	public void i_clicked_on_Consent_Link_in_Manage_User_Access() {
		try {
			addNewUserPage.clickIConsentLinkManage();
			reportPass("Clicked on I Consent Link");
		} catch (Exception e) {
			reportFail("Failed to click on I Consent Link");
		}
	}

	@When("I deselect all the personal Accounts")
	public void i_deselect_all_the_personal_Accounts() {
		try {
			addNewUserPage.deSelectPersonalAccts();
			reportPass("Deselected the personal Accounts");
		} catch (Exception e) {
			reportFail("Failed to Deselect the personal Accounts");
		}
	}

	@Then("I should see common accounts for adminstrators")
	public void i_should_see_common_accounts_for_adminstrators() {
		if (addNewUserPage.validateCommonAccounts())
			reportPass("Only common accounts are displayed");
		else
			reportFail("Other than common accounts are displayed");
	}

	@When("I update valid SSN in Manage User Access")
	public void i_update_valid_SSN_in_Manage_User_Access() {
		if (addNewUserPage.updateSSN(jsonDataParser.getTestDataMap()))
			reportPass("Update SSN value in manage user access page");
		else
			reportFail("Failed to update SSN value in manage user access page");
	}

	@When("I update the status {string} in manage User Access Page")
	public void i_update_the_status_in_manage_User_Access_Page(String status) {
		try {
			addNewUserPage.updateStatus(status);
			reportPass("Updated User status in Manage User Access Page");
		} catch (Exception e) {
			reportFail("Failed to Update User status in Manage User Access Page");
		}
	}

	@Then("I should see the Page Content Points")
	public void i_should_see_the_Page_Content_Points() {
		if (addNewUserPage.verifyPageContentPoints(jsonDataParser.getTestDataMap()))
			reportPass(
					"The Content {" + jsonDataParser.getTestDataMap().get("Contents") + "} is Successfully displayed");
		else
			reportFail("The Content {" + jsonDataParser.getTestDataMap().get("Contents") + "} is not displayed");
	}

	@Then("I should see the Top Note")
	public void i_should_see_the_Top_Note() {
		if (addNewUserPage.verifyPageContent(jsonDataParser.getTestDataMap()))
			reportPass("The Content {" + jsonDataParser.getTestDataMap().get("Note1") + "} is Successfully displayed");
		else
			reportFail("The Content {" + jsonDataParser.getTestDataMap().get("Note1") + "} is not displayed");
	}

	@Then("I should see the Note Points")
	public void i_should_see_the_Note_Points() {
		if (addNewUserPage.verifyPageNotePoints(jsonDataParser.getTestDataMap()))
			reportPass("The Content {" + jsonDataParser.getTestDataMap().get("Points") + "} is Successfully displayed");
		else
			reportFail("The Content {" + jsonDataParser.getTestDataMap().get("Points") + "} is not displayed");
	}

	@Then("I should see the Userrole Information labels")
	public void i_should_see_the_Userrole_Information_labels() {
		if (addNewUserPage.verifyUserRoleInfoLabels(jsonDataParser.getTestDataMap()))
			reportPass("The Labels {" + jsonDataParser.getTestDataMap().get("Headers") + "} is Successfully displayed");
		else
			reportFail("The Labels {" + jsonDataParser.getTestDataMap().get("Headers") + "} is not displayed");
	}

	@Then("I should see the User role information")
	public void i_should_see_the_User_role_information() {
		if (addNewUserPage.verifyUserRoleInfo(jsonDataParser.getTestDataMap()))
			reportPass("The Information {" + jsonDataParser.getTestDataMap().get("Values")
					+ "} is Successfully displayed");
		else
			reportFail("The Information {" + jsonDataParser.getTestDataMap().get("Values") + "} is not displayed");
	}

	@Then("I should see the confirmation Details")
	public void i_should_see_the_confirmation_Details() {
		if (!addNewUserPage.getConfirmDetails())
			reportPass("Retrieved add new user confirmation details{" + addNewUserPage.authorizedUserMap
					+ "} Successfully");
		else
			reportFail("Failed to Retrieve add new user confirmation details");
	}

	@Then("I should see the confirmation message")
	public void i_should_see_the_confirmation_message() {
		if (addNewUserPage.verifyConfirmMsg(jsonDataParser.getTestDataMap()))
			reportPass("The Confirmation message {" + jsonDataParser.getTestDataMap().get("Confirmation")
					+ "} is Successfully displayed");
		else
			reportFail("The Confirmation message {" + jsonDataParser.getTestDataMap().get("Confirmation")
					+ "} is not displayed");
	}

	@Then("I should see the name Mismatch content")
	public void i_should_see_the_name_Mismatch_content() {
		if (addNewUserPage.verifyNameErr(jsonDataParser.getTestDataMap()))
			reportPass("The Name Mismatch content {" + jsonDataParser.getTestDataMap().get("Error")
					+ "} is Successfully displayed");
		else
			reportFail("The Name Mismatch content {" + jsonDataParser.getTestDataMap().get("Error")
					+ "} is not displayed");
	}

	@When("I click on continue button to add new user with correct name")
	public void i_click_on_continue_button_to_add_new_user_with_correct_name() {
		try {
			addNewUserPage.clickContinueButton();
			reportPass("Clicked on continue button in add new user");
		} catch (Exception e) {
			reportFail("Failed to click on continue button in add new user");
		}
	}

	@Then("I should see the SSN Mismatch Error")
	public void i_should_see_the_SSN_Mismatch_Error() {
		if (addNewUserPage.verifySSNErr(jsonDataParser.getTestDataMap()))
			reportPass("The SSN Mismatch content {" + jsonDataParser.getTestDataMap().get("Error")
					+ "} is Successfully displayed");
		else
			reportFail(
					"The SSN Mismatch content {" + jsonDataParser.getTestDataMap().get("Error") + "} is not displayed");
	}

	@Then("validate the Next Step Links")
	public void validate_the_Next_Step_Links() {
		if (addNewUserPage.verifyNextSteps(jsonDataParser.getTestDataMap()))
			reportPass("The Next step links {" + jsonDataParser.getTestDataMap().get("NextSteps")
					+ "} are Successfully displayed");
		else
			reportFail(
					"The Next step links {" + jsonDataParser.getTestDataMap().get("NextSteps") + "} are not displayed");
	}

	@When("I click on Start Over link")
	public void i_click_on_Start_Over_link() {
		try {
			addNewUserPage.clickStartOver();
			reportPass("Clicked on Start Over link in add new user");
		} catch (Exception e) {
			reportFail("Failed to Click on Start Over link in add new user");
		}
	}

	@When("I click on Manage Users link")
	public void i_click_on_Manage_Users_link() {
		try {
			addNewUserPage.clickManageUsers();
			reportPass("Clicked on Manage Users link in add new user");
		} catch (Exception e) {
			reportFail("Failed to Click on Manage Users link in add new user");
		}
	}

	@Then("I should see the Inactive warning message")
	public void i_should_see_the_Inactive_warning_message() {
		if (addNewUserPage.verifyInactiveWarningMsg(jsonDataParser.getTestDataMap()))
			reportPass("The Inactive user warning message {" + jsonDataParser.getTestDataMap().get("Warning")
					+ "} is Successfully displayed");
		else
			reportFail("The Inactive user warning message {" + jsonDataParser.getTestDataMap().get("Warning")
					+ "} is not displayed");
	}

	@Then("I should see the status updated as {string}")
	public void i_should_see_the_status_updated_as(String status) {
		addNewUserPage.getManageUserDetails();
		if (addNewUserPage.validateStatus(status))
			reportPass("The status value is displayed as {" + status + "} in Manage user access confirmation page");
		else
			reportFail("The status value is not displayed as {" + status + "} in Manage user access confirmation page");
	}

	@Then("I shold see the account information")
	public void i_shold_see_the_account_information() {
		if (addNewUserPage.verifyViewOnlyUserAcctInfo(jsonDataParser.getTestDataMap()))
			reportPass("The View-Only user Account message {" + jsonDataParser.getTestDataMap().get("View-Only")
					+ "} is Successfully displayed");
		else
			reportFail("The View-Only user Account message {" + jsonDataParser.getTestDataMap().get("View-Only")
					+ "} is not displayed");
	}

	@Then("I should see the Role value as {string}")
	public void i_should_see_the_Role_value_as(String role) {
		addNewUserPage.getManageUserDetails();
		if (addNewUserPage.validateUserRole(role))
			reportPass("The status value is displayed as {" + role + "} in Manage user access confirmation page");
		else
			reportFail("The status value is not displayed as {" + role + "} in Manage user access confirmation page");
	}

	@Then("I should see the user account information")
	public void i_should_see_the_user_account_information() {
		if (addNewUserPage.verifyUserAcctInfo(jsonDataParser.getTestDataMap()))
			reportPass("The user Account message {" + jsonDataParser.getTestDataMap().get("Note")
					+ "} is Successfully displayed");
		else
			reportFail(
					"The user Account message {" + jsonDataParser.getTestDataMap().get("Note") + "} is not displayed");
	}

	@Then("I should see the All the error messages in Add new User page")
	public void i_should_see_the_All_the_error_messages_in_Add_new_User_page() {
		if (addNewUserPage.verifyErrorMessages(jsonDataParser.getTestDataMap()))
			reportPass("The Error messages {" + jsonDataParser.getTestDataMap().get("Error")
					+ "} are Successfully displayed");
		else
			reportFail("The Error messages {" + jsonDataParser.getTestDataMap().get("Error") + "} are not displayed");
	}

}
