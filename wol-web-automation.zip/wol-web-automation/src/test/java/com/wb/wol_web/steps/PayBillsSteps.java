package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.json.simple.parser.ParseException;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.PayBillsPage;
import com.wb.wol_web.pages.PendingPaymentsPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class PayBillsSteps extends ObjectBase {

	PayBillsPage payBillsPage = new PayBillsPage();
	PendingPaymentsPage pendingPaymentsPage = new PendingPaymentsPage();

	@Then("I check if all the options in {string} dropdown are present")
	public void i_check_if_all_the_options_in_dropdown_are_present(String selectBox) {
		String optionsMissing = payBillsPage.checkTheListOptions(selectBox);
		if (!optionsMissing.equals(""))
			reportFail("Some of the options " + optionsMissing + " are missing in the dropdown " + selectBox);
		else
			reportPass("All the options are present in the dropdown " + selectBox);
	}

	@Then("I check if all the payees are expanded on clicking expandall button")
	public void i_check_if_all_the_payees_are_expanded_on_clicking_expandall_button() {
		payBillsPage.clickOnExpandAll();
		if (payBillsPage.checkExpandAllPayees())
			reportPass("All the payees are expanded on clicking expandall button");
		else
			reportFail("All the payees are not expanded on clicking expandall button");
	}

	@Then("I check for the {string} notice text")
	public void i_check_for_the_notice_text(String warningType) {
		if (payBillsPage.checkTheTextForWarnings(warningType))
			reportPass("Found the text :{" + jsonDataParser.getTestDataMap().get(warningType) + "}");
		else
			reportFail("Could not find the text :{" + jsonDataParser.getTestDataMap().get(warningType) + "}");
	}

	@Then("I check that PayeeName,Date,Amount are dispalyed for a payee without expanding")
	public void i_check_that_PayeeName_Date_Amount_are_dispalyed_for_a_payee_without_expanding() {
		String payeesFields = payBillsPage.checkThePayeeListWithoutExpand();
		if (payeesFields.equals(""))
			reportPass("All the three labels are displayed : name,Date Amount");
		else
			reportFail("All the three labels are not displayed.Missing fields are " + payeesFields);
	}

	@Then("I check the naming format for payee {string} with no nickname")
	public void i_check_the_naming_format_for_payee_with_no_nickname(String name) {
		if (payBillsPage.checkThePayeeNameFormat(jsonDataParser.getTestDataMap().get(name), false))
			reportPass("Name format is correct for a payee without nickname");
		else
			reportFail("Name format is not correct for a payee without nickname");

	}

	@Then("I check the naming format for payee {string} with nickname")
	public void i_check_the_naming_format_for_payee_with_nickname(String name) {
		if (payBillsPage.checkThePayeeNameFormat(jsonDataParser.getTestDataMap().get(name), true))
			reportPass("Name format is correct for a payee with nickname");
		else
			reportFail("Name format is not correct for a payee with nickname");
	}

	@Then("I check the default value in {string} dropdown as {string}")
	public void i_check_the_default_value_in_dropdown_as(String dropDown, String value) {
		if (payBillsPage.checkTheDefaultValueInDropDown(dropDown, value))
			reportPass("Default value in " + dropDown + " is " + value);
		else
			reportFail("Default value in " + dropDown + " is not " + value);
	}

	@When("I click on the payments menu")
	public void i_click_on_the_payments_menu() {
		if (payBillsPage.clickOnPaymentsMenu())
			reportPass("Clicked on the payments menu");
		else
			reportHardFail("Failed to click on payments menu");
	}

	@Then("I check the info title for set up recurring bill payments")
	public void i_check_the_info_title_for_set_up_recurring_bill_payments() {
		if (payBillsPage.checkInfoTitleForRecurringPayments())
			reportPass("Found the info title as {" + jsonDataParser.getTestDataMap().get("InfoTitle") + "} ");
		else
			reportHardFail("Failed to find the info title for recuuring payments ");

	}

	@Then("I should be in Set Up Recurring Bill Payments page")
	public void i_should_be_in_Set_Up_Recurring_Bill_Payments_page() {
		if (payBillsPage.checkForRecurringPaymentsTitle())
			reportPass("Found the page title as {" + jsonDataParser.getTestDataMap().get("Recurring PageTitle") + "} ");
		else
			reportHardFail("Failed to find the page title for recuuring payments ");
	}

	@Then("I check for the warning message in recurring payments page")
	public void i_check_for_the_warning_message_in_recurring_payments_page() {
		if (payBillsPage.checkForRecurringPaymentsWarnignMsg())
			reportPass("Found the warning message in recurring page as {"
					+ jsonDataParser.getTestDataMap().get("WarningTitle") + "} ");
		else
			reportFail("Failed to find the warning message in recuuring payments page");
	}

	@Then("I enter all the payment details for {string} payee")
	public void i_enter_all_the_payment_details_for_payee(String payeeType, DataTable paymentDetails)
			throws ParseException {
		String fileName = WOLTestBase.props.getProperty("paybills.json.file.name");
		List<Map<String, String>> jsonDetails = paymentDetails.asMaps(String.class, String.class);
		try {
			List<Map<String, String>> transferDetails = payBillsPage.getSortedJSONData(jsonDetails, fileName);
			payBillsPage.enterPaymentDetails(transferDetails, payeeType);
			reportPass("Entered the details " + transferDetails);
		} catch (Exception e) {
			reportHardFail("Failed to enter details of the payment");
		}
	}

	@When("I Click on Continue Button in paybills")
	public void i_Click_on_Continue_Button_in_paybills() {
		if (payBillsPage.clickOnContinue()) {
			if (payBillsPage.checkForDuplicateBills()) {
				payBillsPage.clickOnContinue();
				reportPass("Clicked on continue button");
			}
		} else
			reportHardFail("Failed to click on the continue button");
	}

	@Then("I check the details in verification page with data entered")
	public void i_check_the_details_in_verification_page_with_data_entered() {
		if (payBillsPage.validateDataInVerificationPage()) {
			reportPass("Data entered is same as the data displayed in verification page");
		} else
			reportHardFail("Data entered is not same as the data displayed in verification page");
	}

	@Then("I check the details in confirmation page with data entered")
	public void i_check_the_details_in_confirmation_page_with_data_entered() {
		if (payBillsPage.validateDataInConfirmationPage()) {
			reportPass("Data entered is same as the data displayed in confirmation page");
		} else
			reportHardFail("Data entered is not same as the data displayed in confirmation page");
	}

	@Then("I get the pay bills confirmation details")
	public void i_get_the_pay_bills_confirmation_details() {
		payBillsPage.setConfirmationNumbers();
	}

	@Then("I check the payment details are displayed in Pending Payments page")
	public void i_check_the_payment_details_are_displayed_in_Pending_Payments_page() {
		if (pendingPaymentsPage.deletePendingPayments(false, "PayBillsConfirmationNumber"))
			reportPass("Confirmation details are found in Pending Payments Page");
		else {
			reportFail("Confirmation details are not found in Pending Payments Page");
		}
	}

	@Then("I check the tooltip message for {string} in paybills")
	public void i_check_the_tooltip_message_for_in_paybills(String string) {
		if (payBillsPage.checkToolTipMessage())
			reportPass("Found the tool tip message {" + jsonDataParser.getTestDataMap().get("Message") + "}");
		else {
			reportFail("Failed to find the tool tip message {" + jsonDataParser.getTestDataMap().get("Message") + "}");
		}
	}

	@Then("I check if all the next step links are present in the page")
	public void i_check_for_the_next_step_links_in_non_responsive_page() {
		String linksNotPresent = payBillsPage.checkForNextStepLinks("", "NextStepLinks");
		if (linksNotPresent.equals(jsonDataParser.getTestDataMap().get("NextStepLinks") + ","))
			reportPass("All the next step links are present {" + jsonDataParser.getTestDataMap().get("NextStepLinks")
					+ "}");
		else
			reportFail("Some of the next steps are missing.Only  {" + linksNotPresent + "} are present");
	}

	@Then("I check if all the next step links are present in the confirmation page")
	public void i_check_for_the_next_step_links_in_non_confirmation_page() {
		String linksNotPresent = payBillsPage.checkForNextStepLinks("Confirmation", "NextStepLinks");
		if (linksNotPresent.equals(jsonDataParser.getTestDataMap().get("NextStepLinks") + ","))
			reportPass("All the next step links are present {" + jsonDataParser.getTestDataMap().get("NextStepLinks")
					+ "}");
		else
			reportFail("Some of the next steps are missing.Only  {" + linksNotPresent + "} are present");
	}

	@Then("I check if all the next step links are present in the delete payee confirmation page")
	public void i_check_for_the_next_step_links_in_delete_confirmation_page() {
		String linksNotPresent = payBillsPage.checkForNextStepLinks("", "DeletePayeeNextStepLinks");
		if (linksNotPresent.equals(jsonDataParser.getTestDataMap().get("DeletePayeeNextStepLinks") + ","))
			reportPass("All the next step links are present {" + jsonDataParser.getTestDataMap().get("NextStepLinks")
					+ "}");
		else
			reportFail("Some of the next steps are missing.Only  {" + linksNotPresent + "} are present");
	}

	@Then("I check for the page level error message")
	public void i_check_for_the_page_level_error_message() {
		if (payBillsPage.checkPageLevelErrorMsg())
			reportPass("Found the error message in page level {"
					+ jsonDataParser.getTestDataMap().get("Common Error Message") + "}");
		else
			reportFail("Failed to find the error message in page level {"
					+ jsonDataParser.getTestDataMap().get("Common Error Message") + "}");
	}

	@Then("I look for the field level error message as {string}")
	public void i_look_for_the_field_level_error_message_as(String errorType) {
		if (payBillsPage.checkFieldLevelErrorMsg(errorType))
			reportPass(
					"Found the error message in field level {" + jsonDataParser.getTestDataMap().get(errorType) + "}");
		else
			reportFail("Failed to find the error message in field level {"
					+ jsonDataParser.getTestDataMap().get(errorType) + "}");
	}

	@Then("I enter all the invalid payment details for {string} payee")
	public void i_enter_all_the_invalid_payment_details_for_payee(String payeeType, DataTable paymentDetails) {

		List<Map<String, String>> details = paymentDetails.asMaps(String.class, String.class);
		try {
			payBillsPage.enterInvalidPaymentDetails(details, payeeType);
			reportPass("Entered the details " + details);
		} catch (Exception e) {
			reportHardFail("Failed to enter details of the payment");
		}
	}

	@When("I check if the payment memo has only twenty letters from the data {string}")
	public void i_check_if_the_payment_memo_has_only_twenty_letters_from_the_data(String data) {
		if (payBillsPage.checkMemoLetterCount(data)) {
			reportPass("Only 20 letters are allowed in payment memo");
		} else
			reportFail("More than 20 letters are allowed in payment memo");
	}

	@Then("I check the tooltip message of delivery date is same as list of {string} date cycles with {string} frequency")
	public void i_check_the_tooltip_message_of_delivery_date_is_same_as_list_of_date_cycles_of_frequency_in_page(
			String cycles, String paymentType) {
		if (payBillsPage.checkTheDeliveryDateToolTip(jsonDataParser.getTestDataMap().get(paymentType),
				jsonDataParser.getTestDataMap().get(cycles))) {
			reportPass("Tool tip is displayed correct");
		} else {
			reportFail("Tool tip is not displayed correct");
		}
	}

	@When("I select the option {string} from sortby dropdown")
	public void i_select_the_option_from_sortby_dropdown(String sortByValue) {
		if (payBillsPage.selectSortBy(sortByValue)) {
			reportPass("Selected the option from sort by dropdown :" + sortByValue);
		} else {
			reportHardFail("Failed to select the option from sort by dropdown " + sortByValue);
		}
	}

	@Then("All the payees should be displayed alphabetical order")
	public void all_the_payees_should_be_displayed_alphabetical_order() {
		if (payBillsPage.checkSortByFunctionality("NORMAL")) {
			reportPass("payees are displayed in the alphabetical order:");
		} else {
			reportFail("payees are not displayed in the alphabetical order:");
		}

	}

	@Then("All the payees should be displayed reverse alphabetical order")
	public void all_the_payees_should_be_displayed_reverse_alphabetical_order() {
		if (payBillsPage.checkSortByFunctionality("REVERSE")) {
			reportPass("payees are displayed in reverse alphabetical order:");
		} else {
			reportFail("payees are not displayed in reverse alphabetical order:");
		}
	}

	@Then("I click on expand all button")
	public void i_click_on_expand_all_button() {
		if (payBillsPage.clickOnExpandAll()) {
			reportPass("Clicked on expand all button");
		} else {
			reportHardFail("Failed to click on expand all button");
		}
	}

	@Then("I check that no {string} payees are present in the page")
	public void i_check_that_no_payees_are_present_in_the_page(String payeeType) {
		if (payBillsPage.checkForPayeeTypeNeg(payeeType)) {
			reportPass("No " + payeeType + " payees are present");
		} else {
			reportFail(payeeType + " payees are present");
		}
	}

	@Then("I check that the payee seleted is {string}")
	public void i_check_that_any_payee_seleted_is(String payeeOnList) {
		if (payBillsPage.checkIfPayeeIsOnShortList(payeeOnList)) {
			reportPass("payee is " + payeeOnList);
		} else {
			reportFail("payee is not " + payeeOnList);
		}
	}

	@When("^I click on PayeeDetails link for \"([^\"]*)\" payee$")
	public void i_click_on_PayeeDetails_link(String payeeType) throws Throwable {
		if (!payBillsPage.clickOnPayeeDetailsLink(payeeType)) {
			reportFail("Failed to click on payee details link for " + payeeType + " payee");
		}
	}

	@Then("^I select the type of payment as \"([^\"]*)\" from Showonly dropdown$")
	public void i_select_the_type_of_payment_as_from_Showonly_dropdown(String paymentType) throws Throwable {
		try {
			payBillsPage.selectFromShowOnlyDropDown(paymentType);
			reportPass(paymentType + " is selected from  ShowOnly dropdown");
		} catch (Exception e) {
			reportFail("Failed to select the type of payment");
		}
	}

	@Then("^I click on the \"([^\"]*)\" payee and check for the below labels$")
	public void i_should_see_below_UI_labels(String payeename) throws Throwable {
		Map<String, String> map = new HashMap<>();
		List<String> detailsLabels = new ArrayList<String>();
		for (String eachLabel : jsonDataParser.getTestDataMap().values()) {
			detailsLabels.add(eachLabel);
		}
		try {
			map = payBillsPage.clickOnThePayeeFromList(payeename);
			String reportMsg = "";
			for (String eachLabel : detailsLabels) {
				if (map.containsKey(eachLabel)) {
					reportMsg = reportMsg + eachLabel + ",";
				}
			}
			reportPass("Following Labels are present in the payee details" + "\n" + reportMsg);
		} catch (Exception e) {
			reportFail("Labels are missing in payees details");
		}
	}

	@Then("^I should navigate to Payment \"([^\"]*)\" page and check for the heading \"([^\"]*)\"$")
	public void check_the_payment_page_and_heading(String pagename, String heading) {
		if (payBillsPage.checkForPageHeading(pagename, heading)) {
			reportPass("Heading " + heading + " is found");
		} else {
			reportFail("heading " + heading + "  is not found");
		}
	}

	@Then("^Check for the \"([^\"]*)\" message as \"([^\"]*)\"$")
	public void check_for_the_message(String pagename, String mesage) throws Throwable {
		if (payBillsPage.checkForTheMessage(pagename, jsonDataParser.getTestDataMap().get(mesage))) {
			reportPass("Message " + mesage + " is found");
		} else {
			reportFail("Message " + mesage + "  is not found");
		}
	}

	@Then("^I click on when payment is delivered checkbox and SetupAlerts button$")
	public void i_click_on_when_payment_is_delivered_checkbox_and_SetupAlerts_button() throws Throwable {
		try {
			payBillsPage.acceptAlertCheckbox();
		} catch (Exception e) {
			reportHardFail("Failed to click on setup alerts button");
		}
	}

	@Then("I should go to {string} page")
	public void i_should_go_to_page(String title) {
		if (payBillsPage.checkMakeDepositTitle(title))
			reportPass("Found the title  " + title);
		else {
			reportHardFail("Failed to find the title " + title);
		}
	}

	@And("^I get the selected account from which the payment is to be made$")
	public void getAccountNumber() {
		String accountSelected = payBillsPage.getTheAccountNumber();
		if (!accountSelected.equals("")) {
			reportPass("Payment is made from the account " + accountSelected);
		} else {
			reportFail("Failed to get the account from which the payment is made");
		}
	}
}
