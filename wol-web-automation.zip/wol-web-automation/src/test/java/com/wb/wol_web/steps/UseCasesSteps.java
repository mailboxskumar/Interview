package com.wb.wol_web.steps;

import java.util.List;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddBillPayeePage;
import com.wb.wol_web.pages.UseCasesPage;
import com.wb.wol_web.testbases.WOLTestBase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class UseCasesSteps extends ObjectBase {

	UseCasesPage useCasesPage = new UseCasesPage();
	AddBillPayeePage addBillPayeePage = new AddBillPayeePage();

	public String customerName = "";
	public String txtValue = "";
	public String confirmationNumber = "";
	public String payeeName = "";
	public String timeStamp = "";
	public String accountNumber = "";

	@Then("I get the confirmation number")
	public void i_get_the_confirmation_number() {
		confirmationNumber = useCasesPage.captureConfirmationNumber();
		if (confirmationNumber != null)
			reportPass("Confirmation Number: " + confirmationNumber + " is displayed");
		else
			reportFail("Confirmation Number is not displayed");
	}

	@Then("I verify the confirmation number is present")
	public void i_verify_the_confirmation_number_is_present() {
		if (useCasesPage.checkConfirmationNumber(confirmationNumber))
			reportPass("Confirmation Number: " + confirmationNumber + " is displayed ");
		else
			reportFail("Confirmation Number is not displayed");
	}

	@Then("I click on the delivery date of pending payment")
	public void i_click_on_the_delivery_date_of_pending_payment() {
		if (useCasesPage.clickOnPendingTransDate())
			reportPass("Clicked on Pening payment delivery date");
		else
			reportHardFail("No Pending payments or not clicked on Pending payment delivery date");
	}

	@Given("As a user I logged into PASS application")
	public void as_a_user_I_logged_into_PASS_application() {
		if (useCasesPage.loginPassApplication())
			reportPass("Logged into PASS Application");
		else
			reportHardFail("Failed to Logged into PASS Aplication");
	}

	@Then("I should be in {string} page of PASS application")
	public void i_should_be_in_page_of_PASS_application(String pageName) {
		if (useCasesPage.checkPageTitlePass(pageName))
			reportPass("Redirected to " + pageName + " page");
		else
			reportHardFail("Not redirected to " + pageName + " page");
	}

	@Then("I enter the username as {string} in PASS")
	public void i_enter_the_username_as_in_PASS(String userKey) {
		String userName = WOLTestBase.envProps.getProperty(userKey);
		if (useCasesPage.enterUserName(userName))
			reportPass("Entered the username {" + userName + "}");
		else
			reportHardFail(
					"Incorrect username entered, Terminating execution. Please verify the username and re-execute the script.");
	}

	@Given("I select the {string} in {string} field")
	public void i_select_the_in_Transaction_Name_field(String value, String labelName) {
		if (useCasesPage.selectTransactionName(value, labelName))
			reportPass("Value: " + value + " is selected in label: " + labelName);
		else
			reportFail("Value: " + value + " is not selected in label: " + labelName);
	}

	@Then("I enter the payment due date")
	public void i_enter_the_payment_due_date() {
		if (useCasesPage.enterPaymentDueDate())
			reportPass("Payment due date is entered");
		else
			reportHardFail("Payment due date is entered");
	}

	@Then("I select the reason for research")
	public void i_select_the_reason_for_research() {
		if (useCasesPage.selectReasonResearch())
			reportPass("Research reason is checked");
		else
			reportHardFail("Research reason is not checked");
	}

	@Then("I click on {string} button in PASS application")
	public void i_click_on_button_in_PASS_application(String btnName) {
		if (useCasesPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I click on {string} button in {string} page of PASS application")
	public void i_click_on_button_in_page_of_PASS_application(String btnName, String pageName) {
		if (useCasesPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked in page: " + pageName);
		else
			reportFail("Button: " + btnName + " is not clicked in page: " + pageName);
	}

	@Then("I verify the label {string} is displayed")
	public void i_verify_the_label_is_displayed(String labelName) {
		if (useCasesPage.checkForDisplay(labelName))
			reportPass("Label: " + labelName + " is displayed");
		else
			reportFail("Label: " + labelName + " is not displayed");
	}

	@Then("I should see message as {string} in PASS application")
	public void i_should_see_message_as_in_PASS_application(String message) {
		message=jsonDataParser.getTestDataMap().get(message);
		if (useCasesPage.checkForUpdateMessage(message))
			reportPass("Message: " + message + " is displayed");
		else
			reportFail("Message: " + message + " is not displayed");
	}

	@Then("I click on {string} button of {string} in PASS application")
	public void i_click_on_button_of_in_PASS_application(String btnName, String labelName) {
		if (useCasesPage.clickOnLabelButton(btnName, labelName))
			reportPass("Button: " + btnName + " is clicked on label: " + labelName);
		else
			reportFail("Button: " + btnName + " is not clicked on label: " + labelName);
	}

	@Then("I click on the {string} transaction name with user name")
	public void i_click_on_the_transaction_name_with_user_name(String transactionName) {
		if (useCasesPage.clickOnTransaction(transactionName, customerName))
			reportPass("Customer Name: " + customerName + " with transaction name: " + transactionName
					+ " is displayed and clicked on transaction");
		else
			reportFail("Customer Name is not displayed or not clicked on transaction");
	}

	@Then("I click on the {string} transaction name with confirmation number")
	public void i_click_on_the_transaction_name_with_confirmation_number(String transactionName) {
		if (useCasesPage.clickOnTransaction(transactionName, confirmationNumber))
			reportPass("Confirmation Number: " + confirmationNumber + " with transaction name: " + transactionName
					+ " is displayed and clicked on transaction");
		else
			reportFail("Confirmation Number is not displayed or not clicked on transaction");
	}

	@Then("I click on the {string} transaction name with created time")
	public void i_click_on_the_transaction_name_with_created_time(String transactionName) {
		if (useCasesPage.clickOnTransactionWithTime(transactionName, timeStamp))
			reportPass("Transaction : " + transactionName + " with timeStamp: " + timeStamp
					+ " is displayed and clicked on transaction");
		else
			reportFail("Transaction : " + transactionName + " with timeStamp: " + timeStamp
					+ " is not displayed or not clicked on transaction");
	}

	@Then("I get the customer name")
	public void i_get_the_customer_name() {
		customerName = useCasesPage.getCustomerName();
		if (customerName != null)
			reportPass("Customer Name: " + customerName + " is displayed");
		else
			reportFail("Customer Name: " + customerName + " is not displayed");
	}

	@Then("I enter {string} value in {string} field")
	public void i_enter_value_in_field(String value, String fieldName) {
		txtValue = useCasesPage.enterValueInField(value, fieldName);
		if (txtValue != null)
			reportPass("Value: " + value + " is entered in field: " + fieldName);
		else
			reportFail("Value return as null in field: " + fieldName);
	}

	@Then("I enter the {string} value in {string} field")
	public void i_enter_the_value_in_field(String value, String fieldName) {
		payeeName = useCasesPage.enterDisplayName(value);
		if (payeeName != null)
			reportPass("Value: " + value + " is entered in field: " + fieldName);
		else
			reportFail("Value return as null in field: " + fieldName);
	}

	@Then("I enter the payment confirmation number in PASS")
	public void i_enter_the_payment_confirmation_number_in_PASS() {
		txtValue = useCasesPage.enterPaymentConfirmationNumber();
		if (txtValue != null)
			reportPass("Confirmation Number: " + txtValue + " is entered in payment confirmation number");
		else
			reportFail("Confirmation Number: " + txtValue + " is not entered in payment confirmation number");
	}

	@Then("I get the Research  information confirmation number")
	public void i_get_the_Research_information_confirmation_number() {
		String researchConfirmationNumber = useCasesPage.getResearchConfirmationNumber();
		if (researchConfirmationNumber != null)
			reportPass("Research Confirmation Number: " + researchConfirmationNumber + " is captured");
		else
			reportFail("Research Confirmation Number  is not captured");
	}

	@Then("I get the confirmation number of {string} payee without {string} status")
	public void i_get_the_confirmation_number_of_payee_without_status(String payeePaymentStatus,
			String payeeResearchStatus) {
		confirmationNumber = useCasesPage.getPaymentConfirmationNumber(payeePaymentStatus, payeeResearchStatus);
		if (confirmationNumber != null)
			reportPass("Confirmation Number: " + confirmationNumber + " is displayed with payment status as "
					+ payeePaymentStatus);
		else
			reportFail("Confirmation Number is not displayed");
	}

	@Then("I verify the research confirmation number of {string} payee with {string} status")
	public void i_verify_the_research_confirmation_number_of_payee_with_status(String payeePaymentStatus,
			String payeeResearchStatus) {
		if (useCasesPage.verifyResearchConfirmationNumber(payeePaymentStatus, payeeResearchStatus, confirmationNumber))
			reportPass("Confirmation Number: " + confirmationNumber + " is displayed with payment status as "
					+ payeePaymentStatus);
		else
			reportFail("Confirmation Number is not displayed");
	}

	@Then("user click on payee name link")
	public void user_click_on_payee_name_link() {
		try {
			addBillPayeePage.clickPayeeName(payeeName);
			reportPass("Clicked on Payee " + payeeName + "  link");
		} catch (Exception e) {
			reportFail("Failed to click on Payee " + payeeName + "  link");
		}
	}

	@Then("I enter payeename in displayname")
	public void i_enter_payeename_in_displayname() {
		if (useCasesPage.enterDisplayName(payeeName) != null)
			reportPass("Display name: " + payeeName + " is entered in display field name");
		else
			reportFail("Display name is not entered");
	}

	@Then("I update the delivery date and amount in Update Payment Details")
	public void i_update_the_delivery_date_and_amount_in_Update_Payment_Details() {
		List<String> updatedValues = useCasesPage.updateDateAndAmount();
		if (updatedValues != null)
			reportPass("Date and Amount values " + updatedValues.toString() + " are updated respectively");
		else
			reportFail("Date and Amount Values are not updated");
	}

	@Then("I click on {string} button of update payment")
	public void i_click_on_button_of_update_payment(String btnName) {
		if (useCasesPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportHardFail("Button: " + btnName + " is not clicked");
	}

	@Then("I get the confirmation number of transaction of {string}")
	public void i_get_the_confirmation_number_of_transaction_of(String transactionName) {
		confirmationNumber = useCasesPage.getUpdatedConfirmationNumber(transactionName);
		if (confirmationNumber != null)
			reportPass("Confirmation Number: " + confirmationNumber + " is captured ");
		else
			reportHardFail("Confirmation Number is not captured");
	}

	@Then("I get the get the timestamp of order")
	public void i_get_the_get_the_timestamp_of_order() {
		timeStamp = useCasesPage.getOrderTimestamp();
		if (timeStamp != null)
			reportPass("Order Creation Timestamp: " + timeStamp + " is captured ");
		else
			reportHardFail("Order Creation Timestamp is not captured");
	}

	@Then("I click on delete button of first pending payment")
	public void i_click_on_delete_button_of_first_pending_payment() {
		if (useCasesPage.clickOnDeleteButton())
			reportPass("Delete button of pending paymnets is clicked");
		else
			reportHardFail("Delete button of pending paymnets is not clicked");
	}

	@Then("I click on edit icon of {string} status account in Manage Non-Webster Transfer Accounts")
	public void i_click_on_edit_icon_of_status_account_in_Manage_Non_Webster_Transfer_Accounts(String accountStatus) {
		if (useCasesPage.clickOnEditOfActiveAccount(accountStatus))
			reportPass("Edit icon of active status acount is clicked");
		else
			reportHardFail("Edit icon of active status acount is not clicked");
	}

	@Then("I update the nickname of account with random value")
	public void i_update_the_nickname_of_account_with_random_value() {
		customerName = useCasesPage.updateAccountNickname();
		if (customerName != null)
			reportPass("Nickname updated as " + customerName);
		else
			reportHardFail("Nickname is not updated");
	}

	@Then("I click on {string} button of Manage Non-Webster Transfer Accounts page")
	public void i_click_on_button_of_Manage_Non_Webster_Transfer_Accounts_page(String btnName) {
		if (useCasesPage.clickOnButton(btnName))
			reportPass("Continue button of Manage Non-Webster Transfer Accounts page is clicked");
		else
			reportHardFail("Continue button of Manage Non-Webster Transfer Accounts page is not clicked");
	}

	@Then("I get the account number")
	public void i_get_the_account_number() {
		accountNumber = useCasesPage.getAccountNumber();
		if (accountNumber != null)
			reportPass("Account Number: " + accountNumber + " is captured");
		else
			reportHardFail("Account Number: " + accountNumber + " is not captured");
	}

	@Then("I enter the new payee account number")
	public void i_enter_the_new_payee_account_number() {
		if (addBillPayeePage.clickEditIcon(accountNumber.substring(6, 10)))
			reportPass("Clicked on Edit Icon for a payee in Manage Payee Page");
		else
			reportFail("Failed to click on Edit Icon in Manage Payees page");
	}

	@Then("I select the from date as one year back date")
	public void i_select_the_from_date_as_one_year_back_date() {
		String fromDate = useCasesPage.selectOneYearBackFromDate();
		if (fromDate != null)
			reportPass("From Date: " + fromDate + " is selected");
		else
			reportFail("Valid From Date is not selected");
	}
	
	@Then("I get the non-webster active account")
	public void i_get_the_non_webster_active_account() {
		String nonWebsterAccount = useCasesPage.getNonWebsterAccount();
		if (nonWebsterAccount != null)
			reportPass("Active Non-Webster Account : " + nonWebsterAccount + " is captured");
		else
			reportFail("Active Non-Webster Account is not captured");
	}
	
}