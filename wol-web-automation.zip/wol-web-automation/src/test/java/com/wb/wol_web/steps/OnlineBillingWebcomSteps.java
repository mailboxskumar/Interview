package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.List;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.OnlineBillingWebcomPage;
import com.wb.wol_web.pages.WebcomPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OnlineBillingWebcomSteps extends ObjectBase {

	OnlineBillingWebcomPage onlineBillingWebcomPage = new OnlineBillingWebcomPage();
	WebcomPage webcomPage = new WebcomPage();
	public List<String> listLabels= new ArrayList<String>();

	@When("I {string} the account of {string}")
	public void i_the_account_of(String action, String accountNumber) {
		accountNumber = jsonDataParser.getTestDataMap().get(accountNumber);
		if (onlineBillingWebcomPage.clickOnAccountCheckbox(action, accountNumber))
			reportPass("Account Number: " + accountNumber + " is " + action);
		else
			reportHardFail("Account Number: " + accountNumber + " is not " + action);
	}

	@When("I select the {string} account from Webster Account dropdown")
	public void i_select_the_account_from_Webster_Account_dropdown(String account) {
		account = jsonDataParser.getTestDataMap().get(account);
		if (onlineBillingWebcomPage.selectAccount(account))
			reportPass("Account Number:" + account + " is selected");
		else
			reportHardFail("Account Number:" + account + " is not selected");
	}

	@When("^I click on \"([^\"]*)\" Account link in Webcom Options$")
	public void i_click_on_Account_link_in_retailbank_activities_options(String linkText) throws Throwable {
		try {
			linkText=jsonDataParser.getTestDataMap().get(linkText);
			webcomPage.selectLinkFromTheMenuWebcom(linkText);
			reportPass("Clicked on Link " + linkText);
		} catch (Exception e) {
			reportFail("Failed to click on Link" + linkText);
		}
	}

	@When("I click on the {string} button")
	public void i_click_on_the_button(String btnName) {
		if (onlineBillingWebcomPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportHardFail("Button: " + btnName + " is not clicked");
	}

	@Then("I verify the below details of {string} Webcom page")
	public void i_verify_the_below_details_of_Webcom_page(String pageName) {
		listLabels.clear();
		listLabels.addAll(jsonDataParser.getTestDataMap().values());
		if (listLabels.size() == onlineBillingWebcomPage.verifyLabels(pageName, listLabels))
			reportPass("Labels: " + listLabels.toString() + " are verified successfully");
		else
			reportFail("Labels: " + listLabels.toString() + " are not verified ");
	}

	@Then("I should see {string} in the account number {string} statement eDelivery field")
	public void i_should_see_in_the_account_number_statement_eDelivery_field(String status, String accountNumber) {
		accountNumber = jsonDataParser.getTestDataMap().get(accountNumber);
		if (onlineBillingWebcomPage.checkAccountEdelivery(status, accountNumber))
			reportPass("Account Number:" + accountNumber + ", eDelivery status: " + status + " is displayed");
		else
			reportHardFail("Account Number:" + accountNumber + ", eDelivery status: " + status + " is displayed");
	}

	@Then("I click on {string} in the account number {string} Remove Account field")
	public void i_click_on_in_the_account_number_Remove_Account_field(String fieldName, String accountNumber) {
		accountNumber= jsonDataParser.getTestDataMap().get(accountNumber);
		if (onlineBillingWebcomPage.clickOnCheckbox(fieldName, accountNumber))
			reportPass("Account Number: " + accountNumber + " corresponding remove account field is " + fieldName);
		else
			reportHardFail(
					"Account Number: " + accountNumber + "  corresponding remove account field  is not " + fieldName);
	}
}