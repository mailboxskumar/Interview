package com.wb.wol_web.steps;

import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.InternalTransfersPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InternalTransfersSteps extends ObjectBase {

	InternalTransfersPage internalTransfersPage = new InternalTransfersPage();

	@And("^I click on Date Link of the confirmation number in Pending Transfers Page$")
	public void i_click_on_date_link_of_the_confirmation_number_in_pending_transfers_page() throws Throwable {
		if (internalTransfersPage.clickLinkinTablebyvalue())
			reportPass("Clicked on Date Link of Transfer in pending transfers page");
		else
			reportFail("Failed to click on Date link of Transfer in pending transfers page");
	}

	@And("^I Entered required details to set up Transfer in Transfer Between Webster Accounts Page$")
	public void i_Entered_required_details_to_set_up_Transfer_in_Transfer_Between_Webster_Accounts_Page()
			throws Throwable {
		Map<String, String> transferDetails = jsonDataParser.getTestDataMap();
		internalTransfersPage.selectTransferFromAcct(transferDetails);
		internalTransfersPage.selectTransferToAcct(transferDetails);
		internalTransfersPage.selectTransferTypeDetails(transferDetails);
		internalTransfersPage.selectLoanPaymentType(transferDetails);
		if (internalTransfersPage.enterAmount(transferDetails))
			reportPass("Entered All the required Transfer Details");
		else
			reportFail("Failed to enter transfer details");
	}

	@And("^I Click on continue button in Transfers page$")
	public void i_click_on_continue_button_in_transfers_page() throws Throwable {
		try {
			internalTransfersPage.clickContinueToTransfer();
			reportPass("Clicked on Continue Button");
		} catch (Exception e) {
			reportHardFail("Failed to click on Continue button");
		}
	}

	@Then("^I should get confirmation number$")
	public void i_should_get_confirmation_number() throws Throwable {
		internalTransfersPage.getTransferCnfrmDetails();
		if (internalTransfersPage.getTransferConfirmationNumber())
			reportPass("Retrieved the Transfer Confirmation Number: " + internalTransfersPage.confirmNumber);
		else
			reportFail("Failed to get Transfer Confirmation number");
	}

	@Then("^I should be in \"([^\"]*)\" page in Internal Transfers functionality$")
	public void i_should_be_in_something_page_in_internal_transfers_functionality(String message) throws Throwable {
		if (internalTransfersPage.verifyInternalTransfersPageTitle(message))
			reportPass("The Header Text:" + message + "  is successfully displayed");
		else {
			reportFail("The Header Text:" + message + " is not displayed");
		}
	}

	@And("^Transfer confirmation message should be displayed$")
	public void immediate_transfer_confirmation_message_something_should_be_displayed() throws Throwable {
		if (internalTransfersPage.verifyInternalTransfersConfrmMsg(jsonDataParser.getTestDataMap().get("CnfrmMsg")))
			reportPass("The Confirmation message: " + jsonDataParser.getTestDataMap().get("CnfrmMsg")
					+ "  is successfully displayed");
		else {
			reportFail("The Confirmation message: " + jsonDataParser.getTestDataMap().get("CnfrmMsg")
					+ " is not displayed");
		}
	}

	@Then("^Prinicpal Only Content should be displayed$")
	public void prinicpal_only_content_something_should_be_displayed() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("Principal");
		if (internalTransfersPage.verifyPrincipalContent(message))
			reportPass("The Principal only option content: " + message + "  is successfully displayed");
		else {
			reportFail("The Principal only option content: " + message + " is not displayed");
		}
	}

	@And("^MSP Account content should be displayed$")
	public void msp_account_content_somethingregular_paymentsomething_should_be_displayed() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("MSP");
		if (internalTransfersPage.verifyMSPAccountContent(message))
			reportPass("The content of MSP account: " + message + "  is successfully displayed");
		else {
			reportFail("The content of MSP account: " + message + " is not displayed");
		}
	}

	@When("^I enter Past date (.*) Transfer Date in Transfers Page$")
	public void i_enter_past_date_something_transfer_date_in_transfers_page(int days) throws Throwable {
		try {
			internalTransfersPage.enterTransferDate(days);
			reportPass("Entered Past date as a Transfer Date");
		} catch (Exception e) {
			reportFail("Failed to enter Transfer date as a past date");
		}
	}

	@When("^I Click on Transfers Disclosure Link$")
	public void i_click_on_transfers_disclosure_link() throws Throwable {
		if (internalTransfersPage.clickTransferDisclosure())
			reportPass("Clicked on " + internalTransfersPage.disclosurelnkText + " Link");
		else
			reportFail("Failed to click on Disclosure Link");
	}

	@Then("^I should see the Statement Savings or Money Market Deposit Account link in Lightbox$")
	public void i_should_see_the_statement_savings_or_money_market_deposit_account_link_in_lightbox() throws Throwable {
		if (internalTransfersPage.verifyTransfersLink())
			reportPass("The content of Lightbox: " + internalTransfersPage.txtdisclosurelightbox
					+ "  is successfully displayed");
		else {
			reportFail("The content of Lightbox: " + internalTransfersPage.txtdisclosurelightbox + " is not displayed");
		}
	}

	@When("^I click on Close button in Disclosure$")
	public void i_click_on_close_button_in_disclosure() throws Throwable {
		try {
			internalTransfersPage.clickDisclosureCloseButton();
			reportPass("Clicked on Close button in a Disclosure Lightbox");
		} catch (Exception e) {
			reportFail("Failed to click Close button in Disclosure Lightbox");

		}
	}

	@And("^I should see the Error message in Transfers Page$")
	public void i_should_see_the_error_message_something_in_transfers_page() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("ErrorMsg");
		if (internalTransfersPage.verifyNoAccountsError(message))
			reportPass("The Error message: " + message + "  is successfully displayed");
		else {
			reportFail("The Error message: " + message + " is not displayed");
		}
	}

	@Then("^I should see the Loan Accounts error message in Transfers Page$")
	public void i_should_see_the_loan_accounts_error_message_something_in_transfers_page() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("ErrorMsg");
		if (internalTransfersPage.verifyLoanAccountsError(message))
			reportPass("The Error message: " + message + "  is successfully displayed");
		else {
			reportHardFail("The Error message: " + message + " is not displayed");
		}
	}

	@When("^I am able to see all the details about transfer confirmation$")
	public void i_am_able_to_see_all_the_details_about_transfer_confirmation() throws Throwable {
		internalTransfersPage.verifyTransferDetails();
	}

	@Then("^Transfer confirmation details should be displayed in Transfer History$")
	public void transfer_confirmation_details_should_be_displayed_in_transfer_history() throws Throwable {
		if (internalTransfersPage.validateTransferDetails())
			reportPass("Transfer details are : " + wolWebUtil.returnMap + "  successfully displayed");
		else {
			reportFail("Transfer details are   not displayed");
		}
	}

	@And("^I should see the Immediate Transfer content in Transfers Page$")
	public void i_should_see_the_immediate_transfer_content_something_in_transfers_page() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("Immediate");
		if (internalTransfersPage.verifyImmediateContent(message))
			reportPass("The Immediate Transfer content : " + message + "  is successfully displayed");
		else {
			reportFail("The Immediate Transfer content : " + message + " is not displayed");
		}
	}

	@Then("^I should see the Future Transfer content in Transfers Page$")
	public void i_should_see_the_future_transfer_content_something_in_transfers_page() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("Future");
		if (internalTransfersPage.verifyFutureContent(message))
			reportPass("The Future Transfer content : " + message + "  is successfully displayed");
		else
			reportFail("The Future Transfer content : " + message + " is not displayed");
	}

	@And("^I should not see account in Transfer From Dropdown$")
	public void i_should_not_see_something_account_in_transfer_from_dropdown() throws Throwable {
		String value = jsonDataParser.getTestDataMap().get("Account Type");
		if (!internalTransfersPage.verifyTransferFromValues(value)) {
			reportPass("The Account type: " + value + " is not displayed");
		} else
			reportFail("The Account type: " + value + " is displayed");

	}

	@And("^I should not see account in Transfer To Dropdown$")
	public void i_should_not_see_something_account_in_transfer_to_dropdown() throws Throwable {
		String value = jsonDataParser.getTestDataMap().get("Account Type");
		if (!internalTransfersPage.verifyTransferToValues(value)) {
			reportPass("The Account type: " + value + " is not displayed");
		} else
			reportFail("The Account type: " + value + " is displayed");

	}

	@And("^I should  see account in Transfer From Dropdown$")
	public void i_should_see_something_account_in_transfer_from_dropdown() throws Throwable {
		String value = jsonDataParser.getTestDataMap().get("Account Type");
		if (internalTransfersPage.verifyTransferFromValues(value))
			reportPass("The Account type: " + value + " is displayed");
		else {
			reportFail("The Account type: " + value + " is not displayed");
		}
	}

	@And("^I should  see account in Transfer To Dropdown$")
	public void i_should_see_something_account_in_transfer_to_dropdown() throws Throwable {
		String value = jsonDataParser.getTestDataMap().get("Account Type");
		if (internalTransfersPage.verifyTransferToValues(value))
			reportPass("The Account type: " + value + " is displayed");
		else {
			reportFail("The Account type: " + value + " is not displayed");
		}
	}

	@When("^I Select account in Transfer From dropdown in Transfer Between Webster Accounts Page$")
	public void i_select_account_something_in_transfer_from_dropdown_in_transfer_between_webster_accounts_page()
			throws Throwable {
		String acctno = jsonDataParser.getTestDataMap().get("Account");
		internalTransfersPage.selectTransferFromAcct(acctno);
	}

	@Then("^I should see account is auto populated in Transfer To Dropdown$")
	public void i_should_see_something_account_is_auto_populated_in_transfer_to_dropdown() throws Throwable {
		if (internalTransfersPage.getTransferToAcct().isEmpty()) {
			reportFail("The account is not auto populated in Transfer To dropdown");
		} else
			reportPass("The Account number: " + internalTransfersPage.getTransferToAcct()
					+ " is auto populated in Transfer To Dropdown");
	}

	@When("^I clear Transfer From dropdown in Transfer Between Webster Accounts Page$")
	public void i_clear_transfer_from_dropdown_in_transfer_between_webster_accounts_page() throws Throwable {
		try {
			internalTransfersPage.clearTransferFromAcct();
			reportPass("The Account number is cleared in Transfer From dropdown");
		} catch (Exception e) {
			reportFail("unavle to clear Account number in Transfer From dropdown");
		}
	}

	@Then("^I should see Transfer To drop down as blank in Transfer To Dropdown$")
	public void i_should_see_transfer_to_drop_down_as_blank_in_transfer_to_dropdown() throws Throwable {
		if (internalTransfersPage.getTransferToAcct().isEmpty())
			reportPass("The account cleared in Transfer To dropdown" + internalTransfersPage.getTransferToAcct());
		else {
			reportHardFail(
					"The Account is not cleared in Transfer To Dropdown" + internalTransfersPage.getTransferToAcct());
		}
	}

	@Then("^I should see Transfer from Error message")
	public void i_should_see_transfer_from_error_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("FromErr");
		if (internalTransfersPage.verifyFromErrMsg(message))
			reportPass("The Error message: " + message + "is successfully displayed");
		else
			reportFail("The Error message: " + message + "is not displayed");
	}

	@And("^I should see Transfer To Error message")
	public void i_should_see_transfer_to_error_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("ToErr");
		if (internalTransfersPage.verifyToErrMsg(message))
			reportPass("The Error message: " + message + "is successfully displayed");
		else
			reportFail("The Error message: " + message + "is not displayed");
	}

	@And("^I should see Transfer Amount Error message")
	public void i_should_see_transfer_amount_error_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("AmountErr");
		if (internalTransfersPage.verifyAmountErrMsg(message))
			reportPass("The Error message: " + message + "is successfully displayed");
		else
			reportFail("The Error message: " + message + "is not displayed");
	}

	@Then("^I should see Transfer Frequency Error message")
	public void i_should_see_transfer_frequency_error_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("FrequencyErr");
		if (internalTransfersPage.verifyFrequencyErrMsg(message))
			reportPass("The Error message: " + message + "is successfully displayed");
		else
			reportFail("The Error message: " + message + "is not displayed");
	}

	@And("^I should see Remaining Transfers  Error message")
	public void i_should_see_remaining_transfers_error_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("TransfersErr");
		if (internalTransfersPage.verifyRemainingTransfersErrMsg(message))
			reportPass("The Error message: " + message + "is successfully displayed");
		else
			reportFail("The Error message: " + message + "is not displayed");
	}

	@When("^I click on Edit button in Transfers Page$")
	public void i_click_on_edit_button_in_transfers_page() throws Throwable {
		try {
			internalTransfersPage.clickEditTransfer();
			reportPass("Clicked on Edit Button");
		} catch (Exception e) {
			reportFail("Failed to click on Edit button");
		}
	}
}
