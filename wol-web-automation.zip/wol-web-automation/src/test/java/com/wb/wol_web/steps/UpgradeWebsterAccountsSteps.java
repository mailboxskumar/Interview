package com.wb.wol_web.steps;

import java.util.HashMap;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.UpgradeWebsterAccountsPage;

import cucumber.api.java.en.Then;

public class UpgradeWebsterAccountsSteps extends ObjectBase {

	UpgradeWebsterAccountsPage upgradeWebsterAccountsPage = new UpgradeWebsterAccountsPage();
	Map<String,String> testDataMap1 = new HashMap<String,String>();
	String message = "";

	@Then("I select the from account radiobutton in Upgrade Webster Accounts")
	public void i_select_the_account_radiobutton_in_Upgrade_Webster_Accounts() {
		String accountName = jsonDataParser.getTestDataMap().get("FromAccount");
		String account = upgradeWebsterAccountsPage.selectAccountRadioButton(accountName);
		if (account != null)
			reportPass("Account: " + account + " is selected");
		else
			reportFail("Account: " + accountName + " is not selected or not presented");
	}

	@Then("I click on upgrade button of target Account")
	public void i_click_on_upgrade_button_of_Account() {
		String accountType = jsonDataParser.getTestDataMap().get("ToAccount");
		if (upgradeWebsterAccountsPage.selectAccountUpgradeButton(accountType))
			reportPass("Account: " + accountType + ": upgrade button is clicked");
		else
			reportFail("Account: " + accountType + ": upgrade button is not clicked");
	}

	@Then("I click on {string} button of Upgrade Webster Accounts page")
	public void i_click_on_button_of_Upgrade_Webster_Accounts_page(String btnName) {
		if (upgradeWebsterAccountsPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is Clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I click on {string} button of Verify Selection Lightbox")
	public void i_click_on_button_of_Verify_Selection_Lightbox(String btnName) {
		if (upgradeWebsterAccountsPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is Clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I click on {string} button in popup")
	public void and_I_click_on_button_in_popup(String btnName) {
		if (upgradeWebsterAccountsPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is Clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I click on {string} button of Read and Accept Terms page")
	public void i_click_on_button_of_Read_and_Accept_Terms_page(String btnName) {
		if (upgradeWebsterAccountsPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is Clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I verify the {string} lightbox with content")
	public void i_verify_the_lightbox_with_content(String txtHeading) {
		if (upgradeWebsterAccountsPage.verifyLightboxText(txtHeading))
			reportPass("Lightbox Heading: " + txtHeading + " is displayed");
		else
			reportFail("Lightbox Heading: " + txtHeading + " is not displayed");
	}

	@Then("I verify the {string} button in lightbox")
	public void i_verify_the_button_in_lightbox(String btnName) {
		if (upgradeWebsterAccountsPage.verifyButton(btnName))
			reportPass("Button : " + btnName + " is displayed");
		else
			reportFail("Button : " + btnName + " is not displayed");
	}

	@Then("I verify the disclosures in {string} page")
	public void i_verify_the_disclosures_in_page(String pageName) {
		 testDataMap1 = jsonDataParser.getTestDataMap();
		if (upgradeWebsterAccountsPage.verifyDisclosuresLinkText(testDataMap1))
			reportPass("Disclosures : " + testDataMap1.values().toString() + " is displayed");
		else
			reportFail("Disclosures : " + testDataMap1.values().toString() + " is not displayed");
	}

	@Then("I click on all the checkboxes")
	public void i_click_on_all_the_checkboxes() {
		if (upgradeWebsterAccountsPage.acceptAllCheckboxes())
			reportPass("Accepted the all checkboxes");
		else
			reportFail("Not Accepted the all checkboxes");
	}

	@Then("I verify process info text is displayed")
	public void i_verify_process_info_text_is_displayed() {
		testDataMap1 = jsonDataParser.getTestDataMap();
		if (upgradeWebsterAccountsPage.checkDisplay(testDataMap))
			reportPass("Text : " + testDataMap1.values().toString() + " is displayed");
		else
			reportFail("Text : " + testDataMap1.values().toString() + " is not displayed");
	}

	@Then("I verify the all the labels are displayed")
	public void i_verify_the_all_the_labels_are_displayed() {
		testDataMap1 = jsonDataParser.getTestDataMap();
		if (upgradeWebsterAccountsPage.verifyLabels(testDataMap1))
			reportPass("Labels : " + testDataMap1.values().toString() + " are displayed");
		else
			reportFail("Labels : " + testDataMap1.values().toString() + " is/are not displayed");
	}

	@Then("I verify the no accounts message")
	public void i_verify_the_no_accounts_message() {
		String message = jsonDataParser.getTestDataMap().get("Message");
		if (upgradeWebsterAccountsPage.checkNoAccountDisplayMessage(message))
			reportPass("Text : " + message + " is displayed");
		else
			reportFail("Text : " + message + " is not displayed");
	}

	@Then("I should not see from account radiobutton in Upgrade Webster Accounts")
	public void i_should_not_see_from_account_radiobutton_in_Upgrade_Webster_Accounts() {
		String accountName = jsonDataParser.getTestDataMap().get("FromAccount");
		if (!upgradeWebsterAccountsPage.verifyAccountRadioButton(accountName))
			reportPass("Account: " + accountName + " is not displayed");
		else
			reportFail("Account: " + accountName + " is displayed");
	}

	@Then("I verify the Upgrade Webster Accounts {string}")
	public void i_verify_the_Upgrade_Webster_Accounts_description_note(String labelName) {
		message = jsonDataParser.getTestDataMap().get(labelName);
		if (upgradeWebsterAccountsPage.verifyText(message, labelName))
			reportPass("Text: " + message + " is displayed");
		else
			reportFail("Text: " + message + " is not displayed");
	}

	@Then("I verify the {string} button in Upgrade Webster Accounts")
	public void i_verify_the_button_in_Upgrade_Webster_Accounts(String btnName) {
		if (upgradeWebsterAccountsPage.verifyButton(btnName))
			reportPass("Button : " + btnName + " is displayed in Upgrade Webster Accounts");
		else
			reportFail("Button : " + btnName + " is not displayed in Upgrade Webster Accounts");
	}

	@Then("I verify the Disclosure error text")
	public void i_verify_the_Disclosure_error_text() {
		message = jsonDataParser.getTestDataMap().get("ErrorText");
		if (upgradeWebsterAccountsPage.verifyDisclosureErrorText(message))
			reportPass("Text: " + message + " is displayed");
		else
			reportFail("Text: " + message + " is not displayed");
	}

	@Then("I click on More Info of {string} account")
	public void i_click_on_More_Info_of_account(String accountName) {
		if (upgradeWebsterAccountsPage.clickOnMoreInfoOfAccount(accountName))
			reportPass("Account : " + accountName + " is MoreInfo is clicked");
		else
			reportFail("Account : " + accountName + " is not MoreInfo is clicked");
	}

	@Then("I should be in the {string} Account page")
	public void i_should_be_in_the_Account_page(String pageName) {
		if (upgradeWebsterAccountsPage.verifyPageTitle(pageName))
			reportPass("Page Name : " + pageName + " is displayed");
		else
			reportFail("Page Name : " + pageName + " is not displayed");
	}

	@Then("I should be in the {string} Disclosure Lightbox")
	public void i_should_be_in_the_Disclosure_Lightbox(String pageName) {
		if (upgradeWebsterAccountsPage.verifyLightboxPageTitle(pageName))
			reportPass("Page Name : " + pageName + " is displayed");
		else
			reportFail("Page Name : " + pageName + " is not displayed");
	}

	@Then("I click on {string} button of Disclosure Lightbox")
	public void i_click_on_button_of_Disclosure_Lightbox(String btnName) {
		if (upgradeWebsterAccountsPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is Clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

}
