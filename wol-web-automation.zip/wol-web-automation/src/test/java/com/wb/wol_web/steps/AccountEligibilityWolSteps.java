package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AccountEligibilityWolPage;

import cucumber.api.java.en.Then;

public class AccountEligibilityWolSteps extends ObjectBase {

	AccountEligibilityWolPage accountEligibilityWolPage = new AccountEligibilityWolPage();

	@Then("I should navigate to {string} page in WOL")
	public void i_should_navigate_to_page_in_WOL(String pgTitle) {
		if (accountEligibilityWolPage.verifySetUpAcctFeaturesPgTitle(pgTitle))
			reportPass("Navigated to { " + pgTitle + " } page successfully");
		else
			reportFail("Failed to navigate { " + pgTitle + " } page");
	}

	@Then("verify {string} section should not present in setup accounts feature page")
	public void verify_section_should_not_present_in_setup_accounts_feature_page(String verifyText) {
		if (accountEligibilityWolPage.verifyCustOnlineProfile(verifyText))
			reportPass(" { " + verifyText + " } text is not present in Add/Manage webster accounts page");
		else
			reportFail(" { " + verifyText + " } text is presented in Add/Manage webster accounts page");
	}

}