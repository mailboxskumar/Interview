package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddBillPayeePage;
import com.wb.wol_web.pages.AddTaxPayeePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddTaxPayeeSteps extends ObjectBase {

	AddBillPayeePage addBillPayeePage = new AddBillPayeePage();
	AddTaxPayeePage addTaxPayeePage = new AddTaxPayeePage();

	@When("I click on Tax Group  and click Tax Payee name")
	public void i_click_on_Tax_Group_and_click_Tax_Payee_name() {
		try {
			addTaxPayeePage.selectTaxPayeeName(jsonDataParser.getTestDataMap().get("Group Name"),
					jsonDataParser.getTestDataMap().get("Payee Name"));
			reportPass("Clicked on Tax Payee link " + jsonDataParser.getTestDataMap().get("Payee Name")
					+ " to add a new Tax Payee");
		} catch (Exception e) {
			reportFail("Failed to click on Tax Payee Link" + jsonDataParser.getTestDataMap().get("Payee Name"));
		}
	}

	@When("I Enter new Tax Payee details")
	public void i_Enter_new_Tax_Payee_details() {
		addTaxPayeePage.enterTaxPayeeNickName();
		addTaxPayeePage.selectTaxPayeeType(jsonDataParser.getTestDataMap().get("Payee Type"));
		if (addTaxPayeePage.enterTaxPayeeID(jsonDataParser.getTestDataMap().get("TIN")))
			reportPass("Entered tax payee details like TIN: " + jsonDataParser.getTestDataMap().get("TIN")
					+ " in add a new tax payee Page");
		else
			reportFail("Failed to enter Tax ID number in add a new tax payee page");
	}

	@When("^Select Tax Disclosure Agreement check box$")
	public void select_tax_disclosure_agreement_check_box() throws Throwable {
		addTaxPayeePage.selectDisclosureCheckbox();
	}

	@And("^Click on Continue Button in Tax Payees page$")
	public void click_on_continue_button_in_tax_payees_page() throws Throwable {
		try {
			addTaxPayeePage.clickTaxContinueButton();
			reportPass("Clicked on Continue button");
		} catch (Exception e) {
			reportFail("Failed to click on continue button");
		}
	}

	@Then("^I should be in \"([^\"]*)\" page in Add a New Tax Payee functionality$")
	public void i_should_be_in_something_page_in_adda_new_tax_payee_functionality(String pageTitle) throws Throwable {
		if (addTaxPayeePage.verifyAddTaxPayeePageTitle(pageTitle))
			reportPass("The Page Title:" + pageTitle + " is displaying successfully");
		else
			reportFail("The Page Title:" + pageTitle + " is not displaying");
	}

	@Then("^I should be in Error page \"([^\"]*)\" in Add a New Tax Payee functionality$")
	public void i_should_be_in_error_something_page_in_add_a_new_tax_payee_functionality(String pageTitle)
			throws Throwable {
		if (addTaxPayeePage.verifyTaxPayeeErrPageTitle(pageTitle))
			reportPass("The Page Title:" + pageTitle + " is displaying successfully");
		else
			reportFail("The Page Title:" + pageTitle + " is not displaying");
	}

	@Then("Unauthorized Error Message should be displayed")
	public void unauthorized_Error_Message_should_be_displayed() {
		String message = jsonDataParser.getTestDataMap().get("Error Msg");
		if (addTaxPayeePage.verifyTaxPayeeErrMsgViewOnly(message))
			reportPass("The Error Message:" + message + " is displaying successfully");
		else
			reportFail("The Error Message:" + message + " is not displaying");
	}

	@Then("Error message should be displayed in Add a New Tax Payee Page")
	public void error_message_should_be_displayed_in_Add_a_New_Tax_Payee_Page() {
		if (addTaxPayeePage.verifyTaxPayeeErrMsgDisclosure(jsonDataParser.getTestDataMap().get("Error Msg")))
			reportPass("The Error Message:" + jsonDataParser.getTestDataMap().get("Error Msg")
					+ " is displaying successfully");
		else
			reportFail("The Error Message:" + jsonDataParser.getTestDataMap().get("Error Msg") + " is not displaying");
	}

	@Then("^Tooltip Message should be displayed in Add a Tax Payee Page$")
	public void tooltip_message_something_should_be_displayed() throws Throwable {
		if (addTaxPayeePage.verifyTooltipTaxPayee(jsonDataParser.getTestDataMap().get("Tooltip")))
			reportPass("The Tooltip Pay From Which Accounts content is displaying properly");
		else
			reportFail("The Tooltip Pay From Which Accounts content is not displaying properly");
	}

	@Then("^Tax ID Error message \"([^\"]*)\" should be displayed in Add Tax Payee Page$")
	public void tax_id_error_message_something_should_be_displayed_in_add_tax_payee_page(String message)
			throws Throwable {
		if (addTaxPayeePage.verifyTaxPayeeErrMsgDisclosure(message))
			reportPass("The Error Message:" + message + " is displaying successfully");
		else
			reportFail("The Error Message:" + message + " is not displaying");
	}

	@Then("^Pay From Account Error message \"([^\"]*)\" should be displayed in Add Tax Payee Page$")
	public void pay_from_account_error_message_something_should_be_displayed_in_add_tax_payee_page(String message)
			throws Throwable {
		if (addTaxPayeePage.verifyTaxPayeeErrMsgDisclosure(message))
			reportPass("The Error Message:" + message + " is displaying successfully");
		else
			reportFail("The Error Message:" + message + " is not displaying");
	}

	@Then("^Duplicate Tax Payee Error message \"([^\"]*)\" should be displayed$")
	public void duplicate_tax_payee_error_message_something_should_be_displayed(String message) throws Throwable {
		if (addTaxPayeePage.verifyTaxPayeeErrMsgDisclosure(message))
			reportPass("The Error Message:" + message + " is displaying successfully");
		else
			reportFail("The Error Message:" + message + " is not displaying");
	}

	@And("^I should be in \"([^\"]*)\" Page When I click on here link in Add Tax Payee Page$")
	public void i_should_be_in_page_when_i_click_on_here_link_in_add_tax_payee_page(String pageTitle) throws Throwable {
		if (addTaxPayeePage.verifyTaxAgncyLnknavigation(pageTitle))
			reportPass("Tax Agency Information page is displaying successfully");
		else
			reportFail("Tax Agency Information page  is not displaying");
	}
}
