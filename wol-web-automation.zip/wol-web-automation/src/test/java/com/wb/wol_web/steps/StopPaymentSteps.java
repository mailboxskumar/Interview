package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.StopPaymentPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StopPaymentSteps extends ObjectBase {

	StopPaymentPage stopPaymentPage = new StopPaymentPage();

	public String checkNumber = "";

	@When("I enter check number")
	public void i_enter_check_number() {
		checkNumber = stopPaymentPage.enterCheckNumber();
		if (checkNumber != null)
			reportPass("Entered the check number " + checkNumber);
		else
			reportFail("Not entered the check number");
	}

	@Then("I should see error message {string}")
	public void i_should_see_error_message(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (stopPaymentPage.duplicateCheckNumberError(message))
			reportPass("Message: " + message + " is dispayed");
		else
			reportFail("Message: " + message + " is not dispayed");
	}

	@Then("I should see message of {string}")
	public void i_should_see_message_of(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (stopPaymentPage.confirmationMessage(message))
			reportPass("Message: " + message + " is displayed");
		else
			reportFail("Message: " + message + " is not displayed");
	}

	@When("I click on {string} button of {string} page")
	public void i_click_on_button_of_page(String btnContinue, String pageName) {
		if (stopPaymentPage.clickOnContinueButton())
			reportPass("Clicked on " + btnContinue + " button of " + pageName + " page ");
		else
			reportHardFail("Clicked on " + btnContinue + " button of  " + pageName + " page ");
	}

	@When("I enter same check number again")
	public void i_enter_same_check_number_again() {
		checkNumber = stopPaymentPage.enterCheckNumberAgain();
		if (checkNumber != null)
			reportPass("Entered the check number: " + checkNumber);
		else
			reportFail("Not entered the check number");
	}

	@Then("I should see error message of {string}")
	public void i_should_see_error_message_of(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (stopPaymentPage.getEnterCheckNumberMessage(message))
			reportPass("Message: " + message + " is dispayed");
		else
			reportFail("Message: " + message + " is not dispayed");
	}

	@Then("I should be in the {string} page of {string}")
	public void i_should_be_in_the_page_of(String pageHeading, String flowName) {
		if (stopPaymentPage.checkPageTitle(pageHeading, flowName))
			reportPass("redirected to " + pageHeading + " page");
		else
			reportFail("Not redirected to " + pageHeading + " page");
	}

	@Then("I verify Note of {string}")
	public void i_verify_Note_of(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (stopPaymentPage.checkNoteMessage(message))
			reportPass("Message: " + message + " is dispayed");
		else
			reportFail("Message: " + message + " is not dispayed");
	}
}
