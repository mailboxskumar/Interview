
package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.RunBatchJobPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

public class RunBatchJobSteps extends ObjectBase {

	RunBatchJobPage runBatchJobPage = new RunBatchJobPage();

	@When("^I select the \"([^\"]*)\" job from the list$")
	public void i_select_the_job(String job) {
		if (runBatchJobPage.selectTheBatchJob(job))
			reportPass("Selected the job " + job + " from the list");
		else
			reportFail("Failed to select the job " + job + " from the list");

	}

	@And("^I click on the run job button$")
	public void i_click_on_button() {
		if (runBatchJobPage.clickOnRubJobButton())
			reportPass("clicked on the run job button");
		else
			reportFail("Failed to click on the run job button");

	}

	@And("^I wait for the Job Submitted status$")
	public void i_wait_for_status() {
		if (runBatchJobPage.checkForSubmitStatus())
			reportPass("Job Submitted status is displayed");
		else
			reportFail("Job Submitted status is not displayed");
	}

	@When("I load the batchjob URL")
	public void i_load_batchjob_url() {
		try {
			runBatchJobPage.loadBatchJobURL();
		} catch (Exception e) {
			reportFail("Failed to load the batch job url");
		}
	}
}
