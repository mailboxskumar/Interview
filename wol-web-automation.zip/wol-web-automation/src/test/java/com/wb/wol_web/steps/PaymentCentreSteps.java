package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.PaymentCenterPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class PaymentCentreSteps extends ObjectBase {

	PaymentCenterPage paymentCenterPage = new PaymentCenterPage();

	@When("^I click on \"([^\"]*)\" button$")
	public void i_click_on_button(String btnName) throws Throwable {
		if (paymentCenterPage.ClickOnButton(btnName)) {
			reportPass("Clicked on the button " + btnName);
		} else {
			reportFail("Could not click on the button " + btnName);
		}
	}

	@And("^Check for the error message for \"([^\"]*)\"$")
	public void check_for_error_message(String errorType) {
		String msg = jsonDataParser.getTestDataMap().get(errorType);
		if (paymentCenterPage.checkForNoPayeeErrorMsg(msg, errorType))
			reportPass("Error message " + msg + "is present");
		else {
			reportHardFail("Error message " + msg + "is not present");
		}
	}

	@Then("^I should get the heading \"([^\"]*)\" in lightbox$")
	public void i_should_get_the_heading(String pageTitle) throws Throwable {
		if (paymentCenterPage.verifyForTheMessageInLightBox(pageTitle))
			reportPass("Reached the " + pageTitle + " page");
		else {
			reportHardFail("Heading not found " + pageTitle);
		}
	}

	@Then("^I select the  \"([^\"]*)\" in PayFrom dropdown$")
	public void select_the_Account_in_payFrom(String accountType) {
		try {
			paymentCenterPage.selectTheAccountTypeFromPayFromDropDown(accountType);
			reportPass("Selected " + accountType + " in payfrom dropdown");
		} catch (Exception e) {
			reportHardFail("Failed to select the account in payfrom dropdown");
		}
	}

	public void i_should_get_the_message(String strMsg) throws Throwable {
		if (paymentCenterPage.verifyForTheMessage(strMsg))
			reportPass("Found the message " + strMsg);
		else {
			reportHardFail("Message not found " + strMsg);
		}

	}

	@Then("^Title of calendar should change to \"([^\"]*)\" month$")
	public void title_of_calendar_should_change_to_month(String arg1) throws Throwable {
		if (paymentCenterPage.checkCalendarTitle(arg1)) {
			reportPass("Calendar title changed correctly on clicking " + arg1 + " button");
		} else {
			reportFail("Calendar title is displayed wrong on clicking " + arg1 + " button");

		}
	}

	@Then("^Add Payment dialogue box should appear$")
	public void add_Payment_dialogue_box_should_appear() throws Throwable {
		if (paymentCenterPage.checkForAddPaymentDialogueBox())
			reportPass("Dialog box to add or manage Payments  appears on clicking the calendar date");
		else {
			reportHardFail("Dialog box to add or manage Payments is not displayed ");
		}
	}

	@Then("^Add Payment dialogue box should not appear$")
	public void add_Payment_dialogue_box_should_not_appear() throws Throwable {
		if (!paymentCenterPage.checkForAddPaymentDialogueBox())
			reportPass("Dialog box to add or manage Payments  didn't appear for viewonly user");
		else {
			reportHardFail("Dialog box to add or manage Payments is displayed ");
		}
	}

	@Then("^I should get the title \"([^\"]*)\" in the page$")
	public void i_should_get_the_title(String actionType) {
		if (paymentCenterPage.checkPageTitleInUpdatePaymentDetails(actionType))
			reportPass("Page Title is same as " + actionType);
		else {
			reportHardFail("Page Title is not same as " + actionType);
		}
	}

	@When("^I click on active dates in the calendar for \"([^\"]*)\" payment$")
	public void i_click_on_active_dates_in_the_calendar_for_payment(String arg1) throws Throwable {
		String date = paymentCenterPage.clickOnActiveDates(arg1);
		if (!date.equals(""))
			reportPass("Clicked on the date " + date);
		else
			reportHardFail("Failed to click on the date");
	}

	@When("I check that the calendar is not eligible for clicking")
	public void i_check_that_the_calendar_is_not_eligible_for_clicking() {
		if (paymentCenterPage.checkForActiveDates())
			reportPass("Calendar is not active");
		else
			reportHardFail("Calendar is active and is eligible to click on date link");
	}

	@When("^I click on the dates with existing payments in \"([^\"]*)\"$")
	public void i_click_on__existing_payments_date(String paymentdate) throws Throwable {
		String date = paymentCenterPage.clickOnDatesWithPayments(paymentdate);
		if (!date.equals(""))
			reportPass("Clicked on the date " + date + " with existing payment");
		else
			reportHardFail("Failed to click on the date with existing payment");
	}

	@When("^I click on the  Action Menu for the existing payment \"([^\"]*)\"$")
	public void i_click_on_the_Action_Menu_for_the_existing_payment(String arg1) throws Throwable {
		try {
			paymentCenterPage.clickOnActionIconForExistingPayments(jsonDataParser.getTestDataMap().get(arg1));
			reportPass("Clicked on the pyament details action menu icon");
		} catch (Exception e) {
			reportFail("Failed to click the pyament details action menu icon");
		}
	}

	@Then("^I should be in Make a New Payment page$")
	public void i_shoud_be_make_new_payment_page() {
		if (paymentCenterPage.checkForMakeNewPaymentPage()) {
			reportPass("Reached the page with heading Make a New payment");
		} else {
			reportFail("Could not reach the page with heading Make a New payment");
		}
	}

	@When("^I click on \"([^\"]*)\" button in update payment details page$")
	public void i_click_on_button_in_update_payment_details_page(String arg1) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("Delete"))
				paymentCenterPage.ClickOnButton("Delete");
			else if (arg1.equalsIgnoreCase("Update"))
				paymentCenterPage.ClickOnButton("Update");
			else if (arg1.equalsIgnoreCase("Verification Page Update"))
				paymentCenterPage.ClickOnButton("Verification Page Update");
			reportPass("Clicked on the button " + arg1 + " in update payment details page");
		} catch (Exception e) {
			reportHardFail("Failed to click on the button " + arg1);
		}
	}

	@When("^I click on \"([^\"]*)\" button in delete Pending Payment Verification page$")
	public void i_click_on_button_in_delete_Pending_Payment_Verification_page(String arg1) throws Throwable {
		try {
			if (paymentCenterPage.ClickOnButton("Delete in Verification Page"))
				reportPass("Clicked on the delete button in Pending Verification Page ");
			else
				reportFail("Failed to click on the delete button in verificatin page");
		} catch (Exception e) {
			reportHardFail("Failed to click on the button " + arg1);
		}
	}

	@Then("^Verify if the message \"([^\"]*)\" is present in dialogue box$")
	public void verify_if_the_message_is_present_in_dialogue_box(String strMsg) throws Throwable {

		try {
			if (paymentCenterPage.verifyForTheMessage(strMsg))
				reportPass("Message " + strMsg + " is found");
			else
				reportFail("Message " + strMsg + " is not  found");
		} catch (Exception e) {
			reportFail(strMsg + " not found ");
		}
	}

	@When("^I click on continue button in Quick Pay Verification page$")
	public void i_click_on_continue_button_in_Quick_Pay_Verification_page() throws Throwable {

		if (paymentCenterPage.clickOnContinueButton())
			reportPass("Clicked on the continue button");
		else {
			reportFail("Failed to click on the continue button in Quick Pay Verification page");
		}
	}

	@When("^I enter the invalid data \"([^\"]*)\" in amount field$")
	public void i_enter_the_invalid_data_in_amount_field(String arg1) throws Throwable {
		try {
			paymentCenterPage.enterInvalidDataInAmountField(jsonDataParser.getTestDataMap().get(arg1));
			reportPass("Entered the invalid data " + jsonDataParser.getTestDataMap().get(arg1) + " in amount field");
		} catch (Exception e) {
			reportHardFail("Failed to enter invalid data in amount field " + arg1);
		}
	}

	@Then("^I should get the error message \"([^\"]*)\" in lightbox$")
	public void i_should_get_the_error_message(String errorMsg) throws Throwable {

		if (paymentCenterPage.checkForErrorMessage(jsonDataParser.getTestDataMap().get(errorMsg)))
			reportPass("Error message " + errorMsg + " is displayed");
		else
			reportFail("Error message " + errorMsg + " is not displayed");

	}

	@Then("^I enter the following details of the payment$")
	public void i_enter_the_following_details_of_the_payment(DataTable table) throws Throwable {
		List<Map<String, String>> paymentDetails = table.asMaps(String.class, String.class);
		try {
			paymentCenterPage.enterPaymentDetails(paymentDetails);
			reportPass("Entered the details as " + paymentDetails);
		} catch (Exception e) {
			reportHardFail("Falied to enter details of the payment");
		}
	}

	@Then("^I enter the details of the payment retrieved from JSON$")
	public void i_enter_the_following_details_of_the_payment_from_JSON() throws Throwable {
		List<Map<String, String>> paymentDetailsFromJSON = new ArrayList<Map<String, String>>();
		try {
			paymentDetailsFromJSON.add(jsonDataParser.getTestDataMap());
			paymentCenterPage.enterPaymentDetails(paymentDetailsFromJSON);

			reportPass("Entered the details as " + paymentDetailsFromJSON);
		} catch (Exception e) {
			reportHardFail("Falied to enter details of the payment");
		}
	}

	@Then("^I check the payment details displayed$")
	public void i_check_payment_details() throws Throwable {
		List<Map<String, String>> paymentDetailsFromJSON = new ArrayList<Map<String, String>>();
		paymentDetailsFromJSON.add(jsonDataParser.getTestDataMap());
		if (paymentCenterPage.checkPaymentDetails(paymentDetailsFromJSON))
			reportPass("Paymet details are displayed correct ");
		else
			reportFail("Payment details are not displayed correct");
	}

	@Then("^I should get the error message \"([^\"]*)\" for PayTo dropdown$")
	public void check_for_payTo_error_message(String msg) {
		String errorMsg = jsonDataParser.getTestDataMap().get(msg);
		if (paymentCenterPage.checkForErrorMessagePayToDropDown(errorMsg))
			reportPass("Error message " + errorMsg + " is present");
		else
			reportFail("Error message " + errorMsg + " is  not  present");
	}

	@Then("^I change the payment frequency to \"([^\"]*)\"$")
	public void i_change_the_payment_frequency_to(String frequecyType) throws Throwable {

		try {
			paymentCenterPage.changePaymentFrequency(frequecyType);
		} catch (Exception e) {
			reportHardFail("Failed to change the payment frequency");
		}
	}

	@Then("^I should get the message for \"([^\"]*)\"$")
	public void i_should_get_the_message_for_for(String msgType) throws Throwable {
		String lookFor = jsonDataParser.getTestDataMap().get(msgType);
		if (paymentCenterPage.checkTheMessageInPage(msgType, lookFor))
			reportPass("Message " + lookFor + " is found");
		else {
			reportFail("Message " + lookFor + " is not found");
		}
	}

	@Then("^Verify if the following bill details are present in the page$")
	public void verify_if_the_following_bill_details_are_present_in_the_page(DataTable billDetails) throws Throwable {
		List<String> list = billDetails.asList(String.class);
		List<String> listCol = new ArrayList<String>();
		try {
			for (String eachCol : jsonDataParser.getTestDataMap().get(list.get(0)).split(",")) {
				listCol.add(eachCol);
			}
			String colPresent = paymentCenterPage.checkTheColumnsInBillPayeeDetailsPage(listCol);
			if (colPresent.equals(""))
				reportPass("Bill details are present in the page");
		} catch (Exception e) {
			reportFail("Failed to verify the bill details labels");
		}
	}

	@Then("^A dialog box should appear with information about \"([^\"]*)\" payment$")
	public void check_for_disclosure_check_box(String paymentType) {
		if (paymentCenterPage.checkForDisclosureDialogBoxes(paymentType))
			reportPass("Dialog box for disclosure is displayed for " + paymentType + " payment");
		else {
			reportHardFail("Dialog box for disclosure is not displayed for " + paymentType + " payment");
		}
	}

	@And("^I close the dialog box for \"([^\"]*)\" payment$")
	public void close_for_disclosure_check_box(String paymentType) throws InterruptedException {
		paymentCenterPage.closeForDisclosureDialogBoxes(paymentType);
	}

	@When("^I click on \"([^\"]*)\" button for the payment \"([^\"]*)\"$")
	public void i_click_on_button_for_the_payment(String actionType, String payeeName) {
		try {
			paymentCenterPage.clickOnEditOrDeletePayment(actionType, jsonDataParser.getTestDataMap().get(payeeName));
			reportPass("Clicked on the button " + actionType);
		} catch (Exception e) {
			reportHardFail("Failed to " + actionType + " the payment");
		}
	}

	@When("^I click on update payment button in lightbox$")
	public void i_click_update_payment_button() {
		if (paymentCenterPage.clickOnUpdatePaymentLightBox())
			reportPass("Clicked on update button in lightbox");
		else
			reportHardFail("Could not click on update button in lightbox");
	}

	@When("I click on active dates in future for getting alert before the delivery date")
	public void i_click_on_active_dates_in_future_for_getting_alert_before_day() {
		try {
			String date = paymentCenterPage
					.clickOnFutureDatesForAlert(Integer.parseInt(jsonDataParser.getTestDataMap().get("Days")));
			reportPass("Clicked on the date " + date);
		} catch (Exception e) {
			reportHardFail("Could not click on the future date for payment alert");
		}
	}

	@Then("^I select the number of days before delivery date to get the alert$")
	public void i_select_no_of_days_prior_to_delivery_date_the_alerts_should_start_as() throws Throwable {
		if (paymentCenterPage.selectFromDaysBeforeAlertDropDown(jsonDataParser.getTestDataMap().get("Days"))) {
			reportPass("Select " + jsonDataParser.getTestDataMap().get("Days")
					+ " days from delivery date dropdown to get the alert");
		} else
			reportFail("Falied to select " + jsonDataParser.getTestDataMap().get("Days")
					+ " days from delivery date dropdown");
	}
}
