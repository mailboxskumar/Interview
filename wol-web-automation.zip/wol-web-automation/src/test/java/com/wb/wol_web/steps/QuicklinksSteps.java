package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.QuickLinksPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class QuicklinksSteps extends ObjectBase {

	QuickLinksPage quickLinksPage = new QuickLinksPage();

	@And("^I check only four links are displayed in quicklinks$")
	public void quicklinks_size() {
		String quicklinks = quickLinksPage.checkQuickLinkSize();
		if (!quicklinks.equals("")) {
			reportPass("QuickLinks present are " + quicklinks);
		} else {
			reportFail("No QuickLinks  are present" + quicklinks);
		}

	}

	@When("^I click on the \"([^\"]*)\" button in financial summary page$")
	public void I_click_on_button_in_summary_page(String btnName) throws Exception {
		if (quickLinksPage.clickOnTheButton(btnName)) {
			reportPass("Clicked on the button " + btnName);
		} else {
			reportHardFail("Failed to click on the button " + btnName);
		}
	}

	@Then("I should check for the business order of the links {string} for {string}")
	public void i_should_check_for_the_business_order_of_the_links_for(String links, String userType) {
		if (quickLinksPage.checkTheBusinessOrderForLinks(userType, jsonDataParser.getTestDataMap().get(links))) {
			reportPass("Links are displayed in expected business order");
		} else {
			reportFail("Links are not displayed in expected business order");
		}
	}

	@Then("^I should see a lightbox popup for quicklinks$")
	public void i_should_get_lightbox_popup() {
		if (quickLinksPage.checkForLightBox()) {
			reportPass("Pop up is displayed on clicking edit button");
		} else
			reportFail("Pop up is displayed on clicking edit button");
	}

	@And("^Check if the \"([^\"]*)\" buttons are displayed$")
	public void check_if_the_buttons_are_displayed(String buttons) throws Throwable {
		try {
			if (quickLinksPage.checkForButtonsDisplayed("Cancel"))
				reportPass("Cancel button is presentin edit dialogue box  ");
			else
				reportFail("Cancel button is not found in edit dialogue box");
			if (quickLinksPage.checkForButtonsDisplayed("Submit"))
				reportPass("Submit button is present in edit dialogue box ");
			else
				reportFail("Submit button is not found in edit dialogue box");
			if (quickLinksPage.checkForButtonsDisplayed("DeselectAll"))
				reportPass("DeselectAll button is present in edit dialogue box ");
			else
				reportFail("DeselectAll button is not found in edit dialogue box");
			if (quickLinksPage.checkForButtonsDisplayed("Close"))
				reportPass("Close button is present in edit dialogue box");
			else
				reportFail("Close button is not found in edit dialogue box");

		} catch (Exception e) {
			reportFail("Exception in checking element presence ");
		}
	}

	@Then("^I close the lightbox for quicklinks$")
	public void i_close_the_lightbox_for_quicklinks() throws Throwable {

		quickLinksPage.clickOnTheButton("LightBoxClose");
	}

	@Then("^I check for the message \"([^\"]*)\" in FinancialSummary$")
	public void i_check_for_the_message_as_in_FinancialSummary(String msgType) throws Throwable {
		if (quickLinksPage.CheckForTheMessage(jsonDataParser.getTestDataMap().get(msgType), msgType))
			reportPass("Message is present  " + jsonDataParser.getTestDataMap().get(msgType));
		else {
			reportFail("Message is not present  " + jsonDataParser.getTestDataMap().get(msgType));

		}
	}

	@And("^check that no quick link is disabled to select$")
	public void check_no_link_is_disabled() {
		if (quickLinksPage.checkNoLinksAreDisabled())
			reportPass("All the links are enabled to select");
		else {
			reportFail("Links are disabled to select");
		}
	}

	@Then("^Check if all the qucik links for \"([^\"]*)\" user are present$")
	public void check_if_all_the_qucik_links_for_user_are_present(String userType) throws Throwable {

		String links = quickLinksPage.checkLinkNamesAreCorrect(userType, testDataMap);
		if (!links.equals(null))
			reportPass("Links present in the edit light box are" + links);

		else
			reportFail("Links are not present in the edit light box");
	}

	@And("^I check if the small talk container is positioned below  QuickLinks container$")
	public void i_check_if_the_samll_talk_container() {
		if (quickLinksPage.checkTheSmallTalkContainerPosition())
			reportPass("Small Talk Container is positioned below the Quick LInk Container");
		else {
			reportFail("Small Talk Container is not positioned below the Quick LInk Container");
		}
	}

	@Then("I select the {string} links from the quicklinks list")
	public void i_select_the_links_from_the_quicklinks_list(String links) {
		try {
			quickLinksPage.clickOnTheLinks(jsonDataParser.getTestDataMap().get(links));
			reportPass("selected the links " + jsonDataParser.getTestDataMap().get(links));
		} catch (Exception e) {
			reportFail("Failed to selcet the links due to the error " + e.getMessage());
		}
	}

	@Then("I deselect the {string} links from the quicklinks list")
	public void i_deselect_the_links_from_the_quicklinks_list(String links) {
		try {
			quickLinksPage.clickOnTheLinks(jsonDataParser.getTestDataMap().get(links));
			reportPass("Deselected the links " + jsonDataParser.getTestDataMap().get(links));
		} catch (Exception e) {
			reportFail("Failed to deselcet the links due to the error ");
		}
	}

	@Then("All the other links should be disabled to select")
	public void all_the_other_links_should_be_disabled_to_select() {
		if (quickLinksPage.getTheSizeOfDisabledLinks() == 13)
			reportPass("All the other 13 links are disabled");
		else {
			reportFail("Only " + quickLinksPage.getTheSizeOfDisabledLinks() + " links are disabled in edit light box");
		}

	}

	@Then("I should get the message for {string} when redirected from quicklinks page")
	public void i_should_get_the_message_for_as(String errorType) {
		if (quickLinksPage.checkTheErrorMessageOnClickingLinks(errorType,
				jsonDataParser.getTestDataMap().get(errorType)))
			reportPass("Got the message " + jsonDataParser.getTestDataMap().get(errorType));
		else {
			reportFail("Message " + jsonDataParser.getTestDataMap().get(errorType) + " is not found");
		}
	}

	@Then("I should see all the {string} in summary page")
	public void i_should_see_all_the_in_summary_page(String links) throws Exception {
		String qLinkspresent = quickLinksPage
				.checkTheLinkNamesInSummaryPage(jsonDataParser.getTestDataMap().get(links));
		if (!qLinkspresent.equals(""))
			reportPass("Links which are present in summary page are " + qLinkspresent);
		else
			reportFail("Links  are not present in summary page are ");
	}

	@When("I click on the link {string} from summary page")
	public void i_click_on_the_link_from_summary_page(String link) throws Exception {
		if (quickLinksPage.clickOnTheLinksInSummaryPage(link)) {
			reportPass("Clicked on the link " + link + " in summary page ");
		} else {
			reportFail("Failed to click on the link " + link + " in summary page");
		}
	}

	@Then("I should see no quick links in summary page")
	public void i_should_see_no_quick_links_in_summary_page() {
		if (quickLinksPage.checkThatNoQuickLinksInSummaryPage())
			reportPass("No quick links  are present in the summary page");
		else {
			reportFail("Qucik links  are present in the summary page");
		}

	}
}
