package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.SwitchTestingPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SwitchTestingSteps extends ObjectBase {

	SwitchTestingPage switchTestingPage = new SwitchTestingPage();

	public String accountNumber = "";
	public String confirmationNumber = "";

	@Then("I should see the confirmation number of transfer")
	public void i_should_see_the_confirmation_number_of_transfer() {
		confirmationNumber = switchTestingPage.getConfirmationNumber();
		if (confirmationNumber != null)
			reportPass("Confirmation Number: " + confirmationNumber + " is displayed");
		else
			reportFail("Confirmation Number is displayed as null");
	}

	@Then("I verify the cofirmation number is displayed in webcom same as in WOL")
	public void i_verify_the_cofirmation_number_is_displayed_in_webcom_same_as_in_WOL() {
		confirmationNumber = switchTestingPage.verifyConfirmationNumber();
		if (accountNumber != null)
			reportPass("Confirmation Number: " + confirmationNumber + " is displayed");
		else
			reportFail("Confirmation Number is not displayed same as in WOL application");
	}

	@Then("I verify the cofirmation number is displayed in webcom transfer history same as in WOL")
	public void i_verify_the_cofirmation_number_is_displayed_in_webcom_transfer_history_same_as_in_WOL() {
		confirmationNumber = switchTestingPage.verifyTransferHistoryConfirmationNumber();
		if (confirmationNumber != null)
			reportPass("Confirmation Number: " + confirmationNumber + " is displayed");
		else
			reportFail("Confirmation Number is not displayed same as in WOL application");
	}

	@Then("I verify the cofirmation number is not displayed in webcom same as in WOL")
	public void i_verify_the_cofirmation_number_is_not_displayed_in_webcom_same_as_in_WOL() {
		confirmationNumber = switchTestingPage.verifyConfirmationNumber();
		if (confirmationNumber == null)
			reportPass("Confirmation Number: " + confirmationNumber + " is not displayed as expected");
		else
			reportFail("Confirmation Number:" + confirmationNumber + " is displayed same as in WOL application");
	}

	@When("I select the {string} in Update mode of account")
	public void i_select_the_in_Update_mode_of_account(String listValue) {
		if (switchTestingPage.selectUpdateMode(listValue))
			reportPass("Account Update mode of Value: " + listValue + " is selected");
		else
			reportFail("Account Update mode of Value: " + listValue + " is not selected");
	}

	@When("I click on {string} button of update non-webster account page")
	public void i_click_on_button_of_update_non_webster_account_page(String btnName) {
		if (switchTestingPage.clickOnButton(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I should see the {string} message")
	public void i_should_see_the_message(String message) {
		if (switchTestingPage.checkForMessage(message))
			reportPass("Message: " + message + " is displayed");
		else
			reportFail("Message: " + message + " is not displayed");
	}

	@Then("I should see the account number in message")
	public void i_should_see_the_account_number_in_message() {
		if (switchTestingPage.checkForMessage(accountNumber))
			reportPass("Account: " + accountNumber + " is displayed");
		else
			reportFail("Account: " + accountNumber + " is not displayed");
	}

	@Then("I store the account number")
	public void i_store_the_account_number() {
		accountNumber = switchTestingPage.captureAccountNumber();
		if (accountNumber.length() > 0)
			reportPass("Account: " + accountNumber + " is displayed");
		else
			reportFail("Account: " + accountNumber + " is not displayed");
	}

	@Then("I verify the account is not present in {string} account list")
	public void i_verify_the_account_is_not_present_in_account_list(String labelName) {
		if (switchTestingPage.checkForAccountNotPresent(accountNumber, labelName))
			reportPass("Account: " + accountNumber + " is not displayed");
		else
			reportFail("Account: " + accountNumber + " is displayed");
	}
}