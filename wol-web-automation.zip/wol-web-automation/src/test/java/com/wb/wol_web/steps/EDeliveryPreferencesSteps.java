package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.EDeliveryPreferencesPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EDeliveryPreferencesSteps extends ObjectBase {

	EDeliveryPreferencesPage eDeliveryPreferencesPage = new EDeliveryPreferencesPage();
	ArrayList<String> listValues = new ArrayList<String>();

	@Then("I verify the {string} is {string}")
	public void i_verify_the_is(String accNumber, String accCheckBoxSts) {
		accNumber=jsonDataParser.getTestDataMap().get(accNumber);
		if (eDeliveryPreferencesPage.verifyAccountCheckBoxStatus(accNumber, accCheckBoxSts))
			reportPass(accNumber + " Account number is " + accCheckBoxSts);
		else
			reportFail(accNumber + " Account number is not " + accCheckBoxSts);
	}

	@When("I select the {string} is {string}")
	public void i_select_the_is(String accountNumber, String accCheckBoxSts) {
		if (eDeliveryPreferencesPage.verifyAccountCheckBoxStatus(accountNumber, accCheckBoxSts))
			reportPass(accountNumber + "is " + accCheckBoxSts + " in eDelivery Preference Page");
		else
			reportFail(accountNumber + " is not " + accCheckBoxSts + " in eDelivery Preference Page");
	}

	@When("I click on Continue button in eDelivery Preferences page")
	public void i_click_on_Continue_button_in_eDelivery_Preferences_page() {
		if (eDeliveryPreferencesPage.clickOnContinueBtnIneDeliveryPrefPage())
			reportPass("Clicked on Continue button in eDelivery Preferences Page");
		else
			reportFail("Unable to clicked on Continue button in eDelivery Preferences Page");
	}

	@Then("I verify the messages as {string}")
	public void i_verify_the_messages_as(String eDeliveryConfMsg) {
		eDeliveryConfMsg = jsonDataParser.getTestDataMap().get(eDeliveryConfMsg);
		if (eDeliveryPreferencesPage.verifyeDeliveryPrefConfMsg(eDeliveryConfMsg))
			reportPass(eDeliveryConfMsg + " message is displayed");
		else
			reportFail(eDeliveryConfMsg + " message is not displayed");
	}

	@Then("I verify the Other Deposit Account Notices check box displayed")
	public void i_verify_the_Other_Deposit_Account_Notices_check_box_displayed() {
		if (eDeliveryPreferencesPage.otherDepositAccNoticesChkBox())
			reportPass("Other Deposit Account Notices check box is displayed");
		else
			reportFail("Other Deposit Account Notices check box is not displayed");
	}

	@Then("I verify the {string} text display")
	public void i_verify_the_text_display(String otherDepositAccNoticeMsg) {
		if (eDeliveryPreferencesPage.verifyOtherDepositAccNoticeMsg(otherDepositAccNoticeMsg))
			reportPass(otherDepositAccNoticeMsg + " message is displayed");
		else
			reportFail(otherDepositAccNoticeMsg + " message is not displayed");
	}

	@Then("I verify the tool tip image displayed")
	public void i_verify_the_tool_tip_image_displayed() {
		if (eDeliveryPreferencesPage.toolTipForeDelivery())
			reportPass("eDelivery Tooltip Image is displayed");
		else
			reportFail("eDelivery Tooltip Image is not displayed");
	}

	@Then("I verify the {string} text is displayed")
	public void i_verify_the_text_is_displayed(String sendNotificationsMsg) {
		if (eDeliveryPreferencesPage.verifySendNotificationsMsg(sendNotificationsMsg))
			reportPass(sendNotificationsMsg + " text is displayed");
		else
			reportFail(sendNotificationsMsg + " text is not displayed");
	}

	@Then("I verify the Email address as {string}")
	public void i_verify_the_Email_address_as(String emailId) {
		if (eDeliveryPreferencesPage.verifySendNotificationsEmailId(emailId))
			reportPass(emailId + " Email Address is displayed");
		else
			reportFail(emailId + " Email Address is not displayed");
	}

	@Then("I verify the email id edit button is displayed")
	public void i_verify_the_email_id_edit_button_is_displayed() {
		if (eDeliveryPreferencesPage.emailIdEditButton())
			reportPass("Email Id Edit button is displayed");
		else
			reportFail("Email Id Edit button is not displayed");
	}

	@Then("I verify the Other Deposit Account Notices header with status as {string}")
	public void i_verify_the_Other_Deposit_Account_Notices_header_with_status_as(String electronicStatus) {
		if (eDeliveryPreferencesPage.verifyElectronicStatus(electronicStatus))
			reportPass(electronicStatus + " text is displayed");
		else
			reportFail(electronicStatus + " text is not displayed");
	}

	@Then("I verify the {string} text displayed")
	public void i_verify_the_text_displayed(String notificationDelivered) {
		if (eDeliveryPreferencesPage.verifyNotificationsDeliveredTo(notificationDelivered))
			reportPass(notificationDelivered + " text is displayed");
		else
			reportFail(notificationDelivered + " text is not displayed");
	}

	@Then("I verify the Notifications Delivered Email address as {string}")
	public void i_verify_the_Notifications_Delivered_Email_address_as(String deliveredEmailId) {
		if (eDeliveryPreferencesPage.verifyNotificationsDeliveredEmailId(deliveredEmailId))
			reportPass(deliveredEmailId + " Email id is displayed");
		else
			reportFail(deliveredEmailId + " Email id is not displayed");
	}

	@And("I verify the checkbox and tooltip for {string}")
	public void i_verify_the_checkbox_and_tooltip_for(String labelName) {
		if (eDeliveryPreferencesPage.verifyCheckboxTooltipOtherDeposits(labelName))
			reportPass("Checkbox and tooltip are present for notices");
		else
			reportFail("Checkbox and tooltip are not present for notices");
	}

	@And("I verify the MailID and Edit button for {string} label")
	public void i_verify_the_MailID_and_Edit_button(String labelName) {
		if (eDeliveryPreferencesPage.verifyMailEditButton(labelName))
			reportPass("Mail ID heading, Mail ID and Edit buttons are present ");
		else
			reportFail("One of Mail ID heading, Mail ID and Edit buttons are not present ");
	}

	@When("I click on Select All link")
	public void i_click_on_Select_All_link() {
		if (eDeliveryPreferencesPage.clickSelectAll())
			reportPass("Select All link is clicked");
		else
			reportFail("Select All link is not clicked");
	}

	@Then("All checkboxes are checked")
	public void all_checkboxes_are_checked() {
		if (eDeliveryPreferencesPage.verifyCheckedCheckboxes())
			reportPass("All checkboxes are checked");
		else
			reportFail("Some of the checkboxes are not checked");
	}

	@When("I click on continue button of eDeliveryPreference")
	public void i_click_on_continue_button_of_eDeliveryPreference() {
		if (eDeliveryPreferencesPage.clickContinueButton())
			reportPass("Continue button is clicked");
		else
			reportFail("Continue button is not clicked");
	}

	@And("I should see headers")
	public void i_should_see_headers() {
		Collection<String> listHeaders = jsonDataParser.getTestDataMap().values();
		if (eDeliveryPreferencesPage.verifyAccountsCheckboxes(listHeaders))
			reportPass(listHeaders.toString() + " are displayed");
		else
			reportFail("some detalis in " + listHeaders.toString() + " is not displayed");
	}

	@When("I click on {string}")
	public void i_click_on(String linkName) {
		if (eDeliveryPreferencesPage.clickLink(linkName))
			reportPass("Link: " + linkName + " is clicked");
		else
			reportFail("Link: " + linkName + " is not clicked");
	}

	@Then("I should see {string}")
	public void i_should_see(String pageName) {
		if (eDeliveryPreferencesPage.checkLightboxTitle(pageName))
			reportPass(pageName + " page is displayed");
		else
			reportFail(pageName + " page is not displayed");
	}

	@Then("I should see the {string} and {string} buttons")
	public void i_should_see_the_and_buttons(String btnPrint, String btnClose) {
		if (eDeliveryPreferencesPage.verifyPrintCloseButtons(btnPrint, btnClose))
			reportPass(btnPrint + ", " + btnClose + " buttons are present");
		else
			reportFail(btnPrint + ", " + btnClose + " buttons are not present");
	}

	@Then("I should scrolldown the agreement")
	public void i_should_scrolldown_the_agreement() {
		listValues.addAll(jsonDataParser.getTestDataMap().values());
		if (eDeliveryPreferencesPage.VerifyAgreementHeadings(listValues))
			reportPass(listValues.toString() + " are displayed");
		else
			reportFail("some detalis in " + listValues.toString() + " is not displayed");
	}

	@Then("I verify the {string} button")
	public void i_verify_the_button(String btnName) {
		if (eDeliveryPreferencesPage.checkForButtons(btnName))
			reportPass("Button : " + btnName + " is displayed");
		else
			reportFail("Button : " + btnName + " is not displayed");
	}

	@Then("I verify the all the accounts not checked")
	public void i_verify_the_all_the_accounts_not_checked() {
		if (eDeliveryPreferencesPage.verifyAccountsNotChecked())
			reportPass("All accounts are not checked");
		else
			reportFail("accounts are not checked");
	}

	@When("I uncheck the all chekboxes")
	public void i_uncheck_the_all_chekboxes() {
		if (eDeliveryPreferencesPage.clickAllAccounts())
			reportPass("All accounts are deselected");
		else
			reportFail("accounts are not deselected");
	}

	@Then("I check for all accounts of user")
	public void i_check_for_all_accounts_of_user() {
		List<String> listAccounts = eDeliveryPreferencesPage.checkAllAccounts();
		if (listAccounts.size() != 0)
			reportPass("Accounts for the user are: " + listAccounts.toString() + " are displayed");
		else
			reportHardFail("one of the accounts for the user are: " + listAccounts.toString() + " are not displayed");
	}

	@When("I {string} the all the checkboxes")
	public void i_the_all_the_checkboxes(String actionType) {
		if (eDeliveryPreferencesPage.clickAllAccounts())
			reportPass("All accounts checkboxes are : " + actionType);
		else
			reportFail("All accounts checkboxes are not: " + actionType);
	}

	@Then("I check for the accounts and checkboxes")
	public void i_check_for_the_accounts_and_checkboxes() {
		if (eDeliveryPreferencesPage.checkAccountsWithCheckboxes())
			reportPass("All eligible accounts are displayed with corresponding checkboxes");
		else
			reportFail("All eligible accounts are not displayed with corresponding checkboxes");
	}

	@When("I {string} the accounts")
	public void i_the_accounts(String typeAction) {
		if (eDeliveryPreferencesPage.verifyAccountCheckboxes(typeAction))
			reportPass("Checkboxes has been " + typeAction);
		else
			reportFail("Checkboxes has not been " + typeAction);
	}

	@When("I click on {string} button in eDeliveryPreference")
	public void i_click_on_button_in_eDeliveryPreference(String btnName) {
		if (eDeliveryPreferencesPage.clickOnButton(btnName))
			reportPass("Clicked on:" + btnName + " button");
		else
			reportHardFail("Not clicked on:" + btnName + " button");
	}

	@Then("I should see update message as {string}")
	public void i_should_see_update_message_as(String txtUpdateMessage) {
		txtUpdateMessage = jsonDataParser.getTestDataMap().get(txtUpdateMessage);
		if (eDeliveryPreferencesPage.checkForMessageLightbox(txtUpdateMessage))
			reportPass("Message :" + txtUpdateMessage + " is displayed");
		else
			reportHardFail("Message :" + txtUpdateMessage + " is not displayed");
	}

	@When("I click on {string} Tooltip")
	public void i_click_on_Tooltip(String txtTooltipName) {
		if (eDeliveryPreferencesPage.clickOnTooltip(txtTooltipName))
			reportPass("Clicked on:" + txtTooltipName + " Tooltip button");
		else
			reportHardFail("Not clicked on:" + txtTooltipName + " Tooltip button");
	}

	@Then("I should see text of {string}")
	public void i_should_see_text_of(String accountType) {
		String txtMessage = jsonDataParser.getTestDataMap().get(accountType);
		if (eDeliveryPreferencesPage.checkForTooltipMessage(accountType, txtMessage))
			reportPass("Label: " + accountType + " with Message: " + txtMessage + " is displayed");
		else
			reportHardFail("Label: " + accountType + " with Message: " + txtMessage + " is not displayed");
	}

	@Then("I should see Mail Edit lightbox note as {string}")
	public void i_should_see_Mail_Edit_lightbox_note_as(String txtNote) {
		txtNote = jsonDataParser.getTestDataMap().get(txtNote);
		if (eDeliveryPreferencesPage.checkForNote(txtNote))
			reportPass("Note: " + txtNote + " is displayed");
		else
			reportHardFail("Note: " + txtNote + " is not displayed");
	}

	@Then("I verify the textbox and label of {string}")
	public void i_verify_the_txtbox_and_label_of(String fieldName) {
		if (eDeliveryPreferencesPage.checkForLabelAndTextbox(fieldName))
			reportPass("Label: " + fieldName + " is displayed with textbox");
		else
			reportHardFail("Label: " + fieldName + " is not displayed with textbox");
	}

	@When("I enter new {string} MailID in {string} and {string}")
	public void i_enter_new_MailID_in_and(String mailType, String mailNew, String mailVerifyNew) {
		if (eDeliveryPreferencesPage.enterNewMailID(mailType, mailNew, mailVerifyNew))
			reportPass(mailType + " mail is entered in  " + mailNew + "," + mailVerifyNew);
		else
			reportFail(mailType + " mail is not entered in  " + mailNew + "," + mailVerifyNew);
	}

	@And("I verify the new MailID updated")
	public void i_verify_the_new_MailID_updated() {
		String mailID = eDeliveryPreferencesPage.checkForUpdatedMail();
		if (mailID != null)
			reportPass("Mail: " + mailID + " is displayed");
		else
			reportHardFail("Mail: " + mailID + " is not displayed");
	}

	@Then("I should see error message at {string}")
	public void i_should_see_error_message_at_as(String labelName) {
		String errorMessage = jsonDataParser.getTestDataMap().get(labelName);
		if (eDeliveryPreferencesPage.checkForErrorMessage(labelName, errorMessage))
			reportPass("Label: " + labelName + " is displayed with error message as: " + errorMessage);
		else
			reportHardFail("Label: " + labelName + " is not displayed with error message as: " + errorMessage);
	}
}