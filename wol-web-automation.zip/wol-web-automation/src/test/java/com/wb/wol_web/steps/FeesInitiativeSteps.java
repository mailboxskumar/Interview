
package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.FeesInitiativePage;

import cucumber.api.java.en.Then;

public class FeesInitiativeSteps extends ObjectBase {

	FeesInitiativePage feesInitiativePage = new FeesInitiativePage();
	public String transactionName = null;
	public String amount = null;

	@Then("I verify the transaction is displayed with withdrawls amount")
	public void and_I_verify_the_transaction_is_displayed_with_withdrawls_amount() {
		transactionName = testDataMap.get("TransName");
		amount = testDataMap.get("Amount");
		if (feesInitiativePage.verifyTransactionAmount(transactionName, amount))
			reportPassWithFullPageScreenshot(
					"Transaction Name: " + transactionName + " and Amount: " + amount + " is displayed");
		else
			reportFailWithFullPageScreenshot(
					"Transaction Name: " + transactionName + " and Amount: " + amount + " is not displayed");
	}
}
