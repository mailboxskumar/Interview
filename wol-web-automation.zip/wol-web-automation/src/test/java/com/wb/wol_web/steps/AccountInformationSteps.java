package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AccountInformationPage;
import com.wb.wol_web.pages.TransactionHistoryPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AccountInformationSteps extends ObjectBase {

	AccountInformationPage accountInformationPage = new AccountInformationPage();
	TransactionHistoryPage transactionHistoryPage = new TransactionHistoryPage();

	@Then("I Verify the {string} page displayed")
	public void i_Verify_the_page_displayed(String accInfoPageTitle) {
		if (accountInformationPage.verifyAccInfoPageTitle(accInfoPageTitle))
			reportPass(accInfoPageTitle + " Page is displayed");
		else
			reportHardFail(accInfoPageTitle + " Page is not displayed");
	}

	@Then("I verify the Account details as {string}")
	public void i_verify_the_Account_details_as(String accNumber) {
		accNumber=jsonDataParser.getTestDataMap().get(accNumber);
		if (accountInformationPage.verifyAccNumber(accNumber))
			reportPass(" Account number " + accNumber + " is matched in Account details");
		else
			reportFail(" Account number " + accNumber + " is not matched in Account details");
	}

	@When("I Click on the edit icon for Nickname field")
	public void i_Click_on_the_edit_icon_for_Nickname_field() {
		if (accountInformationPage.clickOnEditNickName())
			reportPass("Clicked on Nick Name Edit icon");
		else
			reportFail("Unable to click on Nick Name Edit Icon");
	}

	@Then("I verify the updated nickname is displayed")
	public void i_verify_the_updated_nickname_is_displayed() {
		if (accountInformationPage.verifyNickNameInAcccInfoPage())
			reportPass("Updated nickname is displayed");
		else
			reportHardFail("Updated nickname is not displayed");
	}

	@Then("I verify the Statement eDelivery field should be displayed as {string}")
	public void i_verify_the_Statement_eDelivery_field_should_be_displayed_as(String stmteDeliveryStatus) {
		if (accountInformationPage.verifyStatementeDeliveryStatus(stmteDeliveryStatus))
			reportPass("Statement E Delivery Status is displayed as " + stmteDeliveryStatus);
		else
			reportHardFail("Statement E Delivery Status is not displayed as " + stmteDeliveryStatus);
	}

	@When("I Click on the edit icon for Statement eDelivery field")
	public void i_Click_on_the_edit_icon_for_Statement_eDelivery_field() {
		if (accountInformationPage.clickOnStatementeDeliveryEditIcon())
			reportPass("Clicked on Statement e Delivery Edit Icon");
		else
			reportFail("Unable to click on Statement e Delivery Edit Icon");
	}

	@Then("I verify the View Deposit Details field should be displayed as {string}")
	public void i_verify_the_View_Deposit_Details_field_should_be_displayed_as(String viewDepositDetails) {
		if (accountInformationPage.verifyDepositDetailsStatus(viewDepositDetails))
			reportPass("View Deposit Details Status is displayed as " + viewDepositDetails);
		else
			reportHardFail("View Deposit Details Status is not displayed as " + viewDepositDetails);
	}

	@When("I Click on the edit icon for View Deposit Details field")
	public void i_Click_on_the_edit_icon_for_View_Deposit_Details_field() {
		if (accountInformationPage.clickOnDepositDetailsEditIcon())
			reportPass("Clicked on View Deposit Details Edit Icon");
		else
			reportFail("Unable to click on View Deposit Details Edit Icon");
	}

	@Then("I verify the Default Billpay Account field displayed as {string}")
	public void i_verify_the_Default_Billpay_Account_field_displayed_as(String defaultBillPaySts) {
		if (accountInformationPage.verifyDefaultBillPayAccStatus(defaultBillPaySts))
			reportPass("Default Bill Pay Status is displayed as " + defaultBillPaySts);
		else {
			reportFail("Default Bill Pay Status is not displayed as " + defaultBillPaySts);
		}
	}

	@When("I Click on the edit icon for Bill Pay Account field")
	public void i_Click_on_the_edit_icon_for_Bill_Pay_Account_field() {
		if (accountInformationPage.clickOnDefaultBillPayEditIcon())
			reportPass("Clicked on Default Bill Pay Edit Icon");
		else
			reportFail("Unable to click on Default Bill Pay Edit Icon");
	}

	@Then("I verify the View Deposit Details text should not display.")
	public void i_verify_the_View_Deposit_Details_text_should_not_display() {
		if (accountInformationPage.depositTextNotPresent())
			reportPass("Deposit details text is not Present in Account Information page");
		else
			reportFail("Deposit details text is Present in Account Information page");
	}

	@Then("I verify the no accounts message as {string}")
	public void i_verify_the_no_accounts_message_as(String noAccountsErrMsg) {
		if (accountInformationPage.depositTextNotPresent())
			reportPass("No Accounts Error Message displayed as" + noAccountsErrMsg);
		else
			reportFail("No Accounts Error Message not displayed as " + noAccountsErrMsg);
	}

	@Then("I verify the account status as {string}")
	public void i_verify_the_account_status_as(String accountStatus) {
		accountStatus=jsonDataParser.getTestDataMap().get(accountStatus);
		if (accountInformationPage.verifyAccountStatus(accountStatus))
			reportPass("Account Status " + accountStatus + " is displayed");
		else
			reportFail("Account Status " + accountStatus + " is not displayed");
	}

	@When("I click on the Status tooltip")
	public void i_click_on_the_Status_tooltip() {
		if (accountInformationPage.clickOnAccountStatus())
			reportPass("Clicked on Status tooltip link");
		else
			reportFail("Unable to click on Status tooltip link");
	}

	@Then("I verify the {string} content should be displayed")
	public void i_verify_the_content_should_be_displayed(String statusContent) {
		statusContent=jsonDataParser.getTestDataMap().get(statusContent);
		if (accountInformationPage.verifyAccStsToolTipContent(statusContent))
			reportPass("Status Tooltip " + statusContent + " content is displayed");
		else
			reportHardFail("Status Tooltip " + statusContent + " content is not displayed");
	}

	@Then("I verify the Account Receives Overdraft Protection field displayed as Yes\\/No")
	public void i_verify_the_Account_Receives_Overdraft_Protection_field_displayed_as_Yes_No() {
		if (!accountInformationPage.captureODProtectionStatus().equals("N/A"))
			reportPass("Account Receives OverDraft Protection field status displayed as "
					+ accountInformationPage.captureODProtectionStatus());
		else
			reportHardFail("Account Receives OverDraft Protection field status is not displayed");
	}

	@When("I click on the Account Receives Overdraft Protection tooltip")
	public void i_click_on_the_Account_Receives_Overdraft_Protection_tooltip() {
		if (accountInformationPage.clickOnODProtectionLink())
			reportPass("Clicked on Account Receives OverDraft tooltip link");
		else
			reportFail("Unable to click on Account Receives OverDraft tooltip link");
	}

	@Then("I verify the tooltip content should be displayed as {string}")
	public void i_verify_the_tooltip_content_should_be_displayed_as(String odToolTipContent) {
		if (accountInformationPage.verifyODProtectionToolTipContent(odToolTipContent))
			reportPass("OverDraft Protection Tooltip " + accountInformationPage.captureODProtectionToolTipContent()
					+ " content is displayed");
		else
			reportHardFail("OverDraft Protection Tooltip content is not displayed");
	}

	@Then("I verify the What would you like to do next? section should display")
	public void i_verify_the_What_would_you_like_to_do_next_section_should_display() {
		if (accountInformationPage.verifyNextLinksText())
			reportPass("What would you like to do next text displayed");
		else
			reportFail("What would you like to do next text not displayed");
	}

	@Then("I verify the View Transaction History link should display")
	public void i_verify_the_View_Transaction_History_link_should_display() {
		if (accountInformationPage.verifyTransHistoryLink())
			reportPass("View Transaction History link displayed");
		else
			reportFail("View Transaction History link not displayed");
	}

	@Then("I verify the View Account Balances link should display")
	public void i_verify_the_View_Account_Balances_link_should_display() {
		if (accountInformationPage.verifyAccBalancesLink())
			reportPass("View Account Balances link displayed");
		else
			reportFail("View Account Balances link not displayed");
	}

	@Then("I verify the View Statements link should display")
	public void i_verify_the_View_Statements_link_should_display() {
		if (accountInformationPage.verifyAccStatementsLink())
			reportPass("View Account Statements link displayed");
		else
			reportFail("View Account Statements link not displayed");
	}

	@When("I click on View Statements link")
	public void i_click_on_View_Statements_link() {
		if (accountInformationPage.clickOnViewStatementsLink())
			reportPass("Clicked on View Statements link");
		else
			reportFail("Unable to click on View Statements link");
	}

	@When("I select the Purged Checking {string} Account")
	public void i_select_the_Purged_Checking_Account(String checkingAccount) {
		checkingAccount=jsonDataParser.getTestDataMap().get(checkingAccount);
		if (transactionHistoryPage.selectAccFromDropdown(checkingAccount))
			reportPass("Purged checking account " + checkingAccount + " is selected from Accounts dropdown");
		else
			reportFail("Purged checking account " + checkingAccount + " is not selected from Accounts dropdown");
	}

	@Then("I verify the Current balance field displayed as {string}")
	public void i_verify_the_Current_balance_field_displayed_as(String primaryBalance) {
		if (accountInformationPage.verifyPrimaryBalance(primaryBalance))
			reportPass("Purged account primary balance displayed as  " + primaryBalance);
		else
			reportFail("Purged account primary balance not displayed as  " + primaryBalance);
	}

	@Then("I verify the Available balance field displayed as {string}")
	public void i_verify_the_Available_balance_field_displayed_as(String secondaryBalance) {
		if (accountInformationPage.verifySecondaryBalance(secondaryBalance))
			reportPass("Purged account secondary balance displayed as  " + secondaryBalance);
		else
			reportFail("Purged account secondary balance not displayed as  " + secondaryBalance);
	}

	@When("I select the Purged Saving {string} Account")
	public void i_select_the_Purged_Saving_Account(String savingAccount) {
		if (transactionHistoryPage.selectAccFromDropdown(savingAccount))
			reportPass("Purged saving account " + savingAccount + " is selected from Accounts dropdown");
		else
			reportFail("Purged saving account " + savingAccount + " is not selected from Accounts dropdown");
	}

	@When("I select the Purged Loan {string} Account")
	public void i_select_the_Purged_Loan_Account(String loanAccount) {
		if (transactionHistoryPage.selectAccFromDropdown(loanAccount))
			reportPass("Purged loan account " + loanAccount + " is selected from Accounts dropdown");
		else
			reportFail("Purged loan account " + loanAccount + " is not selected from Accounts dropdown");
	}

	@Then("I verify the {string} field and {string} should display for Current balance details")
	public void i_verify_the_field_and_should_display_for_Current_balance_details(String currentBalance, String value) {
		if (accountInformationPage.verifyCurrentBalanceFieldAndValue(currentBalance, value))
			reportPass(currentBalance + " field displayed with " + accountInformationPage.currentBalanceValue);
		else
			reportFail(currentBalance + " field not displayed with " + accountInformationPage.currentBalanceValue);
	}

	@Then("I verify the {string} field and {string} should display for Available balance details")
	public void i_verify_the_field_and_should_display_for_Available_balance_details(String availableBalance,
			String value) {
		if (accountInformationPage.verifyAvailableBalanceFieldAndValue(availableBalance, value))
			reportPass(availableBalance + " field displayed with " + accountInformationPage.availableBalanceValue);
		else
			reportFail(availableBalance + " field not displayed with " + accountInformationPage.availableBalanceValue);
	}

	@Then("I verify the {string} section should display")
	public void i_verify_the_section_should_display(String overiView) {
		if (accountInformationPage.verifyOverViewSection(overiView))
			reportPass(overiView + " section displayed");
		else
			reportFail(overiView + " section not displayed");
	}

	@Then("I verify the {string} field and {string} should display for Account type details")
	public void i_verify_the_field_and_should_display_for_Account_type_details(String accountType, String value) {
		value=jsonDataParser.getTestDataMap().get(value);
		if (accountInformationPage.verifyAccountTypeFieldAndValue(accountType, value))
			reportPass(accountType + " field displayed with " + accountInformationPage.accountTypeValue);
		else
			reportFail(accountType + " field not displayed with " + accountInformationPage.accountTypeValue);
	}

	@Then("I verify the {string} field and value should display for Nick name details")
	public void i_verify_the_field_and_value_should_display_for_Nick_name_details(String nickName) {
		if (accountInformationPage.verifyNickNameFieldAndValue(nickName))
			reportPass(nickName + " field displayed with " + accountInformationPage.captureAccNickName());
		else
			reportFail(nickName + " field not displayed with " + accountInformationPage.captureAccNickName());
	}

	@Then("I verify the {string} field and {string} should display for Account number details")
	public void i_verify_the_field_and_should_display_for_Account_number_details(String accNumber, String value) {
		value=jsonDataParser.getTestDataMap().get(value);
		if (accountInformationPage.verifyAccountNumberFieldAndValue(accNumber, value))
			reportPass(accNumber + " field displayed with " + accountInformationPage.accountDetails);
		else
			reportFail(accNumber + " field not displayed with " + accountInformationPage.accountDetails);
	}

	@Then("I verify the {string} field and {string} should display for Status details")
	public void i_verify_the_field_and_should_display_for_Status_details(String status, String value) {
		if (accountInformationPage.verifyAccountStatusFieldAndValue(status, value))
			reportPass(status + " field displayed with " + accountInformationPage.accountStsValue + " status");
		else
			reportFail(status + " field not displayed with " + accountInformationPage.accountStsValue + " status");
	}

	@Then("I verify the {string} field, {string} and {string} should display for Last deposit details")
	public void i_verify_the_field_and_should_display_for_Last_deposit_details(String lastDeposit, String amount,
			String date) {
		if (accountInformationPage.verifyLastDepositFieldAndValue(lastDeposit, amount, date))
			reportPass(lastDeposit + " field displayed with " + accountInformationPage.lastDepositAmount);
		else
			reportFail(lastDeposit + " field not displayed with " + accountInformationPage.lastDepositAmount);
	}

	@Then("I verify the {string} section should display for Interest details")
	public void i_verify_the_section_should_display_for_Interest_details(String interestSection) {
		if (accountInformationPage.verifyInterestSection(interestSection))
			reportPass(interestSection + " section displayed");
		else
			reportFail(interestSection + " section not displayed");
	}

	@Then("I verify the {string} field and {string} should display for Current Interest Rate details")
	public void i_verify_the_field_and_should_display_for_Current_Interest_Rate_details(String interest, String value) {
		if (accountInformationPage.verifyCurrentIntRateFieldAndValue(interest, value))
			reportPass(interest + " field displayed with " + accountInformationPage.interestPercentage);
		else
			reportFail(interest + " field not displayed with " + accountInformationPage.interestPercentage);
	}

	@Then("I verify the {string} field and {string} should display for APY details")
	public void i_verify_the_field_and_should_display_for_APY_details(String annualInterest, String percentage) {
		if (accountInformationPage.verifyCurrentAPYFieldAndValue(annualInterest, percentage))
			reportPass(annualInterest + " field displayed with " + accountInformationPage.annualInterestPercentage);
		else
			reportFail(annualInterest + " field not displayed with " + accountInformationPage.annualInterestPercentage);
	}

	@Then("I verify the {string} field, {string} and {string} should display for Last interest paid details")
	public void i_verify_the_field_and_should_display_for_Last_interest_paid_details(String lastInterest, String amount,
			String date) {
		if (accountInformationPage.verifyLastInterestFieldAndValue(lastInterest, amount, date))
			reportPass(lastInterest + " field displayed with " + accountInformationPage.lastInterestAmount);
		else
			reportFail(lastInterest + " field not displayed with " + accountInformationPage.lastInterestAmount);
	}

	@Then("I verify the {string} field and {string} should display for YTD details")
	public void i_verify_the_field_and_should_display_for_YTD_details(String yearDateInterest, String amount) {
		if (accountInformationPage.verifyYTDInterestFieldAndValue(yearDateInterest, amount))
			reportPass(yearDateInterest + " field displayed with " + accountInformationPage.yearDateInterestAmount);
		else
			reportFail(yearDateInterest + " field not displayed with " + accountInformationPage.yearDateInterestAmount);
	}

	@Then("I verify the {string} field and {string} should display for PYTD details")
	public void i_verify_the_field_and_should_display_for_PYTD_details(String preYearDateInterest, String value) {
		if (accountInformationPage.verifyPreviousYTDInterestFieldAndValue(preYearDateInterest, value))
			reportPass(
					preYearDateInterest + " field displayed with " + accountInformationPage.prevYearDateInterestValue);
		else
			reportFail(preYearDateInterest + " field not displayed with "
					+ accountInformationPage.prevYearDateInterestValue);
	}

	@Then("I verify the {string} section should display for Features details")
	public void i_verify_the_section_should_display_for_Features_details(String featuresSection) {
		if (accountInformationPage.verifyFeaturesSection(featuresSection))
			reportPass(featuresSection + " section displayed");
		else
			reportFail(featuresSection + " section not displayed");
	}

	@Then("I verify the {string} field and status Yes\\/No should display for Statement eDelivery details")
	public void i_verify_the_field_and_status_Yes_No_should_display_for_Statement_eDelivery_details(String eDelivery) {
		if (accountInformationPage.verifyStmteDeliveryFieldAndValue(eDelivery))
			reportPass(eDelivery + " field displayed with " + accountInformationPage.captureStatementeDeliveryStatus());
		else
			reportFail(eDelivery + " field not displayed with "
					+ accountInformationPage.captureStatementeDeliveryStatus());
	}

	@Then("I verify the {string} field and status Yes\\/No should display for View Deposit details")
	public void i_verify_the_field_and_status_Yes_No_should_display_for_View_Deposit_details(
			String viewDepositDetails) {
		if (accountInformationPage.verifyViewDepositDetailsFieldAndValue(viewDepositDetails))
			reportPass(viewDepositDetails + " field displayed with "
					+ accountInformationPage.captureViewDepositDetailsStatus());
		else
			reportFail(viewDepositDetails + " field not displayed with "
					+ accountInformationPage.captureViewDepositDetailsStatus());
	}

	@Then("I verify the {string} field and status Yes\\/No should display")
	public void i_verify_the_field_and_status_Yes_No_should_display(String OverDraftProtection) {
		if (accountInformationPage.verifyODProtectionFieldAndValue(OverDraftProtection))
			reportPass(OverDraftProtection + " field displayed with "
					+ accountInformationPage.captureODProtectionStatus());
		else
			reportFail(OverDraftProtection + " field not displayed with "
					+ accountInformationPage.captureODProtectionStatus());
	}

	@Then("I verify the {string} field and status Yes\\/No should display for Default Billpay details")
	public void i_verify_the_field_and_status_Yes_No_should_display_for_Default_Billpay_details(String billPayAccount) {
		if (accountInformationPage.verifyDefaultBillPayAccFieldAndValue(billPayAccount))
			reportPass(billPayAccount + " field displayed with "
					+ accountInformationPage.captureDefaultBillPayAccStatus());
		else
			reportFail(billPayAccount + " field not displayed with "
					+ accountInformationPage.captureDefaultBillPayAccStatus());
	}

	@Then("I verify the {string} field and status Yes\\/No should display for Overdraft services details details")
	public void i_verify_the_field_and_status_Yes_No_should_display_for_Overdraft_services_details_details(
			String odServices) {
		if (accountInformationPage.verifyODServicesFieldAndValue(odServices))
			reportPass(odServices + " field displayed with " + accountInformationPage.captureOverDraftServicesStatus());
		else
			reportFail(odServices + " field not displayed with "
					+ accountInformationPage.captureOverDraftServicesStatus());
	}

	@Then("I verify the {string} field and {string} should display for Maturity Date details")
	public void i_verify_the_field_and_should_display_for_Maturity_Date_details(String maturityDatefield,
			String value) {
		if (accountInformationPage.verifyMaturityDateFieldAndValue(maturityDatefield, value))
			reportPass(maturityDatefield + " field displayed with " + accountInformationPage.maturityDate);
		else
			reportFail(maturityDatefield + " field not displayed with " + accountInformationPage.maturityDate);
	}

	@Then("I verify the {string} field and status Yes\\/No should display for Retirement Account details")
	public void i_verify_the_field_and_status_Yes_No_should_display_for_Retirement_Account_details(
			String retirementAcc) {
		if (accountInformationPage.verifyReturementAccountAndValue(retirementAcc))
			reportPass(retirementAcc + " field displayed with " + accountInformationPage.captureRetirementAccStatus());
		else
			reportFail(
					retirementAcc + " field not displayed with " + accountInformationPage.captureRetirementAccStatus());
	}

	@Then("I verify the {string} field and {string} should display for Principal balance details")
	public void i_verify_the_field_and_should_display_for_Principal_balance_details(String principalBalance,
			String value) {
		if (accountInformationPage.verifyCurrentBalanceFieldAndValue(principalBalance, value))
			reportPass(principalBalance + " field displayed with " + accountInformationPage.currentBalanceValue);
		else
			reportFail(principalBalance + " field not displayed with " + accountInformationPage.currentBalanceValue);
	}

	@Then("I verify the {string} field and {string} should display for Amount Due details")
	public void i_verify_the_field_and_should_display_for_Amount_Due_details(String amountDue, String value) {
		if (accountInformationPage.verifyAvailableBalanceFieldAndValue(amountDue, value))
			reportPass(amountDue + " field displayed with " + accountInformationPage.availableBalanceValue);
		else
			reportFail(amountDue + " field not displayed with " + accountInformationPage.availableBalanceValue);
	}

	@Then("I verify the {string} field and {string} should display for Credit Limit details")
	public void i_verify_the_field_and_should_display_for_Credit_Limit_details(String creditLimit, String value) {
		if (accountInformationPage.verifyCreditLimitFieldAndValue(creditLimit, value))
			reportPass(creditLimit + " field displayed with " + accountInformationPage.creditLimitValue);
		else
			reportFail(creditLimit + " field not displayed with " + accountInformationPage.creditLimitValue);
	}

	@Then("I verify the {string} section should display for Payment details")
	public void i_verify_the_section_should_display_for_Payment_details(String paymentSection) {
		if (accountInformationPage.verifyPaymentInformationSection(paymentSection))
			reportPass("Payment Information text displayed");
		else
			reportFail("Payment Information text not displayed");
	}

	@Then("I verify the {string} field, {string} and {string} should display for Next Payment Due details")
	public void i_verify_the_field_and_should_display_for_Next_Payment_Due_details(String nextPaymentDue, String amount,
			String date) {
		if (accountInformationPage.verifyNextPaymenttDueFieldAndValue(nextPaymentDue, amount, date))
			reportPass(nextPaymentDue + " field displayed with " + accountInformationPage.nextPaymentDueAmount);
		else
			reportFail(nextPaymentDue + " field not displayed with " + accountInformationPage.nextPaymentDueAmount);
	}

	@Then("I verify the {string} field and {string} should display for Late Charges details")
	public void i_verify_the_field_and_should_display_for_Late_Charges_details(String lateCharges, String value) {
		if (accountInformationPage.verifyLateChargesFieldAndValue(lateCharges, value))
			reportPass(lateCharges + " field displayed with " + accountInformationPage.lateChargesAmount);
		else
			reportFail(lateCharges + " field not displayed with " + accountInformationPage.lateChargesAmount);
	}

	@Then("I verify the {string} field and {string} should display for Fees details")
	public void i_verify_the_field_and_should_display_for_Fees_details(String fees, String value) {
		if (accountInformationPage.verifyFeesFieldAndValue(fees, value))
			reportPass(fees + " field displayed with " + accountInformationPage.feesAmount);
		else
			reportFail(fees + " field not displayed with " + accountInformationPage.feesAmount);

	}

	@Then("I verify the {string} field and {string} should display for Available balance")
	public void i_verify_the_field_and_should_display_for_Available_balance(String availableBalance, String value) {
		if (accountInformationPage.verifyAvailableBalFieldAndValue(availableBalance, value))
			reportPass(availableBalance + " field displayed with " + accountInformationPage.availableBalanceAmount);
		else
			reportFail(availableBalance + " field not displayed with " + accountInformationPage.availableBalanceAmount);
	}

	@Then("I verify the {string} field and {string} should display for Last Payment Date details")
	public void i_verify_the_field_and_should_display_for_Last_Payment_Date_details(String lastPaymentDate,
			String value) {
		if (accountInformationPage.verifyLastPaymentDateFieldAndValue(lastPaymentDate, value))
			reportPass(lastPaymentDate + " field displayed with " + accountInformationPage.lastPaymentDate);
		else
			reportFail(lastPaymentDate + " field not displayed with " + accountInformationPage.lastPaymentDate);
	}

	@Then("I verify the {string} field and {string} should display for Balance details")
	public void i_verify_the_field_and_should_display_for_Balance_details(String balance, String value) {
		if (accountInformationPage.verifyCurrentBalanceFieldAndValue(balance, value))
			reportPass(balance + " field displayed with " + accountInformationPage.currentBalanceValue);
		else
			reportFail(balance + " field not displayed with " + accountInformationPage.currentBalanceValue);
	}

	@Then("I verify the {string} field and {string} should display for Credit Line details")
	public void i_verify_the_field_and_should_display_for_Credit_Line_details(String creditLine, String value) {
		if (accountInformationPage.verifyAvailableBalanceFieldAndValue(creditLine, value))
			reportPass(creditLine + " field displayed with " + accountInformationPage.availableBalanceValue);
		else
			reportFail(creditLine + " field not displayed with " + accountInformationPage.availableBalanceValue);
	}

	@Then("I verify the {string} field should display {string} or {string} for Escrow balance details")
	public void i_verify_the_field_should_display_or_for_Escrow_balance_details(String escrowBalance, String value1,
			String value2) {
		if (accountInformationPage.verifyEscrowBalanceFieldAndValue(escrowBalance, value1, value2))
			reportPass(escrowBalance + " field displayed with " + accountInformationPage.escrowBalanceAmount);
		else
			reportFail(escrowBalance + " field not displayed with " + accountInformationPage.escrowBalanceAmount);
	}

	@Then("I verify the {string} field should display {string} or {string} for YTD details")
	public void i_verify_the_field_should_display_or_for_YTD_details(String ytdDate, String value1, String value2) {
		if (accountInformationPage.verifyYTDTaxeseFieldAndValue(ytdDate, value1, value2))
			reportPass(ytdDate + " field displayed with " + accountInformationPage.ytdTaxesPaidDate);
		else
			reportFail(ytdDate + " field not displayed with " + accountInformationPage.ytdTaxesPaidDate);
	}

	@Then("I verify the {string} field should display {string} or {string} for PYTD details")
	public void i_verify_the_field_should_display_or_for_PYTD_details(String prevYTDDate, String value1,
			String value2) {
		if (accountInformationPage.verifyPrevYTDTaxeseFieldAndValue(prevYTDDate, value1, value2))
			reportPass(prevYTDDate + " field displayed with " + accountInformationPage.prevYTDTaxesPaidDate);
		else
			reportFail(prevYTDDate + " field not displayed with " + accountInformationPage.prevYTDTaxesPaidDate);
	}

	@Then("I verify the {string} field and {string} should display for Held At details")
	public void i_verify_the_field_and_should_display_for_Held_At_details(String heldAt, String value) {
		if (accountInformationPage.verifyHeldAtFieldAndValue(heldAt, value))
			reportPass(heldAt + " field displayed with " + accountInformationPage.heldAtValue);
		else
			reportFail(heldAt + " field not displayed with " + accountInformationPage.heldAtValue);
	}

	@When("I click on View Transaction History link")
	public void i_click_on_View_Transaction_History_link() {
		if (accountInformationPage.clickOnViewTransHistoryLink())
			reportPass("Clicked on View Transaction History link");
		else
			reportFail("Unable to click on View Transaction History link");
	}

	@When("I click on View Account Balances link")
	public void i_click_on_View_Account_Balances_link() {
		if (accountInformationPage.clickOnViewAccBalancesLink())
			reportPass("Clicked on View Account Balances link");
		else
			reportFail("Unable to click on View Account Balances link");
	}

	@Then("I verify the View Deposit Details text should be present")
	public void i_verify_the_View_Deposit_Details_text_should_be_present() {
		if (accountInformationPage.verifyDepositText())
			reportPass("View Deposit details text displayed in Account details page");
		else
			reportFail("Unable to display View Deposit details text in Account details page");
	}
}
