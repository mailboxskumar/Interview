package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CustomerInformationWebcomPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerInformationWebcomSteps extends ObjectBase {
	CustomerInformationWebcomPage customerInformationWebcomPage = new CustomerInformationWebcomPage();
	String username = "";

	@When("I enter new value in {string} input field")
	public void i_enter_in_input_field(String fieldName) {
		String value = customerInformationWebcomPage.enterValueInInputField(fieldName);
		if (value != null)
			reportPass("Entered the new value as: " + value + " in " + fieldName + " field");
		else
			reportFail("Not entered the new value as: " + value + " in " + fieldName + " field");
	}

	@When("I click on {string} button in Customer Details page")
	public void i_click_on_button_in_Customer_Details_page(String btnName) {
		if (customerInformationWebcomPage.clickOnButton(btnName))
			reportPass("Clicked on " + btnName + " button");
		else
			reportFail("Unable to click on " + btnName + " button");
	}

	@Then("I should see {string} message")
	public void i_should_see_message(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (customerInformationWebcomPage.getUpdateMessage(message))
			reportPass("Update message: " + message + " is displayed ");
		else
			reportHardFail("Update message: " + message + " is not displayed ");
	}

	@And("I verify the updated {string} value same as updated value")
	public void i_verify_the_updated_value_same_as(String labelName) {
		username = customerInformationWebcomPage.verifyUpdatedValue(labelName);
		if (username != null)
			reportPass("new value is: " + username + " updated successfully");
		else
			reportHardFail("new value is: " + username + " not updated");
	}

	@Then("I should see below label and enter the value of {string}")
	public void i_should_see_below_labels_and_enter_the_values(String userName1) {
		username = customerInformationWebcomPage.checkUsername(userName1);
		if (username != null)
			reportPass("Username " + username + " Entered successfully");
		else
			reportFail("Username " + username + " values not entered ");
	}

	@When("I enter old value in {string} input field")
	public void i_enter_old_in_input_field(String fieldName) {
		String value = customerInformationWebcomPage.resetValueInInputField(fieldName);
		if (value != null)
			reportPass("Entered the new value as: " + value + " in " + fieldName + " field");
		else
			reportFail("Not entered the new value as: " + value + " in " + fieldName + " field");
	}

	@And("I Enter the new {string}")
	public void i_Enter_the_new(String labelName) {
		username = customerInformationWebcomPage.enterUserName(labelName);
		if (username != null)
			reportPass("Entered the new username as: " + username + " in " + labelName + " field");
		else
			reportFail("Not entered the new username as: " + username + " in " + labelName + " field");
	}

	@And("I check for the {string} at {string} in the customer details")
	public void i_check_for_the_in_the_customer_details(String userName, String labelName) {
		if (customerInformationWebcomPage.verifyValue(userName, labelName))
			reportPass("Updated username: " + userName + " is present");
		else
			reportHardFail("Updated username: " + userName + " is not present");
	}

	@Then("I should see value as {string}  at {string}")
	public void i_should_see_value_as_at(String message, String labelName) {
		if (customerInformationWebcomPage.verifyValue(message, labelName))
			reportPass("message: " + message + " is displayed at " + labelName + " label");
		else
			reportHardFail("message: " + message + " is not displayed at " + labelName + " label");
	}

}