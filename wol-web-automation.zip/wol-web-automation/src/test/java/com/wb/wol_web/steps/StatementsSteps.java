package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.EDeliveryPreferencesPage;
import com.wb.wol_web.pages.StatementsPage;
import com.wb.wol_web.pages.ViewDepositDetailsPreferencesPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StatementsSteps extends ObjectBase {
	StatementsPage statementsPage = new StatementsPage();
	EDeliveryPreferencesPage eDeliveryPreferencesPage = new EDeliveryPreferencesPage();
	ViewDepositDetailsPreferencesPage viewDepositDetailsPreferencesPage = new ViewDepositDetailsPreferencesPage();

	@Then("I verify the {string} page displayed")
	public void i_verify_the_page_displayed(String stmtsPageTitle) {
		if (statementsPage.verifyStatementsPageTitle(stmtsPageTitle))
			reportPass(stmtsPageTitle + " Page is displayed");
		else
			reportFail(stmtsPageTitle + " Page is not displayed");
	}

	@Then("I verify the message displayed as {string}")
	public void i_verify_the_message_displayed_as(String noStmtsMsg) {
		if (statementsPage.verifyNoStatementsMsg(noStmtsMsg))
			reportPass(noStmtsMsg + " message is displayed");
		else
			reportHardFail(noStmtsMsg + "  message is not displayed");
	}

	@Then("I verify the View your transaction history link should display")
	public void i_verify_the_View_your_transaction_history_link_should_display() {
		if (statementsPage.verifyViewTransHistoryLink())
			reportPass("View Your Transaction History link displayed");
		else
			reportFail("View Your Transaction History link not displayed");
	}

	@Then("I verify the View your Account Balances link should display")
	public void i_verify_the_View_your_Account_Balances_link_should_display() {
		if (statementsPage.verifyViewAccBalancesLink())
			reportPass("View Your Account Balances link displayed");
		else
			reportFail("View Your Account Balances link not displayed");
	}

	@Then("I verify the Loan Account")
	public void i_verify_the_Loan_Account() {
		if (statementsPage.verifyAccDetails())
			reportPass("Account Number " + (testDataMap.get("Loan Account Number")) + " is displayed");
		else
			reportFail("Account Number " + (testDataMap.get("Loan Account Number")) + " is not displayed");
	}

	@Then("I verify the Statement Period")
	public void i_verify_the_Statement_Period() {
		if (statementsPage.verifyStmtPeriod())
			reportPass("Statement Period " + statementsPage.statementPeriod + " is displayed");
		else
			reportFail("Statement Period " + statementsPage.statementPeriod + " is not displayed");
	}

	@Then("I verify the Statement Date Range")
	public void i_verify_the_Statement_Date_Range() {
		if (statementsPage.verifyStmtPeriodDateRange())
			reportPass("Statement Period " + statementsPage.statementPeriodDateRange + " is displayed");
		else
			reportFail("Statement Period " + statementsPage.statementPeriodDateRange + " is not displayed");

	}

	@When("I select the Account in statement page")
	public void i_select_the_Account_in_statement_page() {
		if (statementsPage.selectAccFromDropdownList())
			reportPass(
					"Account Number with last four digits: " + (testDataMap.get("Loan Account Number")) + " is selected");
		else
			reportFail("Account Number with last four digits: " + (testDataMap.get("Loan Account Number"))
					+ " is not selected");
	}

	@When("I select the Check Image Account in statement page")
	public void i_select_the_Check_Image_Account_in_statement_page() {
		if (statementsPage.selectChkImageAccFromDropdownList())
			reportPass("Account Number " + (testDataMap.get("SelectCheckImageAccount")) + " is selected");
		else
			reportFail("Account Number " + (testDataMap.get("SelectCheckImageAccount")) + " is not selected");
	}

	@When("I select the Display Check\\/Deposit Images as Yes")
	public void i_select_the_Display_Check_Deposit_Images_as_Yes() {
		if (statementsPage.selectYesForDisplayImages())
			reportPass("Display Image option selected as Yes");
		else
			reportFail("Yes option not selected for Display Image");
	}

	@When("I click on Image link")
	public void i_click_on_Image_link() {
		if (statementsPage.clickOnImage())
			reportPass("Deposit/Check Image selected");
		else
			reportFail("Unable to select the Deposit/Check Image");
	}

	@When("I select the Statement Period Date in statement page")
	public void i_select_the_Statement_Period_Date_in_statement_page() {
		if (statementsPage.selectStmtPeriod())
			reportPass("Statement Period Date " + (testDataMap.get("SelectStmtPeriodDate")) + " is selected");
		else
			reportFail("Statement Period Date " + (testDataMap.get("SelectStmtPeriodDate")) + " is not selected");
	}

	@When("I click on View Statement button in WOL statement page")
	public void i_click_on_View_Statement_button_in_WOL_statement_page() {
		if (statementsPage.clickOnViewStatement())
			reportPass("Clicked on View Statement button");
		else
			reportFail("Unable to click on View Statement button");
	}

	@Then("I verify the Account Number in the Loan pdf statement")
	public void i_verify_the_Account_Number_in_the_Loan_pdf_statement() {
		if (statementsPage.verifyAccountNumberInLoanStmt())
			reportPass("Loan Statement Account number " + (testDataMap.get("StatementAccNumber"))
					+ " is matched in Pdf statement page");
		else
			reportFail("Loan Statement Account number " + (testDataMap.get("StatementAccNumber"))
					+ " is not matched in Pdf statement page");
	}

	@Then("I verify the Statement date in the Loan pdf statement")
	public void i_verify_the_Statement_date_in_the_Loan_pdf_statement() {
		if (statementsPage.verifyLoanStmtDate())
			reportPass("Loan Statement Date " + (testDataMap.get("LoanStatementDate"))
					+ " is matched in Pdf statement page");
		else
			reportFail("Loan Statement Date " + (testDataMap.get("LoanStatementDate"))
					+ " is not matched in Pdf statement page");
	}

	@Then("I verify the {string} number is {string}")
	public void i_verify_the_number_is(String accNumber, String accCheckBoxSts) {
		accNumber = (testDataMap.get("Loan Account Number"));
		if (eDeliveryPreferencesPage.verifyAccountCheckBoxStatus(accNumber, accCheckBoxSts))
			reportPass(accNumber + " Account number is " + accCheckBoxSts);
		else
			reportFail(accNumber + " Account number is not " + accCheckBoxSts);
	}

	@When("I will close the Current Browser")
	public void i_will_close_the_Current_Browser() {
		try {
			statementsPage.closeTheBrowser();
		} catch (Exception e) {
			reportHardFail("Failed due to unable to close the Browser");
		}
	}

	@Then("I verify the Account is not displaying in the Accounts dropdown list")
	public void i_verify_the_Account_is_not_displaying_in_the_Accounts_dropdown_list() {
		if (statementsPage.verifyAccIsNotInDropdownList() == false)
			reportPass("Account Number " + (testDataMap.get("Loan Account Number"))
					+ " is not in the Accounts dropdown list");
		else
			reportFail("Account Number " + (testDataMap.get("Loan Account Number")) + " is selected");
	}

	@Then("I verify the UnEnroll Account number displayed under Accounts to Receive Paper Statements header")
	public void i_verify_the_UnEnroll_Account_number_displayed_under_Accounts_to_Receive_Paper_Statements_header() {
		if (viewDepositDetailsPreferencesPage.verifyUnEnrollAccNumber(testDataMap.get("LoanAccFormat")))
			reportPass("Opted out Account " + (testDataMap.get("LoanAccFormat") + " is displayed"));
		else
			reportHardFail("Opted out Account " + (testDataMap.get("LoanAccFormat") + " is not displayed"));
	}

	@Then("I verify the Account Number in the statement")
	public void i_verify_the_Account_Number_in_the_statement() {
		if (statementsPage.verifyAccountNumber())
			reportPass("Account number " + (testDataMap.get("AccountNumber") + " is displayed"));
		else
			reportHardFail("Account number " + (testDataMap.get("AccountNumber") + " is not displayed"));
	}

	@When("I select the APY Statement account in statement page")
	public void i_select_the_APY_Statement_account_in_statement_page() {
		if (statementsPage.selectAPYStmtAccFromDropdownList())
			reportPass("Account Number " + (testDataMap.get("APYStatementAccount")) + " is selected");
		else
			reportFail("Account Number " + (testDataMap.get("APYStatementAccount")) + " is not selected");
	}

	@Then("I verify the Statement APYInterest fields")
	public void i_verify_the_Statement_APYInterest_fields() {
		if (statementsPage.verifyInterestFields(jsonDataParser.getTestDataMap()))
			reportPass("APY Interest fields : {" + jsonDataParser.getTestDataMap().get("InterestFields")
					+ "} are successfully displayed");
		else
			reportFail("APY Interest fields : {" + jsonDataParser.getTestDataMap().get("InterestFields")
					+ "} are not displayed");
	}

	@Then("I verify the Statement APYInterest values")
	public void i_verify_the_Statement_APYInterest_values() {
		if (statementsPage.verifyInterestFieldsValues(jsonDataParser.getTestDataMap()))
			reportPass("APY Interest fields values : {" + jsonDataParser.getTestDataMap().get("InterestFieldsValues")
					+ "} is successfully displayed");
		else
			reportFail("APY Interest fields values: {" + jsonDataParser.getTestDataMap().get("InterestFieldsValues")
					+ "} are not displayed");
	}

	@Then("I verify the Detailed content in the Loan statement page")
	public void i_verify_the_Detailed_content_in_the_Loan_statement_page() {
		if (statementsPage.verifyDetailedAccActivityContent())
			reportPass(testDataMap.get("DetailedContent") + " text is displayed");
		else
			reportFail(testDataMap.get("DetailedContent") + " text is displayed");
	}

	@Then("I verify the Detailed Statement date in the Loan statement page")
	public void i_verify_the_Detailed_Statement_date_in_the_Loan_statement_page() {
		if (statementsPage.verifyDetailedStmtDate())
			reportPass("Loan Statement " + testDataMap.get("DetailedStmtDate") + " date is displayed");
		else
			reportFail("Loan Statement " + testDataMap.get("DetailedStmtDate") + " date is not displayed");
	}

	@Then("I verify the Statements are available in the Statement Period date dropdown list")
	public void i_verify_the_Statements_are_available_in_the_Statement_Period_date_dropdown_list() {
		if (statementsPage.verifyStmtIsNotInNADropdownList() == false)
			reportPass("Statement Date " + (testDataMap.get("StatementNotInNA"))
					+ " is not in the Period Date dropdown list");
		else
			reportFail("Statement are not available in the Period Date dropdown list");
	}

	@When("I click on View Your Transaction History link")
	public void i_click_on_View_Your_Transaction_History_link() {
		if (statementsPage.clickOnViewTransHistoryLink())
			reportPass("Clicked on View Your Transaction History link");
		else
			reportFail("Unable to click on Your Transaction History link");
	}

	@Then("I verify the loan statement text in the Statements page")
	public void i_verify_the_loan_statement_text_in_the_Statements_page() {
		if (statementsPage.verifyStmtPeriodMsg())
			reportPass("Loan Statement {" + testDataMap.get("StatementMessage") + "} message is displayed");
		else
			reportFail("Loan Statement {" + testDataMap.get("StatementMessage") + "} message is not displayed");
	}

	@Then("I verify the Customer Service Information label")
	public void i_verify_the_Customer_Service_Information_label() {
		if (statementsPage.verifyCustServiceInfoLabel())
			reportPass("{ " + testDataMap.get("CustomerInformation") + "} label is displayed");
		else
			reportFail("{ " + testDataMap.get("CustomerInformation") + "} label is not displayed");
	}

	@Then("I verify the Summary,Beginning Balance and Ending Balance labels")
	public void i_verify_the_Summary_Beginning_Balance_and_Ending_Balance_labels() {
		if (statementsPage.verifySummaryFields(jsonDataParser.getTestDataMap()))
			reportPass("Summary fields : {" + jsonDataParser.getTestDataMap().get("SummaryFields")
					+ "} are successfully displayed");
		else
			reportFail("Summary fields : {" + jsonDataParser.getTestDataMap().get("SummaryFields")
					+ "} are not displayed");
	}

	@Then("I verify the Transaction headers fields")
	public void i_verify_the_Transaction_headers_fields() {
		if (statementsPage.verifyTransHeaders(jsonDataParser.getTestDataMap()))
			reportPass("Transaction fields : {" + jsonDataParser.getTestDataMap().get("TransactionFields")
					+ "} are successfully displayed");
		else
			reportFail("Transaction fields : {" + jsonDataParser.getTestDataMap().get("TransactionFields")
					+ "} are not displayed");
	}

	@Then("I verify the Important information text message")
	public void i_verify_the_Important_information_text_message() {
		if (statementsPage.verifyAccTypeAndImpStmtMsg(jsonDataParser.getTestDataMap()))
			reportPass("Accoun type and Imp messages : {"
					+ jsonDataParser.getTestDataMap().get("AccTypeAndStmtImpMessage") + "} are successfully displayed");
		else
			reportFail("Accoun type and Imp messages : {"
					+ jsonDataParser.getTestDataMap().get("AccTypeAndStmtImpMessage") + "} are not displayed");
	}

	@Then("I verify the ELECTRONIC FUND TRANSFERS text")
	public void i_verify_the_ELECTRONIC_FUND_TRANSFERS_text() {
		if (statementsPage.verifyElecFundTransferText())
			reportPass("{ " + testDataMap.get("ElectFundTransfer") + "}  is displayed");
		else
			reportFail("{ " + testDataMap.get("ElectFundTransfer") + "}  is not displayed");
	}

	@When("I select the Statement Format as Date Order")
	public void i_select_the_Statement_Format_as_Date_Order() {
		if (statementsPage.selectDateOrderOption())
			reportPass("Date Order option is selected");
		else
			reportFail("Unable to select the Date Order option");
	}

	@When("I select the Display Check\\/Deposit Images as No")
	public void i_select_the_Display_Check_Deposit_Images_as_No() {
		if (statementsPage.selectNoForDisplayImages())
			reportPass("Check Images No option is selected");
		else
			reportFail("Unable to select the Check Images No option");
	}

	@Then("I verify the Date Range in the {string} option selected")
	public void i_verify_the_Date_Range_in_the_option_selected(String option) {
		if (statementsPage.verifyTransDateInRange(option))
			reportPass("Date Range verified Successfully in the Statements page");
		else
			reportFail("Unable to validate the date range in the Statements page");
	}

	@When("I select the Statement Format as By Categories")
	public void i_select_the_Statement_Format_as_By_Categories() {
		if (statementsPage.selectCategoryOrderOption())
			reportPass("By Categories option is selected");
		else
			reportFail("Unable to select the By Categories option");
	}

	@Then("I verify the By Category transactions labels")
	public void i_verify_the_By_Category_transactions_labels() {
		if (statementsPage.verifyTransCategories(jsonDataParser.getTestDataMap()))
			reportPass("Transaction Category labels : {" + jsonDataParser.getTestDataMap().get("TransCategories")
					+ "} are successfully displayed");
		else
			reportFail("Transaction Category labels : {" + jsonDataParser.getTestDataMap().get("TransCategories")
					+ "} are not displayed");
	}

	@Then("I verify the By Category transactions headers")
	public void i_verify_the_By_Category_transactions_headers() {
		if (statementsPage.verifyTransCategoriesHeaders(jsonDataParser.getTestDataMap()))
			reportPass("Transaction Category headers : {"
					+ jsonDataParser.getTestDataMap().get("TransCategoriesHeaders") + "} are successfully displayed");
		else
			reportFail("Transaction Category headers : {"
					+ jsonDataParser.getTestDataMap().get("TransCategoriesHeaders") + "} are not displayed");
	}

	@Then("I verify the Accoun type and Important information text message should display")
	public void i_verify_the_Accoun_type_and_Important_information_text_message_should_display() {
		if (statementsPage.verifyAccTypeAndImpStmtMsg(jsonDataParser.getTestDataMap()))
			reportPass("Accoun type and Imp messages : {"
					+ jsonDataParser.getTestDataMap().get("AccTypeAndStmtImpMessage") + "} are successfully displayed");
		else
			reportFail("Accoun type and Imp messages : {"
					+ jsonDataParser.getTestDataMap().get("AccTypeAndStmtImpMessage") + "} are not displayed");
	}

	@Then("I verify the Transaction messages should display")
	public void i_verify_the_Transaction_messages_should_display() {
		if (statementsPage.verifyTransStmtsMsgs(jsonDataParser.getTestDataMap()))
			reportPass("Transaction messages : {" + jsonDataParser.getTestDataMap().get("TransStmtMessages")
					+ "} are successfully displayed");
		else
			reportFail("Transaction messages : {" + jsonDataParser.getTestDataMap().get("TransStmtMessages")
					+ "} are not displayed");
	}

	@Then("I verify the Print button should display")
	public void i_verify_the_Print_button_should_display() {
		if (statementsPage.verifyPrintButton())
			reportPass("Print button displayed");
		else
			reportFail("Unable to display the Print button");
	}

	@Then("I verify the name and address")
	public void i_verify_the_name_and_address() {
		if (statementsPage.verifyCustomerNameAddress())
			reportPass("Customer Name and Address { " + testDataMap.get("NameAndAddress") + "}  is displayed");
		else
			reportFail("Customer Name and Address { " + testDataMap.get("NameAndAddress") + "}  is not displayed");
	}

	@Then("I verify the Customer Service Right side Information")
	public void i_verify_the_Customer_Service_Right_side_Information() {
		if (statementsPage.verifyCustomerRightSideInfo())
			reportPass(
					"Customer Service Information { " + testDataMap.get("CustomerRightSideInfo") + "}  is displayed");
		else
			reportFail("Customer Service Information { " + testDataMap.get("CustomerRightSideInfo")
					+ "}  is not displayed");
	}

	@Then("I verify the Customer Service Left side Information")
	public void i_verify_the_Customer_Service_Left_side_Information() {
		if (statementsPage.verifyCustomerLeftSideInfo())
			reportPass("Customer Service Information { " + testDataMap.get("CustomerLeftSideInfo") + "}  is displayed");
		else
			reportFail("Customer Service Information { " + testDataMap.get("CustomerLeftSideInfo")
					+ "}  is not displayed");
	}

	@Then("I verify the Checks Paid fields should diaplay")
	public void i_verify_the_Checks_Paid_fields_should_diaplay() {
		if (statementsPage.verifyChecksInformation(jsonDataParser.getTestDataMap()))
			reportPass("Checks details : {" + jsonDataParser.getTestDataMap().get("ChecksInformation")
					+ "} are successfully displayed");
		else
			reportFail("Checks details : {" + jsonDataParser.getTestDataMap().get("ChecksInformation")
					+ "} are not displayed");
	}

	@Then("I verify the Total number of checks paid field")
	public void i_verify_the_Total_number_of_checks_paid_field() {
		if (statementsPage.verifyNumberOfChecks())
			reportPass("Number of Checks { " + testDataMap.get("TotalNumberOfChecks") + "}  text is displayed");
		else
			reportFail("Number of Checks { " + testDataMap.get("TotalNumberOfChecks") + "}  text is not displayed");
	}

	@Then("I verify the Check Images were not displaying")
	public void i_verify_the_Check_Images_were_not_displaying() {
		if (statementsPage.checkImagesNotPresent())
			reportPass("Check Images were not displaying");
		else
			reportFail("Check Images were displayed");
	}

	@Then("I verify the NFS table fields should display")
	public void i_verify_the_NFS_table_fields_should_display() {
		if (statementsPage.verifyNFSTableFields(jsonDataParser.getTestDataMap()))
			reportPass("NFS details : {" + jsonDataParser.getTestDataMap().get("NFSFeeTableFields")
					+ "} are successfully displayed");
		else
			reportFail("NFS details : {" + jsonDataParser.getTestDataMap().get("NFSFeeTableFields")
					+ "} are not displayed");
	}

	@Then("I verify the Statement note")
	public void i_verify_the_Statement_note() {
		if (statementsPage.verifyStatementNote())
			reportPass("{ " + testDataMap.get("StmtNote") + "}  note is displayed");
		else
			reportFail(" { " + testDataMap.get("StmtNote") + "}  note is not displayed");
	}

	@Then("I verify the Transaction section sub headings")
	public void i_verify_the_Transaction_section_sub_headings() {
		if (statementsPage.verifyCategorySubSections(jsonDataParser.getTestDataMap()))
			reportPass("Category SubHeadings details : {"
					+ jsonDataParser.getTestDataMap().get("TransCategorySubHeadings") + "} are successfully displayed");
		else
			reportFail("Category SubHeadings details : {"
					+ jsonDataParser.getTestDataMap().get("TransCategorySubHeadings") + "} are not displayed");
	}

	@Then("I verify the Daily Balance fields should display")
	public void i_verify_the_Daily_Balance_fields_should_display() {
		if (statementsPage.verifyDailyBalanceFields(jsonDataParser.getTestDataMap()))
			reportPass("Daily Balance details : {" + jsonDataParser.getTestDataMap().get("DailyBalanceFields")
					+ "} are successfully displayed");
		else
			reportFail("Daily Balance details : {" + jsonDataParser.getTestDataMap().get("DailyBalanceFields")
					+ "} are not displayed");
	}

	@Then("I verify the Daily Balance Text should display")
	public void i_verify_the_Daily_Balance_Text_should_display() {
		if (statementsPage.verifyDailyBalanceText())
			reportPass("{ " + testDataMap.get("DailyBalanceText") + "}  text is displayed");
		else
			reportFail(" { " + testDataMap.get("DailyBalanceText") + "}  text is not displayed");
	}

	@Then("I verify the {string} in Deposit page")
	public void i_verify_the_in_Deposit_page(String message) {
		if (statementsPage.verifyDepositImagePage(message))
			reportPass("{ " + message + " } Page is displayed");
		else
			reportFail("{ " + message + " } Page is not displayed");
	}

	@Then("I verify the APY Statement {string} number is {string}")
	public void i_verify_the_APY_Statement_number_is(String accNumber, String accCheckBoxSts) {
		accNumber = (testDataMap.get("APYStatementAccount"));
		if (eDeliveryPreferencesPage.verifyAccountCheckBoxStatus(accNumber, accCheckBoxSts))
			reportPass(accNumber + " Account number is " + accCheckBoxSts);
		else
			reportFail(accNumber + " Account number is not " + accCheckBoxSts);
	}

}
