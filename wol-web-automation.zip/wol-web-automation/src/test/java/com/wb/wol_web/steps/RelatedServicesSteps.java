package com.wb.wol_web.steps;

import java.util.Arrays;
import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.RelatedServicesPage;
import com.wb.wol_web.pages.RequestBankingSuppliesPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RelatedServicesSteps extends ObjectBase {
	RelatedServicesPage relatedServicesPage = new RelatedServicesPage();
	RequestBankingSuppliesPage requestBankingSuppliesPage = new RequestBankingSuppliesPage();
	public String timestamp = "";
	public String message = "";

	@Then("I check for the message of {string}")
	public void i_check_for_the_message(String account) {
		message = jsonDataParser.getTestDataMap().get(account);
		if (relatedServicesPage.checkMessage(account, message))
			reportPass("Message: " + message + " is displayed");
		else
			reportFail("Message: " + message + " is not displayed");
	}

	@Then("I verify the details of {string} page")
	public void i_verify_the_details_of_page(String pageName) {
		String[] arrayLabelValues = jsonDataParser.getTestDataMap().get(pageName).split(";");
		List<String> listLabelValues = Arrays.asList(arrayLabelValues);
		if (listLabelValues.size() == relatedServicesPage.verifyLabels(pageName, listLabelValues))
			reportPass("Labels: " + listLabelValues.toString() + " are verified successfully");
		else
			reportFail("Labels: " + listLabelValues.toString() + " are not verified");
	}

	@Then("I verify the {string} details")
	public void i_verify_the_below_details(String pageName) {
		testDataMap = jsonDataParser.getTestDataMap();
		if (relatedServicesPage.checkForDetails(pageName, testDataMap) == testDataMap.size())
			reportPassWithFullPageScreenshot("Details: " + testDataMap.values().toString() + " are displayed");
		else
			reportFail("some detalis in " + testDataMap.values().toString() + " is not displayed");
	}

	@Then("I click on first transaction {string}")
	public void i_click_on_first_transaction(String btnName) {
		if (relatedServicesPage.clickOnButton(btnName))
			reportPass("Clicked on the " + btnName + " button");
		else
			reportHardFail("Not clicked on the " + btnName + " button");
	}

	@Then("I check and click on {string} checkbox under {string}")
	public void i_check_and_click_on_checkbox_under(String labelYes, String headerODServices) {
		if (relatedServicesPage.clickOnCheckboxUnderODHeader(labelYes, headerODServices))
			reportPass("Clicked on the " + labelYes + " under" + headerODServices);
		else
			reportHardFail("Not clicked on the " + labelYes + " under" + headerODServices);
	}

	@When("I click on {string} button of {string}")
	public void i_click_on_button_of(String btnName, String pageName) {
		if (relatedServicesPage.clickOnButton(btnName))
			reportPass("Clicked on the " + btnName + " button in page " + pageName);
		else
			reportHardFail("Not clicked on the " + btnName + " button in page " + pageName);
	}

	@Then("I check for the {string} radio button selected defaulty")
	public void i_check_for_the_yes_radio_button_selected_defaulty(String radioButton) {
		if (relatedServicesPage.verifyDefaultChecked(radioButton))
			reportPass("Yes checkbox is checked by default");
		else
			reportFail("Yes checkbox is not checked by default");
	}

	@When("I click on {string} under {string}")
	public void i_click_on_under(String txtRevokeOD, String txtODHeader) {
		if (relatedServicesPage.clickOnLinkUnderODHeader(txtRevokeOD, txtODHeader))
			reportPass("Clicked on the " + txtRevokeOD + " under" + txtODHeader);
		else
			reportHardFail("Not clicked on the " + txtRevokeOD + " under" + txtODHeader);
	}

	@Then("I should see lightbox of {string}")
	public void i_should_see_lightbox_of(String flowName) {
		String pageTitle = jsonDataParser.getTestDataMap().get(flowName);
		if (relatedServicesPage.checkLightboxTitle(flowName, pageTitle))
			reportPass("Redirected to " + pageTitle + " lightbox");
		else
			reportFail("Not Redirected to " + pageTitle + " lightbox");
	}

	@Then("I check for the {string} button")
	public void i_check_for_the_button(String btnName) {
		if (relatedServicesPage.checkForButton(btnName))
			reportPass("Button: " + btnName + " is displayed");
		else
			reportFail("Button: " + btnName + " is not displayed");
	}

	@When("I should see error text at labels of {string}")
	public void i_should_see_error_text_at_labels_as(String pageName) {
		String[] errorText = jsonDataParser.getTestDataMap().get(pageName).split(";");
		List<String> listErrorText = Arrays.asList(errorText);
		if (relatedServicesPage.checkErrorMessage(listErrorText))
			reportPass("error messages: " + listErrorText.toString() + " are displayed");
		else
			reportFail("error messages: " + listErrorText.toString() + " are not displayed");
	}

	@When("I select the {string} account from dropdown {string}")
	public void i_select_the_account_from_dropdown(String accountNumber, String labelName) {
		accountNumber = jsonDataParser.getTestDataMap().get(accountNumber);
		if (relatedServicesPage.selectAccount(accountNumber, labelName))
			reportPass("Account Number: " + accountNumber + " is selected in label: " + labelName);
		else
			reportFail("Account Number: " + accountNumber + " is not selected in label: " + labelName);
	}

	@Then("I enter the values into fields of {string}")
	public void i_enter_the_values_into_fields(String pageName) {
		String[] labels = jsonDataParser.getTestDataMap().get(pageName).split(";");
		List<String> listLabelNames = Arrays.asList(labels);
		List<String> listEnterdValues = relatedServicesPage.enterValues(listLabelNames);
		if (listEnterdValues.size() == listLabelNames.size())
			reportPass("Labels: " + listLabelNames + " with values: " + listEnterdValues + " are filled");
		else
			reportFail("Labels: " + listLabelNames + " with values: " + listEnterdValues + " are not filled");
	}

	@Then("I enter the values into fields with {string}")
	public void i_enter_the_values_into_fields_with(String labelType) {
		testDataMap = jsonDataParser.getTestDataMap();
		List<String> listEnterdValues = relatedServicesPage.enterValuesInput(testDataMap);
		if (listEnterdValues.size() == testDataMap.size())
			reportPass(
					"Labels: " + testDataMap.keySet().toString() + " with values: " + listEnterdValues + " are filled");
		else
			reportFail("Labels: " + testDataMap.keySet().toString() + " with values: " + listEnterdValues
					+ " are not filled");
	}

	@When("I click on first link")
	public void i_click_on_first_link() {
		if (relatedServicesPage.clickOnFirstLink())
			reportPass("Clicked on the first link");
		else
			reportHardFail("Not clicked on the first link");
	}

	@Then("I should see new checknumber")
	public void i_should_see_new_checknumber() {
		String checkNumber = relatedServicesPage.checkForCheckNumber();
		if (checkNumber != null)
			reportPass("CheckNumber: " + checkNumber + " is displayed");
		else
			reportFail("CheckNumber: " + checkNumber + " is not displayed");
	}

	@Then("I check for the {string} link is not displayed")
	public void i_check_for_the_link_is_not_displayed(String linkName) {
		if (relatedServicesPage.checkForLinkNotPrsent(linkName))
			reportPass("Link: " + linkName + " is not displayed");
		else
			reportFail("Link: " + linkName + " is displayed");
	}

	@Then("I select the {string} value")
	public void value(String value) {
		if (relatedServicesPage.selectValueFromDropDown(value))
			reportPass("Selected the value: " + value + " from dropdown");
		else
			reportFail("Not able to select the value: " + value + " from dropdown");
	}

	@Then("I should see new window with {string}")
	public void i_should_see_new_window_with(String pageTitle) {
		if (relatedServicesPage.checkChildPageTitle(pageTitle))
			reportPassWithFullPageScreenshot("Redirected to " + pageTitle + " page");
		else
			reportFailWithFullPageScreenshot("Not Redirected to " + pageTitle + " page");
	}

	@Then("I should see the {string} page")
	public void i_should_see_the_page(String pageName) {
		if (relatedServicesPage.checkPageHeading(pageName))
			reportPass("Redirected to " + pageName + " page");
		else
			reportFail("Not Redirected to " + pageName + " page");
	}

	@Then("I check for current and future dates are disabled")
	public void i_check_for_current_and_future_dates_are_disabled() {
		if (relatedServicesPage.checkForCurrentAndFutureDatesDisabled())
			reportPass("Current and Future Dates are disabled");
		else
			reportFail("Current and Future Dates are enabled");
	}

	@Then("I verify the transactions sorted by date")
	public void i_verify_the_transactions_sorted_by_date() {
		if (relatedServicesPage.checkForTransactionSort())
			reportPass("Transactions are sorted with date");
		else
			reportFail("Transactions are not sorted with date");
	}

	@Then("I check for the timestamp")
	public void i_check_for_the_timestamp() {
		timestamp = relatedServicesPage.checkForTimestamp();
		if (timestamp != null)
			reportPass("Transaction timestamp is displayed");
		else
			reportFail("Transaction timestamp is not displayed");
	}

	@Then("I search for the confirmation time and username of {string} request type from the search result")
	public void i_search_for_the_confirmation_time_and_username_of_request_type_from_the_search_result(String reqtype) {
		if (requestBankingSuppliesPage.checkTheConfirmationDetailsInWebcom(reqtype, timestamp))
			reportPass("Found the order details in webcom, Order for " + reqtype + " placed on " + timestamp);
		else
			reportFail("Failed to find the order details in webcom");
	}
}