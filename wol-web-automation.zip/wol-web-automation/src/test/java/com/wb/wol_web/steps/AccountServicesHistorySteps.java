package com.wb.wol_web.steps;

import java.util.List;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AccountServicesHistoryPage;
import cucumber.api.java.en.Then;

public class AccountServicesHistorySteps extends ObjectBase {

	AccountServicesHistoryPage accountServicesHistoryPage = new AccountServicesHistoryPage();

	@Then("I should see the labels of Account Services History")
	public void i_should_see_the_labels_of_Account_Services_History() {
		List<String> labels = accountServicesHistoryPage.checkForLabels(testDataMap);
		if (labels.size() == 0)
			reportPass("All Labels: " + testDataMap.values().toString() + " are displayed");
		else
			reportFail("Labels: " + labels.toString() + " are not displayed");

	}
}