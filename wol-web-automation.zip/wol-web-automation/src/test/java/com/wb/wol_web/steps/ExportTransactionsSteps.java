package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.ExportTransactionsPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

/**
 * @author: Ravi kumar Maddula
 *
 */

public class ExportTransactionsSteps extends ObjectBase {

	ExportTransactionsPage exportTransactions = new ExportTransactionsPage();
	List<String> listValues;
	@Then("^Should be reach \"([^\"]*)\" page$")
	public void should_be_reach_page(String header) throws Throwable {
		if (exportTransactions.checkThePageHeading(header)) {
			reportPass("Reached the " + header + " page");
		} else {
			reportFail("Failed to reach " + header + " page");
		}
	}

	@When("^Select \"([^\"]*)\" account from Webster account$")
	public void select_account_from_Webster_account(String account) throws Throwable {
		if (exportTransactions.selectAccount(account)) {
			reportPass("Selected " + account + " from drop down.");
		} else {
			reportHardFail("Failed due to account selection failure");
		}

	}

	@When("^Select \"([^\"]*)\" from Format list$")
	public void select_from_Format_list(String format) throws Throwable {
		if (exportTransactions.selectFormat(format)) {
			reportPass("Selected " + format + " from drop down.");
		} else {
			reportFail("Failed to select " + format + " from the drop down");
		}
	}

	@When("^Select \"([^\"]*)\" from Time Period list$")
	public void select_from_Time_Period_list(String period) throws Throwable {
		if (exportTransactions.selectTimePeriod(period)) {
			reportPass("Selected " + period + " from drop down.");
		} else {
			reportFail("Failed to select " + period + " from the drop down");
		}
	}

	@When("^Select prevoius statement from Time Period list$")
	public void select_prevoius_statement_from_Time_Period_list() throws Throwable {
		if (exportTransactions.selectPreviousStatement()) {
			reportPass("Selected previous statement from drop down.");
		} else {
			reportFail("Failed to select previous statement from drop down");
		}

	}

	@When("^Select \"([^\"]*)\" days back From date$")
	public void slect_days_back_From_date(String day) throws Throwable {
		String date = exportTransactions.enterFromDate(day);
		if (date != null) {
			reportPass("Entered From date- " + date);
		} else {
			reportFail("Failed due to create old date- ");
		}

	}

	@When("^Select \"([^\"]*)\" to days as To date$")
	public void select_to_days_as_To_date(String day) throws Throwable {
		String date = exportTransactions.enterToDate(day);
		if (date != null) {
			reportPass("Entered To date- " + date);
		} else {
			reportFail("Failed due to create old date- ");
		}

	}

	@When("^click on \"([^\"]*)\" button from Transactions page$")
	public void click_on_button_from_Transactions_page(String button) throws Throwable {
		exportTransactions.clickOnContinueButton();
	}

	@Then("^Should be reach \"([^\"]*)\" with transactions result$")
	public void should_be_reach_with_transactions_result(String text) throws Throwable {
		if (exportTransactions.checkTransPreviewHeading(text)) {
			reportPass("Reached the " + text + " page");
		} else {
			reportFail("Failed to reach " + text + " page");
		}
	}

	@When("^Verify transaction results from preview table$")
	public void verify_transaction_results_from_preview_table() throws Throwable {
		if (exportTransactions.verifyDateRangeFromTable()) {
			reportPass("Verified dates from preview table successfully");
		} else {
			reportHardFail("Failed to verify date range in table");
		}

	}

	@When("^Click on \"([^\"]*)\" button from Export transaction preview page$")
	public void click_on_button_from_Export_transaction_preview_page(String arg1) throws Throwable {
		if (exportTransactions.clickOnExportButton()) {
			reportPass("Clicked on Export button");
		} else {
			reportHardFail("Failed to click on Export button");
		}

	}

	@Then("Verify downloaded file {string} from downloads folder with {string} file")
	public void verify_downloaded_file_from_folder_with_file(String file, String extension) {
		if (exportTransactions.verifyFileData(file, extension)) {
			reportPass("Verified downloaded file content successfully");
		} else {
			reportHardFail("Failed to verify downloaded file content");
		}

	}

	@Then("Verify downloaded file {string} from downloads folder with {string} file is empty")
	public void verify_downloaded_file_from_folder_with_file_is_empty(String file, String extension) {
		if (exportTransactions.verifyFileIsEmpty(file, extension)) {
			reportPass("Verified downloaded file and not containing data");
		} else {
			reportHardFail("File containing datanot empty and failed");
		}

	}

	@Then("^Should be reach \"([^\"]*)\" page with Export options$")
	public void should_be_reach_page_with_Export_options(String text) throws Throwable {
		if (exportTransactions.checkTransHistoryHeading(text)) {
			reportPass("Verified Transactions history page header");
		} else {
			reportFail("Fail to verify Transactions history page header");
		}

	}

	@When("^Click on account dropdown$")
	public void click_on_account_dropdown() throws Throwable {
		exportTransactions.clickOnAccount();
	}

	@When("^Select \"([^\"]*)\" account from Transaction history page$")
	public void select_account_from_Transaction_history_page(String account) throws Throwable {
		if (exportTransactions.selectCheckAccount(account)) {
			reportPass("Selected " + account + " from drop down.");
		} else {
			reportFail("Unable to select" + account + " from drop down.");
		}
	}

	@When("^Select \"([^\"]*)\" from the Date Range drop down$")
	public void select_from_the_Date_Range_drop_down(String range) throws Throwable {
		if (exportTransactions.selectDateRange(range)) {
			reportPass("Selected " + range + " from drop down.");
		} else {
			reportFail("Failed to select date range from drop down");
		}

	}

	@Then("^From date should be prefilled and disabled$")
	public void from_date_should_be_prefilled_and_disabled() throws Throwable {
		if (exportTransactions.verifyFromDateDisable()) {
			reportPass("From date icon verified and Disabled");
		} else {
			reportFail("Failed to verify From date icon and Enabled");
		}

	}

	@Then("^To date should be prefilled and disabled$")
	public void to_date_shoukld_be_prefilled_and_disabled() throws Throwable {
		if (exportTransactions.verifyToDateDisable()) {
			reportPass("To date icon verified and Disabled");
		} else {
			reportFail("Failed to verify To date icon and Enabled");
		}
	}

	@When("^Click on \"([^\"]*)\" drop down list$")
	public void click_on_drop_down_list(String value) throws Throwable {
		exportTransactions.clickOnDownLoad();

	}

	@Then("^Verify \"([^\"]*)\" containing below list values$")
	public void verify_containing_below_list_values(String download) throws Throwable {
		listValues=new ArrayList<String>();
		listValues.addAll(jsonDataParser.getTestDataMap().values());
		if (exportTransactions.verifyDownLoadListValues(listValues)) {
			reportPass("Verified all the values from download list");
		} else {
			reportFail("Unable to select" + listValues.toString() + " from download list");
		}

	}

	@When("^Select \"([^\"]*)\" option from Download list$")
	public void select_option_from_Download_list(String selectVal) throws Throwable {
		if (exportTransactions.selectValueFromList(selectVal)) {
			reportPass("Selected " + selectVal + " from download list");
		} else {
			reportFail("Unable to select" + selectVal + " from download list");
		}

	}

	@When("Uncheck all the transactions from Transaction preview table")
	public void uncheck_all_the_transactions_from_Transaction_preview_table() {
		if (exportTransactions.clickOnClearAll()) {
			reportPass("Clicked on clear all link");
		} else {
			reportFail("Not able to click on clear all link");
		}

	}

	@When("Select few transactions from Tansaction preview table")
	public void select_few_transactions_from_Tansaction_preview_table() {
		if (exportTransactions.selectTransactions()) {
			reportPass("Clicked on transaction check box");
		} else {
			reportFail("Not able to click on check box");
		}
	}

	@When("I have click on Update button")
	public void i_have_click_on_Update_button() {
		if (exportTransactions.clickOnUpdateButton()) {
			reportPass("Clicked on update button");
		} else {
			reportFail("Not able to click on update button");
		}

	}

	@Then("Verify Pending transactions list and collect a transaction details")
	public void verify_Pending_transactions_list_and_collect_a_transaction_details() {
		if (exportTransactions.verifyPendingTarnsactions()) {
			reportPass("Pending transactions are avilabale");
		} else {
			reportHardFail("Pending transactions are not availabale to get date");
		}
	}

	@Then("Verify transaction results from preview table for pending transactions")
	public void verify_transaction_results_from_preview_table_for_pending_transactions() {
		if (exportTransactions.verifyPendingTransactionTable()) {
			reportPass("Pending transactions are not present in the table");
		} else {
			reportFail("Pending transactions are present in the table");
		}
	}

	@Then("Verify default values {string},{string} and {string} from dropdowns")
	public void verify_default_values_and_from_dropdowns(String account, String format, String timePeriod) {
		if (exportTransactions.verifyDefaultValues(account, format, timePeriod)) {
			reportPass("Verified default values successfully from drop downs");
		} else {
			reportFail("Failed to verify default values");
		}

	}

	@Then("Verify error message {string} from date field")
	public void verify_error_message_from_date_field(String errorMessage) {
		if (exportTransactions.verifyFromError(errorMessage)) {
			reportPass("From date error verified successfully");
		} else {
			reportFail("From date error verification failed");
		}
	}

	@Then("Verify error message {string} to date field")
	public void verify_error_message_to_date_field(String errorMessage) {
		if (exportTransactions.verifyToError(errorMessage)) {
			reportPass("To date error verified successfully");
		} else {
			reportFail("To date error verification failed");
		}
	}

	@Then("Verify error message {string} from page")
	public void verify_error_message_from_page(String errorMessage) {
		if (exportTransactions.verifyPageError(errorMessage)) {
			reportPass("Transactions page level error verified successfully");
		} else {
			reportFail("Failed to verify Transactions page level error");
		}

	}

	@Then("Verify verbiage {string} from Export transactions page")
	public void verify_verbiage_from_Export_transactions_page(String verbiage) {
		if (exportTransactions.verifyVerbiage(verbiage)) {
			reportPass("Export Transactions page level verbiage verified successfully" + verbiage);
		} else {
			reportFail("Failed to verify Export Transactions page level verbiage");
		}

	}

	@Then("Verify top message {string} from preview page")
	public void verify_top_message_from_preview_page(String topError) {
		if (exportTransactions.verifyFirstMessage(topError)) {
			reportPass("Export Transactions page level top error verified successfully" + topError);
		} else {
			reportHardFail("Failed to verify Export Transactions page level error");
		}
	}

	@Then("Verify second message {string} from preview page")
	public void verify_second_message_from_preview_page(String error) {
		if (exportTransactions.verifySecondMessage(error)) {
			reportPass("Export Transactions page level second error verified successfully" + error);
		} else {
			reportHardFail("Failed to verify Export Transactions page level second error");
		}
	}

	@Then("I verify the Format drop down values")
	public void i_verify_the_Format_drop_down_values() {
		if (exportTransactions.verifyFormatDropdownValues())
			reportPass("All options were present in the List");
		else
			reportFail("All options were not present in the List");
	}

	@When("I click on cancel button in Export transaction page")
	public void i_click_on_cancel_button_in_Export_transaction_page() {
		if (exportTransactions.clickOnCancelButton()) {
			reportPass("Clicked on Cancel button");
		} else
			reportFail("Unable to click on Cancel button");
	}

	@When("I select Yes button")
	public void i_select_Yes_button() {
		if (exportTransactions.clickOnYesButton()) {
			reportPass("Clicked on Yes button");
		} else
			reportFail("Unable to click on Yes button");
	}

	@When("I select No button")
	public void i_select_No_button() {
		if (exportTransactions.clickOnNoButton()) {
			reportPass("Clicked on No button");
		} else
			reportFail("Unable to click on No button");
	}

	@When("I select the account from Webster Account")
	public void i_select_the_account_from_Webster_Account() {
		if (exportTransactions.selectAccount(testDataMap.get("AccountNumber"))) {
			reportPass("Selected " + testDataMap.get("AccountNumber") + " from drop down.");
		} else
			reportFail("Failed due to account selection failure");
	}

	@When("I select the format type from Format list")
	public void i_select_the_format_type_from_Format_list() {
		if (exportTransactions.selectFormat(testDataMap.get("FormatType"))) {
			reportPass("Selected " + (testDataMap.get("FormatType") + " from drop down."));
		} else
			reportFail("Failed to select " + (testDataMap.get("FormatType") + " from the drop down"));
	}

	@When("I select Custom Range from Time Period list")
	public void i_select_Custom_Range_from_Time_Period_list() {
		if (exportTransactions.selectTimePeriod(testDataMap.get("CustomRange"))) {
			reportPass("Selected " + (testDataMap.get("CustomRange") + " from drop down."));
		} else {
			reportFail("Failed to select " + (testDataMap.get("CustomRange") + " from the drop down"));
		}
	}

	@When("I enter few days back for From date")
	public void i_enter_few_days_back_for_From_date() {
		String date = exportTransactions.enterFromDate(testDataMap.get("FromDate"));
		if (date != null) {
			reportPass("Entered From date- " + date);
		} else {
			reportFail("Failed due to enter from date ");
		}

	}

	@When("I enter zero days back for To date")
	public void i_enter_zero_days_back_for_To_date() {
		String date = exportTransactions.enterToDate(testDataMap.get("ToDate"));
		if (date != null) {
			reportPass("Entered To date- " + date);
		} else {
			reportFail("Failed due to enter to date ");
		}

	}

	@When("I select Since Last Statement from Time Period list")
	public void i_select_Since_Last_Statement_from_Time_Period_list() {
		if (exportTransactions.selectTimePeriod(testDataMap.get("LastStatement"))) {
			reportPass("Selected " + (testDataMap.get("LastStatement") + " from drop down."));
		} else {
			reportFail("Failed to select " + (testDataMap.get("LastStatement") + " from the drop down"));
		}
	}

	@Then("I verify the Transaction fields")
	public void i_verify_the_Transaction_fields() {
		if (exportTransactions.verifyTransTableFields(jsonDataParser.getTestDataMap()))
			reportPass("Transaction details : {" + jsonDataParser.getTestDataMap().get("TransactionFields")
					+ "} are successfully displayed");
		else
			reportFail("Transaction details : {" + jsonDataParser.getTestDataMap().get("TransactionFields")
					+ "} are not displayed");
	}
}
