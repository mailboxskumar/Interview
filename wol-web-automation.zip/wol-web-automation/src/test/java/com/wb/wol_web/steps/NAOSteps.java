package com.wb.wol_web.steps;

import java.util.HashMap;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.NAOPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class NAOSteps extends ObjectBase {

	NAOPage naoPage = new NAOPage();

	@When("I click on the {string} tab and click on {string} link from the list")
	public void i_hover_on_link_and_click_on_link_from_the_list(String mainElement, String subElement)
			throws Exception {
		if (naoPage.selectFromHomepage(mainElement, subElement)) {
			reportPass("Clicked on the {" + mainElement + "} tab and selected {" + subElement + "} sub menu");
		} else {
			reportHardFail("Failed to click on the " + subElement + " under " + mainElement);
		}
	}

	@When("^I click on the account$")
	public void i_click_on_the_account() {
		try {
			naoPage.clickOnTheAccount(jsonDataParser.getTestDataMap().get("AccountType"));
			reportPass("Clicked on the account type " + jsonDataParser.getTestDataMap().get("AccountType"));
		} catch (Exception e) {
			reportHardFail("Failed to click on the account " + e.getMessage());
		}
	}

	@Then("I check for the page heading {string}")
	public void i_check_for_the_page_heading(String pageHeading) {
		if (naoPage.checkForStartPageHeading(pageHeading))
			reportPass("Reached the starting page with heading : " + pageHeading);
		else
			reportFail("Heading " + pageHeading + " is not found ");
	}

	@Then("I enter the details in email verification page")
	public void i_enter_email_details() throws Exception {
		if (naoPage.enterEmailDetails(jsonDataParser.getTestDataMap())) {
			reportPass("Entered the email address as " + jsonDataParser.getTestDataMap().get("Email"));
		} else {
			reportHardFail("Failed to enter the email address");
		}
	}

	@When("I enter the details in personal information page")
	public void i_enter_personal_details() {
		try {
			naoPage.enterPersonalInformationDetails(jsonDataParser.getTestDataMap());
			reportPass("Entered all the personal details successfully ");
		} catch (Exception e) {
			reportHardFail("Failed  to enter the details in personal information page ");
		}
	}

	@When("I enter the details in driving license information page")
	public void i_enter_dl_details() {
		try {
			naoPage.enterDLInformationDetails(jsonDataParser.getTestDataMap());
			reportPass("Entered all the driving license details successfully as - Driver's License Number:"
					+ jsonDataParser.getTestDataMap().get("Driver's License Number") + " , Driver's License Issue Date:"
					+ jsonDataParser.getTestDataMap().get("Driver's License Issue Date") + ""
					+ " , Driver's License Expiration Date:"
					+ jsonDataParser.getTestDataMap().get("Driver's License Expiration Date") + ", Issued State:"
					+ jsonDataParser.getTestDataMap().get("State Full Name"));
		} catch (Exception e) {
			reportHardFail("Failed to enter driving license details");
		}
	}

	@And("^I check the tooltip message for \"([^\"]*)\" label$")
	public void check_the_tooltips_pep_questions(String labelType) throws Exception {
		if (naoPage.checkTheToolTipForAnyLabel(labelType, jsonDataParser.getTestDataMap().get(labelType)))
			reportPass("Tooltip is found for the " + labelType);
		else
			reportFail("Tooltip is not found for " + labelType);

	}

	@Then("I check that no debit card section is present")
	public void i_check_that_no_debit_card_section_is_present() {
		if (!naoPage.checkForCardBlock())
			reportPass("Debit card section is not present");
		else
			reportFail("Debit card section is present");
	}

	@Then("I check for the debit card section and select the card type")
	public void i_check_for_the_debit_card_sections_and_select_the_card_type() {
		if (naoPage.checkForCardBlock()) {
			if (naoPage
					.selectTheDebitCardType(jsonDataParser.getTestDataMap().get("Send Free Webster Visa Debit Card"))) {
				reportPass("Selected " + jsonDataParser.getTestDataMap().get("Send Free Webster Visa Debit Card")
						+ "for debit card");
			} else {
				reportFail("Failed to select the debit card type");
			}
		}
	}

	@Then("^I should be in \"([^\"]*)\" page in NAO functionality$")
	public void i_should_in_identification_info_page(String pageTitle) {
		if (naoPage.checkThePageTitle(pageTitle)) {
			reportPass("Reached the { " + pageTitle + " } page");
		} else {
			reportHardFail("Page not found " + pageTitle);
		}
	}

	@Then("^I verify the data displayed in verfication page is same as the data entered$")
	public void compareData() {
		if (naoPage.verifyDataKeyedInWithDataDisplayedInDOM()) {
			reportPass("Data displayed in verfication page is same as the data entered " + wolWebUtil.returnMap);
		} else {
			reportFail("Data displayed in verfication page is not same as the data entered ");
		}
	}

	@And("^I select the answers to politically exposed persons questions$")
	public void i_select_pep_questions() {
		try {
			naoPage.selectCitizenship(jsonDataParser.getTestDataMap().get("Country of Citizenship Full Name"));
			naoPage.selectIdentificationInfo(jsonDataParser.getTestDataMap().get("Affiliations Question 1"),
					jsonDataParser.getTestDataMap().get("Affiliations Question 2"));
			reportPass("Selected all the identification details PEPQuestion1: "
					+ jsonDataParser.getTestDataMap().get("Affiliations Question 1") + " and PEPQuestion2 as "
					+ jsonDataParser.getTestDataMap().get("Affiliations Question 2"));
		} catch (Exception e) {
			reportHardFail("Failed to select the answers to politically exposed persons questions");
		}
	}

	@Then("^I select the type of employment status of the user$")
	public void i_select_the_employment_status() {
		try {
			naoPage.selectEmpStatusInfo(jsonDataParser.getTestDataMap().get("Employment Status"));
			reportPass("Selected all the employment status details as :"
					+ jsonDataParser.getTestDataMap().get("Employment Status"));
		} catch (Exception e) {
			reportHardFail("Failed to select the employment status of the user ");
		}
	}

	@Then("^I enter the employment details of the user$")
	public void i_enter_the_employment_details() {
		try {
			naoPage.enterEmploymentDetails();
			reportPass("Entered all the employment status details as Employer Name:"
					+ jsonDataParser.getTestDataMap().get("Employer Name") + " and Job Title as "
					+ jsonDataParser.getTestDataMap().get("Job Title"));
		} catch (Exception e) {
			reportHardFail("Failed to enter employment details");
		}
	}

	@Then("^I enter the username details of the user$")
	public void i_enter_the_username_details() {
		try {
			naoPage.enterUserNameDetails(jsonDataParser.getTestDataMap());
			reportPass("Entered all the username details successfully");
		} catch (Exception e) {
			reportHardFail("Failed to enter the username details ");
		}
	}

	@And("^I check if the account name is displayed correct in review page$")
	public void i_check_if_the_accountname_is_displayed_correct() {
		if (naoPage.checkAccountNameInReviewPage(jsonDataParser.getTestDataMap().get("AccountType") + ","
				+ jsonDataParser.getTestDataMap().get("Account Requested")))
			reportPass("Account Name is displayed properly in review account page");
		else
			reportFail("Account Name is not displayed properly in review account page");
	}

	@Then("I select the following values for the questions in Account Information page")
	public void i_select_the_following_values_in_Account_Information_page() {
		try {
			naoPage.selectCashFlowAndWiredServices(
					jsonDataParser.getTestDataMap().get("Average Monthly Cash Deposit Amount"),
					jsonDataParser.getTestDataMap().get("Average Monthly Cash Withdrawal Amount"));
			naoPage.selectInternatonalWiredServies(jsonDataParser.getTestDataMap().get("International Wire Transfers"));
			reportPass("selected all the account information details successfully");
		} catch (Exception e) {
			reportHardFail("Failed to select the cash questions ");
		}

	}

	@And("^I select the overdraft service and statement edelivery options$")
	public void i_select_ocerdraft_and_edelivery_services() {
		try {
			naoPage.selectOverdraftAndeDeliveryServices(
					jsonDataParser.getTestDataMap().get("Sign up for Debit Card Overdraft Services"),
					jsonDataParser.getTestDataMap().get("Sign up for eDelivery"));
			reportPass("Entered all the overdraft and  eDelivery details successfully");
		} catch (Exception e) {
			reportHardFail("Failed to select overdraft service and statement edelivery options ");
		}
	}

	@And("^I click on continue button in NAO functionality$")
	public void click_on_continue() throws Exception {
		if (naoPage.clickOnContinue()) {
			reportPass("Clicked on continue button successfully");
		} else {
			reportHardFail("Failed to click on continue button");
		}
	}

	@Then("^I select the suitable options to emulation questions$")
	public void selectOptionsForEmulationsQuestions() {
		try {
			naoPage.selectEmulationQuestions(jsonDataParser.getTestDataMap().get("Emulation Question1"),
					jsonDataParser.getTestDataMap().get("Emulation Question2"));
			reportPass("Selected the options in emulation questions successfully");
		} catch (Exception e) {
			reportHardFail("Failed to select emulation questions");
		}
	}

	@Then("^I select all the disclosures checkboxes in the page$")
	public void selectAllDisclosures() {
		try {
			naoPage.selectAllDisclosures();
			reportPass("Selected all the disclosures successfully");
		} catch (Exception e) {
			reportHardFail("Failed to select all the disclosures ");
		}
	}

	@Then("I look for the congratulations message in confirmation page")
	public void i_look_for_the_congratulations_message_in_confirmation_page() {
		if (naoPage.validateConfirmationMessage())
			reportPass("Congratulation message is found in the confirmation page");
		else
			reportFail("Congratulation message is not found in the confirmation page");
	}

	@Then("I validate the data generated according to the account type and accountname is same as account selected$")
	public void i_validate_the_data_generated_according_to_the_account_type() throws Exception {
		try {
			HashMap<String, String> details = naoPage.getSystemGeneratedConfirmationDetails();
			if (jsonDataParser.getTestDataMap().get("AccountType").contains(details.get("Account Type")))
				reportPass("Account Type in confirmation page is same as "
						+ jsonDataParser.getTestDataMap().get("AccountType"));
			if (details.get("Routing Number").equalsIgnoreCase(jsonDataParser.getTestDataMap().get("Routing Number")))
				reportPass("Routing Number  " + details.get("Routing Number")
						+ " in confirmation page is correctly generated ");
			else
				reportFail("Routing Number is not correct");

			if (details.get("Account Number").matches("^[0-9]+$"))
				reportPass("Account Number is generated in confirmation page " + details.get("Account Number"));
			else
				reportFail("Account Number is not correct");
		} catch (Exception e) {
			reportHardFail("Failed to get account details from the confirmation page");
		}
	}

	@When("^I click on Existing Customer Link$")
	public void i_click_on_existing_customer_link() throws Throwable {
		if (naoPage.clickExistingCustomer())
			reportPass("Clicked on Existing customer? Link");
		else
			reportHardFail("Failed to click on Existing customer? Link");
	}

	@Then("I should get the error message for personally exposed questions")
	public void i_should_get_the_error_message_for_personally_exposed_questions() {
		String status = naoPage.checkForThePEPErrorMessages();
		if (status.equals("true1,true2")) {
			reportPass("Found the error message " + jsonDataParser.getTestDataMap().get("PEP Error Message")
					+ " for both the questions");
		} else if (status.equals("true1")) {
			reportPass("Found the error message " + jsonDataParser.getTestDataMap().get("PEP Error Message")
					+ " for only question 1");
		} else if (status.equals("true2")) {
			reportPass("Found the error message " + jsonDataParser.getTestDataMap().get("PEP Error Message")
					+ " for only question 2");
		} else
			reportFail("Failed to find the error message " + jsonDataParser.getTestDataMap().get("PEP Error Message")
					+ " for both the questions");
	}

	@Then("I should get the error message for cash questions")
	public void i_should_get_the_error_message_for_cash_questions() {
		String status = naoPage.checkForTheCashErrorMessages();
		if (status.equals("true1,true2")) {
			reportPass("Found the error message {" + jsonDataParser.getTestDataMap().get("Cash Error Message")
					+ "} for both the questions");
		} else if (status.equals("true1")) {
			reportPass("Found the error message {" + jsonDataParser.getTestDataMap().get("Cash Error Message")
					+ "} for cash in question ");
		} else if (status.equals("true2")) {
			reportPass("Found the error message {" + jsonDataParser.getTestDataMap().get("Cash Error Message")
					+ "} for cash out question ");
		} else
			reportFail("Failed to find the error message {" + jsonDataParser.getTestDataMap().get("Cash Error Message")
					+ "} for both the questions");
	}

	@Then("I select the citizenship option in the page")
	public void i_select_the_citizenship_option_in_the_page() {
		try {
			naoPage.selectCitizenship(jsonDataParser.getTestDataMap().get("Country of Citizenship Full Name"));
			reportPass("Selected the citizenship as "
					+ jsonDataParser.getTestDataMap().get("Country of Citizenship Full Name"));
		} catch (Exception e) {
			reportHardFail("Failed to select the citizenship");
		}
	}

	@Then("I select the international wired services")
	public void i_select_the_international_wired_services() {
		try {
			naoPage.selectInternatonalWiredServies(jsonDataParser.getTestDataMap().get("International Wire Transfers"));
			reportPass("Selected the international wire services as "
					+ jsonDataParser.getTestDataMap().get("Cash Error Message"));
		} catch (Exception e) {
			reportHardFail("Failed to select international wire services");
		}
	}

	@Then("I check for the three bullet points which specifies the types of information needed")
	public void i_check_for_the_three_bullet_points_which_specifies_the_types_of_information_needed() {
		String bulletPoints = naoPage.checkForTheBulletPoints();
		String dataFromMap = jsonDataParser.getTestDataMap().get("List of Bullet Points") + ",";

		if (dataFromMap.equals(bulletPoints)) {
			reportPass("All the three bullet points are present " + dataFromMap);
		} else {
			reportFail("Some of the bullet points are missing.Only " + bulletPoints + " are present");
		}
	}

	@Then("I get the data from the review personal information page")
	public void i_get_the_data_from_the_review_personal_information_page() {
		try {
			naoPage.getAllThePersonalDetails();
		} catch (Exception e) {
			reportFail("Failed to get the personal information");
		}
	}

	@Then("I select the international wire tansaction type and the amount intended to transfer")
	public void i_select_the_international_wire_transfer_type() {
		try {
			naoPage.selectInternationalWiredServicesForYes();
			reportPass("Selected the international wire transaction type");
		} catch (Exception e) {
			reportHardFail("Falied to select the international wire transaction type");
		}
	}

	@Then("I should get the appropriate negative confirmation text for invalid emulator questions")
	public void i_should_get_the_appropriate_negative_confirmation_text_invalid() {
		if (naoPage.checkForNegativeConfirmationText("InvalidEmulatorQuestions")) {
			reportPass("Found the negative confirmation text for invalid emulator questions");
		} else
			reportFail("Could not find the negative confirmation text for invalid emulator questions");
	}

	@Then("I should get the appropriate negative confirmation text for failed efunds")
	public void i_should_get_the_appropriate_negative_confirmation_falied_efunds() {
		if (naoPage.checkForNegativeConfirmationText("InvalidEmulatorQuestions")) {
			reportPass("Found the negative confirmation text for failed efunds");
		} else
			reportFail("Could not find the negative confirmation text for failed efunds");
	}

	@Then("I should get the appropriate negative confirmation text")
	public void i_should_get_the_appropriate_negative_confirmation_text() {
		if (naoPage.checkForNegativeConfirmationText("ExistingCustomerNewCDD")) {
			reportPass("Found the negative confirmation text");
		} else
			reportFail("Could not find the negative confirmation text");
	}

	@Then("I should get the appropriate negative confirmation text for Non US and Non Resident")
	public void i_should_get_the_appropriate_negative_confirmation_text_NOn_US() {
		if (naoPage.checkForNegativeConfirmationText("NonUSNonResident")) {
			reportPass("Found the negative confirmation text for Non US and Non Resident");
		} else
			reportFail("Could not find the negative confirmation text for Non US and Non Resident");
	}

	@When("I enter the existing ssn and dob of an user")
	public void i_enter_the_existing_ssn_and_dob_of_an_user() {
		try {
			naoPage.enterSsnAndDob();
			reportPass("Entered existing DOB and SSN values ");
		} catch (Exception e) {
			reportHardFail("Falied to enter DOB and SSN");
		}
	}

	@Then("I should get the sign in notice as user is already enrolled")
	public void i_should_get_the_sign_in_notice_as_user_is_already_enrolled() {
		if (naoPage.checkForAlreadyEnrolledNotice()) {
			reportPass("Found the sign in notice as user is already enrolled");
		} else
			reportHardFail("Could not find the sign in notice ");
	}

	@Then("I click on sign in link in NAO page")
	public void i_click_on_sign_in_link_in_NAO_page() {
		if (naoPage.clickOnSignInLink()) {
			reportPass("Clicked on the sign in link");
		} else
			reportHardFail("Could not click on the sign in link");
	}

	@Then("I select the residential status of the user")
	public void i_select_the_residential_status_of_the_user() {
		if (naoPage.clickOnResidentAlienType()) {
			reportPass("Clicked on residential status: " + jsonDataParser.getTestDataMap().get("Resident Status"));
		} else
			reportHardFail("Could not click on residential status");
	}

	@Then("I click on the debit card overdraft services link")
	public void i_click_on_the_debit_card_overdraft_services_link() {
		if (naoPage.clickOnOverDraftLink()) {
			reportPass("Clicked on the  debitcard service link");
		} else
			reportFail("Could not click on debitcard service link");
	}

	@Then("I look for successfully applied for new account message")
	public void i_look_for_successfully_applied_for_new_account_message() {
		if (naoPage.checkForSuccessfulAppliedMessage()) {
			reportPass(
					"Found the text {" + jsonDataParser.getTestDataMap().get("Successfully Applied For Account") + "}");
		} else
			reportFail("Could not find the text {"
					+ jsonDataParser.getTestDataMap().get("Successfully Applied For Account") + "}");
	}

	@Then("I click on overdraft disclosure link and verify the text")
	public void i_click_on_overdraft_disclosure_link_and_verify_the_text() {
		if (naoPage.clickOnOverDraftLink()) {
			if (naoPage.verifyTheDisclosureContent()) {
				reportPass("Found the overdraft disclosure content successfully");

			} else
				reportFail("Could not find the overdraft disclosure content");
		}
	}

	@Then("I check all the edit buttons are present in the page")
	public void i_check_all_the_edit_buttons_are_present_in_the_page() {
		String buttonsDisplayed = naoPage.checkForTheEditButtons(jsonDataParser.getTestDataMap().get("Edit Buttons"),
				false);
		if (buttonsDisplayed.equals(jsonDataParser.getTestDataMap().get("Edit Buttons") + ",")) {
			reportPass("Found all the edit buttons in review page");
		} else
			reportFail("Only " + buttonsDisplayed + " buttons are displayed in the page");
	}

	@Then("I close the overdraft disclosure")
	public void i_close_the_overdraft_disclosure() {
		if (!naoPage.closeOverDraftDisclosure())
			reportHardFail("Failed to close the overdraft disclosure");
	}

	@Then("I select the CD account type")
	public void i_select_the_CD_account_type() {
		if (naoPage.clickOnCDAccType()) {
			reportPass("Clicked on the CD account : " + jsonDataParser.getTestDataMap().get("Account Requested"));
		} else
			reportHardFail("Failed to click on the CD account");

	}

	@Then("I look for the congratulations message in confirmation page for CD account")
	public void i_look_for_the_congratulations_message_in_confirmation_page_for_CD_account() {
		if (naoPage.validateConfirmationMessageForCD())
			reportPass("Congratulation message is found in the confirmation page for CD account");
		else
			reportFail("Congratulation message is not found in the confirmation page for CD account");
	}

	@Then("I check that the husky debit card section is not present")
	public void i_check_that_the_husky_debit_card_section_is_not_present() {
		if (naoPage.checkForTheTextHusky())
			reportPass("Husky debit card section is not present");
		else
			reportFail("Husky debit card section is present");
	}

	@Then("I check all the edit buttons are present in the page and click on the edit button {string}")
	public void i_check_all_the_edit_buttons_are_present_in_the_page_and_click_on_the_edit_button(String button) {
		String buttonsDisplayed = naoPage.checkForTheEditButtons(button, true);
		if (!buttonsDisplayed.equals("")) {
			reportPass("Clicked on  the edit button " + button + " in review page");
		} else
			reportHardFail("Failed to click on the edit button");
	}

	@Then("I check if the data is prepopulated as entered data")
	public void i_check_if_the_data_is_prepopulated_as_entered_data() {
		if (naoPage.checkThePrepopulatedData()) {
			reportPass("Data is prepopulated correctly in personal info page");
		} else
			reportFail("Data is not prepopulated correctly in personal info page");
	}

	@Then("I check if the cash flow questions are already selected")
	public void i_check_if_the_cash_flow_questions_are_already_selected() {
		if (naoPage.checkCashOptionsArePreSelected(
				jsonDataParser.getTestDataMap().get("Average Monthly Cash Deposit Amount"),
				jsonDataParser.getTestDataMap().get("Average Monthly Cash Withdrawal Amount"))) {
			reportPass("Cash flow answers are preselected");
		} else
			reportFail("Cash flow answers are not preselected");
	}

	@Then("I select new options for cash flow questions")
	public void i_select_new_options_for_cash_flow_questions() {
		if (naoPage.selectNewCashOptions(jsonDataParser.getTestDataMap().get("Average Monthly Cash Deposit Amount"),
				jsonDataParser.getTestDataMap().get("Average Monthly Cash Withdrawal Amount"))) {
			reportPass("Selected new options for cash flow questions");
		} else
			reportHardFail("Failed to select new options for cash flow questions");
	}

	@Then("I check if the {string} debit card is selected by default")
	public void i_check_if_the_premier_debit_card_is_selected_by_default(String cardType) {
		if (naoPage.checkDefaultDebitCard(cardType)) {
			reportPass(cardType + " Debit card is preselected");
		} else
			reportFail(cardType + " Debit card is not preselected");
	}

	@When("I enter an existing usename in the page")
	public void i_enter_an_existing_usename_in_the_page() {
		try {
			naoPage.enterExistingUsername();
			reportPass("Entered an existing username " + jsonDataParser.getTestDataMap().get("Existing Username"));
		} catch (Exception e) {
			reportHardFail("Failed to enter an existing username");
		}
	}

	@Then("I should get the error message for username")
	public void i_should_get_the_error_message() {
		if (naoPage.checkForTheErrorMessage()) {
			reportPass("Found the error message{ " + jsonDataParser.getTestDataMap().get("Error Message") + " }");
		} else
			reportFail(
					"Failed to find the error message:{ " + jsonDataParser.getTestDataMap().get("Error Message") + "}");
	}

	@Then("I should check for the premier savings precondition error message")
	public void i_should_check_for_the_premier_savings_precondition_error_message() {
		if (naoPage.checkForPremierSavingsErrorMsg()) {
			reportPass("Found the error message {" + jsonDataParser.getTestDataMap().get("Premier Saving Error Message")
					+ "}");
		} else
			reportFail("Failed to find the error message{ "
					+ jsonDataParser.getTestDataMap().get("Premier Saving Error Message") + "}");
	}

	@Then("I should find the return to homepage button")
	public void i_should_find_the_return_to_home_button() {
		if (naoPage.checkForReturnHomeButton(false)) {
			reportPass("Found the button {Return To Homepage}");
		} else
			reportHardFail("Failed to find the button {Return To Homepage}");
	}

	@Then("I enter a valid promoode")
	public void i_enter_a_valid_promoode() {
		if (naoPage.enterOrClearPromoCode(jsonDataParser.getTestDataMap().get("Promo code applied"), false)) {
			reportPass("Entered the promo code");
		} else
			reportHardFail("Failed to enter promocode");
	}

	@Then("I enter an invalid promoode")
	public void i_enter_a_invalid_promoode() {
		if (naoPage.enterOrClearPromoCode(jsonDataParser.getTestDataMap().get("Invalid Promocode"), false)) {
			reportPass("Entered the invalid promo code");
		} else
			reportHardFail("Failed to enter invalid promocode");
	}

	@Then("I enter an expired promoode")
	public void i_enter_a_expired_promoode() {
		if (naoPage.enterOrClearPromoCode(jsonDataParser.getTestDataMap().get("Expired Promocode"), false)) {
			reportPass("Entered the expired promo code");
		} else
			reportHardFail("Failed to enter expired promocode");
	}

	@Then("I check if the light box is displayed for promo")
	public void i_wait_for_the_light_box_to_appear() {
		if (naoPage.waitForPromoCodeLightBox(false)) {
			reportPass("Found the promo light box and closed it");
		} else
			reportFail("Failed to find the promocode light box");
	}

	@Then("I wait for the light box to appear and close it")
	public void i_wait_for_the_light_box_to_appear_and_close_it() {
		if (naoPage.waitForPromoCodeLightBox(true)) {
			reportPass("Found the promo light box and closed it");
		} else
			reportFail("Failed to find the promocode light box");
	}

	@When("I clear the promocode already given")
	public void i_clear_the_promocode_already_given() {
		if (naoPage.enterOrClearPromoCode("", true)) {
			reportPass("Successfully cleared the promo code");
		} else
			reportHardFail("Failed to clear the  promocode");
	}

	@Then("I check that the overdraft section is disabled")
	public void i_check_that_the_overdraft_section_is_disabled() {
		if (naoPage.checkODPRadioBtnsDisabled()) {
			reportPass("Debit card overdraft service radio buttons are disabled");
		} else
			reportFail("Debit card overdraft service radio buttons are not disabled");
	}

	@Then("I check the overdraft heading and the content")
	public void i_check_the_overdraft_heading_and_the_content() {
		if (naoPage.checkOverDraftHeading()) {
			if (naoPage.checkTheOverDraftServicesContent())
				reportPass("Debit card overdraft service heading and content present is correct");
			else
				reportFail("Debit card overdraft service heading is correct and content present is not correct");
		} else
			reportFail("Debit card overdraft service heading and content present is not correct");
	}

	@Then("I check if all the progress bar steps are present")
	public void i_check_if_all_the_progress_bar_steps_are_present() {
		if (naoPage.checkForProgressBarSteps())
			reportPass("All the progress bar steps are present");
		else
			reportFail("All the progress bar steps are not present");
	}

	@Then("I check for the promoode label")
	public void i_check_for_the_promoode_label() {
		if (naoPage.checkForPromoCodeLabel())
			reportPass("Promo code label is present");
		else
			reportFail("Promo code label is not present");
	}

	@Then("I click on the continue button in promo light box")
	public void i_click_on_the_continue_button_in_promo_light_box() {
		naoPage.waitForPromoCodeLightBox(false);
		if (naoPage.clickOnContinueInPromoLightBox())
			reportPass("Clicked on continue button in promo light box");
		else
			reportHardFail("Failed to click on continue button in promo light box");
	}

	@Then("I validate the promo details and account generated in confirmation page")
	public void i_validate_the_promo_details_and_account_generated_in_confirmation_page() {
		try {
			boolean status = true;
			HashMap<String, String> details = naoPage.getSystemGeneratedConfirmationDetails();
			for (String key : details.keySet()) {
				if (key.equals("Account Number")) {
					if (!details.get("Account Number").matches("^[0-9]+$")) {
						status = false;
					}
				} else {
					if (!jsonDataParser.getTestDataMap().get(key).contains(details.get(key))) {
						status = false;
					}
				}
			}
			if (status)
				reportPass("The details are generated correctly " + details);
			else
				reportFail("The details are not generated correctly in confirmation page ");
		} catch (Exception e) {
			reportHardFail("Failed to get account details from the confirmation page");
		}
	}

	@Then("I check for the oppportunity checking label in OC page")
	public void i_check_for_the_oppportunity_checking_label_in_OC_page() {
		if (naoPage.validateOCAccInfoPage())
			reportPass("Found the opportunity checking label in OC Account Information page");
		else
			reportHardFail("Failed to find the opportunity checking label in OC Account Information page");
	}

	@Then("I select the debit card and edelivery option in OC page")
	public void i_select_the_debit_card_and_edelivery_option_in_OC_page() {

		if (!jsonDataParser.getTestDataMap().get("Send Free Webster Visa Debit Card").equals("No")) {
			if (naoPage.selectAccDebitCardOptionForOC())
				reportPass("selected debit card option for OC");
			else
				reportFail("Failed to select debit card option for OC");
		}
		if (!jsonDataParser.getTestDataMap().get("Sign up for eDelivery").equals("No")) {
			if (naoPage.selectAccEDeliveryOptionForOC())
				reportPass("selected edelivery option for OC");
			else
				reportFail("Failed to select edelivery option for OC");
		}
	}

	@Then("I check if the appropraiate message for {string} is dispalyed in lightbox")
	public void i_check_if_the_appropraiate_message_for_is_dispalyed_in_lightbox(String messageType) {
		if (naoPage.checkPromoErrorMessage(messageType))
			reportPass("Found the message {" + jsonDataParser.getTestDataMap().get(messageType) + " }");
		else
			reportHardFail("Message not found {" + jsonDataParser.getTestDataMap().get(messageType) + " }");
	}

	@Then("I click on ok button in promo lightbox")
	public void i_click_on_ok_button_in_promo_lightbox() {
		if (naoPage.clickOkButtonInPromo())
			reportPass("Clicked on the ok button in promo light box");
		else
			reportHardFail("Failed to click on the ok button in promo light box");
	}

	@Then("I should see the promo offer details and account name")
	public void i_should_see_the_promo_offer_details_and_account_name() {
		if (naoPage.checkForThePromoOfferLabels())
			reportPass("Promo offer info and account name are found");
		else
			reportHardFail("Promo offer info and account name are not found");
	}

	@Then("I check if the {string} are displayed in the review page")
	public void i_check_if_the_are_displayed_in_the_review_page(String headersType) {
		if (naoPage.checkForTheHeadersInReviewAccPage(headersType))
			reportPassWithFullPageScreenshot("All the " + headersType + " are found in the page: "
					+ jsonDataParser.getTestDataMap().get(headersType));
		else
			reportHardFail(headersType + " are not found in the page");
	}

	@Then("I click on back button in NAO functionality")
	public void i_click_on_back_button_in_NAO_functionality() {
		if (naoPage.clickOnBack())
			reportPass("Clicked on the back buton");
		else
			reportHardFail("Failed to click on the back button");
	}

	@Then("I change the international wiring option as no")
	public void i_change_the_international_wiring_option_as_no() {
		try {
			naoPage.selectInternatonalWiredServies(
					jsonDataParser.getTestDataMap().get("New International Wire Transfers"));
			reportPass("Selected international wiring option as no");
		} catch (Exception e) {
			reportHardFail("Failed to select international wiring option as no");
		}
	}

	@Then("I check if all the terms disclosure content is displayed correct in the page")
	public void i_check_if_all_the_terms_disclosure_content_is_displayed_correct_in_the_page() {
		String termsNotPresent = naoPage.checkTheDisclosurePageContent(
				jsonDataParser.getTestDataMap().get("Disclosure Terms Labels"),
				jsonDataParser.getTestDataMap().get("Disclosure Terms LinkText"));
		if (termsNotPresent.equals("")) {
			reportPass("All the disclosure content is present as expected in the page");
		} else
			reportFail("Could not find the disclosure content for the links " + termsNotPresent);
	}

	@Then("I click on each dislcoure and check if the appropriate content is displayed in the lightbox")
	public void i_click_on_each_dislcoure_and_check_if_the_appropriate_content_is_displayed_in_the_lightbox() {
		String links = naoPage.checkTheDisclosureLinks();
		if (links.equals("")) {
			reportPass("All the disclosure links are clicked and checked content successfully");
		} else {
			reportFail("Failed to click the links " + links + " and check the content");
		}
	}

	@Then("I should see the error message {string}")
	public void i_should_see_the_error_message(String string) {
		if (naoPage.checkForTermsErrorMessage(string)) {
			reportPass("Found the error message : {" + jsonDataParser.getTestDataMap().get(string) + "}");
		} else {
			reportFail("Failed to find the error message : {" + jsonDataParser.getTestDataMap().get(string) + "}");
		}
	}

	@Then("I leave one of the disclosures unchecking in  the page")
	public void i_leave_some_of_the_disclosures_unchecking_in_the_page() {
		try {
			naoPage.selectSomeDisclosures();
			reportPass("Unchecked one of the disclosures successfully ");
		} catch (Exception e) {
			reportHardFail("Failed to leave one of the disclosures unchecked");
		}
	}

	@Then("I check the content in the confirmation page for {string}")
	public void i_check_the_content_in_the_confirmation_page_for(String string) {
		String contentStatus = naoPage.checkContentInConfirmatioPage();
		if (contentStatus.equals("")) {
			reportPass("All the confirmation page headers and content present is as expected");
		} else
			reportHardFail("Could not find the confirmation page headers and content for " + contentStatus);

	}

	@When("I enter invalid details in driving license number {string} for the state {string}")
	public void i_enter_invalid_details_in_driving_license_number_for_the_state(String dlNumberFormat, String state) {
		try {
			naoPage.enterInvalidDLInformationDetails(dlNumberFormat, state);
			reportPass("Entered details in driving license number as "
					+ jsonDataParser.getTestDataMap().get(dlNumberFormat));
		} catch (Exception e) {
			reportHardFail("Failed to enter details in driving license number");
		}
	}

	@Then("I should get the light box with the error message for invalid driving license format")
	public void i_should_get_the_light_box_with_the_error_message_for_invalid_driving_license_format() {
		if (naoPage.checkDrivingLicenseErrorMsg())
			reportPass("Found the error message for invalid driving license format");
		else
			reportHardFail("Failed to find the error message for invalid driving license in the light box");

	}

	@Then("I click on the edit button from the lightbox")
	public void i_click_on_the_edit_button_from_the_lightbox() {
		if (naoPage.waitForPromoCodeLightBox(true))
			reportPass("Clicked on the edit button in light box for invalid driving license");
		else
			reportHardFail("Failed to click on the edit button in light box for invalid driving license");
	}

	@Then("I click on the continue button in error light box")
	public void click_on_contnue_promo() {
		if (naoPage.clickOnContinueInPromoLightBox())
			reportPass("Clicked on continue button in promo light box");
		else
			reportHardFail("Failed to click on continue button in promo light box");
	}

	@When("I enter invalid data in email verification page as {string}")
	public void i_enter_invalid_data_in_email_verification_page_as(String emailData) throws Exception {
		if (naoPage.enterInvalidEmailDetails(jsonDataParser.getTestDataMap().get(emailData))) {
			reportPass("Entered the email address as " + jsonDataParser.getTestDataMap().get("emailData"));
		} else {
			reportHardFail("Failed to enter the invalid email address");
		}
	}

	@Then("I should get the error message in the start page")
	public void i_should_get_the_eerror_message_in_the_start_page() {
		if (naoPage.checkEmailErrorMsg(jsonDataParser.getTestDataMap().get("Start Page Error Message"))) {
			reportPass("Found the error message for email address as {"
					+ jsonDataParser.getTestDataMap().get("Start Page Error Message") + "}");
		} else {
			reportHardFail("Failed to find the error message for email address");
		}
	}

	@When("I check the content present at the bottom of the Start page")
	public void i_check_the_content_present_at_the_bottom_of_the_Start_page() {
		if (naoPage.checkContentInStartPage()) {
			reportPass("Found the content in start page as {"
					+ jsonDataParser.getTestDataMap().get("Start Page Content") + "}");
		} else {
			reportFail("Failed to find the content in start page");
		}
	}

	@When("I click on the cancel button in start page")
	public void i_click_on_the_cancel_button_in_start_page() {
		if (naoPage.clickOnCancelButton()) {
			reportPass("Clicked on the cancel button in start page");
		} else {
			reportHardFail("Failed to click on the cancel button in start page");
		}
	}

	@Then("I should see a light box for cancel transaction")
	public void i_should_see_a_light_box_for_cancel_transaction() {
		if (naoPage.clickOnCancelLightBox("Yes", false)) {
			reportPass("Found the light box for cancel transaction");
		} else {
			reportHardFail("Failed to find light box for cancel transaction");
		}
	}

	@When("I click on the button {string} in the cancel light box")
	public void i_click_on_the_button_in_the_cancel_light_box(String button) {
		if (naoPage.clickOnCancelLightBox(button, true)) {
			reportPass("Found and clicked on the button " + button + " in light box for cancel transaction");
		} else {
			reportHardFail("Failed to find the button" + button + " in the light box for cancel transaction");
		}
	}

	@Then("I should be in the home page")
	public void i_should_be_in_the_page() {
		if (naoPage.bankButtonIsDisplayed()) {
			reportPass("Reached the home page");
		} else {
			reportHardFail("Failed to reach the home page on clicking the yes button in cancel light box");
		}
	}

	@When("I click on the return to homepage buton")
	public void i_click_on_the_return_to_homepage_buton() {
		if (naoPage.checkForReturnHomeButton(true)) {
			reportPass("Clicked on the return to homepage button");
		} else {
			reportHardFail("Failed to click on the return to homepage button");
		}
	}

	@Then("I check the content for PEP questions in the Identification page")
	public void i_check_the_content_in_the_Identification_page() {
		if (naoPage.checkContentInIdentificationPage(jsonDataParser.getTestDataMap().get("PEP Question1 Label"),
				jsonDataParser.getTestDataMap().get("PEP Question2 Label"),
				jsonDataParser.getTestDataMap().get("Citizenship Label")))
			reportPass("Content in the identification page is correct for PEP questions");
		else
			reportHardFail("Content in the identification page is not correct for PEP questions");
	}

	@Then("I change the citizenship option in the page")
	public void i_select_the_citizenship_option_in__the_page() {
		try {
			naoPage.selectCitizenship(jsonDataParser.getTestDataMap().get("New Country of Citizenship"));
			reportPass(
					"Selected the citizenship as " + jsonDataParser.getTestDataMap().get("New Country of Citizenship"));
		} catch (Exception e) {
			reportHardFail("Failed to select the citizenship");
		}
	}

	@Then("I check all the values in the {string}")
	public void i_check_all_the_values_in_the(String empStatus) {
		String options = naoPage.checkTheListOptions(empStatus);
		if (options.equals(""))
			reportPass("Found all the options under employment status ");
		else
			reportFail("All the options under employment status are not present");
	}

	@Then("I change the employment status to {string}")
	public void i_change_the_employment_status_to(String empStatus) {
		try {
			naoPage.selectEmpStatusInfo(jsonDataParser.getTestDataMap().get(empStatus));
			reportPass("Selected all the employment status details successfully as "
					+ jsonDataParser.getTestDataMap().get(empStatus));
		} catch (Exception e) {
			reportHardFail("Failed to select the employment status of the user ");
		}

	}

	@Then("I enter the details for {string},{string},{string}")
	public void i_enter_the_details_for(String name, String date, String activity) {
		try {
			naoPage.enterSelfEmploymentData(jsonDataParser.getTestDataMap().get(name),
					jsonDataParser.getTestDataMap().get(date), jsonDataParser.getTestDataMap().get(activity));
			reportPass("entered all the self employment details details : " + name + " as "
					+ jsonDataParser.getTestDataMap().get(name) + " , " + date + " as "
					+ jsonDataParser.getTestDataMap().get(date) + " , " + activity + " as "
					+ jsonDataParser.getTestDataMap().get(activity));
		} catch (Exception e) {
			reportHardFail("Failed to enter the self employment details of the user ");
		}
	}

	@Then("I should get the error message in the {string} page")
	public void i_should_get_the_error_message_in_the_page(String page) {
		if (naoPage.checkThePersonalErrorMessage(jsonDataParser.getTestDataMap().get("Message"))) {
			reportPass("Found the error message {" + jsonDataParser.getTestDataMap().get("Message") + "} in " + page
					+ " page");
		} else
			reportFail("Failed to find the error message {" + jsonDataParser.getTestDataMap().get("Message") + "} in "
					+ page + " page");
	}

	@When("I enter the details with some details missing {string} in personal information page")
	public void i_enter_the_details_with_some_details_missing_in_personal_information_page(String field) {
		try {
			naoPage.enterPersonalInformationDetailsForErrors(jsonDataParser.getTestDataMap());
			reportPass("Entered all the personal details successfully except in the field " + field);
		} catch (Exception e) {
			reportHardFail("Failed  to enter the details in personal information page ");
		}
	}

	@Then("I should get the error message for {string} fields")
	public void i_should_get_the_error_message_for_fields(String fields) {
		for (String field : fields.split(",")) {
			if (naoPage.checkTheDLErrorMessage(field)) {
				reportPass("Found the error message{" + jsonDataParser.getTestDataMap().get(field) + "}");
			} else
				reportFail("Failed to find the error message {" + jsonDataParser.getTestDataMap().get("Message") + "}");
		}
	}

	@Then("I should get the page level error in NAO functionality")
	public void i_should_get_the_page_level_error_in_NAO_functionality() {
		if (naoPage.checkThePageLevelErrorMessage(jsonDataParser.getTestDataMap().get("Page Level Message")))
			reportPass("Found the page level error message {"
					+ jsonDataParser.getTestDataMap().get("Page Level Message") + "}");
		else
			reportFail("Failed to find the page level error message");
	}

	@When("I see that the opportunity checking open button is not present")
	public void i_see_that_the_opportunity_checking_open_button_is_not_present() {

		if (naoPage.checkForOCOpenButton()) {
			reportPass("Open button for opportunity checking button is not present ");
		} else
			reportFail("Open button for opportunity checking button is present ");
	}

	@Then("I click on the {string} tab from mian menu")
	public void i_click_on_the_tab_from_mian_menu(String tab) {
		if (naoPage.clickOnTabFromMainMenu(tab)) {
			reportPass("Clicked on the tab " + tab + " from main menu");
		} else
			reportHardFail("Failed to Clicked on the tab " + tab + " from main menu");
	}

	@Then("I check for the order placed using {string} and click on its view link")
	public void i_check_for_the_order_placed_using_and_click_on_its_view_link(String link) {
		if (naoPage.clickOnViewLink(link)) {
			reportPass("Clicked on the view  link for the nao order in webcom");
		} else
			reportHardFail("Failed to click on the view  link for the nao order in webcom");
	}

	@Then("I check the audit step is dispalyed as expected")
	public void i_check_the_audit_step_is_dispalyed_as_expected() {
		if (naoPage.checkTheAuditStepMsg(jsonDataParser.getTestDataMap().get("Webcom Audit Step"))) {
			reportPass("Found the message {" + jsonDataParser.getTestDataMap().get("Webcom Audit Step") + "}");
		} else
			reportHardFail(
					"Failed to find the message {+" + jsonDataParser.getTestDataMap().get("Webcom Audit Step") + "}");
	}

	@Then("I should get the message for already existing customer to sign in")
	public void i_should_get_the_message_for_already_existing_customer_to_sign_in() {
		if (naoPage.checkTheSignInMsg(jsonDataParser.getTestDataMap().get("Sign In for Existing SSN"))) {
			reportPass("Found the message {" + jsonDataParser.getTestDataMap().get("Sign In for Existing SSN") + "}");
		} else
			reportHardFail("Failed to find the message {+"
					+ jsonDataParser.getTestDataMap().get("Sign In for Existing SSN") + "}");
	}

	@Then("I check the text displayed in the license light box")
	public void i_check_the_text_displayed_in_the_light_box() {

		if (naoPage.checkTheLicenseLightBoxText(jsonDataParser.getTestDataMap().get("Driving License Error Message"))) {
			reportPass(
					"Found the message {" + jsonDataParser.getTestDataMap().get("Driving License Error Message") + "}");
		} else
			reportHardFail("Failed to find the message {+"
					+ jsonDataParser.getTestDataMap().get("Driving License Error Message") + "}");
	}

	@When("I get the interest rate and apy")
	public void i_get_the_interest_rate_and_apy() {
		try {
			if (naoPage.getInterestRate(testDataMap.get("Account Requested")))
				reportPass("Selected all the disclosures successfully");
		} catch (Exception e) {
			reportHardFail("Failed to select all the disclosures ");
		}
	}

	@When("I verify the Interest rate and Apy rate in Webcom applicaiton")
	public void i_verify_the_Interest_rate_and_Apy_rate_in_Webcom_applicaiton() {
		try {
			if (naoPage.verifyRatesInWebcom(testDataMap.get("Account Requested")))
				reportPass("Rate Range, Interest Rate and APY Rate are verified successfully");
		} catch (Exception e) {
			reportHardFail("Rate Range, Interest Rate and APY Rate are not verified");
		}
	}

	@When("I click on {string} button in NAO page")
	public void i_click_on_button_in_NAO_page(String btnName) {
		if (naoPage.clickOnNAOButton(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportHardFail("Button: " + btnName + " is not clicked");
	}

	@When("I verify the {string} button is displayed")
	public void i_verify_the_button_is_displayed(String btnName) {
		if (naoPage.verifyNAOButton(btnName))
			reportPass("Button: " + btnName + " is displayed");
		else
			reportHardFail("Button: " + btnName + " is not displayed");
	}

	@Then("I should see the unable to open message")
	public void i_should_see_the_unable_to_open_message() {
		String message = jsonDataParser.getTestDataMap().get("ErrorMessage");
		if (naoPage.verifyMessage(testDataMap))
			reportPass("Message: " + message + " is displayed");
		else
			reportHardFail("Message: " + message + " is not displayed");
	}

}
