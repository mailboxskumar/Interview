package com.wb.wol_web.steps;

import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.PublicSiteRefreshPage;
import cucumber.api.java.en.Then;

public class PublicSiteRefreshSteps extends ObjectBase {

	PublicSiteRefreshPage publicSiteRefreshPage = new PublicSiteRefreshPage();
	public List<String> listLabels = null;

	@Then("I click on the {string} link under {string} account")
	public void i_click_on_the_link_under_account(String linkText, String accountType) {
		if (publicSiteRefreshPage.clickOnLinkUnderHeader(linkText, accountType))
			reportPass("Link: " + linkText + " is clicked");
		else
			reportFail("Link: " + linkText + " is not clicked");
	}

	@Then("I expand the Accounts and click on {string} link")
	public void i_expand_all_the_Accounts(String linkText) {
		if (publicSiteRefreshPage.clickOnAllHeaders(linkText))
			reportPass("All Accounts are expanded");
		else
			reportFail("All Accounts are not expanded");
	}

	@Then("I check for the label {string} is present")
	public void i_check_for_the_label_is_present(String labelName) {
		if (publicSiteRefreshPage.checkForPersonalLabel(labelName))
			reportPass("Label(s) : " + labelName + " is displayed");
		else
			reportFail("One or many Label(s) : " + labelName.toString() + " is not displayed");
	}

	@Then("I check for all the labels displayed")
	public void i_check_for_all_the_labels_displayed() {
		Map<String, String> testDataMap1 = jsonDataParser.getTestDataMap();
		if (publicSiteRefreshPage.checkForLabels(testDataMap1))
			reportPass("Label(s) : " + testDataMap1.values().toString() + " is displayed");
		else
			reportFail("One or many Label(s) : " + testDataMap1.values().toString() + " is(are) not displayed");
	}

	@Then("I verify the links under {string} header")
	public void i_verify_the_links_under_header(String headerName) {
		Map<String, String> testDataMap1 = jsonDataParser.getTestDataMap();
		if (publicSiteRefreshPage.checkForLinks(testDataMap1, headerName))
			reportPass("Link(s) : " + testDataMap1.values().toString() + " is displayed");
		else
			reportFail("One or many Link(s) : " + testDataMap1.values().toString() + " is(are) not displayed");
	}
	
	@Then("I should be in the {string} page of NAO")
	public void i_should_be_in_the_page_of_NAO(String pageName) {
		if (publicSiteRefreshPage.checkPageName(pageName))
			reportPass("Page : " + pageName + " is displayed");
		else
			reportFail("Page : " + pageName + " is not displayed");
	}
}