package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AccountEligibilityWebcomPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AccountEligibilityWebcomSteps extends ObjectBase {

	AccountEligibilityWebcomPage accountEligibilityWebcomPage = new AccountEligibilityWebcomPage();

	@Then("Enter account details and click on submit button in update webster accounts page")
	public void enter_account_details_and_click_on_submit_button_in_update_webster_accounts_page() {

		if (accountEligibilityWebcomPage.addAccountInWebcom(testDataMap))
			reportPass("Entered webster account number { " + testDataMap.get("AccountorCreditCardNumber")
					+ " } and clicked on submit button successfully in WEBCOM update webster accounts page");
		else
			reportFail("Unable to enter values in WEBCOM update webster accounts page");
	}

	@Then("verify add account message in update webster accounts page")
	public void verify_add_account_message_in_update_webster_accounts_page() {
		if (accountEligibilityWebcomPage.verifyAddAccountMsg(testDataMap))
			reportPass("Verify message { " + testDataMap.get("Message")
					+ " } is displayed successfully in WEBCOM update webster accounts page");
		else
			reportFail("Message { " + testDataMap.get("Message") + " } is not displayed");
	}

	@When("Remove account from profile in webcom")
	public void remove_account_from_profile_in_webcom() {
		if (accountEligibilityWebcomPage.removeAccountInWebcom(testDataMap))
			reportPass("The account is deleted successfully");
		else
			reportFail("Failed to remove account from profile");

	}

	@When("Verify remove account message in update webster accounts page")
	public void verify_remove_account_message_in_update_webster_accounts_page() {
		if (accountEligibilityWebcomPage.verifyRemoveAccountConfirmMessage(testDataMap))
			reportPass("Verify message { " + testDataMap.get("RemoveMessage")
					+ " } is displayed successfully in WEBCOM update webster accounts page");
		else
			reportFail("Failed to verify message {" + testDataMap.get("RemoveMessage") + " } is not displayed");

	}

}
