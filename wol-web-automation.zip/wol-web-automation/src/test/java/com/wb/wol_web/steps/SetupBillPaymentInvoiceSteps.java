package com.wb.wol_web.steps;

import java.util.ArrayList;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.SetUpBillPaymentInvoicePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SetupBillPaymentInvoiceSteps extends ObjectBase {

	SetUpBillPaymentInvoicePage setupBillInvoice = new SetUpBillPaymentInvoicePage();

	@Then("^I enter the invoice payment details retrieved from json$")
	public void i_enter_invoice_details_from_json() throws Throwable {
		try {

			setupBillInvoice.enterInvoiceDetails(jsonDataParser.getTestDataMap().get("Description"),
					jsonDataParser.getTestDataMap().get("Amount"), jsonDataParser.getTestDataMap().get("PayeeName"));
		} catch (Exception e) {
			reportHardFail("Failed to enter the data for invoice payment");
		}
	}

	@Then("^I click on \"([^\"]*)\" button in setup invoice payment page$")
	public void i_click_on_continue_button_in_setup_invoice_payment_page(String buttonName) throws Throwable {
		if (!setupBillInvoice.clickOnTheButton(buttonName))
			reportHardFail("Failed to click on the button " + buttonName);
	}

	@Then("^check for the extra description and amount rows$")
	public void check_for_the_extra_description() throws Throwable {
		if (setupBillInvoice.checkExtraAddDescriptions())
			reportPass("More that 5 extra add descriptions tabs are present");
		else
			reportFail("Extra add descriptions tabs are not present");
	}

	@Then("^I check for the notice light box and close it if it appears$")
	public void check_for_the_dilapog_box() throws Exception {
		try {
			setupBillInvoice.checkForDialogBox();
		} catch (Exception e) {
			reportFail("Failed to close the notice dialogue box");
		}
	}

	@And("^I enter the additional description and amount$")
	public void enter_the_extra_description() throws Throwable {
		try {
			setupBillInvoice.enterExtraDescriptionAndAmount(
					jsonDataParser.getTestDataMap().get("Additional Description"),
					jsonDataParser.getTestDataMap().get("Amount"));
		} catch (Exception e) {
			reportHardFail("Failed to enter the additional description");
		}
	}

	@Then("^I should navigate to \"([^\"]*)\" page$")
	public void i_should_navigate_to_page(String title) throws Throwable {
		if (setupBillInvoice.checkPageTitle(title))
			reportPass("reached the page " + title);
		else {
			reportHardFail("Could not reach the page " + title);
		}
	}

	@When("^I select \"([^\"]*)\" from account dropdown$")
	public void i_select_account_from_dropdown(String accountType) {
		try {
			setupBillInvoice.selectFromAccountDropdown(accountType);
		} catch (Exception e) {
			reportHardFail("Failed to select " + accountType + " from the dropdown");
		}
	}

	@Then("^Check the error message for \"([^\"]*)\"$")
	public void check_the_error_message_for_as(String lookFor) throws Throwable {
		String message = jsonDataParser.getTestDataMap().get(lookFor);
		if (setupBillInvoice.checkTheErrorMessageInPage(lookFor, message))
			reportPass("Found the message " + message);
		else {
			reportFail("Could not find the message " + message);
		}
	}

	@Then("^I select payee and check if  delivery date is displayed correctly$")
	public void check_for_deliverydate() {
		if (setupBillInvoice.checkForDeliveryDate())
			reportPass("Delivery date is in correct format");
		else {
			reportHardFail("Delivery date is not in correct format");
		}
	}

	@Then("I get the list of all the payees displayed under select a payee dropdown")
	public void i_get_the_list_of_all_the_payees_displayed_under_select_a_payee_dropdown() {
		try {
			ArrayList<String> payees = setupBillInvoice.getListOfSelectPayeesDisplayed();
			reportPass("List of payees in setup invoice payment page : " + payees);
		} catch (Exception e) {
			reportHardFail("Failed to get the list of payees in setup invoice payment page");
		}
	}

	@Then("I get the list of all the payees displayed in manage payees page")
	public void i_get_the_list_of_all_the_payees_displayed_in_manage_payees_page() {
		try {
			ArrayList<String> payees = setupBillInvoice.getListOfPayeesInManagePayees();
			reportPass("List of payees in manage payees page : " + payees);
		} catch (Exception e) {
			reportHardFail("Failed to get the list of payees in manage payees page");
		}
	}

	@Then("I select the option {string} from the show only dropdown in manage payees page")
	public void i_select_the_option_from_the_show_only_dropdown_in_manage_payees_page(String type) {
		if (setupBillInvoice.selectFromShowOnlyList(type))
			reportPass("Selected the option " + type + " from show only dropdown");
		else {
			reportHardFail("Failed to select the option " + type + " from show only dropdown");
		}
	}

	@Then("I verify if the list of payees in invoice page is same as the list in manage payees")
	public void i_verify_if_the_list_of_payees_in_invoice_page_is_same_as_the_list_in_manage_payees() {
		if (setupBillInvoice.comparePayees())
			reportPass("List of payees in invoice page is same as the list of payees in manage payees");
		else {
			reportHardFail("list of payees in invoice page is not same as the list in manage payees");
		}
	}

}
