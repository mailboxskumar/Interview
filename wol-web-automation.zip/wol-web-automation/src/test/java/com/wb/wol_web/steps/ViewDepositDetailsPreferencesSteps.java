package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.ViewDepositDetailsPreferencesPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewDepositDetailsPreferencesSteps extends ObjectBase {
	ViewDepositDetailsPreferencesPage viewDepositDetailsPreferencesPage = new ViewDepositDetailsPreferencesPage();

	@Then("I verify {string} page display.")
	public void i_verify_page_display(String viewDepositDetailsPage) {
		if (viewDepositDetailsPreferencesPage.verifyViewDepositDetailsPageTitle(viewDepositDetailsPage))
			reportPass(viewDepositDetailsPage + " is displayed");
		else
			reportFail(viewDepositDetailsPage + "is not displayed");
	}

	@When("I click on Continue button in View Deposit Details Preferences page")
	public void i_click_on_Continue_button_in_View_Deposit_Details_Preferences_page() {
		if (viewDepositDetailsPreferencesPage.clickOnContinueBtnInDepositDetailsPage())
			reportPass("Clicked on Continue button in Deposit Details Page");
		else
			reportFail("Unable to click on Continue button in Deposit Details Page");
	}

	@Then("I verify {string} page should display")
	public void i_verify_page_should_display(String depositDetailsConfPage) {
		if (viewDepositDetailsPreferencesPage.verifyDepositDetailsConfPageTitle(depositDetailsConfPage))
			reportPass(depositDetailsConfPage + " Page is displayed");
		else
			reportFail(depositDetailsConfPage + " Page is not displayed");
	}

	@Then("I verify the message {string}")
	public void i_verify_the_message(String depositDetailsConfMsg) {
		if (viewDepositDetailsPreferencesPage.verifyDepositDetailsConfPageMsg(jsonDataParser.getTestDataMap().get(depositDetailsConfMsg)))
			reportPass(jsonDataParser.getTestDataMap().get(depositDetailsConfMsg) + " Message is displayed");
		else
			reportFail(jsonDataParser.getTestDataMap().get(depositDetailsConfMsg) + " Message is not displayed");
	}

	@Then("I verify the {string} is {string} in Deposit Details page")
	public void i_verify_the_is_in_Deposit_Details_page(String accNumber, String accCheckBoxSts) {
		accNumber=jsonDataParser.getTestDataMap().get(accNumber);
		if (viewDepositDetailsPreferencesPage.verifyAccountCheckBoxStatus(accNumber, accCheckBoxSts))
			reportPass(accNumber + " Account number is " + accCheckBoxSts);
		else
			reportFail(jsonDataParser.getTestDataMap().get(accNumber) + " Account number is not " + accCheckBoxSts);
	}

	@When("I select the {string} is {string} in Deposit Details page")
	public void i_select_the_is_in_Deposit_Details_page(String accountNumber, String accCheckBoxSts) {
		accountNumber=jsonDataParser.getTestDataMap().get(accountNumber);
		if (viewDepositDetailsPreferencesPage.verifyAccountCheckBoxStatus(accountNumber, accCheckBoxSts))
			reportPass(accountNumber + " Account number is " + accCheckBoxSts);
		else
			reportFail(accountNumber + " Account number is not" + accCheckBoxSts);
	}

	@Then("I verify the message as {string} should be displayed.")
	public void i_verify_the_message_as_should_be_displayed(String msg) {
		if (viewDepositDetailsPreferencesPage.verifyDepositDetailsMsg(jsonDataParser.getTestDataMap().get(msg)))
			reportPass(jsonDataParser.getTestDataMap().get(msg) + " is displaying successfully");
		else
			reportFail(jsonDataParser.getTestDataMap().get(msg) + " is not displaying");
	}

	@Then("verify the Note as {string}.")
	public void verify_the_Note_as(String note) {
		if (viewDepositDetailsPreferencesPage.verifyNoteDepositDetailsPage(jsonDataParser.getTestDataMap().get(note)))
			reportPass(jsonDataParser.getTestDataMap().get(note) + " is displaying successfully");
		else
			reportFail(jsonDataParser.getTestDataMap().get(note) + " is not displaying");
	}

	@Then("verify the {string}  should be present")
	public void verify_the_should_be_present(String option) {
		if (viewDepositDetailsPreferencesPage.verifyChkUnChkAll(jsonDataParser.getTestDataMap().get(option)))
			reportPass(jsonDataParser.getTestDataMap().get(option) + " is displaying successfully");
		else
			reportFail(jsonDataParser.getTestDataMap().get(option) + " is not displaying");
	}

	@Then("I verify the Cancel button is enabled")
	public void i_verify_the_Cancel_button_is_enabled() {
		if (viewDepositDetailsPreferencesPage.cancelBtn())
			reportPass("Continue button is clicked");
		else
			reportFail("Unable to click on Continue button");
	}

	@Then("verify {string} should be present.")
	public void verify_should_be_present(String enrollMsg) {
		if (viewDepositDetailsPreferencesPage.verifyEnrollText(jsonDataParser.getTestDataMap().get(enrollMsg)))
			reportPass(jsonDataParser.getTestDataMap().get(enrollMsg) + " Enroll Message is displayed");
		else
			reportFail(jsonDataParser.getTestDataMap().get(enrollMsg) + " Enroll Message is not displayed");
	}

	@Then("I verify the Enroll Account number format as {string}.")
	public void i_verify_the_Enroll_Account_number_format_as(String enroll) {
		if (viewDepositDetailsPreferencesPage.verifyEnrollAccNumber(jsonDataParser.getTestDataMap().get(enroll)))
			reportPass(jsonDataParser.getTestDataMap().get(enroll) + " Enroll Account is displayed");
		else
			reportHardFail(jsonDataParser.getTestDataMap().get(enroll) + " Enroll Account is not displayed");
	}

	@Then("{string} should be present.")
	public void should_be_present(String unEnrollMsg) {
		if (viewDepositDetailsPreferencesPage.verifyUnEnrollText(jsonDataParser.getTestDataMap().get(unEnrollMsg)))
			reportPass(jsonDataParser.getTestDataMap().get(unEnrollMsg) + " Enroll Message is displayed");
		else
			reportFail(jsonDataParser.getTestDataMap().get(unEnrollMsg) + " Enroll Message is not displayed");
	}

	@Then("I verify the UnEnroll Account number format as {string}.")
	public void i_verify_the_UnEnroll_Account_number_format_as(String unEnroll) {
		if (viewDepositDetailsPreferencesPage.verifyUnEnrollAccNumber(jsonDataParser.getTestDataMap().get(unEnroll)))
			reportPass(jsonDataParser.getTestDataMap().get(unEnroll) + " UnEnroll Account is displayed");
		else
			reportHardFail(jsonDataParser.getTestDataMap().get(unEnroll) + " UnEnroll Account is not displayed");
	}

	@Then("I verify the {string} account is {string} in Deposit Details page")
	public void i_verify_the_account_is_in_Deposit_Details_page(String account, String status) {
		if (viewDepositDetailsPreferencesPage.verifyAccountEnrolledOrUnEnrolled(account, status))
			reportPass(account + " account is " + status + " in Deposit details page");
		else
			reportFail(account + " account is not in " + status + " in Deposit details page");
	}
	
	@When("I capture the {string} Account number")
	public void i_capture_the_Account_number(String user) {
		if (!viewDepositDetailsPreferencesPage.captureEnrollAccountNumber(user).equals(""))
			reportPass("Account number " + viewDepositDetailsPreferencesPage.captureEnrollAccountNumber(user) + " is displayed");
		else
			reportFail("Account number " + viewDepositDetailsPreferencesPage.captureEnrollAccountNumber(user)
					+ " is not displayed");
	} 

	@Then("I verify the Account number is Auto Enrolled in Deposit Details page")
	public void i_verify_the_Account_number_is_Auto_Enrolled_in_Deposit_Details_page() {
		if (viewDepositDetailsPreferencesPage.verifyAccountNumberIsEnrolled())
			reportPass("Account number is Auto Enrolled");
		else
			reportFail("Account number is UnEnrolled");
	}
	
	@When("I capture the NAO New Account number")
	public void i_capture_the_NAO_New_Account_number() {
		if (!(viewDepositDetailsPreferencesPage.captureNAOAccountNumber().equalsIgnoreCase("")))
			reportPass("Account number " + viewDepositDetailsPreferencesPage.captureNAOAccountNumber() + " is displayed");
		else
			reportFail("Account number " + viewDepositDetailsPreferencesPage.captureNAOAccountNumber()
					+ " is not displayed");
	} 

	@Then("I verify the NAO New Account number is Auto Enrolled in Deposit Details page")
	public void i_verify_the_NAO_New_Account_number_is_Auto_Enrolled_in_Deposit_Details_page() {
		if (viewDepositDetailsPreferencesPage.verifyNAOAccountNumberIsEnrolled())
			reportPass("NAO Account number is Auto Enrolled");
		else
			reportFail("NAO Account number is UnEnrolled");
	}

}
