package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddNonWebsterAccountsPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class AddNonWebsterAccountsSteps extends ObjectBase {

	AddNonWebsterAccountsPage addNonWebsterAccountsPage = new AddNonWebsterAccountsPage();

	@Then("I enter all the details for {string} account of type {string}  in add non webster account page")
	public void enter_details(String accType, String fileType) {
		try {
			addNonWebsterAccountsPage.enterNonWebsterAccDetails(fileType, accType, jsonDataParser.getTestDataMap());
			reportPass("Entered all the account details successfully " + addNonWebsterAccountsPage.details);
		} catch (Exception e) {
			reportHardFail("Failed to enter the account details");
		}
	}

	@Then("^I should be in \"([^\"]*)\" page for \"([^\"]*)\" while managing non webster account$")
	public void i_should_be_in_page(String pageHeading, String checkFor) {
		if (addNonWebsterAccountsPage.checkForTheHeading(pageHeading, checkFor))
			reportPass("The heading text " + pageHeading + " is found");
		else
			reportFail("The heading text " + pageHeading + " is not found");
	}

	@Then("I validate the details in confirmation page are same as the details entered")
	public void validate_details_in_confirmation_page() {
		boolean status = true;
		HashMap<String, String> confirmDetails = addNonWebsterAccountsPage.validateConfirmationDetails();
		HashMap<String, String> dataEntered = addNonWebsterAccountsPage.details;
		for (String eachdata : dataEntered.keySet()) {
			if (!confirmDetails.containsKey(eachdata)) {
				status = false;
			}
		}
		if (status == true) {
			reportPass("Confirmation details are same as the data entered " + confirmDetails);
		} else {
			reportFail("Confirmation details are not same as the data entered.Data obtained from UI:  " + confirmDetails
					+ " Data Entered :" + dataEntered);
		}
	}

	@Then("^I verify if the account status is \"([^\"]*)\" for the account added$")
	public void validte_the_account_status_in_manage_accounts(String status) {
		if (addNonWebsterAccountsPage.getAccountStatusTableData(status))
			reportPass("Found the status as " + status);
		else
			reportFail("Status " + status + " is not found");

	}

	@Then("I click on the link \"([^\"]*)\" present at the bottom right of the page")
	public void click_on_the_LInk(String linkFeature) throws Exception {
		String link = jsonDataParser.getTestDataMap().get(linkFeature);
		if (addNonWebsterAccountsPage.clickOnTheLink(link))
			reportPass("Clicked on the link " + link);
		else {
			reportHardFail("Could not click on the link " + link);
		}
	}

	@Then("I verify the heading \"([^\"]*)\" and content \"([^\"]*)\"  in the page$")
	public void verify_the_link_and_heading(String headingFeature, String contentFeature) {
		String content = jsonDataParser.getTestDataMap().get(contentFeature);
		String heading = jsonDataParser.getTestDataMap().get(headingFeature);
		if (addNonWebsterAccountsPage.checkForTheHeadingAndContent(heading, content))
			reportPass("Heading and content are same as expected in the page :" + heading);
		else
			reportFail("Heading and content are not same as expected in the page :" + heading);
	}

	@Then("^I open a new tab and close the current window$")
	public void openNewTab() {
		try {
			addNonWebsterAccountsPage.openNewWindowAndCloseCurrentWindow();
		} catch (Exception e) {
			reportHardFail("Failed to close  the current tab and open a new tab ");
		}
	}

	@Then("^I check if the user is still logged in and click on return to your account link$")
	public void check_if_user_still_logged_in() throws Exception {
		if (addNonWebsterAccountsPage.checkIfUserIsStillLoggedIn()) {
			addNonWebsterAccountsPage.clickOnReturnToYourAccount();
			reportPass("User is still logged in");
		} else
			reportFail("User is not logged in after closing the current window and opening the session in new window ");
	}

	@Then("^I go back to the confirmation page$")
	public void gobacktoAPage() {
		try {
			addNonWebsterAccountsPage.navigateBack();
		} catch (Exception e) {
			reportHardFail("Failed to navigate back to confirmation page ");
		}
	}

	@Then("^I click on edit account button for the account \"([^\"]*)\"$")
	public void I_click_on_edit_button(String accountName) {
		try {
			addNonWebsterAccountsPage.clickOnTheTableElementToEditAccount(accountName);
		} catch (Exception e) {
			reportHardFail("Failed to click on the edit account button for " + accountName);
		}
	}

	@Then("^I update the nickname and click on continue button$")
	public void I_update_the_nickname() {
		try {
			addNonWebsterAccountsPage.updateNickName();
		} catch (Exception e) {
			reportHardFail("Failed to update the nickname");
		}
	}

	@Then("^I check for the status \"([^\"]*)\" for the account added in webcom$")
	public void check_for_the_status_in_webcom(String status) {

		if (addNonWebsterAccountsPage.checkTheStatusOfTheAccountAddedInWebcom(status)) {
			reportPass("Found the status of the account as " + status);
		} else {
			reportFail("Status of the account is not found as  " + status);
		}
	}

	@And("^I check if the progessbar is not present in the page when there are only active accounts$")
	public void i_check_if_the_progressbar_is_not_present() {
		if (!addNonWebsterAccountsPage.checkForProgressBar())
			reportPass(
					"Progress bar is not present in the Manage non webster transfer accounts page when there are only active accounts");
		else
			reportFail(
					"Progress bar is present in the Manage non webster transfer accounts page when there are only active accounts");

	}

	@And("^I check if the progessbar is not present in the page when there are no external acounts added$")
	public void i_check_if_the_progressbar_is_present() {

		if (!addNonWebsterAccountsPage.checkForProgressBar())
			reportPass(
					"Progress bar is not present in the Manage non webster transfer accounts page when no accounts are added");
		else
			reportFail(
					"Progress bar is present in the Manage non webster transfer accounts page when no accounts are added");

	}

	@And("^I check the message \"([^\"]*)\" for \"([^\"]*)\" in nonwebster accounts flow$")
	public void i_check_the_message_nonWEbster_accounts_flow(String message, String type) {

		if (addNonWebsterAccountsPage.checkForTheMessageInThePage(message, type))
			reportPass("Message is found in the page " + message);
		else
			reportFail("Message is not found in the page " + message);

	}

	@When("^I enter invalid data in \"([^\"]*)\" while adding non webster account and click on continue button$")
	public void i_enter_invalid_data(String labelName, DataTable datatable) throws Exception {
		List<Map<String, String>> jsonDetails = datatable.asMaps(String.class, String.class);
		List<Map<String, String>> accDetails = new ArrayList<Map<String, String>>();
		try {
			Map<String, String> map = new HashMap<String, String>();
			map = jsonDataParser.parseJsonTestData(WOLTestBase.props.getProperty("routingnumbers.json.file.name"),
					jsonDetails.get(0).get("ExternalAccountDetails"));
			accDetails.add(map);
			addNonWebsterAccountsPage.enterInvalidNonWebsterAccDetails(accDetails);
			reportPass("Entered invalid data " + accDetails.get(0).get(labelName) + " in " + labelName);
		} catch (Exception e) {
			reportHardFail("Failed to enter the invalid data in account information");
		}
	}

	@When("^I enter same data as the active existing account$")
	public void i_enter_same_data(DataTable datatable) {
		List<Map<String, String>> jsonDetails = datatable.asMaps(String.class, String.class);
		List<Map<String, String>> accDetails = new ArrayList<Map<String, String>>();
		try {
			Map<String, String> map = new HashMap<String, String>();
			map = jsonDataParser.parseJsonTestData(WOLTestBase.props.getProperty("routingnumbers.json.file.name"),
					jsonDetails.get(0).get("ExternalAccountDetails"));
			accDetails.add(map);
			addNonWebsterAccountsPage.enterInvalidNonWebsterAccDetails(accDetails);
			reportPass("Entered same data as the existing account");
		} catch (Exception e) {
			reportHardFail("Failed to enter existing account data");
		}
	}

	@Then("^I should get the error message \"([^\"]*)\" while adding non webster account$")
	public void i_check_for_error_message(String errorMsgFeature) throws Exception {
		String errorMsg = jsonDataParser.getTestDataMap().get(errorMsgFeature);
		if (addNonWebsterAccountsPage.checkTheErrorMessage(errorMsg))
			reportPass("Error message " + errorMsg + " is found ");
		else
			reportFail("Error message " + errorMsg + " is not found ");

	}

	@And("^I check for the small talk for \"([^\"]*)\" with message \"([^\"]*)\"$")
	public void i_check_for_the_smalltalk_message(String smallTalkType, String messageFeature) throws Exception {
		String message = jsonDataParser.getTestDataMap().get(messageFeature);
		if (addNonWebsterAccountsPage.checkTheSmallTalkMessage(smallTalkType, message))
			reportPass("Found the small talk with message " + message);
		else
			reportFail("Samll talk is not found ");
	}

	@Then("I get the account number with status as active from the manage transfers page")
	public void i_get_the_account_number_with_status_as_active_from_the_manage_transfers_page() {
		addNonWebsterAccountsPage.getActiveStatusAccount();
		if (!addNonWebsterAccountsPage.accNumberAndRoutingNumber.equals(""))
			reportPass("Clicked on the account " + addNonWebsterAccountsPage.accNumberAndRoutingNumber.split(",")[1]
					+ " and routing number " + addNonWebsterAccountsPage.accNumberAndRoutingNumber.split(",")[0]);
		else
			reportFail("Failed to click on the account with active status");
	}

	@Then("I shoud get the error message {string} for {string} in manage nonwebster functionality")
	public void i_shoud_get_the_error_message_for_in_manage_nonwebster_functionality(String msgFeature,
			String msgType) {
		String msg = jsonDataParser.getTestDataMap().get(msgFeature);
		if (addNonWebsterAccountsPage.checkForTheErrorMessage(msg, msgType))
			reportPass("Message {" + msg + "} is found");
		else
			reportFail("Message {" + msg + "} is not  found");
	}

	@When("I click on View Details link in small talk message")
	public void i_click_on_View_Details_link_in_small_talk_message() {
		if (addNonWebsterAccountsPage.clickOnTheViewDetailsLink()) {
			reportPass("Clicked on the view details link in small talk");
		} else
			reportHardFail("Failed to click on the view details link");
	}

	@Then("I click on the message {string} created on the same day as job ran")
	public void click_on_the_link(String msg) {
		if (addNonWebsterAccountsPage.checkAndClickOnTheAppropriatedDateLink(msg))
			reportPass("Clicked on the message {" + msg + "} created after the job run");
		else
			reportHardFail("Failed to find the message {" + msg + "} after the job run");

	}

	@Then("I check for the message {string} in message centre")
	public void i_check_for_the_message_for_in_message_centre(String msgType) {
		String msg = jsonDataParser.getTestDataMap().get(msgType);
		if (addNonWebsterAccountsPage.checkForTheMessageInMessageCentre(msg, msgType))
			reportPass("Found the message :{" + msg + "}");
		else
			reportFail("Failed to find the message :{" + msg + "}");
	}

	@Then("I click on the edit button for the account to which transfer is done")
	public void i_click_on_the_edit_button_for_the_account_to_which_transfer_is_done() {

		try {
			addNonWebsterAccountsPage.clickOnTheEditButtonForAccount();
		} catch (Exception e) {
			reportHardFail("Failed to click on the edit button to the account ");
		}
	}

	@Then("I click on delete checkbox and click on continue button")
	public void i_click_on_delete_checkbox_and_click_on_continue_button() {
		if (addNonWebsterAccountsPage.clickOnDeleteAccount())
			reportPass("Clicked on the delete check box in manage transfer account");
		else
			reportFail("Failed to click on the delete check box in manage transfer account");
	}

	@Then("I should get the error message {string} for the same account")
	public void i_should_get_the_error_message_for_the_same_account(String msgFeature) {
		String msg = jsonDataParser.getTestDataMap().get(msgFeature);
		if (addNonWebsterAccountsPage.checkForFailedDeleteMsg(msg))
			reportPass("Found the message {" + msg + "} in the page");
		else
			reportFail("Failed to find the message {" + msg + "} in the page");
	}

}
