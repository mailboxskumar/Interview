package com.wb.wol_web.steps;

import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.pages.LoginPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class LoginSteps extends ObjectBase {

	LoginPage loginPage = new LoginPage();
	CommonPage commonPage = new CommonPage();

	@Then("I should see the Weblink Lockout Error message")
	public void i_should_see_the_weblink_lockout_error_message_something() throws Throwable {
		String message = jsonDataParser.getTestDataMap().get("Error Msg");
		if (loginPage.verifyWebLinkLockMsg(message))
			reportPass("The WebLink user lockout error message: " + wolWebUtil.containsText
					+ " is  successfully displayed");
		else {
			reportFail("The WebLink user lockout error message: " + message + " is not displayed");
		}
	}

	@And("^I enter password in enhanced security page I should see the password error message$")
	public void i_enter_password_password_in_enhanced_security_page_I_should_see_the_password_error_message_errorMsg() {
		testDataMap = jsonDataParser.getTestDataMap();
		if (loginPage.enterPassword(testDataMap.get("Password"))) {
			reportPass("Entered Invalid Password value  in Enhanced Security page and clicked on Continue Button");
			if (loginPage.verifyPasswordErrMessage(testDataMap.get("Error Msg")))
				reportPass("The Error message " + testDataMap.get("Error Msg")
						+ " is  successfully displayed for Invalid password" + testDataMap.get("Password"));
			else
				reportFail("The Password Error message " + testDataMap.get("Error Msg") + " is  not displayed");
		} else
			reportFail("Failed to enter Password value in Enhanced Security page");
	}

	@Then("I should see the page {string}")
	public void i_should_see_the_page(String message) {
		if (loginPage.verifySecurityInfoTitle(message))
			reportPass("The Page: " + wolWebUtil.containsText + " is  successfully displayed");
		else {
			reportFail("The Page: " + message + " is not displayed");
		}
	}

	@Then("I should able to see the content of Security Information page")
	public void i_should_able_to_see_the_content_of_Security_Information_page() {
		String message = jsonDataParser.getTestDataMap().get("Content");
		if (loginPage.verifySecurityInfoContent(message))
			reportPass("The Content in Update Security Information " + wolWebUtil.containsText
					+ " is  successfully displayed");
		else {
			reportFail("The Content in Update Security Information " + message + " is not displayed");
		}
	}

	@Then("I should able to see error message")
	public void i_should_able_to_see_error_message() {
		String message = jsonDataParser.getTestDataMap().get("Error Msg");
		if (loginPage.verifyWebLinkNAOErr(message))
			reportPass("The Error message  " + wolWebUtil.containsText + " is  successfully displayed");
		else {
			reportFail("The Error message " + message + " is not displayed");
		}
	}

	@When("I enter password value")
	public void i_enter_password_value() throws Exception {
		String passwordValue = jsonDataParser.getTestDataMap().get("Password");
		if (commonPage.enterPassword(passwordValue))
			reportPass("Entered Password value in password text box");
		else
			reportFail("Failed to enter password value");
	}

	@Then("I should able to see the tool tip text")
	public void i_should_able_to_see_the_tool_tip_text() {
		String message = jsonDataParser.getTestDataMap().get("Tooltip");
		if (loginPage.verifyRegisterNoteMsg(message))
			reportPass("The content { " + wolWebUtil.containsText
					+ "} is  successfully displayed in Register for Enhanced Online Security page");
		else
			reportFail("The content {" + message + "} is not displayed in Register for Enhanced Online Security page");
	}

	@Then("i should able te see the content")
	public void i_should_able_te_see_the_content() {
		String message = jsonDataParser.getTestDataMap().get("Content");
		if (loginPage.verifyChallengeNoteMsg(message))
			reportPass("The Challenge Question content { " + wolWebUtil.containsText
					+ "} is  successfully displayed in Register for Enhanced Online Security page");
		else
			reportFail("The Challenge Question  content {" + message
					+ "} is not displayed in Register for Enhanced Online Security page");
	}

	@When("I hover on Unregistered then i am able to see the content")
	public void i_hover_on_Unregistered_then_i_am_able_to_see_the_content() {
		String message = jsonDataParser.getTestDataMap().get("Unregistered Content");
		if (loginPage.verifyChallengeTooltipMsg(message))
			reportPass("The Unregistered Tooltip content { " + loginPage.unregistered
					+ "} is  successfully displayed in Register for Enhanced Online Security page");
		else
			reportFail("The Unregistered  content {" + message
					+ "} is not displayed in Register for Enhanced Online Security page");
	}

	@When("I should able to see the content under Step two")
	public void i_should_able_to_see_the_content_under_Step_two() {
		String message = jsonDataParser.getTestDataMap().get("Step 2 Content");
		if (loginPage.verifyRecognizeNoteMsg(message))
			reportPass("The Recognize me content { " + wolWebUtil.containsText
					+ "} is  successfully displayed in Register for Enhanced Online Security page");
		else
			reportFail("The Recognize me content {" + message
					+ "} is not displayed in Register for Enhanced Online Security page");
	}

	@When("I should able to see the content under Step three")
	public void i_should_able_to_see_the_content_under_Step_three() {
		String message = jsonDataParser.getTestDataMap().get("Step 3 Content");
		if (loginPage.verifyEmailSectionNoteMsg(message))
			reportPass("The Email content { " + wolWebUtil.containsText
					+ "} is  successfully displayed in Register for Enhanced Online Security page");
		else
			reportFail("The Email content {" + message
					+ "} is not displayed in Register for Enhanced Online Security page");
	}

	@When("I hover on regestering then i am able to see the content")
	public void i_hover_on_regestering_then_i_am_able_to_see_the_content() {
		String message = jsonDataParser.getTestDataMap().get("Hover");
		if (loginPage.verifyRecognizeTooltipMsg(message))
			reportPass("The registering Tooltip content { " + loginPage.registering
					+ "} is  successfully displayed in Register for Enhanced Online Security page");
		else
			reportFail("The registering  content {" + message
					+ "} is not displayed in Register for Enhanced Online Security page");
	}

	@Then("I should able to see the label")
	public void i_should_able_to_see_the_label() {
		String message = jsonDataParser.getTestDataMap().get("Label");
		if (loginPage.verifyRecognizeLabel(message))
			reportPass("The Option { " + message + "} is  successfully displayed in Register your device page");
		else
			reportFail("The Option {" + message + "} is not displayed in Register your device page");
	}

	@Then("I should not able to see the label")
	public void i_should_not_able_to_see_the_label() {
		String message = jsonDataParser.getTestDataMap().get("Label");
		if (!loginPage.verifyRecognizeLabel(message))
			reportPass("The Option { " + message + "} is  not displayed in Register your device page");
		else
			reportFail("The Option {" + message + "} is successfully displayed in Register your device page");
	}

	@When("I enter invalid answer and Click on continue button then I should see the error message")
	public void i_enter_invalid_answer_and_Click_on_continue_button_then_I_should_see_the_error_message() {
		testDataMap = jsonDataParser.getTestDataMap();
		commonPage.enterInAnswerTextBoxIfExists(testDataMap.get("Answer"));
		loginPage.clickContinueButton();
		if (loginPage.verifyAnswerErr(testDataMap.get("Error Msg")))
			reportPass("The Error message { " + testDataMap.get("Error Msg")
					+ "}  is  successfully displayed for Invalid answer" + testDataMap.get("Answer"));
		else
			reportFail("The Answer Error message {  " + testDataMap.get("Error Msg") + "} is  not displayed");

	}

	@When("As a User I click on Sign In Link")
	public void as_a_User_I_click_on_Sign_In_Link() {
		if (loginPage.clickSignIn())
			reportPass("Clicked on Sign In link in sign out page");
		else
			reportFail("Failed to click on Sign In Link in sign out page");
	}

	@When("I select Register device option as")
	public void i_select_Register_device_option_as() {
		String value = jsonDataParser.getTestDataMap().get("Register");
		if (commonPage.selectRegisterDevice(value))
			reportPass("Selected Register device as a " + value);
		else
			reportFail("Failed to select Register device");
	}

	@Then("I should see the page level error message")
	public void i_should_see_the_page_level_error_message() {
		String message = jsonDataParser.getTestDataMap().get("Page Error");
		if (loginPage.verifyPageLevelErr(message))
			reportPass("The Error message { " + message + " } is successfully displayed at the top of the page ");
		else
			reportFail("The Error message { " + message + " } is not displayed at the top of the page ");
	}

	@When("I enter valid answer")
	public void i_enter_valid_answer() {
		String answer = jsonDataParser.getTestDataMap().get("Answer");
		if (commonPage.enterInAnswerTextBoxIfExists(answer))
			reportPass("Entered answer value in Register your device page");
		else
			reportFail("Failed to enter answer value in Register Your device page");

	}

	@When("I click on continue button")
	public void i_click_on_continue_button() {
		loginPage.clickContinueButton();
	}

	@When("I Enter First time Login username")
	public void i_Enter_First_time_Login_username() {
		if (loginPage.enterUserName())
			reportPass("Entered New Username value {" + runtimeDataMap.get("newCustomer-webcom") + "}");
		else
			reportFail("Failed to enter new username");
	}

	@When("I Enter First Login Password value")
	public void i_Enter_First_Login_Password_value() {
		if (loginPage.enterPassword())
			reportPass("Entered Password value {" + runtimeDataMap.get("firstPassword-webcom") + "}");
		else
			reportFail("Failed to enter Password");
	}

	@Then("I should see the Label")
	public void i_should_see_the_Label() {
		String message = jsonDataParser.getTestDataMap().get("Label");
		if (loginPage.verifyCurrentUsernameLabel(message))
			reportPass("The Label {" + message + "} is successfully displayed in Update Username and Password page");
		else
			reportFail("The Label {" + message + "} is not displayed in Update Username and Password page");
	}

	@Then("I should see the New User name help message")
	public void i_should_see_the_New_User_name_help_message() {
		String message = jsonDataParser.getTestDataMap().get("Username Help");
		if (loginPage.verifyNewUsernameHelpMsg(message))
			reportPass("The New Username Help Message {" + message
					+ "} is successfully displayed in Update Username and Password page");
		else
			reportFail("The New Username Help Message {" + message
					+ "} is not displayed in Update Username and Password page");
	}

	@Then("I should see the New Password help message")
	public void i_should_see_the_New_Password_help_message() {
		String message = jsonDataParser.getTestDataMap().get("Password Help");
		if (loginPage.verifyNewPasswordHelpMsg(message))
			reportPass("The New Password Help Message {" + message
					+ "} is successfully displayed in Update Username and Password page");
		else
			reportFail("The New Password Help Message {" + message
					+ "} is not displayed in Update Username and Password page");
	}

	@When("I enter Update Username details")
	public void i_enter_Update_Username_details() {
		if (commonPage.enterDetailsInNewUsernamePage())
			reportPass("New Username and Password details are successfully given");
		else
			reportFail("Failed to give new username and password details");
	}

	@When("I completed the Registering for Enhanced Online Security")
	public void i_completed_the_Registering_for_Enhanced_Online_Security() throws Exception {
		testDataMap = jsonDataParser.parseJsonTestData(WOLTestBase.props.getProperty("common.json.file.name"),
				WOLTestBase.props.getProperty("common.json.test.name"));
		if (commonPage.selectFromEnhancedSecurityQuestionsPage(testDataMap))
			reportPass("Completed all the Register Enhanced Security information");
		else
			reportFail("Failed to complete all the Register Enhanced Security information");
	}

	@Then("I should see the First Login Confirmation message")
	public void i_should_see_the_First_Login_Confirmation_message() {
		String message = jsonDataParser.getTestDataMap().get("Message");
		if (loginPage.verifyFirstLoginConfrmMsg(message))
			reportPass("The First Login Confirmation message {" + message + "} is successfully displayed ");
		else
			reportFail("The First Login Confirmation message {" + message + "} is not displayed ");
	}

	@When("I select disclosures in Agree to Disclosures page")
	public void i_select_disclosures_in_Agree_to_Disclosures_page() {
		commonPage.selectFromDisclosuresPage();
	}

	@Then("I should see the label")
	public void i_should_see_the_label() {
		String message = jsonDataParser.getTestDataMap().get("Label");
		if (loginPage.verifyCurrentEmailLabel(message))
			reportPass("The Label {" + message + "} is successfully displayed in verify Email Address page");
		else
			reportFail("The Label {" + message + "} is not displayed in verify Email Address page");
	}

	@Then("I should see Email label")
	public void i_should_see_label_Is_this_Email_Address_correct() {
		String message = jsonDataParser.getTestDataMap().get("Email Label");
		if (loginPage.verifyIsEmailCorrectLabel(message))
			reportPass("The Label {" + message + "} is successfully displayed in verify Email Address page");
		else
			reportFail("The Label {" + message + "} is not displayed in verify Email Address page");
	}

	@Then("I should see the Email Error message")
	public void i_should_see_the_Email_Error_message() {
		String message = jsonDataParser.getTestDataMap().get("Error Msg");
		if (loginPage.verifyEmailError(message))
			reportPass(
					"The Email Error message {" + message + "} is successfully displayed in verify Email Address page");
		else
			reportFail("The Email Error message {" + message + "} is not displayed in verify Email Address page");
	}

	@When("I select option for the question is email address correct")
	public void i_select_option_for_the_question_is_email_address_correct() {
		String verifyMail = jsonDataParser.getTestDataMap().get("Change");
		commonPage.verifyEmailAddressPage(verifyMail);
	}

	@Then("I should see new email label")
	public void i_should_see_new_email_label() {
		String message = jsonDataParser.getTestDataMap().get("Label");
		if (loginPage.verifyNewEmailLabel(message))
			reportPass("The Label {" + message + "} is successfully displayed in verify Email Address page");
		else
			reportFail("The Label {" + message + "} is not displayed in verify Email Address page");
	}

	@When("I enter New Username details and click on continue button then I should see the proper error message")
	public void i_enter_New_Username_details_and_click_on_cont_inue_button_then_I_should_see_the_proper_error_message(
			DataTable dataTable) {
		testDataMap = jsonDataParser.getTestDataMap();
		if (loginPage.enterDetailsInNewUsernamePage(testDataMap.get("Username"), testDataMap.get("Password1"),
				testDataMap.get("Password2"))) {
			reportPass("Entered New Username Password details in Update Username and Password page");
			if (testDataMap.get("Error Type").equalsIgnoreCase("Password")) {
				if (loginPage.verifyNewPasswordErrMsg(testDataMap.get("Error Msg")))
					reportPass("The New Password Error message {" + testDataMap.get("Error Msg")
							+ "} is  successfully displayed in Update Username and Password page");
				else
					reportFail("The New Password Error message {" + testDataMap.get("Error Msg")
							+ "} is  not displayed in Update Username and Password page");
				if (loginPage.verifyCnfrmPasswordErrMsg(testDataMap.get("Error Msg")))
					reportPass("The Re-Type Password Error message {" + testDataMap.get("Error Msg")
							+ "} is  successfully displayed in Update Username and Password page");
				else
					reportFail("The Re-Type Password Error message {" + testDataMap.get("Error Msg")
							+ "} is  not displayed in Update Username and Password page");
			} else if (loginPage.verifyNewUsernameErrMsg(testDataMap.get("Error Msg")))
				reportPass("The New Password Error message {" + testDataMap.get("Error Msg")
						+ "} is  successfully displayed in Update Username and Password page");
			else
				reportFail("The New Password Error message {" + testDataMap.get("Error Msg")
						+ "} is  not displayed in Update Username and Password page");
		} else
			reportFail("Failed to enter New Username  & Password value Update Username and Password page");
	}

	@When("I enter all the RSA information and click on continue button then I should see the error messages")
	public void i_enter_all_the_RSA_information_and_click_on_continue_button_then_I_should_see_the_error_messages() {
		testDataMap = jsonDataParser.getTestDataMap();
		if (commonPage.selectFromEnhancedSecurityQuestionsPage(Integer.parseInt(testDataMap.get("Question")),
				testDataMap.get("Answer"))) {
			if (loginPage.verifyQuestionOneErr(testDataMap.get("Question Error")))
				reportPass("The Error Message {" + testDataMap.get("Question Error")
						+ "} is  successfully displayed in Register Enhanced security information page");
			else
				reportFail("The Error Message {" + testDataMap.get("Question Error")
						+ "} is  not displayed in Register Enhanced security information page");
			if (loginPage.verifyAnswerOneErr(testDataMap.get("Answer Error")))
				reportPass("The Error Message {" + testDataMap.get("Answer Error")
						+ "} is  successfully displayed in Register Enhanced security information page");
			else
				reportFail("The Error Message {" + testDataMap.get("Answer Error")
						+ "} is  not displayed in Register Enhanced security information page");
			reportPass("Entered all the RSA Information in Register Enhanced security information page");
		} else
			reportFail("Failed to enter RSA Information in Register Enhanced security information page");
	}

	@When("I enter all the RSA information")
	public void i_enter_all_the_RSA_information() throws Exception {
		String fileName = WOLTestBase.props.getProperty("common.json.file.name");
		String testCaseName = WOLTestBase.props.getProperty("common.json.test.name");
		Map<String, String> commonTestDataMap = jsonDataParser.parseJsonTestData(fileName, testCaseName);
		if (commonPage.selectFromEnhancedSecurityQuestionsPage(commonTestDataMap))
			reportPass("Entered all the RSA Information in Register Enhanced security information page");
		else
			reportFail("Failed to enter RSA Information in Register Enhanced security information page");
	}

}
