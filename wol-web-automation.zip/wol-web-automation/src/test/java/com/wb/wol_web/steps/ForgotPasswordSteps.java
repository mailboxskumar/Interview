package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.ForgotPasswordPage;
import com.wb.wol_web.testbases.WOLTestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ForgotPasswordSteps extends ObjectBase {

	ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage();

	@And("^I click on Forgot Password Link$")
	public void i_click_on_forgot_password_link() throws Throwable {
		try {
			forgotPasswordPage.clickForgotPasswordLink();
			reportPass("Clicked on Forgot Password Link");
		} catch (Exception e) {
			reportHardFail("Failed to click on Forgot Password Link");
		}
	}

	@When("^I enter username \"([^\"]*)\"$")
	public void i_enter_username_something(String userKey) throws Throwable {
		String userName = WOLTestBase.envProps.getProperty(userKey);
		if (forgotPasswordPage.enterUserName(userName))
			reportPass("Entered username {" + userName + "} in Reset Password Page");
		else
			reportFail("Failed to enter username {" + userName + "} in Reset Password Page");
	}

	@When("^I enter an answer for the Challenge Question$")
	public void i_enter_an_answer_something_for_the_challenge_question() throws Throwable {
		String answer = jsonDataParser.getTestDataMap().get("Answer");
		if (forgotPasswordPage.enterAnswer(answer))
			reportPass("Entered answer {" + answer + "} in Reset Password Page");
		else
			reportFail("Failed to enter answer {" + answer + "} in Reset Password Page");
	}

	@Then("^user should navigate to \"([^\"]*)\" page$")
	public void user_should_navigate_to_something_page(String rpTitle) throws Throwable {
		if (forgotPasswordPage.verifyResetPasswordTitle(rpTitle))
			reportPass("The page: {" + rpTitle + "} is successfully displayed");
		else
			reportFail("The page: {" + rpTitle + "} is not displayed");
	}

	@And("^I should see username label$")
	public void i_should_see_username_something_label() throws Throwable {
		String userName = jsonDataParser.getTestDataMap().get("User Label");
		if (forgotPasswordPage.verifyUserNameLabel(userName))
			reportPass("The label: {" + userName + "} is successfully displayed");
		else
			reportFail("The label: {" + userName + "} is not displayed");
	}

	@And("^I click on Continue button$")
	public void i_click_on_continue_button() throws Throwable {
		try {
			forgotPasswordPage.clickOnContinueButton();
			reportPass("Clicked on Continue Button in Reset Password Page");
		} catch (Exception e) {
			reportHardFail("Failed to click on continue button");
		}
	}

	@And("^I should see  Question label$")
	public void i_should_see_something_label() throws Throwable {
		String challengeQuestion = jsonDataParser.getTestDataMap().get("QuestionLabel");
		if (forgotPasswordPage.verifyChallengeQuestionLabel(challengeQuestion))
			reportPass("The label: {" + challengeQuestion + "} is successfully displayed");
		else
			reportFail("The label: {" + challengeQuestion + "} is not displayed");
	}

	@And("^I should see the tool tip")
	public void i_should_see_the_tool_tip_something() throws Throwable {
		String toolTip = jsonDataParser.getTestDataMap().get("Tooltip");
		if (forgotPasswordPage.verifyToolTip(toolTip))
			reportPass("The tool tip message : {" + toolTip + "} is successfully displayed");
		else
			reportFail("The tool tip message : {" + toolTip + "} is not displayed");
	}

	@And("^I should see the confirmation message for Successful reset password$")
	public void i_should_see_the_confirmation_message_somethingfor_successful_reset_password() throws Throwable {
		String confirmationMessage = jsonDataParser.getTestDataMap().get("Cnfrm Msg");
		if (forgotPasswordPage.verifyConfirmationMessage(confirmationMessage))
			reportPass("The label: {" + confirmationMessage + "} is successfully displayed");
		else
			reportFail("The label: {" + confirmationMessage + "} is not displayed");
	}

	@And("^I should see the Sign in to your account link$")
	public void i_should_see_the_sign_in_to_your_account_link() throws Throwable {
		if (forgotPasswordPage.verifyNextStepLink())
			reportPass("The Sign in your account link is successfully displayed");
		else
			reportFail("The Sign in your account link is not displayed");
	}

	@When("^I click on Webster Logo image$")
	public void i_click_on_webster_logo_image() throws Throwable {
		if (forgotPasswordPage.clickWebsterLogo())
			reportPass("Clicked on Webster Logo image");
		else
			reportFail("Failed to click on Webster logo");
	}

	@And("^url value should have the string \"([^\"]*)\"$")
	public void url_value_should_have_the_string_something(String url) throws Throwable {
		if (forgotPasswordPage.checkResetPasswordURL(url))
			reportPass("Clicked on Webster Logo image");
		else
			reportFail("Failed to click on Webster logo");
	}

	@Then("^I should see password error message")
	public void i_should_see_password_error_message_something() throws Throwable {
		String errMessage = jsonDataParser.getTestDataMap().get("Error Msg");
		if (forgotPasswordPage.verifyPasswordErrMessage(errMessage))
			reportPass("The Password error message {" + errMessage + "} is successfully displayed");
		else
			reportFail("The Password error message {" + errMessage + "} is not displayed");
	}

	@Then("I should see step and its label")
	public void i_should_see_step_and_its_label() {
		Integer number = Integer.parseInt(jsonDataParser.getTestDataMap().get("Number"));
		String message = jsonDataParser.getTestDataMap().get("Label");
		if (forgotPasswordPage.verifyStepLabels(number, message))
			reportPass("The Step  {" + number + "} Label {" + message + "} is successfully displayed");
		else
			reportFail("The Step  {" + number + "} Label {" + message + "} is not displayed");
	}

	@Then("I should see the Step content")
	public void i_should_see_the_Step_content() {
		String message = jsonDataParser.getTestDataMap().get("Content");
		if (forgotPasswordPage.verifyStepDetails(message))
			reportPass("The Password Reset step details {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("The Password Reset step details {" + message + "} is not displayed");
	}

}
