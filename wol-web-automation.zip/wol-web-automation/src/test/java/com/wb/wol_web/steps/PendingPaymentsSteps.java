package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.PendingPaymentsPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PendingPaymentsSteps extends ObjectBase {

	PendingPaymentsPage pendingPaymentsPage = new PendingPaymentsPage();

	@Then("^I should navigate to \"([^\"]*)\" page in pending payments$")
	public void i_should_navigate_toPage_in_pending_payment_flow(String pageHeading) {
		if (pendingPaymentsPage.checkPageTitleForPendingPayment(pageHeading))
			reportPass("Reached the Page " + pageHeading);
		else
			reportFail("Page is not found " + pageHeading);
	}

	@And("^I delete the pending payment for the user$")
	public void deletePendingPayment() {
		pendingPaymentsPage.deletePendingPayments(true, "");
		reportInfo("Deleted Pending payment");

	}

	@Then("^I should be in \"([^\"]*)\" page for pending payment functionality$")
	public void i_should_be_in_the_page(String pageHeading) {
		if (pendingPaymentsPage.checkTitleForDeletePendingPayment(pageHeading))
			reportPass("Reached the Page " + pageHeading);
		else
			reportFail("Page is not found " + pageHeading);
	}

	@When("^I click on \"([^\"]*)\" button in pending payment functionality$")
	public void i_click_on_button_in_pending_payment(String btnName) {
		pendingPaymentsPage.clickOnButton(btnName);

	}

}
