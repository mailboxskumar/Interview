package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddOrMangeWebsterAccountsPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddOrManageWebsterAccountsSteps extends ObjectBase {

	AddOrMangeWebsterAccountsPage addOrMangeWebsterAccountsPage = new AddOrMangeWebsterAccountsPage();

	@Then("^I should navigate to \"([^\"]*)\" page in manage webster accounts$")
	public void i_should_navigate_toPage_in_pending_payment_flow(String pageHeading) {
		if (addOrMangeWebsterAccountsPage.checkPageTitleForMangeWebsterAccounts(pageHeading))
			reportPass("Reached the Page " + pageHeading);
		else {
			reportHardFail("Page is not found " + pageHeading);
		}
	}

	@Then("^I delete the same account from which the payment is made$")
	public void i_delete_same_accont() {
		try {
			addOrMangeWebsterAccountsPage.selectAndRemoveTheAccount();
			reportPass("Clicked on remove this account link successfully ");
		} catch (Exception e) {
			reportHardFail("Failed to click on remove this account ");
		}
	}

	@When("I delete the same account from which the transfer is made")
	public void i_delete_the_same_account_from_which_the_transfer_is_made() throws Throwable {
		try {
			addOrMangeWebsterAccountsPage
					.removeAccountFromProfile(getValueFromRuntimeDataMap("ExternalTransfersAccount"));
			reportPass("Clicked on remove this account link successfully for the account: "
					+ getValueFromRuntimeDataMap("ExternalTransfersAccount"));
		} catch (Exception e) {
			reportHardFail("Failed to click on remove this account ");
		}
	}

	@Then("^I should get the error message as \"([^\"]*)\" for \"([^\"]*)\"$")
	public void i_should_get_the_error_message_as_for(String msg, String errorType) throws Throwable {
		
		if (addOrMangeWebsterAccountsPage.checkForErrorMessage(jsonDataParser.getTestDataMap().get(msg), errorType))
			reportPass("Found the message " + msg);
		else {
			reportHardFail("message is not found " + msg);
		}
	}

	@Then("I verify the only selected {string} display")
	public void i_verify_the_only_selected_display(String accNumber) {
		accNumber=jsonDataParser.getTestDataMap().get(accNumber);
		if (addOrMangeWebsterAccountsPage.verifyAccountNumber(accNumber))
			reportPass(accNumber + " is displayed in ManageWebster Accounts Page");
		else
			reportFail(accNumber + " is not displayed in ManageWebster Accounts Page");
	}

	@When("I update the {string} nickname of the account")
	public void i_update_the_nickname_of_the_account(String nickName) {
		nickName=jsonDataParser.getTestDataMap().get(nickName);
		if (addOrMangeWebsterAccountsPage.enterAccountNickName(nickName))
			reportPass("Nick name entered as " + nickName);
		else
			reportFail("Nick name not entered as " + nickName);
	}

	@When("I get the nickName")
	public void i_get_the_nickName() {
		if (!addOrMangeWebsterAccountsPage.captureAccountNickName().equals(""))
			reportPass("Captured Account Nick name");
		else
			reportFail("Unable to capture Account Nick name");
	}

	@When("I click on Continue button in Manage Webster Accounts page")
	public void i_click_on_Continue_button_in_Manage_Webster_Accounts_page() {
		if (addOrMangeWebsterAccountsPage.clickOnContinueBtn())
			reportPass("Clicked on Continue button");
		else
			reportFail("Unable to click on Continue button");
	}

	@Then("I verify the {string} page display")
	public void i_verify_the_page_display(String accConfPageTitle) {
		if (addOrMangeWebsterAccountsPage.verifyWebsterAccConfPage(accConfPageTitle))
			reportPass(accConfPageTitle + " Page is displayed");
		else
			reportFail(accConfPageTitle + " Page is not displayed");
	}

	@When("I update the {string} Account Nick Name as N\\/A")
	public void i_update_the_Account_Nick_Name_as_N_A(String accountDetails) {
		if (addOrMangeWebsterAccountsPage
				.updateAccountNickNameasNA(jsonDataParser.getTestDataMap().get(accountDetails)))
			reportPass("Account Nickname is cleared");
		else
			reportFail("Account Nickname is not cleared");
	}

	@Then("I verify the Account Nick Name as {string}")
	public void i_verify_the_Account_Nick_Name_as(String accNickNameNA) {
		if (addOrMangeWebsterAccountsPage.verifyWebtsterAccNickNameNa(accNickNameNA))
			reportPass("Account Nick Name displayed as " + accNickNameNA);
		else
			reportFail("Account Nick Name is not displayed as " + accNickNameNA);
	}

	@When("I click on Set as Default billpay account link")
	public void i_click_on_Set_as_Default_billpay_account_link() {
		if (addOrMangeWebsterAccountsPage.clickDefaultBillPayLink())
			reportPass("Clicked on Default Bill Pay Link");
		else
			reportFail("Unable to click on Default Bill Pay Link");
	}

	@Then("I verify the message as {string}.")
	public void i_verify_the_message_as(String billPayAccMsg) {
		if (addOrMangeWebsterAccountsPage.verifyBillPayAccountMsg(billPayAccMsg))
			reportPass("Default Bill Pay Account message displayed as " + billPayAccMsg);
		else
			reportFail("Default Bill Pay Account message is not displayed as " + billPayAccMsg);
	}

	@When("I click on the Update View Deposit Details Preferences link")
	public void i_click_on_the_Update_View_Deposit_Details_Preferences_link() {
		if (addOrMangeWebsterAccountsPage.clickOnDepositDetailsPrefLink())
			reportPass("Deposit Details Preferences link is clicked");
		else
			reportFail("Unable to click on Deposit Details Preferences link");
	}

	@Then("Remove the account {string} from Profile")
	public void remove_the_account_from_Profile(String accountNumberKey) throws Throwable {
		if (addOrMangeWebsterAccountsPage.removeAccountFromProfile(jsonDataParser.getTestDataMap().get(accountNumberKey)))
			reportPass(" User removed account { " + jsonDataParser.getTestDataMap().get(accountNumberKey) + " } from profile successfully");
		else
			reportFail("Unable to find the specified account number");
	}

	@Then("User should navigate to {string} manage confirmation page")
	public void user_should_navigate_to_manage_confirmation_page(String pgTtlManageAccounts) {
		if (addOrMangeWebsterAccountsPage.verifyManageAccountsConfirmationPageTitle(pgTtlManageAccounts) == true)
			reportPass("User navigated to {" + pgTtlManageAccounts + " } page successfully");
		else
			reportFail("User unable to navigate {" + pgTtlManageAccounts + " }  page");
	}

	@Then("Verify manage websteraccounts confirmation message {string}")
	public void verify_manage_websteraccounts_confirmation_message(String DelAccountConfirmMsg) {
		if (addOrMangeWebsterAccountsPage.verifyManageAccountsConfirmMessage(jsonDataParser.getTestDataMap().get(DelAccountConfirmMsg)) == true)
			reportPass("The confirmation message {" + jsonDataParser.getTestDataMap().get(DelAccountConfirmMsg)
					+ " } successfully displayed in manage webster accounts confirmation page");
		else
			reportFail("Failed to verify the confirmation message {" + jsonDataParser.getTestDataMap().get(DelAccountConfirmMsg)
					+ " } in manage webster accounts confirmation page");
	}

	@Then("I should navigate to {string} page in add webster accounts")
	public void i_should_navigate_to_page_in_add_webster_accounts(String pgTtlAddAccounts) {
		if (addOrMangeWebsterAccountsPage.verifyAddAccPgTitle(pgTtlAddAccounts) == true)
			reportPass("User navigated to {" + pgTtlAddAccounts + " } page successfully");
		else
			reportFail("User unable to navigate to {" + pgTtlAddAccounts + " }  page");
	}

	@When("I enter values {string} and {string} in add webster accounts page and click on AddAccount Button")
	public void i_enter_values_and_in_add_webster_accounts_page_and_click_on_AddAccount_Button(String accountNumberKey,
			String nickName) throws Throwable {
		if (addOrMangeWebsterAccountsPage.inputAddAccountsDetails(jsonDataParser.getTestDataMap().get(accountNumberKey), nickName))
			reportPass("User entered values { Account Number : " + jsonDataParser.getTestDataMap().get(accountNumberKey) + " and NickName : " + nickName
					+ " } successfully in Add webster accounts page");
		else
			reportFail("User unable to enter values in add webster accounts page");
	}

	@Then("User should navigate to add accounts {string} confirm page")
	public void user_should_navigate_to_add_accounts_confirm_page(String pgTtlAddAccountsConfirm) {
		if (addOrMangeWebsterAccountsPage.verifyAddAccountsConfirmPageTitle(pgTtlAddAccountsConfirm) == true)
			reportPass("User navigated to {" + pgTtlAddAccountsConfirm + " } page successfully");
		else
			reportFail("Failed to navigate {" + pgTtlAddAccountsConfirm + " } page");
	}

	@Then("verify the add accounts confirmation message {string}")
	public void verify_the_add_accounts_confirmation_message(String AddAccountConfirmMsg) {
		if (addOrMangeWebsterAccountsPage.verifyAddAccountsConfirmMsg(jsonDataParser.getTestDataMap().get(AddAccountConfirmMsg)))
			reportPass("The confirmation message {" + addOrMangeWebsterAccountsPage.addAccountsConfirmMsg
					+ " } is successfully displayed in Add webster accounts confirmation page");
		else
			reportFail(
					"Failed to verify the confirmation message {" + addOrMangeWebsterAccountsPage.addAccountsConfirmMsg
							+ " } in Add webster accounts confirmation page");
	}

	@Then("Get the account number and name of the aacount")
	public void get_the_account_number_and_name_of_the_aacount() {
		if (addOrMangeWebsterAccountsPage.getAccountDetails())
			reportPass(" Retrevied { " + addOrMangeWebsterAccountsPage.getAccountNumber + "} and {"
					+ addOrMangeWebsterAccountsPage.getAccountName + " } successfully ");
		else
			reportHardFail(" Unable to retrieve the account details in manage webster accounts page");
	}

	@Then("Enter add account details and click on add account button")
	public void enter_add_account_details_and_click_on_add_Account_button() {
		if (addOrMangeWebsterAccountsPage.enterAccountDetails())
			reportPass("User entered { " + addOrMangeWebsterAccountsPage.getAccountNumber
					+ " } and clicked on add account button successfully");
		else
			reportFail(" Unable to enter account details ");
	}

	@Then("verify add account confirmation message {string}")
	public void verify_add_account_confirmation_message(String addExistingAccMsgKey) {
		if (addOrMangeWebsterAccountsPage.verifyAddExistingAccountMsg(jsonDataParser.getTestDataMap().get(addExistingAccMsgKey)))
			reportPass("{ " + jsonDataParser.getTestDataMap().get(addExistingAccMsgKey)
					+ " } message is successfully displayed");
		else
			reportFail("{ " + addOrMangeWebsterAccountsPage.addExistingAccountMsg + " } message is  not displayed");
	}

	@Then("Enter credit card no {string} and click on add account button")
	public void enter_credit_card_no_and_click_on_add_account_button(String creditCardNoKey) {
		if (addOrMangeWebsterAccountsPage.enterCreditCardDetails(jsonDataParser.getTestDataMap().get(creditCardNoKey)))
			reportPass(" User Entered Credit card no { " + jsonDataParser.getTestDataMap().get(creditCardNoKey)
					+ " } and clicked on add account button successfully in add accounts page");
		else
			reportFail("Unable to enter credit card details in add accounts page");
	}

	@Then("Verify Credit card message {string} in Add accounts page")
	public void verify_Credit_card_message_in_Add_accounts_page(String addExistingCardMsgKey) {
		if (addOrMangeWebsterAccountsPage.verifyAddExistingCCMsg(jsonDataParser.getTestDataMap().get(addExistingCardMsgKey)))
			reportPass("{ " + jsonDataParser.getTestDataMap().get(addExistingCardMsgKey) + " } is successfully displayed");
		else
			reportFail("{ " + jsonDataParser.getTestDataMap().get(addExistingCardMsgKey) + " } is not displayed");
	}

	@Then("Click on the account {string} to change the nickname {string} and click continue button")
	public void click_on_the_account_to_change_the_nickname_and_cclick_continue_button(String accountNumberKey,
			String nickNameKey) {
		if (addOrMangeWebsterAccountsPage.inputNickNameDetails(jsonDataParser.getTestDataMap().get(accountNumberKey), jsonDataParser.getTestDataMap().get(nickNameKey)))
			reportPass("User successfully entered nickname { " + addOrMangeWebsterAccountsPage.newNickName
					+ " } in manage webster accounts page");
		else
			reportHardFail("Unable to enter details in manage webster accounts page");
	}

	@Then("verify updated nick name displayed on account headder in manage webster accounts page")
	public void verify_updated_nick_name_displayed_on_account_headder_in_manage_webster_accounts_page() {
		if (addOrMangeWebsterAccountsPage.verifyNickNameInAccountsHeader())
			reportPass(" Nick name { " + addOrMangeWebsterAccountsPage.newNickName
					+ " } verified successfully in manage webster accounts page account header");
		else
			reportFail("Nick name { " + addOrMangeWebsterAccountsPage.newNickName
					+ " }not present in account header in manage webster accounts page");
	}

	@Then("Click on Cancel button in add webster accounts page")
	public void click_on_Cancel_button_in_add_webster_accounts_page() {
		try {
			addOrMangeWebsterAccountsPage.clickAddAccountsCancelButton();
			reportPass("Clicked on { Cancel } button successfully in add webster accounts page");
		} catch (Exception e) {
			reportFail("Unable to click on { Cancel } button");
		}
	}

	@Then("Click on No button in light box in add webster accounts page")
	public void click_on_No_button_in_light_box_in_add_webster_accounts_page() {
		try {
			addOrMangeWebsterAccountsPage.clickNoInLightBoxAddAccounts();
			reportPass("Clicked on { No } button in add webster accounts page light box");
		} catch (Exception e) {
			reportFail("Unable to click on { No } button in add webster accounts page light box");
		}
	}

	@Then("Click on Yes button in add webster accounts page")
	public void click_on_Yes_button_in_add_webster_accounts_page() {
		try {
			addOrMangeWebsterAccountsPage.clickYesInLightBoxAddAccounts();
			reportPass("Clicked on { Yes } button in add webster accounts page light box");
		} catch (Exception e) {
			reportFail("Unable to click on { Yes } button in add webster accounts page light box");
		}
	}

	@Then("Enter account no {string} and click on add account button")
	public void enter_account_no_and_click_on_add_account_button(String accountNumberKey) {
		if (addOrMangeWebsterAccountsPage.enterCreditCardDetails(jsonDataParser.getTestDataMap().get(accountNumberKey))) 
			reportPass("Entered account number { " + jsonDataParser.getTestDataMap().get(accountNumberKey) + " } and clicked on add account button successfully ");
		else
			reportFail("Unable to enter account number in add webster accounts page");
	}

	@Then("Verify add accounts generic error message {string}")
	public void verify_add_accounts_generic_error_message(String pageLevelErrorMessageKey) {
		if (addOrMangeWebsterAccountsPage.verifyAddAccGenErrMessage(jsonDataParser.getTestDataMap().get(pageLevelErrorMessageKey)))
			reportPass("Page level error message { " + jsonDataParser.getTestDataMap().get(pageLevelErrorMessageKey)
					+ " } is displayed successfully in add webster accounts page");
		else
			reportFail("Error message { " + jsonDataParser.getTestDataMap().get(pageLevelErrorMessageKey) + " }is not displayed in add webster accounts page");
	}

	@Then("Verify add account error message {string}")
	public void verify_add_account_error_message(String errorMessageKey) {
		if (addOrMangeWebsterAccountsPage.verifyAddAccErrMessage(jsonDataParser.getTestDataMap().get(errorMessageKey)))
			reportPass("Error message { " + jsonDataParser.getTestDataMap().get(errorMessageKey) + " } is displayed successfully for invalid webster accounts");
		else
			reportFail("Error message { " + jsonDataParser.getTestDataMap().get(errorMessageKey) + " } is not displayed in add webster accounts page");
	}

	@Then("Verify page content in add webster accounts page {string}")
	public void verify_page_content_in_add_webster_accounts_page(String pgContentAddAccKey) {
		if (addOrMangeWebsterAccountsPage.verifyAddAccPageContent(jsonDataParser.getTestDataMap().get(pgContentAddAccKey)))
			reportPass(
					"Page Content { " + jsonDataParser.getTestDataMap().get(pgContentAddAccKey) + " } is displayed successfully in add webster accounts page");
		else
			reportFail("Page content { " + jsonDataParser.getTestDataMap().get(pgContentAddAccKey) + " }is not displayed in add webster accounts page");
	}

	@Then("Verify pop-up message {string} in manage webster accounts page")
	public void verify_pop_up_message_in_manage_webster_accounts_page(String popUpMsgKey) {
		if (addOrMangeWebsterAccountsPage.verifyPopUpMsgInManageAccounts(jsonDataParser.getTestDataMap().get(popUpMsgKey)))
			reportPass(
					" The pop up message { " + jsonDataParser.getTestDataMap().get(popUpMsgKey) + " } verified successfully in manage webster accounts page");
		else
			reportFail("The pop up message { " + jsonDataParser.getTestDataMap().get(popUpMsgKey) + " } not displayed in manage webster accounts page");
	}

	@When("I Click on Manage User Access link in the pop-up")
	public void i_Click_on_Manage_User_Access_link_in_the_pop_up() {
		if (addOrMangeWebsterAccountsPage.clickLinkInPopUpMessage())
			reportPass(" Clicked on the { Manage User Access } link successfully in pop up message");
		else
			reportFail("Unable to click on { Manage User Access } link in manage webster accounts page");
	}

	@When("I Click on View Link in Manage Audit Trail Page")
	public void i_Click_on_View_Link_in_Manage_Audit_Trail_Page() {
		if (addOrMangeWebsterAccountsPage.clickViewLinkMngAuditPage())
			reportPass("Clicked on View link in manage audit trail details page");
		else
			reportFail("Failed to click on manage audit trail page");
	}

	@Then("Verify account no in audit trail details page")
	public void verify_account_no_in_audit_trail_details_page() {
		if (addOrMangeWebsterAccountsPage.verifyAccountNoInAuditDetailsPage(testDataMap))
			reportPass("The account no { " + testDataMap.get("AccountorCreditCardNumber")
					+ " } is displayed successfully");
		else
			reportFail("The account no { " + testDataMap.get("AccountorCreditCardNumber") + " } is not displayed");
	}

	@When("I enter nickname in update webster accounts page and click on submit button")
	public void i_enter_nickname_in_update_webster_accounts_page_and_click_on_submit_button() {
		if (addOrMangeWebsterAccountsPage.updateNickName(testDataMap))
			reportPass("Updated the nick name as { " + testDataMap.get("NickName") + " } for the account number { "
					+ testDataMap.get("AccountorCreditCardNumber") + " }");
		else
			reportHardFail("Failed to update nick name");
	}

	@Then("verify update nickname confirmation message")
	public void verify_update_nickname_confirmation_message() {
		if (addOrMangeWebsterAccountsPage.verifyNickNameConfirmationMessage(testDataMap))
			reportPass(
					"Confirmation message { " + testDataMap.get("UpdateNickNameMessage") + " } displayed successfully");
		else
			reportFail("Confirmation message { " + testDataMap.get("UpdateNickNameMessage") + " } is not displayed");
	}

	@Then("Verify Nickname details in audit details page")
	public void verify_Nickname_details_in_audit_details_page() {
		if (addOrMangeWebsterAccountsPage.verifyUpdatedNickNameInAuditDetails(testDataMap))
			reportPass("Verified Updated nick name successfully in audit details page");
		else
			reportFail("Updated nick name is not present in the audit details page");

	}

	@When("Clear the updated nick name")
	public void clear_the_updated_nick_name() {
		if (addOrMangeWebsterAccountsPage.clearNickNameValue(testDataMap))
			reportPass("Cleared the nick name value for the account { " + testDataMap.get("AccountorCreditCardNumber")
					+ " }");
		else
			reportFail("Failed to clear the nick name value for the account { "
					+ testDataMap.get("AccountorCreditCardNumber") + " }");
	}

}
