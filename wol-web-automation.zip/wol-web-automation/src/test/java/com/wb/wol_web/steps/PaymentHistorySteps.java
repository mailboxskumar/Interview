package com.wb.wol_web.steps;

import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.PaymentHistoryPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class PaymentHistorySteps extends ObjectBase {

	PaymentHistoryPage paymentHistoryPage = new PaymentHistoryPage();

	@Then("^I should in \"([^\"]*)\" page$")
	public void i_should_in_page(String pgTtlTxt) throws Throwable {
		if (paymentHistoryPage.verifyPaymentHistoryTitle(pgTtlTxt))
			reportPass("User navigated to { Payment History } Page Successfully");
		else
			reportFail("Failed to Navigate { Payment History } Page");
	}

	@When("^User Clicks on Search for Payments Link$")
	public void user_Clicks_on_Search_for_Payments_Link() throws Throwable {
		if (paymentHistoryPage.clickSearchForPaymentsLink())
			reportPass("Clicked on { Search for Payments } link successfully");
		else
			reportHardFail("Unable to click on { Search for Payments} link");
	}

	@Then("^User should navigate to \"([^\"]*)\" Page$")
	public void user_should_navigate_to_Page(String pgTtlTxt) throws Throwable {
		if (paymentHistoryPage.verifySearchForPayments(pgTtlTxt))
			reportPass("User navigated to { Search for Payments } page successfully");
		else
			reportFail("Failed to navigate Serach for Payments Page");
	}

	@When("^User Click on Select search by Payment Information Link$")
	public void user_Click_on_Select_search_by_Payment_Information_Link() throws Throwable {
		if (paymentHistoryPage.clickSearchByPaymentInfoLink())
			reportPass("Clicked on { Search by Payment Information } link successfully");
		else
			reportFail("Unable to click on the { Search by Payment Information } link");
	}

	@When("I enters all details like from date in search by payment information page")
	public void i_enters_all_details_like_from_date_in_search_by_payment_information_page() throws Throwable {
		if (paymentHistoryPage.enterSearchByPaymentInfoDetails())
			reportPass("User provided all the details in { Search By Payment Information } page");
		else
			reportFail("Unable to enter details in { Search By Payment Information } page");
	}

	@Then("^User Clicks on Search Button$")
	public void user_Clicks_on_Search_Button() throws Throwable {
		if (paymentHistoryPage.clickSearchButton())
			reportPass("User clicked on { Search } Button");
		else
			reportHardFail("Unable to click on Seach button");
	}

	@Then("^User should be in \"([^\"]*)\" Page$")
	public void user_should_be_in_Page(String pgTtlTxt) throws Throwable {
		if (paymentHistoryPage.verifyPaymentSearchResultsPageTtl(pgTtlTxt))
			reportPass("User navigated to { Payment Search Results } page successfully");
		else
			reportFail("User not in payment search results page");
	}

	@Then("^User should see \"([^\"]*)\" Link at bottom of the Serach Results$")
	public void user_should_see_link_at_bottom_of_the_search_results(String lnkText) throws Throwable {
		if (paymentHistoryPage.verifySearchForPaymentsLink(lnkText))
			reportPass(" {Search for Payments } link is Present under the Payment Results Table");
		else
			reportFail(" { Search for Payments } ink is not Present under the Payment Results Table");
	}

	@When("^User clicks on delivery date having payment status as \"([^\"]*)\"$")
	public void user_clicks_on_delivery_date_having_payment_status_as(String pmtStatus) throws Throwable {
		if (paymentHistoryPage.clickDeliveryDateLink(pmtStatus))
			reportPass(
					"User clicked on { DeliveryDate } successfully in payment history page having payment status is{ "
							+ pmtStatus);
		else
			reportHardFail("Unable to click on the Delivery Date");
	}

	@Then("^User should navigate to \"([^\"]*)\" page$")
	public void user_should_navigate_to_page(String pgTtlTxt) throws Throwable {
		if (paymentHistoryPage.verifyBillPaymentDetailsPage(pgTtlTxt))
			reportPass("User navigated to { Payment Details } Page successfully");
		else
			reportFail("Unable to view { Payment Details } Page");
	}

	@Then("^User should see Remittance Address label$")
	public void user_should_see_Remittance_Address_label() throws Throwable {
		if (paymentHistoryPage.verifyRemittanceAddressLbl())
			reportPass("{ Remittance Address } label is present in bill payments details page");
		else
			reportFail("{ Remittance Address } label is not present in bill payments details page");
	}

	@When("^User clicks on Request Research on this payment link$")
	public void user_clicks_on_Request_Research_on_this_payment_link() throws Throwable {
		if (paymentHistoryPage.clickRequestResearchLink())
			reportPass("User clicked on { Request Research on this Payment } Link");
		else
			reportHardFail("Unable to click on Request Research Link");
	}

	@Then("^User Should be in \"([^\"]*)\" page$")
	public void user_Should_Navigate_to_page(String pgTtlTxt) throws Throwable {
		if (paymentHistoryPage.verifyRequestResearchPage(pgTtlTxt))
			reportPass("User Navigated to { Request Research } Page Successfully");
		else
			reportFail("User Faild to Navigate Request Research Page");
	}

	// Due to Test data maintenance issue we kept this step as unused, if required
	// we can use this step by giving new value each time
	@Then("^User Enters Request Research Deatails and Click on Research Request Button$")
	public void user_Enters_Request_Research_Deatails_and_Click_on_Research_Request_Button(DataTable researchDetails1)
			throws Throwable {
		List<String> researchDetails = researchDetails1.asList(String.class);
		if (paymentHistoryPage.inputRequestResearchDetails(researchDetails))
			reportPass("User Entered all the details in { Request Research } page");
		else
			reportFail("Unable to enter values in { Request Research } page");
	}

	@Then("^User should in \"([^\"]*)\" page$")
	public void user_should_in_page(String pgTtlTxt) throws Throwable {
		if (paymentHistoryPage.verifyRequestResearchConfirmationPage(pgTtlTxt))
			reportPass("User navigated to { Request Research Confirmation } page successfully");
		else
			reportFail(" User unable to navigate { Request Research Confirmation } Page");
	}

	@Then("^Get the Confirmation No from the Payment History Page$")
	public void get_the_Confirmation_No_from_the_Payment_History_Page() throws Throwable {
		if (!paymentHistoryPage.getConfirmationNo().equals(null))
			reportPass("Confirmation Number { " + paymentHistoryPage.confirmationNo + " } retrieved successfully");
		else
			reportFail("Failed to retrieve confirmation number");
	}

	@When("^User Click on Select search by confirmationNo Link$")
	public void user_Click_on_Select_search_by_confirmationNo_Link() throws Throwable {
		if (paymentHistoryPage.clickSearchByConfirmationNoLink())
			reportPass("Clicked on { Search by Payment Confirmation Link } successfully");
		else
			reportFail("{ Search by Payment Confirmation Link } not Present in the Page");
	}

	@When("^User Enter Confirmation no retrived from Payment History page$")
	public void user_Enter_Confirmation_no_retrived_from_Payment_History_page() throws Throwable {
		if (paymentHistoryPage.inputConfirmationNo())
			reportPass("Payment confirmation No { " + paymentHistoryPage.confirmationNo
					+ " } entered successfully in search results Page");
		else
			reportFail("Payment Confirmation number is not entered");
	}

	@Then("Verify payment search results are in given date range")
	public void verify_payment_search_results_are_in_given_date_range() {
		if (paymentHistoryPage.verifyPaymentSearchResults())
			reportPass("Verified values are in given date range on payments search results table");
		else
			reportFail("Failed due to Payments search results table not available in given date range");
	}

	@Then("Verify confirmation details in the payment details page")
	public void verify_confirmation_details_in_the_payment_details_page() {
		paymentHistoryPage.getBillPaymentConfirmDetails();
		if (paymentHistoryPage.verifyBillPaymentConfirmatinDetails())
			reportPass("Verified confirmation no { " + paymentHistoryPage.confirmationNo + " } and  payee name { "
					+ paymentHistoryPage.payeeName + " } successfully");
		else
			reportFail(" Failed to verify confirmation details in bill payments page");
	}
}
