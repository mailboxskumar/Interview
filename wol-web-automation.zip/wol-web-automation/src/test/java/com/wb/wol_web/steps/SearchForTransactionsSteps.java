package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.SearchForTransactionsPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchForTransactionsSteps extends ObjectBase {

	SearchForTransactionsPage searchForTransactionsPage = new SearchForTransactionsPage();
	List<String> listValues;
	@Then("I verify {string} page should be displayed")
	public void i_verify_page_should_be_displayed(String pageTitle) {
		if (searchForTransactionsPage.verifySearchForTransPage(pageTitle))
			reportPass(pageTitle + " Page is displayed");
		else
			reportFail(pageTitle + " Page is not displayed");
	}

	@Then("I verify the {string} key content displayed")
	public void i_verify_the_key_content_displayed(String keyContent) {
		if (searchForTransactionsPage.verifyKeyContentInSearchForTransPage(jsonDataParser.getTestDataMap().get(keyContent)))
			reportPass(jsonDataParser.getTestDataMap().get(keyContent) + "  text is displayed");
		else
			reportHardFail(jsonDataParser.getTestDataMap().get(keyContent) + "  text is not displayed");
	}

	@When("I select the webster {string} Account")
	public void i_select_the_webster_Account(String account) {
		if (searchForTransactionsPage.selectWebsterAccount(jsonDataParser.getTestDataMap().get(account)))
			reportPass("Account " + jsonDataParser.getTestDataMap().get(account) + " is selected from Accounts dropdown");
		else
			reportFail("Account " + jsonDataParser.getTestDataMap().get(account) + " is not selected from Accounts dropdown");
	}

	@Then("I verify the Date Range radio button selected")
	public void i_verify_the_Date_Range_radio_button_selected() {
		if (searchForTransactionsPage.verifyDateRangeOptionSelected())
			reportPass("By default Date Range option is selected");
		else
			reportFail("Date Range option is not selected");
	}

	@When("I Enter {string} days back for from date")
	public void i_Enter_days_back_for_from_date(String fromDate) {
		if (!searchForTransactionsPage.enterFromDate(jsonDataParser.getTestDataMap().get(fromDate)).equals(""))
			reportPass("From Date " + searchForTransactionsPage.enterFromDate(jsonDataParser.getTestDataMap().get(fromDate)) + " is entered");
		else
			reportFail("From Date " + searchForTransactionsPage.enterFromDate(jsonDataParser.getTestDataMap().get(fromDate)) + " is not entered");
	}

	@When("I Enter {string} days back for to date")
	public void i_Enter_days_back_for_to_date(String toDate) {
		if (!searchForTransactionsPage.enterToDate(jsonDataParser.getTestDataMap().get(toDate)).equals(""))
			reportPass("To Date " + searchForTransactionsPage.enterToDate(jsonDataParser.getTestDataMap().get(toDate)) + " is entered");
		else
			reportFail("To Date " + searchForTransactionsPage.enterToDate(jsonDataParser.getTestDataMap().get(toDate)) + " is not entered");
	}

	@When("I select Transaction type as {string}")
	public void i_select_Transaction_type_as(String transType) {
		if (searchForTransactionsPage.selectTransactionType(transType))
			reportPass("Transaction type " + transType + " is selected from Transaction type dropdown");
		else
			reportFail("Transaction type " + transType + " is not selected from Transaction type dropdown");
	}

	@When("I click on Search button")
	public void i_click_on_Search_button() {
		if (searchForTransactionsPage.clickOnSearchButton())
			reportPass("Clicked on Search button");
		else
			reportFail("Unable to click on Search button");
	}

	@Then("I verify the error message as {string}")
	public void i_verify_the_error_message_as(String errorMessage) {
		if (searchForTransactionsPage.verifyDatesErrorMsg(jsonDataParser.getTestDataMap().get(errorMessage)))
			reportPass(jsonDataParser.getTestDataMap().get(errorMessage) + " message is displayed");
		else
			reportHardFail(jsonDataParser.getTestDataMap().get(errorMessage) + "  message is not displayed");
	}

	@Then("I verify the default error message as {string}")
	public void i_verify_the_default_error_message_as(String defaultErrMsg) {
		if (searchForTransactionsPage.verifyDefaultErrorMsg(jsonDataParser.getTestDataMap().get(defaultErrMsg)))
			reportPass(jsonDataParser.getTestDataMap().get(defaultErrMsg) + "  message is displayed");
		else
			reportHardFail(jsonDataParser.getTestDataMap().get(defaultErrMsg) + " message is not displayed");
	}

	@Then("I verify the Date Range radio button under Time Period option for first selection")
	public void i_verify_the_Date_Range_radio_button_under_Time_Period_option_for_first_selection() {
		if (searchForTransactionsPage.verifyDateRangeOptionSelected())
			reportPass("Date Range radio button displayed under Time Period option");
		else
			reportFail("Date Range radio button not displayed under Time Period option");
	}

	@Then("I verify the webster account")
	public void i_verify_the_webster_account() {
		if (searchForTransactionsPage.verifyWebsterAccount())
			reportPass("Webster Account dropdown field displayed");
		else
			reportFail("Unable to display the Webster Account dropdown field");
	}

	@Then("I verify the below Time Period options")
	public void i_verify_the_below_Time_Period_options() {
		 listValues = new ArrayList<String>();
		 listValues.addAll(jsonDataParser.getTestDataMap().values());
		if (searchForTransactionsPage.verifyGivenOptionsInTheList(listValues))
			reportPass("Verified options in Time Period list");
		else
			reportFail("Unable to verify options in Time Period list");
	}

	@Then("I verify the Cancel button should display")
	public void i_verify_the_Cancel_button_should_display() {
		if (searchForTransactionsPage.verifyCancelButton())
			reportPass("Cancel button is displayed");
		else
			reportFail("Unable to display the Cancel button");
	}

	@Then("I verify the Search button should display")
	public void i_verify_the_Search_button_should_display() {
		if (searchForTransactionsPage.verifySearchButton())
			reportPass("Search button is displayed");
		else
			reportFail("Unable to display the Search button");
	}

	@Then("I verify the From date and To date fields should display")
	public void i_verify_the_From_date_and_To_date_fields_should_display() {
		if (searchForTransactionsPage.verifyFromAndToDates())
			reportPass("From and To date fields are displayed");
		else
			reportFail("Unable to display the From and To dates");
	}
}
