package com.wb.wol_web.steps;

import java.util.HashMap;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.WebcomNAOPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WebcomNAOSteps extends ObjectBase {
	WebcomNAOPage webcomNAOPage = new WebcomNAOPage();

	@When("I enter the details to create a promo for {string} accounts")
	public void i_enter_the_details_to_create_a_promo_for_accounts(String string) {
		try {
			webcomNAOPage.enterPromoData(jsonDataParser.getTestDataMap());
			reportPass("Entered the data in create new promotion page " + jsonDataParser.getTestDataMap());
		} catch (Exception e) {
			reportHardFail("Failed to enter data to create new promotion");
		}
	}

	@When("I click on continue button in webcom page")
	public void i_click_on_continue_button_in_webcom_page() {
		if (webcomNAOPage.clickOnContinue())
			reportPass("Clicked on the button continue");
		else
			reportHardFail("Failed to click on the continue button");
	}

	@When("I click on createpromotion button in webcom page")
	public void i_click_on_createpromotion_button_in_webcom_page() {
		if (webcomNAOPage.clickOnCreatePromotion())
			reportPass("Clicked on the button createpromotion");
		else
			reportHardFail("Failed to click on the createpromotion button");
	}

	@When("I click on search button in webcom page")
	public void i_click_on_search_button_in_webcom_page() {
		if (webcomNAOPage.clickOnSearch())
			reportPass("Clicked on the button search");
		else
			reportHardFail("Failed to click on the search button");
	}

	@Then("I check if all the details displayed are same as entered")
	public void i_check_if_all_the_details_displayed_are_same_as_entered() {

		Map<String, String> details = new HashMap<>();
		details = webcomNAOPage.checkData(jsonDataParser.getTestDataMap());
		if (details.size() == jsonDataParser.getTestDataMap().size())
			reportPass("All the data displayed in verification page is same as data entered ");
		else
			reportFail("The data displayed in verification page is not same as data entered");

	}

	@Then("I enter the data in the field {string} to search")
	public void i_enter_the_data_in_the_field_to_search(String field) {
		try {
			webcomNAOPage.enterPromoDataToSearch(field);
			reportPass("Entered the data in create new promotion page " + jsonDataParser.getTestDataMap());
		} catch (Exception e) {
			reportHardFail("Failed to enter data to create new promotion");
		}
	}

	@Then("I click on view link in webcom page")
	public void i_click_on_view_link_in_webcom_page() {
		if (webcomNAOPage.clickOnViewLink())
			reportPass("Clicked on the view link");
		else
			reportHardFail("Failed to click on the view link");
	}

	@When("I enter the range of dates to get NAO orders list")
	public void i_enter_the_range_of_dates_to_get_NAO_orders_list() {
		try {
			webcomNAOPage.enterSearchDates(wolWebUtil.getDateInTheFormat("MM/dd/yyyy", -30));
			reportPass("Entered the start date as " + wolWebUtil.getDateInTheFormat("MM/dd/yyyy", -30));
		} catch (Exception e) {
			reportHardFail("Failed to enter the dates for nao order search");
		}
	}

	@Then("I click on view link for any one of the search results")
	public void i_click_on_view_link_for_any_one_of_the_search_results() {
		try {
			webcomNAOPage.clickAnyRowInNAOResults();
			reportPass("Clicked on the view link");
		} catch (Exception e) {
			reportHardFail("Failed to click on the view link for nao order results");
		}
	}

	@Then("I check the labels present in the {string} side")
	public void i_check_the_labels_present_in_the_side(String side) {
		if (webcomNAOPage.checkTheLabelsInOrderDetails(side, jsonDataParser.getTestDataMap().get(side)))
			reportPass("Found the labels " + jsonDataParser.getTestDataMap().get(side) + " at the " + side
					+ " side of the page");
		else
			reportHardFail("Failed to find the labels " + jsonDataParser.getTestDataMap().get(side));
	}

	@Then("I enter the data for search criteria")
	public void i_enter_the_data_for_search_criteria() {
		try {
			webcomNAOPage.enterSearchCriteria("Checking", wolWebUtil.getDateInTheFormat("MM/dd/yyyy", -30));
			reportPass("Entered the data: Checking in category");
		} catch (Exception e) {
			reportHardFail("Failed to enter data to search");
		}
	}

	@Then("I should be in {string} page in Webcom")
	public void i_should_be_in_page_in_Webcom(String message) {
		if (webcomNAOPage.verifyPageHeader(message))
			reportPass("The Page Header: {" + message + "} is  successfully displayed");
		else {
			reportFail("The Page Header: {" + message + "} is not displayed");
		}
	}

	@Then("I click on the link {string} under New Account menu")
	public void click_NAO_menu(String link) {
		if (webcomNAOPage.clickOnNAOMenu(link))
			reportPass("Clicked on the link: {" + link + "}");
		else {
			reportFail("Failed to click on the link: {" + link + "}");
		}
	}

	@Then("I select the type of wil service")
	public void i_select_the_type_of_wil_service() {
		if (webcomNAOPage.selectFromWILService(jsonDataParser.getTestDataMap().get("WIL Service"))) {
			reportPass("Selected the value :" + jsonDataParser.getTestDataMap().get("WIL Service")
					+ " from WIL service dropdown");
		} else
			reportHardFail("Failed to select the value :" + jsonDataParser.getTestDataMap().get("WIL Service")
					+ " from WIL service dropdown");
	}

	@Then("I select the type of request action")
	public void i_select_the_type_of_request_action() {
		if (webcomNAOPage.selectFromReqAction(jsonDataParser.getTestDataMap().get("Request Action"))) {
			reportPass("Selected the value :" + jsonDataParser.getTestDataMap().get("Request Action")
					+ " from Request Action dropdown");
		} else
			reportHardFail("Failed to select the value :" + jsonDataParser.getTestDataMap().get("Request Action")
					+ " from Request Action dropdown");
	}

	@Then("I enter the CIF number of the user")
	public void i_enter_the_CIF_number_of_the_user() {
		if (webcomNAOPage.enterCIFNumber(jsonDataParser.getTestDataMap().get("CIF"))) {
			reportPass("Entered the value :" + jsonDataParser.getTestDataMap().get("CIF") + " in cif input box");
		} else
			reportHardFail(
					"Failed to enter the value :" + jsonDataParser.getTestDataMap().get("CIF") + " in cif input box");
	}

	@Then("I click on the submit button in soap request page")
	public void i_click_on_the_submit_button_in_soap_request_page() {
		if (webcomNAOPage.clickOnSubmitButton()) {
			reportPass("Clicked on the submit button in soap request page");
		} else
			reportHardFail("Failed to click on the submit button in soap request page");
	}

	@Then("I check if the previosuly denied falg is yes in the soap response")
	public void i_check_that_the_previosuly_denied_falg_is_yes_in_the_soap_response() {
		if (webcomNAOPage.checkSOAPResonse("previouslyDeniedService", "Yes")) {
			reportPass("Found the previouslyDeniedService tag value as: Yes for the user");
		} else
			reportHardFail("previouslyDeniedService tag value is not Yes for the user");
	}

}
