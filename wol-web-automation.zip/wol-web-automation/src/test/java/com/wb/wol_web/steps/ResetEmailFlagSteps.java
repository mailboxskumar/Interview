package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.ResetEmailFlagPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ResetEmailFlagSteps extends ObjectBase {

	ResetEmailFlagPage resetEmailFlagPage = new ResetEmailFlagPage();

	@Given("I verify {string}, {string} fields of {string} in Webcom")
	public void i_verify_fields_of_in_Webcom(String fieldNameFirst, String fieldNameSecond, String labelName) {
		if (resetEmailFlagPage.checkForFields(fieldNameFirst, fieldNameSecond, labelName))
			reportPass("Fields: " + fieldNameFirst + ", " + fieldNameSecond + " is displayed at :" + labelName);
		else
			reportPass("Fields: " + fieldNameFirst + ", " + fieldNameSecond + " is not displayed at :" + labelName);
	}

	@Then("I verify {string} and {string} fields in Verify Email Address Page")
	public void i_verify_and_fields_in_Verify_Email_Address_Page(String newEmail, String retypeEmail) {
		if (resetEmailFlagPage.checkForEmailAddress(newEmail, retypeEmail))
			reportPass("Labels: " + newEmail + ", " + retypeEmail + " are displayed");
		else
			reportFail("Labels: " + newEmail + ", " + retypeEmail + " are not displayed");
	}

	@And("I verify {string} button is selected by default of {string} in Webcom")
	public void i_verify_button_is_selected_by_default_of_in_Webcom(String fieldName, String labelName) {
		if (resetEmailFlagPage.verifyDefaultSelection(fieldName, labelName))
			reportPass("Field: " + fieldName + " is selected by default at :" + labelName);
		else
			reportFail("Field: " + fieldName + " is not selected by default at :" + labelName);

	}

	@Given("I click on {string} button of {string} in Webcom")
	public void i_click_on_button_of_in_Webcom(String fieldName, String labelName) {
		if (resetEmailFlagPage.clickOnButton(fieldName, labelName))
			reportPass("Field: " + fieldName + " is clicked on button :" + labelName);
		else
			reportFail("Field: " + fieldName + " is not clicked on button :" + labelName);
	}

	@Then("I verify update success message in {string} page")
	public void i_verify_update_success_message_in_page(String labelName) {
		String resetEmailUpdateSuccessMessage = jsonDataParser.getTestDataMap().get("ResetEmailUpdateSuccessMessage");
		if (resetEmailFlagPage.verifyMessage(resetEmailUpdateSuccessMessage, labelName))
			reportPass("Message: " + resetEmailUpdateSuccessMessage + ", message is received at :" + labelName);
		else
			reportFail("Message: " + resetEmailUpdateSuccessMessage + ",  message is not received at :" + labelName);
	}

	@Then("user navigate to {string} page")
	public void user_navigate_to_page(String pageTitle) {
		if (resetEmailFlagPage.verifyTitle(pageTitle))
			reportPass("User navigated to: " + pageTitle);
		else
			reportFail("User not navigated to: " + pageTitle);
	}

	@Then("I verify {string} and {string} buttons in Verify Email Address Page")
	public void i_verify_and_buttons_in_Verify_Email_Address_Page(String labelYes, String labelNo) {
		if (resetEmailFlagPage.verifyEmailLabels(labelYes, labelNo))
			reportPass("Labels are present: " + labelYes + ", " + labelNo);
		else
			reportFail("Label are not present: " + labelYes + ", " + labelNo);
	}

	@Then("I verify {string} button is selected by default in Verify Email Address Page")
	public void i_verify_button_is_selected_by_default_in_Verify_Email_Address_Page(String labelNo) {
		if (resetEmailFlagPage.verifyDefaultSelection(labelNo))
			reportPass("Field is selected by default at:" + labelNo);
		else
			reportFail("Field is not selected by default at:" + labelNo);
	}

	@Given("I enter new email address as {string} in new email and Re-type Email fields")
	public void i_enter_new_email_address_as_in_new_email_and_Re_type_Email_fields(String newEmailAddress) {
		if (resetEmailFlagPage.enterEmailAddress(newEmailAddress))
			reportPass("New Email Address is entered as: " + newEmailAddress
					+ " in New Email and Re-type Email address fields");
		else
			reportFail("New Email Address is not entered as: " + newEmailAddress
					+ " in New Email and Re-type Email address fields");
	}

	@Given("I click on {string} button in Verify Email Address Page")
	public void i_click_on_button_in_Verify_Email_Address_Page(String btnContinue) {
		if (resetEmailFlagPage.clickButton(btnContinue))
			reportPass("Button is clicked: " + btnContinue);
		else
			reportFail("Button is not clicked: " + btnContinue);
	}

	@Then("I click on {string} button of Manager Audit Trail Details page")
	public void i_click_on_button_of_Manager_Audit_Trail_Details_page(String btnView) {
		if (resetEmailFlagPage.clickButton(btnView))
			reportPass("View button is clicked: " + btnView);
		else
			reportFail("View button is not clicked: " + btnView);
	}

	@Then("I verify {string} message in {string} field")
	public void i_verify_message_in_field(String value, String label) {
		if (resetEmailFlagPage.verifyLabelValues(value, label))
			reportPass("Value: " + value + " is available at label: " + label);
		else
			reportFail("Value: " + value + " is not available at label: " + label);
	}

	@Then("I verify {string} and {string} fields is not present in Verify Email Address Page")
	public void i_verify_and_fields_is_not_present_in_Verify_Email_Address_Page(String newEmail, String retypeEmail) {
		if (resetEmailFlagPage.checkForEmailAddress(newEmail, retypeEmail))
			reportFail("Labels: " + newEmail + " " + retypeEmail + " are displayed");
		else
			reportPass("Labels: " + newEmail + " " + retypeEmail + " are not displayed");
	}

	@Then("I verify the error message")
	public void i_verify_the_error_message() {
		String resetEmailErrorMessage = jsonDataParser.getTestDataMap().get("ResetEmailErrorMessage");
		if (resetEmailFlagPage.verifyEmailErrorMsg(resetEmailErrorMessage))
			reportPass("The correct message is populated as: " + resetEmailErrorMessage);
		else
			reportFail("The incorrect message is populated: " + resetEmailErrorMessage);
	}

	@Then("I verify the New Email Address field error message")
	public void i_verify_the_New_Email_Address_field_error_message() {
		String resetEmailNewEmailErrorMessage = jsonDataParser.getTestDataMap().get("ResetEmailNewEmailErrorMessage");
		if (resetEmailFlagPage.verifyBlankErrorMsg(resetEmailNewEmailErrorMessage))
			reportPass("The correct message is populated as: " + resetEmailNewEmailErrorMessage);
		else
			reportFail("The incorrect message is populated: " + resetEmailNewEmailErrorMessage);
	}

	@Then("I verify the Retype Email Address field error message")
	public void i_verify_the_Retype_Email_Address_field_error_message() {
		String resetEmailRetypeEmailErrorMessage = jsonDataParser.getTestDataMap()
				.get("ResetEmailRetypeEmailErrorMessage");
		if (resetEmailFlagPage.verifyBlankErrorMsg(resetEmailRetypeEmailErrorMessage))
			reportPass("The correct message is populated as: " + resetEmailRetypeEmailErrorMessage);
		else
			reportFail("The incorrect message is populated: " + resetEmailRetypeEmailErrorMessage);
	}
}
