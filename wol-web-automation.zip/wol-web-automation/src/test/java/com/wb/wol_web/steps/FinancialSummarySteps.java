package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.FinancialSummaryPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FinancialSummarySteps extends ObjectBase {

	FinancialSummaryPage financialSummaryPage = new FinancialSummaryPage();

	@When("I verify the updated nickname account and click on Account details link")
	public void i_verify_the_updated_nickname_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on updated Nick name Account details link");
		else
			reportFail("Unable to click on updated Nick name Account details link");
	}

	@Then("I verify the updated nickname is displayed in Account details Page")
	public void i_verify_the_updated_nickname_is_displayed_in_Account_details_Page() {
		if (financialSummaryPage.verifyNickNameInAccDetailsPage())
			reportPass("Updated Nick name is displayed in Account details Page");
		else
			reportHardFail("Updated Nick name is not displayed in Account details Page");
	}

	@When("I click on Account Details link for account {string} which does not have any nickname")
	public void i_click_on_Account_Details_link_for_account_which_does_not_have_any_nickname(
			String accountDetailsLink) {
		accountDetailsLink=jsonDataParser.getTestDataMap().get(accountDetailsLink);
		if (financialSummaryPage.clickOnAccountDetailsLink(accountDetailsLink))
			reportPass("Clicked on Account details link");
		else
			reportFail("Unable to click on Account details link");
	}

	@When("I close the lightbox")
	public void i_close_the_lightbox() {
		if (financialSummaryPage.clickOnCloseButton())
			reportPass("Lightbox page closed");
		else
			reportFail("Unable to close the Lightbox page");
	}

	@When("I verify the Checking account and click on Account details link")
	public void i_verify_the_Checking_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on Checking Account details link");
		else
			reportFail("Unable to click on Checking Account details link");
	}

	@When("I verify the Saving account and click on Account details link")
	public void i_verify_the_Saving_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on Saving Account details link");
		else
			reportFail("Unable to click on Saving Account details link");
	}

	@When("I verify the CD account and click on Account details link")
	public void i_verify_the_CD_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on CD Account details link");
		else
			reportFail("Unable to click on CD Account details link");
	}

	@When("I verify the CreditLine account and click on Account details link")
	public void i_verify_the_CreditLine_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on Credit Line Account details link");
		else
			reportFail("Unable to click on Credit Line Account details link");
	}

	@When("I verify the BusinessLoan account and click on Account details link")
	public void i_verify_the_BusinessLoan_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on Business Loan Account details link");
		else
			reportFail("Unable to click on Business Loan Account details link");
	}

	@When("I verify the CreditCard account and click on Account details link")
	public void i_verify_the_CreditCard_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on Credit Card Account details link");
		else
			reportFail("Unable to click on Credit Card Account details link");
	}

	@When("I verify the Investment account and click on Account details link")
	public void i_verify_the_Investment_account_and_click_on_Account_details_link() {
		if (financialSummaryPage.clickOnAccountDetailsInSummaryPage())
			reportPass("Clicked on Investment Account details link");
		else
			reportFail("Unable to click on Investment Account details link");
	}

	@Then("I verify the Print button should display in Lightbox for Investment Account")
	public void i_verify_the_Print_button_should_display_in_Lightbox_for_Investment_Account() {
		if (financialSummaryPage.isDisplayPrintButtonForInvestmentAcc())
			reportPass("Print button displayed in Lightbox");
		else
			reportFail("Print button not displayed in Lightbox");
	}

	@Then("I verify the Close button should display in Lightbox for Investment Account")
	public void i_verify_the_Close_button_should_display_in_Lightbox_for_Investment_Account() {
		if (financialSummaryPage.isDisplayCloseButtonForInvestmentAcc())
			reportPass("Close button displayed in Lightbox");
		else
			reportFail("Close button not displayed in Lightbox");
	}

	@Then("I verify the Print button should display in Lightbox")
	public void i_verify_the_Print_button_should_display_in_Lightbox() {
		if (financialSummaryPage.isDisplayPrintButton())
			reportPass("Print button displayed in Lightbox");
		else
			reportFail("Print button not displayed in Lightbox");
	}

	@Then("I verify the Close button should display in Lightbox")
	public void i_verify_the_Close_button_should_display_in_Lightbox() {
		if (financialSummaryPage.isDisplayCloseButton())
			reportPass("Close button displayed in Lightbox");
		else
			reportFail("Close button not displayed in Lightbox");
	}

}
