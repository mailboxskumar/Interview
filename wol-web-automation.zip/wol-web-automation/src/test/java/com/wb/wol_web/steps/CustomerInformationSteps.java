package com.wb.wol_web.steps;

import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.pages.CustomerInformationPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.emory.mathcs.backport.java.util.Arrays;

public class CustomerInformationSteps extends ObjectBase {
	CustomerInformationPage customerInformationPage = new CustomerInformationPage();
	CommonPage commonPage = new CommonPage();

	public String newEmailAddress = "";

	@Then("I check for the Current Email Adddress")
	public void i_check_for_the_Current_Email_Adddress() {
		if (customerInformationPage.checkCurrentEmailAddress() != null)
			reportPass("Current Email Address is " + customerInformationPage.checkCurrentEmailAddress());
		else
			reportFail("Not able to get current Email Address");
	}

	@When("I click on {string} button Update Email Address page")
	public void i_click_on_button_page(String btnName) {
		if (customerInformationPage.clickOnButton(btnName))
			reportPass("Clicked on the " + btnName + " button");
		else
			reportHardFail("Not clicked on the " + btnName + " button");
	}

	@Then("I should see error on top of the page")
	public void i_should_see_error_on_top_of_the_page() {
		if (customerInformationPage.checkErrorMessageOnPageTop() != null)
			reportPass(customerInformationPage.checkErrorMessageOnPageTop() + " is displayed");
		else
			reportFail("Top Error message is not present");
	}

	@Then("I should see error {string} at New Email Address and {string} Verify New Email Address")
	public void i_should_see_error_at_New_Email_Address_and_Verify_New_Email_Address(String txtNewErrorMessage,
			String txtVerifyErrorMessage) {
		txtNewErrorMessage = jsonDataParser.getTestDataMap().get(txtNewErrorMessage);
		txtVerifyErrorMessage = jsonDataParser.getTestDataMap().get(txtVerifyErrorMessage);
		if (customerInformationPage.checkTwoMessages(txtNewErrorMessage, txtVerifyErrorMessage))
			reportPass("Error messages: " + txtNewErrorMessage + "," + txtVerifyErrorMessage + " is present");
		else
			reportFail("Two Fields Error message is not present");
	}

	@And("I should see error {string} at Verify New Email Address")
	public void i_should_see_error_at_Verify_New_Email_Address(String txtErrorMessage) {
		txtErrorMessage = jsonDataParser.getTestDataMap().get(txtErrorMessage);
		if (customerInformationPage.checkVerifyEmailMessage(txtErrorMessage))
			reportPass("Message: " + txtErrorMessage + " is present");
		else
			reportFail("Error message is not present");
	}

	@Then("I should see {string} as Updated New Email Address")
	public void i_should_see_as_Updated_New_Email_Address(String txtUpdatedEmail) {
		if (customerInformationPage.checkUpdatedEmail())
			reportPass("New eMail Address: " + newEmailAddress + " is present");
		else
			reportHardFail("New eMail Address: " + newEmailAddress + " is not present");
	}

	@Then("I should be navigated to {string} page")
	public void i_should_be_navigated_to_page(String pageName) {
		if (commonPage.checkPageTitle(pageName))
			reportPass("Redirected to " + pageName + " page");
		else
			reportFail("Not redirected to " + pageName + " page");
	}

	@And("I check for the current user name")
	public void i_check_for_the_current_user_name() {
		if (customerInformationPage.checkCurrentUserName() != null)
			reportPass("current user name is " + customerInformationPage.checkCurrentUserName());
		else
			reportFail("Not able to retrieve current user name");
	}

	@Then("I should see labels and enter the values with username as {string}")
	public void i_should_see_below_labels_and_enter_the_values(String username) {
		Map<String, String> testDataMap1 = jsonDataParser.getTestDataMap();
		testDataMap1.putIfAbsent("New User Name", username);
		List<String> listValues = customerInformationPage.checkAndEnterValues(testDataMap1);
		if (listValues != null)
			reportPass(listValues.toString() + " Entered successfully");
		else
			reportFail("Required values not entered ");
	}

	@Then("I should see labels and enter the values")
	public void i_should_see_below_labels_and_enter_the_values() {
		Map<String, String> testDataMap1 = jsonDataParser.getTestDataMap();
		List<String> listValues = customerInformationPage.checkAndEnterValues(testDataMap1);
		if (listValues != null)
			reportPass(listValues.toString() + " Entered successfully");
		else
			reportFail("Required values not entered ");
	}

	@When("I click on {string} button of page Update Password and\\/or User Name")
	public void i_click_on_button_of_page(String btnName) {
		if (customerInformationPage.clickOnButton(btnName))
			reportPass("Clicked on the " + btnName + " button");
		else
			reportHardFail("Not clicked on the " + btnName + " button");
	}

	@Then("I should see message {string} for {string}")
	public void i_should_see_message_for(String message, String value) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (customerInformationPage.updateMessage(message))
			reportPass("Message:" + message + " is displayed");
		else
			reportHardFail("Message:" + message + " is not displayed");
	}

	@And("I should see error message for password {string}")
	public void i_should_see_error_message_for_password(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (customerInformationPage.forgotPasswordErrorMessage(message))
			reportPass("Error message: " + message + " is displayed");
		else
			reportFail("Error message: " + message + " is not displayed");
	}

	@Then("I will enter {string}")
	public void i_will_enter(String newPassword) {
		newPassword = jsonDataParser.getTestDataMap().get(newPassword);
		if (customerInformationPage.enterPassword(newPassword))
			reportPass("I entered the new password as: " + newPassword);
		else
			reportFail("not able to enter the new password as: " + newPassword);
	}

	@Then("I should see error message on top as {string}")
	public void i_should_see_error_message_on_top_as(String genericErrorMessage) {
		genericErrorMessage = jsonDataParser.getTestDataMap().get(genericErrorMessage);
		if (customerInformationPage.checkErrorMessageOnPageTop() != null)
			reportPass(customerInformationPage.checkErrorMessageOnPageTop() + " is displayed");
		else
			reportFail("Error message at top of the page is not present");
	}

	@Then("I should see error message on {string} label as {string}")
	public void i_should_see_error_message_on_label_as(String labelName, String errorMessage) {
		errorMessage = jsonDataParser.getTestDataMap().get(errorMessage);
		if (customerInformationPage.checkSpecificErrorMessage(labelName, errorMessage))
			reportPass("error message at " + labelName + " is " + errorMessage);
		else
			reportFail("error message at " + labelName + " is not displayed as " + errorMessage);
	}

	@Then("I check for the note of {string}")
	public void i_check_for_the_note_as(String noteMessage) {
		noteMessage = jsonDataParser.getTestDataMap().get(noteMessage);
		if (customerInformationPage.checkNote(noteMessage))
			reportPass("Message: " + noteMessage + " is displayed");
		else
			reportFail("Note message is not displayed");
	}

	@When("I click on {string} button of Update Business Information page")
	public void i_click_on_button_Update_Business_Information_page(String btnName) {
		if (customerInformationPage.clickOnButton(btnName))
			reportPass("Clicked on the " + btnName + " button");
		else
			reportFail("Not clicked on the " + btnName + " button");
	}

	@And("I check for the current Business user name")
	public void i_check_for_the_current_Business_user_name() {
		if (customerInformationPage.checkCurrentBusinessUserName() != null)
			reportPass("current user name is " + customerInformationPage.checkCurrentBusinessUserName());
		else
			reportFail("Not able to retrieve current user name");
	}

	@Then("I should see below labels and enter the {string} values")
	public void i_should_see_below_labels_and_enter_the_some_values(String valuesType) {
		Map<String, String> map = jsonDataParser.getTestDataMap();
		if (customerInformationPage.checkAndEnterValuesOfUpdateBusiness(map))
			reportPass(map.values().toString() + " entered successfully");
		else
			reportFail(map.values().toString() + " values not entered ");
	}

	@Then("I should see message {string}")
	public void i_should_see_message(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (customerInformationPage.updateMessageBusiness(message))
			reportPass("Message: " + message + " is displayed");
		else
			reportFail("Message: " + message + " is not displayed");
	}

	@Then("I check for the {string} links")
	public void i_check_for_the_below_links(String pageName) {
		String[] links = jsonDataParser.getTestDataMap().get(pageName).split(";");
		@SuppressWarnings("unchecked")
		List<String> listLinks = Arrays.asList(links);
		if (listLinks.size() == customerInformationPage.checkLinkTitles(listLinks))
			reportPass(listLinks.toString() + " links are verified successfully");
		else
			reportHardFail(listLinks.toString() + " links are not verified ");
	}

	@Then("I select the {string} for Recognize me on this Computer")
	public void i_select_the_for_Recognize_me_on_this_Computer(String radioButton) {
		if (customerInformationPage.clickOnButton(radioButton))
			reportPass("Clicked on the " + radioButton + " radio button");
		else
			reportHardFail("Not clicked on the " + radioButton + " radio buton");
	}

	@When("I click on {string} of Update Security Information page")
	public void i_click_on_of_Update_Security_Information_page(String btnName) {
		if (customerInformationPage.clickOnButton(btnName))
			reportPass("Clicked on the " + btnName + " button");
		else
			reportHardFail("Not clicked on the " + btnName + " button");
	}

	@Then("I check for the {string} message")
	public void i_check_for_the_message(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (customerInformationPage.checkMessage(message))
			reportPass("Message: " + message + " is displayed");
		else
			reportHardFail("Message: " + message + " is not displayed");
	}

	@Then("I answer the question in authentication page")
	public void i_answer_the_question_in_authentication_page() {
		if (customerInformationPage.enterAnswer())
			reportPass("Authentication is successfully completed");
		else
			reportHardFail("Authentication is not displayed");
	}

	@When("I select {string} button for Register this device and click on Continue button")
	public void i_select_for_Register_this_device_and_click_on_Continue_button(String btnName) {
		if (customerInformationPage.selectAndClick(btnName))
			reportPass("Radio Button {No} is selected and clicked continue button");
		else
			reportFail("Radio Button {No} is not selected or not clicked on continue button");
	}

	@Then("I enter password and click on Continue button")
	public void i_enter_password_and_click_on_Continue_button() {
		if (customerInformationPage.enterOnlyPassword())
			reportPass(" Password entered and clicked on continue button");
		else
			reportFail(" Password is not entered or not  clicked on continue button");
	}

	@When("I click on {string} Menu")
	public void i_click_on_Menu(String Menu) {
		if (customerInformationPage.clickOnButton(Menu))
			reportPass("Clicked on the " + Menu + " Menu");
		else
			reportHardFail("Not clicked on the " + Menu + " Menu");
	}

	@Then("I check for {string} link is not displayed")
	public void i_check_for_link_is_not_displayed(String linkName) {
		if (customerInformationPage.checkForLinkNotPresent(linkName))
			reportPass(linkName + " link is not displayed");
		else
			reportHardFail(linkName + " link is displayed");
	}

	@When("I click on {string} widget")
	public void i_click_on_widget(String btnName) {
		if (customerInformationPage.clickOnButton(btnName))
			reportPass("Clicked on the " + btnName + " button");
		else
			reportHardFail("Not clicked on the " + btnName + " button");
	}

	@When("I select questions and {string} answers")
	public void i_select_questions_and_answers(String answerType) {
		if (customerInformationPage.selectRandomQuestion(answerType))
			reportPass("Selected random question");
		else
			reportFail("Not Selected random question");
	}

	@Then("I should see {string} message, {string} and {string} information are displayed")
	public void i_should_see_message_and_information_are_displayed(String welcome, String lastLogin, String messages) {
		welcome = jsonDataParser.getTestDataMap().get(welcome);
		lastLogin = jsonDataParser.getTestDataMap().get(lastLogin);
		messages = jsonDataParser.getTestDataMap().get(messages);
		List<String> details = customerInformationPage.checkForPresence(welcome, lastLogin, messages);
		if (details.size() == 3)
			reportPass("Labels: " + details.toString() + " is displayed");
		else
			reportHardFail("one of " + welcome + ", " + lastLogin + " and " + messages + " is not displayed");
	}

	@Then("I should see profile links")
	public void i_should_see_below_links() {
		testDataMap = jsonDataParser.getTestDataMap();
		List<String> links = customerInformationPage.checkLinkValues(testDataMap);
		if (links.size() != 0)
			reportPass(links.toString() + " Verified successfully");
		else
			reportHardFail("one/many of link(s): " + links.toString() + " is/are not displayed");
	}

	@When("I click on {string} link on widget")
	public void i_click_on_link_on_widget(String linkName) {
		if (customerInformationPage.clickOnLink(linkName))
			reportPass("Clicked on the " + linkName + " link ");
		else
			reportHardFail("Not clicked on the " + linkName + " link ");
	}

	@Then("I should see error as {string}")
	public void i_should_see_error_as(String txtErrorMessage) {
		txtErrorMessage = jsonDataParser.getTestDataMap().get(txtErrorMessage);
		if (customerInformationPage.checkAddressErrorMessage(txtErrorMessage))
			reportPass("error message  is displayed as: " + txtErrorMessage);
		else
			reportFail("error message is not displayed as: " + txtErrorMessage);
	}

	@Then("I should see a {string} page")
	public void i_should_see_a_page(String pageName) {
		if (customerInformationPage.checkAddressPageTitle(pageName))
			reportPassWithFullPageScreenshot("Redirected to " + pageName + " page");
		else
			reportHardFailWithFullPageScreenshot("Not Redirected to " + pageName + " page");
	}

	@When("I Enter {string} in New Email Addres field")
	public void i_Enter_in_New_Email_Addres_field(String mailType) {
		newEmailAddress = customerInformationPage.enterNewEmailAddress(mailType);
		if (newEmailAddress != null)
			reportPass("New eMail Address as:" + newEmailAddress + " is entered");
		else
			reportFail("New eMail Address is not entered correctly");
	}

	@When("I Enter {string} in Verify New Email Addres field")
	public void i_Enter_in_Verify_New_Email_Addres_field(String mailType) {
		newEmailAddress = customerInformationPage.enterVerifyNewEmailAddress(mailType);
		if (newEmailAddress != null)
			reportPass("Verify New eMail Address as:" + newEmailAddress + " is entered");
		else
			reportFail("Verify New eMail Address is not entered correctly");
	}

	@When("I verify the profile security information")
	public void i_verify_the_profile_security_information() {
		String infoText = jsonDataParser.getTestDataMap().get("Security Info Text");
		if (customerInformationPage.verifySecurityInfo(infoText))
			reportPass("Security Info:" + infoText + " is displayed");
		else
			reportFail("Security Info is not displayed");
	}

	@When("I verify the simplify login text")
	public void i_verify_the_simplify_login_text() {
		String text1 = jsonDataParser.getTestDataMap().get("SimplifyLogin1");
		String text2 = jsonDataParser.getTestDataMap().get("SimplifyLogin2");
		if (customerInformationPage.verifySimplifyLoginInfo(text1, text2))
			reportPass("Simplify Login: " + text1 + text2 + " is displayed");
		else
			reportFail("Simplify Login is not displayed");
	}

	@Then("I should be in the page of {string}")
	public void i_should_be_in_the_page(String pageName) {
		if (customerInformationPage.checkPageTitle(pageName))
			reportPassWithFullPageScreenshot("Redirected to " + pageName + " page");
		else
			reportHardFailWithFullPageScreenshot("Not Redirected to " + pageName + " page");
	}

	@When("I verify the error message at three answer fields")
	public void i_verify_the_error_message_at_theree_answer_fields() {
		String answerError = jsonDataParser.getTestDataMap().get("AnswerError");
		if (customerInformationPage.verifyAnswerError(answerError))
			reportPass("Answer Error:" + answerError + " is displayed");
		else
			reportFail("Answer Error:" + answerError + " is not displayed");
	}
}