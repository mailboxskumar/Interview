package com.wb.wol_web.steps;

import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.pages.ForgotUsernamePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class ForgotUsernameSteps extends ObjectBase {

	ForgotUsernamePage forgotUsernamePage = new ForgotUsernamePage();

	@When("^I enter password and click on continue button$")
	public void i_enter_password_something_and_click_on_continue_button() throws Throwable {
		String value=jsonDataParser.getTestDataMap().get("Password");
		if (new CommonPage().enterPassword(value))
			reportPass("Entered Password value ");
		else
			reportFail("Failed to enter password value");
	}
	@When("I enter password {string} and click on continue button")
	public void i_enter_password_and_click_on_continue_button(String value) throws Throwable {
		if (new CommonPage().enterPassword(value))
			reportPass("Entered Password value ");
		else
			reportFail("Failed to enter password value");
	}

	@Then("^I should able to see Forgot Username Link$")
	public void i_should_able_to_see_forgot_username_link() throws Throwable {
		if (forgotUsernamePage.verifyForgotUsernameLink())
			reportPass("Forgot Username? Link is successfully displayed");
		else
			reportFail("Forgot Username? Link is not displayed");
	}

	@When("^I click on Forgot Username Link$")
	public void i_click_on_forgot_username_link() throws Throwable {
		try {
			forgotUsernamePage.clickForgotUsernameLink();
			reportPass("Clicked on Forgot Username? Link");
		} catch (Exception e) {
			reportHardFail("Failed to click on Forgot Username? link");
		}
	}

	@And("^I entered Request User name Details$")
	public void i_entered_request_user_name_details() throws Throwable {
		testDataMap = jsonDataParser.getTestDataMap();
		if (forgotUsernamePage.requestUsernameDetails(testDataMap))
			reportPass("Entered all the required User name details SSN: " + testDataMap.get("SSN")
					+ "and Account Number: " + testDataMap.get("Acct Number"));
		else
			reportFail("Failed to enter required User name details SSn & Account Number");
	}

	@And("^I click On Continue Button in Request Username Page$")
	public void i_click_on_continue_button_in_request_username_page() throws Throwable {
		try {
			forgotUsernamePage.clickContinueButton();
			reportPass("Clicked on Continue button in Request Username page");
		} catch (Exception e) {
			reportFail("Failed to click on Continue button in Request Username page");
		}
	}

	@Then("^I should see Account number error message in Request Username Page")
	public void i_should_see_account_number_error_message_something_in_request_username_page()
			throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (forgotUsernamePage.verifyAcctErrMsg(message))
			reportPass("The Account Number Error message {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("The Account Number Error message: {" + message + "} is not displayed");
	}
	@Then("I should see SSN error message in Request Username Page")
	public void i_should_see_SSN_error_message_in_Request_Username_Page() {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (forgotUsernamePage.verifySSNErrMsg(message))
			reportPass("The SSN Error message {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("The SSN Error message: {" + message + "} is not displayed");
	}
	@Then("^I should see No User Error message")
	public void i_should_see_no_user_error_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (forgotUsernamePage.verifyUserErrMsg(message))
			reportPass("The user message: {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportHardFail("The User message: {" + message + "} is not displayed");
	}

	@And("^I enter value in Answer text field$")
	public void i_enter_value_something_in_answr_text_field() throws Throwable {
		String value=jsonDataParser.getTestDataMap().get("Answer");
		try {
			forgotUsernamePage.enterAnswer(value);
			reportPass("Entered value {" + value + "} in answer text field");
		} catch (Exception e) {
			reportFail("Failed to enter Answer value");
		}
	}

	@Then("^I should see Answer error message")
	public void i_should_see_answer_error_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (forgotUsernamePage.verifyAnswerErrMsg(message))
			reportPass("The Answer Error message: {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("The Answer Error message: {" + message + "} is not displayed");
	}

	@Then("^I should see the user confirmation message")
	public void i_should_see_the_confirmation_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Cnfrm Msg");
		if (forgotUsernamePage.verifyCnfrmMsg(message))
			reportPass("The Confirmation message: {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("The Confirmation message: {" + message + "} is not displayed");
	}

	@And("^I should see the user value$")
	public void i_should_see_the_user_value() throws Throwable {
		if (forgotUsernamePage.getUserValue())
			reportPass("Retrieved the User Name: {" + forgotUsernamePage.user + "}  successfully");
		else
			reportFail("Failed to get user name");
	}

	@Then("^I should see the Cancel message")
	public void i_should_see_the_cancel_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Cancel Msg");
		if (forgotUsernamePage.verifyCancelMsg(message))
			reportPass("Cancellation message: {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("Cancellation message: {" + message + "} is not displayed");
	}

	@When("^I click on close button$")
	public void i_click_on_close_button() throws Throwable {
		try {
			forgotUsernamePage.clickCloseButton();
			reportPass("Clicked on close button");
		} catch (Exception e) {
			reportFail("Failed to click on Close button");
		}
	}
	@When("^I click on cancel button$")
	public void i_click_on_cancel_button() throws Throwable {
		try {
			forgotUsernamePage.clickCancelButton();
			reportPass("Clicked on close button");
		} catch (Exception e) {
			reportFail("Failed to click on Close button");
		}
	}

	@When("^I click on No button$")
	public void i_click_on_no_button() throws Throwable {
		try {
			forgotUsernamePage.clickNoButton();
			reportPass("Clicked on No button");
		} catch (Exception e) {
			reportFail("Failed to click on No Button");
		}
	}

	@When("^I click on Yes button$")
	public void i_click_on_yes_button() throws Throwable {
		try {
			forgotUsernamePage.clickYesButton();
			reportPass("Clicked on Yes button");
		} catch (Exception e) {
			reportFail("Failed to click on Yes button");
		}
	}

	@Then("^I should be navigated to the \"([^\"]*)\" page$")
	public void i_should_be_navigated_to_something_page(String message) throws Throwable {
		if (forgotUsernamePage.verifyPageTiitle(message))
			reportPass("The Page: {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("The Page: {" + message + "} is not displayed");
	}

	@When("^I click on Return SignIn Link$")
	public void i_click_on_return_signin_link() throws Throwable {
		if (forgotUsernamePage.clickReturnSignInLink())
			reportPass("Clicked on Return Sign In Link");
		else
			reportFail("Failed to click on Return Sign In Link");
	}

	@Then("^I should able to see Error message")
	public void i_should_able_to_see_error_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (forgotUsernamePage.verifySignInErrMsg())
			reportPass("Sign In Error message: {" + wolWebUtil.containsText + "} is successfully displayed");
		else
			reportFail("Sign In Error message: {" + message + "} is not displayed");
	}

	@And("^I should see Start Again Link$")
	public void i_should_see_start_again_link() throws Throwable {
		if (forgotUsernamePage.verifyStartAgainLink())
			reportPass("Start Again Link is successfully displayed");
		else
			reportFail("Start Again Link is not displayed");
	}

	@And("^I should able to see Forgot Password Link$")
	public void i_should_able_to_see_forgot_password_link() throws Throwable {
		if (forgotUsernamePage.verifyForgotPasswordLink())
			reportPass("Forgot Password Link is successfully displayed");
		else
			reportFail("Forgot Password Link is not displayed");
	}

	@Then("^I should see the first challenge Question$")
	public void i_should_see_the_first_challenge_question() throws Throwable {
		forgotUsernamePage.getChallengeQuestion();
	}

	@And("^I should see the second challenge question$")
	public void i_should_see_the_second_challenge_question() throws Throwable {
		if (forgotUsernamePage.verifyChallengeQuestion())
			reportPass("The Second Challenge Question {" + forgotUsernamePage.question2 + "} is displayed");
		else
			reportFail("The Second Challenge Question  is not displayed");

	}

	@And("^I should able to see error message of Username")
	public void i_should_able_to_see_error_message_of_username_something() throws Throwable {
		String errormsg=jsonDataParser.getTestDataMap().get("Error Msg");
		if (forgotUsernamePage.verifyUsernameErrMsg(errormsg))
			reportPass("Username Error message: {" + errormsg + "} is successfully displayed");
		else
			reportFail("Username Error message: {" + errormsg + "} is not displayed");
	}

	@When("^I click on Start Again Link$")
	public void i_click_on_start_again_link() throws Throwable {
		if (forgotUsernamePage.clickStartAgainLink())
			reportPass("Clicked on Start Again Link in Sign In Error page");
		else
			reportFail("Failed to click on Start Again Link");
	}

	@And("^I should see Username Text box$")
	public void i_should_see_username_text_box() throws Throwable {
		if (forgotUsernamePage.verifyUsernameField())
			reportPass("Username Text Box is successfully displayed");
		else
			reportFail("Username Text Box is not displayed");
	}

}
