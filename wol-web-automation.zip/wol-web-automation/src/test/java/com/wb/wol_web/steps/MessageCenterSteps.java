package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.MessageCenterPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MessageCenterSteps extends ObjectBase {
	MessageCenterPage messageCenterPage = new MessageCenterPage();

	@Then("I verify the {string} details of message center")
	public void i_verify_the_below_of_message_center_details(String pageName) {
		testDataMap = jsonDataParser.getTestDataMap();
		if (messageCenterPage.checkForDetails(pageName, testDataMap) == testDataMap.size())
			reportPass("Labels: " + testDataMap.values().toString() + " are displayed");
		else
			reportFail("some detalis in " + testDataMap.values().toString() + " is not displayed");
	}

	@When("I click on {string} link in RELATED LINKS")
	public void i_click_on_link_in_RELATED_LINKS(String linkName) {
		if (messageCenterPage.clickOnRelatedLink(linkName))
			reportPass("Link: " + linkName + " is clicked");
		else
			reportFail("Link: " + linkName + " is not clicked");
	}

	@And("I verify the service message")
	public void i_verify_the_service_message() {
		String serviceMessage = jsonDataParser.getTestDataMap().get("serviceMessage");
		if (messageCenterPage.checkServiceMessage(serviceMessage))
			reportPass("Message: " + serviceMessage + " is displayed");
		else
			reportFail("Message: " + serviceMessage + " is not displayed ");
	}

	@When("I click on {string} button of send message page")
	public void i_click_on_button_of_send_message_page(String btnName) {
		if (messageCenterPage.clickOnLink(btnName))
			reportPass("Clicked on " + btnName + " button");
		else
			reportFail("Not clicked on " + btnName + " button");
	}

	@When("I click on {string} on lightbox")
	public void i_click_on_on_lightbox(String btnName) {
		if (messageCenterPage.clickOnLink(btnName))
			reportPass("Clicked on " + btnName + " button");
		else
			reportFail("Not clicked on " + btnName + " button");
	}

	@When("I click on {string} subject of message")
	public void i_click_on_subject(String linkName) {
		if (messageCenterPage.clickOnLink(linkName))
			reportPass("Clicked on " + linkName + " link");
		else
			reportHardFail("Not clicked on " + linkName + " link");
	}

	@And("I verify for the {string} button")
	public void i_verify_for_the_and_buttons(String btnName) {
		if (messageCenterPage.checkDisplay(btnName))
			reportPass("verified for the " + btnName + " button");
		else
			reportFail(btnName + " button is not present");
	}

	@Then("I verify the message in {string}")
	public void i_verify_the_message_in(String msgElement) {
		String text = messageCenterPage.getText(msgElement);
		if (text != null)
			reportPass("Text: " + text + " is displayed");
		else
			reportFail("Text under " + msgElement + " is unable to retrieve");
	}

	@When("I click on {string} of Read Message page")
	public void i_click_on_button_of_Read_Message_page(String btnName) {
		if (messageCenterPage.clickOnLink(btnName))
			reportPass("Clicked on " + btnName + " button");
		else
			reportFail("Not clicked on " + btnName + " button");
	}

	@Then("I verify the deleted link is not present")
	public void i_verify_the_deleted_link_is_present() {
		if (messageCenterPage.checkLinkDisplay())
			reportPass("Link is not displayed, Deleted successfully");
		else
			reportFail("Link is displayed, Not deleted ");
	}

	@Then("I should see error at {string} as {string}")
	public void i_should_see_error_at_as(String labelName, String errorMessage) {
		if (messageCenterPage.getLabelErrorText(labelName, errorMessage))
			reportPass("Error message at " + labelName + " is displayed as " + errorMessage);
		else
			reportFail("Error message at " + labelName + " is not displayed as " + errorMessage);
	}

	@When("I enter data into {string}")
	public void i_enter_data_into(String textAreaName) {
		if (messageCenterPage.enterRandomText(textAreaName, 10))
			reportPass("Entered the random text at " + textAreaName);
		else
			reportFail("Not Entered the random text at " + textAreaName);
	}

	@When("I cleared data into {string}")
	public void i_cleared_data_into(String textAreaName) {
		if (messageCenterPage.enterRandomText(textAreaName, 0))
			reportPass("Entered the random text at " + textAreaName);
		else
			reportFail("Not Entered the random text at " + textAreaName);
	}

	@When("I should see update message of message center as {string}")
	public void i_should_see_update_message_of_message_center_as(String updatedMessage) {
		updatedMessage = jsonDataParser.getTestDataMap().get(updatedMessage);
		if (messageCenterPage.checkUpdateMessage(updatedMessage))
			reportPass("Message: " + updatedMessage + " is displayed");
		else
			reportFail("Message: " + updatedMessage + " is not displayed ");
	}

	@When("I select first account of dropdown")
	public void i_select_first_account_of_dropdown() {
		if (messageCenterPage.selectAccount())
			reportPass("Selected the first account");
		else
			reportFail("not Selected the first account");
	}

	@When("I click on {string} link of message center in Webcom Options")
	public void i_click_on_link_of_message_center_in_Webcom_Options(String linkName) {
		if (messageCenterPage.clickOnLinksWC(linkName))
			reportPass("Clicked on link: " + linkName);
		else
			reportFail("Not clicked on link: " + linkName);
	}

	@When("I click on {string} link of Agent in message center in Webcom Options")
	public void i_click_on_link_of_Agent_in_message_center_in_Webcom_Options(String linkName) {
		if (messageCenterPage.clickOnLinkGetNext(linkName))
			reportPass("Clicked on link: " + linkName);
		else
			reportFail("Not clicked on link: " + linkName);
	}

	@When("I enter the {string} text in {string} field")
	public void i_enter_the_text_in_field(String data, String fieldName) {
		String txtData = messageCenterPage.enterDataInField(data, fieldName);
		if (txtData != null) {
			reportPass("Input: " + txtData + " is entered at field:" + fieldName);
		} else
			reportFail("Input: " + txtData + " is not entered at field:" + fieldName);
	}

	@When("I click on {string} button of message center of webcom")
	public void i_click_on_button_of_message_center_of_webcom(String btnName) {
		if (messageCenterPage.clickOnLink(btnName))
			reportPass("Clicked on " + btnName + " button");
		else
			reportFail("Not clicked on " + btnName + " button");
	}

	@And("I should see and click on replay message in inbox")
	public void i_should_see_and_click_on_replay_message_in_inbox() {
		if (messageCenterPage.checkInboxSubject())
			reportPass("Inbox with Subject is displayed");
		else
			reportHardFail("Inbox with Subject is not displayed ");
	}

	@When("I select the {string} value from {string} dropdown")
	public void i_select_the_value_from_dropdownx(String data, String fieldName) {
		if (messageCenterPage.selectDataInField(data, fieldName))
			reportPass("Input Value: " + data + " is selected at field:" + fieldName);
		else
			reportFail("Input Value: " + data + " is not selected at field:" + fieldName);
	}

	@And("I should not see replay message in inbox")
	public void i_should_not_see_replay_message_in_inbox() {
		if (!messageCenterPage.checkInboxSubject())
			reportPass("Replay message is not present");
		else
			reportFail("Replay message is present ");
	}

	@When("I verify the {string} button of message center")
	public void i_verify_the_button_of_message_center(String btnName) {
		if (messageCenterPage.verifyButton(btnName))
			reportPass("Verified the " + btnName + " button");
		else
			reportFail(btnName + " button is not present");
	}

	@Then("I verify all subjects are clickable")
	public void i_verify_all_subjects_are_clickable() {
		if (messageCenterPage.verifySubjectClickable())
			reportPass("All subjects are clickable");
		else
			reportFail("All subjects are not clickable");
	}

	@Then("I check for all the blue links only have delete checkbox")
	public void i_check_for_all_the_blue_links_only_have_delete_checkbox() {
		if (messageCenterPage.verifyBlueLinksDeleteCheckbox())
			reportPass("All Blue Links have delete checkbox");
		else
			reportFail("Some of the Blue Links don't have delete checkbox");
	}

	@Then("I verify for the {string} button except payment and transactions message")
	public void i_verify_for_the_button_except_payment_and_transactions_message(String replayButton) {
		if (messageCenterPage.verifyReplayButton(replayButton))
			reportPass(
					"Verified the " + replayButton + " button for the message except payment and transactions message");
		else
			reportHardFail(replayButton
					+ " button is not present for the message which are not related to payment and transactions");
	}

	@Then("I should see the Account number")
	public void I_should_see_the_Account_number() {
		String AccountNumber = messageCenterPage.checkAccountNumber();
		if (AccountNumber != null)
			reportPass("Account number: " + AccountNumber + " is  present");
		else
			reportFail("Account number: " + AccountNumber + "Account number is not present ");
	}

}
