package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.List;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.OnlineBillingWOLPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OnlineBillingWOLSteps extends ObjectBase {

	OnlineBillingWOLPage onlineBillingWOLPage = new OnlineBillingWOLPage();
	public List<String> listLabels = new ArrayList<String>();

	@Then("I check for the labels in {string}")
	public void i_check_for_the_labels_in(String subHeadingName) {
		listLabels.clear();
		listLabels.addAll(jsonDataParser.getTestDataMap().values());
		if (listLabels.size() == onlineBillingWOLPage.checkLabelTitles(subHeadingName, listLabels))
			reportPass("Label: " + listLabels.toString() + " are verified successfully");
		else
			reportHardFail("Labels: " + listLabels.toString() + " are not verified ");
	}

	@And("I check for the {string} subheading")
	public void i_check_for_the_subheading(String subheadingName) {
		if (onlineBillingWOLPage.checkForSubHeading(subheadingName))
			reportPass("Sub-Heading: " + subheadingName + " is displayed");
		else
			reportFail("Sub-Heading: " + subheadingName + " is not displayed");
	}

	@Then("I check the {string} with dropdown")
	public void i_check_the_with_dropdown(String labelName) {
		if (onlineBillingWOLPage.checkForLabel(labelName))
			reportPass("Label: " + labelName + " is displayed with dropdown");
		else
			reportFail("Label: " + labelName + " is not displayed with dropdown");
	}

	@Then("I verify the {string} button of statement")
	public void i_verify_the_button_of_statement(String btnName) {
		if (onlineBillingWOLPage.checkForButton(btnName))
			reportPass("Button: " + btnName + " is displayed ");
		else
			reportFail("Button: " + btnName + " is not displayed ");
	}

	@Then("I should see statement with {string}")
	public void i_should_see_statement_with(String txtHeading) {
		if (onlineBillingWOLPage.checkForDefaultStatement(txtHeading))
			reportPass("Sub-Heading: " + txtHeading + " is displayed ");
		else
			reportFail("Sub-Heading: " + txtHeading + " is not displayed ");
	}

	@Then("I check for below {string} accounts statements")
	public void i_check_for_below_accounts_statements(String accountType) {
		listLabels.clear();
		listLabels.addAll(jsonDataParser.getTestDataMap().values());
		if (listLabels.size() == onlineBillingWOLPage.checkForAccountsStatement(listLabels))
			reportPass("Account Numbers: " + listLabels.toString() + " Statements are displayed ");
		else
			reportFail("Account Numbers: " + listLabels.toString() + " Statements are displayed ");
	}

	@Then("I check for below {string} accounts should not display")
	public void i_check_for_below_accounts_should_not_display(String accountType) {
		listLabels.clear();
		listLabels.addAll(jsonDataParser.getTestDataMap().values());
		if (listLabels.size() == onlineBillingWOLPage.checkForAccountsNotPresent(listLabels))
			reportPass("Account Numbers: " + listLabels.toString() + " are not displayed on Webster Account dropdown");
		else
			reportFail("Account Numbers: " + listLabels.toString() + " are displayed on Webster Account dropdown ");
	}

	@Then("I close the default opened account")
	public void i_close_the_default_opened_account() {
		if (onlineBillingWOLPage.closeDefaultOpenAccount())
			reportPass("closed the defaulty opened account in manage webster accounts page ");
		else
			reportFail("not closed the defaulty opened account in manage webster accounts page ");
	}

	@Then("I click on the account {string} in manage webster page")
	public void i_click_on_the_account_in_manage_webster_page(String acccountNumber) {
		acccountNumber = jsonDataParser.getTestDataMap().get(acccountNumber);
		if (onlineBillingWOLPage.clickOnAccountNumber(acccountNumber))
			reportPass("AccountNumber: " + acccountNumber + " is clicked ");
		else
			reportFail("AccountNumber: " + acccountNumber + " is not clicked ");
	}

	@Then("I check for the message of eDelivery as {string}")
	public void i_check_for_the_message_of_eDelivery_as(String message) {
		message = jsonDataParser.getTestDataMap().get(message);
		if (onlineBillingWOLPage.checkEDeliveryMessage(message))
			reportPass("Message: " + message + " is displayed ");
		else
			reportFail("Message: " + message + " is not displayed ");
	}

	@Then("I check for the nickname textbox and continue button")
	public void i_check_for_the_nickname_textbox_and_continue_button() {
		if (onlineBillingWOLPage.checkNicknameContinueButton())
			reportPass("Nickname input box and Continue button is present ");
		else
			reportFail("Nickname input box and Continue button is not present  ");
	}

	@When("I click on {string} link of Manage webster page")
	public void i_click_on_link_of_Manage_webster_page(String linkName) {
		if (onlineBillingWOLPage.clickOnLink(linkName))
			reportPass("Link: " + linkName + " is clicked ");
		else
			reportFail("Link: " + linkName + " is not clicked ");
	}

	@Then("I should see the error message of eDelivery as {string}")
	public void i_should_see_the_error_message_of_eDelivery_as(String txtErrorMessage) {
		txtErrorMessage = jsonDataParser.getTestDataMap().get(txtErrorMessage);
		if (onlineBillingWOLPage.checkErrorMessage(txtErrorMessage))
			reportPass("Message: " + txtErrorMessage + " is displayed ");
		else
			reportFail("Message: " + txtErrorMessage + " is not displayed ");
	}

	@And("I select the {string} Account option from list")
	public void i_select_the_Account_option_from_list(String account) {
		account = jsonDataParser.getTestDataMap().get(account);
		if (onlineBillingWOLPage.selectAccFromDropdown(account))
			reportPass(account + " is selected from Accounts dropdown");
		else
			reportFail(account + " is not selected from Accounts dropdown");
	}

}
