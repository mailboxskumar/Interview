package com.wb.wol_web.steps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddNewUserPage;
import com.wb.wol_web.pages.CommonPage;
import com.wb.wol_web.pages.EDeliveryPreferencesPage;
import com.wb.wol_web.pages.EducationConsolidationLoanPage;
import com.wb.wol_web.pages.OnlineBillingWebcomPage;
import com.wb.wol_web.pages.ViewDepositDetailsPreferencesPage;
import com.wb.wol_web.pages.WebcomPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationConsolidationLoanSteps extends ObjectBase {

	EducationConsolidationLoanPage educationConsolidationLoanPage = new EducationConsolidationLoanPage();
	EDeliveryPreferencesPage eDeliveryPreferencesPage = new EDeliveryPreferencesPage();
	ViewDepositDetailsPreferencesPage viewDepositDetailsPreferencesPage = new ViewDepositDetailsPreferencesPage();
	OnlineBillingWebcomPage onlineBillingWebcomPage = new OnlineBillingWebcomPage();
	WebcomPage webcomPage = new WebcomPage();

	Map<String, String> lstBalanceInfo = null;
	String userName = "";

	@Then("I read the Balance, Loan, Payment Information details in Account Information Page")
	public void i_read_the_Balance_Loan_Payment_Information_details_in_Account_Information_Page() {
		lstBalanceInfo = educationConsolidationLoanPage.getLabelValues();
		int lstBalanceInfoSize = lstBalanceInfo.size();
		if (lstBalanceInfoSize != 0)
			reportPass("Student Loan Account Information details are captured.");
		else
			reportFail("Unable to capture Student Loan Account Information details.");
	}

	@Then("I click on {string} link under Account Type in {string} Options")
	public void i_click_on_link_under_Account_Type_in_Options(String acctNo, String appName) {
		if (educationConsolidationLoanPage.clickOnStudentLoan(acctNo, appName))
			reportPass("Clicked on Student Loan account: " + acctNo + " in " + appName);
		else
			reportFail("Unable to click on Student Loan account: " + acctNo + " in " + appName);
	}

	@Then("I verify Student Loan Account details in Webcom Options")
	public void i_verify_Student_Loan_Account_details_in_Webcom_Options() {
		Map<String, String> unmatchedValues = educationConsolidationLoanPage.verifyStudentLoanDetails(lstBalanceInfo);
		if (unmatchedValues.size() == 0)
			reportPass("Student Loan Account details in Webcom and WOL are matched.");
		else
			reportFail("Student Loan Account details in Webcom and WOL are not matched.. Unmatched values are: "
					+ unmatchedValues.toString());
	}

	@Then("I select Student Loan Account in Manage Webster Accounts Page in {string}")
	public void i_select_Student_Loan_Account_in_Manage_Webster_Accounts_Page_in(String appName) {
		String loanAccountNumber = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (educationConsolidationLoanPage.clickOnStudentLoan(loanAccountNumber, appName))
			reportPass("Clicked on Student Loan account: " + loanAccountNumber + " in " + appName);
		else
			reportFail("Unable to click on Student Loan account: " + loanAccountNumber + " in " + appName);
	}

	@Given("I verify Enrollement Edelivery error message")
	public void i_verify_Enrollement_Edelivery_error_message() {
		String enrolledInEdeliveryMessage = jsonDataParser.getTestDataMap().get("EnrolledInEdeliveryMessage");
		if (educationConsolidationLoanPage.verifyEnrollementErrorMsg(enrolledInEdeliveryMessage))
			reportPass("Enrollement Edelivery error message is verified: " + enrolledInEdeliveryMessage);
		else
			reportFail("Enrollement Edelivery error message is not verified: " + enrolledInEdeliveryMessage);
	}

	@Given("I verify the {string} field under Student Loan section")
	public void i_verify_the_field_under_Student_Loan_section(String fieldName) {
		if (educationConsolidationLoanPage.verifyStudentLoanLabels(fieldName))
			reportPass("Field: " + fieldName + " is present under Loan section.");
		else
			reportFail("Field: " + fieldName + " is not present under Loan section.");
	}

	@Given("I verify the {string} button under Student Loan section")
	public void i_verify_the_button_under_Student_Loan_section(String btnName) {
		if (educationConsolidationLoanPage.verifyStudentLoanLabels(btnName))
			reportPass("Button: " + btnName + " is present under Loan section.");
		else
			reportFail("Button: " + btnName + " is not present under Loan section.");
	}

	@Given("I verify the {string} header under Student Loan section")
	public void i_verify_the_header_under_Student_Loan_section(String headerName) {
		if (educationConsolidationLoanPage.verifyStudentLoanLabels(headerName))
			reportPass("Header: " + headerName + " is present under Loan section.");
		else
			reportFail("Header: " + headerName + " is not present under Loan section.");
	}

	@Given("I verify the {string} link under Student Loan section")
	public void i_verify_the_link_under_Student_Loan_section(String linkName) {
		if (educationConsolidationLoanPage.verifyStudentLoanLabels(linkName))
			reportPass("Link: " + linkName + " is present under Loan section.");
		else
			reportFail("Link: " + linkName + " is not present under Loan section.");
	}

	@Given("I click on {string} link under student loan details")
	public void i_click_on_link_under_student_loan_details(String removeAccountLink) {
		if (educationConsolidationLoanPage.clickOnRemoveAcctLink(removeAccountLink))
			reportPass("Remove account link is clicked");
		else
			reportFail("Remove account link is not clicked");
	}

	@Then("I click on {string} section in Address and\\/or Phone Number Change page")
	public void i_click_on_section_in_Address_and_or_Phone_Number_Change_page(String sectionName) {
		if (educationConsolidationLoanPage.clickOnAddressSection(sectionName))
			reportPass("Section is clicked: " + sectionName);
		else
			reportFail("Section is not clicked: " + sectionName);
	}

	@Given("I verify Student Loan Account in Accounts section in {string} section")
	public void i_verify_Student_Loan_Account_in_Accounts_section_in_section(String sectionName) {
		String loanAccountNumber = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (educationConsolidationLoanPage.verifyAcctInAddressSection(loanAccountNumber, sectionName))
			reportPass("Account is verified: " + loanAccountNumber + " under section: " + sectionName);
		else
			reportFail("Account is verified: " + loanAccountNumber + " under section: " + sectionName);
	}

	@Then("I should be in the {string} Page")
	public void i_should_be_in_the_Page(String pageName) {
		if (educationConsolidationLoanPage.verifyPageName(pageName))
			reportPass("Navigated to Page: " + pageName);
		else
			reportFail("Page not navigated to: " + pageName);
	}

	@Then("I verify {string}, {string}, {string} and {string} header fields in Webcom Options")
	public void i_verify_and_header_fields_in_Webcom_Options(String acctNumber, String balanceInfo, String loanInfo,
			String paymentInfo) {
		String headerNames[] = { acctNumber, balanceInfo, loanInfo, paymentInfo };
		List<String> lstHeaderNames = new ArrayList<String>();
		lstHeaderNames.addAll(Arrays.asList(headerNames));
		String txtHeader = "Header";
		List<String> lstHeaderNamesNotMatched = educationConsolidationLoanPage.verifyHeaderInformation(lstHeaderNames,
				txtHeader);
		if (lstHeaderNamesNotMatched.size() == 0)
			reportPass(
					"All header fields: Account Number, Balance Information, Loan Information and Payment Information are verified.");
		else
			reportFail("Header Fields not matched are: " + lstHeaderNamesNotMatched.toString());
	}

	@Then("Verify the {string}, {string} fields in the {string} header block")
	public void verify_the_fields_in_the_header_block(String labelLoanPrincipalBalance, String labelDueNow,
			String blockName) {
		if (educationConsolidationLoanPage.verifyLabelsInBlock(labelLoanPrincipalBalance, labelDueNow, blockName))
			reportPass("All Header and Header fields are matched:" + blockName + ", " + labelLoanPrincipalBalance + ", "
					+ labelDueNow);
		else
			reportFail("Header/ Header Fields are not matched.");
	}

	@Then("Verify the {string}, {string}, {string}, {string}, {string}, {string} fields under the {string} block")
	public void verify_the_fields_under_the_block(String labelConsumerLoan, String labelPrincipalBalance,
			String labelAmountDue, String labelPaymentDueDate, String labelLastTransaction, String labelAccountDetails,
			String labelLoanAccounts) {
		String labelNames[] = { labelConsumerLoan, labelPrincipalBalance, labelAmountDue, labelPaymentDueDate,
				labelLastTransaction, labelAccountDetails };
		List<String> lstBodyFields = new ArrayList<String>();
		lstBodyFields.addAll(Arrays.asList(labelNames));
		List<String> lstBodyFieldsMatch = educationConsolidationLoanPage.verifyLabelsUnderBlock(lstBodyFields);
		if (lstBodyFieldsMatch.size() == 0)
			reportPass("All fields under: " + labelLoanAccounts + " are matched.");
		else
			reportFail("Fields under: " + labelLoanAccounts + " are not matched:" + lstBodyFieldsMatch.toString());
	}

	@Given("I verify {string} label has value {string}")
	public void i_verify_label_has_value(String labelName, String value) {
		String labelNameValue[] = { labelName, value };
		List<String> lstLabelValueName = new ArrayList<String>();
		lstLabelValueName.addAll(Arrays.asList(labelNameValue));
		String txtLabelValue = "Label Value";
		List<String> lstLabelValueNameNotMatched = educationConsolidationLoanPage
				.verifyHeaderInformation(lstLabelValueName, txtLabelValue);
		if (lstLabelValueNameNotMatched.size() == 0)
			reportPass("Label: " + labelName + ", and Value: " + value + " is present");
		else
			reportFail("Label/ Value is not verified: " + lstLabelValueNameNotMatched.toString());
	}

	@Then("I Select Student Loan Account in Account dropdown in {string} Page")
	public void i_Select_Student_Loan_Account_in_Account_dropdown_in_Page(String pageName) {
		String loanAccountNumber = jsonDataParser.getTestDataMap().get("Loan Account Number");
		if (educationConsolidationLoanPage.selectFromDropdown(loanAccountNumber, pageName))
			reportPass("Account is selected from dropdown: " + loanAccountNumber + " in page: " + pageName);
		else
			reportFail("Account is not selected from dropdown: " + loanAccountNumber + " in page: " + pageName);
	}

	@Given("I verify Update Edelivery error message")
	public void i_verify_Update_Edelivery_error_message() {
		String updateEdeliveryErrorMessage = jsonDataParser.getTestDataMap().get("UpdateEdeliveryErrorMessage");
		if (educationConsolidationLoanPage.verifyErrorMsg(updateEdeliveryErrorMessage))
			reportPass("Update Edelivery error message is verified: " + updateEdeliveryErrorMessage);
		else
			reportFail("Update Edelivery error message is not verified: " + updateEdeliveryErrorMessage);
	}

	@Then("I check the Student Loan Refinance Fixed Rate")
	public void i_check_the_Student_Loan_Refinance_Fixed_Rate() {
		if (educationConsolidationLoanPage.clickOnChkBoxStudentLoan())
			reportPass("Checkbox of Student Loan is checked.");
		else
			reportFail("Checkbox of Student Loan is not checked.");
	}

	@Then("I Select Student Loan Account in Account dropdown in Account Information page")
	public void i_Select_Student_Loan_Account_in_Account_dropdown_in_Account_Information_page() {
		String studentLoanAccount = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (educationConsolidationLoanPage.selectStudentLoanAccount(studentLoanAccount))
			reportPass("Account is selected from dropdown: " + studentLoanAccount + " in Account Information page: ");
		else
			reportFail("Account is not selected from dropdown: " + studentLoanAccount + " in Account Information page");
	}

	@Then("I select Student Loan Account from dropdown in {string} page in Webcom Options")
	public void i_select_Student_Loan_Account_from_dropdown_in_page_in_Webcom_Options(String pageName) {
		String studentLoanAccount = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (educationConsolidationLoanPage.selectFromDropdown(studentLoanAccount, pageName))
			reportPass("Account is selected from dropdown: " + studentLoanAccount + " in page: " + pageName);
		else
			reportFail("Account is not selected from dropdown: " + studentLoanAccount + " in page: " + pageName);
	}

	@Given("I verify the Student Loan Account statement")
	public void i_verify_the_Student_Loan_Account_statement() {
		String studentLoanAccount = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (educationConsolidationLoanPage.verifyStudentLoanStatement(studentLoanAccount))
			reportPass("Student Loan Account statement: " + studentLoanAccount + " is verified.");
		else
			reportFail("Student Loan Account statement: " + studentLoanAccount + " is not verified.");
	}

	@Given("I click on {string} for the Student Loan Account number in eDelivery Account field")
	public void i_click_on_for_the_Student_Loan_Account_number_in_eDelivery_Account_field(String fieldName) {
		String loanAccountNumber = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (educationConsolidationLoanPage.clickOnCheckbox(fieldName, loanAccountNumber))
			reportPass("Student Loan Account: " + loanAccountNumber + " , field: " + fieldName + " is clicked");
		else
			reportFail("Student Loan Account: " + loanAccountNumber + " , field: " + fieldName + " is not clicked");
	}

	@Then("I verify status of {string} for Student Loan Account number in eDelivery Account field is checked")
	public void i_verify_status_of_for_Student_Loan_Account_number_in_eDelivery_Account_field_is_checked(
			String fieldName) {
		String loanAccountNumber = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (educationConsolidationLoanPage.verifyCheckboxValue(fieldName, loanAccountNumber))
			reportPass("Student Loan Account: " + loanAccountNumber + " , field: " + fieldName + " is checked");
		else
			reportFail("Student Loan Account: " + loanAccountNumber + " , field: " + fieldName + " is not checked");
	}

	@Given("I verify Remove Account error message")
	public void i_verify_Remove_Account_error_message() {
		String removeAccountErrorMessage = jsonDataParser.getTestDataMap().get("RemoveAccountErrorMessage");
		if (educationConsolidationLoanPage.verifyErrorMsg(removeAccountErrorMessage))
			reportPass("Update Edelivery error message is verified: " + removeAccountErrorMessage);
		else
			reportFail("Update Edelivery error message is not verified: " + removeAccountErrorMessage);
	}

	@Then("I verify enroll update message")
	public void i_verify_enroll_update_message() {
		String enrollStmtEDeliveryMessage = jsonDataParser.getTestDataMap().get("EnrollStmtEDeliveryMessage");
		if (eDeliveryPreferencesPage.checkForMessageLightbox(enrollStmtEDeliveryMessage))
			reportPass("Message :" + enrollStmtEDeliveryMessage + " is displayed");
		else
			reportFail("Message :" + enrollStmtEDeliveryMessage + " is not displayed");
	}

	@Then("I verify the remove Statement eDelivery message")
	public void i_verify_the_remove_Statement_eDelivery_message() {
		String RemoveStmtEDeliveryMessage = jsonDataParser.getTestDataMap().get("RemoveStmtEDeliveryMessage");
		if (eDeliveryPreferencesPage.checkForMessageLightbox(RemoveStmtEDeliveryMessage))
			reportPass("Message :" + RemoveStmtEDeliveryMessage + " is displayed");
		else
			reportFail("Message :" + RemoveStmtEDeliveryMessage + " is not displayed");
	}

	@Then("I enter Student Loan Account Number in Account Number field in Webcom Options")
	public void i_enter_Student_Loan_Account_Number_in_Account_Number_field_in_Webcom_Options() {
		String studentLoanAccountNumber = jsonDataParser.getTestDataMap().get("StudentLoanAccountNumber");
		if (educationConsolidationLoanPage.enterStudentLoanAcctNumber(studentLoanAccountNumber))
			reportPass("Student Loan Account Number is entered as: " + studentLoanAccountNumber);
		else
			reportFail("Student Loan Account Number not entered: " + studentLoanAccountNumber);
	}

	@Then("I verify the Student Loan Account is {string}")
	public void i_verify_the_Student_Loan_Account_is(String accCheckBoxSts) {
		String edeliveryStudentLoanAccountNumber = jsonDataParser.getTestDataMap()
				.get("EDeliveryStudentLoanAccountNumber");
		if (eDeliveryPreferencesPage.verifyAccountCheckBoxStatus(edeliveryStudentLoanAccountNumber, accCheckBoxSts))
			reportPass(edeliveryStudentLoanAccountNumber + " Account number is " + accCheckBoxSts);
		else
			reportFail(edeliveryStudentLoanAccountNumber + " Account number is not " + accCheckBoxSts);
	}

	@Then("I verify the eDelivery Preferences Confirmation message")
	public void i_verify_the_eDelivery_Preferences_Confirmation_message() {
		String edeliveryPreferConfMessage = jsonDataParser.getTestDataMap().get("EDeliveryPreferConfMessage");
		if (eDeliveryPreferencesPage.verifyeDeliveryPrefConfMsg(edeliveryPreferConfMessage))
			reportPass(edeliveryPreferConfMessage + " message is displayed");
		else
			reportFail(edeliveryPreferConfMessage + " message is not displayed");
	}

	@Then("I verify the Enroll Account number format")
	public void i_verify_the_Enroll_Account_number_format() {
		String enrollFormat = jsonDataParser.getTestDataMap().get("EnrollFormat");
		if (viewDepositDetailsPreferencesPage.verifyEnrollAccNumber(enrollFormat))
			reportPass(enrollFormat + " Enroll Account is displayed");
		else
			reportHardFail(enrollFormat + " Enroll Account is not displayed");
	}

	@Then("I verify the Notifications delivered to text is displayed")
	public void i_verify_the_Notifications_delivered_to_text_is_displayed() {
		String notificationDeliveredTo = jsonDataParser.getTestDataMap().get("NotificationDeliveredTo");
		if (eDeliveryPreferencesPage.verifyNotificationsDeliveredTo(notificationDeliveredTo))
			reportPass(notificationDeliveredTo + " text is displayed");
		else
			reportFail(notificationDeliveredTo + " text is not displayed");
	}

	@Then("I verify the Notifications Delivered Email address")
	public void i_verify_the_Notifications_Delivered_Email_address() {
		String notificationDeliveredEmailAddress = jsonDataParser.getTestDataMap()
				.get("NotificationDeliveredEmailAddress");
		if (eDeliveryPreferencesPage.verifyNotificationsDeliveredEmailId(notificationDeliveredEmailAddress))
			reportPass(notificationDeliveredEmailAddress + " Email id is displayed");
		else
			reportFail(notificationDeliveredEmailAddress + " Email id is not displayed");
	}

	@Then("I verify the fields {string}, {string}, {string}, {string}, {string}, {string}, {string}, {string}, {string} in Customer Statement List page")
	public void i_verify_the_fields_in_Customer_Statement_List_page(String customerName, String acctNo,
			String eDelivery, String irsTaxId, String printOptions, String applCode, String cycleDate,
			String viewStatement, String print) {
		String labelName[] = { customerName, acctNo, eDelivery, irsTaxId, printOptions, applCode, cycleDate,
				viewStatement, print };
		List<String> lstLabelName = new ArrayList<String>();
		lstLabelName.addAll(Arrays.asList(labelName));
		String txtLabelValue = "Customer Statement List";
		List<String> lstLabelValueNotMatched = educationConsolidationLoanPage.verifyHeaderInformation(lstLabelName,
				txtLabelValue);
		if (lstLabelValueNotMatched.size() == 0)
			reportPass("All labels are present for Student Loan Account: " + lstLabelName.toString()
					+ " in Customer Statement List page");
		else
			reportFail("Student Loan Account labels are not verified in Customer Statement List page: "
					+ lstLabelValueNotMatched.toString());

	}

	@Then("I verify the eDelivery field value as {string}")
	public void i_verify_the_eDelivery_field_value_as(String value) {
		if (educationConsolidationLoanPage.verifyLabelValue(value))
			reportPass("eDelivery field is verified with value: " + value);
		else
			reportFail("eDelivery field is not verified with value: " + value);
	}

	@Then("I navigate to main window")
	public void i_navigate_to_main_window() {
		if (educationConsolidationLoanPage.navigateToMainWindow())
			reportPass("Navigated to main window.");
		else
			reportFail("Not navigated to main window.");
	}

	@Given("I click on {string} for Student Loan Account number in Remove Account field")
	public void i_click_on_for_Student_Loan_Account_number_in_Remove_Account_field(String fieldName) {
		String loanAccountNumber = jsonDataParser.getTestDataMap().get("LoanAccountNumber");
		if (onlineBillingWebcomPage.clickOnCheckbox(fieldName, loanAccountNumber))
			reportPass("Account Number: " + loanAccountNumber + " corresponding remove account field is " + fieldName);
		else
			reportHardFail("Account Number: " + loanAccountNumber + "  corresponding remove account field  is not "
					+ fieldName);
	}

	@When("I search customer by field name Customer ID in Manual Add Account page")
	public void i_search_customer_by_field_name_Customer_ID_in_Manual_Add_Account_page() {
		String customerID = jsonDataParser.getTestDataMap().get("CustomerID");
		if (educationConsolidationLoanPage.enterCustomerId(customerID))

			reportPass("Customer ID: " + customerID + " entered in Customer field");
		else
			reportHardFail("Customer ID: " + customerID + " not entered in Customer field");
	}

	@Then("I click on Get Customer button in Manual Add Account page")
	public void i_click_on_Get_Customer_button_in_Manual_Add_Account_page() {
		if (educationConsolidationLoanPage.clickOnCustomerButton())
			reportPass("Able to click on Get Customer button");
		else
			reportHardFail("Unable to click on Get Customer button");
	}

	@Then("I select the Product Category in Manual Add Account Page")
	public void i_select_the_Product_Category_in_Manual_Add_Account_Page() {
		String productCategory = jsonDataParser.getTestDataMap().get("Product Category");
		String fieldName = "Product Category";
		if (educationConsolidationLoanPage.enterStudentLoanDetails(productCategory, fieldName))
			reportPass("Selected Product Category: " + productCategory + " in Manual Add Account Page");
		else
			reportHardFail("Unable to enter Product Category in Manual Add Account Page");
	}

	@Then("I select the Products in Manual Add Account Page")
	public void i_select_the_Products_in_Manual_Add_Account_Page() {
		String products = jsonDataParser.getTestDataMap().get("Products");
		String fieldName = "Products";
		if (educationConsolidationLoanPage.enterStudentLoanDetails(products, fieldName))
			reportPass("Selected Products: " + products + " in Manual Add Account Page");
		else
			reportHardFail("Unable to enter Product Category in Manual Add Account Page");
	}

	@Then("I enter the Account Number in Manual Add Account Page")
	public void i_enter_the_Account_Number_in_Manual_Add_Account_Page() {
		String accountNumber = jsonDataParser.getTestDataMap().get("Account Number");
		String fieldName = "Account Number";
		if (educationConsolidationLoanPage.enterStudentLoanDetails(accountNumber, fieldName))
			reportPass("Entered Account Number: " + accountNumber + " in Manual Add Account Page");
		else
			reportHardFail("Unable to enter Account Number in Manual Add Account Page");
	}

	@Then("I enter the Nick Name in Manual Add Account Page")
	public void i_enter_the_Nick_Name_in_Manual_Add_Account_Page() {
		String nickName = jsonDataParser.getTestDataMap().get("Nick Name");
		String fieldName = "Nick Name";
		if (educationConsolidationLoanPage.enterStudentLoanDetails(nickName, fieldName))
			reportPass("Entered Nick Name: " + nickName + " in Manual Add Account Page");
		else
			reportHardFail("Unable to enter Nick Name in Manual Add Account Page");
	}

	@Then("I click on {string} button in Manual Add Account page")
	public void i_click_on_button_in_Manual_Add_Account_page(String string) {
		if (educationConsolidationLoanPage.clickOnAddAccountButton())
			reportPass("Clicked on Add Account button in Manual Add Account page");
		else
			reportHardFail("Unable to click on Add Account button in Manual Add Account page");
	}

	@Then("I verify the Student Loan Account message")
	public void i_verify_the_Student_Loan_Account_message() {
		String acctAdditionMsg = jsonDataParser.getTestDataMap().get("Account Addition Message");
		if (educationConsolidationLoanPage.verifyStudentLoanAccountAddMessage(acctAdditionMsg))
			reportPass("Student Loan Account message: " + acctAdditionMsg + " in Manual Add Account page");
		else
			reportHardFail("Unable to verify Student Loan Account message: " + acctAdditionMsg
					+ " in Manual Add Account page");
	}

	@Then("I get the username added to new user")
	public void i_get_the_username_added_to_new_user() {
		String addedUser = new AddNewUserPage().addNewUser;
		if (addedUser.length() == 9)
			reportPass("Added User Name: " + addedUser + " retrieved successfully");
		else
			reportHardFail("Unable to retrieve Added User Name");
	}

	@When("I search customer by field name {string} with user name of Manual Add Account page")
	public void i_search_customer_by_field_name_with_user_name_of_Manual_Add_Account_page(String searchBy) {
		try {
			String searchValue = getValueFromRuntimeDataMap("addNewWOLUser");
			if (searchValue.equalsIgnoreCase("enrollment"))
				searchValue = getValueFromRuntimeDataMap("enrollmentUser");
			webcomPage.searchCustomer(searchBy, searchValue);
			reportPass("Searched customer: {" + searchValue + "} details successfully");
		} catch (Exception e) {
			reportHardFail("Failed to Retrieve Customer Details");
		}
	}

	@Then("I verify Statement eDelivery field as {string}")
	public void i_verify_Statement_eDelivery_field_as(String value) {
		if (educationConsolidationLoanPage.verifyValueOfStatementeDelivery(value))
			reportPass("Statement EDelivery value is: " + value + " verified successfully");
		else
			reportFail("Unable to verify value of Statement eDelivery");
	}

	@Then("I click on {string} for the Student Loan Account number in eDelivery page")
	public void i_click_on_for_the_Student_Loan_Account_number_in_eDelivery_page(String value) {
		if (educationConsolidationLoanPage.clickOnStudentLoanAccountIneDelivery(value))
			reportPass("Clicked on Checkbox of Student Loan Account successfully");
		else
			reportFail("Unable to click on Checkbox of Student Loan Account");
	}

	@Then("I verify Update Account error message")
	public void i_verify_Update_Account_error_message() {
		String updateAcctErrorMsg = jsonDataParser.getTestDataMap().get("UpdateAccountErrorMessage");
		if (educationConsolidationLoanPage.verifyStudentLoanAccountUpdateMessage(updateAcctErrorMsg))
			reportPass("Student Loan Account message: " + updateAcctErrorMsg + " in Manual Add Account page");
		else
			reportHardFail("Unable to verify Student Loan Update Account message: " + updateAcctErrorMsg);
	}

	@When("I Enter username of Manual Add Account Page")
	public void i_Enter_username_of_Manual_Add_Account_Page() {
		String userName = getValueFromRuntimeDataMap("addNewWOLUser");
		boolean flag = new CommonPage().enterUserName(userName);
		if (flag)
			reportPass("Entered the username {" + userName + "}");
		else
			reportHardFail(
					"Incorrect username entered, Terminating execution. Please verify the username and re-execute the script.");
	}
}