package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddAddressOrPhonePage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddAddressOrPhoneSteps extends ObjectBase {

	AddAddressOrPhonePage addAddressOrPhonePage = new AddAddressOrPhonePage();

	@Then("^I click on Phone Numbers heading and enter the new values$")
	public void i_click_on_phone_number_heading_enter_values() throws Exception {

		if (!addAddressOrPhonePage.clickOnEditPhoneTitle())
			reportFail("Failed to click on the edit phone number title");
		try {
			addAddressOrPhonePage.enterNewPhoneNumber();
		} catch (Exception e) {
			reportFail("Failed to enter new phone number");
		}
	}

	@When("^I click on \"([^\"]*)\" button in Address Change functionality$")
	public void i_click_on_the_button(String buttonName) {

		if (!addAddressOrPhonePage.clickOnTheButton(buttonName)) {
			reportFail("Failed to click on the button " + buttonName + " in address change functionality");

		}
	}

	@Then("^I should be in Confirmation of Address Change page in update phone and address functionality$")
	public void i_shoud_be_in_confirmation_page() {
		if (addAddressOrPhonePage.checkForConfirmationPage("Confirmation of Address Change")) {
			reportPass("Found the confirmation page");
		} else {
			reportHardFail("Could not reach confirmation page");
		}
	}
}
