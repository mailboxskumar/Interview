package com.wb.wol_web.steps;

import java.util.HashMap;
import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AccountSummaryPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AccountSummarySteps extends ObjectBase {

	AccountSummaryPage accountSummaryPage = new AccountSummaryPage();

	@Then("^I check for the \"([^\"]*)\" heading and their respective balances for \"([^\"]*)\" user with \"([^\"]*)\" balance$")
	public void i_check_for_the_headings_and_their_balances(String heading, String userType, String balance) {
		if (accountSummaryPage.checkForTheAccountSummaryHeading(heading))
			reportPass(heading + "heading is found in the summary page");
		else
			reportFail(heading + "heading is not found in the summary page");
		if (!balance.equalsIgnoreCase("NO")) {
			if (accountSummaryPage.checkTheOverAllBalancesForEachSection(userType, heading))
				reportPass("Overall balances for the section " + heading + " are displayed correct");
			else
				reportFail("Overall balances for the section " + heading + " are not displayed correct");
		}
	}

	@Then("^I check all the accounts and their balances under Checking and Savings Accounts section for \"([^\"]*)\" user$")
	public void i_check_all_theaccounts_under_deposit_section(String accountType) {
		boolean status = true;
		List<HashMap<String, String>> loanAccDetails = accountSummaryPage.checkTheDepsoitAccounts(accountType);
		for (HashMap<String, String> eachAcc : loanAccDetails) {
			for (String eachkey : eachAcc.keySet()) {
				status = true;
				if (eachAcc.get(eachkey).contains("incorrect value")) {
					reportFail("Deposit Account details are dispalyed incorrect " + eachAcc.toString());
					status = false;
					break;
				}
			}
			if (status) {
				reportPass("Deposit Account details are displayed correct " + eachAcc.toString());
			}
		}
	}

	@Then("^I check all the accounts and their balances under Loan Accounts section for \"([^\"]*)\" user$")
	public void i_check_all_theaccounts_under_loan_section(String accountType) {
		boolean status = true;
		List<HashMap<String, String>> loanAccDetails = accountSummaryPage.checkTheLoanAccounts(accountType);
		for (HashMap<String, String> eachAcc : loanAccDetails) {
			for (String eachkey : eachAcc.keySet()) {
				status = true;
				if (eachAcc.get(eachkey).contains("incorrect value")) {
					reportFail("Loan Account details are dispalyed incorrect " + eachAcc.toString());
					status = false;
					break;
				}
			}
			if (status) {
				reportPass("Loan Account details are displayed correct " + eachAcc.toString());
			}

		}
	}

	@Then("^I check all the accounts and their balances under Credit Card Accounts section for \"([^\"]*)\" user$")
	public void i_check_all_theaccounts_under_creditcards_section(String accountType) {
		boolean status = true;
		List<HashMap<String, String>> loanAccDetails = accountSummaryPage.checkTheCreditCardAccounts(accountType);
		for (HashMap<String, String> eachAcc : loanAccDetails) {
			for (String eachkey : eachAcc.keySet()) {
				status = true;
				if (eachAcc.get(eachkey).contains("incorrect value")) {
					reportFail("Credit card Account details are dispalyed incorrect " + eachAcc.toString());
					status = false;
					break;
				}
			}
			if (status) {
				reportPass("Credit card Account details are displayed correct " + eachAcc.toString());
			}
		}
	}

	@Then("^I check that there are no accounts under \"([^\"]*)\" section$")
	public void i_check_that_no_accounts_under_each_section(String section) {
		if (accountSummaryPage.checkNoAccountsUnderEachSection(section))
			reportPass("No Accounts are present under the section  " + section);
		else
			reportFail("Accounts are present under the section  " + section);
	}

	@When("I click on + button next to {string} section")
	public void i_click_on_button_next_to_section(String sectionName) {
		try {
			accountSummaryPage.clickOnAddAccountButton(sectionName);
			reportPass("Clicked on the + button next to " + sectionName);
		} catch (Exception e) {
			reportHardFail("Failed to click on the + button next to " + sectionName);
		}
	}

	@Then("I should got to {string} page from summary page")
	public void i_should_got_to_tranaction_history_page_from_summary_page(String pageHeading) {
		if (accountSummaryPage.checkForTheDestPageOnClickingLinksFromFS(pageHeading))
			reportPass("Reached " + pageHeading + " page");
		else
			reportFail("Failed to reach " + pageHeading + " page");
	}

	@When("^I click on any loan account$")
	public void i_click_on_loan_account() {
		try {
			accountSummaryPage.clickOnLoanAccount();
		} catch (Exception e) {
			reportFail("Exception in clicking loan acount");
		}
	}

	@When("I click on any {string} account")
	public void i_click_on_cd_account(String accountType) {
		if (accountSummaryPage.clickOnDepositAccount(accountType))
			reportPass("Clicked on the " + AccountSummaryPage.accName + "account ");
		else
			reportFail("Failed to click on the " + AccountSummaryPage.accName + "  account ");
	}

	@Then("I verify the Emergency message title")
	public void i_verify_the_Emergency_message_title() {
		if (accountSummaryPage.verifyEmergencyMsgTitle())
			reportPass("Message title {" + (jsonDataParser.getTestDataMap().get("EmergencyMessageTitle")) + "} is displayed");
		else
			reportFail("Message title {" + (jsonDataParser.getTestDataMap().get("EmergencyMessageTitle")) + "} is not displayed");
	}

	@Then("I verify the Emergency message body")
	public void i_verify_the_Emergency_message_body() {
		if (accountSummaryPage.verifyEmergencyMsgTitle())
			reportPass("Message body {" + (jsonDataParser.getTestDataMap().get("EmergencyMessageBody")) + "} is displayed");
		else
			reportFail("Message body {" + (jsonDataParser.getTestDataMap().get("EmergencyMessageBody")) + "} is not displayed");
	}

	@When("I click on any Credit Card account")
	public void i_click_on_any_Credit_Card_account() {
		if (accountSummaryPage.clickOnCreditCardAccount())
			reportPass("Clicked on the Credit card account ");
		else
			reportFail("Exception in clicking credit card acount");
	}

	@When("I click on Credit Card account details link")
	public void i_click_on_Credit_Card_account_details_link() {
		if (accountSummaryPage.clickOnCreditCardAccountDetails())
			reportPass("Clicked on the Credit card account details link ");
		else
			reportFail("Exception in clicking credit card acount details link");
	}

	@Then("I Verify the {string} page is displayed")
	public void i_Verify_the_page_is_displayed(String pageTitle) {
		if (accountSummaryPage.verifyTemporarilyUnavailablePage(pageTitle))
			reportPass("{ " + pageTitle + "} Page is displayed ");
		else
			reportFail("{ " + pageTitle + "} Page is not displayed ");
	}

	@Then("I verify the {string} field is displayed")
	public void i_verify_the_field_is_displayed(String accNumber) {
		if (accountSummaryPage.verifyAccountNumberField(accNumber))
			reportPass("{ " + accNumber + "} field is displayed ");
		else
			reportFail("{ " + accNumber + "} field is not displayed ");
	}

	@Then("I verify the {string} field should displayed")
	public void i_verify_the_field_should_displayed(String accType) {
		if (accountSummaryPage.verifyAccountTypeField(accType))
			reportPass("{ " + accType + "} field is displayed ");
		else
			reportFail("{ " + accType + "} field is not displayed ");
	}

	@Then("I verify the {string} should displayed")
	public void i_verify_the_should_displayed(String accNickName) {
		if (accountSummaryPage.verifyNickNameField(accNickName))
			reportPass("{" + accNickName + "} field is displayed ");
		else
			reportFail("{" + accNickName + "} field is not displayed ");
	}

	@Then("I verify the account details link for any {string} account")
	public void i_verify_the_account_details_link_for_any_account(String accountType) {
		if (accountSummaryPage.verifyAccountDetailsLink(accountType))
			reportPass(accountType + " account details link displayed");
		else
			reportFail("Unable to display the " + accountType + "  account details link ");
	}

	@Then("I verify the no transaction message as {string}")
	public void i_verify_the_no_transaction_message_as(String msg) {
		msg=jsonDataParser.getTestDataMap().get(msg);
		if (accountSummaryPage.verifyTransactionErrMsg(msg))
			reportPass("{ " + msg + "}  message is displayed ");
		else
			reportFail("{ " + msg + "} message is not displayed ");
	}

	@Then("I verify the Available balance and Current balance both amounts are different for CD accounts")
	public void i_verify_the_Available_balance_and_Current_balance_both_amounts_are_different_for_CD_accounts() {
		if (accountSummaryPage.verifyCDAccBalances())
			reportPass("Available balance and Current balance amounts are different for CD accounts");
		else
			reportFail("Available balance and Current balance amounts are equal for CD accounts");
	}

	@Then("I verify the Principal balance and Amount due both amounts are different for Loan accounts")
	public void i_verify_the_Principal_balance_and_Amount_due_both_amounts_are_different_for_Loan_accounts() {
		if (accountSummaryPage.verifyLoanAccBalances())
			reportPass("Principal balance and Amount due amounts are different for Loan accounts");
		else
			reportFail("Principal balance and Amount due amounts are equal for Loan accounts");
	}

	@Then("I verify the Balance and Credit limit both amounts are different for Credit Card accounts")
	public void i_verify_the_Balance_and_Credit_limit_both_amounts_are_different_for_Credit_Card_accounts() {
		if (accountSummaryPage.verifyCreditCardAccBalances())
			reportPass("Balance and Credit Limit amounts are different for Credit Card accounts");
		else
			reportFail("Balance and Credit Limit amounts are equal for Credit Card accounts");
	}

	@Then("I click on {string} tab and verify the Accounts related features should display")
	public void i_click_on_tab_and_verify_the_Accounts_related_features_should_display(String accounts) {
		if (accountSummaryPage.verifyMenuLinks(accounts, jsonDataParser.getTestDataMap()))
			reportPass("Account links : {" + jsonDataParser.getTestDataMap().get("Accounts Links")
					+ "} is successfully displayed");
		else
			reportFail(
					"Account links : {" + jsonDataParser.getTestDataMap().get("Accounts Links") + "} is not displayed");
	}

	@Then("I click on {string} tab and verify the Transfers related features should display")
	public void i_click_on_tab_and_verify_the_Transfers_related_features_should_display(String transfers) {
		if (accountSummaryPage.verifyMenuLinks(transfers, jsonDataParser.getTestDataMap()))
			reportPass("Transfer links : {" + jsonDataParser.getTestDataMap().get("Transfers Links")
					+ "} is successfully displayed");
		else
			reportFail("Transfer links : {" + jsonDataParser.getTestDataMap().get("Transfers Links")
					+ "} is not displayed");
	}

	@Then("I click on {string} tab and verify the Payments related features should display")
	public void i_click_on_tab_and_verify_the_Payments_related_features_should_display(String payments) {
		if (accountSummaryPage.verifyMenuLinks(payments, jsonDataParser.getTestDataMap()))
			reportPass("Payments links : {" + jsonDataParser.getTestDataMap().get("Payments Links")
					+ "} is successfully displayed");
		else
			reportFail("Payments links : {" + jsonDataParser.getTestDataMap().get("Payments Links")
					+ "} is not displayed");
	}

	@Then("I click on {string} tab and verify the Services related features should display")
	public void i_click_on_tab_and_verify_the_Services_related_features_should_display(String services) {
		if (accountSummaryPage.verifyMenuLinks(services, jsonDataParser.getTestDataMap()))
			reportPass("Services links : {" + jsonDataParser.getTestDataMap().get("Services Links")
					+ "} is successfully displayed");
		else
			reportFail("Services links : {" + jsonDataParser.getTestDataMap().get("Services Links")
					+ "} is not displayed");

	}

	@Then("I click on {string} tab and verify the Support related features should display")
	public void i_click_on_tab_and_verify_the_Support_related_features_should_display(String support) {
		if (accountSummaryPage.verifyMenuLinks(support, jsonDataParser.getTestDataMap()))
			reportPass("Support links : {" + jsonDataParser.getTestDataMap().get("Support Links")
					+ "} is successfully displayed");
		else
			reportFail(
					"Support links : {" + jsonDataParser.getTestDataMap().get("Support Links") + "} is not displayed");
	}

	@Then("I verify the {string} loan accounts should display in proper order")
	public void i_verify_the_loan_accounts_should_display_in_proper_order(String user) {
		if (accountSummaryPage.verifyLoanAccountsOrder(user))
			reportPass(user + " Loan Accounts are displayed in Proper Order");
		else
			reportFail(user + " Loan Accounts are not displayed in Proper Order");
	}

	@Then("I verify the {string} Deposit accounts should display in proper order")
	public void i_verify_the_Deposit_accounts_should_display_in_proper_order(String user) {
		if (accountSummaryPage.verifyDepositAccountsOrder(user))
			reportPass(user + " Deposit accounts are displayed in proper order");
		else
			reportFail(user + " Deposit accounts are not displayed in proper order");
	}

	@When("I click on Credit card Account")
	public void i_click_on_Credit_card_Account() {
		if (accountSummaryPage.clickOnCCAccountLink())
			reportPass("Clicked on Credit Card Account link");
		else
			reportFail("Unable to click on Credit Card Account link");
	}

	@Then("I verify the E-SIGN page should display")
	public void i_verify_the_E_SIGN_page_should_display() {
		if (accountSummaryPage.verifyESIGNPage())
			reportPass("E-Sign Page is displayed");
		else
			reportFail("Unable to display the E-Sign Page");
	}

}
