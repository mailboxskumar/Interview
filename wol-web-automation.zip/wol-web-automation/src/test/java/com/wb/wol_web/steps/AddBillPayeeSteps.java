package com.wb.wol_web.steps;

import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.AddBillPayeePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class AddBillPayeeSteps extends ObjectBase {

	AddBillPayeePage addBillPayeePage = new AddBillPayeePage();

	@When("^click on Browse Available Payee link$")
	public void click_on_Browse_Available_Payee_link() throws Throwable {
		if (addBillPayeePage.clickAvailablePayees())
			reportPass("Clicked on Browse Available Payees Link");
		else
			reportFail("Failed to click on Browse Available Payees Link ");
	}

	@When("^I Checked check box Pay by check method$")
	public void i_checked_check_box_pay_by_check_method() throws Throwable {
		addBillPayeePage.selectNoAcctNumOption();
	}

	@When("user click on required payee name link")
	public void user_click_on_required_payee_name_link() {
		try {
			addBillPayeePage.clickPayeeName(jsonDataParser.getTestDataMap().get("Payee Name"));
			reportPass("Clicked on Payee " + jsonDataParser.getTestDataMap().get("Payee Name") + "  link");
		} catch (Exception e) {
			reportFail("Failed to click on Payee " + jsonDataParser.getTestDataMap().get("Payee Name") + "  link");
		}
	}

	@Then("verify displayed Payname  is same as the selected payee")
	public void verify_displayed_Payname_is_same_as_the_selected_payee() {
		if (addBillPayeePage.verifyPayeeNameSelected(jsonDataParser.getTestDataMap().get("Payee Name")))
			reportPass("Verified the selected payee: " + jsonDataParser.getTestDataMap().get("Payee Name"));
		else
			reportFail("Verified the selected payee : " + jsonDataParser.getTestDataMap().get("Payee Name")
					+ " is not displayed");
	}

	@When("I Enter new Payee details")
	public void i_Enter_new_Payee_details() throws InterruptedException {
		addBillPayeePage.selectPayeeshortlist(jsonDataParser.getTestDataMap().get("ShortList"));
		addBillPayeePage.selectPayeeFrom(jsonDataParser.getTestDataMap().get("Payee Type"));
		if (addBillPayeePage.enterPayeeAcctDetails())
			reportPass("Entered all Payee Account details in a Add a new Bill Payee page");
		else
			reportFail("Failed to enter account number in a Add a new Bill Payee page");
	}

	@When("^Click on Continue Button$")
	public void click_on_Continue_Button() throws Throwable {
		try {
			addBillPayeePage.clickContinueButton();
			reportPass("Clicked on Continue Button");
		} catch (Exception e) {
			reportHardFail("Failed to click on continue button");
		}
	}

	@When("^I Click on Continue Button$")
	public void i_Click_on_Continue_Button() throws Throwable {
		try {
			addBillPayeePage.clickContinueButton();
			reportPass("Clicked on Continue Button");
		} catch (Exception e) {
			reportHardFail("Failed to click on continue button");
		}
	}

	@And("^Click on Continue Button in a Light box$")
	public void click_on_continue_button_in_a_light_box() throws Throwable {
		try {
			addBillPayeePage.clickContinueButtonLightBox();
			reportPass("Clicked on Continue Button in a Lightbox");
		} catch (Exception e) {
			reportFail("Failed to click on continue button");
		}
	}

	@When("^Select Disclosure Agreement check box$")
	public void select_Disclosure_Agreement_check_box() throws Throwable {
		addBillPayeePage.selectDisclosure();
	}

	@Then("Payee add Confirmation message should be displayed")
	public void payee_add_Confirmation_message_should_be_displayed() {
		if (addBillPayeePage.verifyConfrmMsgAdding(jsonDataParser.getTestDataMap().get("Add Message")))
			reportPass("The Confirmation message:" + jsonDataParser.getTestDataMap().get("Add Message")
					+ "  is successfully displayed");
		else
			reportFail("The Confirmation message:" + jsonDataParser.getTestDataMap().get("Add Message")
					+ "is not displayed");
	}

	@When("I Enter payee name  to add new payee to my payee list")
	public void i_Enter_payee_name_to_add_new_payee_to_my_payee_list() {
		if (addBillPayeePage.enterPayeeName(jsonDataParser.getTestDataMap().get("Payee Name")))
			reportPass("Entered payee name " + jsonDataParser.getTestDataMap().get("Payee Name")
					+ " to add a new Bill payee");
		else
			reportFail("Failed to enter payee name ");
	}

	@When("I Enter address datails of the Payee")
	public void i_Enter_address_datails_of_the_Payee() {
		addBillPayeePage.enterPayeeCity(jsonDataParser.getTestDataMap().get("City"));
		addBillPayeePage.enterPayeeZip(jsonDataParser.getTestDataMap().get("Zip"));
		addBillPayeePage.selectPayeeState();
		if (addBillPayeePage.enterPayeeAddressOne(jsonDataParser.getTestDataMap().get("Address One")))
			reportPass("Enetered the payee address details");
		else
			reportFail("Failed to enter Payee address");
	}

	@When("I Re-Enter payee name  to add new payee to my payee list")
	public void i_Re_Enter_payee_name_to_add_new_payee_to_my_payee_list() {
		if (addBillPayeePage.reEnterPayeeName(jsonDataParser.getTestDataMap().get("Payee Name")))
			reportPass("Re-Entered payee name " + jsonDataParser.getTestDataMap().get("Payee Name")
					+ " to add a new payee");
		else
			reportFail("Failed to Re-Enter Payee Name");
	}

	@When("^I Click on Select Address Button$")
	public void i_Click_on_Select_Address_Button() throws Throwable {
		if (addBillPayeePage.clickSelectAddress())
			reportPass("Clicked on Select Payee Address button");
		else
			reportFail("Failed to click on select Payee Address button");
	}

	@Then("^Select Address Lightbox with message \"([^\"]*)\" should be displayed$")
	public void lightbox_with_message_should_be_displayed(String message) throws Throwable {
		if (addBillPayeePage.verifyAddressLghtBoxMsg(message))
			reportPass("The text:" + message + "  is successfully displayed");
		else if (addBillPayeePage.verifyAddressMsg(message))
			reportPass("The text:" + message + "  is successfully displayed");
		else
			reportFail("The text:" + message + " is not displayed");
	}

	@Then("Cancel Lightbox with message should be displayed")
	public void cancel_Lightbox_with_message_should_be_displayed() {
		if (addBillPayeePage.verifyCancelLghtBoxMsg(jsonDataParser.getTestDataMap().get("Cancel Msg")))
			reportPass("The text:" + jsonDataParser.getTestDataMap().get("Cancel Msg") + "  is successfully displayed");
		else
			reportFail("The text:" + jsonDataParser.getTestDataMap().get("Cancel Msg") + " is not displayed");
	}

	@When("^Select Address for a new payee$")
	public void select_address_for_a_new_payee() throws Throwable {
		try {
			addBillPayeePage.selectPayeeAddress();
			reportPass("Selected Address to a new payee");
		} catch (Exception e) {
			reportFail("Failed to select Address");
		}
	}

	@Then("^Addreeses more than 7 message \"([^\"]*)\" should be displayed$")
	public void addreeses_more_than_7_message_something_should_be_displayed(String message) throws Throwable {
		if (addBillPayeePage.verifyAddressMoreLabel(message))
			reportPass("The Label :" + message + "  is successfully displayed");
		else if (addBillPayeePage.verifyAddressMoreLabelLightBox(message))
			reportPass("The Label :" + message + "  is successfully displayed");
		else
			reportFail("The Label :" + message + " is not displayed");
	}

	@And("^\"([^\"]*)\" Label Should be displayed$")
	public void something_label_should_be_displayed(String message) throws Throwable {
		if (addBillPayeePage.verifyPayeeNameLabel(message))
			reportPass("The Label :" + message + "  is successfully displayed");
		else
			reportFail("The Label :" + message + " is not displayed");
	}

	@When("^I Click on Cancel button$")
	public void i_click_on_cancel_button() throws Throwable {
		if (addBillPayeePage.clickCancelButton())
			reportPass("Clicked on Cancel Button");
		else
			reportFail("Failed to click on cancel button");
	}

	@When("^I Click on No button$")
	public void i_click_on_no_button() throws Throwable {
		try {
			addBillPayeePage.clickNoButton();
			reportPass("Clicked on No Button");
		} catch (Exception e) {
			reportFail("Failed to click on No button");
		}
	}

	@When("^I Click on Yes button$")
	public void i_click_on_yes_button() throws Throwable {
		try {
			addBillPayeePage.clickYesButton();
			reportPass("Clicked on Yes Button");
		} catch (Exception e) {
			reportFail("Failed to click on Yes button");
		}
	}

	@Then("Account Number Error message should be displayed")
	public void account_Number_Error_message_should_be_displayed() {
		if (addBillPayeePage.verifyPayeeAcctError(jsonDataParser.getTestDataMap().get("Error Msg")))
			reportPass("The Error message:" + jsonDataParser.getTestDataMap().get("Error Msg")
					+ "  is successfully displayed");
		else
			reportFail("The Error message:" + jsonDataParser.getTestDataMap().get("Error Msg") + " is not displayed");
	}

	@Then("Invalid Account mask Error message should be displayed")
	public void invalid_Account_mask_Error_message_should_be_displayed() {
		if (addBillPayeePage.verifyPayeeInvalidAcctError(jsonDataParser.getTestDataMap().get("Error Msg")))
			reportPass("The Error message:" + jsonDataParser.getTestDataMap().get("Error Msg")
					+ "  is successfully displayed");
		else
			reportFail("The Error message:" + jsonDataParser.getTestDataMap().get("Error Msg") + " is not displayed");
	}

	@Then("Confirm Account Number Error message should be displayed")
	public void confirm_Account_Number_Error_message_should_be_displayed() {
		if (addBillPayeePage.verifyPayeeCnfrmAcctError(jsonDataParser.getTestDataMap().get("Error Msg")))
			reportPass("The Error message:" + jsonDataParser.getTestDataMap().get("Error Msg")
					+ "  is successfully displayed");
		else
			reportFail("The Error message:" + jsonDataParser.getTestDataMap().get("Error Msg") + " is not displayed");
	}

	@Then("Address Error message should be displayed")
	public void address_Error_message_should_be_displayed() {
		if (addBillPayeePage.verifyPayeeAddressOneError(jsonDataParser.getTestDataMap().get("Address Err")))
			reportPass("The Error message:" + jsonDataParser.getTestDataMap().get("Address Err")
					+ "  is successfully displayed");
		else
			reportFail("The Error message:" + jsonDataParser.getTestDataMap().get("Address Err") + " is not displayed");
	}

	@Then("City Error message should be displayed")
	public void city_Error_message_should_be_displayed() {
		if (addBillPayeePage.verifyPayeeCityError(jsonDataParser.getTestDataMap().get("City Err")))
			reportPass("The Error message:" + jsonDataParser.getTestDataMap().get("City Err")
					+ "  is successfully displayed");
		else
			reportFail("The Error message:" + jsonDataParser.getTestDataMap().get("City Err") + " is not displayed");
	}

	@Then("State Error message should be displayed")
	public void state_Error_message_should_be_displayed() {
		if (addBillPayeePage.verifyPayeeStateError(jsonDataParser.getTestDataMap().get("State Err")))
			reportPass("The Error message:" + jsonDataParser.getTestDataMap().get("State Err")
					+ "  is successfully displayed");
		else
			reportFail("The Error message:" + jsonDataParser.getTestDataMap().get("State Err") + " is not displayed");
	}

	@Then("Zip Error message should be displayed")
	public void zip_Error_message_should_be_displayed() {
		if (addBillPayeePage.verifyPayeeZipError(jsonDataParser.getTestDataMap().get("Zip Err")))
			reportPass("The Error message:" + jsonDataParser.getTestDataMap().get("Zip Err")
					+ "  is successfully displayed");
		else
			reportFail("The Error message:" + jsonDataParser.getTestDataMap().get("Zip Err") + " is not displayed");
	}

	@When("I Enter Invalid new Payee details")
	public void i_enter_new_payee_details_something_something_something_something() throws Throwable {
		addBillPayeePage.selectPayeeshortlist(jsonDataParser.getTestDataMap().get("ShortList"));
		addBillPayeePage.selectPayeeFrom(jsonDataParser.getTestDataMap().get("Payee Type"));
		addBillPayeePage.enterCnfrmPayeeAcctNum(jsonDataParser.getTestDataMap().get("Cnfrm Account Number"));
		if (addBillPayeePage.enterPayeeAcctNum(jsonDataParser.getTestDataMap().get("Account Number")))
			reportPass("Entered all Payee Account details");
		else
			reportFail("Failed to enter payee details");
	}

	@When("^I hand Over on Pay From Which Accounts$")
	public void i_hand_over_on_pay_from_which_accounts() throws Throwable {
		addBillPayeePage.clickPayFromLabel();
	}

	@Then("Tooltip Message should be displayed")
	public void tooltip_Message_should_be_displayed() {
		if (addBillPayeePage.verifyTooltip(jsonDataParser.getTestDataMap().get("Tooltip Msg")))
			reportPass("The Tooltip Pay From Which Accounts content is displaying properly");
		else
			reportFail("The Tooltip Pay From Which Accounts content is not displayed properly");
	}

	@When("I click on Edit Icon of  PayeeName to update payee details")
	public void i_click_on_Edit_Icon_of_PayeeName_to_update_payee_details() {
		if (addBillPayeePage.clickEditIcon(jsonDataParser.getTestDataMap().get("Payee Name")))
			reportPass("Clicked on Edit Icon for a payee in Manage Payee Page");
		else
			reportFail("Failed to click on Edit Icon in Manage Payees page");
	}

	@When("^I Update Payee details$")
	public void i_update_payee_details() throws Throwable {
		if (addBillPayeePage.updateNickname())
			reportPass("Updated Nick name for a payee");
		else
			reportFail("Failed to update nick name");
	}

	@And("^Click on Continue Button in update payee details page$")
	public void click_on_continue_button_in_update_payee_details_page() throws Throwable {
		try {
			addBillPayeePage.clickUpdateButton();
			reportPass("Clicked on Continue Button");
		} catch (Exception e) {
			reportHardFail("Failed to click on continue button");
		}
	}

	@When("^I Click on Delete Button$")
	public void i_click_on_delete_button() throws Throwable {
		try {
			addBillPayeePage.clickDeleteButton();
			reportPass("Clicked on Delete Button");
		} catch (Exception e) {
			reportFail("Failed to click on Delete button");
		}
	}

	@When("^I Click on Add Payee Link$")
	public void i_click_on_add_payee_link() throws Throwable {
		if (addBillPayeePage.clickAddPayee())
			reportPass("Clicked on AddPayee link in Manage Payees Page");
		else
			reportFail("Failed to click on AddPayee link in Manage Payees Page");
	}

	@When("^I Click on Edit Button$")
	public void i_click_on_edit_button() throws Throwable {
		try {
			addBillPayeePage.clickEditButton();
			reportPass("Clicked on Edit Button");
		} catch (Exception e) {
			reportFail("Failed to click on Edit button");
		}
	}

	@Then("^I should be in Update \"([^\"]*)\" page$")
	public void i_should_be_in_update_something_page(String pageTitle) throws Throwable {
		if (addBillPayeePage.verifyUpdtPayeePageTitle(pageTitle))
			reportPass("The Page Title:" + pageTitle + "  is successfully displayed");
		else
			reportFail("The Page Title:" + pageTitle + " is not displayed");
	}

	@When("^I Update Payee Account Number \"([^\"]*)\" details$")
	public void i_update_payee_account_number_something_details(String acctnum) throws Throwable {
		if (addBillPayeePage.updateAcctNum(acctnum))
			reportPass("Updated Payee Account Number");
		else
			reportFail("Failed to update Account number");
	}

	@Then("^I should be in \"([^\"]*)\" page in Add a Bill Pay Payee functionality$")
	public void i_should_be_in_something_page_in_add_a_bill_pay_payee_functionality(String message) throws Throwable {
		if (addBillPayeePage.verifyAddBillPayeeTitles(message))
			reportPass("The Header Text:" + message + "  is successfully displayed");
		else
			reportFail("The Header Text:" + message + " is not displayed");
	}

	@Then("Delete or Update confirmation message should be displayed")
	public void delete_or_Update_confirmation_message_should_be_displayed() {
		if (addBillPayeePage.verifyConfrmMsgDeleting(jsonDataParser.getTestDataMap().get("Delete Msg")))
			reportPass("The Confirmation message: " + jsonDataParser.getTestDataMap().get("Delete Msg")
					+ "  is successfully displayed");
		else
			reportFail("The Confirmation message: " + jsonDataParser.getTestDataMap().get("Delete Msg")
					+ " is not displayed");
	}

	@Then("^I check for the following \"([^\"]*)\" payee details list in Update Payee Details page$")
	public void i_check_for_payee_details_list_in_update_details_page(String payeeType, DataTable payeeDetails) {
		List<String> details = payeeDetails.asList(String.class);
		List<String> actualdetails = addBillPayeePage.checkPayeeLabelsInUPDPage(details, payeeType);
		String colDisplayed = "";
		for (String eachLabel : actualdetails) {
			if (details.contains(eachLabel)) {
				colDisplayed = colDisplayed + eachLabel + ",";
			}
		}
		if (details.size() == actualdetails.size())
			reportPass("Payee Details present are " + colDisplayed);
		else
			reportFail("Only following Payee Details are  present. " + colDisplayed);

	}

	@And("^I should see add a new Payee cofirmation details$")
	public void i_should_see_add_a_new_payee_cofirmation_details() throws Throwable {
		addBillPayeePage.getPayeeCnfrmDetails();
	}

	@Then("^I should see the Selected payee address value$")
	public void i_should_see_the_selected_payee_address_value() throws Throwable {
		if (addBillPayeePage.verifyAddressValue())
			reportPass("Selected Payee Address " + addBillPayeePage.address + " is successfully displayed");
		else
			reportFail("Selected Payee Address is not displayed");
	}

	@Then("I should see the selected payee name  and entered account number")
	public void i_should_see_the_selected_payee_name_and_entered_account_number() {
		if (addBillPayeePage.verifyConfirmDetails(jsonDataParser.getTestDataMap().get("Payee Name")))
			reportPass("Selected Payee Name: " + jsonDataParser.getTestDataMap().get("Payee Name")
					+ " & Account Number: " + addBillPayeePage.acctNum + " is successfully displayed");
		else
			reportFail("Selected Payee Name & Account Number is not displayed");
	}

}
