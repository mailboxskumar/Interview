package com.wb.wol_web.steps;

import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.PendingTransfersPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class PendingTransfersSteps extends ObjectBase {

	PendingTransfersPage pendingTransfersPage = new PendingTransfersPage();

	@When("^I click on Disclosure Link in Update Pending Transfer Page$")
	public void i_click_on_disclosure_link_in_update_pending_transfer_page() throws Throwable {
		if (pendingTransfersPage.clickUpdateTransferDisclosure())
			reportPass("Clicked on Disclosure Link in update pending Transfers");
		else
			reportFail("Failed to click on Disclosure Link in update pending Transfers");
	}

	@Then("^I should able to see the content of Disclosure in a Lightbox$")
	public void i_should_able_to_see_the_content_of_disclosure_in_a_lightbox() throws Throwable {
		if (pendingTransfersPage.verifyDisclosureContent())
			reportPass("The content in Disclosure Lightbox is  displayed");
		else
			reportFail("The content in Disclosure Lightbox is not displayed");

	}

	@When("^I click on Close button in Disclosure in Pending Transfers$")
	public void i_click_on_close_button_in_disclosure_in_pending_transfers() throws Throwable {
		try {
			pendingTransfersPage.clickUpdateDisclosureCloseButton();
			reportPass("Clicked on Close button in Disclosure in update pending Transfers");
		} catch (Exception e) {
			reportFail("Failed to click on Close button in Disclosure in update pending Transfers");
		}
	}

	@When("^I update amount in Pending Transfers$")
	public void i_update_amount_something_in_pending_transfers() throws Throwable {
		String amount=jsonDataParser.getTestDataMap().get("Update Amount");
		if (pendingTransfersPage.enterAmount(amount))
			reportPass("Entered amount value in Pending Transfers");
		else
			reportFail("Failed to enter amount value in Pending Transfers");
	}

	@And("^I click on continue button in pending Transfers page$")
	public void i_click_on_continue_button_in_pending_transfers_page() throws Throwable {
		try {
			pendingTransfersPage.clickContinueToUpdate();
			reportPass("Clicked on Continue button  in update pending Transfers");
		} catch (Exception e) {
			reportHardFail("Failed to click on continue button");
		}
	}

	@Then("^I should able to see Note content \"([^\"]*)\" should be displayed$")
	public void i_should_able_to_see_note_content_something_should_be_displayed(String message) throws Throwable {
		if (pendingTransfersPage.verifyNoteContent(message))
			reportPass("The Note content: " + message + "  is successfully displayed");
		else
			reportFail("The Note content: " + message + "  is not displayed");
	}

	@When("^I click on Delete button in Update Pending Transfer Page$")
	public void i_click_on_delete_button_in_update_pending_transfer_page() throws Throwable {
		try {
			pendingTransfersPage.clickDeleteButton();
			reportPass("Clicked on Delete button in update pending Transfers");
		} catch (Exception e) {
			reportFail("Failed to click on Delete button in update pending Transfers");
		}

	}

	@Then("^I should able to see confirmation message should be displayed$")
	public void i_should_able_to_see_confirmation_message_something_should_be_displayed()
			throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("DeleteMsg");
		if (pendingTransfersPage.verifyConfirmMsg(message))
			reportPass("The Confirmation message: " + message + "  is successfully displayed");
		else {
			reportFail("The Confirmation message: " + message + "  is successfully displayed");
		}
	}

	@When("^I Entered required details to Update Transfer in Update Pending Transfers Page$")
	public void i_entered_required_details_to_update_transfer_in_update_pending_transfers_page()
			throws Throwable {
		Map<String, String> transferDetails = jsonDataParser.getTestDataMap();
		if (pendingTransfersPage.updateTransferTypeDetails(transferDetails))
			reportPass("Updated Internal Transfer Details");
		else
			reportFail("Failed to update transfer details");
	}

	@Then("^I should see the amount error message")
	public void i_should_see_the_amount_error_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (pendingTransfersPage.verifyAmountErrMsg(message))
			reportPass("The Error message: " + message + "  is successfully displayed");
		else
			reportFail("The Error message: " + message + "  is not displayed");
	}

	@When("^I enter Past date Transfer Date in Pending Transfers Page$")
	public void i_enter_past_date_2_transfer_date_in_pending_transfers_page() throws Throwable {
		try {
			int days=Integer.parseInt(jsonDataParser.getTestDataMap().get("Update Date"));
			pendingTransfersPage.updateTransferPastDate(days);
			reportPass("Entered past date in Date field in Pending Transfers Page");
		} catch (Exception e) {
			reportFail("Failed to enter past date in Pending Transfers Page");
		}
	}

	@Then("^I should see the Date Error message")
	public void i_should_see_the_date_error_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (pendingTransfersPage.verifyDateErrMsg(message))
			reportPass("The Error message: " + message + "  is successfully displayed");
		else
			reportFail("The Error message: " + message + "  is not displayed");
	}

	@When("^I enter Special Characters in date Transfer Date in Pending Transfers Page$")
	public void i_enter_special_characters_in_date_something_transfer_date_in_pending_transfers_page()
			throws Throwable {
		String date=jsonDataParser.getTestDataMap().get("Update Date");
		if (pendingTransfersPage.updateTransferDate(date))
			reportPass("EnteredDate value in Date field in Pending Transfers Page");
		else
			reportFail("Failed to enter date value in Date field in Pending Transfers Page ");
	}

	@Then("^I Should see the frequency error message")
	public void i_should_see_the_frequency_error_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (pendingTransfersPage.verifyDateErrMsg(message))
			reportPass("The Error message: " + message + "  is successfully displayed");
		else
			reportFail("The Error message: " + message + "  is not displayed");
	}

	@Then("^I should see the Transfers Remaining error message")
	public void i_should_see_the_transfers_remaining_error_message_something() throws Throwable {
		String message=jsonDataParser.getTestDataMap().get("Error Msg");
		if (pendingTransfersPage.verifyDateErrMsg(message))
			reportPass("The Error message: " + message + "  is successfully displayed");
		else
			reportFail("The Error message: " + message + "  is not displayed");
	}

}
