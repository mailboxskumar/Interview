package com.wb.wol_web.steps;

import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.CreditCardPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

/**
 * @author: Ravi kumar Maddula
 *
 */

public class CreditCardSteps extends ObjectBase {

	CreditCardPage creditCardPage = new CreditCardPage();

	@Then("Move cursor to Bank menu and tab the menu")
	public void move_cursor_to_Bank_menu_and_tab_the_menu() {
		if (creditCardPage.moveToBank()) {
			reportPass("Moved cursor to Bank menu option successfully");
		} else {
			reportFail("Failed to Move the cursor to Bank menu option");
		}
	}

	@Then("Click on Credit cards link from the sub menu")
	public void click_on_Credit_cards_link_from_the_sub_menu() {
		if (creditCardPage.clickCreditCard()) {
			reportPass("Clicked on credit cards option successfully");
		} else {
			reportFail("Failed to Click on credit cards option option");
		}
	}

	@Then("Click on Apply now button from the list of credit cards, verify text of the alert box, Click on Ok button from the alert box")
	public void click_on_Apply_now_button_from_the_list_of_credit_cards_verify_text_of_the_alert_box_Click_on_Ok_button_from_the_alert_box() {
		String alertText = testDataMap.get("AlertText");
		if ((creditCardPage.clickApplyNow()) && (creditCardPage.verifyAlertText(alertText))
				&& (creditCardPage.acceptAlert())) {
			reportPass(
					"Clicked on apply now button successfully and alert text is verified and successfully displayed as: "
							+ creditCardPage.alertText + "Accepted alert successfully");
		} else {
			reportFail(
					"Failed to Click on apply now button and Failed to verify alert text and Failed to Accept alert");
		}
	}

	@Then("Should navigate to Elan site and verify page title {string} and close the browser")
	public void should_navigate_to_Elan_site_and_verify_page_title_and_close_the_browser(String string) {
		if (creditCardPage.verifyElanWindow(string)) {
			reportPass("Verified Elan window by switching to window successfully");
		} else {
			reportFail("Failed to verify Elan window");
		}
	}

	@Then("Click on Apply now button from the list of credit cards, Click on dismiss from the alert box")
	public void click_on_Apply_now_button_from_the_list_of_credit_cards_Click_on_dismiss_from_the_alert_box() {
		if ((creditCardPage.clickApplyNow()) && (creditCardPage.dismissAlert())) {
			reportPass("Clicked on apply now button successfully and Dismissed alert successfully");
		} else {
			reportFail("Failed to Click on apply now button, Failed to dismiss alert");
		}
	}

	@Then("I click on {string} tab from main menu")
	public void i_click_on_tab_from_main_menu(String string) {
		if (creditCardPage.clickMenuBank(string)) {
			reportPass("Clicked on menu and selected Bank option successfully");
		} else {
			reportFail("Failed to click on Bank option from menu");
		}
	}

	@Then("Move cursor to Financing menu and tab the menu, Click on {string} link from the sub menu")
	public void move_cursor_to_Financing_menu_and_tab_the_menu_Click_on_link_from_the_sub_menu(String string) {
		if ((creditCardPage.moveToFinancing()) && (creditCardPage.clickBusinessCreditCardLink(string))) {
			reportPass(
					"moved cursor to financing option successfully and Clicked on Business Credit Cards Overview link from the sub menu successfully");
		} else {
			reportFail(
					"Failed to move cursor to financing option from menu, Failed to click Business Credit Cards Overview link from the sub menu");
		}
	}

	@Then("verify navigate to {string} page")
	public void verify_navigate_to_page(String header) {
		if (creditCardPage.verifyBusinessCreditCardHeader(header)) {
			reportPass("Verified business credit card header successfully: " + header);
		} else {
			reportFail("Failed to verify business credit card header: " + header);
		}
	}

	@Then("Click on Apply now button from Small business page")
	public void click_on_Apply_now_button_from_Small_business_page() {
		if (creditCardPage.clickOnApplyNow()) {
			reportPass("Clicked on apply now button successfully");
		} else {
			reportFail("Failed to Click on apply now button");
		}
	}

	@Then("Click on Cancel button")
	public void click_on_Cancel_button() {
		if (creditCardPage.clickCancel()) {
			reportPass("Clicked on cancel button successfully");
		} else {
			reportFail("Failed to Click on cancel button");
		}
	}

	@Then("Click on Continue button")
	public void click_on_Continue_button() {
		if (creditCardPage.clickContinue()) {
			reportPass("Clicked on continue button successfully");
		} else {
			reportFail("Failed to Click on continue button");
		}
	}

	@Then("Click on credit card link from credit cards table")
	public void click_on_credit_card_link_from_credit_cards_table() {
		if (creditCardPage.clickCreditCardLink()) {
			reportPass("Clicked on credit card number successfully");
		} else {
			reportFail("Failed to Click on credit card number");
		}
	}

	@Then("Verify credit card information fields")
	public void verify_credit_card_information_fields(DataTable values) {
		List<String> selectValues = values.asList(String.class);
		if (creditCardPage.verifyCardInfo(selectValues)) {
			reportPass("Verified card information successfully");
		} else {
			reportFail("Failed to Verify card information");
		}
	}

	@Then("Should navigate to Elan site and verify page title as {string} and close the browser")
	public void should_navigate_to_Elan_site_and_verify_page_title_as_and_close_the_browser(String string) {
		if (creditCardPage.verifyElanSite(string)) {
			reportPass("Verified Elan site successfully");
		} else {
			reportFail("Failed to verify Elan site");
		}
	}

}
