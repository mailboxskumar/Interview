package com.wb.wol_web.steps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.SmallTalkWebcomPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmallTalkWebcomSteps extends ObjectBase {

	SmallTalkWebcomPage smallTalkWebcomPage = new SmallTalkWebcomPage();
	public List<String> txtDate = null;
	Map<String, String> testDataMap1 = new HashMap<String, String>();

	@When("I enter random data into {string} field in {string} page")
	public void i_enter_random_data_into_field_in_page(String fieldName, String pageName) {
		String data = smallTalkWebcomPage.enterRandomDataInField(fieldName);
		if (data != null)
			reportPass("Data: " + data + " is entered at Field: " + fieldName + " in page: " + pageName);
		else
			reportFail("Data is not entered at Field: " + fieldName + " in page: " + pageName);
	}

	@When("I verify the {string} is {string} by default")
	public void i_verify_the_is_by_default(String fieldName, String value) {
		if (smallTalkWebcomPage.verifyDefaultValue(fieldName, value))
			reportPassWithFullPageScreenshot("FieldName: " + fieldName + " is " + value + " by default");
		else
			reportFailWithFullPageScreenshot("FieldName: " + fieldName + " is not " + value + " by default");
	}

	@Then("I select the radio button of {string}")
	public void i_select_the_radio_button_of(String fieldName) {
		testDataMap1 = jsonDataParser.getTestDataMap();
		if (smallTalkWebcomPage.selectValueInField(testDataMap1.get("ChannelType"), fieldName))
			reportPass("Value: " + testDataMap1.get("AccountType") + " is selected for the field " + fieldName);
		else
			reportFail("Value: " + testDataMap1.get("ChannelType") + " is not selected for the field " + fieldName);
	}

	@Then("I click on {string} button in {string} page of Webcom Application")
	public void i_click_on_button_in_page_of_Webcom_Application(String btnName, String pageName) {
		if (smallTalkWebcomPage.clickOnButton(btnName, pageName))
			reportPass("Button: " + btnName + " is clicked on the page " + pageName);
		else
			reportFail("Button: " + btnName + " is not clicked on the page " + pageName);
	}

	@Then("I verify the popup with sorted application code")
	public void i_verify_the_popup_with_sorted_application_code() {
		if (smallTalkWebcomPage.verifyApplicationCodeSorted())
			reportPass("Application codes are in sorted order");
		else
			reportFail("Application codes are not in sorted order");
	}

	@Then("I verify the {string} list box is displayed")
	public void i_verify_the_list_box_is_displayed(String labelName) {
		if (smallTalkWebcomPage.checkForDisplay(labelName))
			reportPass("Label: " + labelName + " is displayed with list");
		else
			reportFail("Label: " + labelName + " is not displayed with list");
	}

	@Then("I verify the {string} button in Account Type popup")
	public void i_verify_the_button_in_Account_Type_popup(String btnName) {
		if (smallTalkWebcomPage.checkForDisplay(btnName))
			reportPass("Button: " + btnName + " is displayed");
		else
			reportFail("Button: " + btnName + " is not displayed");
	}

	@When("I click on Application code of Account Type")
	public void i_click_on_Application_code_of_Account_Type() {
		testDataMap1 = jsonDataParser.getTestDataMap();
		if (smallTalkWebcomPage.clickOnApplicationCode(testDataMap1.get("AccountType")))
			reportPass("Application Code: " + testDataMap1.get("AccountType") + " is clicked");
		else
			reportFail("Application Code: " + testDataMap1.get("AccountType") + " is not clicked");
	}

	@Then("I move the {string} account from Exclude box to Include box")
	public void i_move_the_account_from_Exclude_box_to_Include_box(String numberOfAccounts) {
		if (smallTalkWebcomPage.moveAccountsFromExcludeToInclude(numberOfAccounts))
			reportPassWithFullPageScreenshot(numberOfAccounts + " Account(s) is/are moved from Exclude to Include box");
		else
			reportFailWithFullPageScreenshot(
					numberOfAccounts + " Account(s) is/are not moved from Exclude to Include box");
	}

	@Then("I check the selected {string} are displayed under {string}")
	public void i_check_the_selected_are_displayed_under(String values, String labelName) {
		List<String> listValues = smallTalkWebcomPage.verifySelectedValues(values, labelName);
		if (listValues != null)
			reportPass("Value(s): " + listValues.toString() + " is/are displayed under Label: " + labelName);
		else
			reportFail("Values is/are not displayed under Label: " + labelName);
	}

	@Then("I verify the popup of {string} is displayed")
	public void i_verify_the_popup_of_is_displayed(String popupName) {
		if (smallTalkWebcomPage.checkForDisplay(popupName))
			reportPass("Location Popup is displayed");
		else
			reportFail("Location Popup is not displayed");
	}

	@When("I click on {string} State in location")
	public void i_click_on_State_in_location(String stateName) {
		if (smallTalkWebcomPage.clickOnStateName(stateName))
			reportPass("State Name: " + stateName + " is clicked");
		else
			reportFail("State Name: " + stateName + " is not clicked");
	}

	@Then("I should see the success Small Talk message")
	public void i_should_see_the_Small_Talk_message() {
		String message = jsonDataParser.getTestDataMap().get("Message");
		if (smallTalkWebcomPage.checkSmallTalkUpdateMessage(message))
			reportPass("Message: " + message + " is displayed");
		else
			reportFail("Message: " + message + " is not displayed");
	}

	@Then("I verify the created message in {string} status")
	public void i_verify_the_created_message_in_status(String batchStatus) {
		String messageName = smallTalkWebcomPage.verifyBatchStatus(batchStatus);
		if (messageName != null)
			reportPass("Message Name: " + messageName + " is displayed with batch status as: " + batchStatus);
		else
			reportFail("Message Name: " + messageName + " is not displayed with batch status as: " + batchStatus);
	}

	@When("I click on Edit button of the message in {string} status")
	public void i_click_on_Edit_button_of_the_message_in_status(String batchStatus) {
		if (smallTalkWebcomPage.clickOnEditLink(batchStatus))
			reportPass("Edit button is clicked with batch status as: " + batchStatus);
		else
			reportFail("Edit button is clicked with batch status as: " + batchStatus);
	}

	@When("I enter the {string} date and {string} time for Start date")
	public void i_enter_the_date_and_time_for_Start_date(String dateToEnter, String time) {
		txtDate = smallTalkWebcomPage.enterStartDate(dateToEnter, time);
		if (txtDate != null)
			reportPass("Date and Time " + txtDate.toString() + " is entered in start date");
		else
			reportFail("Date and Time are not entered in start date");
	}

	@When("I enter the {string} date and {string} time for End date")
	public void i_enter_the_date_and_time_for_End_date(String dateToEnter, String time) {
		txtDate = smallTalkWebcomPage.enterEndDate(dateToEnter, time);
		if (txtDate != null)
			reportPass("Date and Time " + txtDate.toString() + " is entered in end date");
		else
			reportFail("Date and Time are not entered in end date");
	}

	@Then("I verify the {string} button in Message body field")
	public void i_verify_the_button_in_Message_body_field(String btnName) {
		if (smallTalkWebcomPage.checkForDisplay(btnName))
			reportPass("Button: " + btnName + " is displayed");
		else
			reportFail("Button: " + btnName + " is not displayed");
	}

	@When("I click on {string} button in Message body field of {string} page")
	public void i_click_on_button_in_Message_body_field(String btnName, String pageName) {
		if (smallTalkWebcomPage.clickOnButton(btnName, pageName))
			reportPass("Button: " + btnName + " is clicked on the page " + pageName);
		else
			reportFail("Button: " + btnName + " is not clicked on the page " + pageName);
	}

	@Then("I verify the {string} button in placeholder properties")
	public void i_verify_the_button_in_placeholder_properties(String btnName) {
		if (smallTalkWebcomPage.checkForDisplay(btnName))
			reportPass("Button: " + btnName + " is displayed");
		else
			reportFail("Button: " + btnName + " is not displayed");
	}

	@Then("I verify the values are present in placeholder dropdown")
	public void i_verify_the_values_are_present_in_placeholder_dropdown() {
		testDataMap1 = jsonDataParser.getTestDataMap();
		List<String> listPlaceholder = smallTalkWebcomPage.checkPlaceholderDropdown(testDataMap1);
		if (listPlaceholder.size() == 0)
			reportPass("Values: " + testDataMap.values() + " is displayed");
		else
			reportFail("Values: " + listPlaceholder.toString() + " is not displayed");
	}

	@Then("I select the {string} from {string} field")
	public void i_select_the_from_field(String value, String listName) {
		if (smallTalkWebcomPage.selectPlaceholderValue(value, listName))
			reportPass("Value: " + value + " is selected in list: " + listName);
		else
			reportFail("Value: " + value + " is not selected in list: " + listName);
	}

	@Then("I verify the {string} are displayed")
	public void i_verify_the_are_displayed(String listName) {
		testDataMap1 = jsonDataParser.getTestDataMap();
		List<String> lisValues = smallTalkWebcomPage.checkForListDisplay(listName, testDataMap1);
		if (lisValues.size() == 0)
			reportPass(listName + " : " + testDataMap1.values().toString() + " is/are displayed");
		else
			reportFail(listName + " : " + lisValues.toString() + " is/are not displayed");
	}

	@Then("I verify the {string} button in Location pickup popup")
	public void i_verify_the_button_in_Location_pickup_popup(String btnName) {
		if (smallTalkWebcomPage.checkForDisplay(btnName))
			reportPass("Button: " + btnName + " is displayed");
		else
			reportFail("Button: " + btnName + " is not displayed");
	}

	@Then("I verify the {string} tooltip content displayed correctly")
	public void i_verify_the_tooltip_content_displayed_correctly(String labelName) {
		String message = testDataMap.get(labelName);
		if (smallTalkWebcomPage.checkForTooltipMessage(labelName, message))
			reportPass("Label: " + labelName + " with content: " + message + " is displayed");
		else
			reportFail("Label: " + labelName + " with content: " + message + " is not displayed");
	}

	@Then("I verify the {string} error message")
	public void i_verify_the_error_message(String labelName) {
		String errorMessage = smallTalkWebcomPage.checkForErrorMessages(labelName, testDataMap.get(labelName));
		if (errorMessage != null)
			reportPass("Label: " + labelName + " with content: " + errorMessage + " is displayed");
		else
			reportFail("Label: " + labelName + " with content: " + errorMessage + " is not displayed");
	}

	@Then("I verify the All error messages")
	public void i_verify_the_All_error_messages() {
		List<String> errorMessage = smallTalkWebcomPage.checkForAllErrorMessages(testDataMap);
		if (errorMessage.size() == 0)
			reportPass("Error Messages: " + testDataMap.values().toString() + " is displayed");
		else
			reportFail("Error Messages: " + errorMessage.toString() + " is not displayed");
	}

	@Then("I mousehover the priority ranking tooltip")
	public void i_mousehover_the_priority_ranking_tooltip() {
		if (smallTalkWebcomPage.mouseHover())
			reportPass("Able to MouseHover the priority ranking tooltip icon");
		else
			reportFail("Unable to MouseHover the priority ranking tooltip icon");
	}
}