package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.BrokerageAndManagedAccountsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BrokerageAndManagedAccountsSteps extends ObjectBase{
	BrokerageAndManagedAccountsPage brokerageManagedAccountsPage=new BrokerageAndManagedAccountsPage();
	
	@Given("I verify {string} message should displayed") 
	public void i_verify_message_should_displayed(String message) {
		if (brokerageManagedAccountsPage.verifyAccessNoPrivateBankAccountsMsg(message))
			reportPass("Message is displayed " + message) ;
		else
			reportFail("Message is not displayed " + message);
	}
	@When("I click on Cancel button")
	public void i_click_on_Cancel_button() {
	   	if (brokerageManagedAccountsPage.clickOnCancel())
			reportPass("Cancel Button is present");
		else
			reportFail("Cancel Button is not present");
	}
	
	@Then("I should verify alert with No and Yes buttons")
	public void i_should_verify_alert_with_No_and_Yes_buttons() {    
		if (brokerageManagedAccountsPage.verifyNoYesButtons())
			reportPass("Yes,No Buttons are present");
		else
			reportFail("Yes,No Buttons are not present");
	}
	
	@When("I click on No button in Brokerage page")
	public void i_click_on_No_button_in_Brokerage_page() {
		if (brokerageManagedAccountsPage.clickOnNo())
			reportPass("No Button is clicked");
		else
			reportFail("No Button is not clicked");		
	}
	
	@Then("I verify Cancel and Continue buttons")
	public void i_verify_Cancel_and_Continue_buttons() {
		if (brokerageManagedAccountsPage.verifyCancelContinueButtons())
			reportPass("Cancel and Continue buttons are displaying");
		else
			reportFail("Cancel and Continue buttons are not displaying");		
	}
	
	@When("I click on Yes Button in Brokerage page")
	public void i_click_on_Yes_Button_in_Brokerage_page() {
		if (brokerageManagedAccountsPage.clickOnYes())
			reportPass("Yes Button is clicked");
		else
			reportFail("Yes Button is not clicked");
	}

}
