package com.wb.wol_web.steps;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.DebitCardCounterPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class DebitCardCounterSteps extends ObjectBase {

	DebitCardCounterPage debitCardCounterPage = new DebitCardCounterPage();

	@Then("Verify {string} field is not displayed in {string} page")
	public void verify_field_is_not_displayed_in_page(String fieldName, String pageName) {
		if (debitCardCounterPage.verifyFieldName(fieldName)) {
			reportPass("Field: " + fieldName + " is not present in page: " + pageName);
		} else {
			reportFail("Field: " + fieldName + " is present in page: " + pageName);
		}
	}

	@Given("I click on Update button and Validate alert error message")
	public void i_click_on_Update_button_and_Validate_alert_error_message() {
		String alertErrorMessage = jsonDataParser.getTestDataMap().get("AlertText");
		if (debitCardCounterPage.verifyAlertErrorMessage(alertErrorMessage)) {
			reportPass("Alert Error Message is available: " + alertErrorMessage);
		} else {
			reportFail("Alert Error Message is not available: " + alertErrorMessage);
		}
	}

	@Then("Verify {string} field is not displayed and Validate debit card counter message is not displayed in Transaction History page")
	public void verify_field_is_not_displayed_and_Validate_debit_card_counter_message_is_not_displayed_in_Transaction_History_page(
			String fieldName) {
		String messageDebitCardCounter = jsonDataParser.getTestDataMap().get("DebitCardCounterMessage");
		if ((debitCardCounterPage.verifyLabelName(fieldName))
				&& (debitCardCounterPage.verifyDebitCardCounterMessage(messageDebitCardCounter))) {
			reportPass("Label Name is not available: " + fieldName + " Message is not available: "
					+ messageDebitCardCounter);
		} else {
			reportFail("Label is available: " + fieldName + " Message is available: " + messageDebitCardCounter);
		}
	}
}
