
package com.wb.wol_web.steps;

import java.util.HashMap;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.RequestBankingSuppliesPage;
import com.wb.wol_web.pages.WebcomPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RequestBankingSuppliesSteps extends ObjectBase {

	RequestBankingSuppliesPage requestBankingSuppliesPage = new RequestBankingSuppliesPage();
	WebcomPage webcomPage = new WebcomPage();
	public HashMap<String, String> confirmDetails = new HashMap<>();

	@Then("^I should be in \"([^\"]*)\" page in request banking supplies flow$")
	public void i_should_be_in_the_page(String pageHeading) throws Throwable {
		if (requestBankingSuppliesPage.checkForThePageHeading(pageHeading)) {
			reportPass("Reached the page " + pageHeading);
		} else {
			reportFail("Page not found " + pageHeading);
		}

	}

	@Then("I  select the request supplies {string}")
	public void i_select_the_request_supplies(String supplies) {
		if (requestBankingSuppliesPage.clickOnSupplies(supplies)) {
			reportPass("Selected the supplies " + supplies);
		} else {
			reportHardFail("Failed to click on the supplies " + supplies);
		}
	}

	@When("I click on the request supplies button")
	public void i_click_on_the_request_supplies_button() throws Exception {
		if (requestBankingSuppliesPage.clickOnRequestSuppliesButton()) {
			reportPass("Clicked on request supplies button ");
		} else {
			reportHardFail("Failed to click on request supplies button");
		}
	}

	@Then("^I check if the supplies selected \"([^\"]*)\" are displayed correctly in confirmation page$")
	public void check_supplies_selected_are_displayed_corrrect(String suppliesSelected) {
		String suppliesUpdated = "";
		String suppliesNotUpdated = "";

		confirmDetails = requestBankingSuppliesPage.validateConfirmationDetails();
		for (String eachSupply : confirmDetails.get("Supplies Requested").split("\n")) {
			if (suppliesSelected.contains(eachSupply)) {
				suppliesUpdated = suppliesUpdated + eachSupply + ",";
			} else {
				suppliesNotUpdated = suppliesNotUpdated + eachSupply + ",";
			}
		}
		if (suppliesNotUpdated.equals("")) {
			reportPass("All the supplies selected are displayed correct in confirmation page " + suppliesUpdated);
		} else {
			reportFail("All the supplies selected are not displayed correct in confirmation page.Missing supplies are "
					+ suppliesNotUpdated);
		}
		if (!confirmDetails.get("Confirmation Date").equals("")) {
			reportPass("Confirmation Date is displayed correct in confirmation page "
					+ confirmDetails.get("Confirmation Date"));
		} else {
			reportFail("Confirmation Date is not displayed correct in confirmation page.");
		}
		if (!confirmDetails.get("Confirmation #").equals("")) {
			reportPass("Confirmation Number is displayed correct in confirmation page "
					+ confirmDetails.get("Confirmation #"));
		} else {
			reportFail("Confirmation Number is not displayed correct in confirmation page.");
		}

	}

	@Then("^I search for the confirmation date and username of \"([^\"]*)\" request type from the search result$")
	public void check_the_confirmation_Details(String reqtype) {
		if (requestBankingSuppliesPage.checkTheConfirmationDetailsInWebcom(reqtype,
				confirmDetails.get("Confirmation Date")))
			reportPass("Found the order details in webcom,Order for " + reqtype + " placed on "
					+ confirmDetails.get("Confirmation Date"));
		else
			reportFail("Failed to find the order details in webcom");
	}

	@Then("^I search for the activities list of request type \"([^\"]*)\" and click on search button in main page$")
	public void search_for_activites_list_of_type(String reqType) {
		try {
			webcomPage.clickOnSearchFromCustomerRequestActivitesResult();
			webcomPage.selectTheRequestType(reqType);
			webcomPage.clickOnSearchButtonInCustomerReqSearchResultMainPage();
			reportPass("Selected the request type " + reqType + " and clicked on search button");
		} catch (Exception e) {
			reportFail("Failed to select the request type");

		}
	}
}
