package com.wb.wol_web.steps;

import java.util.List;

import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.pages.TravelNotificationPage;
import cucumber.api.java.en.Then;

public class TravelNotificationSteps extends ObjectBase {

	TravelNotificationPage travelNotificationPage = new TravelNotificationPage();

	@Then("I should see the Travel access message as {string}")
	public void i_should_see_the_Travel_access_message_as(String message) {
		if (travelNotificationPage.checkAccessMessage(message))
			reportPass("Message: " + message + " is displayed");
		else
			reportFail("Message: " + message + " is not displayed");
	}

	@Then("I click on {string} button of Travel Notification page")
	public void i_click_on_button_of_Travel_Notification_Verification_page(String btnName) {
		if (travelNotificationPage.clickOnButtonTravelNotification(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I click on {string} button of Travel Notification Verification page")
	public void i_click_on_button_of_Travel_Notification_page(String btnName) {
		if (travelNotificationPage.clickOnButtonTravelNotifVerification(btnName))
			reportPass("Button: " + btnName + " is clicked");
		else
			reportFail("Button: " + btnName + " is not clicked");
	}

	@Then("I check for the error messages of {string}")
	public void i_check_for_the_error_messages_of(String pageName) {
		List<String> listNotificaitonMessages = travelNotificationPage.checkForErrorMessage(pageName, testDataMap);
		if (listNotificaitonMessages.size() == 0)
			reportPass("Messages: " + testDataMap.values().toString() + " are displayed");
		else
			reportFail("Messages in " + listNotificaitonMessages.toString() + " is not displayed");
	}

	@Then("I verify the customer name is displayed")
	public void i_verify_the_customer_name_is_displayed() {
		String customerName = travelNotificationPage.checkCustomerName();
		if (customerName != null)
			reportPass("Customer Name: " + customerName + " is displayed");
		else
			reportFail("Customer Name  is not displayed");
	}

	@Then("I enter the {string} Phone number in {string}")
	public void i_enter_the_Phone_number_in(String value, String fieldName) {
		if (travelNotificationPage.enterValueInField(value, fieldName))
			reportPass("Value: " + value + " is entered at field: " + fieldName);
		else
			reportFail("Value: " + value + " is not entered at field: " + fieldName);
	}

	@Then("I enter the {string} Date in {string}")
	public void i_enter_the_Date_in(String value, String fieldName) {
		if (travelNotificationPage.enterValueInField(value, fieldName))
			reportPass("Value: " + value + " is entered at field: " + fieldName);
		else
			reportFail("Value: " + value + " is not entered at field: " + fieldName);
	}

	@Then("I enter the {string} value in {string}")
	public void i_enter_the_value_in(String value, String fieldName) {
		if (travelNotificationPage.enterValueInField(value, fieldName))
			reportPass("Value: " + value + " is entered at field: " + fieldName);
		else
			reportFail("Value: " + value + " is not entered at field: " + fieldName);
	}

	@Then("I select the Debit card checkbox")
	public void i_select_the_Debit_card_checkbox() {
		if (travelNotificationPage.clickOnDebitCardCheckbox())
			reportPass("Debit card checkbox is checked");
		else
			reportFail("Debit card checkbox is not checked");
	}
}