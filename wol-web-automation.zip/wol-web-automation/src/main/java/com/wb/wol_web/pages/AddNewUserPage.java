package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class AddNewUserPage extends ObjectBase {

	public AddNewUserPage() {
		PageFactory.initElements(driver, this);
	}

	EnrollmentPage enrollmentPage = new EnrollmentPage();

	public LinkedHashMap<String, String> authorizedUserMap = new LinkedHashMap<String, String>();
	public LinkedHashMap<String, String> managedUserMap = new LinkedHashMap<String, String>();
	public String ssn;
	String rdbtnRole = "input[value='%s']";
	String rdbtnManageRole = "input[id='ROLE_IDs']";
	String rdbtnStatus = "input[id='STATUSV']";
	String txtAccounts = "table tbody tr:nth-child(number) td:nth-child(2)";
	String txtUserRole = "table tbody tr:nth-child(user) td:nth-child(4)";
	public String addNewUser;
	public List<String> businessAccts;
	public List<String> personalAccts;

	@FindBy(css = "table tbody tr")
	protected List<WebElement> tblManage;

	@FindBy(css = "div.midTopHeadingHolder > div > div > h1")
	protected WebElement txtPageTitle;

	@FindBy(css = "div.midTopHeadingHolder > div > div > p")
	protected WebElement txtPageContent;

	@FindBy(css = "#accept_tandc")
	protected WebElement chkDisclosure;

	@FindBy(css = "ul.listItem.disclosure  a")
	protected WebElement lnkDisclosure;

	@FindBy(css = "table > tbody > tr > td")
	protected List<WebElement> txtUserRoleInfo;

	@FindBy(css = "thead > tr > th  div")
	protected List<WebElement> txtUserRoleInfoLabels;

	@FindBy(css = "ul:nth-child(7) > li")
	protected List<WebElement> txtPageContentPoints;

	@FindBy(css = "ul.bulletListItem > li")
	protected List<WebElement> txtNotePoints;

	@FindBy(css = "div[class*='errorIndicator']")
	protected WebElement txtPageLevelErr;

	@FindBy(css = "div[class*='errorInline']")
	protected WebElement txtErrorMsg;

	@FindBy(css = "div[class*='errorInline']")
	protected List<WebElement> txtErrorMsgs;

	@FindBy(css = "h3#authorizedaccess")
	protected WebElement txtDisclosure;

	@FindBy(css = "div.ProdBodyBgShadow > div > p")
	protected WebElement txtUserNameNote;

	@FindBy(css = "#pageContent > p:nth-child(2)")
	protected WebElement txtComingledViewContent;

	@FindBy(css = "p[class='subsection-header']")
	protected List<WebElement> txtComingledViewLabels;

	@FindBy(css = "input[data-disclosure='B_addPersonalAccountConsent']")
	protected List<WebElement> chkPersonalAccounts;

	@FindBy(css = "input.account-select-checkbox[checked='checked']")
	protected List<WebElement> chkBusinessAccounts;

	@FindBy(css = "#disclosureContainer > p")
	protected WebElement txtConsentNote;

	@FindBy(css = "a.js-continue.webster-button-v2.webster-button-v2--calltoaction")
	protected WebElement lnkIConsent;

	@FindBy(css = "a.js-cancel.webster-button-v2.webster-button-v2--cancel")
	protected WebElement lnkIDontConsent;

	@FindBy(css = "table > tbody > tr > td")
	protected List<WebElement> txtCnfrmDetails;

	@FindBy(css = "#pageContent > p:nth-child(3)")
	protected WebElement txtCnfrmMsg;

	@FindBy(name = "cancel")
	protected WebElement btnCancelDisplay;

	@FindBy(css = "input[type='submit']")
	protected WebElement btnContinue;

	@FindBy(css = "input[Value='Continue']")
	protected WebElement btnContinue1;

	@FindBy(name = "firstname")
	protected WebElement txtFirstName;

	@FindBy(name = "middlename")
	protected WebElement txtMiddleName;

	@FindBy(name = "lastname")
	protected WebElement txtLastName;

	@FindBy(name = "address1")
	protected WebElement txtAddress1;

	@FindBy(name = "address2")
	protected WebElement txtAddress2;

	@FindBy(name = "city")
	protected WebElement txtCity;

	@FindBy(name = "state")
	protected WebElement cmbState;

	@FindBy(name = "zip")
	protected WebElement txtZipCode;

	@FindBy(name = "hphone1")
	protected WebElement txtHomePhone1;

	@FindBy(name = "hphone2")
	protected WebElement txtHomePhone2;

	@FindBy(name = "hphone3")
	protected WebElement txtHomePhone3;

	@FindBy(name = "bphone1")
	protected WebElement txtOfficePhone1;

	@FindBy(name = "bphone2")
	protected WebElement txtOfficePhone2;

	@FindBy(name = "bphone3")
	protected WebElement txtOfficePhone3;

	@FindBy(name = "ssn1")
	protected WebElement txtSocialSecurityNumber1;

	@FindBy(name = "ssn2")
	protected WebElement txtSocialSecurityNumber2;

	@FindBy(name = "ssn3")
	protected WebElement txtSocialSecurityNumber3;

	@FindBy(name = "date1")
	protected WebElement txtDateofBirthMonth;

	@FindBy(name = "date2")
	protected WebElement txtDateofBirthDate;

	@FindBy(name = "date3")
	protected WebElement txtDateofBirthYear;

	@FindBy(name = "email")
	protected WebElement txtEmailId;

	@FindBy(name = "nusername")
	protected WebElement txtUserName;

	@FindBy(css = "table")
	protected WebElement tblManageUser;

	@FindBy(css = "div[class='lightbox-wrap is-visible is-top'] button[aria-label='Close the dialog']")
	protected WebElement btnClose;

	@FindBy(css = "#ts > p")
	protected WebElement txtNameMismatch;

	@FindBy(css = "div.notification")
	protected WebElement txtSSNMismatchErr;

	@FindBy(css = "ul.nextsteps > li > a")
	protected List<WebElement> lnkNextSteps;

	@FindBy(css = "#pageContent > ul > li:nth-child(1) > a")
	protected WebElement lnkStartOver;

	@FindBy(css = "a[href*='ManageUsers'][class*='blue']")
	protected WebElement lnkManageUsers;

	@FindBy(css = "div.label")
	protected List<WebElement> txtManageUserCnfrmLabels;

	@FindBy(css = "div.data")
	protected List<WebElement> txtManageUserCnfrmValues;

	@FindBy(css = "#inactivityWarning")
	protected WebElement txtInactiveWarning;

	@FindBy(css = "#acctmessage")
	protected WebElement txtUserAcctInfo;

	@FindBy(css = "#pageContent > p")
	protected WebElement txtViewAcctInfo;

	@FindBy(css = "[data-wbst-message-key='authorizationaccess_name']")
	protected WebElement txtNameLabel;

	public boolean verifyNextSteps(Map<String, String> message) {
		return enrollmentPage.verifyListMesagses(lnkNextSteps, message, "NextSteps", "verifyNextSteps");
	}

	public boolean verifyLabelNames(Map<String, String> message) {
		return enrollmentPage.verifyListMesagses(txtComingledViewLabels, message, "Labels", "verifyLabelNames");
	}

	public boolean verifyUserRoleInfoLabels(Map<String, String> message) {
		return enrollmentPage.verifyListMesagses(txtUserRoleInfoLabels, message, "Headers", "verifyUserRoleInfoLabels");
	}

	public boolean verifyUserRoleInfo(Map<String, String> message) {
		return enrollmentPage.verifyListMesagses(txtUserRoleInfo, message, "Values", "verifyUserRoleInfo");
	}

	public boolean verifyPageNotePoints(Map<String, String> message) {
		return enrollmentPage.verifyListMesagses(txtNotePoints, message, "Points", "verifyPageNotePoints");
	}

	public boolean verifyPageContentPoints(Map<String, String> message) {
		return enrollmentPage.verifyListMesagses(txtPageContentPoints, message, "Contents", "verifyPageContentPoints");
	}

	public boolean verifyErrorMessages(Map<String, String> message) {
		return enrollmentPage.verifyListMesagses(txtErrorMsgs, message, "Error", "verifyPageContentPoints");
	}

	public boolean verifyUserAcctInfo(Map<String, String> message) {
		return wolWebUtil.verifyText(txtUserAcctInfo, message.get("Note"), "verifyUserAcctInfo");
	}

	public boolean verifyViewOnlyUserAcctInfo(Map<String, String> message) {
		return wolWebUtil.verifyText(txtViewAcctInfo, message.get("View-Only"), "verifyViewOnlyUserAcctInfo");
	}

	public boolean verifyPageContent(Map<String, String> message) {
		return wolWebUtil.verifyText(txtPageContent, message.get("Note1"), "verifyPageContent");
	}

	public boolean verifySSNErr(Map<String, String> message) {
		return wolWebUtil.verifyText(txtSSNMismatchErr, message.get("Error"), "verifySSNErr");
	}

	public boolean verifyInactiveWarningMsg(Map<String, String> message) {
		return wolWebUtil.verifyText(txtInactiveWarning, message.get("Warning"), "verifyInactiveWarningMsg");
	}

	public boolean verifyNameErr(Map<String, String> message) {
		return wolWebUtil.verifyText(txtNameMismatch, message.get("Error"), "verifyNameErr");
	}

	public boolean verifyConfirmMsg(Map<String, String> message) {
		return wolWebUtil.verifyText(txtCnfrmMsg, message.get("Confirmation"), "verifyConfirmMsg");
	}

	public void clickCloseButton() {
		wolWebUtil.clickWebElement(btnClose, "clickCloseButton");
	}

	public void clickContinueButton() {
		wolWebUtil.clickWebElement(btnContinue1, "clickContinueButton");
	}

	public void clickStartOver() {
		wolWebUtil.clickWebElement(lnkStartOver, "clickStartOver");
	}

	public void clickManageUsers() {
		wolWebUtil.clickWebElement(lnkManageUsers, "clickManageUsers");
	}

	public void clickDoNotConsentLink() {
		wolWebUtil.clickWebElement(lnkIDontConsent, "clickDoNotConsentLink");
	}

	public boolean verifyDisclosureText(Map<String, String> message) {
		return wolWebUtil.verifyText(txtPageTitle, message.get("Content"), "verifyDisclosureText");
	}

	public boolean verifyErrorMsg(Map<String, String> message) {
		return wolWebUtil.verifyText(txtErrorMsg, message.get("Error"), "verifyErrorMsg");
	}

	public boolean verifyPageLevelErrorMsg(Map<String, String> message) {
		return wolWebUtil.verifyText(txtPageLevelErr, message.get("Page Error"), "verifyPageLevelErrorMsg");
	}

	public boolean verifyConsentFormNote(Map<String, String> message) {
		return wolWebUtil.verifyText(txtConsentNote, message.get("Consent"), "verifyPageLevelErrorMsg");
	}

	public void clickIConsentLink() {
		wolWebUtil.clickWebElement(lnkIConsent, "clickIConsentLink");
	}

	public void clickIConsentLinkManage() {
		if (waits.waitUntilElementIsPresent(lnkIConsent, maxTimeOut))
			wolWebUtil.clickWebElement(lnkIConsent, "clickIConsentLink");
	}

	/**
	 * verifyPageTitle: To verify the Page Title of Add new user functionality
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyPageTitle(String message) {
		boolean flag = false;
		for (int i = 0; i < 10; i++) {
			flag = wolWebUtil.verifyText(txtPageTitle, message, "verifyPageTitle");
			if (flag == false)
				waits.staticWait(3);
			else
				break;
		}
		return flag;
	}

	/**
	 * verifyDisclosure: To verify the Authorized access agreement Disclosure
	 * 
	 * @return
	 */
	public boolean verifyDisclosure() {
		boolean flag = false;
		try {
			flag = webActions.isDisplayed(lnkDisclosure);
			LogUtility.logInfo("--->verifyDisclosure<--- <---", "Verified to Disclosure link");
		} catch (Exception e) {
			LogUtility.logException("verifyDisclosure", "Failed to Verify Disclosure link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * getConfirmDetails: To get the add new user confirmation details
	 * 
	 * @return
	 */
	public boolean getConfirmDetails() {
		try {
			for (int i = 1; i < txtCnfrmDetails.size() - 1; i++) {
				authorizedUserMap.put(txtCnfrmDetails.get(i).getText(), txtCnfrmDetails.get(i + 1).getText());
			}
			LogUtility.logInfo("--->getConfirmDetails<--- <---", "Retrieved add new user confirmation details");
		} catch (Exception e) {
			LogUtility.logException("getConfirmDetails", "Failed to Retrieve add new user confirmation details", e,
					LoggingLevel.ERROR, true);
		}
		return authorizedUserMap.isEmpty();
	}

	/**
	 * getManageUserDetails: To get Manage User confirmation Details
	 */
	public void getManageUserDetails() {
		try {
			for (int i = 1; i < txtManageUserCnfrmLabels.size(); i++) {
				managedUserMap.put(txtManageUserCnfrmLabels.get(i).getText(),
						txtManageUserCnfrmValues.get(i).getText());
			}
			LogUtility.logInfo("--->getManageUserDetails<--- <---", "Retrieved Manage user confirmation details");
		} catch (Exception e) {
			LogUtility.logException("getConfirmDetails", "Failed to Retrieve Manage user confirmation details", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * validateStatus: To validate the status value in Manage user confirmation page
	 * 
	 * @param status
	 * @return
	 */
	public boolean validateStatus(String status) {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			flag = managedUserMap.get("Status").equalsIgnoreCase(status);
			LogUtility.logInfo("--->validateStatus<--- <---",
					"Validated Status value in Manage User Access confirmation page");
		} catch (Exception e) {
			LogUtility.logException("validateStatus",
					"Failed to Validate Status value in Manage User Access confirmation page", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * validateUserRole: To validate the Role value in Manage user confirmation page
	 * 
	 * @param role
	 * @return
	 */
	public boolean validateUserRole(String role) {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			flag = managedUserMap.get("Role").equalsIgnoreCase(role);
			LogUtility.logInfo("--->validateUserRole<--- <---",
					"Validated Role value in Manage User Access confirmation page");
		} catch (Exception e) {
			LogUtility.logException("validateUserRole",
					"Failed to Validate Role value in Manage User Access confirmation page", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * clickAgreementLink: To click on Authorized acccess agreement link
	 * 
	 * @return
	 */
	public boolean clickAgreementLink() {
		boolean flag = false;
		try {
			wolWebUtil.clickWebElement(lnkDisclosure, "clickAgreementLink");
			if (txtDisclosure.isDisplayed()) {
				flag = true;
				LogUtility.logInfo("--->clickAgreementLink<--- <---", "Clicked on Authorized Access Agreement Link");
			} else
				LogUtility.logInfo("--->clickAgreementLink<--- <---",
						"Failed to Click on Authorized Access Agreement Link");
		} catch (Exception e) {
			LogUtility.logException("clickAgreementLink", "Failed to Click on Authorized Access Agreement Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectDisclosure: To select the disclosure
	 */
	public void selectDisclosure() {
		try {
			if (chkDisclosure.isDisplayed()) {
				webActions.clickElementJS(chkDisclosure);
				waits.waitForDOMready();
				LogUtility.logInfo("--->selectDisclosure<--- <---", "Accepted Disclosure");
			}
		} catch (Exception e) {
			LogUtility.logException("selectDisclosure", "Failed to Select disclosure", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectPersonalAccts: To select personal account check boxes
	 * 
	 * @param number
	 */
	public void selectPersonalAccts(int number) {
		try {
			for (int accounts = 0; accounts <= number; accounts++) {
				WebElement account = chkPersonalAccounts.get(accounts);
				if (!account.isSelected())
					webActions.clickElementJS(account);
				waits.waitForDOMready();
			}
			LogUtility.logInfo("--->selectPersonalAccts<--- <---", "Selected " + number + "Personal Accounts");
		} catch (Exception e) {
			LogUtility.logException("selectPersonalAccts", "Failed to Select Personal Accounts", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * deSelectPersonalAccts: To deselect personal account checkboxes
	 */
	public void deSelectPersonalAccts() {
		try {
			waits.waitForDOMready();
			for (WebElement element : chkPersonalAccounts) {
				if (element.isSelected())
					webActions.clickElementJS(element);
				waits.waitForDOMready();
			}
			LogUtility.logInfo("--->deSelectPersonalAccts<--- <---", "De Selected Personal Accounts");
		} catch (Exception e) {
			LogUtility.logException("deSelectPersonalAccts", "Failed to De Select Personal Accounts", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * verifyPersonalAccountsSelection: To verify whether personal accounts are
	 * selected or not
	 * 
	 * @return
	 */
	public boolean verifyPersonalAccountsSelection() {
		boolean flag = false;
		int count = 0;
		try {
			waits.waitForDOMready();
			for (WebElement element : chkPersonalAccounts) {
				if (!element.isSelected())
					count = count + 1;
			}
			if (count == chkPersonalAccounts.size()) {
				flag = true;
				LogUtility.logInfo("--->verifyPersonalAccountsSelection<--- <---",
						"Personal accounts are not auto selected");
			} else
				LogUtility.logInfo("--->verifyPersonalAccountsSelection<--- <---",
						"Personal accounts are  auto selected");

		} catch (Exception e) {
			LogUtility.logException("verifyPersonalAccountsSelection",
					"Failed to validate Personal accounts are  auto selected or not", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyBusinessAccountsSelection: To verify whether Business accounts are
	 * selected or not
	 * 
	 * @return
	 */
	public boolean verifyBusinessAccountsSelection() {
		boolean flag = false;
		int count = 0;
		try {
			waits.waitForDOMready();
			for (WebElement element : chkBusinessAccounts) {
				if (element.isSelected())
					count = count + 1;
			}
			if (count == chkBusinessAccounts.size()) {
				flag = true;
				LogUtility.logInfo("--->verifyBusinessAccountsSelection<--- <---",
						"Business accounts are  auto selected");
			} else
				LogUtility.logInfo("--->verifyBusinessAccountsSelection<--- <---",
						"Business accounts are  not auto selected");

		} catch (Exception e) {
			LogUtility.logException("verifyBusinessAccountsSelection", "Failed to check Business accounts selection", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * validateCommonAccounts: To validate the common accounts in Manage users page
	 * 
	 * @return
	 */
	public boolean validateCommonAccounts() {
		boolean flag = false;
		String account = null;
		ArrayList<String> accounts = new ArrayList<String>();
		try {
			int tblRows = tblManage.size();
			for (int row = 1; row <= tblRows; row++) {
				String getValue = driver.findElement(By.cssSelector(txtAccounts.replace("number", String.valueOf(row))))
						.getText();
				if (getValue.equals("Administrator") || getValue.equals("Transact User")) {
					WebElement text = driver
							.findElement(By.cssSelector(txtUserRole.replace("user", String.valueOf(row))));
					account = webActions.getText(text);
				}
				if (!(account == null))
					accounts.add(account);
			}
			for (int row = 0; row < accounts.size() - 1; row++) {
				flag = accounts.get(0).equals(accounts.get(row + 1));
			}
			LogUtility.logInfo("--->validateCommonAccounts<--- <---",
					"Validated accounts display in manage users page");
		} catch (Exception e) {
			LogUtility.logException("validateCommonAccounts",
					"Failed to Validate accounts display in manage users page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickUserName: To click on User name link in manage users page
	 * 
	 * @param value
	 */
	public void clickUserName(String value) {
		try {
			waits.waitUntilElementIsPresent(tblManageUser);
			wolWebUtil.clickOnTableCell(tblManageUser, value);
			for (int i = 0; i < 10; i++) {
				boolean flag = waits.waitUntilElementIsPresent(txtNameLabel, maxTimeOut);
				if (flag == false)
					waits.staticWait(3);
				else
					break;
			}
			LogUtility.logInfo("--->clickUserName<--- <---", "Clicked on user name in manage users page");
		} catch (Exception e) {
			LogUtility.logException("clickUserName", "Failed to click on user name in manage users page", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To Click on Continue button
	 * 
	 */
	public boolean clickOnContinueButton() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnContinue)) {
				webActions.clickElementJS(btnContinue);
				waits.waitForDOMready();
				if (!waits.waitUntilElementIsPresent(txtComingledViewContent)) {
					waits.waitForPageReadyState();
					waits.waitForPageToLoad(maxTimeOut);
				}
				LogUtility.logInfo("--->clickOnContinueButton<--- <---", "Clicked on Continue button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("--->clickOnContinueButton<--- <---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To Enter data for all the required fields
	 */

	public boolean enterDataForAllFields(Map<String, String> userData) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtEmailId);
			webActions.setValue(txtFirstName, userData.get("First Name"));
			webActions.setValue(txtMiddleName, userData.get("Middle Initial"));
			webActions.setValue(txtLastName, userData.get("Last Name"));
			webActions.setValue(txtAddress1, userData.get("Street Address"));
			webActions.setValue(txtAddress2, userData.get("Street Address Line 2"));
			webActions.setValue(txtCity, userData.get("City"));
			webActions.selectDropDownByValueJs(cmbState, userData.get("State"));
			webActions.setValue(txtZipCode, userData.get("Zip"));
			webActions.setValue(txtHomePhone1, userData.get("HPhone1"));
			webActions.setValue(txtHomePhone2, userData.get("HPhone2"));
			webActions.setValue(txtHomePhone3, userData.get("HPhone3"));
			webActions.setValue(txtOfficePhone1, userData.get("OPhone1"));
			webActions.setValue(txtOfficePhone2, userData.get("OPhone2"));
			webActions.setValue(txtOfficePhone3, userData.get("OPhone3"));
			ssn = userData.get("SSN");
			if (ssn.equalsIgnoreCase("random")) {
				webActions.setValue(txtSocialSecurityNumber1, wolWebUtil.getRandomNumber(3));
				webActions.setValue(txtSocialSecurityNumber2, wolWebUtil.getRandomNumber(2));
				webActions.setValue(txtSocialSecurityNumber3, wolWebUtil.getRandomNumber(4));
			} else {
				webActions.setValue(txtSocialSecurityNumber1, ssn.substring(0, 3));
				webActions.setValue(txtSocialSecurityNumber2, ssn.substring(3, 5));
				webActions.setValue(txtSocialSecurityNumber3, ssn.substring(5, 9));
			}
			String date[] = userData.get("Date of Birth").split("/");
			webActions.setValueJs(txtDateofBirthMonth, date[0]);
			webActions.setValueJs(txtDateofBirthDate, date[1]);
			webActions.setValueJs(txtDateofBirthYear, date[2]);
			webActions
					.clickElementJS(driver.findElement(By.cssSelector(rdbtnRole.replace("%s", userData.get("Role")))));
			webActions.setValue(txtEmailId, userData.get("Email Address"));
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtEmailId, "value").equalsIgnoreCase(userData.get("Email Address"))) {
				flag = true;
				LogUtility.logInfo("--->enterDataForAllFields<---", "Entered data for all the fields");
			} else
				LogUtility.logInfo("--->enterDataForAllFields<---", "Failed to Enter data for all the fields");
		} catch (Exception e) {
			LogUtility.logException("enterDataForAllFields", "Failed to Enter data for all the fields", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * updateSSN: To update SSN value
	 * 
	 * @param userData
	 * @return
	 */
	public boolean updateSSN(Map<String, String> userData) {
		if (waits.waitUntilElementIsPresent(txtSocialSecurityNumber3)) {
			boolean flag = false;
			try {
				waits.waitUntilElementIsPresent(txtSocialSecurityNumber3);
				ssn = userData.get("Update SSN");
				if (ssn.equalsIgnoreCase("random")) {
					ssn = wolWebUtil.getRandomNumber(9);
				}
				webActions.setValue(txtSocialSecurityNumber1, ssn.substring(0, 3));
				webActions.setValue(txtSocialSecurityNumber2, ssn.substring(3, 5));
				webActions.setValue(txtSocialSecurityNumber3, ssn.substring(5, 9));
				waits.waitForDOMready();
				if (webActions.getAttributeValue(txtSocialSecurityNumber3, "value")
						.equalsIgnoreCase(ssn.substring(5, 9))) {
					flag = true;
					LogUtility.logInfo("--->updateSSN<---", "Updated SSN");
				} else
					LogUtility.logInfo("--->updateSSN<---", "Failed to Update SSN");
			} catch (Exception e) {
				LogUtility.logException("updateSSN", "Failed to update SSN", e, LoggingLevel.ERROR, true);
			}
			return flag;
		} else
			return true;
	}

	/**
	 * selectRole: To select user role
	 * 
	 * @param role
	 */
	public void selectRole(String role) {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			webActions.clickElementJS(driver.findElement(By.cssSelector(rdbtnManageRole.replace("s", role))));
			waits.waitForPageReadyState(maxTimeOut);
			LogUtility.logInfo("--->selectRole<---", "Selected user role");
		} catch (Exception e) {
			LogUtility.logException("selectRole", "Failed to update SSN", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * updateStatus: To update the status of the user
	 * 
	 * @param status
	 */
	public void updateStatus(String status) {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			webActions.clickElementJS(driver.findElement(By.cssSelector(rdbtnStatus.replace("V", status))));
			waits.waitForPageReadyState(maxTimeOut);
			LogUtility.logInfo("--->updateStatus<---", "updated the status of the user");
		} catch (Exception e) {
			LogUtility.logException("updateStatus", "Failed to update the status of the user", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * To Enter data in the User name field
	 * 
	 */
	public boolean enterUserNameForSupportUser(Map<String, String> userData) {
		boolean flag = false;
		try {
			addNewUser = userData.get("User Name");
			if (addNewUser.equalsIgnoreCase("random"))
				addNewUser = wolWebUtil.getRandomString(9);
			webActions.setValue(txtUserName, addNewUser);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtUserName, "value").equalsIgnoreCase(addNewUser)) {
				flag = true;
				LogUtility.logInfo("--->enterUserNameForSupportUser<---",
						"Entered User name for adding new user" + addNewUser);
			} else
				LogUtility.logInfo("--->enterUserNameForSupportUser<---",
						"Failed to Enter User name for adding new user");
		} catch (Exception e) {
			LogUtility.logException("enterUserNameForSupportUser", "Failed to Enter User name for adding new user", e,
					LoggingLevel.ERROR, true);
		}
		setValueInRuntimeDataMap("addNewWOLUser", addNewUser);
		return flag;
	}

}
