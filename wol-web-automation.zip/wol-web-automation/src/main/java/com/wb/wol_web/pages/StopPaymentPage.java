package com.wb.wol_web.pages;

/**
 * @author Ramesh Pagadala
 *
 */
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class StopPaymentPage extends ObjectBase {

	public StopPaymentPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "continue")
	protected WebElement btnContinue;

	@FindBy(name = "check_number")
	protected WebElement inputCheckNumber;

	@FindBy(css = "div#bodyContent h1")
	protected WebElement txtPageTitle;

	@FindBy(css = "div[data-wbst-message-key='no_number']")
	protected WebElement txtEnterCheckNumberMessage;

	@FindBy(css = "div#pageContent span:nth-of-type(2)")
	protected WebElement txtduplicateCheckNumberMessage;

	@FindBy(css = "/h1[data-wbst-message-key='relatedservices.stoppayment.confirm']")
	protected WebElement txtConfirmStopPaymentPageTitle;

	@FindBy(css = "h1[data-wbst-message-key='relatedservices.stoppayment.verify']")
	protected WebElement txtVerifyPageTitle;

	@FindBy(css = "div#pageContent>div")
	protected WebElement txtConfirmStopPaymentMessage;

	@FindBy(css = "div.note ")
	protected WebElement txtNote;

	public String checkNumber = "";

	/**
	 * enterCheckNumber-to enter random 8 digit check number
	 * 
	 * @return
	 */
	public String enterCheckNumber() {
		try {
			checkNumber = wolWebUtil.getRandomNumber(8);
			if (webActions.isDisplayed(inputCheckNumber)) {
				webActions.setValue(inputCheckNumber, checkNumber);
				LogUtility.logInfo("--->enterCheckNumber<---", "able to enter a check number: " + checkNumber);
				return checkNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterCheckNumber<-", "Not able to enter a check number", e, LoggingLevel.ERROR,
					true);
		}
		return null;
	}

	/**
	 * confirmationMessage-to check the successful stop payment confirmation message
	 * 
	 */
	public boolean confirmationMessage(String message) {
		try {
			if (wolWebUtil.verifyTextContains(txtConfirmStopPaymentMessage, message)) {
				LogUtility.logInfo("--->confirmationMessage<---", message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->confirmationMessage<-", message + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * clickOnContinueButton-to click on continue button
	 * 
	 */
	public boolean clickOnContinueButton() {
		try {
			waits.waitForPageReadyState();
			if (webActions.isDisplayed(btnContinue)) {
				webActions.clickElement(btnContinue);
				LogUtility.logInfo("--->clickOnContinueButton<---", " able to click on continue button");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnContinueButton<-", "Not able to click on continue button", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkPageTitle-to check the page Title
	 * 
	 */
	public boolean checkPageTitle(String pageHeading, String flowName) {
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			waits.staticWait(5);
			if (wolWebUtil.verifyTextContains(txtPageTitle, pageHeading)) {
				LogUtility.logInfo("--->checkPageTitle<---", "Redirected to the " + pageHeading + "page ");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkPageTitle<-", "Not Redirected to the " + pageHeading + "page ", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * getEnterCheckNumberMessage- To get the check number message when we dont
	 * enter check number
	 * 
	 */
	public boolean getEnterCheckNumberMessage(String message) {
		try {
			waits.waitForPageReadyState();
			if (wolWebUtil.verifyTextContains(txtEnterCheckNumberMessage, message)) {
				LogUtility.logInfo("--->getEnterCheckNumberMessage<---",
						"Check number messages is displayed as: " + message);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->getEnterCheckNumberMessage<-",
					"Check number messages is not displayed as: " + message, e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterCheckNumberAgain- To enter the same check number again
	 * 
	 */
	public String enterCheckNumberAgain() {
		try {
			waits.waitForPageReadyState();
			if (webActions.isDisplayed(inputCheckNumber)) {
				webActions.setValue(inputCheckNumber, checkNumber);
				LogUtility.logInfo("--->enterCheckNumberAgain<---", "Able to enter a check number: " + checkNumber);
				return checkNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterCheckNumberAgain<-", "Not able to enter a check number: " + checkNumber, e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * duplicateCheckNumberError- To validate the duplicate check number error
	 * message
	 */
	public boolean duplicateCheckNumberError(String message) {
		try {
			if (wolWebUtil.verifyTextContains(txtduplicateCheckNumberMessage, message)) {
				LogUtility.logInfo("--->duplicateCheckNumberError<---",
						"Able to see the duplicate check number error message as: " + message);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->duplicateCheckNumberError<-",
					"Not able to see the duplicate check number error message as: " + message, e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkNoteMessage : To check the note message
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkNoteMessage(String message) {
		try {
			if (wolWebUtil.verifyTextContains(txtNote, message)) {
				LogUtility.logInfo("--->checkNoteMessage<---", "Message: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkNoteMessage<-", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}
}
