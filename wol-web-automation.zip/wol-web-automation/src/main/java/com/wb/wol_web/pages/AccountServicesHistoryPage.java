
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class AccountServicesHistoryPage extends ObjectBase {

	public AccountServicesHistoryPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "#pageContent thead th>div")
	protected List<WebElement> listLablesAccountHistory;

	public List<String> checkForLabels(Map<String, String> testDataMap) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		String labelName = "";
		List<String> listLabels = new ArrayList<String>();
		try {
			waits.waitForPageReadyState();
			for (WebElement detail : listLablesAccountHistory) {
				labelName = webActions.getText(detail);
				if (testDataMap.containsValue(labelName)) {
					LogUtility.logInfo("-->checkForLabels<--", labelName + " is present");
				} else
					listLabels.add(labelName);
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForLabels--", "Labels are not present: " + listLabels.toString(), e,
					LoggingLevel.ERROR, true);
		}
		return listLabels;
	}
}
