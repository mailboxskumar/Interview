package com.wb.wol_web.pages;

/**
 * @author Ramesh Pagadala
 *
 */
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.testbases.WOLTestBase;

public class CustomerInformationWebcomPage extends ObjectBase {

	public CustomerInformationWebcomPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "username")
	protected WebElement inputUsername;

	@FindBy(css = "input[value='Show Details']")
	protected WebElement btnShowDetails;

	@FindBy(name = "email")
	protected WebElement inputEmail;

	@FindBy(css = "input[value='Save']")
	protected WebElement btnSave;

	@FindAll({ @FindBy(css = "div[class='page-body'] div[class='message']"),
			@FindBy(css = "div[class='page-body'] div[class='message--error']") })
	protected WebElement txtUpdateMessage;

	@FindBy(css = "div#pageContent strong")
	protected WebElement txtCurrentEmail;

	@FindBy(name = "Address1")
	protected WebElement inputAddress;

	@FindBy(css = "label[data-wbst-message-key='profile.update_password_username.username']~strong")
	protected WebElement labelCurrentUserName;

	@FindBy(name = "driver_license")
	protected WebElement inputDriverLicense;

	@FindBy(name = "first_name")
	protected WebElement inputFirstName;

	@FindBy(name = "last_name")
	protected WebElement inputLastName;

	@FindBy(name = "username")
	private WebElement txtUserName;

	@FindBy(css = "table#customerDetail td:nth-of-type(2)")
	protected WebElement txtUpdatedUsernameWebcom;

	@FindBy(id = "answer1__error-message-text")
	protected WebElement txtErrorBlacklistWords;

	@FindBy(css = "div.formRow:nth-child(7) > div:nth-child(1) > label")
	protected WebElement labelNewUserName;

	@FindBy(name = "username")
	protected WebElement inputNewUserName;

	public String value = "";
	public String CurrentValue = "";

	/**
	 * searchUsername: To search the user name
	 * 
	 * @param userName
	 * @return
	 */
	public boolean searchUsername(String userName) {
		waits.waitForDOMready();
		try {
			waits.waitUntilElementIsPresent(inputUsername, maxTimeOut);
			if (webActions.isDisplayed(inputUsername)) {
				webActions.setValue(inputUsername, userName);
				webActions.clickElement(btnShowDetails);
				LogUtility.logInfo("--->searchUsername<---", "Searched with username: " + userName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->searchUsername<--", "Unable to search the username", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * enterValueInInputField : To enter the value in the field
	 * 
	 * @param fieldName
	 * @return
	 */
	public String enterValueInInputField(String fieldName) {
		waits.waitForDOMready();
		try {
			WebElement inputField = null;
			switch (fieldName) {
			case "Email":
				inputField = inputEmail;
				break;
			case "Address":
				inputField = inputAddress;
				break;
			case "Username":
				inputField = inputUsername;
				break;
			case "DriverLicense":
				inputField = inputDriverLicense;
				break;
			case "FirstName":
				inputField = inputFirstName;
				break;
			case "LastName":
				inputField = inputLastName;
				break;
			default:
				LogUtility.logInfo("--->enterValueInInputField<---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(inputField)) {
				value = wolWebUtil.getRandomString(2) + webActions.getAttributeValue(inputField, "value");
				webActions.setValue(inputField, value);
				LogUtility.logInfo("--->enterValueInInputField<---", "Updated the " + fieldName + " as " + value);
				return value;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterValueInInputField<--", "Unable to search the username", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * clickOnButton : To click on the button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(btnSave, maxTimeOut);
			if (webActions.isDisplayed(btnSave)) {
				webActions.clickElement(btnSave);
				LogUtility.logInfo("--->clickOnButton<---", "clicked on " + btnName + " button");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "Unable to click on button", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * getUpdateMessage : To get the update message
	 * 
	 * @param message
	 * @param labelName
	 * @return
	 */
	public boolean getUpdateMessage(String message) {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtUpdateMessage, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtUpdateMessage, message)) {
					LogUtility.logInfo("--->getUpdateMessage<---", message + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->getUpdateMessage<--", "Unable to get update message", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyUpdatedValue : To verify the updated value is matching or not
	 * 
	 * @param labelName
	 * @param txtValue
	 * @return
	 */
	public String verifyUpdatedValue(String labelName) {
		try {
			waits.waitForDOMready();
			WebElement fieldName = null;
			switch (labelName) {
			case "Email":
				fieldName = txtCurrentEmail;
				break;
			case "Username":
				fieldName = labelCurrentUserName;
				break;
			default:
				LogUtility.logInfo("--->verifyUpdatedValue<---", "No case match found");
				break;
			}
			if (wolWebUtil.verifyTextContains(fieldName, value)) {
				LogUtility.logInfo("--->verifyUpdatedValue<---", "Updated the " + fieldName + " as " + value);
				return value;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyUpdatedValue<--", "Unable to verify the updated value", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkUsername : To check User name and enter new value in user name field
	 * 
	 * @param userName
	 * @return
	 */
	public String checkUsername(String userName) {
		try {
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(labelNewUserName, maxTimeOut);
//			String txtNewUserName = webActions.getText(labelNewUserName);
			if (waits.waitUntilElementIsPresent(inputNewUserName, maxTimeOut)) {
				 String	name = WOLTestBase.envProps.getProperty(userName);
					webActions.setValue(inputNewUserName, name);
					LogUtility.logInfo("--->checkUsername<---", "new user name: " + name);
				return name;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkUsername<--", "Unable to check the username", e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * enterUserName: To enter Username
	 * 
	 * @param userName
	 * @return
	 */
	public String enterUserName(String labelName) {
		try {
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(txtUserName, maxTimeOut);
			if (webActions.isDisplayed(txtUserName)) {
				webActions.setValue(txtUserName, value);
				LogUtility.logInfo("---> enterUserName <---", "Entered the username " + value);
				return value;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterUserName<--", "Unable to enter the username", e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * verifyValue : To verify the value at given label
	 * 
	 * @param message
	 * @param labelName
	 * @return
	 */
	public boolean verifyValue(String message, String labelName) {
		try {
			waits.waitForDOMready();
			WebElement fieldName = null;
			switch (labelName) {
			case "Answer":
				fieldName = txtErrorBlacklistWords;
				break;
			case "username":
				message = WOLTestBase.envProps.getProperty(message);
				fieldName = txtUpdatedUsernameWebcom;
				break;
			default:
				LogUtility.logInfo("--->verifyValue<---", "No case match found");
				break;
			}
			if (wolWebUtil.verifyTextContains(fieldName, message)) {
				LogUtility.logInfo("--->verifyValue<---", message + " is displayed at " + fieldName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyValue<--", "Unable to verify the value", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	public String resetValueInInputField(String fieldName) {
		waits.waitForDOMready();
		try {
			WebElement inputField = null;
			switch (fieldName) {
			case "Email":
				inputField = inputEmail;
				break;
			case "Address":
				inputField = inputAddress;
				break;
			case "Username":
				inputField = inputUsername;
				break;
			case "DriverLicense":
				inputField = inputDriverLicense;
				break;
			case "FirstName":
				inputField = inputFirstName;
				break;
			case "LastName":
				inputField = inputLastName;
				break;
			default:
				LogUtility.logInfo("--->resetValueInInputField<---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(inputField)) {
				webActions.setValue(inputField, CurrentValue);
				LogUtility.logInfo("--->resetValueInInputField<---", "Updated the " + fieldName + " as " + value);
				return value;
			}
		} catch (Exception e) {
			LogUtility.logException("-->resetValueInInputField<--", "Unable to reset the value in input field", e,
					LoggingLevel.ERROR, true);
		}
		return null;

	}

}