
package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class UpgradeWebsterAccountsPage extends ObjectBase {

	public UpgradeWebsterAccountsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "[name='accountid']+label")
	protected List<WebElement> listAccountNames;

	@FindBy(name = "continue")
	protected WebElement btnContinue;

	@FindBy(name = "cancel")
	protected WebElement btnCancel;

	@FindBy(name = "yes")
	protected WebElement btnYesPopup;

	@FindBy(name = "no")
	protected WebElement btnNoPopup;

	@FindBy(css = "[class='upgrade_account_title']")
	protected List<WebElement> listAccountNameTitles;

	@FindBy(css = "#lightboxContent0 h2")
	protected WebElement txtLightboxTitle;

	@FindBy(css = "p[data-wbst-message-key='upgrade_center.confirm.description']")
	protected WebElement txtProcessInfo;

	@FindBy(css = "[data-wbst-message-key='upgrade_center.description']")
	protected WebElement txtProductDescInfo;

	@FindBy(css = "[class='pageHeaderBlock']>[data-wbst-message-key='upgrade_center.select.product.description']+p")
	protected WebElement txtProductUpgradeDescInfo;

	@FindBy(css = "[type='checkbox']")
	protected List<WebElement> listCheckboxDisclosure;

	@FindBy(css = "[type='checkbox']+a")
	protected List<WebElement> listDisclosureNames;

	@FindBy(css = "#pageContent div.labeldata div.label")
	protected List<WebElement> listUpgradeConfirmationLabels;

	@FindBy(css = "#pageContent [data-wbst-message-key='upgrade_center.error.noaccounts']")
	protected WebElement txtNoAccountsMessage;

	@FindBy(css = ".lightbox-wrap.is-visible.is-top  [aria-label='Close the dialog']")
	protected WebElement btnClose;

	@FindBy(css = "[data-wbst-message-key='general.disclosure.error.message']")
	protected WebElement txtDisclosureError;

	@FindBy(css = "h2 strong")
	protected WebElement txtPageTitle;

	@FindAll({ @FindBy(css = ".lightbox-wrap.is-visible.is-top #subHeaderContainer h1 strong"),
			@FindBy(css = ".lightbox-wrap.is-visible.is-top #subHeaderContainer h1") })
	protected WebElement txtLightboxPageTitle;

	public String txtAccountName = "(//span[@class='upgrade_account_title']";
	public String btnAccountName = "/following-sibling::span/button";
	public String txtAccountNameMiddlePath = ")[";
	public String txtAccountNameEndingPath = "]";
	public String linkMoreInfo = "//span[contains(text(),'%s')]/parent::div/parent::div/following-sibling::div[@class='upgrade_account_body']/p/a";

	/**
	 * selectAccountRadioButton: To select the account radio button
	 * 
	 * @param accountName
	 * @return
	 */
	public String selectAccountRadioButton(String accountName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement account : listAccountNames) {
				if (wolWebUtil.verifyTextContains(account, accountName)) {
					webActions.clickElement(driver.findElement(By.id(webActions.getAttributeValue(account, "for"))));
					LogUtility.logInfo("--->selectAccountRadioButton<---", "Account: " + accountName + " is selected");
					return webActions.getText(account);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->selectAccountRadioButton<--", "Account: " + accountName + " is not selected", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * clickOnButton: To click on the button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement btnToBeClick = null;
		try {
			switch (btnName) {
			case "Continue":
				btnToBeClick = btnContinue;
				break;
			case "Cancel":
				btnToBeClick = btnCancel;
				break;
			case "Yes":
				btnToBeClick = btnYesPopup;
				break;
			case "No":
				btnToBeClick = btnNoPopup;
				break;
			case "Close":
				btnToBeClick = btnClose;
				break;
			default:
				LogUtility.logInfo("--->clickOnButton<---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(btnToBeClick)) {
				//No and Yes buttons in pop-up window is taking time to load in firefox
				waits.staticWait(5);
				webActions.clickElement(btnToBeClick);
				LogUtility.logInfo("--->clickOnButton<---", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "Button: " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectAccountUpgradeButton: To select the upgrade button of Account type
	 * 
	 * @param accountType
	 * @return true
	 */
	public boolean selectAccountUpgradeButton(String accountType) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement upgradeButton = null;
		WebElement accountName = null;

		try {
			for (int index = 1; index < listAccountNameTitles.size(); index++) {
				accountName = driver.findElement(By.xpath(
						String.format(txtAccountName + txtAccountNameMiddlePath + index + txtAccountNameEndingPath)));
				if (wolWebUtil.verifyTextContains(accountName, accountType)) {
					upgradeButton = driver.findElement(By.xpath(String.format(txtAccountName + btnAccountName
							+ txtAccountNameMiddlePath + index + txtAccountNameEndingPath)));
					webActions.clickElement(upgradeButton);
					LogUtility.logInfo("--->selectAccountUpgradeButton<---",
							"Account: " + accountType + ": upgrade button is clicked");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->selectAccountUpgradeButton<--",
					"Account: " + accountType + ": upgrade button is not clicked", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyText: To verify the lightbox Title
	 * 
	 * @param txtHeading
	 * @return
	 */
	public boolean verifyLightboxText(String txtHeading) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtLightboxTitle, txtHeading)) {
				LogUtility.logInfo("--->verifyLightboxText<---", "Heading: " + txtHeading + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyLightboxText<--", "Heading: " + txtHeading + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyButton: To verify the button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean verifyButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement btnToCheck = null;
		try {
			switch (btnName) {
			case "Continue":
				btnToCheck = btnContinue;
				break;
			case "Cancel":
				btnToCheck = btnCancel;
				break;
			default:
				LogUtility.logInfo("--->verifyButton<---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(btnToCheck)) {
				LogUtility.logInfo("--->verifyButton<---", "Button: " + btnName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyButton<--", "Button: " + btnName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * acceptAllCheckboxes: To accept all check-boxes
	 * 
	 * @return
	 */
	public boolean acceptAllCheckboxes() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement checkbox : listCheckboxDisclosure) {
				webActions.clickElement(checkbox);
			}
			LogUtility.logInfo("--->acceptAllCheckboxes<---", "All checkboxes are accepted");
			return true;
		} catch (Exception e) {
			LogUtility.logException("-->acceptAllCheckboxes<--", "Checkboxes are not accepted", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyDisclosuresLinkText: To verify the disclosures link text
	 * 
	 * @param testDataMap
	 * @return
	 */
	public boolean verifyDisclosuresLinkText(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement eleDisclosureName : listDisclosureNames) {
				String name = webActions.getText(eleDisclosureName);
				if (testDataMap.values().toString().contains(name)) {
					LogUtility.logInfo("--->verifyDisclosuresLinkText<---", "Disclouser link text is verified");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyDisclosuresLinkText<--", "Disclouser link text is not verified", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkDisplay: To verify the text in process status
	 * 
	 * @param testDataMap
	 * @return
	 */
	public boolean checkDisplay(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			String name = webActions.getText(txtProcessInfo);
			if (testDataMap.values().toString().contains(name)) {
				LogUtility.logInfo("--->checkDisplay<---",
						"Text: " + testDataMap.values().toString() + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("--->checkDisplay<---",
					"Text: " + testDataMap.values().toString() + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	public boolean verifyLabels(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement elementLabel : listUpgradeConfirmationLabels) {

				String name = webActions.getText(elementLabel);
				if (testDataMap.values().toString().contains(name)) {
					LogUtility.logInfo("--->checkDisplay<---",
							"Text: " + testDataMap.values().toString() + " is displayed");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("--->checkDisplay<---",
					"Text: " + testDataMap.values().toString() + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkNoAccountDisplayMessage: To check the no accounts message display
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkNoAccountDisplayMessage(String message) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtNoAccountsMessage, message)) {
				LogUtility.logInfo("--->checkNoAccountDisplayMessage<---", "Text: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("--->checkNoAccountDisplayMessage<---", "Text: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyAccountRadioButton: To verify the account radio button is displayed
	 * 
	 * @param accountName
	 * @return
	 */
	public boolean verifyAccountRadioButton(String accountName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement account : listAccountNames) {
				if (wolWebUtil.verifyTextContains(account, accountName)) {
					LogUtility.logInfo("--->verifyAccountRadioButton<---", "Account: " + accountName + " is displayed");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyAccountRadioButton<--", "Account: " + accountName + " is not displayed",
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyText: To verify the text
	 * 
	 * @param message
	 * @param labelName
	 * @return boolean
	 */
	public boolean verifyText(String message, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement txtToVerify = null;
		try {
			switch (labelName) {
			case "Description Note":
				txtToVerify = txtProductDescInfo;
				break;
			case "Product Note":
				txtToVerify = txtProductUpgradeDescInfo;
				break;
			default:
				LogUtility.logInfo("--->verifyText<---", "No case match found");
				break;
			}
			if (wolWebUtil.verifyTextContains(txtToVerify, message)) {
				LogUtility.logInfo("--->verifyText<---", "Text: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyText<--", "Text: " + message + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyDisclosureErrorText : To verify the disclosure error text is displayed
	 * 
	 * @param message
	 * @return boolean
	 */
	public boolean verifyDisclosureErrorText(String message) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtDisclosureError, message)) {
				LogUtility.logInfo("--->verifyDisclosureErrorText<---", "Text: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyDisclosureErrorText<--", "Text: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnMoreInfoOfAccount : To click on More Info of parameter Account
	 * 
	 * @param accountName
	 * @return
	 */
	public boolean clickOnMoreInfoOfAccount(String accountName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			webActions.clickElement(driver.findElement(By.xpath(String.format(linkMoreInfo, accountName))));
			LogUtility.logInfo("--->clickOnMoreInfoOfAccount<---",
					"Account: " + accountName + ", more info is clicked");
			return true;
		} catch (Exception e) {
			LogUtility.logException("-->clickOnMoreInfoOfAccount<--",
					"Account: " + accountName + ", more info is not clicked", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyPageTitle: To verify the page Title
	 * 
	 * @param pageName
	 * @return boolean
	 */
	public boolean verifyPageTitle(String pageName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtPageTitle, pageName)) {
				LogUtility.logInfo("--->verifyPageTitle<---", "Page Name : " + pageName + " is displayed");
				return true;
			} else
				LogUtility.logError("--->verifyPageTitle<---", "Page Name : " + pageName + " is not displayed");
		} catch (Exception e) {
			LogUtility.logException("-->verifyPageTitle<--", "Page Name : " + pageName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyLightboxPageTitle : To verify the lightbox page title
	 * 
	 * @param pageName
	 * @return boolean
	 */
	public boolean verifyLightboxPageTitle(String pageName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		// TODO: Lightbox is taking time to load
		waits.staticWait(5);
		try {
			if (wolWebUtil.verifyTextContains(txtLightboxPageTitle, pageName)) {
				LogUtility.logInfo("--->verifyLightboxPageTitle<---", "Page Name : " + pageName + " is displayed");
				return true;
			} else
				LogUtility.logError("--->verifyLightboxPageTitle<---", "Page Name : " + pageName + " is not displayed");
		} catch (Exception e) {
			LogUtility.logException("-->verifyLightboxPageTitle<--", "Page Name : " + pageName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}
}