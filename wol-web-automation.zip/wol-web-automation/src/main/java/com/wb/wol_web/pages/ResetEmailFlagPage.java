package com.wb.wol_web.pages;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class ResetEmailFlagPage extends ObjectBase {

	public ResetEmailFlagPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "thead>tr>th")
	private List<WebElement> lstResetEmailFlag;

	@FindBy(css = "input[name='email_invalid_ind']+label")
	private List<WebElement> lstEmailFlag;

	@FindBy(css = "input[name='email_invalid_ind']+label:first-of-type")
	private WebElement lblInvalidEmailFlag;

	@FindBy(css = "input[name='email_invalid_ind']:first-of-type")
	private WebElement radioInvalidEmailFlag;

	@FindBy(css = "input[name='email_invalid_ind']+label:nth-of-type(2)")
	private WebElement lblValidEmailFlag;

	@FindBy(css = "input[name='email_invalid_ind']:nth-of-type(2)")
	private WebElement radioValidEmailFlag;

	@FindBy(css = "input[type='submit']")
	private WebElement btnSubmit;

	@FindBy(css = ".message")
	private WebElement msgEmailFlagUpdation;

	@FindBy(css = "#update-invalid-email-optional__pageTitle_gen")
	private WebElement pageTitleOfEmailAddress;

	@FindBy(css = "#email_valid_yes__labelCaption")
	private WebElement lblYesEmail;

	@FindBy(css = "#email_valid_no__labelCaption")
	private WebElement lblNoEmail;

	@FindBy(css = "#email_valid_no__input")
	private WebElement radioNoEmail;

	@FindBy(id = "new_email__label")
	private WebElement lblNewEmail;

	@FindBy(id = "new_email_conf__label")
	private WebElement lblRetypeEmail;

	@FindBy(id = "new_email__input")
	private WebElement txtNewEmail;

	@FindBy(id = "new_email_conf__input")
	private WebElement txtRetypeEmail;

	@FindBy(css = "button[type='submit']")
	private WebElement btnContinue;

	@FindBy(css = "tr:nth-child(2) > td:nth-child(6) > a")
	private WebElement btnView;

	@FindBy(css = "td:nth-of-type(3)>b")
	private WebElement lblNewInformation;

	@FindBy(css = "td:nth-of-type(4)>b")
	private WebElement lblOldInformation;

	@FindBy(css = "tr:nth-of-type(3) td:nth-of-type(3)")
	private WebElement txtNewInformation;

	@FindBy(css = "tr:nth-of-type(3) td:nth-of-type(4)")
	private WebElement txtOldInformation;

	@FindBy(css = "#email_valid_yes__input")
	private WebElement radioYes;

	@FindBy(css = "#new_email__error-message-text")
	private WebElement msgNewEmailError;

	@FindBy(css = "#new_email_conf__error-message-text")
	private WebElement msgRetypeEmailError;

	/**
	 * verifyDefaultSelection - To verify default selection of the radio buttons
	 * 
	 * @return flag
	 */
	public boolean verifyDefaultSelection(String fieldName, String labelName) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			WebElement defaultLabelSelection = null;
			WebElement defaultSelection = null;
			switch (fieldName) {
			case "Invalid":
				defaultLabelSelection = lblInvalidEmailFlag;
				defaultSelection = radioInvalidEmailFlag;
				break;
			case "Valid":
				defaultLabelSelection = lblValidEmailFlag;
				defaultSelection = radioValidEmailFlag;
				break;
			default:
				LogUtility.logInfo("--->verifyDefaultSelection<---", "Default condition is matched");
				break;
			}
			if ((defaultLabelSelection != null) && (defaultSelection != null))
				if (wolWebUtil.verifyTextContains(defaultLabelSelection, fieldName)) {
					if (webActions.isChecked(defaultSelection)) {
						LogUtility.logInfo("--->verifyDefaultSelection<---",
								"radio button is defaulted to " + fieldName);
						flag = true;
					} else
						LogUtility.logInfo("--->verifyDefaultSelection<---",
								"radio button is not defaulted to " + fieldName);
				} else
					LogUtility.logInfo("--->verifyDefaultSelection<---", "radio button is not displayed " + labelName);
		} catch (Exception e) {
			LogUtility.logException("-->verifyDefaultSelection<--", "default selection is not working properly", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnButton - To click on the button
	 * 
	 * @param fieldName
	 * @param labelName
	 * @return flag
	 */
	public boolean clickOnButton(String fieldName, String labelName) {
		boolean flag = false;
		WebElement radioSelection = null;
		try {
			switch (fieldName) {
			case "Invalid":
				radioSelection = radioInvalidEmailFlag;
				break;
			case "Submit":
				radioSelection = btnSubmit;
				break;
			case "Valid":
				radioSelection = radioValidEmailFlag;
				break;
			default:
				LogUtility.logInfo("--->clickOnButton<---", "Default condition is matched");
				break;
			}
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			if (radioSelection != null) {
				if (webActions.isDisplayed(radioSelection)) {
					webActions.clickElement(radioSelection);
					LogUtility.logInfo("--->clickOnButton<---", fieldName + " is clicked");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "click on button is not working properly", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyMessage - To verify message after updating Email flag
	 * 
	 * @param msgDescription
	 * @param labelName
	 * @return flag
	 */
	public boolean verifyMessage(String msgDescription, String labelName) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			if (webActions.isDisplayed(msgEmailFlagUpdation)) {
				if (wolWebUtil.verifyText(msgEmailFlagUpdation, msgDescription)) {
					LogUtility.logInfo("--->verifyMessage<---", msgDescription + " received");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyMessage<--", "email flag updation message is not populated correctly", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyTitle - To verify the page title
	 * 
	 * @param pageTitle
	 * @return flag
	 */
	public boolean verifyTitle(String pageTitle) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			if (wolWebUtil.verifyText(pageTitleOfEmailAddress, pageTitle)) {
				LogUtility.logInfo("--->verifyTitle<---", "Navigated to " + pageTitle + " page");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyTitle<--", "email address page title is not populated correctly", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyButtons - To verify presence of email buttons
	 * 
	 * @param labelYes
	 * @param labelNo
	 * @return flag
	 */
	public boolean verifyEmailLabels(String labelYes, String labelNo) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			if (webActions.isDisplayed(lblYesEmail)) {
				LogUtility.logInfo("--->verifyEmailLabels<---", labelYes + " Label is present");
				if (webActions.isDisplayed(lblNoEmail)) {
					LogUtility.logInfo("--->verifyEmailLabels<---", labelNo + " Label is present");
					flag = true;
				} else
					LogUtility.logInfo("--->verifyEmailLabels<---", labelNo + " Label is not present");
			} else
				LogUtility.logInfo("--->verifyEmailLabels<---", labelYes + " Label is not present");
		} catch (Exception e) {
			LogUtility.logException("-->verifyEmailLabels<--", "email address labels are not populated correctly", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * checkForEmailAddress - To verify presence of email fields
	 * 
	 * @param newEmail
	 * @param retypeEmail
	 * @return flag
	 */
	public boolean checkForEmailAddress(String newEmail, String retypeEmail) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			// Need to wait for page loading to run in IE browser
			waits.staticWait(3);
			if (webActions.isDisplayed(lblNewEmail)) {
				LogUtility.logInfo("--->checkForEmailAddress<---", newEmail + " Label is present");
				if (webActions.isDisplayed(lblRetypeEmail)) {
					LogUtility.logInfo("--->checkForEmailAddress<---", retypeEmail + " Label is present");
					flag = true;
				} else
					LogUtility.logInfo("--->checkForEmailAddress<---", retypeEmail + " Label is not present");
			} else
				LogUtility.logInfo("--->checkForEmailAddress<---", newEmail + " Label is not present");
		} catch (Exception e) {
			LogUtility.logException("-->checkForEmailAddress<--",
					"email address labels verification is not done correctly", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyDefaultSelect - To verify default selection of radio button
	 * 
	 * @param labelNo
	 * @return flag
	 */
	public boolean verifyDefaultSelection(String labelNo) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			if (webActions.isDisplayed(lblNoEmail)) {
				if (webActions.isChecked(radioNoEmail)) {
					LogUtility.logInfo("--->verifyDefaultSelection<---", "radio button is defaulted to " + labelNo);
					flag = true;
				} else
					LogUtility.logInfo("--->verifyDefaultSelection<---", "radio button is not defaulted to " + labelNo);
			} else
				LogUtility.logInfo("--->verifyDefaultSelection<---", "radio button is not displayed " + labelNo);
		} catch (Exception e) {
			LogUtility.logException("-->verifyDefaultSelection<--",
					"default selection of radio buttons is not completed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * enterEmailAddress - To enter email address in email address fields
	 * 
	 * @param newEmailAddress
	 * @return flag
	 */
	public boolean enterEmailAddress(String newEmailAddress) {
		boolean flag = false;
		try {
			String randomEmailAddress = "";
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			switch (newEmailAddress) {
			case "AutoIT1234@websterbank.com":
				randomEmailAddress = wolWebUtil.getRandomString(4) + newEmailAddress;
				webActions.setValue(txtNewEmail, randomEmailAddress);
				LogUtility.logInfo("--->enterEmailAddress<---",
						randomEmailAddress + " Email is entered in new email address");
				webActions.setValue(txtRetypeEmail, randomEmailAddress);
				LogUtility.logInfo("--->enterEmailAddress<---",
						randomEmailAddress + " Email is entered in Retype email address");
				flag = true;
				break;
			case "AutoITIS1234@websterbank.com":
				randomEmailAddress = wolWebUtil.getRandomString(6) + newEmailAddress;
				webActions.setValue(txtNewEmail, newEmailAddress);
				LogUtility.logInfo("--->enterEmailAddress<---",
						newEmailAddress + " Email is entered in new email address");
				webActions.setValue(txtRetypeEmail, randomEmailAddress);
				LogUtility.logInfo("--->enterEmailAddress<---",
						randomEmailAddress + " Email is entered in Retype email address");
				flag = true;
				break;
			case "blank":
				webActions.setValue(txtNewEmail, randomEmailAddress);
				LogUtility.logInfo("--->enterEmailAddress<---", newEmailAddress + " is entered in new email address");
				webActions.setValue(txtRetypeEmail, randomEmailAddress);
				LogUtility.logInfo("--->enterEmailAddress<---",
						newEmailAddress + " is entered in Retype email address");
				flag = true;
				break;
			default:
				LogUtility.logInfo("--->enterEmailAddress<---", "Default condition is matched");
				break;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterEmailAddress<--",
					"email address is not entered in all the required fields", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickButton - To click on continue button
	 * 
	 * @param btnName
	 * @return flag
	 */
	public boolean clickButton(String btnName) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			WebElement btnClick = null;
			switch (btnName) {
			case "Continue":
				btnClick = btnContinue;
				break;
			case "View":
				btnClick = btnView;
				break;
			case "Yes":
				btnClick = radioYes;
				break;
			default:
				LogUtility.logInfo("--->clickButton<---", "Default condition is matched");
				break;
			}
			if (btnClick != null) {
				if ((webActions.isDisplayed(btnClick))) {
					webActions.clickElement(btnClick);
					LogUtility.logInfo("--->clickButton<---", btnName + " Button is clicked");
					flag = true;
				} else
					LogUtility.logInfo("--->clickButton<---", btnName + " Button is not clicked");
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickButton<--", "button click is not successful", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyLabelValues - To verify values of the labels
	 * 
	 * @param value
	 * @param label
	 * @return flag
	 */
	public boolean verifyLabelValues(String value, String label) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			WebElement labelName = null;
			WebElement verifyLabelValue = null;
			switch (value) {
			case "Valid":
				labelName = lblNewInformation;
				verifyLabelValue = txtNewInformation;
				break;
			case "Invalid":
				labelName = lblOldInformation;
				verifyLabelValue = txtOldInformation;
				break;
			default:
				LogUtility.logInfo("--->verifyLabelValues<---", "Default condition is matched");
				break;
			}
			if ((labelName != null) && (verifyLabelValue != null)) {
				if (wolWebUtil.verifyTextContains(labelName, label)) {
					LogUtility.logInfo("--->verifyLabelValues<---", labelName + " Label Name is present");
					if (wolWebUtil.verifyTextContains(verifyLabelValue, value)) {
						LogUtility.logInfo("--->verifyLabelValues<---",
								"Value of the label is correctly displayed as " + verifyLabelValue);
						flag = true;
					} else
						LogUtility.logInfo("--->verifyLabelValues<---"
								+ "Value of the label is incorrectly displayed as " + verifyLabelValue);
				} else
					LogUtility.logInfo("--->verifyLabelValues<---", labelName + " Label Name is not present");
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyLabelValues<--", "label name and values verification is not successful",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyEmailErrorMsg - To verify Email Error Message in New Email and ReType
	 * Email Address fields when both id's are different
	 * 
	 * @param invalidEmailMsg
	 * @return flag
	 */
	public boolean verifyEmailErrorMsg(String invalidEmailMsg) {
		boolean flag = false;
		try {
			if (wolWebUtil.verifyText(msgNewEmailError, invalidEmailMsg)) {
				LogUtility.logInfo("--->verifyEmailErrorMsg<---",
						"Invalid message is received at New Email Address field: " + invalidEmailMsg);
				if (wolWebUtil.verifyText(msgRetypeEmailError, invalidEmailMsg)) {
					LogUtility.logInfo("--->verifyEmailErrorMsg<---",
							"Invalid message is received at Retype Email Address field: " + invalidEmailMsg);
					flag = true;
				} else
					LogUtility.logInfo("--->verifyEmailErrorMsg<---",
							"Invalid message is not received at Retype Email Address field: " + invalidEmailMsg);
			} else
				LogUtility.logInfo("--->verifyEmailErrorMsg<---",
						"Invalid message is not received at New Email Address field: " + invalidEmailMsg);
		} catch (Exception e) {
			LogUtility.logException("-->verifyEmailErrorMsg<--",
					"Invalid message is not received at New/ Retype Email Address fields", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyBlankErrorMsg - To verify error message when blank is entered in New
	 * Email and Re-Type email address fields
	 * 
	 * @param blankErrorMsg
	 * @return flag
	 */
	public boolean verifyBlankErrorMsg(String blankErrorMsg) {
		boolean flag = false;
		WebElement verifyMsg = null;
		try {
			waits.waitForPageReadyState();
			switch (blankErrorMsg) {
			case "Please enter your new email address.":
				verifyMsg = msgNewEmailError;
				break;
			case "Please verify your new email address.":
				verifyMsg = msgRetypeEmailError;
				break;
			default:
				LogUtility.logInfo("--->verifyBlankErrorMsg<---", "Default condition is matched");
				break;
			}
			if (verifyMsg != null) {
				if (wolWebUtil.verifyTextContains(verifyMsg, blankErrorMsg)) {
					LogUtility.logInfo("--->verifyBlankErrorMsg<---",
							"Correct error message is displayed: " + blankErrorMsg);
					flag = true;
				} else
					LogUtility.logInfo("--->verifyBlankErrorMsg<---",
							"Incorrect error message is displayed: " + blankErrorMsg);
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyBlankErrorMsg<--", "Blank errror message is not received", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * checkForFields - To verify two fields for a label
	 *
	 * @param fieldNameFirst
	 * @param fieldNameSecond
	 * @param labelName
	 * @return flag
	 */
	public boolean checkForFields(String fieldNameFirst, String fieldNameSecond, String labelName) {
		boolean flag = false;
		List<WebElement> lstCheck = null;
		int count = 0;
		try {
			switch (labelName) {
			case "Reset Invalid Email Flag Fields":
				lstCheck = lstResetEmailFlag;
				break;
			case "Email Flag":
				lstCheck = lstEmailFlag;
				break;
			default:
				LogUtility.logInfo("--->checkForFields<---", "Default condition is matched");
				break;
			}
			int labelSize = lstCheck.size();
			if (lstCheck != null) {
				for (WebElement ele : lstCheck) {
					if (wolWebUtil.verifyTextContains(ele, fieldNameFirst)) {
						LogUtility.logInfo("--->checkForFields<---", "Field Name is available: " + fieldNameFirst);
						count++;
					}
					if (wolWebUtil.verifyTextContains(ele, fieldNameSecond)) {
						LogUtility.logInfo("--->checkForFields<---", "Field Name is available: " + fieldNameSecond);
						count++;
					}
				}
			}
			if (labelSize == count)
				flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->checkForFields<--", "label name and field name is not working properly", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

}