package com.wb.wol_web.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class BrokerageAndManagedAccountsPage extends ObjectBase {
	public BrokerageAndManagedAccountsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='mainSiteNav__submenu1__menuLabel']")
	protected WebElement lblMenuAccounts;

	@FindBy(linkText = "Private Bank Accounts")
	protected WebElement lnkPrivateBankAccounts;

	@FindBy(xpath = "//h1[@data-wbst-message-key='sei-iracma-header_title']")
	protected WebElement lblAccessPrivateBankAccounts;

	@FindBy(css = "[id='pageContent'] >p:nth-child(1)")
	protected WebElement txtAccessPrivateBankAccounts;

	@FindBy(css = "a[name=cancel]")
	protected WebElement btnCancel;

	@FindBy(css = "a[name=no]")
	protected WebElement btnNo;

	@FindBy(css = "a[name=yes]")
	protected WebElement btnYes;

	@FindBy(css = "#continue")
	protected WebElement btnContinue;

	/**
	 * verifyAccessNoPrivateBankAccountsMsg: To verify the error message in the
	 * Private Bank Accounts Page
	 *
	 * @return flag
	 */
	public boolean verifyAccessNoPrivateBankAccountsMsg(String msg) {
		boolean flag = false;
		try {
			// Need static wait to run in IE browser
			waits.staticWait(3);
			waits.waitUntilElementIsPresent(txtAccessPrivateBankAccounts, maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtAccessPrivateBankAccounts, msg)) {
				flag = true;
				LogUtility.logInfo("-->verifyAccessNoPrivateBankAccountsMsg<--",
						"Error message displayed in Private Bank Accounts page");
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyAccessNoPrivateBankAccountsMsg<--",
					"Error message not displayed in Private Bank Accounts page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnCancel: To click on Cancel button
	 *
	 * @return flag
	 */
	public boolean clickOnCancel() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnCancel, maxTimeOut);
			webActions.clickElement(btnCancel);
			flag = true;
			LogUtility.logInfo("-->clickOnCancel<--", "Cancel button is clicked");
		} catch (Exception e) {
			LogUtility.logException("-->clickOnCancel<--", "Cancel button is not clicked", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyNoYesButtons: To verify Yes and No buttons are displayed
	 * 
	 * @return flag
	 */
	public boolean verifyNoYesButtons() {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			// Need static wait to run in IE browser
			waits.staticWait(3);
			if ((webActions.isDisplayed(btnNo)) && (webActions.isDisplayed(btnYes))) {
				LogUtility.logInfo("-->verifyNoYesButtons<--", "No and Yes Buttons are displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyNoYesButtons<--", "Yes and No button is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnNo: To click on No button
	 *
	 * @return flag
	 */
	public boolean clickOnNo() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnNo, maxTimeOut);
			if (webActions.isDisplayed(btnNo)) {
				webActions.clickElement(btnNo);
				flag = true;
				LogUtility.logInfo("-->clickOnNo<--", "No button is clicked");
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnNo<--", "No button is not clicked", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyCancelContinueButtons: To verify Cancel and Continue buttons are
	 * displayed
	 * 
	 * @return flag
	 */
	public boolean verifyCancelContinueButtons() {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			// Need static wait to run in IE browser
			waits.staticWait(3);
			if ((webActions.isDisplayed(btnCancel)) && (webActions.isDisplayed(btnContinue))) {
				flag = true;
				LogUtility.logInfo("-->verifyCancelContinueButtons<--", "Cancel and Continue buttons are displayed.");
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyCancelContinueButtons<--",
					"Continue and Cancel buttons are not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnYes: To click on Yes button
	 * 
	 * @return flag
	 */
	public boolean clickOnYes() {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			// Need static wait to run in IE browser
			waits.staticWait(3);
			waits.waitUntilElementIsPresent(btnYes, maxTimeOut);
			if (webActions.isDisplayed(btnYes)) {
				webActions.clickElement(btnYes);
				flag = true;
				LogUtility.logInfo("-->clickOnYes<--", "Yes button is clicked");
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnYes<--", "Yes button is not clicked", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

}