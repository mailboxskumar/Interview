package com.wb.wol_web.pages;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class QuickLinksPage extends ObjectBase {

	public QuickLinksPage() {
		PageFactory.initElements(driver, this);
	}

	@FindAll(@FindBy(xpath = "//ul[@id='quickLinks_menu__list' ]//li[@data-mm-is-active='true']//a"))
	protected List<WebElement> quickLinksList;

	@FindBy(id = "editButton")
	protected WebElement btnEditLinks;

	@FindBy(id = "quickLinkLibrary_button_clear")
	protected WebElement btnDeselectAll;

	@FindBy(id = "quickLinkLibrary_button_submit__buttonText")
	protected WebElement btnSubmit;

	@FindBy(id = "quickLinkLibrary_button_cancel")
	protected WebElement btnCancel;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle1' ]")
	protected WebElement lightBox;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle1' ]//button[text()='Close']")
	protected WebElement btnLightBoxClose;

	@FindAll(@FindBy(xpath = "//input[@name='userQuicklinkIds' and @disabled='disabled']"))
	protected List<WebElement> disabledLinks;

	@FindBy(id = "transaction_history_no_accounts__pageErrors__transaction_history_no_accounts__pageError__body")
	protected WebElement txtNoTransactionHistryMsg;

	@FindBy(id = "transfer_no_accounts__pageErrors__transfer_no_accounts__pageError__body")
	protected WebElement txtNoTranfersMsg;

	@FindBy(id = "error-no-billpay-account__pageErrors__error-no-billpay-account__pageError__body")
	protected WebElement txtNoOneTimeBillPayMsg;

	@FindBy(css = "div[data-wbst-message-key=statement-no-statements-message]")
	protected WebElement txtNoStatementsMsg;

	@FindBy(xpath = "//div[@id='pageContent']/div[1]")
	protected WebElement txtUnAuthorizedUserMsg;

	@FindAll(@FindBy(xpath = "//input[@name='userQuicklinkIds']/../span"))
	protected List<WebElement> lstLinksNames;

	@FindAll(@FindBy(xpath = "//*[contains(@for,'quickLink_chooser__option')]"))
	protected List<WebElement> lstLinkLabels;

	@FindBy(id = "quickLinksArea")
	protected WebElement quickLinkContainer;

	@FindBy(id = "smallTalkContainer")
	protected WebElement smallTalkContainer;

	@FindBy(id = "quickLink_chooser__label")
	protected WebElement txtForMax4Links;

	@FindBy(id = "quickLinks_maxLinks_warning_message__body")
	protected WebElement txtForMoreThan4Links;

	@FindBy(id = "quickLinks_noLinks_warning_message__body")
	protected WebElement txtDeselectAll;

	/**
	 * Checks no of quick links present in the summary page
	 * 
	 * @Author:Sneha K
	 * @Created on: May 8th 2019
	 * @Modified on:
	 * @return
	 */
	public String checkQuickLinkSize() {
		String links = "";
		try {
			if (quickLinksList.size() <= 4) {
				for (WebElement eachlink : quickLinksList) {
					links = links + webActions.getText(eachlink);
				}
				LogUtility.logInfo("---> checkQuickLinkSize <---", "Quick Links present are " + links);
			} else {
				LogUtility.logError("---> checkQuickLinkSize <---",
						"More than 4 links present in summary page " + links);
			}
		} catch (Exception e) {
			LogUtility.logException("checkQuickLinkSize", "More than 4 links present in summary page", e,
					LoggingLevel.ERROR, true);
		}
		return links;
	}

	/*
	 * To click on the button based on the button name
	 * 
	 * @Author:Sneha K
	 * 
	 * @Created on: May 1st 2019
	 * 
	 * @Modified on:
	 * 
	 * @param btnName
	 */
	public boolean clickOnTheButton(String btnName) throws Exception {
		boolean status = false;
		WebElement eleToClick = null;
		try {
			switch (btnName) {
			case "Edit":
				eleToClick = btnEditLinks;
				break;
			case "LightBoxClose":
				eleToClick = btnLightBoxClose;
				break;
			case "DeselectAll":
				eleToClick = btnDeselectAll;
				break;
			case "Submit":
				eleToClick = btnSubmit;
				break;
			case "Cancel":
				eleToClick = btnCancel;
				break;
			default:
				break;
			}

			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(eleToClick);
			if (webActions.isDisplayed(eleToClick)) {
				webActions.clickElementJS(eleToClick);
				status = true;
			} else {
				LogUtility.logError("---> clickOnTheButton <---", "Element not found " + eleToClick);
			}
			LogUtility.logInfo("---> clickOnTheButton <---", "Clicked on the button " + btnName);
		} catch (Exception e) {
			LogUtility.logException("clickOnTheButton", "Exception in clicking on the button " + btnName, e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/*
	 * To check if lightbox is present for Quicklinks Edit function
	 * 
	 * @Author:Sneha K
	 * 
	 * @Created on: May 1st 2019
	 * 
	 * @Modified on:
	 * 
	 * @param btnName
	 */
	public boolean checkForLightBox() {

		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(lightBox);
			if (webActions.isDisplayed(lightBox)) {
				status = true;
				LogUtility.logInfo("---> checkForLightBox <---", "Lightbox for quicklinks is present");
			}
		} catch (Exception e) {
			LogUtility.logException("checkForLightBox", "Exception in finding Lightbox for quicklinks", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/*
	 * To check if lightbox is present for Quicklinks Edit function
	 * 
	 * @Author:Sneha K
	 * 
	 * @Created on: May 1st 2019
	 * 
	 * @Modified on:
	 * 
	 * @param btnName
	 */
	public boolean checkForButtonsDisplayed(String btnName) {
		boolean status = false;
		try {
			WebElement eleToCheck = null;
			switch (btnName) {
			case "Cancel":
				eleToCheck = btnCancel;
				break;
			case "Submit":
				eleToCheck = btnSubmit;
				break;
			case "DeselectAll":
				eleToCheck = btnDeselectAll;
				break;
			case "Close":
				eleToCheck = btnLightBoxClose;
				break;
			default:
				LogUtility.logError("checkForButtonsDisplayed", "Invlaid button to check the presence " + btnName);
			}
			if (webActions.isDisplayed(eleToCheck)) {
				status = true;
				LogUtility.logInfo("--->checkForButtonsDisplayed<---", btnName + " button is displayed");
			} else {
				LogUtility.logError("---> checkForButtonsDisplayed <---", "Element not found " + btnName);
			}

		} catch (Exception e) {
			LogUtility.logException("checkForButtonsDispalyed", "Exception in finding the button " + btnName, e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/*
	 * To check for the message in the page
	 * 
	 * @Author:Sneha K
	 * 
	 * @Created on: May 9th 2019
	 * 
	 * @Modified on:
	 * 
	 * @param btnName
	 */
	public boolean CheckForTheMessage(String msg, String msgType) {
		WebElement eleToGetText = null;
		boolean status = false;
		try {
			switch (msgType) {
			case "EditQuickLinksTitle":
				eleToGetText = txtForMax4Links;
				break;
			case "DeselectAllTitle":
				eleToGetText = txtDeselectAll;
				break;
			case "SelectMorethan4Links":
				eleToGetText = txtForMoreThan4Links;
				break;
			default:
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText);
			if (webActions.getText(eleToGetText).equals(msg)) {
				status = true;
				LogUtility.logInfo("---> CheckForTheMessage <---", "message is present " + msg);
			} else
				LogUtility.logError("---> CheckForTheMessage <---", "Message not found " + msg);
		} catch (Exception e) {
			LogUtility.logException("CheckForTheMessage", "Exception in finding the message " + msg, e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/*
	 * To check that no link is disabled to select
	 * 
	 * @Author:Sneha K
	 * 
	 * @Created on: May 9th 2019
	 * 
	 * @Modified on:
	 * 
	 * @param btnName
	 */
	public boolean checkNoLinksAreDisabled() {
		boolean status = false;
		try {
			if (disabledLinks == null || disabledLinks.size() == 0) {
				status = true;
				LogUtility.logInfo("---> checkNoLinksAreDisabled <---", "All links are enabled to click");
			} else
				LogUtility.logError("---> checkNoLinksAreDisabled <---", "All links are not enabled to clik");
		} catch (Exception e) {
			LogUtility.logException("checkNoLinksAreDisabled", "Exception in finding the links", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/*
	 * To check that quick link are displayed according to the user type
	 * 
	 * @Author:Sneha K
	 * 
	 * @Created on: May 9th 2019
	 * 
	 * @Modified on:
	 * 
	 * @param btnName
	 */
	public String checkLinkNamesAreCorrect(String userType, Map<String, String> linksList) {
		String actualLinksPresent = "";
		try {
			for (WebElement eachLink : lstLinksNames) {
				if (linksList.containsKey(webActions.getText(eachLink).trim())) {
					actualLinksPresent += webActions.getText(eachLink) + ",";
				}
			}
			LogUtility.logInfo("---> checkLinkNamesAreCorrect <---", "quicklinks present are " + actualLinksPresent);
		} catch (Exception e) {
			LogUtility.logException("checkLinkNamesAreCorrect", "Exception in finding the quicklinks", e,
					LoggingLevel.ERROR, true);
		}
		return actualLinksPresent;
	}

	/**
	 * TO check the position of the quicklink container when smalltalk container is
	 * present
	 * 
	 * @return true if small talk container lies below Quicklist container
	 */
	public boolean checkTheSmallTalkContainerPosition() {
		boolean status = false;
		try {
			int smallTalkY = wolWebUtil.getThePosition(smallTalkContainer).getY();
			int quickLinkY = wolWebUtil.getThePosition(quickLinkContainer).getY();
			if (smallTalkY - quickLinkY > 0) {
				status = true;
				LogUtility.logInfo("---> checkTheSmallTalkContainerPosition <---",
						"Small Talk Container is positioned below the Quick Link Container");
			} else
				LogUtility.logError("---> checkTheSmallTalkContainerPosition <---",
						"Small Talk Container is not  positioned below the Quick Link Container");
		} catch (Exception e) {
			LogUtility.logException("checkTheSmallTalkContainerPosition",
					"Exception in finding the quicklinks container", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To click on the links given in the parameters
	 * 
	 * @param links
	 * @throws Exception
	 */
	public void clickOnTheLinks(String links) throws Exception {
		try {
			for (String eachLinkName : links.split(","))
				for (WebElement eachLink : lstLinkLabels) {
					if (webActions.getAttributeValue(eachLink, "data-bdm-text").equals(eachLinkName)) {
						webActions.clickElement(eachLink.findElement(By.tagName("input")));
						LogUtility.logInfo("--->clickOnTheLinks<---", "Clicked on the link " + eachLinkName);
						break;
					}
				}
		} catch (Exception e) {
			LogUtility.logException("clickOnTheLinks", "Exception in clicking on the quicklink", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * To click on the links given in the parameters from summary page
	 * 
	 * @param links
	 * @throws Exception
	 */
	public boolean clickOnTheLinksInSummaryPage(String link) throws Exception {
		boolean status = false;
		try {
			waits.waitForDOMready();
			waits.staticWait(5);// Not working with other waits
			for (WebElement eachLink : quickLinksList) {
				if (webActions.getText(eachLink).equals(link)) {
					webActions.clickElementJS(eachLink);
					LogUtility.logInfo("--->clickOnTheLinksInSummaryPage<---",
							"Clicked on the link  in summary page" + link);
					waits.waitForDOMready();
					waits.staticWait(3);
					status = true;
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnTheLinksInSummaryPage",
					"Exception in clicking on the quicklink in summary page", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check if the links given from argument are present in the summary page
	 * 
	 * @param links-contains the list of links to be checked separated by ','
	 * @return string - links which are not in summary page separated by ","
	 * @throws Exception
	 */
	public String checkTheLinkNamesInSummaryPage(String links) throws Exception {
		String elementPresent = "";
		try {
			waits.waitForPageReadyState(maxTimeOut);
			waits.waitForPageToLoad(maxTimeOut);
			for (WebElement eachLink : quickLinksList) {
				waits.waitUntilElementIsPresent(eachLink);
				if (links.contains(webActions.getText(eachLink).trim())) {
					elementPresent += webActions.getText(eachLink) + ",";
				}
			}
			LogUtility.logInfo("---> checkTheLinkNamesInSummaryPage <---",
					"Links present in summary page are " + links);
		} catch (Exception e) {
			LogUtility.logException("checkTheLinkNamesInSummaryPage",
					"Exception in finding the quicklink in summary page", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return elementPresent;
	}

	/**
	 * returns the size of the disabled links
	 * 
	 * @return
	 */
	public int getTheSizeOfDisabledLinks() {
		int size;
		try {
			size = disabledLinks.size();
			LogUtility.logInfo("--->getTheSizeOfDisabledLinks<---", "Size is " + size);
		} catch (Exception e) {
			LogUtility.logException("getTheSizeOfDisabledLinks", "Exception in getting the size of diasbled links", e,
					LoggingLevel.ERROR, true);
		}
		return disabledLinks.size();
	}

	/**
	 * returns true if no quick links are present in summary page
	 * 
	 * @return
	 */
	public boolean checkThatNoQuickLinksInSummaryPage() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			if (quickLinksList == null || quickLinksList.size() == 0) {
				status = true;
				LogUtility.logInfo("---> checkThatNoQuickLinksInSummaryPage <---", "Quick link list is empty");
			} else
				LogUtility.logError("---> checkThatNoQuickLinksInSummaryPage <---", "Quick link list is not empty");
		} catch (Exception e) {
			LogUtility.logException("checkThatNoQuickLinksInSummaryPage", "Exception in getting the size of quicklinks",
					e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * returns true if error message is displayed correct on clicking Links
	 * 
	 * @return
	 */
	public boolean checkTheErrorMessageOnClickingLinks(String errorType, String errorMsg) {
		boolean status = false;
		try {
			WebElement eleToGetText = null;
			switch (errorType) {
			case "NoTransactionMsg":
				eleToGetText = txtNoTransactionHistryMsg;
				break;
			case "NoTranfersMsg":
				eleToGetText = txtNoTranfersMsg;
				break;
			case "NoOneTimeBillPayMsg":
				eleToGetText = txtNoOneTimeBillPayMsg;
				break;
			case "NoStatementsMsg":
				eleToGetText = txtNoStatementsMsg;
				break;
			case "unAuthorizedUserMsg":
				eleToGetText = txtUnAuthorizedUserMsg;
				break;
			default:
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (wolWebUtil.verifyText(eleToGetText, errorMsg)) {
				status = true;
				LogUtility.logInfo("---> checkTheErrorMessageOnClickingLinks <---", "Got the message " + errorMsg);
			} else
				LogUtility.logError("---> checkTheErrorMessageOnClickingLinks <---", "Message not found " + errorMsg);
		} catch (Exception e) {
			LogUtility.logException("checkTheErrorMessageOnClickingLinks", "Exception in finding the error message", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks the business order of the links displayed in summary page.
	 * 
	 * @param userType
	 * @param links
	 * @return
	 */
	public boolean checkTheBusinessOrderForLinks(String userType, String links) {
		boolean status = false;
		HashMap<String, Integer> selectedLinksMap = new HashMap<>();
		HashMap<String, Integer> expectedBusinessOrderMap = new HashMap<>();
		HashMap<String, Integer> standardPositionOflinks = getQLBusinessOrderMap(userType);
		String expectedLinksOrder = "";
		String actualLinksOrder = "";

		try {
			for (String eachLink : links.split(",")) {
				selectedLinksMap.put(eachLink, standardPositionOflinks.get(eachLink));
			}
			expectedBusinessOrderMap = wolWebUtil.sortMapByValue(selectedLinksMap);
			for (String eachKey : expectedBusinessOrderMap.keySet()) {
				expectedLinksOrder = expectedLinksOrder + eachKey + ",";
			}
			for (WebElement element : quickLinksList) {
				actualLinksOrder = actualLinksOrder + webActions.getText(element) + ",";
			}
			if (expectedLinksOrder.equals(actualLinksOrder)) {
				status = true;
				LogUtility.logInfo("---> checkTheBusinessOrderForLinks <---",
						"Quick Links are in excpected business order " + expectedLinksOrder);
			} else
				LogUtility.logError("---> checkTheBusinessOrderForLinks <---",
						"Quick Links are not in excpected business order " + expectedLinksOrder);
		} catch (Exception e) {
			LogUtility.logException("checkTheBusinessOrderForLinks",
					"Exception in finding the business order of the quicklinks", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Sets the business order of the quick links
	 * 
	 * @param userType
	 * @return
	 */
	public HashMap<String, Integer> getQLBusinessOrderMap(String userType) {
		HashMap<String, Integer> map = new HashMap<>();
		map.put("Transaction History", 1);
		map.put("Webster Transfer", 2);
		map.put("Pay Bills", 3);
		map.put("Payment Center", 4);
		map.put("Pending Payments", 5);
		map.put("Statements", 6);
		map.put("Manage Payees", 7);
		map.put("Payment History", 8);
		map.put("Search Payments", 9);
		map.put("Search Transactions", 10);
		map.put("Export Transactions", 11);
		map.put("Brokerage Accounts", 12);
		map.put("Private Bank Accounts", 13);
		map.put("Banking Supplies", 14);
		map.put("Reorder Checks", 15);
		map.put("Travel Notification", 16);
		if (userType.equals("Business"))
			map.put("Make a Deposit", 17);
		else
			map.put("Non-Webster Transfer", 17);
		return map;
	}
}