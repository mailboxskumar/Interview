package com.wb.wol_web.pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class RelatedServicesPage extends ObjectBase {

	public RelatedServicesPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "div[id='bodyContent'] p")
	protected WebElement txtAccountServicesHistory;

	@FindBy(css = "div[id='bodyContent'] table td>a")
	protected WebElement btnTransactionDate;

	@FindBy(css = "div[id='bodyContent'] table div")
	protected List<WebElement> listAccountServicesHistory;

	@FindBy(css = "div#bodyContent table td:nth-of-type(1)")
	protected List<WebElement> listAccountServicesHistoryDetails1;

	@FindBy(css = "div#bodyContent table td:nth-of-type(1)")
	protected List<WebElement> listAccountServicesHistoryDetails;

	@FindBy(css = "div#pageContent>div:nth-of-type(2)")
	protected WebElement txtNoAccountServicesHistory;

	@FindBy(css = "div#pageContent>div>span")
	protected WebElement txtNoAccountsMessage;

	@FindBy(css = "div#pageContent > p:nth-of-type(2)")
	protected WebElement txtInformationMessage;

	@FindBy(css = "[class='notification ']")
	protected WebElement txtFeeDuplicateTaxform;

	@FindBy(id = "odp-2")
	protected WebElement checkboxYesIntrested;

	@FindBy(id = "odp-3")
	protected WebElement checkboxNoIntrested;

	@FindBy(css = "span[data-wbst-message-key='orr.manage.odp_label']")
	protected WebElement txtHeadingODServices;

	@FindBy(css = "form[name='defaultform'] div>a")
	protected WebElement txtRevokeODUnderODHeader;

	@FindBy(css = "a.fakesubmit")
	protected WebElement linkClickingHereUnderOD;

	@FindBy(name = "continue")
	protected WebElement btnContinue;

	@FindBy(css = "div#lightboxContent0 input[name='continue']")
	protected WebElement btnContinueFees;

	@FindBy(css = "div#lightboxContent0 h2")
	protected WebElement txtLightBoxTitle;

	@FindBy(css = "div#lightboxContent0 b")
	protected WebElement txtLightBoxRevokeTitle;

	@FindBy(css = "#pageContent  div.label")
	protected List<WebElement> listAccountODConfirmation;

	@FindBy(id = "target_acct")
	protected WebElement dropdownCheckingAccountRecievingOD;

	@FindBy(css = "p>a[rel='lightbox']")
	protected WebElement linkDepositAccountDisclosure;

	@FindBy(css = "div#subHeaderContainer h1")
	protected WebElement txtDisclosureLightbox;

	@FindBy(css = "div.lightbox-wrap.is-visible.is-top  button[aria-label='Close the dialog']")
	protected WebElement btnCloseAgreement;

	@FindBy(css = "button[aria-label='Print the dialog']")
	protected WebElement btnPrintAgreement;

	@FindBy(name = "continue")
	protected WebElement btnRequestCheckCopy;

	@FindBy(name = "cancel")
	protected WebElement btnCancelRequestCheckCopy;

	@FindBy(css = "div.errorInline")
	protected WebElement txtErrorReceivingOD;

	@FindBy(css = "form[name='frm']>div label")
	protected List<WebElement> listRequestCheckCopyLabels;

	@FindBy(xpath = "//form[@name='frm']/div//label/preceding-sibling::div")
	protected List<WebElement> listErrorTextRequestCheckCopyLabels;

	@FindBy(css = "h1 + p")
	protected WebElement txtCheckCopyMail;

	@FindBy(css = "div#pageContent>table + div")
	protected WebElement txtCheckCopyConfirmation;

	@FindBy(id = "accCat")
	protected WebElement dropdownAccont;

	@FindBy(css = "table td:nth-of-type(1)")
	protected List<WebElement> listConfirmationDetails;

	@FindBy(css = "form[name='frm'] div>label + input")
	protected List<WebElement> listInputsReqCheckCopy;

	@FindBy(css = "table td:nth-of-type(1)")
	protected List<WebElement> listTransDates;

	@FindBy(css = " tr:nth-of-type(1)>td:nth-of-type(1)>a")
	protected WebElement linkFirstConfirmation;

	@FindBy(name = "cancel")
	protected WebElement btnCancel;

	@FindBy(css = "div#pageContent>div:nth-of-type(1)")
	protected WebElement txtNoCheckingAccount;

	@FindBy(css = "div[id='pageContent']>div:nth-of-type(1) + p")
	protected WebElement txtContactUS;

	@FindBy(name = "edit")
	protected WebElement btnEditSavingsOD;

	@FindBy(css = "form[name='updateCardForm']>div:nth-of-type(1)")
	protected WebElement txtReOrderChecksNote;

	@FindBy(css = "[data-wbst-message-key='tf_provide_information']")
	protected WebElement txtTaxFormsInfo;

	@FindBy(css = "div[id='pageContent'] form>div:nth-of-type(1)")
	protected WebElement txtCorrectionTaxFormsNote;

	@FindBy(css = "form[name='updateCardForm']>div label")
	protected List<WebElement> listReOrderLabels;

	@FindBy(css = "form[name='defaultform'] div>label")
	protected List<WebElement> listReqDuplicateTaxLabels;

	@FindBy(name = "account_id")
	protected WebElement dropdownAccount;

	@FindBy(id = "page-title")
	protected WebElement txtPageHeading;

	@FindBy(name = "submit")
	protected WebElement btnSubmit;

	@FindBy(name = "attr_value_1_1")
	protected WebElement dropdownWebsterAccount;

	@FindBy(name = "attr_value_1_3")
	protected WebElement dropdownTaxYear;

	@FindBy(name = "attr_value_1_4")
	protected WebElement dropdownChargeAccount;

	@FindBy(css = "input[id='date1'] + button")
	protected WebElement btnCalendar;

	@FindBy(css = "form[name='read_mail'] div")
	protected List<WebElement> listLabelDetails;

	@FindBy(css = "form[name='read_mail'] label")
	protected List<WebElement> listSendMessageDetails;

	@FindBy(css = "table>tbody>tr>td:nth-child(1)")
	protected List<WebElement> listComposeMessageDetails;

	@FindBy(css = "div#pageContent td:nth-of-type(1)")
	protected List<WebElement> listReviewSentMessageDetails;

	@FindBy(css = "div#pageContent ul>li>a")
	protected List<WebElement> listQuickLinks;

	@FindBy(css = "div.errorInline")
	protected List<WebElement> listErrorMessages;

	@FindBy(css = "#pageContent  tr:nth-child(3) > td.description")
	protected WebElement txtCheckNumberConfirmation;

	@FindBy(css = "div#pageContent div[data-wbst-message-key='related.services.stop.payment.no.account']")
	protected WebElement txtNoStopPayment;

	@FindBy(xpath = "//*[@id='pageContent']//table//tr/td[contains(text(),'Confirmation Date')]/following-sibling::td")
	protected WebElement txtTimestamp;

	public String txtErrorMessage = "";
	public String checkNumber = null;
	public String amount = "";
	protected String toDateValue = null;
	List<String> listValues = new ArrayList<String>();
	public String txtCheckNumber = "";
	public String txtLink = "//*[contains(text(),'%s')]";
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
	String firstDate = null;
	String secondDate = null;
	Date d1;
	Date d2;
	public String timestamp = "";

	/**
	 * checkMessage - to verify the update message
	 * 
	 * @param message
	 * @param accountType
	 * @return
	 */
	public boolean checkMessage(String accountType, String message) {
		WebElement txtMessage = null;
		try {
			switch (accountType) {
			case "Active Account":
				txtMessage = txtCheckCopyMail;
				break;
			case "New Account":
				txtMessage = txtNoAccountServicesHistory;
				break;
			case "No Accounts":
				txtMessage = txtNoAccountsMessage;
				break;
			case "Information":
			case "Important Notification":
				txtMessage = txtInformationMessage;
				break;
			case "Fee Duplicate Taxform":
				txtMessage = txtFeeDuplicateTaxform;
				break;
			case "Error OD":
				txtMessage = txtErrorReceivingOD;
				break;
			case "Check Copy Mail":
			case "SetUp Savings OD":
				txtMessage = txtCheckCopyMail;
				break;
			case "Check Copy Confirmation":
			case "Duplicate Tax":
				txtMessage = txtCheckCopyConfirmation;
				break;
			case "Request a Check Copy":
				txtMessage = txtCheckCopyMail;
				break;
			case "No IM account":
			case "No CD account":
			case "No Saving account":
			case "Mail Information":
			case "No Account Request Duplicate Tax Forms":
				txtMessage = txtNoCheckingAccount;
				break;
			case "Contact Us":
				txtMessage = txtContactUS;
				break;
			case "Re Order Checks Note":
				txtMessage = txtReOrderChecksNote;
				break;
			case "Information Tax Forms":
				txtMessage = txtTaxFormsInfo;
				break;
			case "Correction Tax Forms":
				txtMessage = txtCorrectionTaxFormsNote;
				break;
			case "Stop Payment":
				txtMessage = txtNoStopPayment;
				break;
			default:
				LogUtility.logInfo("--->checkMessage<---", "Case match not found");
				break;
			}
			waits.waitForPageReadyState();
			if (wolWebUtil.verifyTextContains(txtMessage, message)) {
				LogUtility.logInfo("--->checkMessage<---", message + " is present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkMessage<-", "Unable check the message", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButton: To Click on button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement btnToBeClicked = null;
		try {
			switch (btnName) {
			case "date":
				btnToBeClicked = btnTransactionDate;
				break;
			case "Continue":
			case "Setup":
				btnToBeClicked = btnContinue;
				break;
			case "Cancel":
				btnToBeClicked = btnCancelRequestCheckCopy;
				break;
			case "Edit":
				btnToBeClicked = btnEditSavingsOD;
				break;
			case "Disclosure":
				btnToBeClicked = linkDepositAccountDisclosure;
				waits.staticWait(4);
				break;
			case "continue fee":
				btnToBeClicked = btnContinueFees;
				waits.staticWait(4);
				break;
			case "Close":
				btnToBeClicked = btnCloseAgreement;
				break;
			case "Print":
				btnToBeClicked = btnPrintAgreement;
				break;
			case "Request Check Copy":
				btnToBeClicked = btnRequestCheckCopy;
				break;
			case "Calendar":
				btnToBeClicked = btnCalendar;
				break;
			case "Request Forms":
				btnToBeClicked = btnSubmit;
				break;
			default:
				LogUtility.logInfo("--->clickOnButton<---", "Case match not found");
				break;
			}
			waits.waitForDOMready();
			if (webActions.isDisplayed(btnToBeClicked)) {
				webActions.clickElement(btnToBeClicked);
				LogUtility.logInfo("--->clickOnButton<---", "Clicked on button " + btnToBeClicked);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButton<-", "Unable click on Button: " + btnName, e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkAndEnterValues : To check the fields in update user name and password
	 * and enter the values to it
	 * 
	 * @param list
	 * @return
	 */
	public int verifyLabels(String pageName, List<String> list) {
		int count = 0;
		try {
			List<WebElement> listNames = null;
			switch (pageName) {
			case "Account Services History":
				listNames = listAccountServicesHistory;
				break;
			case "Account Services History Detail":
			case "Request Duplicate Tax Forms Confirmation":
				listNames = listAccountServicesHistoryDetails;
				break;
			case "Manage Webster Account Confirmation":
				listNames = listAccountODConfirmation;
				break;
			case "Request Check Copy":
			case "SetUpSavings OD":
				listNames = listRequestCheckCopyLabels;
				break;
			case "CheckCopy Confirmation":
				listNames = listConfirmationDetails;
				break;
			case "ReOrder Checks":
				listNames = listReOrderLabels;
				break;
			case "Request Duplicate Tax Forms":
				listNames = listReqDuplicateTaxLabels;
				break;
			default:
				LogUtility.logInfo("--->verifyLabels<---", "Case match not found");
				break;
			}
			if (webActions.isDisplayed(listNames.get(0))) {
				for (WebElement label : listNames) {
					if (wolWebUtil.verifyTextContains(label, list.toString())) {
						LogUtility.logInfo("----->verifyLabels<----", label + " is present");
						count++;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyLabels<-", "Unable verify the labels", e, LoggingLevel.ERROR, true);
		}
		return count;
	}

	/**
	 * clickOnCheckboxUnderHeader : To check the check box under headerODServices
	 * 
	 * @param labelYes
	 * @param headerODServices
	 * @return
	 */
	public boolean clickOnCheckboxUnderODHeader(String labelYes, String headerODServices) {
		try {
			if (wolWebUtil.verifyTextContains(txtHeadingODServices, headerODServices)) {
				webActions.clickElement(checkboxYesIntrested);
				LogUtility.logInfo("--->clickOnCheckboxUnderHeader<---",
						"Clicked on " + labelYes + " checkbox under " + headerODServices);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnCheckboxUnderHeader<-", "Unable click on checkbox under header", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkPageTitle : To verify the title of light box
	 * 
	 * @param pageName
	 * @return
	 */
	public boolean checkPageTitle(String pageName) {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtLightBoxTitle, pageName)) {
				LogUtility.logInfo("--->checkPageTitle<---", "redirected to " + pageName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkPageTitle<-", "Unable to check the page title", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForDetails- To verify the label names
	 * 
	 * @param pageName
	 * @param testDataMap
	 * @return
	 */
	public int checkForDetails(String pageName, Map<String, String> testDataMap) {
		int count = 0;
		try {
			List<WebElement> listofValues = null;
			switch (pageName) {
			case "Review Messages":
				listofValues = listLabelDetails;
				break;
			case "Send Message":
				listofValues = listSendMessageDetails;
				break;
			case "Read Message":
			case "Review Sent Message":
				listofValues = listReviewSentMessageDetails;
				break;
			case "QuickLinks":
			case "Important Notification":
				listofValues = listQuickLinks;
				break;
			case "Compose Message":
				listofValues = listComposeMessageDetails;
				break;
			default:
				LogUtility.logInfo("--->checkForDetails<---", "Case match not found");
				break;
			}
			for (WebElement detail : listofValues) {
				if (wolWebUtil.verifyTextContains(detail, testDataMap.values().toString())) {
					LogUtility.logInfo("----->checkForDetails<----", detail + " is present");
					count++;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForDetails<-", "Unable to check the details", e, LoggingLevel.ERROR, true);
		}
		return count;
	}

	/**
	 * verifyDefaultChecked : To verify yes check-box is selected by default
	 * 
	 * @param radioButton
	 * @return
	 */
	public boolean verifyDefaultChecked(String radioButton) {
		waits.waitForPageReadyState();
		try {
			WebElement agreementRadioButton = null;
			switch (radioButton) {
			case "Yes":
				agreementRadioButton = checkboxYesIntrested;
				break;
			case "No":
				agreementRadioButton = checkboxNoIntrested;
				break;
			default:
				LogUtility.logInfo("--->verifyDefaultChecked<---", "Case match not found");
				break;
			}
			if (webActions.isChecked(agreementRadioButton)) {
				LogUtility.logInfo("--->verifyDefaultChecked<---",
						agreementRadioButton + " checkbox is checked by default");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyDefaultChecked<-", "Unable to verify the defaulty checked radio button", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnLinkUnderODHeader : Click on link under OD services
	 * 
	 * @param txtRevokeOD
	 * @param txtODHeader
	 * @return
	 */
	public boolean clickOnLinkUnderODHeader(String txtRevokeOD, String txtODHeader) {
		try {
			if (wolWebUtil.verifyTextContains(txtHeadingODServices, txtODHeader)) {
				if (wolWebUtil.verifyTextContains(txtRevokeODUnderODHeader, txtRevokeOD)) {
					webActions.clickElement(linkClickingHereUnderOD);
					LogUtility.logInfo("--->clickOnLinkUnderODHeader<---",
							"Clicked on " + txtRevokeOD + " link under " + txtODHeader);
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnLinkUnderODHeader<-", "Unable to click on link under Over Draft Header",
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkLightboxTitle : To get the title of light-box
	 * 
	 * @param txtLightboxTitle
	 * @param pageTitle
	 * @return
	 */
	public boolean checkLightboxTitle(String flowName, String pageTitle) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		// TODO: Light-boxes are taking time to load
		waits.staticWait(5);
		WebElement lightboxTitle = null;
		try {
			switch (flowName) {
			case "OD Fees":
				lightboxTitle = txtLightBoxTitle;
				break;
			case "Revoke":
				lightboxTitle = txtLightBoxRevokeTitle;
				break;
			case "Disclosure":
				lightboxTitle = txtDisclosureLightbox;
				break;
			default:
				LogUtility.logInfo("--->checkLightboxTitle<---", "Case match not found");
				break;
			}
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			if (wolWebUtil.verifyTextContains(lightboxTitle, pageTitle)) {
				LogUtility.logInfo("--->checkLightboxTitle<---", "redirected to " + pageTitle + " page");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkLightboxTitle<-", "Unable to check the lightbox title", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForButton: To check the buttons are present or not
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean checkForButton(String btnName) {
		WebElement btnToBeChecked = null;
		try {
			switch (btnName) {
			case "Cancel":
				btnToBeChecked = btnCancelRequestCheckCopy;
				break;
			case "Edit":
				btnToBeChecked = btnEditSavingsOD;
				break;
			case "Request Check Copy":
			case "Continue":
			case "Setup":
				btnToBeChecked = btnRequestCheckCopy;
				break;
			case "Close":
				btnToBeChecked = btnCloseAgreement;
				break;
			case "Print":
				btnToBeChecked = btnPrintAgreement;
				break;
			case "Request Forms":
				btnToBeChecked = btnSubmit;
				break;
			default:
				LogUtility.logInfo("--->checkForButton<---", "Case match not found");
				break;
			}
			if (webActions.isDisplayed(btnToBeChecked)) {
				LogUtility.logInfo("--->checkForButton<---", "checked for" + btnToBeChecked + " button");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForButton<-", "Unable to check for the button", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkErrorMessage : To check the list of error messages
	 * 
	 * @param listErrorMessage
	 * @return
	 */
	public boolean checkErrorMessage(List<String> listErrorMessage) {
		int count = 0;
		try {
			for (WebElement txtLabelError : listErrorMessages) {
				for (String textError : listErrorMessage)
					if (wolWebUtil.verifyTextContains(txtLabelError, textError)) {
						LogUtility.logInfo("--->checkErrorMessage<---",
								webActions.getText(txtLabelError) + " is present");
						count++;
						break;
					}
			}
			if (count == listErrorMessage.size())
				return true;
		} catch (Exception e) {
			LogUtility.logException("->checkErrorMessage<-", "Unable to check for the error message", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectAccount: To select the account with partial text
	 * 
	 * @param accountNumber
	 * @param labelName
	 * @return
	 */
	public boolean selectAccount(String accountNumber, String labelName) {
		try {
			WebElement eleDropdown = null;
			switch (labelName) {
			case "Account":
				eleDropdown = dropdownAccont;
				break;
			case "Webster Account":
				eleDropdown = dropdownWebsterAccount;
				break;
			case "Tax Year":
				eleDropdown = dropdownTaxYear;
				break;
			case "Account to charge":
				eleDropdown = dropdownChargeAccount;
				break;
			default:
				LogUtility.logInfo("--->selectAccount<---", "Case match not found");
				break;
			}
			if (webActions.isDisplayed(eleDropdown)) {
				wolWebUtil.selectValueByPartialVisibleText(eleDropdown, accountNumber);
				LogUtility.logInfo("--->selectAccount<---", "Account Number: " + eleDropdown + " is selected");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->selectAccount<-", "Unable to select the account", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterValues: To enter the values
	 * 
	 * @param listLabelNames
	 * @return
	 */
	public List<String> enterValues(List<String> listLabelNames) {
		checkNumber = wolWebUtil.getRandomNumber(3);
		amount = wolWebUtil.getRandomNumber(3);
		toDateValue = wolWebUtil.getOldDate("1");
		try {
			waits.staticWait(5);
			listValues.clear();
			webActions.setValue(listInputsReqCheckCopy.get(0), checkNumber);
			listValues.add(checkNumber);
			LogUtility.logInfo("--->enterValues<---", "CheckNumber: " + checkNumber + " is entered");
			webActions.setValue(listInputsReqCheckCopy.get(1), amount);
			listValues.add(amount);
			LogUtility.logInfo("--->enterValues<---", "Amount: " + amount + " is entered");
			webActions.setValue(listInputsReqCheckCopy.get(2), toDateValue);
			listValues.add(toDateValue);
			LogUtility.logInfo("--->enterValues<---", "Date: " + toDateValue + " is entered");
			return listValues;
		} catch (Exception e) {
			LogUtility.logException("->enterValues<-", "Unable to enter values", e, LoggingLevel.ERROR, true);
		}
		return listValues;
	}

	/**
	 * clickOnFirstLink : To click on the first link
	 * 
	 * @return
	 */
	public boolean clickOnFirstLink() {
		try {
			if (webActions.isDisplayed(linkFirstConfirmation)) {
				webActions.clickElement(linkFirstConfirmation);
				LogUtility.logInfo("--->clickOnFirstLink<---", "Clicked on first linkr");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnFirstLink<-", "Unable to click on first link", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForCheckNumber : To verify the checkNumber is present or not
	 * 
	 * @return
	 */
	public String checkForCheckNumber() {
		try {
			if (wolWebUtil.verifyTextContains(txtCheckNumberConfirmation, checkNumber)) {
				LogUtility.logInfo("--->checkForCheckNumber<---", "CheckNumber: " + checkNumber + " is displayed");
				return checkNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForCheckNumber<-", "Unable to check for check number", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkForLinkNotPrsent: To check verify the link is present or not
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean checkForLinkNotPrsent(String linkName) {
		try {
			WebElement eleLink = driver.findElement(By.xpath(String.format(txtLink, linkName)));
			if (webActions.isDisplayed(eleLink)) {
				LogUtility.logInfo("--->checkForLinkNotPrsent<---", "linkName: " + linkName + " is displayed");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForLinkNotPrsent<-", "Unable to check for the link is not present", e,
					LoggingLevel.ERROR, true);
		}
		return true;
	}

	/**
	 * selectValueFromDropDown: To select the value from dropdown by partial text
	 * 
	 * @param value
	 * @return
	 */
	public boolean selectValueFromDropDown(String value) {
		try {
			waits.waitForDOMready();
			wolWebUtil.selectValueByPartialVisibleText(dropdownAccount, value);
			LogUtility.logInfo("--->selectValueFromDropDown<---", "Selected the value:" + value);
			return true;
		} catch (Exception e) {
			LogUtility.logException("->selectValueFromDropDown<-", "Unable to select value from drop down", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkChildPageTitle: To verify the title of child window
	 * 
	 * @param pageTitle
	 * @return
	 */
	public boolean checkChildPageTitle(String pageTitle) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			// TODO : to load the third party page it is taking time
			waits.staticWait(5);
			waits.waitForPageToLoad(maxTimeOut);
			if (wolWebUtil.verifyPageTitleOfChildWindow(pageTitle)) {
				LogUtility.logInfo("--->checkChildPageTitle<---", "Child window title: " + pageTitle + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkChildPageTitle<-", "Unable to verify the child page title", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public boolean checkPageHeading(String pageName) {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtPageHeading, pageName)) {
				LogUtility.logInfo("--->checkPageHeading<---", "redirected to " + pageName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkPageHeading<-", "Unable to verify the page heading", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * enterValuesInput: To enter the values
	 * 
	 * @param testDataMap
	 * @return
	 */
	public List<String> enterValuesInput(Map<String, String> testDataMap) {
		try {
			listValues.clear();
			if (testDataMap.get("Check").equalsIgnoreCase("Random"))
				checkNumber = wolWebUtil.getRandomNumber(3);
			else
				checkNumber = testDataMap.get("Check");
			if (testDataMap.get("Date Check Cleared").equalsIgnoreCase("Random"))
				toDateValue = wolWebUtil.getOldDate("1");
			else
				toDateValue = testDataMap.get("Date Check Cleared");
			amount = testDataMap.get("Amount");

			webActions.setValue(listInputsReqCheckCopy.get(0), checkNumber);
			listValues.add(checkNumber);
			LogUtility.logInfo("--->enterValuesInput<---", "CheckNumber: " + checkNumber + " is entered");
			webActions.setValue(listInputsReqCheckCopy.get(1), amount);
			listValues.add(amount);
			LogUtility.logInfo("--->enterValuesInput<---", "Amount: " + amount + " is entered");
			webActions.setValue(listInputsReqCheckCopy.get(2), toDateValue);
			listValues.add(toDateValue);
			LogUtility.logInfo("--->enterValuesInput<---", "Date: " + toDateValue + " is entered");
			return listValues;
		} catch (Exception e) {
			LogUtility.logException("->enterValuesInput<-", "Unable to enter the values input", e, LoggingLevel.ERROR,
					true);
		}
		return listValues;

	}

	/**
	 * checkForCurrentAndFutureDatesDisabled: To check the current and future dates
	 * are disabled
	 * 
	 * @return
	 */
	public boolean checkForCurrentAndFutureDatesDisabled() {
		waits.waitForPageReadyState();
		try {
			By element;
			int currentDay = 0;
			int dateCount = 0;
			int currentDate = 0;
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String CurrentDate = dateFormat.format(date);
			Calendar calendar = Calendar.getInstance();
			WebElement dates;
			int maxDaysInMonth = calendar.getActualMaximum(Calendar.DATE);
			for (currentDate = 1; currentDate < maxDaysInMonth; currentDate++) {
				dates = driver.findElement(By.xpath("(//table//td[@class='invalid'])[" + currentDate + "]"));
				if (wolWebUtil.verifyTextContains(dates, CurrentDate)) {
					currentDay = Integer.parseInt(CurrentDate);
					dateCount = currentDate;
					break;
				}
			}
			for (int presentDay = currentDay; presentDay <= maxDaysInMonth; presentDay++) {
				element = By.xpath("(//table//td[@class='invalid'])[" + dateCount + "]");
				dates = driver.findElement(element);
				String value = webActions.getAttributeValue(dates, "class");
				if (!(value.equalsIgnoreCase("Invalid")))
					return false;
				dateCount++;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForCurrentAndFutureDatesDisabled<-",
					"Unable to check the current and future dates disabled", e, LoggingLevel.ERROR, true);
		}
		LogUtility.logInfo("--->checkForCurrentAndFutureDatesDisabled<---", "redirected to ");
		return true;
	}

	/**
	 * checkForTransactionSort: To check transactions are sorted
	 * 
	 * @return
	 */
	public boolean checkForTransactionSort() {
		waits.waitForPageReadyState();
		try {
			secondDate = null;
			int count = 1;
			for (WebElement transDate : listTransDates) {
				firstDate = webActions.getText(transDate);
				if (count == 1)
					secondDate = firstDate;
				d1 = sdf.parse(firstDate);
				d2 = sdf.parse(secondDate);
				if (!(d2.after(d1) || d2.equals(d1)))
					return false;
				secondDate = firstDate;
				count++;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForTransactionSort<-", "Unable to check the transaction sort", e,
					LoggingLevel.ERROR, true);
		}
		LogUtility.logInfo("--->checkForTransactionSort<---", "Transactions are sorted ");
		return true;
	}

	/**
	 * checkForTimestamp: To get the timestamp
	 * 
	 * @return
	 */
	public String checkForTimestamp() {
		try {
			if (webActions.isDisplayed(txtTimestamp)) {
				timestamp = webActions.getText(txtTimestamp);
				LogUtility.logInfo("--->checkForTimestamp<---", "Timestamp is displayed as : " + timestamp);
				return timestamp;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForTimestamp<-", "Unable to check for the timestamp", e, LoggingLevel.ERROR,
					true);
		}
		return null;
	}
}