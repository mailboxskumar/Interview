package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class AccountEligibilityWolPage extends ObjectBase {
	public AccountEligibilityWolPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "div[class*='widgetHeaderTitle']")
	private List<WebElement> lstAcctFeatures;

	@FindBy(css = "h1[data-wbst-message-key='account_features-header_title']")
	private WebElement ttlSetUpAccountFeatures;

	/**
	 * @author VSomalaraju-adm
	 * @param pgTitle
	 * @return
	 */
	public boolean verifySetUpAcctFeaturesPgTitle(String pgTitle) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(ttlSetUpAccountFeatures, maxTimeOut)) {
				flag = wolWebUtil.verifyText(ttlSetUpAccountFeatures, pgTitle);
			}

		} catch (Exception e) {
			LogUtility.logException("---> verifySetUpAcctFeaturesPgTitle <---",
					"Unable to navigate : " + pgTitle + " : page in WOL application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param verifyValue
	 * @return
	 */
	public boolean verifyCustOnlineProfile(String verifyValue) {
		boolean flag = false;
		int headersCount = lstAcctFeatures.size();
		List<String> textMsgs = new ArrayList<String>();
		try {
			if (headersCount > 0) {
				for (int i = 0; i < headersCount; i++) {
					textMsgs.add(lstAcctFeatures.get(i).getText());
					if (!textMsgs.contains(verifyValue)) {
						LogUtility.logInfo("---> verifyCustOnlineProfile <---",
								"Value : " + verifyValue + " : is not presented in Setup Account Features page");
						flag = true;
				}
			}
			
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyCustOnlineProfile <---",
					"Value : " + verifyValue + " : is presented in Setup Account Features page", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}
}