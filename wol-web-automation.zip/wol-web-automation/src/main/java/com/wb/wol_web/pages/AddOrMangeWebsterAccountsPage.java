
package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class AddOrMangeWebsterAccountsPage extends ObjectBase {

	PaymentCenterPage paymentCenterPage = new PaymentCenterPage();
	AccountEligibilityWebcomPage accountEligibilityWebcomPage = new AccountEligibilityWebcomPage();

	public static String accountNumber = "";
	public static String accountNickNameInPreviewPage = "";
	public String accountPath = "//li[@class='accordion__item']/a[contains(.,'%s')]";
	public String websterAccountsPath = "//div[@id='pageContent']/ul[1]/li/a[contains(text(),'%s')]";
	public String txtAccNickNamePath = "(//div[@id='pageContent']/ul[1]/li/a[contains(text(),'%s')]/following::input[@name='nickname'])[1]";
	public String btnContinuePath = "(//div[@id='pageContent']/ul[1]/li/a[contains(text(),'%s')]/following::input[@name='continue'])[1]";
	public String addAccountsConfirmMsg;
	public String getAccountNumber;
	public String getAccountName;
	public String addExistingAccountMsg;
	public String getNickNameText;
	public String newNickName;
	public String nickName = "//td[contains(text(),'%s')]//following-sibling::td/input[contains(@name,'NickName')]";

	public AddOrMangeWebsterAccountsPage() {
		PageFactory.initElements(driver, this);
	}

	FinancialSummaryPage financialSummaryPage = new FinancialSummaryPage();

	@FindBy(xpath = "//h1[contains(@data-wbst-message-key,'profile.manage_webster_account')]")
	protected WebElement pageTitleManageAccount;

	@FindAll(@FindBy(xpath = "//li[@class='accordion__item']"))
	protected List<WebElement> lstAccountDetails;

	@FindBy(xpath = "(//li[@class='accordion__item is-open']//a)[1]")
	protected WebElement defaultAccountClose;

	@FindBy(xpath = "//li[@class='accordion__item is-open']//a[text()='Remove this account']")
	protected WebElement removeAccount;

	@FindBy(xpath = "//div[@data-wbst-message-key='profile.update_account_success.pendingtransfers']")
	protected WebElement pendingPaymentErrorMsg;

	@FindBy(xpath = "(//div[@id='pageContent']/ul)[2]")
	protected WebElement lnkAccNumberDetails;

	@FindBy(xpath = "//div[@id='pageContent']/ul[1]/li/a")
	protected WebElement lnkAccNumber;

	@FindBy(name = "nickname")
	protected WebElement txtNickName;

	@FindBy(name = "continue")
	protected WebElement btnContinue;

	@FindBy(xpath = "//h1[contains(.,'Manage Webster Account Confirmation')]")
	protected WebElement titleWebsterAccPreview;

	@FindBy(xpath = "//div[@id='pageContent']/div[2]/div[2]")
	protected WebElement nickNameWebsterAccPreview;

	@FindBy(xpath = "//a[contains(.,'Set as default bill pay account')]")
	protected WebElement lnkDefaultBillPayAccount;

	@FindBy(xpath = "//div[@id='pageContent']/p[1]/strong")
	protected WebElement msgDefaultBillPayAccount;

	@FindBy(xpath = "(//a[contains(.,'Update View Deposit Details Preferences')])[1]")
	protected WebElement lnkDepositDetailsPref;

	@FindBy(xpath = "//h1[@data-wbst-message-key='profile.manage_webster_account_conf.heading']")
	protected WebElement ttlMngWbstrAccConfirm;

	@FindBy(xpath = "//div[@id='pageContent']/p/Strong")
	protected WebElement txtMngWbstConfirmMsg;

	@FindBy(xpath = "//h1[@data-wbst-message-key='addacc_success_add_webster_acc_confirm']")
	protected WebElement ttlAddWbstAccConfirm;

	@FindBy(xpath = "//h1[@data-wbst-message-key='addacc-header_title']")
	protected WebElement ttlAddAccountsPage;

	@FindBy(xpath = "//form[@name='defaultform']/div")
	protected WebElement txtAddWbstConfirmMsg;

	@FindBy(xpath = "//input[@id='add_account_number']")
	protected WebElement txtAddAccountNumber;

	@FindBy(xpath = "//input[@id='add_account_nick-2']")
	protected WebElement txtAccountNickName;

	@FindBy(xpath = "//input[@value='Add Account']")
	protected WebElement btnAddAccount;

	@FindBy(xpath = "//div[@class ='notification ']")
	protected WebElement txtAddExistingAccMsg;

	@FindBy(xpath = "//div[@data-wbst-message-key='generic_error_msg']")
	protected WebElement txtGenErrMsgAddAccount;

//	@FindBy(xpath = "//div[@data-wbst-message-key='addacc_error_accno_invalid']")
	@FindBy(css = "[data-wbst-message-key*='addacc_error_accno_invalid'],[data-wbst-message-key*='addacc_error_accno_unable_addacc']")
	protected WebElement txtAddAccErrMsg;

	@FindBy(xpath = "//p[@data-wbst-message-key='addacc-header_description']")
	protected WebElement txtAddAccPageCont;

	@FindBy(xpath = "//div[@class='formRowButtons']/a[@name='cancel']")
	protected WebElement btnCancelAddAccounts;

	@FindBy(xpath = "//div[@class='lightbox']//div[@class='formRowButtons']//a[@name='no']")
	protected WebElement btnNoAddAccounts;

	@FindBy(xpath = "//div[@class='lightbox']//div[@class='formRowButtons']//a[@name='yes']")
	protected WebElement btnYesAddAccounts;

	@FindBy(xpath = "//section[@id='messageContainer']/p")
	protected WebElement txtPopUpMessage;

	@FindBy(xpath = "//section[@id='messageContainer']/p/a")
	protected WebElement lnkManageUserAccess;

	@FindBy(css = " table > tbody > tr:nth-child(2) > td:nth-child(6) > a")
	private WebElement lnkViewMngAuditPage;

	@FindBy(xpath = " //b[contains(text(),'Account Number')]/../..//following-sibling::td")
	private WebElement txtAccountNumberAuditDetails;

	@FindBy(xpath = "//b[contains(text(),'Account Nickname')]/../..//following-sibling::td[2]")
	private WebElement txtUpdatedNickName;

	@FindBy(xpath = "//div[@class='message']")
	protected WebElement txtConfirmationMessage;

	/**
	 * To check the page Title in ManageWebster Accounts Functionality
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param pageHeading
	 * @return
	 */
	public boolean checkPageTitleForMangeWebsterAccounts(String pageHeading) {
		try {
			waits.waitUntilElementIsPresent(pageTitleManageAccount, maxTimeOut);
			if (wolWebUtil.verifyText(pageTitleManageAccount, pageHeading)) {
				LogUtility.logInfo("---> checkPageTitleForPendingPayment <---",
						"Heading verified Successfully " + pageHeading);
				return true;
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logException("checkPageTitleForPendingPayment", "Failed to check page title", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check the page Title in ManageWebster Accounts Functionality
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param pageHeading
	 * @return
	 * @throws Exception
	 */
	public void selectAndRemoveTheAccount() throws Exception {
		try {
			String accountFromRecPayment = getValueFromRuntimeDataMap("PayBillsFromAccount").split(" ")[0].replace("x",
					"");
			accountFromRecPayment = accountFromRecPayment.replaceAll("[a-zA-Z]", "");
			waits.waitForPageToLoad(maxTimeOut);
			webActions.clickElement(defaultAccountClose);
			LogUtility.logInfo("selectAndRemoveTheAccount", "accountFromRecurPayment " + accountFromRecPayment);
			webActions
					.clickElementJS(driver.findElement(By.xpath(accountPath.replaceAll("%s", accountFromRecPayment))));
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(removeAccount, maxTimeOut);
			webActions.clickElementJS(removeAccount);
			waits.waitForPageToLoad(maxTimeOut);
			LogUtility.logInfo("selectAndRemoveTheAccount", "Clicked on remove this account link");

		} catch (Exception e) {
			LogUtility.logException("selectAndRemoveTheAccount", "Failed to select and remove the account", e,
					LoggingLevel.ERROR, true);
			throw e;
		}

	}

	/**
	 * To check the error message in ManageWebster Accounts Functionality
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param msg , errorType
	 * @return
	 */
	public boolean checkForErrorMessage(String msg, String errorType) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			WebElement eleToGetText = null;
			switch (errorType) {
			case "CantRemoveAccount":
				eleToGetText = pendingPaymentErrorMsg;
				break;

			default:
				LogUtility.logInfo("--->checkForErrorMessage<---", "Invalid error message");
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText);
			wolWebUtil.scrollToElement(eleToGetText);
			if (webActions.getText(eleToGetText).equals(msg))
				status = true;
		} catch (Exception e) {
			LogUtility.logException("checkForErrorMessage", "Failed to find the error message", e, LoggingLevel.ERROR,
					true);
		}
		return status;

	}

	/**
	 * To Verify the Single Account displayed or not in Manage Webster Accounts Page
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */

	public boolean verifyAccountNumber(String accNumber) {
		boolean flag = false;
		try {
			String accName = webActions.getText(lnkAccNumber);
			if (accName.contains(accNumber))
				flag = true;
			LogUtility.logInfo("--->verifyAccountNumber<---", "Account Number Displayed");
		} catch (Exception e) {
			LogUtility.logError("--->verifyAccountNumber<---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To Enter data in the nick name field
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */

	public boolean enterAccountNickName(String nickName) {
		boolean flag = false;
		try {
			String getAccount = wolWebUtil.dynamicData();
			String accountNickname = getAccount + nickName;
			boolean accNickName = webActions.isDisplayed(txtNickName);
			if (accNickName) {
				webActions.setValue(txtNickName, accountNickname);
				LogUtility.logInfo("--->enterAccountNickName<---", "Nick name entered as " + accountNickname);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("--->enterAccountNickName<---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To Capture the Account Nick Name
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */

	public String captureAccountNickName() {
		try {
			waits.waitUntilElementIsPresent(nickNameWebsterAccPreview, maxTimeOut);
			accountNickNameInPreviewPage = webActions.getText(nickNameWebsterAccPreview);
			LogUtility.logInfo("--->captureAccountNickName<---", "Nick name captured");
		} catch (Exception e) {
			LogUtility.logError("--->captureAccountNickName<---", e.getMessage());
		}
		return accountNickNameInPreviewPage;
	}

	/**
	 * To Verify the Manage Webster Accounts Confirmation Page Title
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */
	public boolean verifyWebsterAccConfPage(String accConfPagetitle) {
		try {
			waits.waitUntilElementIsPresent(titleWebsterAccPreview, maxTimeOut);
			return wolWebUtil.verifyText(titleWebsterAccPreview, accConfPagetitle);
		} catch (Exception e) {
			LogUtility.logError("--->verifyWebsterAccConfPage<---", e.getMessage());
			return false;
		}
	}

	/**
	 * To Click on continue button in Webster Account Confirmation Page
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */

	public boolean clickOnContinueBtn() {
		boolean flag = false;
		try {
			boolean continueBtn = webActions.isDisplayed(btnContinue);
			if (continueBtn) {
				webActions.clickElement(btnContinue);
				LogUtility.logInfo("--->clickOnContinueBtn<---", "Clicked on Continue button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("--->clickOnContinueBtn<---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To update the Account Nick name as N/A
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */
	public boolean updateAccountNickNameasNA(String accountNumber) {
		boolean flag = false;
		try {
			webActions.clickElement(lnkAccNumber);
			WebElement accountDetails = driver.findElement(By.xpath(String.format(websterAccountsPath, accountNumber)));
			// After clicked on Account link, Account details loading takes time
			waits.staticWait(2);
			webActions.clickElement(accountDetails);
			WebElement accountNickName = driver.findElement(By.xpath(String.format(txtAccNickNamePath, accountNumber)));
			waits.waitUntilElementIsPresent(accountNickName, 20);
			webActions.clearValue(accountNickName);
			WebElement btnContinue = driver.findElement(By.xpath(String.format(btnContinuePath, accountNumber)));
			waits.waitUntilElementIsPresent(btnContinue, 20);
			boolean continueButton = webActions.isDisplayed(btnContinue);
			if (continueButton) {
				webActions.clickElement(btnContinue);
				// After clicked on continue button,page loading takes time
				waits.staticWait(1);
				LogUtility.logInfo("---> updateAccountNickNameasNA<---", "verify Account NickName as N/A");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> updateAccountNickNameasNA <---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To Verify the Account Nick Name as N/A
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */
	public boolean verifyWebtsterAccNickNameNa(String accConfPagetitle) {
		try {
			return wolWebUtil.verifyText(financialSummaryPage.lblAccountNickNameDisplay, accConfPagetitle);
		} catch (Exception e) {
			LogUtility.logError("--->verifyWebtsterAccNickNameNa<---", e.getMessage());
			return false;
		}
	}

	/**
	 * To Click on Default Bill Pay Account link in Webster Account Confirmation
	 * Page
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 26th 2019
	 */

	public boolean clickDefaultBillPayLink() {
		boolean flag = false;
		try {
			boolean billPayLink = webActions.isDisplayed(lnkDefaultBillPayAccount);
			if (billPayLink) {
				webActions.clickElement(lnkDefaultBillPayAccount);
				LogUtility.logInfo("--->clickDefaultBillPayLink<---", "Clicked on Default Bill Pay Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("--->clickDefaultBillPayLink<---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To Verify the Default Bill Pay Account message
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */
	public boolean verifyBillPayAccountMsg(String billPayAccMsg) {
		try {
			return wolWebUtil.verifyText(msgDefaultBillPayAccount, billPayAccMsg);
		} catch (Exception e) {
			LogUtility.logError("--->verifyBillPayAccountMsg<---", e.getMessage());
			return false;
		}
	}

	/**
	 * To click on the Deposit Details Preferences link
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Created on: June 3rd 2019
	 */
	public boolean clickOnDepositDetailsPrefLink() {
		boolean flag = false;
		try {
			boolean depositDetailsLink = webActions.isDisplayed(lnkDepositDetailsPref);
			if (depositDetailsLink) {
				webActions.clickElement(lnkDepositDetailsPref);
				LogUtility.logInfo("---> clickOnDepositDetailsPrefLink<----", "clicked OnDeposit Details Preference");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> clickOnDepositDetailsPrefLink  <---", e.getMessage());
		}
		return flag;
	}

	/**
	 * Verify manage webster accounts confirmation page
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlManageAccounts
	 * @return
	 */
	public boolean verifyManageAccountsConfirmationPageTitle(String pgTtlManageAccounts) {
		try {
			return wolWebUtil.verifyText(ttlMngWbstrAccConfirm, pgTtlManageAccounts);
		} catch (Exception e) {
			LogUtility.logException("---> verifyManageAccountsConfirmationPageTitle <---",
					"Failed to navigate { " + pgTtlManageAccounts + " } page", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Verify manage webster accounts confirmation messag
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlManageAccounts
	 * @return
	 */
	public boolean verifyManageAccountsConfirmMessage(String manageAccountsConfirmMsg) {
		try {
			return wolWebUtil.verifyText(txtMngWbstConfirmMsg, manageAccountsConfirmMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyManageAccountsConfirmationPageTitle <---",
					"Failed to verify message { " + manageAccountsConfirmMsg + " }", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Verfiy user in add accounts page or not
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlAddAccounts
	 * @return
	 */
	public boolean verifyAddAccPgTitle(String pgTtlAddAccounts) {
		try {
			return wolWebUtil.verifyText(ttlAddAccountsPage, pgTtlAddAccounts);
		} catch (Exception e) {
			LogUtility.logException("---> verifyAddAccPgTitle <---",
					"Failed to navigate { " + pgTtlAddAccounts + " } page", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * input valid values in add accounts page
	 * 
	 * @author VSomalaraju-adm
	 * @param accNum, nickName
	 */
	public boolean inputAddAccountsDetails(String accNum, String nickName) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddAccountNumber, maxTimeOut);
			boolean accountNumber = webActions.isDisplayed(txtAddAccountNumber);
			if (accountNumber) {
				webActions.setValue(txtAddAccountNumber, accNum);
				webActions.setValue(txtAccountNickName, nickName);
				clickAddAccountButton();
				LogUtility.logInfo("---> inputAddAccountsDetails <---", "Add Account value entered successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> inputAddAccountsDetails <---",
					"Failed to enter account value in add webster accounts page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Used for removed account from profile
	 * 
	 * @author VSomalaraju-adm
	 * @param accountNum
	 * @throws Throwable
	 */
	public boolean removeAccountFromProfile(String accountNum) throws Throwable {
		boolean flag = false;
		try {
			boolean defaultAccClose = webActions.isDisplayed(defaultAccountClose);
			if (defaultAccClose) {
				webActions.clickElement(defaultAccountClose);
				webActions.clickElementJS(ConcurrentEngines.getEngine().getWebDriver()
						.findElement(By.xpath(accountPath.replaceAll("%s", accountNum))));
				waits.waitUntilElementIsPresent(removeAccount, 5);
				webActions.clickElementJS(removeAccount);
				LogUtility.logInfo("---> removeAccountFromProfile <---",
						"Clicked on Remove this account  for the account{" + accountNum + " } link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> removeAccountFromProfile <---",
					"Failed to clicked on Remove this account for { " + accountNum + " } ", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * Clicked on Add Account Button
	 * 
	 * @author VSomalaraju-adm
	 * @throws Throwable
	 */
	public boolean clickAddAccountButton() {
		boolean flag = false;
		try {
			flag = webActions.isDisplayed(btnAddAccount);
			wolWebUtil.clickWebElement(btnAddAccount, "clickAddAccountButton");
		} catch (Exception e) {
			LogUtility.logException("---> clickAddAccountButton <---", "Failed to click on add account button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify manage webster accounts confirmation page
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlManageAccounts
	 * @return
	 */
	public boolean verifyAddAccountsConfirmPageTitle(String pgTtlAddAccountsConfirm) {
		try {
			waits.waitUntilElementIsPresent(ttlAddWbstAccConfirm, maxTimeOut);
			return wolWebUtil.verifyTextContains(ttlAddWbstAccConfirm, pgTtlAddAccountsConfirm);
		} catch (Exception e) {
			LogUtility.logException("---> verifyManageAccountsConfirmationPageTitle <---",
					"Failed to navigate { " + pgTtlAddAccountsConfirm + " } page", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Verify manage webster accounts confirmation message
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlManageAccounts
	 * @return
	 */
	public boolean verifyAddAccountsConfirmMsg(String txtAddAccountsConfirmMsg) {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			if (waits.waitUntilElementIsPresent(txtAddWbstConfirmMsg, maxTimeOut)) {
				addAccountsConfirmMsg = webActions.getText(txtAddWbstConfirmMsg);
				flag = txtAddAccountsConfirmMsg.contains(addAccountsConfirmMsg);
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyManageAccountsConfirmationPageTitle <---",
					"Failed to verify { " + txtAddWbstConfirmMsg + " }in confirmation page", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * Used to get the accou8nt number and account name from the application
	 * 
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean getAccountDetails() {
		boolean flag = false;
		try {
			boolean defaultAccount = waits.waitUntilElementIsPresent(defaultAccountClose, maxTimeOut);
			if (defaultAccount) {
				String accountDetails = webActions.getText(defaultAccountClose);
				String[] subString = accountDetails.split("\\s", 2);
				getAccountNumber = subString[0];
				getAccountNumber = getAccountNumber.replaceAll("^0+", "");
				getAccountName = subString[1];
				LogUtility.logInfo("---> getAccountDetails <---",
						"Retrieved  { " + getAccountNumber + "} and { " + getAccountName + "} successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> getAccountDetails <---", "Failed Retrieve { " + getAccountNumber + "} and { "
					+ getAccountName + "}  in manage webster accounts page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Entering all the details in add accounts page
	 * 
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean enterAccountDetails() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddAccountNumber);
			boolean accountNumber = webActions.isDisplayed(txtAddAccountNumber);
			if (accountNumber) {
				webActions.setValue(txtAddAccountNumber, getAccountNumber);
				clickAddAccountButton();
				LogUtility.logInfo("---> enterAccountDetails <---",
						"Entered { " + getAccountNumber + " } account number successfully in add accounts page");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> enterAccountDetails <---",
					"Failed to enter { " + getAccountNumber + " } account number in add accounts page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify add existing account error message
	 * 
	 * @author VSomalaraju-adm
	 * @param addExistingAccMsg
	 * @return
	 */
	public boolean verifyAddExistingAccountMsg(String addExistingAccMsg) {
		try {
			addExistingAccountMsg = addExistingAccMsg.replace("{Value1 to replace}", getAccountName)
					.replace("{Value2 to replace}", getAccountNumber);
			return wolWebUtil.verifyTextContains(txtAddExistingAccMsg, addExistingAccountMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyAddExistingAccountMsg <---",
					"Failed to verify Message : " + addExistingAccountMsg + " :", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * enter Credit card details
	 * 
	 * @author VSomalaraju-adm
	 * @param creditCardNo
	 * @return
	 */
	public boolean enterCreditCardDetails(String creditCardNo) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddAccountNumber, maxTimeOut);
			if (webActions.isDisplayed(txtAddAccountNumber)) {
				webActions.setValue(txtAddAccountNumber, creditCardNo);
				clickAddAccountButton();
				LogUtility.logInfo("---> enterAccountDetails <---", "User Successfully entered { " + creditCardNo
						+ " } account number successfully in add accounts page");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> enterAccountDetails <---",
					"User failed to enter { " + creditCardNo + " } account number successfully in add accounts page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify Add existing credit card message
	 * 
	 * @author VSomalaraju-adm
	 * @param addExistingCardMsg
	 * @return
	 */
	public boolean verifyAddExistingCCMsg(String addExistingCardMsg) {
		try {
			waits.waitUntilElementIsPresent(txtAddExistingAccMsg, maxTimeOut);
			return wolWebUtil.verifyTextContains(txtAddExistingAccMsg, addExistingCardMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyAddExistingCCMsg <---",
					"Failed to verify error message : " + addExistingCardMsg + " :", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Provide nick name in manage webster accounts page
	 * 
	 * @author VSomalaraju-adm
	 * @param accountNumber
	 * @param nickName
	 * @return
	 */
	public boolean inputNickNameDetails(String accountNumber, String nickName) {
		boolean flag = false;
		try {
			newNickName = nickName + RandomStringUtils.randomNumeric(3);
			webActions.clickElement(defaultAccountClose);
			boolean givenAccountNo = webActions.isDisplayed(ConcurrentEngines.getEngine().getWebDriver()
					.findElement(By.xpath(accountPath.replaceAll("%s", accountNumber))));
			if (givenAccountNo) {
				webActions.clickElementJS(ConcurrentEngines.getEngine().getWebDriver()
						.findElement(By.xpath(accountPath.replaceAll("%s", accountNumber))));
				WebElement accountNickName = driver
						.findElement(By.xpath(String.format(txtAccNickNamePath, accountNumber)));
				webActions.clearValue(accountNickName);
				webActions.setValue(accountNickName, newNickName);
				webActions.clickElementJS(ConcurrentEngines.getEngine().getWebDriver()
						.findElement(By.xpath(String.format(btnContinuePath, accountNumber))));
				LogUtility.logInfo("---> inputNickNameDetails <---",
						" Clicked on the given accoutnumber { " + accountNumber + " } in Manage webster accounts page");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> inputNickNameDetails <---", " Failed to Click on the given accoutnumber { "
					+ accountNumber + " } in Manage webster accounts page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify nick name in manage webster accounts page
	 * 
	 * @author VSomalaraju-adm
	 * @param nickName
	 * @return
	 */
	public boolean verifyNickNameInAccountsHeader() {
		boolean flag = false;
		try {
			webActions.clickElement(defaultAccountClose);
			waits.waitForPageReadyState();
			boolean accountToVerifyNickName = webActions
					.isDisplayed(driver.findElement(By.xpath(accountPath.replaceAll("%s", accountNumber))));
			if (accountToVerifyNickName) {
				webActions.clickElementJS(ConcurrentEngines.getEngine().getWebDriver()
						.findElement(By.xpath(accountPath.replaceAll("%s", accountNumber))));
				getNickNameText = webActions.getText(ConcurrentEngines.getEngine().getWebDriver()
						.findElement(By.xpath(accountPath.replaceAll("%s", accountNumber))));
				if (getNickNameText.contains(newNickName) == true) {
					LogUtility.logInfo("---> verifyNickNameInAccountsHeader <---",
							"Nick name : " + newNickName + " : verified successfully in Manage webster accounts page");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyNickNameInAccountsHeader <---",
					"Failed to verify Nick name : " + newNickName + " : in Manage webster accounts page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify Add Webster account page level error message
	 * 
	 * @author VSomalaraju-adm
	 * @param genErrMsg
	 * @return
	 */
	public boolean verifyAddAccGenErrMessage(String genErrMsg) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtGenErrMsgAddAccount, maxTimeOut);
			flag = wolWebUtil.verifyText(txtGenErrMsgAddAccount, genErrMsg);
			LogUtility.logInfo("---> verifyAddAccGenErrMessage <---",
					" Page level error message { " + genErrMsg + " } is displayed successfully");
		} catch (Exception e) {
			LogUtility.logException("---> verifyAddAccGenErrMessage <---",
					"Page level error message { " + genErrMsg + " } is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify add webster accounts field level error message
	 * 
	 * @author VSomalaraju-adm
	 * @param addAccErrMsg
	 * @return
	 */
	public boolean verifyAddAccErrMessage(String addAccErrMsg) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddAccErrMsg, maxTimeOut);
			String errText = ConcurrentEngines.getEngine().getWebActions().getText(txtAddAccErrMsg);
			String[] newErrText = errText.split("\n", 2);
			String appErrText = newErrText[0] + newErrText[1];
			if (appErrText.equals(addAccErrMsg)) {
				LogUtility.logInfo("---> verifyAddAccErrMessage <---",
						" Add webster account error message { " + addAccErrMsg + " } is displayed successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyAddAccErrMessage <---",
					" Add webster account error message { " + addAccErrMsg + " } is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify page content in add webster accounts page
	 * 
	 * @author VSomalaraju-adm
	 * @param pgContentAddAcc
	 * @return
	 */
	public boolean verifyAddAccPageContent(String pgContentAddAcc) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddAccPageCont, maxTimeOut);
			String pgContent = ConcurrentEngines.getEngine().getWebActions().getText(txtAddAccPageCont);
			String[] pgText = pgContent.split("\n", 2);
			String appPageText = pgText[0] + pgText[1];
			if (appPageText.equals(pgContentAddAcc)) {
				LogUtility.logInfo("---> verifyAddAccPageContent <---",
						" Page content message { " + pgContentAddAcc + " } is displayed successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyAddAccPageContent <---",
					" Page content message { " + pgContentAddAcc + " } is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Used to click on Cancel button in add webster accounts page
	 * 
	 * @author VSomalaraju-adm
	 */
	public void clickAddAccountsCancelButton() throws Exception {
		try {
			waits.waitUntilElementIsPresent(btnCancelAddAccounts, maxTimeOut);
			webActions.clickElement(btnCancelAddAccounts);
			LogUtility.logInfo("---> clickAddAccountsCancelButton <---",
					"Clicked on : Cancel : button in add webster accounts page");
		} catch (Exception e) {
			LogUtility.logException("---> clickAddAccountsCancelButton <---",
					"Failed on : Cancel : button in add webster accounts page", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * used to click on No button in add webster accounts light box
	 * 
	 * @author VSomalaraju-adm
	 */
	public void clickNoInLightBoxAddAccounts() throws Exception {
		try {
			waits.waitUntilElementIsPresent(btnNoAddAccounts, maxTimeOut);
			webActions.clickElement(btnNoAddAccounts);
			LogUtility.logInfo("---> clickNoInLightBoxAddAccounts <---",
					"Clicked on : No : button in add webster accounts page light box");
		} catch (Exception e) {
			LogUtility.logException("---> clickNoInLightBoxAddAccounts <---",
					"Failed to Click on : No : button in add webster accounts page light box", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * Used to click on yes button in add webster accounts page light box
	 * 
	 * @author VSomalaraju-adm
	 */
	public void clickYesInLightBoxAddAccounts() throws Exception {
		try {
			waits.waitUntilElementIsPresent(btnYesAddAccounts, maxTimeOut);
			webActions.clickElement(btnYesAddAccounts);
			LogUtility.logInfo("---> clickYesInLightBoxAddAccounts <---",
					"Clicked on : Yes : button in add webster accounts page light box");
		} catch (Exception e) {
			LogUtility.logException("---> clickYesInLightBoxAddAccounts <---",
					"Failed to Click on Yes button in add webster accounts page light box", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * Verify Pap up message in Manage webster accounts page
	 * 
	 * @author VSomalaraju-adm
	 * @param popUpMsg
	 * @return
	 */
	public boolean verifyPopUpMsgInManageAccounts(String popUpMsg) {
		boolean flag = false;
		try {
			String str = webActions.getText(txtPopUpMessage);
			if (str.equalsIgnoreCase(popUpMsg)) {
				LogUtility.logInfo("---> verifyPopUpMsgInManageAccounts <---",
						"Pop up Message : " + popUpMsg + " : verified successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyPopUpMsgInManageAccounts <---",
					"Pop up Message : " + popUpMsg + " : not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on the Manage user access link in pop up
	 * 
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean clickLinkInPopUpMessage() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(lnkManageUserAccess, maxTimeOut)) {
				webActions.clickElement(lnkManageUserAccess);
				LogUtility.logInfo("---> clickLinkInPopUpMessage <---",
						"Clicked on : Manage User Access : link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> clickLinkInPopUpMessage <---",
					"Failed to Click on : Manage User Access : link", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean clickViewLinkMngAuditPage() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(lnkViewMngAuditPage, maxTimeOut)) {
				webActions.clickElement(lnkViewMngAuditPage);
				LogUtility.logInfo("Clicked on : View : link in manage audit trail page");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("---> clickViewLinkMngAuditPage <---",
					"Failed to Click on : View : link in manage audit trail page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param auditDetails
	 * @return
	 */
	public boolean verifyAccountNoInAuditDetailsPage(Map<String, String> auditDetails) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(txtAccountNumberAuditDetails, maxTimeOut)) {
				flag = webActions.getText(txtAccountNumberAuditDetails).trim()
						.equals(auditDetails.get("AccountorCreditCardNumber"));
				LogUtility.logInfo("Account number { " + auditDetails.get("AccountorCreditCardNumber")
						+ " } verified successfully in audit details page");
			}
		} catch (Exception e) {
			LogUtility.logException(
					"---> verifyAccountNoInAuditDetailsPage <---", "Failed to verify account number: "
							+ auditDetails.get("AccountorCreditCardNumber") + ": audit details page",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param auditDetails
	 * @return
	 */
	public boolean verifyUpdatedNickNameInAuditDetails(Map<String, String> auditDetails) {
		boolean flag = false;
		try {
			flag = txtUpdatedNickName.getText().equals(auditDetails.get("NickName"));
			LogUtility.logInfo("---> verifyUpdatedNickNameInAuditDetails <---",
					"Text : " + auditDetails.get("NickName") + " : verified successfully in audit details page");
		} catch (Exception e) {
			LogUtility.logException("---> verifyUpdatedNickNameInAuditDetails <---",
					"Failed to verify nick name: " + auditDetails.get("NickName") + ": audit details page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param nickNameDetails
	 * @return
	 */
	public boolean verifyNickNameConfirmationMessage(Map<String, String> nickNameDetails) {
		boolean flag = false;
		try {
			return wolWebUtil.verifyText(txtConfirmationMessage, nickNameDetails.get("UpdateNickNameMessage"));

		} catch (Exception e) {
			LogUtility.logException(
					"---> verifyNickNameConfirmationMessage <---", "Failed to verify nick name conformation message: "
							+ nickNameDetails.get("UpdateNickNameMessage") + ": in update webster accounts page",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param accountInfo
	 * @return
	 */
	public boolean updateNickName(Map<String, String> accountInfo) {
		boolean flag = false;
		try {
			WebElement txtNickName = driver
					.findElement(By.xpath(nickName.replace("%s", accountInfo.get("AccountorCreditCardNumber"))));
			webActions.clearValue(txtNickName);
			webActions.setValue(txtNickName, accountInfo.get("NickName"));
			accountEligibilityWebcomPage.clickSubmitButton();
			waits.waitForPageToLoad(maxTimeOut);
			waits.staticWait(3);// It is required to work this function
			LogUtility.logInfo("---> updateNickName <---", "Nick name { " + accountInfo.get("NickName")
					+ " } updated successfully for account {" + accountInfo.get("AccountorCreditCardNumber") + " }");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("---> updateNickName <---",
					" Unable to update { " + accountInfo.get("NickName") + " } in WEBCOM application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param accountInfo
	 * @return
	 */
	public boolean clearNickNameValue(Map<String, String> accountInfo) {
		boolean flag = false;
		try {
			WebElement txtNickName = driver
					.findElement(By.xpath(nickName.replace("%s", accountInfo.get("AccountorCreditCardNumber"))));
			webActions.clearValue(txtNickName);
			accountEligibilityWebcomPage.clickSubmitButton();
			waits.waitForPageToLoad(maxTimeOut);
			waits.staticWait(3);// It is required to work this function
			LogUtility.logInfo("---> updateNickName <---", "Nick name { " + accountInfo.get("NickName")
					+ " } updated successfully for account {" + accountInfo.get("AccountorCreditCardNumber") + " }");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("---> updateNickName <---",
					" Unable to update { " + accountInfo.get("NickName") + " } in WEBCOM application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}
}
