package com.wb.wol_web.pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * @author rpagadala-adm
 *
 */
public class OnlineBillingWebcomPage extends ObjectBase {

	public OnlineBillingWebcomPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "td>input[type='checkbox']")
	protected List<WebElement> listcheckboxAccounts;

	@FindBy(id = "accounts")
	protected WebElement listWebsterAccounts;

	@FindBy(css = "input[value='View Selected Statement']")
	protected WebElement btnViewStmt;

	@FindBy(css = "thead>tr>th")
	protected List<WebElement> listLoanStmtsHeadings;

	@FindBy(css = "tr > th:nth-child(1)")
	protected List<WebElement> listLoanDetailHeadings;

	public String txtAccount = "//td[contains(text(),'%s')]//preceding-sibling::td/input[1]";
	public String txtAccountEdelivery = "//td[contains(text(),'%s')]/following-sibling::td[1]";
	public String fieldPath = "//td[contains(text(),'%s')]/following-sibling::td/input[@type='checkbox']";

	/**
	 * clickOnAccountCheckbox: To click on the account check box
	 * 
	 * @param typeAction
	 * @param accountNumber
	 * @return
	 */
	public boolean clickOnAccountCheckbox(String typeAction, String accountNumber) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			waits.waitForPageReadyState();
			WebElement checkbox = driver.findElement(By.xpath(String.format(txtAccount, accountNumber)));
			if (typeAction.equalsIgnoreCase("Unchecked")) {
				if (webActions.isChecked(checkbox))
					webActions.clickElement(checkbox);
			} else if (typeAction.equalsIgnoreCase("Checked"))
				if (!webActions.isChecked(checkbox))
					webActions.clickElement(checkbox);
			LogUtility.logInfo("--->clickOnAccountCheckbox<---",
					"Account Number: " + accountNumber + " corresponding checkbox is " + typeAction);
			return true;
		} catch (Exception e) {
			LogUtility.logException("-->clickOnAccountCheckbox<--",
					"Account Number: " + accountNumber + " corresponding checkbox is not " + typeAction, e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * selectAccount: To select account from dropdown
	 * 
	 * @param account
	 * @return
	 */
	public boolean selectAccount(String account) {
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(listWebsterAccounts)) {
				wolWebUtil.selectValueByPartialVisibleText(listWebsterAccounts, account);
				LogUtility.logInfo("--->selectAccount<---", "Account Number: " + account + " is selected");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->selectAccount<--", "Account Number: " + account + " is not selected", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButton: To click on the button of view selected statements
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(btnViewStmt)) {
				webActions.clickElement(btnViewStmt);
				LogUtility.logInfo("--->clickOnButton<---", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "Button: " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public int verifyLabels(String pageName, List<String> listLabelValues) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		int count = 0;
		try {
			List<WebElement> listNames = null;
			switch (pageName) {
			case "Customer Loan statement list":
				listNames = listLoanStmtsHeadings;
				break;
			case "Loan Detail":
				listNames = listLoanDetailHeadings;
				break;
			default:
				LogUtility.logInfo("----->verifyLabels<----", "No case is matched");
				break;
			}
			if (webActions.isDisplayed(listNames.get(0)))
				for (WebElement label : listNames) {
					if (wolWebUtil.verifyTextContains(label, listLabelValues.toString())) {
						LogUtility.logInfo("----->verifyLabels<----", label + " is present");
						count++;
					}
				}
		} catch (Exception e) {
			LogUtility.logException("-->verifyLabels<--", "labels: " + listLabelValues.toString() + " is not present",
					e, LoggingLevel.ERROR, true);
		}
		return count;
	}

	/**
	 * checkAccountEdelivery: To check the eDelivery status of given account number
	 * 
	 * @param status
	 * @param accountNumber
	 * @return
	 */
	public boolean checkAccountEdelivery(String status, String accountNumber) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			WebElement txtStatusEdelivery = driver
					.findElement(By.xpath(String.format(txtAccountEdelivery, accountNumber)));
			if (wolWebUtil.verifyTextContains(txtStatusEdelivery, status)) {
				LogUtility.logInfo("--->checkAccountEdelivery<---",
						"Account Number: " + accountNumber + " corresponding eDelivery status is " + status);
				return true;
			}

		} catch (Exception e) {
			LogUtility.logException("-->checkAccountEdelivery<--",
					"Account Number: " + accountNumber + " corresponding eDelivery status is not " + status, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnCheckbox: To click on the checkbox
	 * 
	 * @param fieldName
	 * @param accountNumber
	 * @return
	 */
	public boolean clickOnCheckbox(String fieldName, String accountNumber) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			WebElement targetedField = driver.findElement(By.xpath(String.format(fieldPath, accountNumber)));
			if (webActions.isDisplayed(targetedField)) {
				webActions.clickElement(targetedField);
				LogUtility.logInfo("--->clickOnCheckbox<---",
						"Account Number: " + accountNumber + " corresponding remove account field is " + fieldName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnCheckbox<--",
					"Account Number: " + accountNumber + " corresponding remove account field is not " + fieldName, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

}
