package com.wb.wol_web.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author Veerababu Pedireddi
 *
 */

public class AccountInformationPage extends ObjectBase {

	public AccountInformationPage() {
		PageFactory.initElements(driver, this);
	}

	FinancialSummaryPage financialSummaryPage = new FinancialSummaryPage();

	public String overDrafttoolTipContent = "";
	public String accountReceivesODProtectionStatus = "";
	public String nickNameValue = "";
	public String statementeDeliveryStatus = "";
	public String viewDepositDetailsStatus = "";
	public String defaultBillPayAccountStatus = "";
	public String overDraftServicesStatus = "";
	public String currentBalanceValue = "";
	public String availableBalanceValue = "";
	public String accountTypeValue = "";
	public String accountDetails = "";
	public String accountStsValue = "";
	public String lastDepositAmount = "";
	public String interestPercentage = "";
	public String annualInterestPercentage = "";
	public String lastInterestAmount = "";
	public String yearDateInterestAmount = "";
	public String prevYearDateInterestValue = "";
	public String maturityDate = "";
	public String retirementAccStatus = "";
	public String creditLimitValue = "";
	public String nextPaymentDueAmount = "";
	public String lastPaymentDate = "";
	public String lateChargesAmount = "";
	public String feesAmount = "";
	public String availableBalanceAmount = "";
	public String escrowBalanceAmount = "";
	public String ytdTaxesPaidDate = "";
	public String prevYTDTaxesPaidDate = "";
	public String heldAtValue = "";

	@FindBy(xpath = "//h1[contains(.,'Account Information')]")
	protected WebElement titleAccInfoPage;

	@FindBy(name = "accountNumber")
	protected WebElement lblaccNumber;

	@FindBy(id = "nickname__link")
	protected WebElement lnkNickNameEdit;

	@FindBy(xpath = "//span[@id='eDelivery__display']/span")
	protected WebElement lblStmteDeliverySts;

	@FindBy(id = "eDelivery__link")
	protected WebElement lnkStmteDeliveryEditIcon;

	@FindBy(xpath = "//span[@id='viewDepositDetails__display']/span")
	protected WebElement lblViewDepositDetailsSts;

	@FindBy(id = "viewDepositDetails__link")
	protected WebElement lnkViewDepositDetailsEditIcon;

	@FindBy(xpath = "//span[@id='defaultBillpay__display']/span")
	protected WebElement lblDefaultBillPaySts;

	@FindBy(id = "defaultBillpay__link")
	protected WebElement lnkDefaultBillPayEditIcon;

	@FindBy(id = "viewDepositDetails__label")
	protected WebElement lblDepositDetails;

	@FindBy(id = "account-details-no-accounts__pageErrors__account-details-no-accounts__pageError__body")
	protected WebElement msgNoAccounts;

	@FindBy(xpath = "//span[@id='status__display']/span")
	protected WebElement accountStatus;

	@FindBy(id = "status__label")
	protected WebElement lblStatus;

	@FindBy(id = "status__label__tooltip")
	protected WebElement toolTipStatusContent;

	@FindBy(id = "overdraftProtection__label")
	protected WebElement lblOverDraftProtection;

	@FindBy(xpath = "//span[@id='overdraftProtection__display']/span")
	protected WebElement overDraftProtectionStatus;

	@FindBy(id = "overdraftProtection__label__tooltip")
	protected WebElement toolTipOverDraftProtectionContent;

	@FindBy(xpath = "//h1[contains(.,'What would you like to do next?')]")
	protected WebElement headerNextLinks;

	@FindBy(xpath = "//a[contains(.,'View Transaction History')]")
	protected WebElement lnkViewTransHistory;

	@FindBy(xpath = "//a[contains(.,'View Statements')]")
	protected WebElement lnkViewStatements;

	@FindBy(xpath = "//a[contains(.,'View Account Balances')]")
	protected WebElement lnkViewAccBalances;

	@FindBy(id = "primary_balance__display")
	protected WebElement lblPrimaryBalanceValue;

	@FindBy(id = "secondary_balance__display")
	protected WebElement lblSecondaryBalanceValue;

	@FindBy(id = "primary_balance__label")
	protected WebElement lblPrimaryBalanceField;

	@FindBy(id = "secondary_balance__label")
	protected WebElement lblSecondaryBalanceField;

	@FindBy(id = "overviewSection__section-title")
	protected WebElement lblOverViewSection;

	@FindBy(id = "accountType__label")
	protected WebElement lblAccountTypeField;

	@FindBy(name = "accountType")
	protected WebElement lblAccountTypeValue;

	@FindBy(id = "accountNumber__label")
	protected WebElement lblAccountNumberField;

	@FindBy(id = "lastDeposit__label")
	protected WebElement lblLastDepositField;

	@FindBy(name = "lastDeposit")
	protected WebElement lblLastDepositValue;

	@FindBy(id = "interestSection__section-title")
	protected WebElement lblInterestSection;

	@FindBy(id = "currentInterestRate__label")
	protected WebElement lblCurrentInterestRateField;

	@FindBy(name = "currentInterestRate")
	protected WebElement lblCurrentInterestRateValue;

	@FindBy(id = "currentAPY__label")
	protected WebElement lblCurrentAPYField;

	@FindBy(name = "currentAPY")
	protected WebElement lblCurrentAPYValue;

	@FindBy(id = "lastInterest__label")
	protected WebElement lblLastInterestField;

	@FindBy(name = "lastInterest")
	protected WebElement lblLastInterestValue;

	@FindBy(id = "YTDInterestPaid__label")
	protected WebElement lblYTDInterestPaidField;

	@FindBy(name = "YTDInterestPaid")
	protected WebElement lblYTDInterestPaidValue;

	@FindBy(id = "prevYTDInterestPaid__label")
	protected WebElement lblPrevYTDInterestPaidField;

	@FindBy(name = "prevYTDInterestPaid")
	protected WebElement lblPrevYTDInterestPaidValue;

	@FindBy(id = "featuresSection__section-title")
	protected WebElement lblFeaturesSection;

	@FindBy(id = "defaultBillpay__label")
	protected WebElement lblDefaultBillPayField;

	@FindBy(id = "nickname__label")
	protected WebElement lblNickNameField;

	@FindBy(id = "eDelivery__label")
	protected WebElement lbleDeliveryField;

	@FindBy(id = "overdraftEligible__label")
	protected WebElement lblOverDraftServicesField;

	@FindBy(name = "overdraftEligible")
	protected WebElement lblOverDraftEligibleValue;

	@FindBy(id = "maturityDate__label")
	protected WebElement lblMaturityDateField;

	@FindBy(name = "maturityDate")
	protected WebElement lblMaturityDate;

	@FindBy(id = "retirementAccount__label")
	protected WebElement lblRetirementAccField;

	@FindBy(name = "retirementAccount")
	protected WebElement lblRetirementAccValue;

	@FindBy(id = "creditLimit__label")
	protected WebElement lblCreditLimitField;

	@FindBy(name = "creditLimit")
	protected WebElement lblCreditLimitAmount;

	@FindBy(id = "paymentSection__section-title")
	protected WebElement lblPaymentSection;

	@FindBy(id = "nextPaymentDue__label")
	protected WebElement lblNextPaymentField;

	@FindBy(name = "nextPaymentDue")
	protected WebElement lblNextPaymentDueAmount;

	@FindBy(id = "lastPaymentDate__label")
	protected WebElement lblLastPymtDateField;

	@FindBy(name = "lastPaymentDate")
	protected WebElement lblLastPymtDate;

	@FindBy(id = "lateCharges__label")
	protected WebElement lblLateChargesField;

	@FindBy(name = "lateCharges")
	protected WebElement lblLateChargesAmount;

	@FindBy(id = "fees__label")
	protected WebElement lblFeesField;

	@FindBy(name = "fees")
	protected WebElement lblFeesAmount;

	@FindBy(id = "availableBalance__label")
	protected WebElement lblAvailableBalanceField;

	@FindBy(name = "fees")
	protected WebElement lblAvailableBalanceAmount;

	@FindBy(id = "escrowBalance__label")
	protected WebElement lblEscrowBalanceField;

	@FindBy(name = "escrowBalance")
	protected WebElement lblEscrowBalanceAmount;

	@FindBy(id = "YTDTaxesPaid__label")
	protected WebElement lblYTDTaxesPaidField;

	@FindBy(name = "YTDTaxesPaid")
	protected WebElement lblYTDTaxesPaidDate;

	@FindBy(id = "prevYTDTaxesPaid__label")
	protected WebElement lblPrevYTDTaxesPaidField;

	@FindBy(name = "prevYTDTaxesPaid")
	protected WebElement lblPrevYTDTaxesPaidDate;

	@FindBy(id = "heldAt__label")
	protected WebElement lblHeldAtField;

	@FindBy(name = "heldAt")
	protected WebElement lblHeldAtValue;

	/**
	 * To Verify the Account Information Page Title
	 */

	public boolean verifyAccInfoPageTitle(String accInfoPageTitle) {
		try {
			waits.waitUntilElementIsPresent(titleAccInfoPage, 20);
			return wolWebUtil.verifyText(titleAccInfoPage, accInfoPageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyAccInfoPageTitle", accInfoPageTitle + " Page is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Account Number in Account information page
	 */

	public boolean verifyAccNumber(String accNumber) {
		try {
			// After selecting the Account, Account details loading takes time
			waits.staticWait(3);
			return wolWebUtil.verifyText(lblaccNumber, accNumber);
		} catch (Exception e) {
			LogUtility.logException("verifyAccNumber", accNumber + "  is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the Account Nickname Edit icon
	 */

	public boolean clickOnEditNickName() {
		boolean flag = false;
		try {
			boolean editNickName = webActions.isDisplayed(lnkNickNameEdit);
			if (editNickName) {
				webActions.clickElement(lnkNickNameEdit);
				LogUtility.logInfo("---> clickOnAccList <---", "Clicked On Edit Nick name for Account");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnEditNickName", " Unable to click on Edit Nick Name link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Updated Nick name in Account information page
	 */

	public boolean verifyNickNameInAcccInfoPage() {
		boolean flag = false;
		try {
			String updatedNickName = AddOrMangeWebsterAccountsPage.accountNickNameInPreviewPage;
			String nickNameAccPage = webActions.getText(financialSummaryPage.lblAccountNickNameDisplay);
			if (updatedNickName.equals(nickNameAccPage)) {
				LogUtility.logInfo("---> verifyNickNameInAcccInfoPage <---",
						"Verify Account Nick Name in Account Information Page");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNickNameInAcccInfoPage", " Nick name is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Statement eDelivery field should be displayed as "Yes/No"
	 */

	public boolean verifyStatementeDeliveryStatus(String StmteDeliverySts) {
		try {
			waits.waitUntilElementIsPresent(lblStmteDeliverySts, 25);
			return wolWebUtil.verifyText(lblStmteDeliverySts, StmteDeliverySts);
		} catch (Exception e) {
			LogUtility.logException("verifyStatementeDeliveryStatus", StmteDeliverySts + " status is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the edit icon for Statement eDelivery field
	 */

	public boolean clickOnStatementeDeliveryEditIcon() {
		boolean flag = false;
		try {
			boolean stmtDeliveryEditIcon = webActions.isDisplayed(lnkStmteDeliveryEditIcon);
			if (stmtDeliveryEditIcon) {
				webActions.clickElement(lnkStmteDeliveryEditIcon);
				LogUtility.logInfo("--->clickOnStatementeDeliveryEditIcon<---",
						"Clicked on Statement e Delivery edit Icon");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnStatementeDeliveryEditIcon",
					" Statement Delivery Edit Icon is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the View Deposit Details field should be displayed as "Yes/No"
	 */

	public boolean verifyDepositDetailsStatus(String depositDetailsSts) {
		try {
			waits.waitUntilElementIsPresent(lblViewDepositDetailsSts, 20);
			return wolWebUtil.verifyText(lblViewDepositDetailsSts, depositDetailsSts);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositDetailsStatus", depositDetailsSts + " status is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the edit icon for View Deposit Details field
	 */

	public boolean clickOnDepositDetailsEditIcon() {
		boolean flag = false;
		try {
			boolean depositDetailsEditIcon = webActions.isDisplayed(lnkViewDepositDetailsEditIcon);
			if (depositDetailsEditIcon) {
				webActions.clickElement(lnkViewDepositDetailsEditIcon);
				LogUtility.logInfo("--->clickOnDepositDetailsEditIcon<---",
						"Clicked on View Deposit Details edit Icon");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnDepositDetailsEditIcon", "Unable to click on Deposit details Edit Icon",
					e, LoggingLevel.ERROR, true);
			LogUtility.logError("--->clickOnDepositDetailsEditIcon<---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To Verify the Default Bill Pay field should be displayed as "Yes/No"
	 */

	public boolean verifyDefaultBillPayAccStatus(String defaultBillPayAccSts) {
		try {
			waits.waitUntilElementIsPresent(lblDefaultBillPaySts, 20);
			return wolWebUtil.verifyText(lblDefaultBillPaySts, defaultBillPayAccSts);
		} catch (Exception e) {
			LogUtility.logException("verifyDefaultBillPayAccStatus", defaultBillPayAccSts + " Status is not displayed",
					e, LoggingLevel.ERROR, true);
			LogUtility.logError("--->verifyDefaultBillPayAccStatus<---", e.getMessage());
			return false;
		}
	}

	/**
	 * To Click on the edit icon for Default Bill Pay field
	 */

	public boolean clickOnDefaultBillPayEditIcon() {
		boolean flag = false;
		try {
			boolean billPayEditIcon = webActions.isDisplayed(lnkDefaultBillPayEditIcon);
			if (billPayEditIcon) {
				webActions.clickElement(lnkDefaultBillPayEditIcon);
				LogUtility.logInfo("--->clickOnDefaultBillPayEditIcon<---", "Clicked on Default Bill Pay edit Icon");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnDefaultBillPayEditIcon", "Unable to click on Default Billpay Edit Icon",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Deposit details Text is not present
	 */
	public boolean depositTextNotPresent() {
		try {
			return wolWebUtil.elementNotDisplay(lblDepositDetails);
		} catch (Exception e) {
			LogUtility.logException("depositTextNotPresent", " Deposit text is not present", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Verify the No Accounts error message displayed
	 */

	public boolean verifyNoAccsErrorMsg(String noAccountsErrMsg) {
		try {
			waits.waitUntilElementIsPresent(msgNoAccounts, 20);
			return wolWebUtil.verifyText(msgNoAccounts, noAccountsErrMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyNoAccsErrorMsg", noAccountsErrMsg + " error message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Account Status as Open/Closed/Purged
	 */

	public boolean verifyAccountStatus(String accStatus) {
		try {
			return wolWebUtil.verifyText(accountStatus, accStatus);
		} catch (Exception e) {
			LogUtility.logException("verifyAccountStatus", accStatus + " status is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the Account Status link
	 */

	public boolean clickOnAccountStatus() {
		boolean flag = false;
		try {
			boolean accountStatusLink = webActions.isDisplayed(lblStatus);
			if (accountStatusLink) {
				webActions.clickElement(lblStatus);
				LogUtility.logInfo("---> clickOnAccountStatus <---", "Clicked On Account Status Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnAccountStatus", "Unable to click on Account status link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;

	}

	/**
	 * To Verify the Open/Closed/Purged Account Status tooltip content
	 */

	public boolean verifyAccStsToolTipContent(String statusToolTipContent) {
		try {
			return wolWebUtil.verifyText(toolTipStatusContent, statusToolTipContent);
		} catch (Exception e) {
			LogUtility.logException("verifyAccStsToolTipContent",
					statusToolTipContent + " Tooltip content is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To return the Account Receives OverDraft Protection tooltip content
	 */

	public String captureODProtectionToolTipContent() {
		try {
			overDrafttoolTipContent = webActions.getText(toolTipOverDraftProtectionContent);
			LogUtility.logInfo("---> captureODProtectionToolTipContent <---",
					"Captured OverDraft Protection ToolTip Content");
		} catch (Exception e) {
			LogUtility.logException("verifyODProtectionToolTipContent",
					" OD Protection Tooltip content is not displayed", e, LoggingLevel.ERROR, true);
		}
		return overDrafttoolTipContent;
	}

	/**
	 * To return the Account Receives OverDraft Protection Status as yes/No
	 */

	public String captureODProtectionStatus() {
		try {
			accountReceivesODProtectionStatus = webActions.getText(overDraftProtectionStatus);
			LogUtility.logInfo("---> captureODProtectionStatus <---", "Captured OverDraft Protection Status");
		} catch (Exception e) {
			LogUtility.logException("captureODProtectionStatus", " ODProtection statu is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return accountReceivesODProtectionStatus;
	}

	/**
	 * To Verify the Account Receives OverDraft Protection Status as Yes/No and
	 * verify the tooltip content
	 */

	public boolean verifyODProtectionToolTipContent(String odToolTipContent) {
		boolean flag = false;
		try {
			String toolTipContent[] = odToolTipContent.split("/");
			captureODProtectionStatus();
			captureODProtectionToolTipContent();
			if (accountReceivesODProtectionStatus.equals("Yes")) {
				if (overDrafttoolTipContent.equals(toolTipContent[0])) {
					flag = true;
					LogUtility.logInfo("---> verifyODProtectionStatus <---", "Verify OverDraft Protection Status");
				}
			} else if (accountReceivesODProtectionStatus.equals("No")) {
				if (overDrafttoolTipContent.equals(toolTipContent[1])) {
					flag = true;
					LogUtility.logInfo("---> verifyODProtectionStatus <---", "Verify OverDraft Protection Status");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyODProtectionToolTipContent",
					" ODProtection Tooltip content is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on the Account Receives OverDraft Protection link
	 */

	public boolean clickOnODProtectionLink() {
		boolean flag = false;
		try {
			boolean accountStatusLink = webActions.isDisplayed(lblOverDraftProtection);
			if (accountStatusLink) {
				webActions.clickElement(lblOverDraftProtection);
				LogUtility.logInfo("---> clickOnODProtectionLink <---", "Clicked On OverDraft Protection Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnODProtectionLink", " Unable to click on ODProtection link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the What would you like to do next? text displayed or not
	 */
	public boolean verifyNextLinksText() {
		try {
			return webActions.isDisplayed(headerNextLinks);
		} catch (Exception e) {
			LogUtility.logException("verifyNextLinksText", " Next Links text is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the View Transaction History Link displayed or not
	 */
	public boolean verifyTransHistoryLink() {
		try {
			return webActions.isDisplayed(lnkViewTransHistory);
		} catch (Exception e) {
			LogUtility.logException("verifyTransHistoryLink", " History Link is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the View Account Balances Link displayed or not
	 */
	public boolean verifyAccBalancesLink() {
		try {
			return webActions.isDisplayed(lnkViewAccBalances);
		} catch (Exception e) {
			LogUtility.logException("verifyAccBalancesLink", " Account Balances Link is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the View Account Statements Link displayed or not
	 */
	public boolean verifyAccStatementsLink() {
		try {
			return webActions.isDisplayed(lnkViewStatements);
		} catch (Exception e) {
			LogUtility.logException("verifyAccStatementsLink", " Account statements Link is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the View Statements link
	 */

	public boolean clickOnViewStatementsLink() {
		boolean flag = false;
		try {
			boolean viewStatementsLink = webActions.isDisplayed(lnkViewStatements);
			if (viewStatementsLink) {
				webActions.clickElement(lnkViewStatements);
				LogUtility.logInfo("---> clickOnViewStatementsLink <---", "Clicked On View Statements Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewStatementsLink", " Unable to click on view statements link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Primary Balances displayed as N/A for Purged Account
	 */
	public boolean verifyPrimaryBalance(String primaryBalance) {
		try {
			return wolWebUtil.verifyText(lblPrimaryBalanceValue, primaryBalance);
		} catch (Exception e) {
			LogUtility.logException("verifyPrimaryBalance", " Primary Balance Link is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Primary Balances displayed as N/A for Purged Account
	 */
	public boolean verifySecondaryBalance(String scecondaryBalance) {
		try {
			return wolWebUtil.verifyText(lblSecondaryBalanceValue, scecondaryBalance);
		} catch (Exception e) {
			LogUtility.logException("verifySecondaryBalance", " Secondary Balance Link is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Current Balance field and corresponding value should display
	 */

	public boolean verifyCurrentBalanceFieldAndValue(String currentBalance, String value) {
		boolean flag = false;
		try {
			String currentBalanceField = webActions.getText(lblPrimaryBalanceField);
			currentBalanceValue = webActions.getText(lblPrimaryBalanceValue);
			if (currentBalanceField.equals(currentBalance) && currentBalanceValue.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyCurrentBalanceFieldAndValue <---",
						"Current Balance field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCurrentBalanceFieldAndValue",
					currentBalance + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Available Balance field and corresponding value should display
	 */

	public boolean verifyAvailableBalanceFieldAndValue(String availableBalance, String value) {
		boolean flag = false;
		try {
			String availableBalanceField = webActions.getText(lblSecondaryBalanceField);
			availableBalanceValue = webActions.getText(lblSecondaryBalanceValue);
			if (availableBalanceField.equals(availableBalance) && availableBalanceValue.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyAvailableBalanceFieldAndValue <---",
						"Available Balance field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAvailableBalanceFieldAndValue",
					availableBalance + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Account OverView text should display
	 */

	public boolean verifyOverViewSection(String overViewSection) {
		try {
			return wolWebUtil.verifyText(lblOverViewSection, overViewSection);
		} catch (Exception e) {
			LogUtility.logException("verifyOverViewSection", overViewSection + " is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Account Type field and corresponding value should display
	 */

	public boolean verifyAccountTypeFieldAndValue(String accountType, String value) {
		boolean flag = false;
		try {
			String accountTypeField = webActions.getText(lblAccountTypeField);
			accountTypeValue = webActions.getText(lblAccountTypeValue);
			if (accountTypeField.equals(accountType) && accountTypeValue.equals(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyAccountTypeFieldAndValue <---",
						"Account Type field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountTypeFieldAndValue",
					accountType + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To capture the Nickname value
	 */

	public String captureAccNickName() {
		try {
			nickNameValue = webActions.getText(financialSummaryPage.lblAccountNickNameDisplay);
			LogUtility.logInfo("---> captureAccNickName <---", "Captured Account Nickname Value");
		} catch (Exception e) {
			LogUtility.logException("captureAccNickName", "Unable to capture the Account NIckname", e,
					LoggingLevel.ERROR, true);
		}
		return nickNameValue;
	}

	/**
	 * To verify the Nickname field and corresponding value should display
	 */

	public boolean verifyNickNameFieldAndValue(String nickName) {
		boolean flag = false;
		try {
			String nickNameField = webActions.getText(lblNickNameField);
			captureAccNickName();
			if (nickNameField.equals(nickName) && !nickNameValue.equals("")) {
				flag = true;
				LogUtility.logInfo("---> verifyNickNameFieldAndValue <---", "Nick name field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNickNameFieldAndValue", nickName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Account Number field and corresponding value should display
	 */

	public boolean verifyAccountNumberFieldAndValue(String accountNumber, String value) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lblAccountNumberField, 30);
			String accountNumberField = webActions.getText(lblAccountNumberField);
			accountDetails = webActions.getText(lblaccNumber);
			if (accountNumberField.equals(accountNumber) && accountDetails.equals(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyAccountTypeFieldAndValue <---",
						"Account Number field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountNumberFieldAndValue",
					accountNumber + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Account Status field and corresponding status should display
	 */

	public boolean verifyAccountStatusFieldAndValue(String accountSts, String value) {
		boolean flag = false;
		try {
			String accountStatusField = webActions.getText(lblStatus);
			accountStsValue = webActions.getText(accountStatus);
			if (accountStatusField.equals(accountSts) && accountStsValue.equals(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyAccountStatusFieldAndValue <---",
						"Account Status field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountStatusFieldAndValue",
					accountSts + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Last deposit field and corresponding values should display
	 */

	public boolean verifyLastDepositFieldAndValue(String lastDeposit, String amount, String date) {
		boolean flag = false;
		try {
			String lastDepositField = webActions.getText(lblLastDepositField);
			lastDepositAmount = webActions.getText(lblLastDepositValue);
			String lastDepositDate = webActions.getText(lblLastDepositValue);
			if (lastDepositField.equals(lastDeposit) && lastDepositAmount.contains(amount)
					&& lastDepositDate.contains(date)) {
				flag = true;
				LogUtility.logInfo("---> verifyLastDepositFieldAndValue <---",
						"Last Deposit field and Values are displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLastDepositFieldAndValue",
					lastDeposit + "field " + amount + ", " + date + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Account Interest text should display
	 */

	public boolean verifyInterestSection(String interestSection) {
		try {
			return wolWebUtil.verifyText(lblInterestSection, interestSection);
		} catch (Exception e) {
			LogUtility.logException("verifyInterestSection", interestSection + " is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Current Interest Rate field and corresponding value should
	 * display
	 */

	public boolean verifyCurrentIntRateFieldAndValue(String interestRate, String value) {
		boolean flag = false;
		try {
			String interestRateField = webActions.getText(lblCurrentInterestRateField);
			interestPercentage = webActions.getText(lblCurrentInterestRateValue);
			if (interestRateField.equals(interestRate) && interestPercentage.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyCurrentIntRateFieldAndValue <---",
						"Current Interest Rate field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCurrentIntRateFieldAndValue",
					interestRate + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Current Annual Percentage Yield (APY) field and corresponding
	 * value should display
	 */

	public boolean verifyCurrentAPYFieldAndValue(String annualPercentage, String value) {
		boolean flag = false;
		try {
			String annualPercentageField = webActions.getText(lblCurrentAPYField);
			annualInterestPercentage = webActions.getText(lblCurrentAPYValue);
			if (annualPercentageField.equals(annualPercentage) && annualInterestPercentage.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyCurrentAPYFieldAndValue <---",
						"Current Annual Percentage Yield field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCurrentIntRateFieldAndValue",
					annualPercentage + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Last Interest Paid field and corresponding values should
	 * display
	 */

	public boolean verifyLastInterestFieldAndValue(String lastInterest, String amount, String date) {
		boolean flag = false;
		try {
			String lastInterestField = webActions.getText(lblLastInterestField);
			lastInterestAmount = webActions.getText(lblLastInterestValue);
			String lastInterestDate = webActions.getText(lblLastInterestValue);
			if (lastInterestField.equals(lastInterest) && lastInterestAmount.contains(amount)
					&& lastInterestDate.contains(date)) {
				flag = true;
				LogUtility.logInfo("---> verifyLastInterestFieldAndValue <---",
						"Last Interest field and Values are displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLastInterestFieldAndValue",
					lastInterest + "field " + amount + "," + date + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Year-to-Date Interest Paid field and corresponding value should
	 * display
	 */

	public boolean verifyYTDInterestFieldAndValue(String yearDateInterest, String value) {
		boolean flag = false;
		try {
			String yearDateInterestField = webActions.getText(lblYTDInterestPaidField);
			yearDateInterestAmount = webActions.getText(lblYTDInterestPaidValue);
			if (yearDateInterestField.equals(yearDateInterest) && yearDateInterestAmount.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyYTDInterestFieldAndValue <---",
						" Year-to-Date Interest Paid field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyYTDInterestFieldAndValue",
					yearDateInterest + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Year-to-Date Interest Paid field and corresponding value should
	 * display
	 */

	public boolean verifyPreviousYTDInterestFieldAndValue(String previousYearDateInterest, String value) {
		boolean flag = false;
		try {
			String prevYearDateInterestField = webActions.getText(lblPrevYTDInterestPaidField);
			prevYearDateInterestValue = webActions.getText(lblPrevYTDInterestPaidValue);
			if (prevYearDateInterestField.equals(previousYearDateInterest)
					&& prevYearDateInterestValue.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyPreviousYTDInterestFieldAndValue <---",
						" Previous Year-to-Date Interest Paid field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPreviousYTDInterestFieldAndValue",
					previousYearDateInterest + "field " + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Account Features text should display
	 */

	public boolean verifyFeaturesSection(String featuresSection) {
		try {
			return wolWebUtil.verifyText(lblFeaturesSection, featuresSection);
		} catch (Exception e) {
			LogUtility.logException("verifyFeaturesSection", featuresSection + " is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To capture the Statement eDelivery Status
	 */

	public String captureStatementeDeliveryStatus() {
		try {
			statementeDeliveryStatus = webActions.getText(lblStmteDeliverySts);
			LogUtility.logInfo("---> captureStatementeDeliveryStatus <---", "Captured Statement e Delivery Status");
		} catch (Exception e) {
			LogUtility.logException("captureStatementeDeliveryStatus", "Unable to capture the Delivery Status", e,
					LoggingLevel.ERROR, true);
		}
		return statementeDeliveryStatus;
	}

	/**
	 * To verify the Statement e Delivery Status field and corresponding status
	 * should display
	 */

	public boolean verifyStmteDeliveryFieldAndValue(String statementeDelivery) {
		boolean flag = false;
		try {
			String statementeDeliveryField = webActions.getText(lbleDeliveryField);
			captureStatementeDeliveryStatus();
			if (statementeDeliveryField.equals(statementeDelivery)) {
				if (statementeDeliveryStatus.equals("Yes")) {
					flag = true;
					LogUtility.logInfo("---> verifyStmteDeliveryFieldAndValue <---",
							"Statement e Delivery field and Value is displayed as Yes");
				} else if (statementeDeliveryStatus.equals("No")) {
					flag = true;
					LogUtility.logInfo("---> verifyStmteDeliveryFieldAndValue <---",
							"Statement e Delivery field and Value is displayed as No");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStmteDeliveryFieldAndValue", statementeDelivery + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To capture the View Deposit Details Status
	 */

	public String captureViewDepositDetailsStatus() {
		try {
			viewDepositDetailsStatus = webActions.getText(lblViewDepositDetailsSts);
			LogUtility.logInfo("---> captureViewDepositDetailsStatus <---", "Captured ViewDepositDetails Status");
		} catch (Exception e) {
			LogUtility.logException("captureViewDepositDetailsStatus", "Unable to capture the Deposit details Status",
					e, LoggingLevel.ERROR, true);
		}
		return viewDepositDetailsStatus;
	}

	/**
	 * To verify the View Deposit Details field and corresponding status should
	 * display
	 */

	public boolean verifyViewDepositDetailsFieldAndValue(String viewDepositDetails) {
		boolean flag = false;
		try {
			String viewDepositDetailsField = webActions.getText(lblDepositDetails);
			captureViewDepositDetailsStatus();
			if (viewDepositDetailsField.equals(viewDepositDetails)) {
				if (viewDepositDetailsStatus.equals("Yes")) {
					flag = true;
					LogUtility.logInfo("---> verifyStmteDeliveryStsFieldAndValue <---",
							"View Deposit Details field and Value is displayed as Yes");
				} else if (viewDepositDetailsStatus.equals("No")) {
					flag = true;
					LogUtility.logInfo("---> verifyStmteDeliveryStsFieldAndValue <---",
							"View Deposit Details field and Value is displayed as No");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStmteDeliveryStsFieldAndValue", viewDepositDetails + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Account Receives Overdraft Protection field and corresponding
	 * status should display
	 */

	public boolean verifyODProtectionFieldAndValue(String overDraftProtection) {
		boolean flag = false;
		try {
			String overDraftProtectionField = webActions.getText(lblOverDraftProtection);
			captureODProtectionStatus();
			if (overDraftProtectionField.equals(overDraftProtection)) {
				if (accountReceivesODProtectionStatus.equals("Yes")) {
					flag = true;
					LogUtility.logInfo("---> verifyODProtectionFieldAndValue <---",
							"Over Draft Protection field and Value is displayed as Yes");
				} else if (accountReceivesODProtectionStatus.equals("No")) {
					flag = true;
					LogUtility.logInfo("---> verifyODProtectionFieldAndValue <---",
							"Over Draft Protection field and Value is displayed as No");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyODProtectionFieldAndValue", overDraftProtection + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To capture the Default Bill Pay Account Status
	 */

	public String captureDefaultBillPayAccStatus() {
		try {
			defaultBillPayAccountStatus = webActions.getText(lblDefaultBillPaySts);
			LogUtility.logInfo("---> captureDefaultBillPayStatus <---", "Captured Default Bill Pay Account Status");
		} catch (Exception e) {
			LogUtility.logException("captureDefaultBillPayStatus", "Unable to capture the Billpay Account status", e,
					LoggingLevel.ERROR, true);
		}
		return defaultBillPayAccountStatus;
	}

	/**
	 * To verify the Default Bill Pay Account field and corresponding value should
	 * display
	 */

	public boolean verifyDefaultBillPayAccFieldAndValue(String defaultBillPayAcc) {
		boolean flag = false;
		try {
			String defaultBillPayAccField = webActions.getText(lblDefaultBillPayField);
			captureDefaultBillPayAccStatus();
			if (defaultBillPayAccField.equals(defaultBillPayAcc)) {
				if (defaultBillPayAccountStatus.equals("Yes")) {
					flag = true;
					LogUtility.logInfo("---> verifyDefaultBillPayAccFieldAndValue <---",
							"Default Bill Pay Account field and Value is displayed as Yes");
				} else if (defaultBillPayAccountStatus.equals("No")) {
					flag = true;
					LogUtility.logInfo("---> verifyDefaultBillPayAccFieldAndValue <---",
							"Default Bill Pay Account field and Value is displayed as No");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDefaultBillPayAccFieldAndValue", defaultBillPayAcc + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To capture the Debit Card Overdraft Services Status
	 */

	public String captureOverDraftServicesStatus() {
		try {
			overDraftServicesStatus = webActions.getText(lblOverDraftEligibleValue);
			LogUtility.logInfo("---> captureOverDraftServicesStatus <---",
					"Captured Debit card Over Draft Services Status");
		} catch (Exception e) {
			LogUtility.logException("verifyDefaultBillPayAccFieldAndValue",
					"Unable to capture the OverDraft service status", e, LoggingLevel.ERROR, true);
		}
		return overDraftServicesStatus;
	}

	/**
	 * To verify the Debitcard Over Draft Services field and corresponding value
	 * should display
	 */

	public boolean verifyODServicesFieldAndValue(String overDraftServices) {
		boolean flag = false;
		try {
			String overDraftServicesField = webActions.getText(lblOverDraftServicesField);
			captureOverDraftServicesStatus();
			if (overDraftServicesField.equals(overDraftServices))
				if (overDraftServicesStatus.equals("Yes")) {
					flag = true;
					LogUtility.logInfo("---> verifyODServicesFieldAndValue <---",
							"OverDraft Services field and Value is displayed as Yes");
				} else if (overDraftServicesStatus.equals("No")) {
					flag = true;
					LogUtility.logInfo("---> verifyODServicesFieldAndValue <---",
							"OverDraft Services field and Value is displayed as No");
				}
		} catch (Exception e) {
			LogUtility.logException("verifyODServicesFieldAndValue", overDraftServices + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Maturity Date field and corresponding value should display
	 */

	public boolean verifyMaturityDateFieldAndValue(String accMaturityDate, String maturityDateValue) {
		boolean flag = false;
		try {
			String maturityDateField = webActions.getText(lblMaturityDateField);
			maturityDate = webActions.getText(lblMaturityDate);
			if (maturityDateField.equals(accMaturityDate) && maturityDate.contains(maturityDateValue)) {
				flag = true;
				LogUtility.logInfo("---> verifyMaturityDateFieldAndValue <---",
						"Maturity Date field and Value is displayed as Yes");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyMaturityDateFieldAndValue",
					accMaturityDate + "field" + maturityDateValue + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To capture the Retirement Account Status
	 */

	public String captureRetirementAccStatus() {
		try {
			retirementAccStatus = webActions.getText(lblRetirementAccValue);
			LogUtility.logInfo("---> captureRetirementAccStatus <---", "Captured Retirement Account Status");
		} catch (Exception e) {
			LogUtility.logException("captureRetirementAccStatus", "Unable to capture the Retirement Acc status", e,
					LoggingLevel.ERROR, true);
		}
		return retirementAccStatus;
	}

	/**
	 * To verify the Retirement Account field and corresponding value should display
	 */

	public boolean verifyReturementAccountAndValue(String retirementAccount) {
		boolean flag = false;
		try {
			String retirementAccField = webActions.getText(lblRetirementAccField);
			captureRetirementAccStatus();
			if (retirementAccField.equals(retirementAccount))
				if (retirementAccStatus.equals("Yes")) {
					flag = true;
					LogUtility.logInfo("---> verifyReturementAccountAndValue <---",
							"Retirement Account field and Value is displayed as Yes");
				} else if (retirementAccStatus.equals("No")) {
					flag = true;
					LogUtility.logInfo("---> verifyReturementAccountAndValue <---",
							"Retirement Account field and Value is displayed as No");
				}
		} catch (Exception e) {
			LogUtility.logException("verifyReturementAccountAndValue", retirementAccount + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Credit Limit field and corresponding value should display
	 */

	public boolean verifyCreditLimitFieldAndValue(String accountCreditLimit, String value) {
		boolean flag = false;
		try {
			String creditLimitField = webActions.getText(lblCreditLimitField);
			creditLimitValue = webActions.getText(lblCreditLimitAmount);
			if (creditLimitField.equals(accountCreditLimit) && creditLimitValue.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyCreditLimitFieldAndValue <---",
						"Credit Limit field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCreditLimitFieldAndValue",
					accountCreditLimit + "field" + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Payment Information text should display
	 */

	public boolean verifyPaymentInformationSection(String paymentInfoSection) {
		try {
			return wolWebUtil.verifyText(lblPaymentSection, paymentInfoSection);
		} catch (Exception e) {
			LogUtility.logException("verifyPaymentInformationSection", paymentInfoSection + " is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Next Payment Due field and corresponding values should display
	 */

	public boolean verifyNextPaymenttDueFieldAndValue(String nextPaymentDue, String amount, String date) {
		boolean flag = false;
		try {
			String nextPaymentDueField = webActions.getText(lblNextPaymentField);
			nextPaymentDueAmount = webActions.getText(lblNextPaymentDueAmount);
			String nextPaymentDate = webActions.getText(lblNextPaymentDueAmount);
			if (nextPaymentDueField.equals(nextPaymentDue) && nextPaymentDueAmount.contains(amount)
					&& nextPaymentDate.contains(date)) {
				flag = true;
				LogUtility.logInfo("---> verifyNextPaymenttDueFieldAndValue <---",
						"Next Payment Due  field and Values are displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNextPaymenttDueFieldAndValue",
					nextPaymentDue + "field" + amount + " ," + date + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Last Payment date field and corresponding value should display
	 */

	public boolean verifyLastPaymentDateFieldAndValue(String lastPmtDate, String value) {
		boolean flag = false;
		try {
			String lastPaymenttDateField = webActions.getText(lblLastPymtDateField);
			lastPaymentDate = webActions.getText(lblLastPymtDate);
			if (lastPaymenttDateField.equals(lastPmtDate) && lastPaymentDate.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyLastPaymentDateFieldAndValue <---",
						"Last Payment Date field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLastPaymentDateFieldAndValue",
					lastPmtDate + "field" + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Late Charges field and corresponding value should display
	 */

	public boolean verifyLateChargesFieldAndValue(String lateCharges, String value) {
		boolean flag = false;
		try {
			String lateChargesField = webActions.getText(lblLateChargesField);
			lateChargesAmount = webActions.getText(lblLateChargesAmount);
			if (lateChargesField.equals(lateCharges) && lateChargesAmount.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyLateChargesFieldAndValue <---",
						"Late Charges field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLateChargesFieldAndValue",
					lateCharges + "field" + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Fees field and corresponding value should display
	 */

	public boolean verifyFeesFieldAndValue(String fees, String value) {
		boolean flag = false;
		try {
			String feesField = webActions.getText(lblFeesField);
			feesAmount = webActions.getText(lblFeesAmount);
			if (feesField.equals(fees) && feesAmount.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyFeesFieldAndValue <---", "Fees field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFeesFieldAndValue", fees + "field" + value + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Available balance field and corresponding value should display
	 * for Credit Line Account
	 */

	public boolean verifyAvailableBalFieldAndValue(String availableBalance, String value) {
		boolean flag = false;
		try {
			String availableBalanceField = webActions.getText(lblAvailableBalanceField);
			availableBalanceAmount = webActions.getText(lblAvailableBalanceAmount);
			if (availableBalanceField.equals(availableBalance) && availableBalanceAmount.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyAvailableBalFieldAndValue <---",
						"Available Balance field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAvailableBalFieldAndValue",
					availableBalance + "field" + value + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Escrow Balance field and corresponding value should display
	 */

	public boolean verifyEscrowBalanceFieldAndValue(String escrowBalance, String value1, String value2) {
		boolean flag = false;
		try {
			String escrowBalanceField = webActions.getText(lblEscrowBalanceField);
			escrowBalanceAmount = webActions.getText(lblEscrowBalanceAmount);
			if (escrowBalanceField.equals(escrowBalance)) {
				if (escrowBalanceAmount.equals(value1)) {
					flag = true;
					LogUtility.logInfo("---> verifyEscrowBalanceFieldAndValue <---",
							"Escrow Balance field and Value is displayed as N/A");
				} else if (escrowBalanceAmount.contains(value2)) {
					flag = true;
					LogUtility.logInfo("---> verifyEscrowBalanceFieldAndValue <---",
							"Escrow Balance field and Value is displayed as $");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyEscrowBalanceFieldAndValue",
					escrowBalance + "field" + value1 + " , " + value2 + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Year-to-Date Taxes Paid field and corresponding value should
	 * display
	 */

	public boolean verifyYTDTaxeseFieldAndValue(String ytdTaxesPaid, String value1, String value2) {
		boolean flag = false;
		try {
			String ytdTaxesPaidField = webActions.getText(lblYTDTaxesPaidField);
			ytdTaxesPaidDate = webActions.getText(lblPrevYTDTaxesPaidDate);
			if (ytdTaxesPaidField.equals(ytdTaxesPaid)) {
				if (ytdTaxesPaidDate.equals(value1)) {
					flag = true;
					LogUtility.logInfo("---> verifyYTDTaxeseFieldAndValue <---",
							"Year to Date Taxes Paid field and Value is displayed as N/A");
				} else if (ytdTaxesPaidDate.contains(value2)) {
					flag = true;
					LogUtility.logInfo("---> verifyYTDTaxeseFieldAndValue <---",
							"Year to Date Taxes Paid field and Value is displayed as date format");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyYTDTaxeseFieldAndValue",
					ytdTaxesPaid + "field" + value1 + " , " + value2 + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Year-to-Date Taxes Paid field and corresponding value should
	 * display
	 */

	public boolean verifyPrevYTDTaxeseFieldAndValue(String preYTDTaxesPaid, String value1, String value2) {
		boolean flag = false;
		try {
			String prevYTDTaxesPaidField = webActions.getText(lblPrevYTDTaxesPaidField);
			prevYTDTaxesPaidDate = webActions.getText(lblPrevYTDTaxesPaidDate);
			if (prevYTDTaxesPaidField.equals(preYTDTaxesPaid)) {
				if (prevYTDTaxesPaidDate.equals(value1)) {
					flag = true;
					LogUtility.logInfo("---> verifyPrevYTDTaxeseFieldAndValue <---",
							"Previous Year to Date Taxes Paid field and Value is displayed as N/A");
				} else if (prevYTDTaxesPaidDate.contains(value2)) {
					flag = true;
					LogUtility.logInfo("---> verifyPrevYTDTaxeseFieldAndValue <---",
							"Previous Year to Date Taxes Paid field and Value is displayed as date format");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPrevYTDTaxeseFieldAndValue",
					preYTDTaxesPaid + "field" + value1 + " , " + value2 + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Held At field and corresponding value should display for
	 * Investment Account
	 */

	public boolean verifyHeldAtFieldAndValue(String heldAt, String value) {
		boolean flag = false;
		try {
			String heldAtField = webActions.getText(lblHeldAtField);
			heldAtValue = webActions.getText(lblHeldAtValue);
			if (heldAtField.equals(heldAt) && heldAtValue.contains(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyHeldAtFieldAndValue <---", "Held At field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyHeldAtFieldAndValue", heldAt + "field" + value + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on the View Transaction History link
	 */

	public boolean clickOnViewTransHistoryLink() {
		boolean flag = false;
		try {
			boolean viewTransHistoryLink = webActions.isDisplayed(lnkViewTransHistory);
			if (viewTransHistoryLink) {
				webActions.clickElement(lnkViewTransHistory);
				LogUtility.logInfo("---> clickOnViewTransHistoryLink <---", "Clicked On View Transaction History Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewTransHistoryLink", "Unable to click on View Transaction Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on the View Account Balances link
	 */

	public boolean clickOnViewAccBalancesLink() {
		boolean flag = false;
		try {
			boolean viewAccBalancesLink = webActions.isDisplayed(lnkViewAccBalances);
			if (viewAccBalancesLink) {
				webActions.clickElement(lnkViewAccBalances);
				LogUtility.logInfo("---> clickOnViewAccBalancesLink <---",
						"Clicked On View Account Balances History Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewTransHistoryLink", "Unable to click on View Acc Balances Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Deposit details Text should display
	 */
	public boolean verifyDepositText() {
		boolean flag = false;
		try {
			boolean depositText = webActions.isDisplayed(lblDepositDetails);
			if (depositText) {
				LogUtility.logInfo("---> verifyDepositText <---", "View Deposit Details Text displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDepositText", "Deposit text is not displayed", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

}
