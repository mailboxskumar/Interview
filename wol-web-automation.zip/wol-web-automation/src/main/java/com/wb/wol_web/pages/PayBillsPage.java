
package com.wb.wol_web.pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class PayBillsPage extends ObjectBase {

	public PayBillsPage() {
		PageFactory.initElements(driver, this);
	}

	public String confirmationNumber = "";
	public WebElement paymentMemo = null;
	List<LinkedHashMap<String, String>> enteredDetails = new ArrayList<LinkedHashMap<String, String>>();
	public String payeeName = "//*[contains(text(),'ReplaceMe')]";
	public String fromAcc = "";

	@FindBy(id = "payees_table__filter__input")
	protected WebElement selShowOnly;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']/span"))
	protected List<WebElement> lstPayees;

	@FindBy(id = "timing_warning__body")
	protected WebElement txtTimingWarning;

	@FindBy(id = "checkPayee_warning__body")
	protected WebElement txtPayeeWarning;

	@FindBy(id = "payees_table__sort__input")
	protected WebElement selSortBy;

	@FindBy(xpath = "//li[contains(@id,'payees_table_row') and @aria-expanded='true' and  @data-mm-hidden='false']")
	protected List<WebElement> lstPayeesAfterExpandAll;

	@FindBy(xpath = "//li[contains(@id,'payees_table_row') and @data-mm-hidden='false']")
	protected List<WebElement> lstPayeesBeforeExpandAll;

	@FindBy(id = "payeesExpandButton")
	protected WebElement btnExpandAll;

	@FindBy(name = "duplicatePaymentChooser")
	protected WebElement btnDuplicateBills;

	@FindBy(xpath = "//*[contains(text(),'Continue')]")
	private WebElement btnContinue;

	@FindBy(xpath = "(//li[@data-mm-hidden='false']//select[contains(@name,'paymentFrequency')])[1]")
	protected WebElement selPayFreq;

	@FindBy(xpath = "(//input[contains(@name,'numberOfPayments')])[1]")
	protected WebElement inputNumOfPayments;

	@FindBy(id = "mainSiteNav__submenu3__menuLabel")
	protected WebElement paymentMenu;

	@FindBy(id = "mainSiteNav__submenu3__megaMenu__section1__entry1__subentry3__navigationLink")
	protected WebElement recurringBillSubMenu;

	@FindBy(css = "div.pageHeaderBlock > div")
	protected WebElement txtRecurrWarning;

	@FindBy(css = "div.pageHeaderBlock > h1")
	protected WebElement txtRecurringPageTitle;

	@FindBy(id = "shortList_yes")
	protected WebElement rdBtnShortListYes;

	@FindBy(id = "payees_table__filterByText__input")
	protected WebElement txtBoxPayeeFilter;

	@FindBy(xpath = "(//li[@data-mm-hidden='false']//a)[1]")
	protected WebElement lnkPayeeDetails;

	@FindBy(id = "shortList_no")
	protected WebElement rdBtnShortListNo;

	@FindBy(css = "td > input[type=checkbox]")
	protected WebElement chkAcceptAlert;

	@FindBy(id = "alertConfirm")
	protected WebElement btnAcceptAlert;

	@FindBy(css = ".pageHeaderBlock>h1")
	protected WebElement txtMakeDeposit;

	@FindBy(id = "billpay-payment-verification__pageTitle")
	protected WebElement lblVerification;

	@FindBy(css = "billpay-payment-confirmation__pageTitle")
	protected WebElement lblConfirmation;

	@FindBy(css = "div.pageHeaderBlock > h3")
	protected WebElement lblAlertConfirmation;

	@FindBy(id = "payees_table__emptyListMessage")
	protected WebElement lblNoPayeeMsg;

	@FindBy(id = "billpay-payment-confirmation__pageAffirmativeNotice__body")
	protected WebElement lblConfirmationMsg;

	@FindBy(css = "h3#page_title")
	protected WebElement lblUpdatePayee;

	@FindBy(xpath = "(//p[contains(@id,'paymentDate') and @class=' error-message-text'])[1]")
	protected WebElement lblInvalidDateMsg;

	@FindBy(xpath = "(//p[contains(@id,'paymentAmount') and @class=' error-message-text'])[1]")
	protected WebElement lblInvalidAmountMsg;

	@FindBy(xpath = "//*[@data-wbst-message-key='ts-auth-error.msg']")
	protected WebElement lblUnauthorizedUser;

	@FindBy(xpath = "//*[@data-wbst-message-key='payee.updateBrochureMessage']")
	protected WebElement lblUpdatePayeeMsg;

	@FindBy(xpath = "//*[@id='error-no-billpay-account__pageErrors__error-no-billpay-account__pageError__body']")
	protected WebElement lblNoBillPayAccountMsg;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']//select[contains(@id,'paymentFrequency')])[1]")
	protected WebElement selPersonalPaymentFreq;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']/span"))
	protected List<WebElement> lstPersonalPayees;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']/span"))
	protected List<WebElement> lstBusinessPayees;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']//select[contains(@id,'paymentFrequency')])[1]")
	protected WebElement selBusinessPaymentFreq;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='PERSONAL']//select[contains(@id,'numberOfPayments')])[1]")
	protected WebElement inputPersonalNumPay;

	@FindBy(xpath = "(//li[@data-mm-hidden='false' and @data-bdm-access-channel='BUSINESS']//input[contains(@id,'numberOfPayments')])[1]")
	protected WebElement inputBusinessNumPay;

	@FindBy(id = "payFromAccount__input")
	protected WebElement selPayFrom;

	@FindAll(@FindBy(css = "#payFromAccount option"))
	protected List<WebElement> selPayFromOptions;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']//span[contains(text(),'Check')]"))
	protected List<WebElement> lstCheckPayees;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']//span[contains(text(),'Electronic')]"))
	protected List<WebElement> lstElectronicPayees;

	@FindAll(@FindBy(xpath = "//li[@aria-expanded='true' and @data-mm-hidden='false']/span"))
	protected List<WebElement> lstPayeesDataExpanded;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']/span[1]"))
	protected List<WebElement> lstAllPayees;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']//input[contains(@id,'numberOfPayments')]"))
	protected List<WebElement> lstAllPayeesNumOfPayments;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']//select[contains(@id,'paymentFrequency')]"))
	protected List<WebElement> lstAllPayeesPayFreq;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']//input[contains(@id,'paymentDate')]"))
	protected List<WebElement> lstAllPayeesDate;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']//input[contains(@id,'paymentAmount')]"))
	protected List<WebElement> lstAllPayeesAmount;

	@FindAll(@FindBy(css = "li[data-mm-hidden='false']  div[id*='__foot-note']"))
	protected List<WebElement> lstAllDebitDate;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']//input[contains(@id,'paymentMemo')]"))
	protected List<WebElement> lstAllPayeesMemo;

	@FindAll(@FindBy(xpath = "//li[@data-mm-hidden='false']/span[@aria-label='Payee Type']"))
	protected List<WebElement> lstAllPayeesPayeeType;

	@FindAll(@FindBy(xpath = "//li[contains(@id,'payments_table_row')]/span"))
	protected List<WebElement> lstPayeeDetInVerificatn;

	@FindAll(@FindBy(xpath = "//li[@id='payments_table_row0']/span"))
	protected List<WebElement> lsyPayeeDetColumns;

	@FindBy(id = "payment-center__pageInstructions--with-tooltip-0")
	protected WebElement toolTipPC;

	@FindAll(@FindBy(css = "div.relatedLinks li a"))
	protected List<WebElement> lstNextSteps;

	@FindAll(@FindBy(css = "a[id*='nextStep']"))
	protected List<WebElement> lstNextStepsConfirm;

	@FindBy(id = "billpay-payment__pageErrors__billPayPayment__error__general__body")
	protected WebElement txtCommonErrorMsg;

	@FindBy(id = "payments_table--with-tooltip-1")
	protected WebElement delDateToolTip;

	@FindBy(css = "div[data-has-error='true'] p")
	protected WebElement txtErrorMsg;

	/**
	 * To check the list options
	 * 
	 * @param selectBox
	 * @return
	 */
	public String checkTheListOptions(String selectBox) {
		String status = "";
		String[] list;
		WebElement eleToCheck = null;
		try {
			if (selectBox.equals("Show Only")) {
				eleToCheck = selShowOnly;
				list = jsonDataParser.getTestDataMap().get("ShowOnlyOptions").split(",");
			} else if (selectBox.equals("Sort By")) {
				eleToCheck = selSortBy;
				list = jsonDataParser.getTestDataMap().get("SortByOptions").split(",");
			} else {
				eleToCheck = selPayFreq;
				list = jsonDataParser.getTestDataMap().get("FrequencyofPaymentsOptions").split(",");
			}
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(eleToCheck);
			for (String eachOption : list) {
				if (!wolWebUtil.verifyListValues(eleToCheck, eachOption)) {
					status = status + eachOption + ",";
				}
			}
			if (!status.equals(""))
				LogUtility.logError("checkTheListOptions",
						"Some of the options " + status + " are missing in the dropdown " + selectBox);
			else
				LogUtility.logInfo("checkTheListOptions", "All the options are present in the dropdown " + selectBox);
		} catch (Exception e) {
			LogUtility.logException("checkTheListOptions",
					"Some of the options " + status + " are missing in the dropdown " + selectBox, e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check if all the payees are expanded on clicking ExpandAll button
	 * 
	 * @return
	 */
	public boolean checkExpandAllPayees() {
		boolean status = false;
		try {
			waits.waitForDOMready();
			if (lstPayeesAfterExpandAll.size() == lstPayeesBeforeExpandAll.size()) {
				status = true;
				LogUtility.logInfo("checkExpandAllPayees", "All the payees are expanded");
			} else
				LogUtility.logError("checkExpandAllPayees", "All the payees are not expanded");
		} catch (Exception e) {
			LogUtility.logException("checkExpandAllPayees", "Failed while checking the expand button", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks warning texts
	 * 
	 * @param warningType
	 * @return
	 */
	public boolean checkTheTextForWarnings(String warningType) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			if (warningType.equals("TimingWarning")) {
				eleToGetText = txtTimingWarning;
			} else
				eleToGetText = txtPayeeWarning;
			if (wolWebUtil.verifyText(eleToGetText, jsonDataParser.getTestDataMap().get(warningType))) {
				status = true;
				LogUtility.logInfo("checkTheTextForWarnings",
						"Found the text :" + jsonDataParser.getTestDataMap().get(warningType));
			} else
				LogUtility.logError("checkTheTextForWarnings",
						"Could not find the text :" + jsonDataParser.getTestDataMap().get(warningType));
		} catch (Exception e) {
			LogUtility.logException("checkExpandAllPayees", "Failed while checking the warning text", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check the payment details(payee name,date,amount) without expanding
	 * 
	 * @return
	 */
	public String checkThePayeeListWithoutExpand() {
		String status = "";
		try {
			for (int i = 0; i < 3; i++) {
				if (!webActions.isDisplayed(lstPayees.get(i))) {
					status = status + webActions.getAttributeValue(lstPayees.get(i), "aria-label");
				}
			}
			if (status.equals(""))
				LogUtility.logInfo("checkThePayeeListWithoutExpand",
						"All the three labels are displayed : name,Date Amount");
			else
				LogUtility.logError("checkThePayeeListWithoutExpand", "Some of the labels are not displayed " + status);
		} catch (Exception e) {
			LogUtility.logException("checkThePayeeListWithoutExpand",
					"Failed while checking the payee list without expanding them", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Check the format of the payee name
	 * 
	 * @param name
	 * @param nickNameExists
	 * @return
	 */
	public boolean checkThePayeeNameFormat(String name, boolean nickNameExists) {
		boolean status = false;
		try {
			String payeeNamefromUI = driver.findElement(By.xpath(payeeName.replaceAll("ReplaceMe", name))).getText();
			if (nickNameExists) {
				if (payeeNamefromUI.split(",").length == 3) {
					status = true;
					LogUtility.logInfo("checkThePayeeNameFormat",
							"Name format is correct for a payee with nickname " + payeeNamefromUI);
				} else {
					LogUtility.logError("checkThePayeeNameFormat",
							"Name format is not correct for a payee with nickname " + payeeNamefromUI);
				}
			} else if (payeeNamefromUI.split(",").length == 2) {
				status = true;
				LogUtility.logInfo("checkThePayeeNameFormat",
						"Name format is correct for a payee without nickname " + payeeNamefromUI);
			} else {
				LogUtility.logError("checkThePayeeNameFormat",
						"Name format is not correct for a payee without nickname " + payeeNamefromUI);
			}
		} catch (Exception e) {
			LogUtility.logException("checkThePayeeNameFormat", "Failed while checking the payee naming format", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks the default value for number of payments and frequency of payments
	 * 
	 * @param dropDown
	 * @param defaultValue
	 * @return
	 */
	public boolean checkTheDefaultValueInDropDown(String dropDown, String defaultValue) {
		boolean status = false;
		try {
			if (dropDown.equals("Frequency of Payments")) {
				if (wolWebUtil.getDefaultValueForSelect(selPayFreq).equals(defaultValue)) {
					status = true;
					LogUtility.logInfo("checkTheDefaultValueInDropdown", "Default value for frequency of Payments is  "
							+ wolWebUtil.getDefaultValueForSelect(selPayFreq));
				} else
					LogUtility.logError("checkTheDefaultValueInDropdown",
							"Default value for frequency of Payments is  not "
									+ wolWebUtil.getDefaultValueForSelect(selPayFreq));
			} else {
				if (webActions.getAttributeValue(inputNumOfPayments, "value").equals(defaultValue)) {
					status = true;
					LogUtility.logInfo("checkTheDefaultValueInDropdown", "Default value for frequency of payments is  "
							+ webActions.getAttributeValue(inputNumOfPayments, "value"));
				} else
					LogUtility.logError("checkTheDefaultValueInDropdown",
							"Default value for frequency of paymnets is  not "
									+ webActions.getAttributeValue(inputNumOfPayments, "value"));
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheDefaultValueInDropdown",
					"Failed while checking the default value in dropdown", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Clickon payment menu
	 * 
	 * @return
	 */
	public boolean clickOnPaymentsMenu() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(paymentMenu)) {
				webActions.clickElement(paymentMenu);
				status = true;
				LogUtility.logInfo("clickOnPaymentsMenu", "Clicked on the payments menu");
			} else
				LogUtility.logError("clickOnPaymentsMenu", "Could not click on the payments menu");
		} catch (Exception e) {
			LogUtility.logException("clickOnPaymentsMenu", "Failed while clicking on payment menu", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check the tool tip text
	 * 
	 * @return
	 */
	public boolean checkInfoTitleForRecurringPayments() {
		boolean status = false;
		String infoTitle = "";
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(recurringBillSubMenu)) {
				wolWebUtil.hoverOnTheElement(recurringBillSubMenu);
				infoTitle = webActions.getAttributeValue(recurringBillSubMenu, "title");
				if (infoTitle.contains(jsonDataParser.getTestDataMap().get("InfoTitle"))) {
					status = true;
					LogUtility.logInfo("checkInfoTitleForRecurringPayments", "Found the info title ");
				} else
					LogUtility.logError("checkInfoTitleForRecurringPayments", "Could not find the info title ");
			}
		} catch (Exception e) {
			LogUtility.logException("checkInfoTitleForRecurringPayments", "Failed while checking the title", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * verify the warning message in recurring payments page
	 * 
	 * @return
	 */
	public boolean checkForRecurringPaymentsWarnignMsg() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtRecurrWarning);
			if (wolWebUtil.verifyText(txtRecurrWarning, jsonDataParser.getTestDataMap().get("WarningMessage"))) {
				status = true;
				LogUtility.logInfo("checkForRecurringPaymentsWarnignMsg",
						"Found the warning message " + jsonDataParser.getTestDataMap().get("WarningMessage"));
			} else
				LogUtility.logError("checkForRecurringPaymentsWarnignMsg",
						"Could not find the warning message " + jsonDataParser.getTestDataMap().get("WarningMessage"));
		} catch (Exception e) {
			LogUtility.logException("checkForRecurringPaymentsWarnignMsg", "Failed while checking the warning message",
					e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * verify the warning title in recurring payments page
	 * 
	 * @return
	 */
	public boolean checkForRecurringPaymentsTitle() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtRecurringPageTitle);
			if (wolWebUtil.verifyText(txtRecurringPageTitle,
					jsonDataParser.getTestDataMap().get("Recurring PageTitle"))) {
				status = true;
				LogUtility.logInfo("checkForRecurringPaymentsWarnignMsg",
						"Found the Title " + jsonDataParser.getTestDataMap().get("Recurring PageTitle"));
			} else
				LogUtility.logError("checkForRecurringPaymentsWarnignMsg",
						"Could not find the Title " + jsonDataParser.getTestDataMap().get("Recurring PageTitle"));
		} catch (Exception e) {
			LogUtility.logException("checkForRecurringPaymentsTitle", "Failed while checking the title", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public List<Map<String, String>> getSortedJSONData(List<Map<String, String>> jsonDetails, String fileName) {
		List<Map<String, String>> transferDetails = new ArrayList<Map<String, String>>();
		try {
			for (int i = 0; i < jsonDetails.size(); i++) {
				for (String eachColName : jsonDetails.get(i).get("PaymentDetails").split(",")) {
					Map<String, String> map = new HashMap<String, String>();
					TreeMap<String, String> sorted = new TreeMap<>();
					sorted.putAll(jsonDataParser.parseJsonTestData(fileName, eachColName));
					for (String entry : sorted.keySet()) {
						map.put(entry, sorted.get(entry));
					}
					transferDetails.add(map);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("getSortedJSONData", "Failed to sort data from JSON", e, LoggingLevel.ERROR, true);
		}
		return transferDetails;
	}

	/**
	 * enters payment details
	 * 
	 * @param details
	 * @param payeeType
	 * @throws Exception
	 */
	public void enterPaymentDetails(List<Map<String, String>> details, String payeeType) throws Exception {
		try {
			List<Map<String, String>> electronicPayments = new ArrayList<>();
			List<Map<String, String>> checkPayments = new ArrayList<>();
			for (int i = 0; i < details.size(); i++) {
				if (details.get(i).get("Payee Type").equals("Check"))
					checkPayments.add(details.get(i));
				else
					electronicPayments.add(details.get(i));
			}
			if (electronicPayments.size() > 0)
				enterData(electronicPayments, "Electronic");
			if (checkPayments.size() > 0)
				enterData(checkPayments, "Check");
			LogUtility.logInfo("---> enterPaymentDetails <---", "Entered the payment details " + details);
		} catch (Exception e) {
			LogUtility.logException("enterPaymentDetails", "Failed while sorting the type of payments", e,
					LoggingLevel.ERROR, true);
			throw new Exception(" Exception while entering details " + e.getMessage());
		}
	}

	public void enterData(List<Map<String, String>> details, String payeeType) throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			selectFromShowOnlyDropDown(payeeType);
			for (int i = 0; i < details.size(); i++) {
				waits.waitForPageToLoad(maxTimeOut);
				if (!lstAllPayeesMemo.get(i).isDisplayed()) {
					wolWebUtil.scrollToElement(lstAllPayees.get(i));
					webActions.clickElement(lstAllPayees.get(i));
				}
				waits.waitForDOMready();
				LinkedHashMap<String, String> eachPaymentDetail = new LinkedHashMap<String, String>();
				for (String eachCol : details.get(i).keySet()) {
					waits.waitForPageToLoad(maxTimeOut);
					waits.waitForDOMready();
					eachPaymentDetail.putIfAbsent(jsonDataParser.getTestDataMap().get("Column1"),
							lstAllPayees.get(i).getText());
					switch (eachCol) {
					case "Delivery Date":
						if (!details.get(i).get(eachCol).equals("Default")) {
							webActions.setValue(lstAllPayeesDate.get(i), wolWebUtil.getDateInTheFormat("MM/dd/yyyy",
									Integer.parseInt(details.get(i).get(eachCol))));
							waits.waitForDOMready();
						}
						eachPaymentDetail.put(jsonDataParser.getTestDataMap().get("Column3"),
								wolWebUtil.changeTheDatePattern("MM/dd/yyyy", "MMM dd, yyyy",
										lstAllPayeesDate.get(i).getAttribute("value")));
						break;
					case "Payment Amount":
						webActions.setValue(lstAllPayeesAmount.get(i), details.get(i).get(eachCol));
						eachPaymentDetail.put(jsonDataParser.getTestDataMap().get("Column4"),
								details.get(i).get(eachCol));
						break;
					case "Payment Memo":
						webActions.setValue(lstAllPayeesMemo.get(i), details.get(i).get(eachCol));
						break;
					case "Frequency of Payments":
						webActions.selectDropDownByText(lstAllPayeesPayFreq.get(i), details.get(i).get(eachCol));
						break;
					case "Number of Payments":
						if (!details.get(i).get(eachCol).equals("1"))
							if (!details.get(i).get("Frequency of Payments").equals("One time")) {
								webActions.selectDropDownByText(lstAllPayeesPayFreq.get(i),
										details.get(i).get("Frequency of Payments"));
								webActions.setValue(lstAllPayeesNumOfPayments.get(i), details.get(i).get(eachCol));
							} else
								webActions.setValue(lstAllPayeesNumOfPayments.get(i), details.get(i).get(eachCol));

						break;
					case "Payee Type":
						if (details.get(i).get(eachCol).equals("Check")) {
							if (lstAllDebitDate.get(i).getText().equals("Will debit when cashed"))
								eachPaymentDetail.put(jsonDataParser.getTestDataMap().get("Column2"),
										lstAllDebitDate.get(i).getText());
						} else {
							if (lstAllDebitDate.get(i).getText().contains("Will debit on"))
								eachPaymentDetail.put(jsonDataParser.getTestDataMap().get("Column2"),
										wolWebUtil.changeTheDatePattern("MM/dd/yyyy", "MMM dd, yyyy",
												lstAllDebitDate.get(i).getText().replaceAll("Will debit on", "")));
						}
						break;
					}
				}
				enteredDetails.add(eachPaymentDetail);
				LogUtility.logInfo("enterData", "Entered the payment details as " + eachPaymentDetail);

			}
		} catch (Exception e) {
			LogUtility.logException("enterData", "Failed while entering the data", e, LoggingLevel.ERROR, true);
			throw new Exception("Exception while entering details " + e.getMessage());
		}

	}

	/**
	 * TODO: Check robot class replacement as it doesnt work in parallel mode
	 * 
	 * @param details
	 * @param payeeType
	 * @throws Exception
	 */
	public void enterInvalidPaymentDetails(List<Map<String, String>> details, String payeeType) throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			for (int i = 0; i < details.size(); i++) {
				wolWebUtil.scrollToElement(lstAllPayees.get(i));
				if (!lstAllPayeesMemo.get(i).isDisplayed())
					webActions.clickElement(lstAllPayees.get(i));
				waits.waitForDOMready();
				for (String eachCol : details.get(i).keySet()) {
					switch (eachCol) {
					case "Delivery Date":
						enterDeliveryDate(lstAllPayeesDate.get(i), details.get(i).get(eachCol));
						break;
					case "Payment Amount":
						if (details.get(i).get(eachCol).equals("0"))
							webActions.clearValue(lstAllPayeesAmount.get(i));
						else if (!details.get(i).get(eachCol).equals(""))
							webActions.setValue(lstAllPayeesAmount.get(i), details.get(i).get(eachCol));

						break;
					case "Payment Memo":
						if (!details.get(i).get(eachCol).equals(""))
							paymentMemo = lstAllPayeesMemo.get(i);
						webActions.setValue(lstAllPayeesMemo.get(i), details.get(i).get(eachCol));
						break;
					case "Frequency of Payments":
						if (!details.get(i).get(eachCol).equals(""))
							webActions.selectDropDownByText(lstAllPayeesPayFreq.get(i), details.get(i).get(eachCol));
						break;
					case "Number of Payments":
						if (!details.get(i).get(eachCol).equals("1") && !details.get(i).get(eachCol).equals("")) {
							webActions.clearValue(lstAllPayeesNumOfPayments.get(i));
							if (browserName.equals("internet explorer")) {
								if (details.get(i).get(eachCol).contains("-")) {
									webActions.clearValue(lstAllPayeesNumOfPayments.get(i));
									Robot robot = new Robot();
									robot.keyPress(KeyEvent.VK_MINUS);
									robot.keyPress(KeyEvent.VK_1);
									robot.keyPress(KeyEvent.VK_2);
								} else {
									webActions.clearValue(lstAllPayeesNumOfPayments.get(i));
									lstAllPayeesNumOfPayments.get(i).sendKeys(details.get(i).get(eachCol));
								}
							} else {
								webActions.clearValue(lstAllPayeesNumOfPayments.get(i));
								lstAllPayeesNumOfPayments.get(i).sendKeys(details.get(i).get(eachCol));
							}
						}
						break;

					}
				}
			}
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			LogUtility.logInfo("---> enterInvalidPaymentDetails <---", "Entered the payment details " + details);
		} catch (Exception e) {
			LogUtility.logException("enterInvalidPaymentDetails", "Failed while entering invalid payment details", e,
					LoggingLevel.ERROR, true);
			throw new Exception(" Exception while entering details " + e.getMessage());
		}
	}

	/**
	 * Enters the delivery date in payment details
	 * 
	 * @param element
	 * @param dateType
	 */
	public void enterDeliveryDate(WebElement element, String dateType) {
		try {
			if (dateType.equals("InvalidDateFormat")) {
				webActions.setValue(element, wolWebUtil.getDateInTheFormat("MMM-dd-yyyy", Integer.parseInt("5")));
				waits.waitForDOMready();
			} else if (dateType.equals("ClearDate")) {
				webActions.clearValue(element);
				waits.waitForDOMready();
			} else if (!dateType.equals("Default") && !dateType.equals("")) {

				webActions.setValue(element, wolWebUtil.getDateInTheFormat("MM/dd/yyyy", Integer.parseInt(dateType)));
				waits.waitForDOMready();
			}
		} catch (Exception e) {
			LogUtility.logException("enterDeliveryDate", "Failed while entering delivery date", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * clicks on expand all button
	 * 
	 * @return
	 */
	public boolean clickOnExpandAll() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnExpandAll)) {
				webActions.clickElement(btnExpandAll);
				status = true;
				LogUtility.logInfo("---> clickOnExpandAll <---", "Clicked on expnad all button ");
			} else {
				LogUtility.logError("---> clickOnExpandAll  <---", "Failed to click on expnad all button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnExpandAll", "Failed while clicking on expand all button", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForDuplicateBills() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnDuplicateBills)) {
				wolWebUtil.scrollToElement(btnDuplicateBills);
				webActions.clickElement(btnDuplicateBills);
				status = true;
				LogUtility.logInfo("---> checkForDuplicateBills <---", "Clicked on duplicate bill pay button ");
			} else {
				LogUtility.logError("---> checkForDuplicateBills  <---",
						"Failed to click on duplicate bill pay button");
			}
		} catch (Exception e) {
			LogUtility.logException("checkForDuplicateBills", "Failed to click on duplicate bill pay button ", e,
					LoggingLevel.ERROR, true);

		}
		return status;
	}

	/**
	 * To click on continue button
	 * 
	 * @return
	 */
	public boolean clickOnContinue() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(btnContinue)) {
				wolWebUtil.clickWebElement(btnContinue, "clickOnContinue");
				status = true;
				LogUtility.logInfo("---> clickOnContinue <---", "Clicked on continue button ");
			} else {
				LogUtility.logError("---> clickOnContinue  <---", "Failed to click on continue button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnContinue", "Failed to click on continue button ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To validate the data displayed in verification page with the data entered
	 * 
	 * @return
	 */
	public boolean validateDataInVerificationPage() {
		boolean status = true;
		List<LinkedHashMap<String, String>> dataFromUI = new ArrayList<LinkedHashMap<String, String>>();
		try {
			for (int i = 0; i < lstPayeeDetInVerificatn.size(); i += lsyPayeeDetColumns.size()) {
				dataFromUI.add(changeFromListToLinkedHashMap(lstPayeeDetInVerificatn.subList(i,
						Math.min(i + lsyPayeeDetColumns.size(), lstPayeeDetInVerificatn.size()))));
			}
			for (int i = 0; i < dataFromUI.size(); i++) {
				if (!wolWebUtil.mapValuesComaparison(dataFromUI.get(i), enteredDetails.get(i))) {
					status = false;
				}
			}

			if (status)
				LogUtility.logInfo("---> validateDataInVerificationPage  <---",
						" data is same as data entered " + dataFromUI);
			else
				LogUtility.logError("---> validateDataInVerificationPage  <---",
						" data is not same as expected  " + dataFromUI);
		} catch (Exception e) {
			LogUtility.logException("validateDataInVerificationPage", "Failed to verify data in verification page  ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To validate the data displayed in confirmation page with the data entered
	 * 
	 * @return
	 */
	public boolean validateDataInConfirmationPage() {
		boolean status = true;
		List<LinkedHashMap<String, String>> confrimationDet = new ArrayList<LinkedHashMap<String, String>>();
		try {
			for (int i = 0; i < lstPayeeDetInVerificatn.size(); i += lsyPayeeDetColumns.size()) {
				confrimationDet.add(changeFromListToLinkedHashMap(lstPayeeDetInVerificatn.subList(i,
						Math.min(i + lsyPayeeDetColumns.size(), lstPayeeDetInVerificatn.size()))));
			}
			for (int i = 0; i < confrimationDet.size(); i++) {
				confirmationNumber += confirmationNumber + confrimationDet.get(i).get("Confirmation Number").trim()
						+ ",";
				if (!wolWebUtil.mapValuesComaparison(confrimationDet.get(i), enteredDetails.get(i))) {
					status = false;
				}
			}
			if (status)
				LogUtility.logInfo("---> validateDataInConfirmationPage  <---",
						" data is same as data entered " + confrimationDet);
			else
				LogUtility.logError("---> validateDataInConfirmationPage  <---",
						" data is not same as expected  " + confrimationDet);
		} catch (Exception e) {
			LogUtility.logException("validateDataInConfirmationPage", "Failed to verify data in confirmation page  ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To change a list into a map based on the requirement
	 * 
	 * @param list
	 * @return
	 */
	public LinkedHashMap<String, String> changeFromListToLinkedHashMap(List<WebElement> list) {
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		try {
			for (int i = 0; i < list.size(); i++) {
				map.put(list.get(i).getAttribute("aria-label"), list.get(i).getText());
			}
			LogUtility.logInfo("---> changeFromListToLinkedHashMap <---", "New map is " + map);
		} catch (Exception e) {
			LogUtility.logException("changeFromListToLinkedHashMap", "Failed to change list to hash map  ", e,
					LoggingLevel.ERROR, true);
		}
		return map;
	}

	/**
	 * To set the confirmation number
	 */
	public void setConfirmationNumbers() {
		try {
			setValueInRuntimeDataMap("PayBillsConfirmationNumber", confirmationNumber);
			LogUtility.logInfo("---> setConfirmationNumbers <---", "Confirmation Number is " + confirmationNumber);
		} catch (Exception e) {
			LogUtility.logException("setConfirmationNumbers", "Failed to set Confirmation Number ", e,
					LoggingLevel.ERROR, true);

		}
	}

	/**
	 * To check the tool tip message
	 */
	public boolean checkToolTipMessage() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(toolTipPC);
			if (webActions.isDisplayed(toolTipPC)) {
				status = wolWebUtil.checkTheTooltipMessage(toolTipPC, jsonDataParser.getTestDataMap().get("Message"));
				if (status)
					LogUtility.logInfo("---> checkToolTipMessage <---",
							"Tool tip message is found " + jsonDataParser.getTestDataMap().get("Message"));
				else
					LogUtility.logError("---> checkToolTipMessage  <---", "Tool tip message is not found  ");
			} else
				LogUtility.logInfo("---> checkToolTipMessage <---", "Tool tip element is not displayed");
		} catch (Exception e) {
			LogUtility.logException("checkToolTipMessage", "Failed to find tooltip element ", e, LoggingLevel.ERROR,
					true);

		}
		return status;
	}

	/**
	 * To check the tool tip message
	 */
	public String checkForNextStepLinks(String linksType, String testDataLinks) {
		String status = "";
		try {
			waits.waitForPageToLoad(maxTimeOut);
			List<WebElement> list = new ArrayList<WebElement>();
			if (linksType.equalsIgnoreCase("Confirmation"))
				list = lstNextStepsConfirm;
			else
				list = lstNextSteps;

			for (String eachStepFromJSON : jsonDataParser.getTestDataMap().get(testDataLinks).split(",")) {
				for (WebElement eachLink : list) {
					if (webActions.getText(eachLink).equals(eachStepFromJSON)) {
						status = status + webActions.getText(eachLink) + ",";
					}
				}
			}
			if (status.equals(jsonDataParser.getTestDataMap().get(testDataLinks) + ","))
				LogUtility.logInfo("---> checkForNextStepLinks <---", "All the next steps are present");
			else
				LogUtility.logError("---> checkForNextStepLinks  <---", "All the next steps are not present");
		} catch (Exception e) {
			LogUtility.logException("checkForNextStepLinks", "Failed to find  next step links ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * verify field level error message
	 * 
	 * @param errorType
	 * @return
	 */
	public boolean checkFieldLevelErrorMsg(String errorType) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtErrorMsg);
			if (txtErrorMsg.getText().equals(jsonDataParser.getTestDataMap().get(errorType))) {
				status = true;
				LogUtility.logInfo("---> checkFieldLevelErrorMsg <---",
						"Found the error message " + txtErrorMsg.getText());
			} else
				LogUtility.logError("---> checkFieldLevelErrorMsg <---",
						"Could not find the error message " + txtErrorMsg.getText());
		} catch (Exception e) {
			LogUtility.logException("checkFieldLevelErrorMsg", "Failed to find  the field level  message ", e,
					LoggingLevel.ERROR, true);

		}
		return status;
	}

	/**
	 * verify page level error message
	 * 
	 * @return
	 */
	public boolean checkPageLevelErrorMsg() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtCommonErrorMsg);
			if (txtCommonErrorMsg.getText().equals(jsonDataParser.getTestDataMap().get("Common Error Message"))) {
				status = true;
				LogUtility.logInfo("---> checkPageLevelErrorMsg <---",
						"Found the error message " + txtErrorMsg.getText());
			} else
				LogUtility.logError("---> checkPageLevelErrorMsg <---",
						"Could not find the error message " + txtErrorMsg.getText());
		} catch (Exception e) {
			LogUtility.logException("checkPageLevelErrorMsg", "Failed to find  the page level  message ", e,
					LoggingLevel.ERROR, true);

		}
		return status;
	}

	/**
	 * verify the maximum number of chars allowed in memo field
	 * 
	 * @param data
	 * @return
	 */
	public boolean checkMemoLetterCount(String data) {
		boolean status = false;
		try {
			waits.waitForDOMready();
			String dataFromUI = paymentMemo.getAttribute("value");
			if (dataFromUI.equals(data.substring(0, 20))) {
				status = true;
				LogUtility.logInfo("---> checkMemoLetterCount <---", "Only 20 letters are allowed in payment memo ");
			} else
				LogUtility.logError("---> checkMemoLetterCount <---",
						"More than 20 letters are allowed in payment memo ");
		} catch (Exception e) {
			LogUtility.logException("checkMemoLetterCount", "Failed to find  the memo max field length ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkTheDeliveryDateToolTip(String paymentType, String cycles) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			eleToGetText = delDateToolTip;
			String fromDate = eleToGetText.getText();
			if (wolWebUtil.checkTheTooltipMessage(eleToGetText, getRepititiveDates(paymentType, cycles, fromDate))) {
				status = true;
				LogUtility.logInfo("---> checkTheDeliveryDateToolTip <---",
						"Tooltip is successfully verified " + getRepititiveDates(paymentType, cycles, fromDate));
			} else {
				LogUtility.logError("---> checkTheDeliveryDateToolTip <---",
						"Tooltip is not displayed as " + getRepititiveDates(paymentType, cycles, fromDate));
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheDeliveryDateToolTip", "Failed to find  Tooltip", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public String getRepititiveDates(String frequency, String cycles, String fromDate) {
		String allDates = "";
		int days = 0;
		try {
			switch (frequency) {
			case "Weekly":
				days = 7;
				break;
			}
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate date = LocalDate.parse(LocalDate.parse(fromDate, formatter).format(formatter2));
			/*
			 * TODO: This following is to be replaced with this loop when the defect gets
			 * closed by dev
			 * 
			 * for (int i = 1; i <= Integer.parseInt(cycles); i++) { allDates = allDates +
			 * wolWebUtil.getDateWithoutHolidaysAndWeekend(date,days*i,jsonDataParser.
			 * getTestDataMap().
			 * get("Public Holidays")).format(DateTimeFormatter.ofLocalizedDate(FormatStyle.
			 * LONG)); }
			 */
			for (int i = 1; i <= Integer.parseInt(cycles) - 1; i++) {
				date = wolWebUtil.getDateWithoutHolidaysAndWeekend(date, days,
						jsonDataParser.getTestDataMap().get("Public Holidays"));
				if (Integer.parseInt(cycles) - 1 == 1) {
					allDates = allDates + date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG))
							.replaceAll(", ", ",").toUpperCase();
					break;
				} else if (i > 4) {
					allDates = allDates + "(" + (String.valueOf(Integer.parseInt(cycles) - i))
							+ jsonDataParser.getTestDataMap().get("More than 5 payments") + ")" + "<br>";
					break;
				} else
					allDates = allDates + date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG))
							.replaceAll(", ", ",").toUpperCase() + "<br>";
			}
			LogUtility.logInfo("---> getRepititiveDates <---", "Tooltip is successfully verified ");
		} catch (NumberFormatException e) {
			LogUtility.logException("getRepititiveDates", "Failed to check  the dates on clicking the tooltip", e,
					LoggingLevel.ERROR, true);
		}
		return allDates;

	}

	/**
	 * checks the sort by functionality
	 * 
	 * @param sortByValue
	 * @return
	 */
	public boolean checkSortByFunctionality(String sortByValue) {
		boolean status = false;
		ArrayList<String> payeeNames = new ArrayList<>();
		List<String> payeeNamesAfterSort = new ArrayList<>();
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			for (WebElement eachPayee : lstAllPayees) {
				payeeNames.add(eachPayee.getText().toUpperCase());
			}
			LogUtility.logInfo("---> checkSortByFunctionality <---", "List of Payee before sort are " + payeeNames);
			if (sortByValue.contains("REVERSE"))
				payeeNamesAfterSort = wolWebUtil.sortTheList(payeeNames, "REVERSE");
			else
				payeeNamesAfterSort = wolWebUtil.sortTheList(payeeNames, "NORMAL");
			if (payeeNames.equals(payeeNamesAfterSort)) {
				status = true;
				LogUtility.logInfo("---> checkSortByFunctionality <---",
						"Payees are displayed in order " + payeeNamesAfterSort);
			} else
				LogUtility.logInfo("---> checkSortByFunctionality <---",
						"Payees are not displayed in order " + payeeNamesAfterSort);
		} catch (Exception e) {
			LogUtility.logException("checkSortByFunctionality", "Failed to check  the sort by functionality", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean selectSortBy(String sortByValue) {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(selSortBy)) {
				webActions.selectDropDownByText(selSortBy, sortByValue);
				status = true;
				LogUtility.logInfo("---> selectSortBy <---", "Selected the option " + sortByValue);
			}
		} catch (Exception e) {
			LogUtility.logException("selectSortBy", "Failed to select the option " + sortByValue, e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * checks if the list payee of type(Electronic /Check are present)
	 * 
	 * @param payeeType
	 * @return true if not present
	 */
	public boolean checkForPayeeTypeNeg(String payeeType) {
		boolean status = false;
		try {
			if (payeeType.equals("Electronic")) {
				if (lstElectronicPayees == null || lstElectronicPayees.size() == 0) {
					status = true;
					LogUtility.logInfo("---> checkForPayeeTypeNeg <---", "No electronic payees are present");
				} else {
					LogUtility.logError("---> checkForPayeeTypeNeg <---", "Electronic payees are present");
				}
			} else {
				if (lstCheckPayees == null || lstCheckPayees.size() == 0) {
					status = true;
					LogUtility.logInfo("---> checkForPayeeTypeNeg <---", "No check payees are present");
				} else {
					LogUtility.logError("---> checkForPayeeTypeNeg <---", "check payees are present");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkForPayeeTypeNeg", "Failed to check the payee type", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * checks if the payee selected is on shortlist
	 * 
	 * @param onShortList
	 * @return
	 */
	public boolean checkIfPayeeIsOnShortList(String onShortList) {
		boolean status = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(rdBtnShortListYes);
			WebElement eleToGetAttrValue = null;
			if (onShortList.equals("On Shortlist"))
				eleToGetAttrValue = rdBtnShortListYes;
			else
				eleToGetAttrValue = rdBtnShortListNo;
			if (webActions.getAttributeValue(eleToGetAttrValue, "checked").equalsIgnoreCase("true")) {
				status = true;
				LogUtility.logInfo("---> checkIfPayeeIsOnShortList <---", "Payee is " + onShortList);
			} else
				LogUtility.logError("---> checkIfPayeeIsOnShortList <---", "Payee type is not : " + onShortList);
		} catch (Exception e) {
			LogUtility.logException("checkIfPayeeIsOnShortList", "Failed to check if payee is shortlisted", e,
					LoggingLevel.ERROR, true);
		}
		return status;

	}

	/**
	 * To click on the PayeeDetails link
	 */
	public boolean clickOnPayeeDetailsLink(String PayeeType) {
		boolean status = true;
		try {
			if (waits.waitUntilElementIsPresent(txtBoxPayeeFilter)) {
				if (!lstAllPayeesMemo.get(0).isDisplayed())
					webActions.clickElement(lstAllPayees.get(0));
				wolWebUtil.scrollToElement(lnkPayeeDetails);
				webActions.clickElement(lnkPayeeDetails);
				if (wolWebUtil.isAlertPresent()) {
					alerts.acceptAlert();
				}
				status = true;
			}
			LogUtility.logInfo("---> clickOnPayeeDetailsLink <---", "Clicked on Payee Details link");
		} catch (Exception e) {
			LogUtility.logException("clickOnPayeeDetailsLink", "Failed to click payee details link", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To select the given value in PayFrom dropdown
	 * 
	 * @throws Exception
	 */
	public void selectFromShowOnlyDropDown(String text) throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(selShowOnly);
			wolWebUtil.scrollToElement(selShowOnly);
			webActions.selectDropDownByText(selShowOnly, text);
			LogUtility.logInfo("---> selectFromShowOnlyDropdown <---", "Selected " + text + " from show only dropdown");
		} catch (Exception e) {
			LogUtility.logException("selectFromShowOnlyDropdown", "Failed to select from dropdown - showonly", e,
					LoggingLevel.ERROR, true);
			throw new Exception("Exception while selecting from showonly dropdown " + e.getMessage());
		}
	}

	/**
	 * To click on the Payee and check for the labels in payment details
	 */
	public Map<String, String> clickOnThePayeeFromList(String payeename) throws InterruptedException {
		HashMap<String, String> mapstatus = new HashMap<>();
		List<WebElement> payeeList = new ArrayList<>();
		try {
			if (payeename.equals("PERSONAL")) {
				webActions.clickElement(lstPersonalPayees.get(1));
				payeeList = lstPersonalPayees;
			} else if (payeename.equals("BUSINESS")) {
				webActions.clickElement(lstBusinessPayees.get(1));
				payeeList = lstBusinessPayees;
			} else {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", lstPayees.get(0));
				lstPayees.get(0).click();
				payeeList = lstPayees;
			}
			for (WebElement payeeDetailsEle : payeeList) {
				mapstatus.put(payeeDetailsEle.getAttribute("aria-label"), payeeDetailsEle.getText());
				if (payeeDetailsEle.getAttribute("aria-label").equals("Additional Details"))
					break;
			}
			LogUtility.logInfo("---> clickonthePayeeFromList <---", "Checked all the labels for a payment");
		} catch (Exception e) {
			LogUtility.logException("clickonthePayeeFromList", "Failed to checked all the labels for a payment", e,
					LoggingLevel.ERROR, true);
		}
		return mapstatus;
	}

	/**
	 * To check the page heading is as expected as the given value
	 * 
	 * @param pagename
	 * @param heading
	 * @return
	 */
	public boolean checkForPageHeading(String pagename, String heading) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (pagename) {
			case "Confirmation":
				eleToGetText = lblConfirmation;
				break;
			case "Verification":
				eleToGetText = lblVerification;
				break;
			case "AlertConfirmation":
				eleToGetText = lblAlertConfirmation;
				break;
			case "UpdatePayee":
				eleToGetText = lblUpdatePayee;
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText);
			if (webActions.getText(eleToGetText).equals(heading)) {
				LogUtility.logInfo("---> checkforPageHeading <---", "Heading " + heading + " is displayed");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkforPageHeading", "Failed to check page heading", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForTheMessage(String messageType, String message) {
		WebElement eleToGetText = null;
		boolean status = false;
		try {
			switch (messageType) {
			case "Confirmation":
				eleToGetText = lblConfirmationMsg;
				break;
			case "NoPayees":
				eleToGetText = lblNoPayeeMsg;
				break;
			case "InvalidDate":
				eleToGetText = lblInvalidDateMsg;
				break;
			case "InvalidAmount":
				eleToGetText = lblInvalidAmountMsg;
				break;
			case "Unauthorizeduser":
				eleToGetText = lblUnauthorizedUser;
				break;
			case "NoBillPayAccounts":
				eleToGetText = lblNoBillPayAccountMsg;
				break;
			case "PayeeUpdate":
				eleToGetText = lblUpdatePayeeMsg;
				break;
			default:
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText, 3);
			if (webActions.getText(eleToGetText).equals(message)) {
				LogUtility.logInfo("---> checkfortheMessage <---", "Message " + message + " is displayed");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkfortheMessage", "Failed to check the message " + message, e,
					LoggingLevel.ERROR, true);

		}
		return status;
	}

	/**
	 * To accept the alert box if exists
	 */
	public void acceptAlertCheckbox() {
		try {
			webActions.clickElement(chkAcceptAlert);
			webActions.clickElement(btnAcceptAlert);
			LogUtility.logInfo("---> acceptAlertCheckbox <---",
					"Accepted the delivery alert and clicked on setup alert");
		} catch (Exception e) {
			LogUtility.logException("acceptAlertCheckbox", "Failed to accept alert box", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public boolean checkMakeDepositTitle(String title) {
		boolean status = false;
		try {
			if (txtMakeDeposit.getText().equals(title)) {
				status = true;
				LogUtility.logInfo("checkMakeDepositTitle", "Found the title " + title);
			}
		} catch (Exception e) {
			LogUtility.logException("checkMakeDepositTitle", "Failed to find the title", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public String getTheAccountNumber() {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			String defaultselected = wolWebUtil.getDefaultValueForSelect(selPayFrom);
			for (WebElement element : selPayFromOptions) {
				fromAcc = webActions.getText(element);
				if (!fromAcc.equals(defaultselected)) {
					webActions.clickElement(element);
					setValueInRuntimeDataMap("PayBillsFromAccount", fromAcc);
					break;
				}
			}
			LogUtility.logInfo("---> getTheAccountNumber <---", "Got the From AccountNumber" + fromAcc);
			waits.waitForPageToLoad(maxTimeOut);
		} catch (Exception e) {
			LogUtility.logException("getTheAccountNumber", "Failed to get the account number", e, LoggingLevel.ERROR,
					true);
		}
		return fromAcc;
	}
}