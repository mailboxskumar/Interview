package com.wb.wol_web.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class DebitCardCounterPage extends ObjectBase {

	public DebitCardCounterPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "tr td b")
	protected List<WebElement> lstApproveSetUpLabels;

	@FindBy(css = "#pending_transactions label")
	protected WebElement btnDebitCardCounter;

	@FindBy(css = "td input[name=\"btnUpdate\"]")
	protected WebElement btnUpdate;

	@FindBy(css = "#pending_transactions div")
	protected List<WebElement> lstPendingMessage;

	/**
	 * verifyFieldName - To verify field name is present or not
	 * 
	 * @param fieldName
	 * @return flag
	 */
	public boolean verifyFieldName(String fieldName) {
		boolean flag = true;
		try {
			for (WebElement element : lstApproveSetUpLabels)
				if (wolWebUtil.verifyTextContains(element, fieldName)) {
					LogUtility.logInfo("---->verifyFieldName<----", lstApproveSetUpLabels + " is present");
					flag = false;
					break;
				}
		} catch (Exception e) {
			LogUtility.logException("verifyFieldName", "Field Name is not verified", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyAlertErrorMessage - To verify Error message in alert
	 * 
	 * @param alertErrorMessage
	 * @return flag
	 */
	public boolean verifyAlertErrorMessage(String alertErrorMessage) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(btnUpdate)) {
				webActions.clickElement(btnUpdate);
				LogUtility.logInfo("---> verifyAlertErrorMessage <---", "Clicked on Update button");
				if (alerts.getTextFromAlert().contains(alertErrorMessage)) {
					flag = true;
					alerts.acceptAlert();
					LogUtility.logInfo("---> verifyAlertErrorMessage <---",
							"Alert Message is verified: " + alertErrorMessage);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAlertErrorMessage", "Alert Error Message is not verified", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyLabelName - To verify label names
	 * 
	 * @param fieldName
	 * @return flag
	 */
	public boolean verifyLabelName(String fieldName) {
		boolean flag = false;
		try {
			if (wolWebUtil.elementNotDisplay(btnDebitCardCounter)) {
				flag = true;
				LogUtility.logInfo("---->verifyLabelName<----", fieldName + " is not present");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLabelName", "Label Name is not verified", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyDebitCardCounterMessage - To verify message for Debit Card Counter
	 * field
	 * 
	 * @param messageDebitCardCounter
	 * @return flag
	 */
	public boolean verifyDebitCardCounterMessage(String messageDebitCardCounter) {
		boolean flag = true;
		try {
			for (WebElement element : lstPendingMessage)
				if (wolWebUtil.verifyTextContains(element, messageDebitCardCounter)) {
					flag = false;
					LogUtility.logInfo("---->verifyDebitCardCounterMessage<----",
							messageDebitCardCounter + " is present");
					break;
				}
		} catch (Exception e) {
			LogUtility.logException("verifyDebitCardCounterMessage", "Debit Card Counter Message is not verified", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

}
