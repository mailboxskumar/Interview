package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class PendingTransfersPage extends ObjectBase {

	public String disclosurelnkText;

	public PendingTransfersPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "#recurringFutureTransferAlert > div")
	protected WebElement txtRecurringMsg;

	@FindBy(id = "future")
	protected WebElement rdbtnFuture;

	@FindBy(id = "recurring")
	protected WebElement rdbtnRecurring;

	@FindBy(id = "transfer_amount-3")
	protected WebElement txtAmount;

	@FindBy(id = "sdate")
	protected WebElement txtDate;

	@FindBy(id = "frequency")
	protected WebElement lstFrequency;

	@FindBy(id = "transfers_note_payments_msp__body")
	protected WebElement txtMSPAccountContent;

	@FindBy(id = "transfers_remaining-9")
	protected WebElement txtRemainTransfers;

	@FindBy(css = "#bodyContent h1:nth-child(1)")
	protected WebElement txtPendingTrnsHeader;

	@FindBy(css = "[class='note ']")
	protected WebElement txtNoteContent;

	@FindBy(css = "div.note a")
	public WebElement lnkDisclosure;

	@FindBy(css = "#subHeaderContainer strong")
	protected WebElement txtDisclosureContent;

	@FindBy(css = "[class='lightbox-wrap is-visible is-top'] button[aria-label='Close the dialog']")
	protected WebElement btnDisclosureClose;

	@FindBy(css = "[class*='errorInline']")
	protected WebElement txtDateErrMsg;

	@FindBy(css = "[class*='notification']")
	protected WebElement txtCnfrmMsg;

	@FindBy(css = "[class='errorInline mediumInput']")
	protected WebElement txtAmountErrMsg;

	@FindBy(id = "submit1")
	protected WebElement btnContinue;

	@FindBy(css = "[value*='Delete']")
	private WebElement btnDelete;

	@FindBy(css = "[name='cancel']")
	private WebElement btnCancel;

	@FindBy(name = "yes")
	private WebElement btnYes;

	@FindBy(name = "no")
	protected WebElement btnNo;

	@FindBy(css = "[class='lightbox-wrap is-visible is-top'] button[aria-label='Close the dialog']")
	protected WebElement btnClose;

	@FindBy(css = "[class=lightBoxCancel] > div:nth-child(1)")
	protected WebElement txtCancelTransfer;

	@FindBy(css = "#bodyContent p")
	protected WebElement txtUpdateContent;

	@FindBy(xpath = "//*[contains(text(),'pending transfer')]")
	protected WebElement txtUpdateTransCnfrmMsg;

	/**
	 * clickUpdateTransferDisclosure:- To Click on Disclosure Link in Update Pending
	 * Transfer Details Page
	 */
	public boolean clickUpdateTransferDisclosure() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkDisclosure, maxTimeOut);
			webActions.clickElement(lnkDisclosure);
			disclosurelnkText = webActions.getText(lnkDisclosure);
			if (waits.waitUntilElementIsPresent(btnDisclosureClose)) {
				flag = true;
				LogUtility.logInfo("clickUpdateTransferDisclosure",
						"Clicked on Disclosure Link in Update Pending Transfer Details Page");
			}
		} catch (Exception e) {
			LogUtility.logException("clickUpdateTransferDisclosure",
					"Failed to Click on Disclosure Link in Update Pending Transfer Details Page ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyDisclosureContent-To Verify Content displayed or not in Disclosure
	 * Light Box
	 * 
	 * @return- True/False
	 */
	public boolean verifyDisclosureContent() {
		try {
			waits.staticWait(3);
			return webActions.isDisplayed(txtDisclosureContent);
		} catch (Exception e) {
			LogUtility.logException("verifyDisclosureContent", "Failed to Verify Disclosure content message ", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * clickUpdateDisclosureCloseButton:- To Click on Close button in Disclosure
	 * Lightbox
	 */
	public void clickUpdateDisclosureCloseButton() {
		try {
			waits.waitUntilElementIsPresent(btnDisclosureClose, maxTimeOut);
			webActions.clickElementJS(btnDisclosureClose);
			waits.staticWait(5);
			LogUtility.logInfo("clickUpdateDisclosureCloseButton",
					"Clicked on Close button in Disclosure Light box of transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickUpdateDisclosureCloseButton",
					"Failed to Click on Close button in Disclosure Light box of transfers Page", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * enterAmount:- To Enter amount in Update Transfers Page
	 * 
	 * @param amount to enter
	 */
	public boolean enterAmount(String amount) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAmount);
			webActions.setValue(txtAmount, amount);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtAmount, "value").equalsIgnoreCase(amount)) {
				flag = true;
				LogUtility.logInfo("enterAmount", "Entered value in Transfer Amount Field");
			}
		} catch (Exception e) {
			LogUtility.logException("enterAmount", "Failed to enter Amount", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * updateTransferTypeDetails:- To update internal Transfer details
	 * 
	 * @param transferDetails:- Transfer Type,Frequency,No.of Transfers
	 */
	public boolean updateTransferTypeDetails(Map<String, String> transferDetails) {
		boolean flag = false;
		try {
			if (transferDetails.get("Update Type").equals("Future")) {
				waits.waitUntilElementIsPresent(rdbtnFuture);
				webActions.clickElement(rdbtnFuture);
				waits.waitForDOMready();
				if (webActions.isChecked(rdbtnFuture))
					flag = true;
			} else if (transferDetails.get("Update Type").equals("Recurring")) {
				waits.waitUntilElementIsPresent(rdbtnRecurring);
				webActions.clickElement(rdbtnRecurring);
				waits.waitForDOMready();
				if (webActions.isChecked(rdbtnRecurring))
					flag = true;
				webActions.selectDropDownByValueJs(lstFrequency, transferDetails.get("Frequency").toUpperCase());
				webActions.setValue(txtRemainTransfers, transferDetails.get("Transfers"));
			}
			LogUtility.logInfo("updateTransferTypeDetails", "updated Transfer Details");
		} catch (Exception e) {
			LogUtility.logException("updateTransferTypeDetails", "Failed to update Transfer Details", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickContinueToUpdate: To click on continue button among transfer pages
	 */
	public void clickContinueToUpdate() {
		try {
			waits.waitUntilElementIsPresent(btnContinue);
			webActions.clickElement(btnContinue);
			LogUtility.logInfo("clickContinueToUpdate", "Clicked on Continue Button in Pending Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickContinueToUpdate",
					"Failed to Click on Continue Button in Pending Transfers Page", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * verifyNoteContent:- To verify the note content displayed in Pending Transfers
	 * page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyNoteContent(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtNoteContent, message);
		} catch (Exception e) {
			LogUtility.logException("verifyNoteContent", "Failed to Verify note content message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyAmountErrMsg:- To verify error message amount text field in Pending
	 * Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAmountErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtAmountErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAmountErrMsg", "Failed to Verify Amount Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyDateErrMsg:- To verify error message Date text field in Pending
	 * Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyDateErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtDateErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyDateErrMsg", "Failed to Verify Date Error message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * updateTransferPastDate: To Enter Date in Transfer Date text field in pending
	 * Transfer page
	 * 
	 * @param days: Days
	 */
	public void updateTransferPastDate(int days) {
		try {
			waits.waitUntilElementIsPresent(txtDate, maxTimeOut);
			wolWebUtil.setRequireDate(txtDate, "Days", days);
			waits.staticWait(3);
			LogUtility.logInfo("updateTransferPastDate", "Entered Date value in Transfer Date field");
		} catch (Exception e) {
			LogUtility.logException("updateTransferPastDate", "Failed to Enter Date value in Transfer Date field", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * updateTransferDate: To Enter Date in Transfer Date text field in pending
	 * Transfer page
	 * 
	 * @param days: Days
	 */
	public boolean updateTransferDate(String date) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtDate, maxTimeOut);
			webActions.setValue(txtDate, date);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtDate, "value").equalsIgnoreCase(date)) {
				flag = true;
				LogUtility.logInfo("updateTransferDate", "Entered Date value in Transfer Date field");
			}
		} catch (Exception e) {
			LogUtility.logException("updateTransferDate", "Failed to Enter Date value in Transfer Date field", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyConfirmMsg:- To verify the confirmation message in Pending Transfers
	 * page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyConfirmMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtCnfrmMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyConfirmMsg", "Failed to verify confirmation message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * clickDeleteButton: To click on Delete button among transfer pages
	 */
	public void clickDeleteButton() {
		try {
			waits.waitUntilElementIsPresent(btnDelete);
			webActions.clickElement(btnDelete);
			LogUtility.logInfo("clickDeleteButton", "Clicked on Delete Button in Pending Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickDeleteButton", "Failed to click Delete button", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

}
