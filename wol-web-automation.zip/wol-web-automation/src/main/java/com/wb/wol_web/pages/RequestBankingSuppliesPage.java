
package com.wb.wol_web.pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class RequestBankingSuppliesPage extends ObjectBase {

	public RequestBankingSuppliesPage() {
		PageFactory.initElements(driver, this);
	}

//	@FindBy(xpath = "//table")
	@FindBy(css = "table")
	protected WebElement tableSearchCustReqData;

//	@FindBy(xpath = "//h1[@data-wbst-message-key='relatedservices.confirm_supplies.heading']")
	@FindBy(css = "h1[data-wbst-message-key='relatedservices.confirm_supplies.heading']")
	protected WebElement txtConfirmationHeading;

//	@FindBy(xpath = "//h1[@data-wbst-message-key='relatedservices.request_supplies.heading']")
	@FindBy(css = "h1[data-wbst-message-key='relatedservices.request_supplies.heading']")
	protected WebElement txtRequestSuppliesHeading;

//	@FindBy(xpath = "//input[@value='Request Supplies']")
	@FindBy(css = "input[value='Request Supplies']")
	protected WebElement btnRequestSupplies;

//	@FindAll(@FindBy(xpath = "//div[@class='label']"))
	@FindAll(@FindBy(css = "div.label"))
	protected List<WebElement> lstConfirmationDetLabels;

//	@FindAll(@FindBy(xpath = "//div[@class='label']/../div[@class='data']"))
	@FindAll(@FindBy(css = "div.labeldata> div.data"))
	protected List<WebElement> lstConfirmationDetValues;

//	@FindBy(xpath = "//input[contains(@id,'box_1Id')]")
	@FindBy(css = "input#box_1Id")
	protected WebElement btnSuppliesCheckBoxes1;

//	@FindBy(xpath = "//input[contains(@id,'box_2Id')]")
	@FindBy(css = "id:contains('box_2Id')")
	protected WebElement btnSuppliesCheckBoxes2;

//	@FindBy(xpath = "//input[contains(@id,'box_3Id')]")
	@FindBy(css = "id:contains('box_3Id')")
	protected WebElement btnSuppliesCheckBoxes3;

//	@FindBy(xpath = "//input[contains(@id,'box_4Id')]")
	@FindBy(css = "id:contains('box_4Id')")
	protected WebElement btnSuppliesCheckBoxes4;

	/**
	 * Checks the page heading with the given parameter
	 * 
	 * @Author:Sneha K
	 * @Created on:Jun 21 2019
	 * @param pageHeading
	 * @return
	 */
	public boolean checkForThePageHeading(String pageHeading) {
		WebElement eleToGetText = null;
		boolean status = false;
		try {

			waits.waitForPageToLoad(10);
			if (pageHeading.contains("Confirmation")) {
				eleToGetText = txtConfirmationHeading;
			} else
				eleToGetText = txtRequestSuppliesHeading;
			if (wolWebUtil.verifyText(eleToGetText, pageHeading)) {
				status = true;
				LogUtility.logInfo("--->checkForThePageHeading<---", "Reached the page with heading" + pageHeading);
			} else
				LogUtility.logError("---> checkForThePageHeading <---", "Failed to Reach the page with heading");
		} catch (Exception e) {
			LogUtility.logError("--->checkForThePageHeading<---", e.getMessage());
		}
		return status;
	}

	/**
	 * Clicks on the request supply items
	 * 
	 * @param supplies
	 */
	public boolean clickOnSupplies(String supplies) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		boolean status = false;
		try {
			if (supplies.contains("Checkbook Register")) {
				if (waits.waitUntilElementIsPresent(btnSuppliesCheckBoxes1)) {
					webActions.clickElement(btnSuppliesCheckBoxes1);
					status = true;
				}
				LogUtility.logInfo("--->clickOnSupplies<---", "Clicked on the Checkbook Register checkbox");
			}
			if (supplies.contains("Bank by Mail Envelopes")) {
				if (waits.waitUntilElementIsPresent(btnSuppliesCheckBoxes2)) {
					webActions.clickElement(btnSuppliesCheckBoxes2);
					status = true;
				}
				LogUtility.logInfo("--->clickOnSupplies<---", "Clicked on the Bank by Mail Envelopes checkbox");
			}
			if (supplies.contains("Deposit Slips for Checking Accounts")) {
				if (waits.waitUntilElementIsPresent(btnSuppliesCheckBoxes3)) {
					{
						webActions.clickElement(btnSuppliesCheckBoxes3);
						status = true;
					}
					LogUtility.logInfo("--->clickOnSupplies<---",
							"Clicked on the Deposit Slips for Checking Accounts checkbox");
				}
				if (supplies.contains("Deposit Slips for Saving Accounts")) {
					waits.waitUntilElementIsPresent(btnSuppliesCheckBoxes4);
					webActions.clickElement(btnSuppliesCheckBoxes4);
					status = true;
				}
				LogUtility.logInfo("--->clickOnSupplies<---",
						"Clicked on the Deposit Slips for Savings Accounts checkbox");
			}
		} catch (Exception e) {
			LogUtility.logError("--->clickOnSupplies<---", e.getMessage());
		}
		return status;
	}

	/**
	 * clicks on RequestSupplies button
	 * 
	 * @throws Exception
	 */
	public boolean clickOnRequestSuppliesButton() throws Exception {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnRequestSupplies)) {
				webActions.clickElement(btnRequestSupplies);
				status = true;
				LogUtility.logInfo("--->clickOnRequestSuppliesButton<---", "clicked on the request supplies");
			} else
				LogUtility.logError("---> clickOnRequestSuppliesButton <---",
						"Failed to click on  the request supplies");
		} catch (Exception e) {
			LogUtility.logError("--->clickOnRequestSuppliesButton<---", e.getMessage());
		}
		return status;
	}

	/**
	 * clicks on RequestSupplies button
	 * 
	 * @throws Exception
	 */
	public HashMap<String, String> validateConfirmationDetails() {
		HashMap<String, String> map = new HashMap<>();
		try {
			for (int i = 0; i < lstConfirmationDetLabels.size(); i++) {
				map.put(lstConfirmationDetLabels.get(i).getText(), lstConfirmationDetValues.get(i).getText());
			}
			LogUtility.logInfo("--->validateConfirmationDetails<---",
					"Confirmation details are " + lstConfirmationDetValues);
		} catch (Exception e) {
			LogUtility.logError("--->validateConfirmationDetails<---", e.getMessage());
		}
		return map;
	}

	public boolean checkTheConfirmationDetailsInWebcom(String requestType, String confirmationDate) {
		boolean status = false;
		String userName = getValueFromRuntimeDataMap("UserName");
		try {
			List<WebElement> rows = tableSearchCustReqData.findElements(By.xpath("//tbody//tr"));
			for (WebElement row : rows) {
				List<WebElement> columns = row.findElements(By.xpath(".//td"));
				if (columns.get(1).getText().equalsIgnoreCase(userName)) {
					if (columns.get(2).getText().equals(requestType)
							&& columns.get(3).getText().contains(confirmationDate.split(" ")[1])) {
						status = true;
						LogUtility.logInfo("--->checkTheConfirmationDetailsInWebcom<---",
								"Found the confirmation details in webcom " + userName + " " + requestType + " "
										+ confirmationDate);
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->checkTheConfirmationDetailsInWebcom<---", e.getMessage());
		}
		return status;
	}

}
