
package com.wb.wol_web.pages;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class UseCasesPage extends ObjectBase {

	public UseCasesPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "#confirmationNumber__display>span")
	protected WebElement txtPaymentConfirmationNumber;

	@FindBy(name = "amount")
	protected WebElement inputAmount;

	@FindBy(id = "focusAction")
	protected WebElement btnUpdate;

	@FindAll({ @FindBy(css = "[data-wbst-message-key='eu.updatepaymentdetails.confirmation'] + div.data"),
			@FindBy(css = "[data-wbst-message-key='payee.nwacct.conf.number'] + div.data") })
	protected WebElement txtUpdatedPaymentConfirmation;

	@FindBy(name = "user")
	protected WebElement txtAppUsername;

	@FindBy(name = "password")
	protected WebElement txtAppPassword;

	@FindBy(name = "submit")
	protected WebElement btnLogon;

	@FindBy(id = "welcome")
	protected WebElement txtWelcomeMsg;

	@FindBy(className = "page_title")
	protected WebElement txtPageHeading;

	@FindBy(tagName = "h1")
	protected WebElement txtPageHeader;

	@FindAll({ @FindBy(name = "user_name"), @FindBy(name = "userName") })
	protected WebElement txtUserName;

	@FindBy(name = "transaction_id")
	protected WebElement listTransactionName;

	@FindBy(name = "network")
	protected WebElement listNetwork;

	@FindBy(name = "state1")
	protected WebElement listState;

	@FindBy(name = "paymentType")
	protected WebElement listPaymentType;

	@FindBy(css = "[value='Search']")
	protected WebElement btnSearch;

	@FindBy(css = "[value='Continue']")
	protected WebElement btnContinue;

	@FindBy(css = "[value='Activate']")
	protected WebElement btnActivate;

	@FindBy(css = "[value='Find Payment Details']")
	protected WebElement btnFindPaymentDetails;

	@FindBy(css = "button.submit[type='button']")
	protected WebElement btnEnable;

	@FindBy(css = "#table1 tr")
	protected List<WebElement> tableAuditSummary;

	@FindBy(css = "#table1 tr:nth-child(2)>td:nth-child(5)")
	protected WebElement txtConfirmationNumber;

	@FindBy(css = "tr>td.display_msg")
	protected List<WebElement> txtLabel;

	@FindBy(className = "formInfo")
	protected WebElement txtUpdateMessage;

	@FindBy(css = "div.col--locked.col--primary>table td")
	protected WebElement txtCustomerName;

	@FindBy(name = "displayName")
	protected WebElement inputDisplayName;

	@FindBy(name = "alias")
	protected WebElement inputAliasName;

	@FindBy(name = "address11")
	protected WebElement inputAddress1;

	@FindBy(name = "address21")
	protected WebElement inputAddress2;

	@FindBy(name = "city1")
	protected WebElement inputCityName;

	@FindBy(name = "zip1")
	protected WebElement inputZip;

	@FindBy(css = "[value='Add Alias']")
	protected WebElement btnAddAlias;

	@FindBy(name = "alias")
	protected WebElement inputAlias;

	@FindBy(css = "[value='Add Remittance Address']")
	protected WebElement btnAddRemAddress;

	@FindBy(css = "#table0 tbody>tr")
	protected List<WebElement> listTableRows;

	@FindBy(css = "[name='paymentdetails'] div.page_title")
	protected List<WebElement> txtResearchHeading;

	@FindBy(css = "[name='paymentdetails'] div:nth-child(6) label.value")
	protected WebElement txtConfirmationNumberPaymentHistory;

	@FindBy(name = "payment_date")
	protected WebElement txtDeliveryDate;

	@FindBy(css = "[name=confirmationNumber]")
	protected WebElement inputConfirmNumber;

	@FindBy(css = "[name=paymentDueDate]")
	protected WebElement inputPaymentDueDate;

	@FindBy(css = "td.stoppayment_reason>input")
	protected WebElement btnReason;

	@FindBy(css = "[data-wbst-message-key='ci.history.submitreseaarch.confirmationno'] + label")
	protected WebElement txtResearchConfirmation;

	@FindBy(css = "[data-wbst-message-key='eu.payment.research.confirmation']+div>label")
	protected WebElement txtResearchConfirmationNumber;

	@FindBy(name = "submitResearch")
	protected WebElement btnSubmitResearch;

	@FindBy(name = "deactivateAction")
	protected WebElement btnDeactivate;

	@FindBy(css = "[name='payment'] tbody>tr:nth-child(1)>td:nth-child(1)")
	protected WebElement linkDeliveryDatePendingPayment;

	@FindBy(css = "[value='Update']")
	protected WebElement btnUpdatePayment;

	@FindBy(css = "[value='Delete']")
	protected WebElement btnDeletePayment;

	@FindBy(css = "[data-wbst-message-key='payee.nwacct.conf.date']+div")
	protected WebElement txtOrderTimestamp;

	@FindBy(css = "[name='payment'] tbody td:nth-child(6)>a")
	protected List<WebElement> listPendingPayments;

	@FindBy(css = "[name='managePayee'] tr")
	protected List<WebElement> listManagePayeeRows;

	@FindBy(name = "nickname")
	protected WebElement txtAccountNickname;

	@FindBy(name = "from_date")
	protected WebElement txtFromDate;

	@FindBy(xpath = "//input[contains(@id,'AccountNumber__input')]")
	private WebElement txtPayeeAcctnum;

	public String paymentConfirmationNumber = "";
	public String basePath = "#table1 tr:nth-child(";
	public String confirmationRow = ")>td:nth-child(5)";
	public String timeStampRow = ")>td:nth-child(3)";
	public String transactionLink = ")>td:nth-child(1)>a";
	public String btnPath = "//tr/td[contains(text(),'%s')]/following-sibling::td/button";
	public String customerName = "";
	public String payeePath = "#pageContent tr:nth-child(";
	public String paymentStatus = ")>td:nth-child(6)";
	public String datePath = ")>td:nth-child(1)";
	public String txtResearchLabel = "[name='paymentdetails'] div.page_title";
	public String researchConfirmationNumber = "";
	public String payeeName = "";
	public String confirmationNumber = "";
	public String orderTimestamp = "";
	public String managePayeeBasePath = "[name='managePayee'] tr:nth-child(";
	public String managePayeeActiveStatus = ")>td:nth-child(3)";
	public String managePayeeActiveEdit = ")>td:nth-child(5)>a";
	public String accountNumber = "";
	public String fromDate = "";
	public String activeNonWebsterAccount = "";
	public String activeAccountPath = "//td[contains(text(),'Active')]//preceding::td[1]";
	public WebElement nonWebsterAccount = null;

	/**
	 * loginPassApplication: To log-on into PASS Application
	 * 
	 * @return
	 */
	public boolean loginPassApplication() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			String env = navigator.goToUrl(appURL);
			if (env.contains("qa"))
				navigator.goToUrl(getEnvironmentProperty("PassQA.url"));
			else if (env.contains("stag"))
				navigator.goToUrl(getEnvironmentProperty("PassStaging.url"));
			waits.waitUntilElementIsPresent(txtAppUsername, 10);
			webActions.setValue(txtAppUsername, getEnvironmentProperty("PassApp.user"));
			webActions.setValue(txtAppPassword, getEnvironmentProperty("PassApp.password"));
			webActions.clickElement(btnLogon);
			if (waits.waitUntilElementIsPresent(txtWelcomeMsg)) {
				LogUtility.logInfo("---> loginPassApplication <---", "Logged into PASS application");
				return true;
			} else
				LogUtility.logInfo("---> loginPassApplication <---", "Failed to Logged into PASS application");
		} catch (MalformedURLException e) {
			LogUtility.logError("---> loginPassApplication <---", e.getMessage());
		}
		return false;
	}

	/**
	 * checkPageTitlePass: To verify the page title
	 * 
	 * @param pageName
	 * @return
	 */
	public boolean checkPageTitlePass(String pageName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtPageHeading, pageName)
					|| wolWebUtil.verifyTextContains(txtPageHeader, pageName)) {
				LogUtility.logInfo("---> checkPageTitlePass <---", "Page  " + pageName + " is present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkPageTitlePass<--", "Page  " + pageName + " is not present", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterUserName: To enter the username
	 * 
	 * @param userName
	 * @return
	 */
	public boolean enterUserName(String userName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(txtUserName)) {
				webActions.setValue(txtUserName, userName);
				LogUtility.logInfo("---> enterUserName <---", "Entered the username " + userName);
				if (webActions.getText(txtUserName).equals(userName))
					return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterUserName<--", "not Entered the username " + userName, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectTransactionName: To select the value from transaction Name dropdown
	 * 
	 * @param value
	 * @param labelName
	 * @return
	 */
	public boolean selectTransactionName(String value, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement labelToSelect = null;
		try {
			switch (labelName) {
			case "Transaction Name":
				labelToSelect = listTransactionName;
				break;
			case "Network":
				labelToSelect = listNetwork;
				break;
			case "State":
				labelToSelect = listState;
				break;
			case "Payment Type":
				labelToSelect = listPaymentType;
				break;
			default:
				LogUtility.logInfo("---> selectTransactionName <---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(labelToSelect)) {
				webActions.selectDropDownByText(labelToSelect, value);
				LogUtility.logInfo("---> selectTransactionName <---", "Selected the value " + value);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->selectTransactionName<--", "not Selected the value " + value, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnTransaction: To click on the transaction link
	 * 
	 * @param transactionName
	 * @param confirmationNumber
	 * @return
	 */
	public boolean clickOnTransaction(String transactionName, String confirmationValue) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement confirmationRowElement;
		WebElement transName;
		try {
			if (webActions.isDisplayed(txtPageHeading))
				for (int value = 2; value <= tableAuditSummary.size(); value++) {
					confirmationRowElement = driver.findElement(By.cssSelector(basePath + value + confirmationRow));
					transName = driver.findElement(By.cssSelector(basePath + value + transactionLink));
					if (wolWebUtil.verifyTextContains(confirmationRowElement, confirmationValue))
						if (wolWebUtil.verifyTextContains(transName, transactionName)) {
							webActions.clickElement(transName);
							LogUtility.logInfo("---> clickOnTransaction <---",
									"clicked on the transaction with the confirmation Value: " + confirmationValue);
							return true;
						}
				}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnTransaction<--",
					"not clicked on the transaction with the confirmation Value: " + confirmationValue, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkConfirmationNumber: To check the confirmation number
	 * 
	 * @param confirmationNumber
	 * @return
	 */
	public boolean checkConfirmationNumber(String confirmationNumber) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtConfirmationNumber, confirmationNumber)) {
				LogUtility.logInfo("---> checkConfirmationNumber <---",
						"Confirmation Number " + confirmationNumber + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkConfirmationNumber<--",
					"Confirmation Number " + confirmationNumber + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButton: To click on button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement btnToBeClick = null;
		try {
			switch (btnName) {
			case "Search":
				btnToBeClick = btnSearch;
				break;
			case "Enable":
				btnToBeClick = btnEnable;
				break;
			case "Add Remittance Address":
				btnToBeClick = btnAddRemAddress;
				break;
			case "Add Alias":
				btnToBeClick = btnAddAlias;
				break;
			case "Continue":
				btnToBeClick = btnContinue;
				break;
			case "Activate":
				btnToBeClick = btnActivate;
				break;
			case "Find Payment Details":
				btnToBeClick = btnFindPaymentDetails;
				break;
			case "Submit":
				btnToBeClick = btnSubmitResearch;
				break;
			case "Deactivate":
				btnToBeClick = btnDeactivate;
				break;
			case "Update":
				btnToBeClick = btnUpdatePayment;
				break;
			case "Delete":
				btnToBeClick = btnDeletePayment;
				break;
			default:
				LogUtility.logInfo("---> clickOnButton <---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(btnToBeClick)) {
				webActions.clickElement(btnToBeClick);
				LogUtility.logInfo("---> clickOnButton <---", "Button " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "Button " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForDisplay: To check the label is displayed
	 * 
	 * @param labelName
	 * @return
	 */
	public boolean checkForDisplay(String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement label : txtLabel)
				if (wolWebUtil.verifyTextContains(label, labelName)) {
					LogUtility.logInfo("---> checkForDisplay <---", "Button " + labelName + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->checkForDisplay<--", "Button " + labelName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForUpdateMessage: To check the update message
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkForUpdateMessage(String message) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtUpdateMessage, message)) {
				LogUtility.logInfo("---> checkForUpdateMessage <---", "Message " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForUpdateMessage<--", "Message " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnLabelButton: click on the button with label name
	 * 
	 * @param btnName
	 * @param labelName
	 * @return
	 */
	public boolean clickOnLabelButton(String btnName, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			webActions.clickElement(driver.findElement(By.xpath(String.format(btnPath, labelName))));
			LogUtility.logInfo("---> clickOnButton <---", "Button " + btnName + " is clicked");
			return true;
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "Button " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * getCustomerName: To get the customer name
	 * 
	 * @return
	 */
	public String getCustomerName() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(txtCustomerName)) {
				customerName = webActions.getText(txtCustomerName);
				LogUtility.logInfo("---> getCustomerName <---", "Customer Name " + customerName + " is captured");
				return customerName;
			}
		} catch (Exception e) {
			LogUtility.logException("-->getCustomerName<--", "Customer Name is not captured", e, LoggingLevel.ERROR,
					true);
		}
		return null;
	}

	/**
	 * enterValueInField: To enter the data in the field
	 * 
	 * @param value
	 * @param fieldName
	 * @return
	 */
	public String enterValueInField(String value, String fieldName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		if (value.equalsIgnoreCase("Random"))
			value = wolWebUtil.getRandomString(5);
		WebElement txtField = null;
		try {
			switch (fieldName) {
			case "Display name":
				txtField = inputDisplayName;
				value = "P" + value;
				payeeName = value;
				break;
			case "Alias name":
				txtField = inputAliasName;
				break;
			case "Address1":
				txtField = inputAddress1;
				break;
			case "Address2":
				txtField = inputAddress2;
				break;
			case "City":
				txtField = inputCityName;
				break;
			case "Zip":
				txtField = inputZip;
				break;
			default:
				LogUtility.logInfo("---> enterValueInField <---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(txtField)) {
				webActions.setValue(txtField, value);
				LogUtility.logInfo("---> enterValueInField <---",
						"Value " + value + " is entered at field: " + fieldName);
				return value;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterValueInField<--",
					"Value " + value + " is not entered at field: " + fieldName, e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * getConfirmationNumber: To get the confirmation number of transaction with
	 * params
	 * 
	 * @param payeePaymentStatus
	 * @param payeeResearchStatus
	 * @return
	 */
	public String getPaymentConfirmationNumber(String payeePaymentStatus, String payeeResearchStatus) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (int payee = 1; payee <= listTableRows.size(); payee++)
				if (wolWebUtil.verifyTextContains(driver.findElement(By.cssSelector(payeePath + payee + paymentStatus)),
						payeePaymentStatus)) {
					webActions.clickElement(driver.findElement(By.cssSelector(payeePath + payee + datePath)));
					waits.waitForDOMready();
					waits.waitForPageReadyState();
					// TODO: To load the next it is taking time
					waits.staticWait(5);
					if (txtResearchHeading.size() == 0) {
						paymentConfirmationNumber = webActions.getText(txtConfirmationNumberPaymentHistory);
						LogUtility.logInfo("---> getPaymentConfirmationNumber <---",
								"Confirmation Number " + paymentConfirmationNumber + " is captured");
						return paymentConfirmationNumber;
					} else
						driver.navigate().back();
				}
		} catch (Exception e) {
			LogUtility.logException("-->getPaymentConfirmationNumber<--", "Confirmation Number is not captured", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * enterPaymentConfirmationNumber: To enter the confirmation number
	 * 
	 * @return
	 */
	public String enterPaymentConfirmationNumber() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(inputConfirmNumber)) {
				webActions.setValue(inputConfirmNumber, paymentConfirmationNumber);
				LogUtility.logInfo("---> enterPaymentConfirmationNumber <---",
						"Confirmation Number " + paymentConfirmationNumber + " is enterd");
				return paymentConfirmationNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterPaymentConfirmationNumber<--", "Confirmation Number is not entered", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * enterPaymentDueDate; To enter the payment due date
	 * 
	 * @return
	 */
	public boolean enterPaymentDueDate() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		String date = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 0);
		try {
			if (webActions.isDisplayed(inputPaymentDueDate)) {
				webActions.setValue(inputPaymentDueDate, date);
				LogUtility.logInfo("---> enterPaymentDueDate <---", "Payment due date " + date + " is enterd");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterPaymentDueDate<--", "Payment due date " + date + " is not enterd", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public boolean selectReasonResearch() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(btnReason)) {
				webActions.clickElement(btnReason);
				LogUtility.logInfo("---> selectReasonResearch <---", "Reason is selected");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->selectReasonResearch<--", "Reason is not selected", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * getResearchConfirmationNumber: To capture the Research confirmaiton number
	 * 
	 * @return
	 */
	public String getResearchConfirmationNumber() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(txtResearchConfirmation)) {
				researchConfirmationNumber = webActions.getText(txtResearchConfirmation);
				LogUtility.logInfo("---> getResearchConfirmationNumber <---",
						"Research Confirmation Number: " + researchConfirmationNumber + " is captured");
				return researchConfirmationNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("-->getResearchConfirmationNumber<--",
					"Research confirmation number is not captured", e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	public boolean verifyResearchConfirmationNumber(String payeePaymentStatus, String payeeResearchStatus,
			String confirmationNumber) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (int payee = 1; payee <= listTableRows.size(); payee++)
				if (wolWebUtil.verifyTextContains(driver.findElement(By.cssSelector(payeePath + payee + paymentStatus)),
						payeePaymentStatus)) {
					webActions.clickElement(driver.findElement(By.cssSelector(payeePath + payee + datePath)));
					waits.waitForDOMready();
					waits.waitForPageReadyState();
					// TODO: To load the next it is taking time
					waits.staticWait(5);
					if (txtResearchHeading.size() > 0)
						if (wolWebUtil.verifyTextContains(txtResearchConfirmationNumber, researchConfirmationNumber)) {
							LogUtility.logInfo("---> verifyResearchConfirmationNumber <---",
									"Confirmation Number " + researchConfirmationNumber + " is displayed");
							return true;
						} else
							driver.navigate().back();
					else
						driver.navigate().back();
				}
		} catch (Exception e) {
			LogUtility.logException("-->verifyResearchConfirmationNumber<--", "Confirmation Number is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public String enterDisplayName(String value) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (value.equalsIgnoreCase("Random"))
				payeeName = "P" + wolWebUtil.getRandomString(5);
			if (webActions.isDisplayed(inputDisplayName)) {
				webActions.setValue(inputDisplayName, payeeName);
				LogUtility.logInfo("---> enterDisplayName <---", "Value " + value + " is entered at display name");
				return payeeName;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterDisplayName<--", "Value " + value + " is not entered at display name", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * clickOnPendingTransDate: To click on the pending payment delivery date link
	 * 
	 * @return
	 */
	public boolean clickOnPendingTransDate() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(linkDeliveryDatePendingPayment)) {
				webActions.clickElement(linkDeliveryDatePendingPayment);
				LogUtility.logInfo("---> clickOnPendingTransDate <---",
						"Clicked on delivery date link of pending payment");
				return true;
			} else
				LogUtility.logError("---> clickOnPendingTransDate <---", "Pending payments are not available");
		} catch (Exception e) {
			LogUtility.logException("-->clickOnPendingTransDate<--",
					"not clicked on delivery date link of pending payment", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * captureConfirmationNumber: To capture the confirmation number
	 * 
	 * @return
	 */
	public String captureConfirmationNumber() {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (webActions.isDisplayed(txtPaymentConfirmationNumber)) {
				confirmationNumber = webActions.getText(txtPaymentConfirmationNumber);
				LogUtility.logInfo("-->captureConfirmationNumber<--",
						"Confirmation Number : " + confirmationNumber + " is displayed");
				return confirmationNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("->captureConfirmationNumber<--",
					"Confirmation Number : " + confirmationNumber + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * updateDateAndAmount: To Update the Date and Amount
	 * 
	 * @return
	 */
	public List<String> updateDateAndAmount() {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		List<String> updatedValues = new ArrayList<String>();
		String txtAmount = wolWebUtil.getRandomNumber(2);
		String txtDeliveryDateToday = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 7);
		try {
			if (webActions.isDisplayed(inputAmount)) {
				webActions.setValue(inputAmount, txtAmount);
				updatedValues.add(txtAmount);
				webActions.setValue(txtDeliveryDate, txtDeliveryDateToday);
				updatedValues.add(txtDeliveryDateToday);
				LogUtility.logInfo("-->updateDateAndAmount<--",
						"Amount : " + txtAmount + " is entered and date: " + txtDeliveryDateToday + " is entered");
				return updatedValues;
			}
		} catch (Exception e) {
			LogUtility.logException("->updateDateAndAmount<--", "Either amount : " + txtAmount
					+ " is not entered or date: " + txtDeliveryDateToday + " is not entered", e, LoggingLevel.ERROR,
					true);
		}
		return null;
	}

	/**
	 * getUpdatedConfirmationNumber; To get the updated confirmation numer
	 * 
	 * @param transactionName
	 * @return
	 */
	public String getUpdatedConfirmationNumber(String transactionName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (webActions.isDisplayed(txtUpdatedPaymentConfirmation)) {
				confirmationNumber = webActions.getText(txtUpdatedPaymentConfirmation);
				LogUtility.logInfo("-->getUpdatedConfirmationNumber<--",
						"Confirmation Number : " + confirmationNumber + " is captured");
				return confirmationNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("->getUpdatedConfirmationNumber<--",
					"Confirmation Number : " + confirmationNumber + " is not captured", e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * getOrderTimestamp: To get the order timestamp
	 * 
	 * @return
	 */
	public String getOrderTimestamp() {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (webActions.isDisplayed(txtOrderTimestamp)) {
				orderTimestamp = webActions.getText(txtOrderTimestamp);
				LogUtility.logInfo("-->getOrderTimestamp<--",
						"Order Creation Timestamp: " + orderTimestamp + " is captured ");
				return orderTimestamp.substring(0, 16);
			}
		} catch (Exception e) {
			LogUtility.logException("->getOrderTimestamp<--", "Order Creation Timestamp is not captured", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * clickOnTransactionWithTime: To click on the transaction with timestamp
	 * 
	 * @param transactionName
	 * @param timeStamp
	 * @return
	 */
	public boolean clickOnTransactionWithTime(String transactionName, String timeStamp) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement confirmationRowElement;
		WebElement transName;
		try {
			if (webActions.isDisplayed(txtPageHeading))
				for (int value = 2; value <= tableAuditSummary.size(); value++) {
					confirmationRowElement = driver.findElement(By.cssSelector(basePath + value + timeStampRow));
					transName = driver.findElement(By.cssSelector(basePath + value + transactionLink));
					if (wolWebUtil.verifyTextContains(confirmationRowElement, timeStamp))
						if (wolWebUtil.verifyTextContains(transName, transactionName)) {
							webActions.clickElement(transName);
							LogUtility.logInfo("---> clickOnTransactionWithTime <---",
									"clicked on the transaction with the Timestamp: " + timeStamp);
							return true;
						}
				}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnTransactionWithTime<--",
					"not clicked on the transaction with the Timestamp: " + timeStamp, e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnDeleteButton: To click on the delete icon of pending payment
	 * 
	 * @return
	 */
	public boolean clickOnDeleteButton() {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (listPendingPayments.size() > 0) {
				webActions.clickElement(listPendingPayments.get(0));
				LogUtility.logInfo("-->clickOnDeleteButton<--", "Delete icon of pending payments is clicked");
				return true;
			} else {
				LogUtility.logError("-->clickOnDeleteButton<--", "Delete icon of pending payments is not displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnDeleteButton<--", "Delete icon of pending payments is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public boolean clickOnEditOfActiveAccount(String accountStatus) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement confirmationRowElement;
		try {
			for (int row = 1; row < listManagePayeeRows.size(); row++) {
				confirmationRowElement = driver
						.findElement(By.cssSelector(managePayeeBasePath + row + managePayeeActiveStatus));
				if (wolWebUtil.verifyTextContains(confirmationRowElement, accountStatus)) {
					webActions.clickElement(
							driver.findElement(By.cssSelector(managePayeeBasePath + row + managePayeeActiveEdit)));
					LogUtility.logInfo("---> clickOnEditOfActiveAccount <---",
							"clicked on edit icon of the Active status account");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnEditOfActiveAccount<--", "Not click on active status account edit icon",
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	public String updateAccountNickname() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			String nickname = wolWebUtil.getRandomString(8);
			if (webActions.isDisplayed(txtAccountNickname)) {
				webActions.setValue(txtAccountNickname, nickname);

				LogUtility.logInfo("---> updateAccountNickname <---", "Nickname " + nickname + " is captured");
				return nickname;
			}
		} catch (Exception e) {
			LogUtility.logException("-->updateAccountNickname<--", "Account Nickname is not captured", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * getAccountNumber: To get the Account number
	 * 
	 * @return boolean
	 */
	public String getAccountNumber() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(txtPayeeAcctnum)) {
				accountNumber = webActions.getAttributeValue(txtPayeeAcctnum, "value");
				LogUtility.logInfo("---> getAccountNumber <---", "Account Number " + accountNumber + " is captured");
				return accountNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("-->getAccountNumber<--", "Account Nickname is not captured", e, LoggingLevel.ERROR,
					true);
		}
		return null;
	}

	/**
	 * selectOneYearBackFromDate: To select the previous years date
	 * 
	 * @return
	 */
	public String selectOneYearBackFromDate() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(txtFromDate)) {
				fromDate = wolWebUtil.getOldDate("365");
				webActions.setValue(txtFromDate, fromDate);
				LogUtility.logInfo("---> selectOneYearBackFromDate <---", "From Date  " + fromDate + " is entered");
				return fromDate;
			}
		} catch (Exception e) {
			LogUtility.logException("-->selectOneYearBackFromDate<--", "Valid From date is not entered", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * getNonWebsterAccount: To get the non webster account
	 * 
	 * @return
	 */
	public String getNonWebsterAccount() {
		waits.waitForDOMready();
		try {
			nonWebsterAccount = driver.findElement(By.xpath(activeAccountPath));
			if (webActions.isDisplayed(nonWebsterAccount)) {
				activeNonWebsterAccount = webActions.getText(nonWebsterAccount);
				LogUtility.logInfo("---> getNonWebsterAccount <---",
						"Active Non Webster Account  " + activeNonWebsterAccount + " is captured");
				return activeNonWebsterAccount;
			}
		} catch (Exception e) {
			LogUtility.logException("-->getNonWebsterAccount<--", "Active Non Webster Account is not captured", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}
}
