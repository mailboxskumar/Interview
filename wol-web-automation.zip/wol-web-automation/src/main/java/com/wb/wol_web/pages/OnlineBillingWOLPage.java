package com.wb.wol_web.pages;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * @author rpagadala-adm
 *
 */
public class OnlineBillingWOLPage extends ObjectBase {

	public OnlineBillingWOLPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "overviewSection__section-title")
	protected WebElement txtOverviewSection;

	@FindBy(id = "interestSection__section-title")
	protected WebElement txtInterestSection;

	@FindBy(id = "paymentSection__section-title")
	protected WebElement txtPaymentSection;

	@FindBy(css = "#overviewSection__section-title ~ div>div>label")
	protected List<WebElement> listLabelAccountOverview;

	@FindBy(css = "#interestSection__section-title ~ div>div>label")
	protected List<WebElement> listLabelInterest;

	@FindBy(css = "#paymentSection__section-title ~ div>div>label")
	protected List<WebElement> listLabelPaymentInfo;

	@FindBy(css = "#statementForm > div:nth-child(1) label")
	protected WebElement txtWebsterAccount;

	@FindBy(css = "#statementForm > div:nth-child(1) label + select")
	protected WebElement listWebsterAccount;

	@FindBy(css = "#statementForm > div:nth-child(1) label")
	protected WebElement txtStatementPeriod;

	@FindBy(css = "#statementForm > div:nth-child(2) label + select")
	protected WebElement listStatementPeriod;

	@FindBy(id = "cancel")
	protected WebElement btnCancel;

	@FindBy(name = "continue")
	protected WebElement btnViewStatement;

	@FindBy(css = "#customerService + h2>span[class='accountNumber']")
	protected WebElement txtStatementSubHeadingAccount;

	@FindBy(css = "h2>span.accountNumber")
	protected WebElement txtAccountNumberStatement;

	@FindBy(css = "#pageContent > ul.accordion.js-accordion > li.accordion__item.is-open > a")
	protected WebElement linkDefaultAccountClose;

	@FindBy(css = "#pageContent>ul li>a.accordion__item__header")
	protected List<WebElement> listAccounts;

	@FindBy(css = "#pageContent > ul.accordion.js-accordion > li.accordion__item.is-open  div.checkmark")
	protected WebElement txtEnrolledEdeliveryMessage;

	@FindBy(css = "#pageContent  li.accordion__item.is-open input[name='nickname']")
	protected WebElement inputNickname;

	@FindBy(css = "#pageContent  li.accordion__item.is-open input[name='continue']")
	protected WebElement btnContinue;

	@FindBy(css = "#pageContent  li.accordion__item.is-open ul.nextsteps li:nth-child(1)>a")
	protected WebElement linkOpenAccuntRemove;

	@FindBy(css = "div.errorIndicator")
	protected WebElement txtTopErrorMessage;

	@FindBy(css = "#pageContent  li.accordion__item.is-open ul.nextsteps li>a")
	protected List<WebElement> listLinksNextSteps;

	@FindBy(id = "accountNav__list")
	protected WebElement lstSelectAccList;

	public WebElement linkRemoveAccount = null;

	/**
	 * checkForSubHeading: To check subHeading is displaying or not
	 * 
	 * @param subheadingName
	 * @return
	 */
	public boolean checkForSubHeading(String subheadingName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement txtSubHeading = null;
		try {
			switch (subheadingName) {
			case "Account Overview":
				txtSubHeading = txtOverviewSection;
				break;
			case "Interest":
				txtSubHeading = txtInterestSection;
				break;
			case "Payment Information":
				txtSubHeading = txtPaymentSection;
				break;
			default:
				LogUtility.logInfo("-->checkForSubHeading<--", "No case is matched");
				break;
			}
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			if (wolWebUtil.verifyTextContains(txtSubHeading, subheadingName)) {
				LogUtility.logInfo("-->checkForSubHeading<--", "SubHeading: " + subheadingName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForErrorMessage<--", "SubHeading: " + subheadingName + " is not displayed",
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkLabelTitles : To check the label Titles of given sub-heading
	 * 
	 * @param subHeadingName
	 * @param listLabels
	 * @return
	 */
	public int checkLabelTitles(String subHeadingName, List<String> listLabels) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		int count = 0;
		List<WebElement> listLabelsToCheck = null;
		try {
			switch (subHeadingName) {
			case "Account Overview":
				listLabelsToCheck = listLabelAccountOverview;
				break;
			case "Interest":
				listLabelsToCheck = listLabelInterest;
				break;
			case "Payment Information":
				listLabelsToCheck = listLabelPaymentInfo;
				break;
			default:
				LogUtility.logInfo("----->checkLabelTitles<----", "No case is matched");
				break;
			}
			for (WebElement label : listLabelsToCheck) {
				if (wolWebUtil.verifyTextContains(label, listLabels.toString())) {
					LogUtility.logInfo("----->checkLabelTitles<----", label + " is present");
					count++;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkLabelTitles<--", "Some of the elements are not present ", e,
					LoggingLevel.ERROR, true);
		}
		return count;
	}

	/**
	 * checkForLabel: To verify the labels are displayed or not
	 * 
	 * @param labelName
	 * @return
	 */
	public boolean checkForLabel(String labelName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement label = null;
		WebElement dropdown = null;
		try {
			switch (labelName) {
			case "Webster Account":
				label = txtWebsterAccount;
				dropdown = listWebsterAccount;
				break;
			case "Statement Period":
				label = txtStatementPeriod;
				dropdown = listStatementPeriod;
				break;
			default:
				LogUtility.logInfo("----->checkForLabel<----", "No case is matched");
				break;
			}
			if (webActions.isDisplayed(label) && webActions.isDisplayed(dropdown)) {
				LogUtility.logInfo("----->checkForLabel<----", label + " is present along with dropdown");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForLabel<--", label + " is not present along with dropdown", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForButton: To check the for the buttons are displayed or not
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean checkForButton(String btnName) {
		waits.waitForPageReadyState();
		WebElement btnElement = null;
		try {
			switch (btnName) {
			case "Cancel":
				btnElement = btnCancel;
				break;
			case "View Statement":
				btnElement = btnViewStatement;
				break;
			default:
				LogUtility.logInfo("----->checkForButton<----", "No case is matched");
				break;
			}
			if (webActions.isDisplayed(btnElement)) {
				LogUtility.logInfo("----->checkForButton<----", btnName + " button is present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForButton<--", btnName + " button is not present", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForDefaultStatement : To check the default statement is displayed or not
	 * 
	 * @param txtHeading
	 * @return
	 */
	public boolean checkForDefaultStatement(String txtHeading) {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtStatementSubHeadingAccount, txtHeading)) {
				LogUtility.logInfo("----->checkForDefaultStatement<----", txtHeading + " Sub-Heading is present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForDefaultStatement<--", txtHeading + " Sub-Heading is not present", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForAccountsStatement: To check the statement of all required accounts
	 * 
	 * @param listAccounts
	 * @return
	 */
	public int checkForAccountsStatement(List<String> listAccounts) {
		waits.waitForPageReadyState();
		int accountsCount = 0;
		try {
			for (String account : listAccounts) {
				wolWebUtil.selectValueByPartialVisibleText(listWebsterAccount, account);
				webActions.clickElement(btnViewStatement);
				waits.waitForPageReadyState();
				waits.waitForDOMready();
				// TODO: Take time to load the next page
				waits.staticWait(5);
				if (wolWebUtil.verifyTextContains(txtAccountNumberStatement, account)) {
					LogUtility.logInfo("-->checkForAccountsStatement<--",
							"Accout: " + account + " statement is displayed");
					accountsCount++;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForAccountsStatement<--",
					"One of Accout: " + listAccounts.toString() + " statement is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return accountsCount;
	}

	/**
	 * checkForAccountsNotPresent: To check accounts are not present in dropdown
	 * 
	 * @param listAccounts
	 * @return
	 */
	public int checkForAccountsNotPresent(List<String> listAccounts) {
		waits.waitForPageReadyState();
		int accountsCount = 0;
		try {
			for (String account : listAccounts) {
				if (!wolWebUtil.verifyListValues(listWebsterAccount, account)) {
					LogUtility.logInfo("-->checkForAccountsNotPresent<--",
							"Accout: " + account + " is not present in dropdown");
					accountsCount++;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForAccountsNotPresent<--",
					"One of Accout: " + listAccounts.toString() + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return accountsCount;
	}

	/**
	 * closeDefaultOpenAccount: To close the default opened account
	 * 
	 * @return
	 */
	public boolean closeDefaultOpenAccount() {
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(linkDefaultAccountClose)) {
				webActions.clickElement(linkDefaultAccountClose);
				LogUtility.logInfo("-->closeDefaultOpenAccount<--", "Closed the default open account");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->closeDefaultOpenAccount<--", "not closed the default open account", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnAccountNumber: To click on the accountNumber
	 * 
	 * @param accountNumber
	 * @return
	 */
	public boolean clickOnAccountNumber(String accountNumber) {
		waits.waitForPageReadyState();
		try {
			for (WebElement linkAccount : listAccounts)
				if (wolWebUtil.verifyTextContains(linkAccount, accountNumber)) {
					webActions.clickElement(linkAccount);
					LogUtility.logInfo("-->clickOnAccountNumber<--", "Clicked on Account Number: " + accountNumber);
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnAccountNumber<--", "Not clicked on Account Number: " + accountNumber, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkEDeliveryMessage: To check the enrolled eDelivery message is present
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkEDeliveryMessage(String message) {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtEnrolledEdeliveryMessage, message)) {
				LogUtility.logInfo("-->checkEDeliveryMessage<--", "Message: " + message + " is displayed ");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkEDeliveryMessage<--", "Message: " + message + " is not displayed ", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkNicknameContinueButton: To check nickname input box and continue button
	 * are present
	 * 
	 * @return
	 */
	public boolean checkNicknameContinueButton() {
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(inputNickname) && webActions.isDisplayed(btnContinue)) {
				LogUtility.logInfo("-->checkNicknameContinueButton<--",
						"Nickname box and continue button are displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkNicknameContinueButton<--",
					"Nickname box and continue button are not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnLink: To click on the given link
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickOnLink(String linkName) {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(linkOpenAccuntRemove, linkName)) {
				webActions.clickElement(linkOpenAccuntRemove);
				LogUtility.logInfo("-->clickOnLink<--", "Link: " + linkName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnLink<--", "Link: " + linkName + " is not clicked", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkErrorMessage: To check for the error message
	 * 
	 * @param txtErrorMessage
	 * @return
	 */
	public boolean checkErrorMessage(String txtErrorMessage) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (waits.waitUntilElementIsPresent(txtTopErrorMessage))
				if (wolWebUtil.verifyTextContains(txtTopErrorMessage, txtErrorMessage)) {
					LogUtility.logInfo("-->checkErrorMessage<--", "Message: " + txtErrorMessage + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->checkErrorMessage<--", "Message: " + txtErrorMessage + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectAccFromDropdown: To select the account from dropdown
	 * 
	 * @param account
	 * @return
	 */
	public boolean selectAccFromDropdown(String account) {
		boolean flag = false;
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			boolean selectAccount = webActions.isDisplayed(lstSelectAccList);
			if (selectAccount) {
				wolWebUtil.selectLinkFromList(lstSelectAccList, account);
				waits.waitForPageReadyState();
				waits.waitForDOMready();
				LogUtility.logInfo("---> Seelct Account From Dropdown <---", "Account Selected");
				flag = true;
				// TODO After select the account, fields are taking time to load
				waits.staticWait(3);
			}
		} catch (Exception e) {
			LogUtility.logException("selectAccFromDropdown", "Unable to select the Account", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}
}
