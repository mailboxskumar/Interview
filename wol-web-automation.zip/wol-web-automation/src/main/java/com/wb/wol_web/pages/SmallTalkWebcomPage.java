
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class SmallTalkWebcomPage extends ObjectBase {

	public SmallTalkWebcomPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "messageName")
	protected WebElement inputMessageName;

	@FindBy(name = "messageDescription")
	protected WebElement inputMessageDesc;

	@FindBy(name = "smtkHeading")
	protected WebElement inputMessageHeader;

	@FindBy(css = "html[dir='ltr']>body.cke_body.cke_editable.cke_editable_themed.cke_contents_ltr")
	protected WebElement inputMessageBody;

	@FindBy(id = "displayStatus1")
	protected WebElement radioBtnDisplayStatus;

	@FindBy(name = "messagePriorityRanking")
	protected WebElement inputPriorityRank;

	@FindBy(id = "channelTypeRadio3")
	protected WebElement radioBtnBothChannelType;

	@FindBy(id = "channelTypeRadio1")
	protected WebElement radioBtnPersonalChannelType;

	@FindBy(id = "channelTypeRadio2")
	protected WebElement radioBtnBusinessChannelType;

	@FindBy(id = "accountTypeButton")
	protected WebElement btnSelectAccountType;

	@FindBy(css = "#appl-code-tabs>button")
	protected List<WebElement> listApplicationCodes;

	@FindBy(id = "account-type-excludedList")
	protected WebElement listAccountsExclude;

	@FindBy(id = "account-type-includedList")
	protected WebElement listAccountsInclude;

	@FindBy(css = "#account-type-myButtons>a:nth-child(1)")
	protected WebElement btnAccountTypeCancel;

	@FindBy(css = "#account-type-myButtons>a:nth-child(2)")
	protected WebElement btnAccountTypeContinue;

	@FindBy(css = "#location-myButtons>a:nth-child(2)")
	protected WebElement btnLocationContinue;

	@FindBy(css = "#location-myButtons>a:nth-child(1)")
	protected WebElement btnLocationCancel;

	@FindBy(css = "[aria-label='Close the dialog']")
	protected WebElement btnClose;

	@FindBy(id = "submit")
	protected WebElement btnCreate;

	@FindBy(id = "account-type-right")
	protected WebElement btnMoveRight;

	@FindBy(id = "account-type-allRight")
	protected WebElement btnMoveAllRight;

	@FindBy(id = "location-right")
	protected WebElement btnLocationMoveRight;

	@FindBy(id = "location-allRight")
	protected WebElement btnLocationMoveAllRight;

	@FindBy(xpath = "//div[@id='account-type-excludedList']//button[@class='two-list-option is-unselected']")
	protected List<WebElement> listAppCodeAccounts;

	@FindBy(xpath = "//div[@id='location-excludedList']//button[@class='two-list-option is-unselected']")
	protected List<WebElement> listStateCities;

	@FindBy(id = "locationButton")
	protected WebElement btnSelectLocation;

	@FindBy(id = "location-chooser-wrap")
	protected WebElement txtPopupLocationPicker;

	@FindBy(css = ".js-accountTypeList.resultsDiv>ul>li")
	protected List<WebElement> listWebElementAccountsSelected;

	@FindBy(css = ".js-locationList.resultsDiv>ul>li")
	protected List<WebElement> listWebElementCitiesSelected;

	@FindBy(css = "#location-tabs>button")
	protected List<WebElement> listStateNames;

	@FindBy(name = "start_m")
	protected WebElement inputStartDateMonth;

	@FindBy(name = "start_d")
	protected WebElement inputStartDateDay;

	@FindBy(name = "start_y")
	protected WebElement inputStartDateYear;

	@FindBy(name = "end_m")
	protected WebElement inputEndDateMonth;

	@FindBy(name = "end_d")
	protected WebElement inputEndDateDay;

	@FindBy(name = "end_y")
	protected WebElement inputEndDateYear;

	@FindBy(css = ".message>p")
	protected WebElement txtSmallTalkUpdateMessage;

	@FindBy(css = "#message tr")
	protected List<WebElement> listSmallTalkMessages;

	@FindBy(name = "start_hr")
	protected WebElement inputStartDateTime;

	@FindBy(name = "end_hr")
	protected WebElement inputEndDateTime;

	@FindBy(css = "[title='Placeholder']")
	protected WebElement btnPlaceholder;

	@FindBy(className = "cke_dialog_title")
	protected WebElement txtPopupPlaceholderProp;

	@FindBy(css = "[title='OK']")
	protected WebElement btnPlaceholderOK;

	@FindBy(css = "[title='Cancel']")
	protected WebElement btnPlaceholderCancel;

	@FindBy(css = "#cke_40_select option")
	protected List<WebElement> listPlaceholder;

	@FindBy(css = "#cke_40_select")
	protected WebElement txtPlaceholder;

	@FindBy(css = "#lightboxContent0 .tabs button")
	protected List<WebElement> listStateButtons;

	@FindBy(css = "#lightboxContent0 p")
	protected List<WebElement> listHeaderLabels;

	@FindBy(css = "#lightboxContent0 #location-moveButtons button")
	protected List<WebElement> listMoveButtons;

	@FindBy(css = "#lightboxContent0 #location-filter label")
	protected List<WebElement> listLocationFiler;

	@FindBy(css = "th.sortable>a")
	protected List<WebElement> listSmallTalkMessageLabels;

	@FindBy(css = "[name='defaultform'] a")
	protected List<WebElement> listAddNewMessageLinks;

	@FindBy(css = "#message th>a")
	protected List<WebElement> listScheduledMessageLabels;

	@FindBy(css = "[for='messageName'] + img.tooltip.formHelpIcon")
	protected WebElement btnMessageNameTooltip;

	@FindBy(css = "[for='messageDescription'] img.tooltip.formHelpIcon")
	protected WebElement btnMessageDescTooltip;

	@FindBy(css = "[for='displayStatus'] +img.tooltip.formHelpIcon")
	protected WebElement btnDisplayStatusTooltip;

	@FindBy(css = "[for='messagePriorityRanking'] +img.tooltip.formHelpIcon")
	protected WebElement btnPriorityRankingTooltip;

	@FindBy(css = "[for='accountTypeField'] +img.tooltip.formHelpIcon")
	protected WebElement btnAccountTypeTooltip;

	@FindBy(css = "[for='']+ img.tooltip.formHelpIcon")
	protected WebElement btnLocationTooltip;

	@FindBy(css = ".message--error div>p")
	protected List<WebElement> listErrorMessage;

	@FindBy(id = "reset")
	protected WebElement btnReset;

	@FindBy(xpath = "//a[contains(@href, '/servlets/ds?action=df_webcom.smtk-SMTKMsgSetup&d')]")
	protected WebElement linkHere;

	public String basePath = "";
	public List<String> listSelectedAccounts = new ArrayList<String>();
	public List<String> listSelectedCities = new ArrayList<String>();
	public String todaysDate = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 0);
	public String FutureDate = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 6);
	public String txtMessageName = "";
	public String smallTalkMessageBasePath = "#message tr:nth-child(";
	public String smallTalkMessageName = ")>td:nth-child(1)";
	public String smallTalkMessageBatchStatus = ")>td:nth-child(2)";
	public String smallTalkMessageViewLink = ")>td:nth-child(11)>a";
	public String smallTalkMessageEditLink = ")>td:nth-child(12)>a";
	public String smallTalkMessagePreviewLink = ")>td:nth-child(13)>a";
	public List<String> listStartDateDetails = new ArrayList<String>();
	public List<String> listEndDateDetails = new ArrayList<String>();
	public List<String> listValues = new ArrayList<String>();
	public String invalidDate = "sd/40/2020";
	public WebElement linkView = null;
	public WebElement linkEdit = null;
	public WebElement linkPreview = null;
	public WebElement messageName = null;
	public WebElement batchstatus = null;
	public WebElement linkNext = null;

	/**
	 * enterRandomDataInField: To enter the random data in the given fieldName
	 * 
	 * @param fieldName
	 * @return
	 */
	public String enterRandomDataInField(String fieldName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement fieldToEnter = null;
		try {
			String value = wolWebUtil.getRandomString(10);
			switch (fieldName) {
			case "Message name":
				fieldToEnter = inputMessageName;
				txtMessageName = value;
				break;
			case "Message description":
				fieldToEnter = inputMessageDesc;
				break;
			case "Small Talk Message header":
				fieldToEnter = inputMessageHeader;
				break;
			case "Message body":
				fieldToEnter = inputMessageBody;
				break;

			case "Priority ranking":
				fieldToEnter = inputPriorityRank;
				value = wolWebUtil.getRandomNumber(2);
				break;
			default:
				LogUtility.logInfo("-->enterRandomDataInField<--", "No Matching case found");
				break;
			}
			if (webActions.isDisplayed(fieldToEnter)) {
				webActions.setValue(fieldToEnter, value);
				LogUtility.logInfo("-->enterRandomDataInField<--",
						"Data: " + value + " is entered at field: " + fieldName);
				return value;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterRandomDataInField<--", "Valid data is not entered at field: " + fieldName,
					e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * verifyDefaultValue: To verify the labels are checked by default
	 * 
	 * @param fieldName
	 * @param value
	 * @return
	 */
	public boolean verifyDefaultValue(String fieldName, String txtValue) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement fieldToCheck = null;
		String labelName = "";
		try {
			switch (fieldName) {
			case "WOL Display status":
				fieldToCheck = radioBtnDisplayStatus;
				break;
			case "Channel type":
				fieldToCheck = radioBtnBothChannelType;
				break;
			default:
				LogUtility.logInfo("-->verifyDefaultValue<--", "No case match found");
				break;
			}
			if (webActions.getAttributeValue(fieldToCheck, "checked").equalsIgnoreCase("true")) {
				labelName = webActions.getAttributeValue(fieldToCheck, "value");
				if (labelName.equalsIgnoreCase(txtValue)) {
					LogUtility.logInfo("-->verifyDefaultValue<--", "Label: " + txtValue + " is checked by default");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyDefaultValue<--",
					"Label: " + txtValue + " is not displayed or not checked by default", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectValueInField: To select the value in selected fieldName
	 * 
	 * @param value
	 * @param fieldName
	 * @return
	 */
	public boolean selectValueInField(String value, String fieldName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement fieldToCheck = null;
		try {
			switch (value) {
			case "Personal":
				fieldToCheck = radioBtnPersonalChannelType;
				break;
			case "Business":
				fieldToCheck = radioBtnBusinessChannelType;
				break;
			case "Both":
				fieldToCheck = radioBtnBothChannelType;
				break;
			default:
				LogUtility.logInfo("-->selectValueInField<--", "No Matching case found");
				break;
			}
			if (webActions.isDisplayed(fieldToCheck)) {
				webActions.clickElement(fieldToCheck);
				LogUtility.logInfo("-->selectValueInField<--",
						"Value: " + value + " is selected for the field " + fieldName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->selectValueInField<--",
					"Value: " + value + " is not selected for the field " + fieldName, e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButton: To click on the button
	 * 
	 * @param btnName
	 * @param pageName
	 * @return
	 */
	public boolean clickOnButton(String btnName, String pageName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement btnToClick = null;
		try {
			switch (btnName) {
			case "Select Account Type":
				btnToClick = btnSelectAccountType;
				break;
			case "Continue":
				btnToClick = btnAccountTypeContinue;
				break;
			case "Create":
				btnToClick = btnCreate;
				break;
			case "Here":
				btnToClick = linkHere;
				break;
			case "Location Continue":
				btnToClick = btnLocationContinue;
				break;
			case "Select Location":
				btnToClick = btnSelectLocation;
				break;
			case "Placeholder":
				btnToClick = btnPlaceholder;
				break;
			case "Cancel":
				btnToClick = btnLocationCancel;
				break;
			case "OK":
				btnToClick = btnPlaceholderOK;
				break;
			case "Close":
				btnToClick = btnClose;
				break;
			case "Reset":
				btnToClick = btnReset;
				break;
			default:
				LogUtility.logInfo("-->clickOnButton<--", "No Matching case found");
				break;
			}
			if (webActions.isDisplayed(btnToClick)) {
				webActions.clickElement(btnToClick);
				LogUtility.logInfo("-->clickOnButton<--", "Button: " + btnName + " is clicked on the page " + pageName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButton<--",
					"Button: " + btnName + " is not clicked on the page " + pageName, e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyApplicationCodeSorted: To verify the List Web-elements are naturally
	 * sorted
	 * 
	 * @return
	 */
	public boolean verifyApplicationCodeSorted() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		// TODO: Taking time to load the pop-up
		waits.staticWait(5);
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyNaturalSortingOfElementsWithText(listApplicationCodes)) {
				LogUtility.logInfo("-->verifyApplicationCodeSorted<--", "Application codes are in sorted order");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyApplicationCodeSorted<--", "Application codes are not in sorted order", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForDisplay: To check the display of element
	 * 
	 * @param elementName
	 * @return
	 */
	public boolean checkForDisplay(String elementName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement elementToCheck = null;
		try {
			switch (elementName) {
			case "Excluded":
				elementToCheck = listAccountsExclude;
				break;
			case "Included":
				elementToCheck = listAccountsInclude;
				break;
			case "Cancel":
				elementToCheck = btnAccountTypeCancel;
				break;
			case "Placeholder":
				elementToCheck = btnPlaceholder;
				break;
			case "Continue":
				elementToCheck = btnAccountTypeContinue;
				break;
			case "OK":
				elementToCheck = btnPlaceholderOK;
				break;
			case "Placeholder Cancel":
				elementToCheck = btnPlaceholderCancel;
				break;
			case "Location Continue":
				elementToCheck = btnLocationContinue;
				break;
			case "Location Cancel":
				elementToCheck = btnLocationCancel;
				break;
			case "Location picker":
				elementToCheck = txtPopupLocationPicker;
				waits.staticWait(5);
				break;
			case "Placeholder Properties":
				elementToCheck = txtPopupPlaceholderProp;
				waits.staticWait(5);
				break;
			default:
				LogUtility.logInfo("-->checkForDisplay<--", "No case match found");
				break;
			}
			if (webActions.isDisplayed(elementToCheck)) {
				LogUtility.logInfo("-->checkForDisplay<--", elementName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForDisplay<--", elementName + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * clickOnApplicationCode: To click on the application code
	 * 
	 * @param applicationCode
	 * @return
	 */
	public boolean clickOnApplicationCode(String applicationCode) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement eleAppCode : listApplicationCodes)
				if (wolWebUtil.verifyText(eleAppCode, applicationCode)) {
					webActions.clickElement(eleAppCode);
					LogUtility.logInfo("-->clickOnApplicationCode<--",
							"Application Code: " + applicationCode + " is clicked");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->clickOnApplicationCode<--",
					"Application Code: " + applicationCode + " is not clicked", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * moveAccountsFromExcludeToInclude: To move the accounts from exclude box to
	 * include box
	 * 
	 * @param numberOfAccounts
	 * @return
	 */
	public boolean moveAccountsFromExcludeToInclude(String numberOfAccounts) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			webActions.clickElement(btnMoveAllRight);
			LogUtility.logInfo("-->moveAccountsFromExcludeToInclude<--",
					numberOfAccounts + " Account(s) is/are moved from Exclude to Include box");
		} catch (Exception e) {
			LogUtility.logException("->moveAccountsFromExcludeToInclude<--",
					numberOfAccounts + " Account(s) is/are not moved from Exclude to Include box", e,
					LoggingLevel.ERROR, true);
			return false;
		}
		return true;
	}

	/**
	 * verifySelectedValues: To verify the selected accounts is displaying
	 * 
	 * @param values
	 * @param labelName
	 * @return
	 */
	public List<String> verifySelectedValues(String values, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		List<WebElement> listWebElementsToCheck = new ArrayList<WebElement>();
		List<String> listValuesToCheck = new ArrayList<String>();
		try {
			switch (values) {
			case "Accounts":
				listWebElementsToCheck = listWebElementAccountsSelected;
				listValuesToCheck = listSelectedAccounts;
				break;
			case "Cities":
				listWebElementsToCheck = listWebElementCitiesSelected;
				listValuesToCheck = listSelectedCities;
				break;
			default:
				LogUtility.logInfo("-->verifySelectedValues<--", "No case match found");
				break;
			}
			for (WebElement webElementToCheck : listWebElementsToCheck) {
				for (String valueToCheck : listValuesToCheck) {
					if (wolWebUtil.verifyTextContains(webElementToCheck, valueToCheck)) {
						LogUtility.logInfo("-->verifySelectedValues<--",
								listValuesToCheck.toString() + " is/are displayed");
					}
				}

			}
		} catch (Exception e) {
			LogUtility.logException("->verifySelectedValues<--", listValuesToCheck.toString() + " is/are not displayed",
					e, LoggingLevel.ERROR, true);
			return null;
		}
		return listValuesToCheck;
	}

	/**
	 * clickOnStateName: To click on the state name
	 * 
	 * @param stateName
	 * @return
	 */
	public boolean clickOnStateName(String stateName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		waits.staticWait(5);
		try {
			for (WebElement eleStateName : listStateNames)
				if (wolWebUtil.verifyText(eleStateName, stateName)) {
					webActions.clickElement(eleStateName);
					LogUtility.logInfo("-->clickOnStateName<--", "State Name: " + stateName + " is clicked");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->clickOnStateName<--", "State Name: " + stateName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterStartDate: To enter the start date
	 * 
	 * @param labelName
	 * @param time
	 * @return
	 */
	public List<String> enterStartDate(String dateToEnter, String time) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (dateToEnter.equalsIgnoreCase("Today"))
				dateToEnter = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 0);
			else if (dateToEnter.equalsIgnoreCase("Future"))
				dateToEnter = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 1);
			else if (dateToEnter.equalsIgnoreCase("Past"))
				dateToEnter = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", -1);
			else if (dateToEnter.equalsIgnoreCase("Invalid"))
				dateToEnter = invalidDate;
			if (time.equalsIgnoreCase("Future"))
				time = wolWebUtil.getTimeStampWithHours(2);
			else if (time.equalsIgnoreCase("Past"))
				time = wolWebUtil.getTimeStampWithHours(-5);

			if (webActions.isDisplayed(inputStartDateDay)) {
				webActions.setValue(inputStartDateMonth, todaysDate.substring(0, 2));
				webActions.setValue(inputStartDateDay, todaysDate.substring(3, 5));
				webActions.setValue(inputStartDateYear, todaysDate.substring(6, 10));
				webActions.selectDropDownByValue(inputStartDateTime, time);

				listStartDateDetails.add(dateToEnter);
				listStartDateDetails.add(time);
				LogUtility.logInfo("-->enterStartDate<--",
						"Date and Time " + listStartDateDetails.toString() + " is entered in start date");
			}
		} catch (Exception e) {
			LogUtility.logException("->enterStartDate<--",
					"Date and Time " + listStartDateDetails.toString() + " is entered in start date", e,
					LoggingLevel.ERROR, true);
			return null;
		}
		return listStartDateDetails;
	}

	/**
	 * enterEndDate: To enter the future date
	 * 
	 * @param date
	 * @param time
	 * @return
	 */
	public List<String> enterEndDate(String dateToEnter, String time) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (dateToEnter.equalsIgnoreCase("Today"))
				dateToEnter = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 0);
			else if (dateToEnter.equalsIgnoreCase("Future"))
				dateToEnter = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 2);
			if (time.equalsIgnoreCase("Future"))
				time = wolWebUtil.getTimeStampWithHours(4);
			else if (time.equalsIgnoreCase("Past"))
				time = wolWebUtil.getTimeStampWithHours(-4);
			if (webActions.isDisplayed(inputEndDateDay)) {
				webActions.setValue(inputEndDateMonth, FutureDate.substring(0, 2));
				webActions.setValue(inputEndDateDay, FutureDate.substring(3, 5));
				webActions.setValue(inputEndDateYear, FutureDate.substring(6, 10));
				webActions.selectDropDownByValue(inputEndDateTime, time);

				listEndDateDetails.add(dateToEnter);
				listEndDateDetails.add(time);
				LogUtility.logInfo("-->enterEndDate<--",
						"Date and Time " + listEndDateDetails.toString() + " is entered in end date");
			}
		} catch (Exception e) {
			LogUtility.logException("->enterEndDate<--",
					"Date and Time " + listEndDateDetails.toString() + " is entered in end date", e, LoggingLevel.ERROR,
					true);
			return null;
		}
		return listEndDateDetails;
	}

	/**
	 * checkSmallTalkUpdateMessage: To check the small Talk update message
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkSmallTalkUpdateMessage(String message) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtSmallTalkUpdateMessage, message)) {
				LogUtility.logInfo("-->checkSmallTalkUpdateMessage<--", "Message: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkSmallTalkUpdateMessage<--", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyBatchStatus: To verify the batch status in webcom table
	 * 
	 * @param batchStatus
	 * @return
	 */
	public String verifyBatchStatus(String batchStatus) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			linkNext = driver.findElement(By.xpath("//a[text()='Next']"));
			while (webActions.isDisplayed(linkNext)) {
				int rowSize = listSmallTalkMessages.size();
				for (int row = 1; row < rowSize; row++) {
					basePath = smallTalkMessageBasePath + row;
					messageName = driver.findElement(By.cssSelector(basePath + smallTalkMessageName));
					if (wolWebUtil.verifyTextContains(messageName, txtMessageName))
						batchstatus = driver.findElement(By.cssSelector(basePath + smallTalkMessageBatchStatus));
					if (wolWebUtil.verifyTextContains(batchstatus, batchStatus)) {
						linkView = driver.findElement(By.cssSelector(basePath + smallTalkMessageViewLink));
						linkEdit = driver.findElement(By.cssSelector(basePath + smallTalkMessageEditLink));
						linkPreview = driver.findElement(By.cssSelector(basePath + smallTalkMessagePreviewLink));
						if (webActions.isDisplayed(linkView) && webActions.isDisplayed(linkEdit)
								&& webActions.isDisplayed(linkPreview)) {
							LogUtility.logInfo("-->verifyBatchStatus<--", "Message Name: " + txtMessageName
									+ " is displayed with Edit,View,Preview links and batch status as: " + batchStatus);
							return txtMessageName;
						}
					}
				}
				webActions.clickElement(linkNext);
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyBatchStatus<--",
					"Message Name: " + txtMessageName + " is not displayed with batch status as: " + batchStatus, e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkPlaceholderDropdown: To check the list of drop-down values
	 * 
	 * @param testDataMap
	 * @return
	 */
	public List<String> checkPlaceholderDropdown(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		String txtPlaceholderName = "";
		try {
			for (WebElement elementPlaceholderValue : listPlaceholder) {
				txtPlaceholderName = webActions.getText(elementPlaceholderValue);
				if (testDataMap.containsValue(txtPlaceholderName)) {
					LogUtility.logInfo("-->checkPlaceholderDropdown<--", txtPlaceholderName + " is displayed");
				} else
					listValues.add(txtPlaceholderName);
			}
		} catch (Exception e) {
			LogUtility.logException("->checkPlaceholderDropdown<--", testDataMap.values() + " is/are not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return listValues;
	}

	/**
	 * selectPlaceholderValue : To select the value from drop-down
	 * 
	 * @param value
	 * @param listName
	 * @return
	 */
	public boolean selectPlaceholderValue(String value, String listName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		String txtPlaceholderName = "";
		try {
			if (webActions.isDisplayed(txtPlaceholder)) {
				webActions.selectDropDownByText(txtPlaceholder, value);
				LogUtility.logInfo("-->checkPlaceholderDropdown<--", value + " is displayed");
				listValues.add(txtPlaceholderName);
			}
		} catch (Exception e) {
			LogUtility.logException("->checkPlaceholderDropdown<--", testDataMap.values() + " is/are not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return true;
	}

	/**
	 * checkForListDisplay: To check the display of list of values
	 * 
	 * @param listName
	 * @param testDataMap
	 * @return
	 */
	public List<String> checkForListDisplay(String listName, Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		String valueToCheck = "";
		List<WebElement> listValuesToCheck = new ArrayList<WebElement>();
		try {
			switch (listName) {
			case "Header labels":
				listValuesToCheck = listHeaderLabels;
				break;
			case "State buttons":
				listValuesToCheck = listStateButtons;
				break;
			case "Move buttons":
				listValuesToCheck = listMoveButtons;
				break;
			case "Filter label":
				listValuesToCheck = listLocationFiler;
				break;
			case "View Small Talk Messages labels":
				listValuesToCheck = listSmallTalkMessageLabels;
				break;
			case "Add New Message links":
				listValuesToCheck = listAddNewMessageLinks;
				break;
			case "Scheduled Message links":
				listValuesToCheck = listScheduledMessageLabels;
				break;
			default:
				LogUtility.logInfo("-->checkForListDisplay<--", "No case match found");
				break;
			}
			for (WebElement elementToCheck : listValuesToCheck) {
				valueToCheck = webActions.getText(elementToCheck);
				if (testDataMap.containsValue(valueToCheck)) {
					LogUtility.logInfo("-->checkForListDisplay<--", valueToCheck + " is displayed");
				} else
					listValues.add(valueToCheck);
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForListDisplay<--", testDataMap.values() + " is/are not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return listValues;
	}

	/**
	 * checkForTooltipMessage: To check the tooltip message
	 * 
	 * @param labelName
	 * @param txtContent
	 * @return
	 */
	public boolean checkForTooltipMessage(String labelName, String txtContent) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement labelToCheck = null;
		try {
			switch (labelName) {
			case "Message name":
				labelToCheck = btnMessageNameTooltip;
				break;
			case "Message description":
				labelToCheck = btnMessageDescTooltip;
				break;
			case "WOL Display status":
				labelToCheck = btnDisplayStatusTooltip;
				break;
			case "Priority ranking":
				labelToCheck = btnPriorityRankingTooltip;
				break;
			case "Account type":
				labelToCheck = btnAccountTypeTooltip;
				break;
			case "Customer location (City) (State)":
				labelToCheck = btnLocationTooltip;
				break;
			default:
				LogUtility.logInfo("-->checkForTooltipMessage<--", "No case match found");
				break;
			}

			if (webActions.getAttributeValue(labelToCheck, "data-title").contains(txtContent)) {
				LogUtility.logInfo("-->checkForTooltipMessage<--", txtContent + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForTooltipMessage<--", txtContent + " is/are not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForErrorMessages: To check one label message
	 * 
	 * @param labelName
	 * @param errorMessage
	 * @return
	 */
	public String checkForErrorMessages(String labelName, String errorMessage) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement eleMessage : listErrorMessage)
				if (wolWebUtil.verifyTextContains(eleMessage, errorMessage)) {
					LogUtility.logInfo("-->checkForErrorMessages<--",
							"Label: " + labelName + " with content: " + errorMessage + " is displayed");
					return errorMessage;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkForErrorMessages<--", errorMessage + " is/are not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkForAllErrorMessages: To check the all the error message
	 * 
	 * @param testDataMap
	 * @return
	 */
	public List<String> checkForAllErrorMessages(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		List<String> listErrorMessages = new ArrayList<String>();
		String errorMessage = "";
		try {
			for (WebElement eleMessage : listErrorMessage) {
				errorMessage = webActions.getText(eleMessage);
				if (testDataMap.containsValue(errorMessage))
					LogUtility.logInfo("-->checkForAllErrorMessages<--",
							"Error Message: " + errorMessage + " is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForAllErrorMessages<--", errorMessage + " is/are not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return listErrorMessages;
	}

	/**
	 * mouseHover: To mouseHover the Priority ranking tool-tip
	 * 
	 * @return boolean
	 */
	public boolean mouseHover() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(btnPriorityRankingTooltip)) {
				wolWebUtil.hoverOnTheElement(btnPriorityRankingTooltip);
				waits.staticWait(5);
				LogUtility.logInfo("-->mouseHover<--", "Mouse Hovered on the priority ranking");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->mouseHover<--", "Not Mouse Hovered on the priority ranking", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnEditLink : To Click on the Edit Link
	 * 
	 * @param batchStatus
	 * @return boolean
	 */
	public boolean clickOnEditLink(String batchStatus) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(linkEdit)) {
				webActions.clickElement(linkEdit);
				LogUtility.logInfo("-->clickOnEditLink<--", "To click on the Edit Link");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnEditLink<--", "Not able to click on the Edit Link", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}
}
