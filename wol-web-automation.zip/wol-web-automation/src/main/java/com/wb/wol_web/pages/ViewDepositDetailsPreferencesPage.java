package com.wb.wol_web.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author Veerababu Pedireddi
 *
 */
public class ViewDepositDetailsPreferencesPage extends ObjectBase {

	public ViewDepositDetailsPreferencesPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "div.midTopHeadingHolder h1")
	protected WebElement titleViewDepositDetailsPage;

	@FindBy(id = "continue_button")
	protected WebElement btnContinueDepositDetailsPage;

	@FindBy(xpath = "//h1[contains(.,'View Deposit Details Preferences Confirmation')]")
	protected WebElement titleDepositDetailsConfPage;

	@FindBy(xpath = "//p[contains(.,'Your View Deposit Details preferences have been updated')]")
	protected WebElement titleDepositDetailsConfMsg;

	@FindBy(xpath = "//div[@id='bodyContent']/div[1]/div/div/p")
	protected WebElement msgDepositDetailsPage;

	@FindBy(xpath = "//div[@id='pageContent']/form/div[1]")
	protected WebElement noteDepositDetailsPage;

	@FindBy(xpath = "//a[contains(.,'Check/Uncheck All')]")
	protected WebElement txtchkUnChkAll;

	@FindBy(id = "cancel_button")
	protected WebElement btnCancel;

	@FindBy(xpath = "//div[@id='pageContent']/h2[1]")
	protected WebElement msgEnrollAccs;

	@FindBy(xpath = "//div[@id='pageContent']/h2[2]")
	protected WebElement msgUnEnrollAccs;

	@FindBy(name = "accountNumber")
	protected WebElement lblNAOAccNumber;

	@FindBy(css = "tr:nth-child(19) td.description")
	protected WebElement lblEnrollmentPerAccNumber;

	@FindBy(css = "tr:nth-child(21) td.description")
	protected WebElement lblEnrollmentBusAccNumber;

	protected String accCheckBoxXpath = "//*[@id='pageContent']/form/div/label[contains(text(),'%s')]/preceding::input[1]";
	protected String enrollAccXpath = "//*[@id='pageContent']/table[1]/tbody/tr/td[contains(text(),'%s')]";
	protected String unEnrollAccXpath = "//*[@id='pageContent']/table[2]/tbody/tr/td[contains(text(),'%s')]";

	public String naoAccountNumber = null;
	public String enrollAccountNumber = null;

	/**
	 * To Verify the View Deposit Details Preferences Page Title
	 */

	public boolean verifyViewDepositDetailsPageTitle(String viewDepositDetailsPageTitle) {
		try {
			waits.waitUntilElementIsPresent(titleViewDepositDetailsPage, 20);
			return wolWebUtil.verifyText(titleViewDepositDetailsPage, viewDepositDetailsPageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyViewDepositDetailsPageTitle",
					viewDepositDetailsPageTitle + " Page is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the Continue button in eDelivery Preferences Page
	 */

	public boolean clickOnContinueBtnInDepositDetailsPage() {
		boolean flag = false;
		try {
			boolean contineButton = webActions.isDisplayed(btnContinueDepositDetailsPage);
			if (contineButton) {
				webActions.clickElement(btnContinueDepositDetailsPage);
				LogUtility.logInfo("--->clickOnContinueBtnInDepositDetailsPage<---", "Clicked on Continue button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnContinueBtnInDepositDetailsPage", "Unable to click on Continue button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/*
	 * To Verify the Deposit Details Confirmation Page Title
	 */

	public boolean verifyDepositDetailsConfPageTitle(String depositDetailsConfPageTitle) {
		try {
			waits.waitUntilElementIsPresent(titleDepositDetailsConfPage, 5);
			return wolWebUtil.verifyText(titleDepositDetailsConfPage, depositDetailsConfPageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositDetailsConfPageTitle",
					depositDetailsConfPageTitle + " Page is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/*
	 * To Verify the Deposit Details Confirmation Page Title
	 */

	public boolean verifyDepositDetailsConfPageMsg(String depositDetailsConfPageMsg) {
		try {
			waits.waitUntilElementIsPresent(titleDepositDetailsConfMsg, 5);
			return wolWebUtil.verifyText(titleDepositDetailsConfMsg, depositDetailsConfPageMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositDetailsConfPageMsg",
					depositDetailsConfPageMsg + " message is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify Account check box is selected or not, If selected un-check the
	 * check box , If Un-checked, select the check box
	 */
	public boolean verifyAccountCheckBoxStatus(String accNumber, String checkBoxStatus) {
		boolean flag = false;
		WebElement accDetails;
		try {
			if (checkBoxStatus.equals("Checked")) {
				accDetails = driver.findElement(By.xpath(String.format(accCheckBoxXpath, accNumber)));
				boolean returnValue = webActions.isChecked(accDetails);
				if (returnValue)
					flag = true;
				else {
					webActions.clickElement(accDetails);
					flag = true;
				}
				LogUtility.logInfo("---> Account checked <---" + accDetails);
			} else if (checkBoxStatus.equals("Unchecked")) {
				accDetails = driver.findElement(By.xpath(String.format(accCheckBoxXpath, accNumber)));
				boolean returnValue = webActions.isChecked(accDetails);
				if (returnValue) {
					webActions.clickElement(accDetails);
					flag = true;
				} else
					flag = true;
				LogUtility.logInfo("---> Account Un checked <---." + accDetails);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountCheckBoxStatus",
					accNumber + " is not displayed" + checkBoxStatus + " status ", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Text message in Deposit Details Preferences Page
	 */
	public boolean verifyDepositDetailsMsg(String text) {
		try {
			return wolWebUtil.verifyText(msgDepositDetailsPage, text);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositDetailsMsg", text + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Note in Deposit Details Preferences Page
	 */
	public boolean verifyNoteDepositDetailsPage(String text) {
		try {
			return wolWebUtil.verifyText(noteDepositDetailsPage, text);
		} catch (Exception e) {
			LogUtility.logException("verifyNoteDepositDetailsPage", text + " text is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Check/Uncheck/All options
	 */
	public boolean verifyChkUnChkAll(String text) {
		try {
			return wolWebUtil.verifyText(txtchkUnChkAll, text);
		} catch (Exception e) {
			LogUtility.logException("verifyChkUnChkAll", text + " text is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify Cancel button is displayed
	 * 
	 * @return
	 */
	public boolean cancelBtn() {
		try {
			return webActions.isDisplayed(btnCancel);
		} catch (Exception e) {
			LogUtility.logException("cancelBtn", "Unable to display Cancel button", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Enrolled Account details
	 */
	public boolean verifyEnrollText(String text) {
		try {
			return wolWebUtil.verifyText(msgEnrollAccs, text);
		} catch (Exception e) {
			LogUtility.logException("verifyEnrollText", text + " text is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Un Enrolled Account details
	 */
	public boolean verifyUnEnrollText(String text) {
		try {
			return wolWebUtil.verifyText(msgUnEnrollAccs, text);
		} catch (Exception e) {
			LogUtility.logException("verifyUnEnrollText", text + " text is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Enroll Account number
	 * 
	 * @return
	 */
	public boolean verifyEnrollAccNumber(String enrollAcc) {
		try {
			WebElement enrollAccountFormat = driver.findElement(By.xpath(String.format(enrollAccXpath, enrollAcc)));
			return wolWebUtil.verifyText(enrollAccountFormat, enrollAcc);
		} catch (Exception e) {
			LogUtility.logException("verifyEnrollAccNumber", enrollAcc + " number is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Un-Enroll Account number
	 * 
	 * @return
	 */
	public boolean verifyUnEnrollAccNumber(String unEnrollAcc) {
		try {
			WebElement unEnrollAccountFormat = driver
					.findElement(By.xpath(String.format(unEnrollAccXpath, unEnrollAcc)));
			return wolWebUtil.verifyText(unEnrollAccountFormat, unEnrollAcc);
		} catch (Exception e) {
			LogUtility.logException("verifyUnEnrollAccNumber", unEnrollAcc + " number is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Enroll/Un-Enroll Account number in Deposit Details Page
	 */

	public boolean verifyAccountEnrolledOrUnEnrolled(String accNumber, String status) {
		boolean flag = false;
		WebElement accDetails;
		try {
			accDetails = driver.findElement(By.xpath(String.format(accCheckBoxXpath, accNumber)));
			boolean accStatus = webActions.isChecked(accDetails);
			if (status.equals("Enrolled")) {
				if (accStatus) {
					LogUtility.logInfo("--->verifyAccountEnrolledOrUnEnrolled<---", "Account Enrolled");
					flag = true;
				}
			} else if (status.equals("Un-Enrolled")) {
				if (!accStatus) {
					LogUtility.logInfo("--->verifyAccountEnrolledOrUnEnrolled<---", "Account UnEnrolled");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountEnrolledOrUnEnrolled",
					accNumber + " is not displayed " + status + "status", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To capture the Enroll Account number
	 * 
	 * @return
	 */
	public String captureEnrollAccountNumber(String user) {
		try {
			if (user.equals("Personal User")) {
				webActions.isDisplayed(lblEnrollmentPerAccNumber);
				String accNumber = webActions.getText(lblEnrollmentPerAccNumber);
				enrollAccountNumber = accNumber.substring(accNumber.length() - 4);
				LogUtility.logInfo("--->captureAccountNumber<---", "Personal User Account number captured");
			} else if (user.equals("Business User")) {
				webActions.isDisplayed(lblEnrollmentBusAccNumber);
				String accNumber = webActions.getText(lblEnrollmentBusAccNumber);
				enrollAccountNumber = accNumber.substring(accNumber.length() - 4);
				LogUtility.logInfo("--->captureAccountNumber<---", "Business User Account number captured");
			}
		} catch (Exception e) {
			LogUtility.logException("captureAccountNumber", "Unable to capture the account number", e,
					LoggingLevel.ERROR, true);
		}
		return enrollAccountNumber;
	}

	/**
	 * To verify the Account number is Enrolled in Deposit Details Page
	 */

	public boolean verifyAccountNumberIsEnrolled() {
		boolean flag = false;
		WebElement accDetails;
		try {
			accDetails = driver.findElement(By.xpath(String.format(accCheckBoxXpath, enrollAccountNumber)));
			boolean accStatus = webActions.isChecked(accDetails);
			if (accStatus) {
				LogUtility.logInfo("--->verifyAccountNumberIsEnrolled<---", "Account is Auto Enrolled");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountNumberIsEnrolled", "Account is UnEnrolled", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To capture the NAO New Account number
	 * 
	 * @return
	 */
	public String captureNAOAccountNumber() {
		try {
			webActions.isDisplayed(lblNAOAccNumber);
			String accNumber = webActions.getText(lblNAOAccNumber);
			naoAccountNumber = accNumber.substring(accNumber.length() - 4);
			LogUtility.logInfo("--->captureNAOAccountNumber<---", "Personal User NAO Account number captured");
		} catch (Exception e) {
			LogUtility.logException("captureNAOAccountNumber", "Unable to capture the NAO account number", e,
					LoggingLevel.ERROR, true);
		}
		return naoAccountNumber;
	}

	/**
	 * To verify the NAO Account number is Enrolled in Deposit Details Page
	 */

	public boolean verifyNAOAccountNumberIsEnrolled() {
		boolean flag = false;
		WebElement accDetails;
		try {
			accDetails = driver.findElement(By.xpath(String.format(accCheckBoxXpath, naoAccountNumber)));
			boolean accStatus = webActions.isChecked(accDetails);
			if (accStatus) {
				LogUtility.logInfo("--->verifyNAOAccountNumberIsEnrolled<---", "Account is Auto Enrolled");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNAOAccountNumberIsEnrolled", "Account is UnEnrolled", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}
}
