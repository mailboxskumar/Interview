
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class AddressPhoneChangePage extends ObjectBase {

	public AddressPhoneChangePage() {
		PageFactory.initElements(driver, this);
	}

	WebcomPage webcomPage = new WebcomPage();

	@FindBy(id = "address-phone-change__formSection--home__section-title")
	protected WebElement labelHomeAddress;

	@FindBy(id = "address-phone-change__formSection--mailing__section-title")
	protected WebElement labelMailAddress;

	@FindBy(id = "address-phone-change__formSection--phone__section-title")
	protected WebElement labelPhoneNumbers;

	@FindBy(id = "address-phone-change__formSection--seasonal__section-title")
	protected WebElement labelSeasonalAddress;

	@FindAll({ @FindBy(id = "address-phone-change__form__button--cancel"),
			@FindBy(id = "address-phone-change-verify__form__button--cancel") })
	protected WebElement btnCancel;

	@FindAll({ @FindBy(id = "address-phone-change__form__button--submit__actualButton"),
			@FindBy(id = "address-phone-change-verify__form__button--submit__actualButton") })
	protected WebElement btnContinue;

	@FindBy(id = "doNotCancelButton")
	protected WebElement btnNo;

	@FindBy(id = "confirmCancelButton")
	protected WebElement btnYes;

	@FindBy(css = "#pageContent>div:nth-child(1)")
	protected WebElement txtAccessMessage;

	@FindBy(id = "address-phone-change-verify__form__button--edit__actualButton")
	protected WebElement btnEdit;

	@FindBy(id = "updateEmailButton")
	protected WebElement btnUpdateEmailAddress;

	@FindBy(css = "section#address-phone-change__formSection--phone__content .label")
	protected List<WebElement> listLabelsPhoneNumbers;

	@FindBy(css = "section#address-phone-change__formSection--phone__content .label + input")
	protected List<WebElement> listInputsPhoneNumbers;

	@FindAll({ @FindBy(css = "#address-phone-change-verify__formSection--phone__content span.display>span"),
			@FindBy(css = "#address-phone-change-confirm__formSection--phone span.display>span") })
	protected List<WebElement> listPhoneNumberValues;

	@FindBy(id = "address-phone-change-confirm__pageAffirmativeNotice__body")
	protected WebElement txtConfirmationMessage;

	@FindBy(css = "#address-phone-change-confirm__nextSteps>ul>li>a")
	protected List<WebElement> listConfirmationLinks;

	@FindBy(css = "h1[aria-expanded='true'] + #address-phone-change__formSection--seasonal__content div>label")
	protected List<WebElement> listLabelsSeasonalAddress;

	@FindBy(css = "h1[aria-expanded='true'] +  #address-phone-change__formSection--seasonal__content div>input[type='text']")
	protected List<WebElement> listInputsSeasonalAddress;

	@FindBy(css = "#address-phone-change__formSection--home__content div>label")
	protected List<WebElement> listLabelsHomeAddress;

	@FindBy(css = "#address-phone-change__formSection--home__content div>input[type='text']")
	protected List<WebElement> listInputsHomeAddress;

	@FindBy(css = "#address-phone-change__formSection--mailing div>label")
	protected List<WebElement> listLabelsMailAddress;

	@FindBy(css = "#address-phone-change__formSection--mailing div>input[type='text']")
	protected List<WebElement> listInputsMailAddress;

	@FindBy(css = "#seasonalAccountList input[type='checkbox']")
	protected WebElement checkboxSeasonalMailingAccount;

	@FindBy(css = "#mailingAccountList input[type='checkbox']")
	protected WebElement checkboxAlternateMailingAccount;

	@FindAll({ @FindBy(css = "#address-phone-change-verify__formSection--phone__content span.display>span"),
			@FindBy(css = "#address-phone-change-confirm__formSection--phone span.display>span") })
	protected List<WebElement> listSeasonalValues;

	@FindAll({ @FindBy(css = "#address-phone-change-verify__formSection--mailing span.display>span"),
			@FindBy(css = "#address-phone-change-confirm__formSection--mailing span.display>span") })
	protected List<WebElement> listMailAddressValues;

	@FindAll({ @FindBy(css = "#address-phone-change-confirm__formSection--home span.display>span"),
			@FindBy(css = "#address-phone-change-verify__formSection--home span.display>span") })
	protected List<WebElement> listHomeAddressValues;

	@FindBy(id = "profile-email-edit__pageInstructions__body")
	protected WebElement txtInformationPopup;

	@FindBy(id = "profile-email-edit__cancel")
	protected WebElement btnCancelPopUp;

	@FindBy(id = "profile-email-edit__submit__actualButton")
	protected WebElement btnContinuePopUp;

	@FindBy(id = "profile-email-edit__email1__label")
	protected WebElement labelNewEmailAddress;

	@FindBy(id = "profile-email-edit__email2__label")
	protected WebElement labelVerifyNewEmailAddress;

	@FindBy(id = "pageError_gen_0__body")
	protected WebElement txtErrorMessagePopup;

	@FindBy(id = "profile-email-edit__affirmativeNotice__body")
	protected WebElement txtSuccessMessagePopup;

	@FindBy(css = "#profile-email-edit__formSection p.error-message-text")
	protected List<WebElement> listTxtMessages;

	@FindBy(id = "profile-email-edit__email1__input")
	protected WebElement inputNewEmailAddress;

	@FindBy(id = "profile-email-edit__email2__input")
	protected WebElement inputVerifyNewEmailAddress;

	@FindBy(css = "#lightBoxTitle2 + button[aria-label='Close the dialog']")
	protected WebElement btnClose;

	@FindBy(css = "#currentEmail__display>span")
	protected WebElement txtEmailAddress;

	@FindBy(css = "#address-phone-change__pageInstructions__body p>a")
	protected WebElement linkAccountServiceHistory;

	@FindAll({ @FindBy(css = "#address-phone-change-confirm__nextSteps>ul>li>a"),
			@FindBy(css = "ul[class='nextsteps'] li>a") })
	protected List<WebElement> listNextStepsLinks;

	@FindBy(id = "seasonalDateStart__calendar-button")
	protected WebElement btnStartDate;

	@FindBy(name = "StartDate")
	protected WebElement inputStartDate;

	@FindBy(css = "#seasonalDateStart__input_table .picker__day--today")
	protected WebElement btnTodaysDate;

	@FindBy(id = "messageSmallTalkRequired0Id__bodyMessage")
	protected WebElement txtSmallTalkMessage;

	@FindBy(id = "nextId")
	protected WebElement btnNextSmallTalk;

	@FindBy(css = "#messageSmallTalkRequired0Id__bodyMessage>a")
	protected WebElement linkClickHereSmallTalk;

	@FindBy(css = "table:nth-child(5)>tbody table tr:nth-child(2)>td:nth-child(6)>a")
	protected List<WebElement> listViewLinks;

	@FindBy(css = "table:nth-child(6) tr>td:nth-child(2)")
	protected List<WebElement> listUpdatedDetails;

	WebElement accountCheckbox = null;
	public List<String> listQuickLinks = new ArrayList<String>();
	public String quickLinkName = "";
	public String seasonalAccountCheckboxPath = "//fieldset[@id='seasonalAccountList']//label/span[contains(text(),'%s')]";
	public String mailAccountCheckboxPath = "//fieldset[@id='mailingAccountList']//label/span[contains(text(),'%s')]";

	/**
	 * checkLabels: To check the presence of label
	 * 
	 * @param labelName
	 * @return
	 */
	public boolean checkLabels(String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement labelToCheck = null;
		try {
			switch (labelName) {
			case "Physical/Home Address":
				labelToCheck = labelHomeAddress;
				break;
			case "Alternate Mailing Address":
				labelToCheck = labelMailAddress;
				break;
			case "Phone Numbers":
				labelToCheck = labelPhoneNumbers;
				break;
			case "Seasonal Address":
				labelToCheck = labelSeasonalAddress;
				break;
			default:
				LogUtility.logInfo("--->checkLabels<---", "No matching case found");
				break;
			}
			if (wolWebUtil.verifyText(labelToCheck, labelName)) {
				LogUtility.logInfo("--->checkLabels<---", "Label: " + labelName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkLabels<--", "Label: " + labelName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButton: To click on the button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement btnToClick = null;
		try {
			switch (btnName) {
			case "Cancel":
				btnToClick = btnCancel;
				break;
			case "Continue":
				btnToClick = btnContinue;
				break;
			case "No":
				btnToClick = btnNo;
				break;
			case "Yes":
				btnToClick = btnYes;
				break;
			case "Phone Numbers":
				btnToClick = labelPhoneNumbers;
				break;
			case "Seasonal Address":
				btnToClick = labelSeasonalAddress;
				break;
			case "Physical/Home Address":
				btnToClick = labelHomeAddress;
				break;
			case "Alternate Mailing Address":
				btnToClick = labelMailAddress;
				break;
			case "Edit":
				btnToClick = btnEdit;
				break;
			case "Update Email Address":
				btnToClick = btnUpdateEmailAddress;
				break;
			case "Continue Email":
				btnToClick = btnContinuePopUp;
				break;
			case "Cancel Email":
				btnToClick = btnCancelPopUp;
				break;
			case "View your Account Services History":
				btnToClick = linkAccountServiceHistory;
				break;
			default:
				LogUtility.logInfo("--->clickOnButton<---", "No matching case found");
				break;
			}
			waits.waitForPageReadyState();
			// TODO: Taking time load the all pages
			waits.staticWait(5);
			if (webActions.isDisplayed(btnToClick)) {
				webActions.clickElement(btnToClick);
				LogUtility.logInfo("--->clickOnButton<---", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "Button: " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkLabelsAndEnterValues: To check the labels and enter values
	 * 
	 * @param testDataMap
	 * @param headerName
	 * @return
	 * @throws Throwable
	 */
	public List<String> checkLabelsAndEnterValues(Map<String, String> testDataMap, String headerName) {
		List<String> listValues = new ArrayList<String>();
		waits.waitForPageReadyState();
		waits.waitForDOMready();

		String value = "";
		List<WebElement> listLabels = null;
		List<WebElement> listInputs = null;
		try {
			switch (headerName) {
			case "Phone Numbers":
				listLabels = listLabelsPhoneNumbers;
				listInputs = listInputsPhoneNumbers;
				break;
			case "Seasonal Address":
				listLabels = listLabelsSeasonalAddress;
				listInputs = listInputsSeasonalAddress;
				break;
			case "Physical/Home Address":
				listLabels = listLabelsHomeAddress;
				listInputs = listInputsHomeAddress;
				break;
			case "Alternate Mailing Address":
				listLabels = listLabelsMailAddress;
				listInputs = listInputsMailAddress;
				break;
			default:
				LogUtility.logInfo("--->checkLabelsAndEnterValues<---", "No matching case found");
				break;
			}
			for (int i = 0; i < listLabels.size(); i++) {
				if (testDataMap.containsKey(webActions.getText(listLabels.get(i))))
					value = testDataMap.get(webActions.getText(listLabels.get(i)));
				if (value.equalsIgnoreCase("RandomPhoneNumber"))
					value = 8 + wolWebUtil.getRandomNumber(9);
				else if (value.equalsIgnoreCase("Today"))
					value = wolWebUtil.getDateInTheFormat("yyyy-MM-dd", 6);
				else if (value.equalsIgnoreCase("FutureDate"))
					value = wolWebUtil.getDateInTheFormat("yyyy-MM-dd", 16);
				listInputs.get(i).clear();
				listInputs.get(i).click();
				listInputs.get(i).sendKeys(value);
				LogUtility.logInfo("--->checkLabelsAndEnterValues<---", "Value: " + value + " is entered");
				waits.waitForDOMready();
				webActions.getValue(listInputs.get(i));
				// TODO: Taking time to convert into phone number format
				waits.staticWait(5);
				listValues.add(webActions.getValue(listInputs.get(i)));
			}
		} catch (Throwable e) {
			LogUtility.logException("-->checkLabelsAndEnterValues<--", "Dates are throwing exception", e,
					LoggingLevel.ERROR, true);
		}
		return listValues;
	}

	/**
	 * checkAccessMessage: To check the unauthorized access message
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkAccessMessage(String message) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtAccessMessage, message)) {
				LogUtility.logInfo("--->checkAccessMessage<---", "Message: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkAccessMessage<--", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkButtons: To check the display of button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean checkButtons(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement btnToCheck = null;
		try {
			switch (btnName) {
			case "Edit":
				btnToCheck = btnEdit;
				break;
			case "Cancel":
				btnToCheck = btnCancel;
				break;
			case "Continue":
				btnToCheck = btnContinue;
				break;
			default:
				LogUtility.logInfo("--->checkButtons<---", "No case is matched");
				break;
			}
			if (wolWebUtil.verifyText(btnToCheck, btnName)) {
				LogUtility.logInfo("--->checkButtons<---", "Button: " + btnName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkButtons<--", "Button: " + btnName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForData: To check the data is displayed
	 * 
	 * @param listValues
	 * @param labelName
	 * @return
	 */
	public boolean checkForData(List<String> listValues, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		List<WebElement> listToCheck = null;
		try {
			switch (labelName) {
			case "Phone Numbers":
				listToCheck = listPhoneNumberValues;
				break;
			case "Seasonal Address":
				listToCheck = listSeasonalValues;
				break;
			case "Physical/Home Address":
				listToCheck = listHomeAddressValues;
				break;
			case "Alternate Mailing Address":
				listToCheck = listMailAddressValues;
				break;
			default:
				LogUtility.logInfo("--->checkForData<---", "No Matching case found");
				break;
			}
			for (WebElement elementValue : listToCheck)
				if (wolWebUtil.verifyTextContains(elementValue, listValues.toString())) {
					LogUtility.logInfo("--->checkForData<---", "Values: " + listValues.toString() + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->checkForData<--", "Values: " + listValues.toString() + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkConfirmationMessage: To check the confirmation message
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkConfirmationMessage(String message) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			waits.waitForPageReadyState();
			if (wolWebUtil.verifyTextContains(txtConfirmationMessage, message)) {
				LogUtility.logInfo("--->checkConfirmationMessage<---", "Message: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkConfirmationMessage<--", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForDetails: To check for the listed links
	 * 
	 * @param headerName
	 * @param QuickLinks
	 * @return
	 */
	public List<String> checkForDetails(String headerName, Map<String, String> mapQuickLinks) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			for (WebElement link : listConfirmationLinks) {
				quickLinkName = webActions.getText(link);
				if (mapQuickLinks.containsValue(quickLinkName)) {
					LogUtility.logInfo("-->checkForDetails<--", "Link: " + quickLinkName + " is present");
				} else
					listQuickLinks.add(quickLinkName);
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForDetails--", "Details are not present", e, LoggingLevel.ERROR, true);
		}
		return listQuickLinks;
	}

	/**
	 * clickOnAccountCheckbox: To click on the mailing account check-box
	 * 
	 * @param account
	 * 
	 * @return
	 */
	public boolean clickOnSeasonalAccountCheckbox(String account) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (account.equalsIgnoreCase("First"))
				accountCheckbox = checkboxSeasonalMailingAccount;
			else
				accountCheckbox = driver.findElement(By.xpath(String.format(seasonalAccountCheckboxPath, account)));
			if (!webActions.isChecked(accountCheckbox)) {
				webActions.clickElementJS(accountCheckbox);
				LogUtility.logInfo("-->clickOnSeasonalAccountCheckbox<--", "mailing account is checked");
			}
			return true;
		} catch (Exception e) {
			LogUtility.logException("->clickOnSeasonalAccountCheckbox--", "mailing account is not checked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnMailAccountCheckbox: To click on the account under Mail Account
	 * 
	 * @param account
	 * @return
	 */
	public boolean clickOnMailAccountCheckbox(String account) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (account.equalsIgnoreCase("First"))
				accountCheckbox = checkboxAlternateMailingAccount;
			else
				accountCheckbox = driver.findElement(By.xpath(String.format(mailAccountCheckboxPath, account)));
			if (!webActions.isChecked(accountCheckbox)) {
				webActions.clickElement(accountCheckbox);
				LogUtility.logInfo("-->clickOnMailAccountCheckbox<--", "mailing account is checked");
			}
			return true;
		} catch (Exception e) {
			LogUtility.logException("->clickOnMailAccountCheckbox--", "mailing account is not checked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkMessageText: To check the message is displayed
	 * 
	 * @param textType
	 * @param map
	 * @return
	 */
	public String checkMessageText(String textType, Map<String, String> mapMessage) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		waits.staticWait(5);
		WebElement messageTypeElement = null;
		String message = null;
		try {
			switch (textType) {
			case "Information":
				messageTypeElement = txtInformationPopup;
				message = mapMessage.get("Info");
				break;
			case "Error":
				messageTypeElement = txtErrorMessagePopup;
				message = mapMessage.get("Error");
				break;
			case "Success":
				messageTypeElement = txtSuccessMessagePopup;
				message = mapMessage.get("Success");
				break;
			default:
				LogUtility.logInfo("--->checkMessageText<---", "No case match found");
				break;
			}
			if (wolWebUtil.verifyTextContains(messageTypeElement, message)) {
				LogUtility.logInfo("--->checkMessageText<---", "Message: " + message + " is displayed");
				return message;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkMessageText<--", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return message;
	}

	/**
	 * verifyDisplayPopup : To verify the contents in pop-up
	 * 
	 * @param name
	 * @return
	 */
	public boolean verifyDisplayPopup(String name) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement eleToCheck = null;
		try {
			switch (name) {
			case "Cancel":
				eleToCheck = btnCancelPopUp;
				break;
			case "Continue":
				eleToCheck = btnContinuePopUp;
				break;
			case "New Email Address":
				eleToCheck = labelNewEmailAddress;
				break;
			case "Verify New Email Address":
				eleToCheck = labelVerifyNewEmailAddress;
				break;
			case "Close":
				eleToCheck = btnClose;
				break;
			default:
				LogUtility.logInfo("--->verifyDisplayPopup<---", "No matching case found");
				break;
			}
			if (wolWebUtil.verifyText(eleToCheck, name)) {
				LogUtility.logInfo("--->verifyDisplayPopup<---", name + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyDisplayPopup<--", name + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForMessages: To verify the string of messages are displayed or not
	 * 
	 * @param testDataMap
	 * @return
	 */
	public List<String> checkForMessages(Map<String, String> testDataMap) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		List<String> listMessages = new ArrayList<String>();
		String message = "";
		try {
			for (WebElement txtMessage : listTxtMessages)
				message = webActions.getText(txtMessage);
			if (testDataMap.containsValue(message)) {
				LogUtility.logInfo("-->checkForMessages<--", "Message: " + message + " is present");
			} else
				listMessages.add(message);
		} catch (Exception e) {
			LogUtility.logException("->checkForMessages--",
					"Message(s)" + listMessages.toString() + " is(are) not present", e, LoggingLevel.ERROR, true);
		}
		return listMessages;
	}

	/**
	 * enterRandomMailInNewEmail: To enter the random mail address
	 * 
	 * @return
	 */
	public String enterRandomMailInNewEmail() {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		String emailAddress = "";
		try {
			if (webActions.isDisplayed(inputNewEmailAddress)) {
				emailAddress = wolWebUtil.getRandomString(7) + "@websterbank.com";
				webActions.setValue(inputNewEmailAddress, emailAddress);
				LogUtility.logInfo("-->enterRandomMailInNewEmail<--", "Mail Address : " + emailAddress + " is entered");
				return emailAddress;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterRandomMailInNewEmail--", "Mail Address : " + emailAddress + " is entered",
					e, LoggingLevel.ERROR, true);
		}
		return emailAddress;
	}

	/**
	 * enterRandomMailInVerifyNewEmail: To enter email address in verify new email
	 * address
	 * 
	 * @param emailAddress
	 * @return
	 */
	public boolean enterRandomMailInVerifyNewEmail(String emailAddress) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (webActions.isDisplayed(inputVerifyNewEmailAddress)) {
				webActions.setValue(inputVerifyNewEmailAddress, emailAddress);
				LogUtility.logInfo("-->enterRandomMailInVerifyNewEmail<--",
						"Mail Address : " + emailAddress + " is entered");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterRandomMailInVerifyNewEmail--",
					"Mail Address : " + emailAddress + " is entered", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkUpdatedEmail: To check the mail id is updated
	 * 
	 * @param emailAddress
	 * @return
	 */
	public boolean checkUpdatedEmail(String emailAddress) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (wolWebUtil.verifyTextContains(txtEmailAddress, emailAddress)) {
				LogUtility.logInfo("-->checkUpdatedEmail<--", "Mail Address : " + emailAddress + " is present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkUpdatedEmail--", "Mail Address : " + emailAddress + " is present", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnNextLinksInPage: Click on Link in nextSteps of page
	 * 
	 * @param linkName
	 * @param pageName
	 * @return
	 */
	public boolean clickOnNextLinksInPage(String linkName, String pageName) {
		try {
			for (WebElement link : listNextStepsLinks)
				if (wolWebUtil.verifyTextContains(link, linkName)) {
					webActions.clickElement(link);
					LogUtility.logInfo("-->clickOnNextLinksInPage<--", linkName + " is clicked in page: " + pageName);
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnNextLinksInPage<--", linkName + " is not clicked in page: " + pageName,
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnSmallTalkHereLink: To click on click here link in small talk message
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickOnSmallTalkHereLink(String linkName) {
		try {
			if (webActions.isDisplayed(linkClickHereSmallTalk)) {
				webActions.clickElement(linkClickHereSmallTalk);
				LogUtility.logInfo("-->clickOnNextLinksInPage<--", linkName + " is clicked in small talk message");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnNextLinksInPage<--", linkName + " is not clicked in small talk message",
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkMessageSmallTalkText: To verify the small talk message is displayed
	 * 
	 * @param textType
	 * @param message
	 * @return
	 */
	public boolean checkMessageSmallTalkText(String textType, String message) {
		try {
			if (webActions.isDisplayed(linkClickHereSmallTalk))
				do {
					if (wolWebUtil.verifyTextContains(txtSmallTalkMessage, message))
						webActions.clickElement(linkClickHereSmallTalk);
					LogUtility.logInfo("-->checkMessageSmallTalkText<--",
							"Message: " + message + " is displayed in small talk message");
					return true;
				} while (webActions.isEnabled(btnNextSmallTalk));
		} catch (Exception e) {
			LogUtility.logException("-->checkMessageSmallTalkText<--",
					"Message: " + message + " is not displayed in small talk message", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkPhoneNumbers : To the phone numbers
	 * 
	 * @param listValues
	 * @param pageName
	 * @return
	 */
	public boolean checkPhoneNumbers(List<String> listValues, String pageName) {
		int listSize = listViewLinks.size();
		int count = 0;
		try {
			waits.waitForDOMready();
			if (listSize > 0) {
				for (int row = 0; row < listSize; row++) {
					webActions.clickElement(listViewLinks.get(row));
					waits.waitForDOMready();
					waits.waitForPageReadyState();
					// TODO; Taking time to load the next page
					waits.staticWait(4);
					if (webcomPage.verifyPageHeader(pageName)) {
						for (WebElement value : listUpdatedDetails)
							if (wolWebUtil.verifyTextContains(value, listValues.toString()))
								count++;
						if (count == 3) {
							LogUtility.logInfo("-->checkPhoneNumbers<--", "Updated Phone numbers are present");
							return true;
						}
					} else {
						driver.navigate().back();
					}
				}
			} else {
				LogUtility.logError("-->checkPhoneNumbers<--", "No records found");
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkPhoneNumbers<--", "Updated phone number values are not present in any row",
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}
}
