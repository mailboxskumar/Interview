package com.wb.wol_web.pages;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class WebcomPage extends ObjectBase {

	public WebcomPage() {
		PageFactory.initElements(driver, this);
	}

	public String webcomPageTitle = "//h1[contains(text(),'%s')]";
	public String webcomConfirmMsg = "//b[contains(text(),'%s')]";
	public String viewDepositDetailsSts = "//td[contains(text(),'%s')]//following::td[2]";
	public String accountStatus = "//td[contains(text(),'%s')]//preceding-sibling::td/input[1]";
	public String cifNumber = "";

	@FindBy(xpath = "//div[contains(text(),'Thank You')]")
	protected WebElement txtLogoutMsg;

	@FindBy(xpath = "//div[@id = 'menu' or @id='mainMenu']")
	protected WebElement lnkMainMenuWebcom;

	@FindBy(id = "LoginName_")
	protected WebElement txtUsername;

	@FindBy(id = "Password_")
	protected WebElement txtPassword;

	@FindBy(xpath = "//input[@type='submit']")
	protected WebElement btnLogin;

	@FindBy(name = "ApplCode")
	protected WebElement lstApplCode;

	@FindBy(name = "AcctType")
	protected WebElement txtAcctType;

	@FindBy(xpath = "//table[@class='data-table ']/tbody//tr[1]//td[4]")
	protected WebElement txtCIFNumberMainPage;

	@FindBy(xpath = "//input[@name='relatedCIF']")
	protected WebElement inputCIFNumber;

	@FindBy(xpath = "//input[@value='Save']")
	protected WebElement btnSave;

	@FindBy(xpath = "//div[@class='message']")
	protected WebElement txtSwitchMessage;

	@FindBy(css = "input[value=Search]")
	protected WebElement btnSearch;

	@FindBy(xpath = "//table//a")
	protected WebElement tblProductApprove;

	@FindBy(css = "div.box > table")
	protected WebElement tblEnrollmentQueue;

	@FindBy(xpath = "//input[@name='transfer_valid_from' and @value='Y']")
	protected WebElement rdbtnTransferFromYes;

	@FindBy(xpath = "//input[@name='transfer_valid_from' and @value='N']")
	protected WebElement rdbtnTransferFromNo;

	@FindBy(xpath = "//input[@name='transfer_valid_to' and @value='Y']")
	protected WebElement rdbtnTransferToYes;

	@FindBy(xpath = "//input[@name='transfer_valid_to' and @value='N']")
	protected WebElement rdbtnTransferToNo;

	@FindBy(xpath = "//input[@name='btnUpdate']")
	protected WebElement btnUpdate;

	@FindBy(xpath = "//div[@class='message']")
	protected WebElement txtDeleteCnfrmMsg;

	@FindBy(xpath = "//*[contains(text(),'Logout')]")
	protected WebElement lnkLogOut;

	@FindBy(css = "a#menuBtn+a")
	protected WebElement lnkLogOutRSA;

	@FindBy(xpath = "//input[contains(@id,'username')]")
	protected WebElement txtUsernameSearch;

	@FindBy(id = "Tax_ID_")
	protected WebElement txtSSN;

	@FindBy(id = "cif_number_")
	protected WebElement txtCIFNumber;

	@FindBy(id = "backend_account_number_")
	protected WebElement txtAcctNumber;

	@FindBy(id = "customer_id_")
	protected WebElement txtCustomerID;

	@FindBy(id = "biz_name_")
	protected WebElement txtBusinessName;

	@FindBy(id = "user_id_")
	protected WebElement txtUserID;

	@FindBy(id = "last_name_")
	protected WebElement txtLastName;

	@FindBy(name = "last_name")
	protected WebElement txtLastNameVal;

	@FindBy(xpath = "//input[contains(@id,'email')]")
	protected WebElement txtEmail;

	@FindBy(xpath = "//div[@id='title2']//b")
	protected WebElement txtResetPassword;

	@FindBy(id = "tin")
	protected WebElement txtTIN;

	@FindBy(id = "ssn")
	protected WebElement txtSSNDel;

	@FindBy(id = "biz_cif")
	protected WebElement txtBusinessCIF;

	@FindBy(id = "psn_cif")
	protected WebElement txtPersonalCIF;

	@FindBy(xpath = "//div[contains(text(),'Inactive')]")
	protected WebElement txtInactiveMsg;

	@FindBy(xpath = "//div[contains(text(),'Activated')]")
	protected WebElement txtActiveMsg;

	@FindBy(xpath = "//span[contains(text(),'Welcome')]")
	protected WebElement txtWelcomeMsg;

	@FindBy(id = "banking_b")
	protected WebElement rdbtnBusiness;

	@FindBy(id = "banking_p")
	protected WebElement rdbtnPersonal;

	@FindBy(id = "cif")
	protected WebElement txtAddPersonalCIF;

	@FindBy(xpath = "//input[@value='View Backend Profile']")
	protected WebElement btnViewBackend;

	@FindBy(css = "div.message")
	protected WebElement txtAddCustomerConfrmMsg;

	@FindBy(xpath = "//input[@value='Update']")
	protected WebElement btnAddUpdate;

	@FindBy(name = "btnUpdate")
	protected WebElement btnUpdateDetails;

	@FindBy(name = "btnCreate")
	protected WebElement btnCreate;

	@FindBy(xpath = "//input[@value='Process']")
	protected WebElement btnProcess;

	@FindBy(xpath = "//a[contains(@href,'com.websterbank.admin.servlets.SelfServiceServlet?purpose=search_form')]")
	protected WebElement btnSearchForCustReqMenu;

	@FindBy(xpath = "//select[@name='request_types']")
	protected WebElement selRequestTypes;

	@FindBy(xpath = "//input[@value='  Search  ']")
	protected WebElement btnSearchForCustReq;

	@FindBy(xpath = "//legend/a[@class='bluelink']")
	protected WebElement lnkCustomerID;

	@FindBy(xpath = "//td[@id='title2']")
	protected WebElement txtAuditCount;

	@FindBy(xpath = "//a[text()='View']")
	protected WebElement lnkView;

	@FindBy(css = "body div.content div.page-body table:nth-child(6)")
	protected WebElement tblInformation;

	@FindBy(xpath = "//*[@class='menu menu--right action-menu']")
	protected WebElement mnuRight;

	@FindBy(xpath = "//ul[@class='menu menu--right action-menu submenu--is-active']")
	protected WebElement subMnuRight;

	@FindBy(name = "customer_id")
	protected WebElement txtUserId;

	@FindBy(name = "email")
	protected WebElement txtEmailId;

	@FindBy(css = "body div.content div.page-body div")
	protected WebElement txtUpdateMessage;

	@FindBy(xpath = "//input[@name='Tax_ID']")
	protected WebElement txtSsnNumber;

	@FindBy(css = "body div.content div.page-body table tbody tr:nth-child(1) td:nth-child(7) a")
	protected WebElement btnCustomerDetails;

	@FindBy(css = "body div.content div.page-body table thead")
	protected WebElement tblHeader;

	@FindBy(css = "body div.content div.page-body table tbody tr:nth-child(1) td:nth-child(8) a")
	protected WebElement btnAuthorized;

	@FindBy(xpath = "//form[@name='WebcomServlet']/table/tbody/tr/td/table/tbody/tr[1]")
	protected WebElement tblBusiness;

	@FindBy(xpath = "//form[@method='get']/div[2]/table[1]/tbody/tr")
	protected WebElement tblBusinessInfo;

	@FindBy(xpath = "//form[@name='WebcomServlet']/table/tbody/tr/td/table/tbody/tr[3]")
	protected WebElement tblCustomer;

	@FindBy(xpath = "//form[@name='frmAccounts']/table/tbody/tr[1]/td[2]")
	protected WebElement txtAccountNumber;

	@FindBy(css = "div.page-header h1")
	protected WebElement txtHeader;

	@FindBy(id = "statementCycleDate")
	protected WebElement lstStatement;

	@FindBy(name = "account_id")
	protected WebElement txtAccountId;

	@FindBy(name = "tax_id")
	protected WebElement txtTaxId;

	@FindBy(xpath = "//a[text()='View Statement']")
	protected WebElement btnViewStatement;

	@FindBy(xpath = "//a[text()='View Statements']")
	protected WebElement btnViewStatements;

	@FindBy(xpath = "//a[text()='Print Preview']")
	protected WebElement btnPrintPreview;

	@FindBy(id = "customer-statement")
	protected WebElement txtCusStatement;

	@FindBy(xpath = "//a[text()='Back']")
	protected WebElement btnBack;

	@FindBy(css = "div.lightbox-wrap.is-visible.is-top div div.lightbox")
	protected WebElement lightBox;

	@FindBy(css = "body div.lightbox-wrap.is-visible.is-top div div.lightbox div.lightbox-controls button.lightbox-controls__button.lightbox-controls__button--close")
	protected WebElement btnClose;

	@FindBy(css = "td:nth-child(2) span a img")
	protected WebElement imgCheck;

	@FindBy(css = "#feesSummary tbody tr.borderTop td.alignRight.nsf-third")
	protected WebElement txtYearToDate;

	@FindBy(css = "#feesSummary tbody tr.borderTop td.alignRight.nsf-second")
	protected WebElement txtCycleToDate;

	@FindBy(id = "statementCycle")
	protected WebElement txtCycleDate;

	@FindBy(id = "statementAddress")
	protected WebElement txtStatAddress;

	@FindBy(id = "detailedAccountSummary")
	protected WebElement txtAcctActivity;

	@FindBy(id = "customerService")
	protected WebElement txtCustServiceSection;

	@FindBy(css = "h2.accountSummaryHeader span")
	protected WebElement txtStatAcctNumber;

	@FindBy(id = "accountSummaryTable")
	protected WebElement txtAcctSummary;

	@FindBy(id = "interestTable")
	protected WebElement txtInterestTable;

	@FindBy(id = "transactionsTable")
	protected WebElement txtTransactionsTable;

	@FindBy(id = "checkList")
	protected WebElement txtChecksTable;

	@FindBy(id = "feesSummary")
	protected WebElement txtFeeSummaryTable;

	@FindBy(id = "ordering_chron")
	protected WebElement optByDate;

	@FindBy(id = "ordering_categ")
	protected WebElement optByCategory;

	@FindBy(xpath = "//input[@name='username']")
	protected WebElement txtUserName;

	@FindBy(xpath = "//input[@value='Show Details']")
	protected WebElement btnShowDetails;

	@FindBy(name = "transNames")
	protected WebElement lstTransactionType;

	@FindBy(css = "table > tbody > tr:nth-child(8) > td:nth-child(4)")
	protected WebElement txtEquifaxDOB;

	@FindBy(css = "table > tbody > tr:nth-child(8) > td:nth-child(2)")
	protected WebElement txtEquifaxSSN;

	@FindBy(css = "table > tbody > tr:nth-child(10) > td:nth-child(3)")
	protected WebElement txtEnrollmentSSN;

	@FindBy(css = "table > tbody > tr:nth-child(3) > td:nth-child(5)")
	protected WebElement txtEquifaxReasonCode;

	@FindBy(css = "table > tbody > tr:nth-child(11) > td:nth-child(3)")
	protected WebElement txtEnrollmentDOB;

	@FindBy(name = "product_id")
	protected WebElement lstProductType;

	@FindBy(css = "tr:nth-child(2) td  table  tbody  tr:nth-child(2)  td:nth-child(4)")
	protected WebElement lblProductType;

	@FindBy(css = "table:nth-child(9)  tbody  tr:nth-child(32)  td:nth-child(2)  input[type=radio]:nth-child(2)")
	protected WebElement optViewDepositAsNo;

	@FindBy(css = "table:nth-child(9)  tbody  tr:nth-child(32)  td:nth-child(2)  input[type=radio]:nth-child(1)")
	protected WebElement optViewDepositAsYes;

	@FindBy(css = "font b")
	protected WebElement msgProductUpdate;

	@FindBy(css = "table.data-table.center thead tr.row--even  th:nth-child(4)")
	protected WebElement lblViewDepositDetailsField;

	@FindBy(css = "table:nth-child(17) tbody tr  td  div  table  tbody  tr:nth-child(1)")
	protected WebElement tblDepositDetailsHeader1;

	@FindBy(css = "table:nth-child(20) tbody tr  td div > table > tbody >tr:nth-child(1)  td")
	protected WebElement msgDepositDetailsInstructions;

	@FindBy(css = "table:nth-child(20) tbody  tr  td  div  table  tbody  tr:nth-child(2)  td  b")
	protected WebElement msgDepositDetailsHeader;

	@FindBy(css = "td >table > tbody > tr:nth-child(1)")
	protected WebElement tblDepositDetailsHeader2;

	@FindBy(css = "table:nth-child(2)  > tbody > tr > td")
	protected WebElement lnkManagerAuditTrailTop;

	@FindBy(id = "title2")
	protected WebElement lblManagerAuditTrailTopCount;

	@FindBy(xpath = "(//td[@id='title2'])[2]")
	protected WebElement lblManagerAuditTrailBottomCount;

	@FindBy(css = "table:nth-child(8) > tbody > tr")
	protected WebElement lnkManagerAuditTrailBottom;

	@FindBy(css = "table:nth-child(5) tbody tr td table tbody tr:nth-child(1)")
	protected WebElement tblManagerAuditTrailHeader;

	@FindBy(css = "table:nth-child(5) tbody tr td table tbody tr:nth-child(2)")
	protected WebElement tblManagerAuditTrailHeaderValues;

	@FindBy(css = "tr:nth-child(2) td:nth-child(3)")
	protected WebElement tblManagerAuditTrailDate;

	@FindBy(css = "table:nth-child(4) tbody tr  td table  tbody  tr:nth-child(1)")
	protected WebElement tblTransTableHeader;

	@FindBy(css = "table:nth-child(4) tbody tr  td table  tbody  tr:nth-child(2)")
	protected WebElement tblTransTableHeaderValues;

	@FindBy(css = "table:nth-child(6) tbody tr  td:nth-child(1) p b")
	protected WebElement tblAccsTableHeader;

	@FindBy(css = "table:nth-child(6) tbody tr  td:nth-child(2)")
	protected WebElement tblAccsTableHeaderValues;

	@FindBy(css = "input[type=submit]")
	protected WebElement btnUpdateDepositDetails;

	@FindBy(xpath = "//form[@name='WebcomServlet']//table//table/tbody/tr[3]/td/table/tbody/tr[1]/td[6]/input")
	protected WebElement chkIsAdmin;

	@FindBy(xpath = "//form[@name='WebcomServlet']//table//table/tbody/tr[3]/td/table/tbody/tr[1]/td[1]/a")
	protected WebElement lnkUserName;

	@FindBy(xpath = "//form[@name='WebcomServlet']//table//table/tbody/tr[3]/td/table/tbody/tr[1]/td[3]")
	protected WebElement txtRole;

	@FindBy(linkText = "Manage Users")
	protected WebElement lnkManageUsers;

	@FindBy(xpath = "//form[@name='WebcomServlet']/table/tbody/tr/td/table/tbody/tr[1]/td/table/tbody/tr/td[3]")
	protected WebElement txtCompanyID;

	@FindBy(css = "body div.content div.page-body table:nth-child(1) thead tr th:nth-child(1)")
	protected WebElement tblCompanyInfo;

	@FindBy(css = "#bodyContent  h3")
	protected WebElement txtPaymentHistory;

	@FindBy(css = "table:nth-child(2) tbody tr td:nth-child(1) table tbody tr td a")
	protected WebElement lnkCustomerDetails;

	@FindBy(css = "table:nth-child(2) tbody tr td:nth-child(2) a")
	protected WebElement lnkStartNewSearch;

	@FindBy(css = "table:nth-child(2) tbody tr td:nth-child(3) a")
	protected WebElement lnkModifySearch;

	@FindBy(css = "table tbody tr:nth-child(3) td table thead")
	protected WebElement tblAllUsers;

	@FindBy(css = "table:nth-child(5) tbody tr td table tbody tr:nth-child(1)")
	protected WebElement tblAddedUsers;

	@FindBy(css = "table:nth-child(6) tbody tr:nth-child(2) td b")
	protected WebElement txtAddConfirmation;

	@FindBy(name = "BranchNumber")
	protected WebElement txtBranchNumber;

	@FindBy(xpath = "//input[@value='Search']")
	protected WebElement btnSearchBranch;

	@FindBy(xpath = "//input[@value='Clear']")
	protected WebElement btnClearBranch;

	@FindBy(xpath = "//input[@value='Add New Branch']")
	protected WebElement btnAddNewBranch;

	@FindBy(css = "div:nth-child(13) table:nth-child(1) tbody tr")
	protected WebElement tblBranchHead;

	@FindBy(css = "table:nth-child(10) tbody tr td")
	protected WebElement txtBranchError;

	@FindBy(name = "branch_number")
	protected WebElement txtBranchId;

	@FindBy(name = "routing_number")
	protected WebElement txtRoutingNumber;

	@FindBy(name = "description")
	protected WebElement txtDescription;

	@FindBy(xpath = "//input[@value='Add']")
	protected WebElement btnAdd;

	@FindBy(name = "commercial")
	protected WebElement chkCommercial;

	@FindBy(css = "table:nth-child(5) tbody tr td")
	protected WebElement txtDuplicateBranchError;

	@FindBy(name = "snDown")
	protected WebElement imgDownBranchNumber;

	@FindBy(name = "snUp")
	protected WebElement imgUpBranchNumber;

	@FindBy(css = "div:nth-child(13) table:nth-child(2) tbody tr td:nth-child(1)")
	protected WebElement cellBranchNumber;

	@FindBy(name = "pnDown")
	protected WebElement imgDownRoutingNumber;

	@FindBy(name = "pnUp")
	protected WebElement imgUpRoutingNumber;

	@FindBy(css = "div:nth-child(13) table:nth-child(2) tbody tr td:nth-child(2)")
	protected WebElement cellRoutingNumber;

	@FindBy(name = "atDown")
	protected WebElement imgDownDescription;

	@FindBy(name = "atUp")
	protected WebElement imgUpDescription;

	@FindBy(css = "div:nth-child(13) table:nth-child(2) tbody tr td:nth-child(4)")
	protected WebElement cellDescription;

	@FindBy(css = "div.nav a:nth-child(2)")
	protected WebElement btnMenuBack;

	@FindBy(xpath = "//a[text()='Delete']")
	protected WebElement lnkDelete;

	@FindBy(id = "confirm-delete-continue")
	protected WebElement btnDeleteContinue;

	@FindBy(id = "confirm-delete")
	protected WebElement lightBoxNew;

	@FindBy(xpath = "//input[@value='Reset']")
	protected WebElement btnReset;

	@FindBy(name = "license_state_id")
	protected WebElement lstLicenseState;

	@FindBy(name = "State")
	protected WebElement lstState;

	@FindBy(xpath = "//*[contains(text(),'User Last Name')]")
	protected WebElement txtUserLastName;

	@FindBy(xpath = "//*[contains(text(),'User Login')]")
	protected WebElement txtUserLogIn;

	@FindBy(xpath = "//*[contains(text(),'User ID')]")
	protected WebElement txtUserIdLock;

	@FindBy(xpath = "//*[contains(text(),'User Name')]")
	protected WebElement txtUserNameColumn;

	@FindBy(css = "table tbody tr:nth-child(8)  td:nth-child(2) i b")
	protected WebElement txtShowDetails;

	@FindBy(xpath = "//input[@value=' Show Details ']")
	protected WebElement btnLockShowDetails;

	@FindBy(css = "#mainMenu ul li.is-active ul")
	protected WebElement mnuSubMenu;

	@FindBy(name = "profile_name")
	protected WebElement lstChooseProfile;

	@FindBy(name = "activity_name")
	protected WebElement lstActivityName;

	@FindBy(css = "table tbody tr:nth-child(5) td:nth-child(2) select")
	protected WebElement lstFilterActivityName;

	@FindBy(css = " table > tbody > tr:nth-child(1) > td:nth-child(2) > input[type=text]")
	protected WebElement txtBoxLastName;

	@FindBy(css = "table tbody tr td:nth-child(6) a")
	protected WebElement lnkViewModify;

	@FindBy(css = "#customerDetail tbody tr td:nth-child(4)")
	protected WebElement txtCurrentStatus;

	@FindBy(css = "#historyItem tbody")
	protected WebElement tblHistoryBody;

	@FindBy(css = "#historyItem thead")
	protected WebElement tblHistoryHeader;

	@FindBy(linkText = "Last")
	protected WebElement lnkLast;

	@FindBy(css = "#contentContainer div.box span:nth-child(3) a:nth-child(4)")
	protected WebElement lnkNext;

	@FindBy(css = "#menu ul li.is-active ul")
	protected WebElement subMenuActions;

	@FindBy(xpath = "//*[@id='historyItem']/tbody/tr/td[1]")
	protected List<WebElement> tblHistorySourceColumn;

	@FindBy(xpath = "//*[@id='historyItem']/tbody/tr/td[2]")
	protected List<WebElement> tblHistoryActivityColumn;

	@FindBy(xpath = "//*[@id='historyItem']/tbody/tr/td[3]")
	protected List<WebElement> tblHistoryDescriptionColumn;

	@FindBy(css = "#contentContainer div.box span:nth-child(2)")
	protected WebElement txtRecords;

	@FindBy(css = "#tblAcct > table:nth-child(1) > tbody > tr > td:nth-child(6)")
	protected List<WebElement> txtAcctNumbers;

	@FindBy(css = "[value=' Get Customer ']")
	protected WebElement btnGetCustomer;

	@FindBy(css = "tr td:nth-child(2) b font")
	protected WebElement msgUpdateDepositDetails;

	@FindBy(css = "h2:nth-child(8)")
	protected WebElement msgImportantText;

	@FindBy(css = "div.statement-disclaimer h3")
	protected WebElement msgNoStatement;

	@FindBy(css = "div.statement-disclaimer p:nth-child(2)")
	protected WebElement msgNoStatementImpSection;

	@FindBy(id = "accounts")
	protected WebElement cmbAtmtAcc;

	@FindBy(css = "tr:nth-child(2) td a")
	protected WebElement lnkEmergencyMsg;

	@FindBy(id = "title")
	protected WebElement txtEmergencyMsgTitle;

	@FindBy(id = "message")
	protected WebElement txtEmergencyMsg;

	@FindBy(name = "start_m")
	protected WebElement txtStartMonth;

	@FindBy(name = "start_d")
	protected WebElement txtStartDate;

	@FindBy(name = "start_y")
	protected WebElement txtStartYear;

	@FindBy(name = "start_hr")
	protected WebElement txtStartHour;

	@FindBy(name = "start_min")
	protected WebElement txtStartMinute;

	@FindBy(name = "end_m")
	protected WebElement txtEndMonth;

	@FindBy(name = "end_d")
	protected WebElement txtEndDate;

	@FindBy(name = "end_y")
	protected WebElement txtEndYear;

	@FindBy(name = "end_hr")
	protected WebElement txtEndHour;

	@FindBy(name = "end_min")
	protected WebElement txtEndMinute;

	@FindBy(id = "privateTarget")
	protected WebElement chkPrivate;

	@FindBy(css = "li.is-active ul li.is-active ul li:nth-child(1) a")
	protected WebElement lnkAccountNumber;

	@FindBy(css = "thead:nth-child(1) tr td b")
	protected WebElement lblAccountNumber;

	@FindBy(css = "tbody:nth-child(4) tr.row--even td:nth-child(2)")
	protected WebElement lblCurrentBalance;

	@FindBy(css = "tbody:nth-child(4) tr.row--odd td:nth-child(2)")
	protected WebElement lblAvailableBalance;

	@FindBy(css = "tr:nth-child(1) > td:nth-child(2) > select")
	protected WebElement lstProductCategory;

	@FindBy(css = "td input[name=\"short_name\"]")
	protected WebElement lblProductShortName;

	@FindBy(css = "table tbody tr:nth-child(1) td:nth-child(1) b")
	protected WebElement lblProductCategory;

	@FindBy(name = "product_id")
	protected WebElement lstProductName;

	@FindBy(css = "table tbody tr:nth-child(2) td:nth-child(1) b")
	protected WebElement lblProductName;

	@FindBy(name = "AcctType")
	protected WebElement txtBoxAccountType;

	@FindBy(css = "table tbody tr:nth-child(3) td:nth-child(1) b")
	protected WebElement lblApplCode;

	@FindBy(css = "table tbody tr:nth-child(4) td:nth-child(1) b")
	protected WebElement lblAccountType;

	@FindBy(name = "product_status")
	protected WebElement lstProductStatus;

	@FindBy(css = "table tbody tr:nth-child(5) td:nth-child(1) b")
	protected WebElement lblProductStatus;

	@FindBy(name = "request_status")
	protected WebElement lstRequestStatus;

	@FindBy(css = "table tbody tr:nth-child(6) td:nth-child(1) b")
	protected WebElement lblRequestStatus;

	@FindBy(name = "recommended_prod")
	protected WebElement lstRecommProduct;

	@FindBy(css = "table tbody tr:nth-child(7) td:nth-child(1) b")
	protected WebElement lblRecommProduct;

	@FindBy(css = "table tbody tr:nth-child(2) td table > tbody > tr:nth-child(2) > td:nth-child(4)")
	protected WebElement tblProductShortName;

	@FindBy(css = "table tbody tr:nth-child(2) td table > tbody > tr:nth-child(2) > td:nth-child(3)")
	protected WebElement tblActType;

	@FindBy(xpath = "//b[contains(text(),'Recommended Product:')]")
	protected WebElement txtRecommendedProduct;

	@FindBy(xpath = "//b[contains(text(),'Apply Eligibility Rules:')]")
	protected WebElement txtApplyEligibilityRules;

	@FindBy(xpath = "//b[contains(text(),'Recommended Product:')]//following::input[1]")
	protected WebElement optionYes;

	@FindBy(css = "form div table:nth-child(9) tbody tr:nth-child(28) td:nth-child(2) input:nth-child(2)")
	protected WebElement optionNo;

	@FindBy(css = "form div table:nth-child(9) tbody tr:nth-child(1) td font b")
	protected WebElement txtApproveError;

	@FindBy(name = "atUp")
	protected WebElement optionAcctSort;

	@FindBy(name = "rsa_user_id")
	protected WebElement lstRsaUserId;

	@FindBy(css = "input[value= Add RSA User]")
	protected WebElement btnAddRSAUser;

	@FindBy(linkText = "PassMark CSR Tool")
	protected WebElement lnkPassMarkCSRTool;

	@FindBy(css = "input[type=submit]")
	protected WebElement btnDeleteRSAUser;

	@FindBy(css = "body div.content div.page-body form b")
	protected WebElement txtMessageDeleteAdd;

	@FindBy(css = " table tbody tr td:nth-child(2)")
	protected List<WebElement> tblCsaNameColumn;

	@FindBy(css = "table tbody tr td:nth-child(3) input")
	protected List<WebElement> tblCsaDeleteColumn;

	@FindBy(css = "#historyItem thead tr th:nth-child(1) a")
	protected WebElement headSource;

	public String auditTrailTransDate = "";
	public String customerLastName = "";
	public String customerSsn = "";
	public String updatedEmail = "";
	public String fieldValue = "";
	public String cycleToDateFee = "";
	public String yearToDateFee = "";
	public String cycleDateVal = "";
	public String activityAcct = "";
	public String acctNumberVal = "";
	public String feeValue = "$0.00";
	public String transDateValue = "";
	public String totalRecodsCount = "";
	public String companyID = "";
	public String defaultValue = "";
	public String defaultEmail = "";
	public String messagePageLevel = "";
	public String defaultState = "";
	public String defaultLicenseState = "";
	public String relationshipCode = "#tblAcct > table:nth-child(1) > tbody > tr:nth-child(p) > td:nth-child(8)";
	public String userTooltip = "i[data-title*='ssn']";
	public String emergencyMsgTitle = "";
	public String emergencyMessageBody = "";
	public String accountNumber = "";
	public String currentBalance = "";
	public String availableBalance = "";
	public String errorMessage = "";

	/**
	 * selectLinkFromTheMenuWebcom To click on link displayed on clicking the main
	 * menu items in Webcom application
	 * 
	 * @param linkText
	 * @throws InterruptedException
	 */
	public void selectLinkFromTheMenuWebcom(String linkText) throws InterruptedException {
		waits.waitForDOMready();
		try {
			waits.waitUntilElementIsPresent(lnkMainMenuWebcom, maxTimeOut);
			wolWebUtil.clickMenuLinkWebcom(lnkMainMenuWebcom, linkText);
			LogUtility.logInfo("---> selectLinkFromTheMenuWebcom <---", "Selected  " + linkText);
		} catch (Exception e) {
			LogUtility.logException("selectLinkFromTheMenuWebcom", "Failed to select link from the Webcom menu", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * loginWebcom: To login to WEBCOM application
	 */
	public boolean loginWebcom() {
		boolean flag = false;
		try {
			String env = navigator.goToUrl(appURL);
			if (env.contains("qa"))
				navigator.goToUrl(getEnvironmentProperty("webcomQA.url"));
			else if (env.contains("stag"))
				navigator.goToUrl(getEnvironmentProperty("webcomStaging.url"));
			waits.waitUntilElementIsPresent(txtUsername, maxTimeOut);
			webActions.setValue(txtUsername, getEnvironmentProperty("webcom.user"));
			webActions.setValue(txtPassword, getEnvironmentProperty("webcom.password"));
			webActions.clickElement(btnLogin);
			if (waits.waitUntilElementIsPresent(txtWelcomeMsg, maxTimeOut)) {
				flag = true;
				LogUtility.logInfo("---> loginWebcom <---", "Logged into Webcom application");
			} else
				LogUtility.logInfo("---> loginWebcom <---", "Failed to Logged into Webcom application");
		} catch (MalformedURLException e) {
			LogUtility.logException("loginWebcom", "Unable to Login to Webcom application", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * selectApplicationCode: To select appl code field value in products approve
	 * page
	 * 
	 * @param value
	 */
	public void selectApplicationCode(String value, String type) {
		try {
			webActions.selectDropDownByText(lstApplCode, value);
			webActions.setValue(txtAcctType, type);
			LogUtility.logInfo("---> selectApplicationCode <---", "Selected value in Appl Code dropdown");
		} catch (Exception e) {
			LogUtility.logException("selectApplicationCode", "Unable to select Application code", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * clickSearchButton: To click on Search button in products approve page
	 */
	public void clickSearchButton() {
		try {
			webActions.clickElement(btnSearch);
			waits.waitUntilElementIsPresent(tblProductApprove, maxTimeOut);
			LogUtility.logInfo("---> clickSearchButton <---", "Clicked on Search Button");
		} catch (Exception e) {
			LogUtility.logException("clickSearchButton", "Unable to click on Search button", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * clickProductApproveView: To click on view link of respective account type
	 * 
	 * @param value- Account Type
	 */
	public void clickProductApproveView(String value) {
		try {
			waits.waitUntilElementIsPresent(tblProductApprove, maxTimeOut);
			webActions.clickElementJS(tblProductApprove);
			waits.waitForDOMready();
			LogUtility.logInfo("---> clickProductApproveView <---",
					"Clicked on View link in Product Maintenance -- List page");
		} catch (Exception e) {
			LogUtility.logException("clickProductApproveView",
					"Unable to click on Product Approve View link in Product Maintenance -- List page", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public void clickEnrollmentView(String value) {
		try {
			waits.waitUntilElementIsPresent(tblEnrollmentQueue, maxTimeOut);
			wolWebUtil.clickOnTableCell(tblEnrollmentQueue, value);
			waits.waitForDOMready();
			LogUtility.logInfo("---> clickEnrollmentView <---",
					"Clicked on View link in Product Maintenance -- List page");
		} catch (Exception e) {
			LogUtility.logException("clickEnrollmentView",
					"Unable to click on Enrollment View link in Product Maintenance -- List page", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * selectTransferEligibility: To set Transfer From & To radio button values
	 * 
	 * @param element- Transfer From/No --Yes/No
	 */
	public void selectTransferEligibility(String element) {
		try {
			switch (element.toUpperCase()) {
			case "FROMYES":
				webActions.clickElement(rdbtnTransferFromYes);
				break;
			case "FROMNO":
				webActions.clickElement(rdbtnTransferFromNo);
				break;
			case "TOYES":
				webActions.clickElement(rdbtnTransferToYes);
				break;
			case "TONO":
				webActions.clickElement(rdbtnTransferToNo);
				break;
			}
			LogUtility.logInfo("---> selectTransferEligibility <---", "Selected Transfer eligibility for a product");
		} catch (Exception e) {
			LogUtility.logException("selectTransferEligibility", "Unable to select Transfer From & To radio buttons", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * clickUpdateButton: To click on Update button in Approve Product page
	 */
	public void clickUpdateButton() {
		try {
			webActions.clickElement(btnUpdate);
			LogUtility.logInfo("---> clickUpdateButton <---", "Clicked on Update Button");
		} catch (Exception e) {
			LogUtility.logException("clickUpdateButton", "Unable to click on Update button", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * clickLogOut: To click on Logout link in WEBCOM application
	 */
	public boolean clickLogOut() {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(lnkLogOut, maxTimeOut))
				webActions.clickElementJS(lnkLogOut);
			else if (waits.waitUntilElementIsPresent(lnkLogOutRSA, maxTimeOut))
				webActions.clickElementJS(lnkLogOutRSA);
			if (waits.waitUntilElementIsPresent(txtLogoutMsg, maxTimeOut)) {
				flag = true;
				LogUtility.logInfo("---> clickLogOut <---", "Clicked on LogOut Button");
			} else
				LogUtility.logInfo("---> clickLogOut <---", "Failed to  Clicked on LogOut Button");
		} catch (Exception e) {
			LogUtility.logException("clickLogOut", "Unable to click on LogOut link in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyPageHeader:- To verify the Page Heading in WEBCOM application pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPageHeader(String message) {
		try {
			waits.staticWait(5);
			waits.waitForPageReadyState();
			WebElement txtHeader = driver.findElement(By.xpath(webcomPageTitle.replaceAll("%s", message)));
			return wolWebUtil.verifyTextContains(txtHeader, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPageHeader", "Unable to verify Page Heading in Webcom application pages", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyConfirmMsg:- To verify the confirmation message in WEBCOM application
	 * pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyConfirmMsg(String message) {
		try {
			WebElement txtConfrmMsg = driver.findElement(By.xpath(webcomConfirmMsg.replaceAll("%s", message)));
			return wolWebUtil.verifyTextContains(txtConfrmMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyConfirmMsg", "Unable to verify Confirmation message in Webcom application",
					e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyDeleteConfirmMsg:- To verify the Delete confirmation message in WEBCOM
	 * application pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyDeleteConfirmMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtDeleteCnfrmMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyDeleteConfirmMsg",
					"Unable to verify Delete Confirmation message in Webcom application", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * searchCustomer:To search the customer in customer Search page of WEBCOM
	 * 
	 * @param searchBy,searchValue:
	 */
	public void searchCustomer(String searchBy, String searchValue) {
		try {
			waits.waitForPageReadyState();
			switch (searchBy) {
			case "CIF":
				webActions.setValue(txtCIFNumber, searchValue);
				break;
			case "CustomerID":
				webActions.setValue(txtCustomerID, searchValue);
				break;
			case "UserID":
				webActions.setValue(txtUserID, searchValue);
				break;
			case "Username":
				webActions.setValue(txtUsernameSearch, searchValue);
				break;
			case "Email":
				webActions.setValue(txtEmail, searchValue);
				break;
			case "SSN":
				webActions.setValue(txtSSN, searchValue);
				break;
			case "Business":
				webActions.setValue(txtBusinessName, searchValue);
				break;
			case "Lastname":
				webActions.setValue(txtLastName, searchValue);
				break;
			case "AccountNumber":
				webActions.setValue(txtAcctNumber, searchValue);
				break;
			}
			webActions.clickElement(btnLogin);
			LogUtility.logInfo("---> searchCustomer <---", "Searched the customer by customer details");
		} catch (Exception e) {
			LogUtility.logException("searchCustomer",
					"Unable to search Customer in Customer Search page of Webcom application", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * deleteCustomer: To delete the customer in Delete Customer From Test
	 * Environment page of WEBCOM
	 * 
	 * @param searchBy,searchValue:
	 */
	public void deleteCustomer(String deleteBy, String deleteValue) {
		try {
			switch (deleteBy) {
			case "BusinessCIF":
				webActions.setValueJs(txtBusinessCIF, deleteValue);
				break;
			case "PersonalCIF":
				webActions.setValueJs(txtPersonalCIF, deleteValue);
				break;
			case "SSN":
				webActions.setValueJs(txtSSNDel, deleteValue);
				break;
			case "TIN":
				webActions.setValueJs(txtTIN, deleteValue);
				break;
			}
			webActions.clickElement(btnLogin);
			LogUtility.logInfo("---> deleteCustomer <---", "Deleted the customer by customer details");
		} catch (Exception e) {
			LogUtility.logException("deleteCustomer",
					"Unable to delete Customer in Delete Customer from Test Environment page of Webcom application", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * acceptAlert: To accept alert pop up in Webcom
	 */
	public void acceptAlert() {
		try {
			if (alerts.isAlertPresent())
				alerts.acceptAlert();
			LogUtility.logInfo("---> acceptAlert <---", "Searched the customer by customer details");
		} catch (Exception e) {
			LogUtility.logException("acceptAlert", "Unable to Accept Alert in Webcom application", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * getResetPasswordValue: To get Reset password value
	 */
	public boolean getResetPasswordValue() {
		boolean flag = false;
		try {
			Set<String> window = driver.getWindowHandles();
			Iterator<String> itr = window.iterator();
			String motherWindow = itr.next();
			String childWindow = itr.next();
			driver.switchTo().window(childWindow);
			waits.waitForDOMready();
			String text = webActions.getText(txtResetPassword);
			int length = text.length();
			String resetPassword = text.substring(length - 5, length - 1);
			setValueInRuntimeDataMap("resetPassword-webcom", resetPassword);
			driver.close();
			driver.switchTo().window(motherWindow);
			if (!resetPassword.isEmpty()) {
				flag = true;
				LogUtility.logInfo("---> getResetPasswordValue <---",
						"Retrieved the Reset password value" + resetPassword);
			} else
				LogUtility.logInfo("---> getResetPasswordValue <---", "Failed to get the Reset Password value");
		} catch (Exception e) {
			LogUtility.logException("getResetPasswordValue",
					"Unable to get the Reset Password Value in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyInactiveConfirmMsg:- To verify the customer Inactive confirmation
	 * message in WEBCOM application pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyInactiveConfirmMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtInactiveMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyInactiveConfirmMsg",
					"Unable to verify Customer Inactive Confirmation message in Webcom application", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyActiveConfirmMsg:- To verify the customer active confirmation message
	 * in WEBCOM application pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyActiveConfirmMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtActiveMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyActiveConfirmMsg",
					"Unable to verify Customer Active Confirmation message in Webcom application", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * updatePersonalDetails: To update Personal Details in Add new customer Page
	 * 
	 * @param personalCIF
	 * @return
	 */
	public boolean updatePersonalDetails(String personalCIF) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddPersonalCIF, maxTimeOut);
			webActions.setValue(txtAddPersonalCIF, personalCIF);
			webActions.clickElementJS(btnViewBackend);
			Set<String> window = driver.getWindowHandles();
			Iterator<String> itr = window.iterator();
			String motherWindow = itr.next();
			String childWindow = itr.next();
			driver.switchTo().window(childWindow);
			waits.waitForDOMready();
			webActions.clickElement(btnUpdateDetails);
			waits.waitForDOMready();
			driver.switchTo().window(motherWindow);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtAddPersonalCIF, "value").equalsIgnoreCase(personalCIF)) {
				flag = true;
				LogUtility.logInfo("---> updatePersonalDetails <---", "Updated Personal Details");
			} else
				LogUtility.logInfo("---> updatePersonalDetails <---", "Failed to Update Personal Details");
		} catch (Exception e) {
			LogUtility.logException("updatePersonalDetails",
					"Unable to Update Personal Details in Add New Customer Page of Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * updateBusinessDetails:To update Business Details in Add new customer Page
	 * 
	 * @param businessCIF
	 * @return
	 */
	public boolean updateBusinessDetails(String businessCIF) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtBusinessCIF, maxTimeOut);
			webActions.setValue(txtBusinessCIF, businessCIF);
			webActions.clickElementJS(btnAddUpdate);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtBusinessCIF, "value").equalsIgnoreCase(businessCIF)) {
				flag = true;
				LogUtility.logInfo("---> updateBusinessDetails <---", "Updated Business Details");
			} else
				LogUtility.logInfo("---> updateBusinessDetails <---", "Failed to Update Business Details");
		} catch (Exception e) {
			LogUtility.logException("updateBusinessDetails",
					"Unable to Update Business Details in Add New Customer Page of Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * enterEmail: To update Email ID in Add new customer Page
	 * 
	 * @param email
	 * @return
	 */
	public boolean enterEmail(String email) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtEmail, maxTimeOut);
			webActions.setValue(txtEmail, email);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtEmail, "value").equalsIgnoreCase(email)) {
				flag = true;
				LogUtility.logInfo("---> enterEmail <---", "Entered Email address");
			} else
				LogUtility.logInfo("---> enterEmail <---", "Failed to Enter Email Value");
		} catch (Exception e) {
			LogUtility.logException("enterEmail",
					"Unable to Update Email ID in Add New Customer Page of Webcom application", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * selectCustomerChannel: To select customer Channel type in Add new customer
	 * Page
	 * 
	 * @param channel
	 */
	public void selectCustomerChannel(String channel) {
		try {
			waits.waitUntilElementIsPresent(rdbtnBusiness, maxTimeOut);
			if (channel.equalsIgnoreCase("Personal")) {
				webActions.clickElementJS(rdbtnPersonal);
				LogUtility.logInfo("---> selectCustomerChannel <---", "Selected customer channel as personal");
			} else {
				webActions.clickElementJS(rdbtnBusiness);
				LogUtility.logInfo("---> selectCustomerChannel <---", "Selected customer channel as Business");
			}
		} catch (Exception e) {
			LogUtility.logException("selectCustomerChannel",
					"Unable to select customer Channel type in Add New Customer Page of Webcom application", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public boolean getUsername() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtUsernameSearch, maxTimeOut);
			String newCustomer = webActions.getAttributeValue(txtUsernameSearch, "value");
			setValueInRuntimeDataMap("newCustomer-webcom", newCustomer);
			if (!newCustomer.isEmpty()) {
				flag = true;
				LogUtility.logInfo("---> getUsername <---", "Retrieved user name value " + newCustomer);
			} else
				LogUtility.logInfo("---> getUsername <---", "Failed to retrieve username");
		} catch (Exception e) {
			LogUtility.logException("getUsername", "Unable to get User Name in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean getLoginPassword() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddCustomerConfrmMsg, maxTimeOut);
			String text = webActions.getText(txtAddCustomerConfrmMsg);
			String firstPassword = text.substring(text.length() - 5, text.length() - 1);
			setValueInRuntimeDataMap("firstPassword-webcom", firstPassword);
			if (!firstPassword.isEmpty()) {
				flag = true;
				LogUtility.logInfo("---> getLoginPassword <---", "Retrieved Password value " + firstPassword);
			} else
				LogUtility.logInfo("---> getLoginPassword <---", "Failed to retrieve password value");
		} catch (Exception e) {
			LogUtility.logException("getLoginPassword", "Unable to retrieve Password value in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public void clickCreateButton() {
		try {
			waits.waitUntilElementIsPresent(btnCreate, maxTimeOut);
			webActions.clickElementJS(btnCreate);
			LogUtility.logInfo("---> clickCreateButton <---", "Clicked on Create customer button");
		} catch (Exception e) {
			LogUtility.logException("clickCreateButton",
					"Unable to click on Create customer button in Webcom application", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public void clickProcessButton() {
		try {
			waits.waitUntilElementIsPresent(btnProcess, maxTimeOut);
			webActions.clickElementJS(btnProcess);
			LogUtility.logInfo("---> clickProcessButton <---", "Clicked on Process button");
		} catch (Exception e) {
			LogUtility.logException("clickCreateButton", "Unable to click on Process button in Webcom application", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/*
	 * click On Search From CustomerRequestActivites Results List
	 */
	public void clickOnSearchFromCustomerRequestActivitesResult() {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			webActions.clickElement(btnSearchForCustReqMenu);
			LogUtility.logInfo("---> clickOnOptionsFromCustomerRequestActivitesResult <---",
					"Clicked on search Button from customer request activities result");
		} catch (Exception e) {
			LogUtility.logException("clickOnSearchFromCustomerRequestActivitesResult",
					"Unable to click on Search from Customer Request Activites Results List in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * click On Search From CustomerRequestActivites Results List
	 * 
	 * @throws Exception
	 */
	public void selectTheRequestType(String requestType) throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			webActions.selectDropDownByText(selRequestTypes, requestType);
			LogUtility.logInfo("---> selectTheRequestType <---", "Selected the request type as " + requestType);
		} catch (Exception e) {
			LogUtility.logException("selectTheRequestType", "Unable to select the Request Type in Webcom application",
					e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * @param requestType
	 * @throws Exception
	 */
	public void clickOnSearchButtonInCustomerReqSearchResultMainPage() throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			webActions.clickElement(btnSearchForCustReq);
			LogUtility.logInfo("---> clickOnNextButtonInSearchResult <---",
					"Clicked on the search button in main page for customer request activities search result");
		} catch (Exception e) {
			LogUtility.logException("clickOnSearchButtonInCustomerReqSearchResultMainPage",
					"Unable to click On Search Button in Customer Requirement Search Result Main page in Webcom application",
					e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * selectApplCode: To select appl code field value in products approve page
	 * 
	 * @param value
	 */
	public void selectApplCode(String value) {
		try {
			webActions.selectDropDownByText(lstApplCode, value);
			LogUtility.logInfo("---> selectApplCode <---", "Selected value in Appl Code dropdown");
		} catch (Exception e) {
			LogUtility.logException("selectApplCode", "Unable to select Application Code in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Returns the CIF number
	 * 
	 * @return
	 */
	public String getCIFNumber(String userType) {
		try {
			if (userType.equalsIgnoreCase("Business"))
				cifNumber = webActions.getText(txtCIFNumberMainPage);
			else
				cifNumber = webActions.getAttributeValue(inputCIFNumber, "value");
			LogUtility.logInfo("---> getCIFNumber <---", "CIF retrieved " + cifNumber);
		} catch (Exception e) {
			LogUtility.logException("getCIFNumber", "Unable to get CIF number in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return cifNumber;
	}

	/**
	 * checks for the message
	 * 
	 * @param msg
	 * @return
	 */
	public boolean checkForTheMessage(String msg) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtSwitchMessage, maxTimeOut);
			if (wolWebUtil.verifyText(txtSwitchMessage, msg)) {
				LogUtility.logInfo("---> checkForTheMessage <---", msg + " is found");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkForTheMessage", "Unable to check for the messages in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks for the message
	 * 
	 * @param msg
	 * @return
	 */
	public boolean enterCIFNumber() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(inputCIFNumber, maxTimeOut)) {
				webActions.setValue(inputCIFNumber, cifNumber);
				LogUtility.logInfo("---> enterCIFNumber <---", cifNumber + " is entered as CIF");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterCIFNumber", "Unable to Enter CIF Number in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * clicks on save button
	 * 
	 * @return
	 */
	public boolean clickOnSaveButton() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnSave, maxTimeOut)) {
				webActions.clickElement(btnSave);
				LogUtility.logInfo("---> clickOnSaveButton <---", "Clicked on save button");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnSaveButton", "Unable to click on Save button in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * clicks on Customer ID Link
	 * 
	 * @return
	 */
	public boolean clickCustomerID() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(lnkCustomerID, maxTimeOut)) {
				webActions.clickElement(lnkCustomerID);
				LogUtility.logInfo("---> clickCustomerID <---", "Clicked on CustomerID link");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickCustomerID", "Unable to click on Customer ID in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Ravi Maddula
	 * 
	 */

	public boolean enterUserName(String userName) {
		boolean flag = false;
		try {
			boolean user = webActions.isDisplayed(txtUserName);
			if (user) {
				webActions.setValue(txtUserName, userName);
				LogUtility.logInfo("---> enterUserName <---", "Entered " + userName + " as user name");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterUserName", "Unable to Enter User Name in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickShowDetails() {
		boolean flag = false;
		try {
			boolean button = webActions.isDisplayed(btnShowDetails);
			if (button) {
				webActions.clickElement(btnShowDetails);
				LogUtility.logInfo("---> clickShowDetails <---", "Clicked on show details button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterUserName", "Unable to Click on Show Details button in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean selectTransactionName(String selectValue) {
		boolean flag = false;
		try {
			boolean transaction = webActions.isDisplayed(lstTransactionType);
			if (transaction) {
				webActions.selectDropDownByText(lstTransactionType, selectValue);
				LogUtility.logInfo("---> selectTransactionName <---",
						"Selected " + selectValue + " from transaction name drop down");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectTransactionName", "Unable to select Transaction Name in Webcom application",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean auditTrailDetails() {
		boolean flag = false;
		try {
			boolean recordsCount = webActions.isDisplayed(txtAuditCount);
			if (recordsCount) {
				LogUtility.logInfo("---> auditTrailDetails <---", "Audit Trail records are available");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("auditTrailDetails", "Unable to check Audit Trail records in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickOnViewLink() {
		boolean flag = false;
		try {
			boolean viewLink = webActions.isDisplayed(lnkView);
			if (viewLink) {
				webActions.clickElement(lnkView);
				LogUtility.logInfo("---> clickOnViewLink <---", "Clicked on view link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewLink", "Unable to click on View Link in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyInformationTable() {
		boolean flag = false;
		try {
			boolean recordsCount = webActions.isDisplayed(tblInformation);
			if (recordsCount) {
				LogUtility.logInfo("---> verifyinformationTable <---", "User information table available");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyInformationTable",
					"Unable to verify Information Table in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickLeftMenu(String linkName) {
		boolean flag = false;
		try {
			boolean viewLink = webActions.isDisplayed(mnuRight);
			if (viewLink) {
				wolWebUtil.selectLinkFromList(mnuRight, linkName);
				LogUtility.logInfo("---> clickLeftMenu <---", "Clicked on view link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickLeftMenu", "Unable to click Left Menu link in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickLeftSubMenu(String linkName) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(subMnuRight);
			boolean viewLink = webActions.isDisplayed(subMnuRight);
			if (viewLink) {
				wolWebUtil.selectLinkFromList(subMnuRight, linkName);
				LogUtility.logInfo("---> clickLeftSubMenu <---", "Clicked on view link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickLeftSubMenu", "Unable to click Left Sub Menu link in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean enterUserID(String userId) {
		boolean flag = false;
		try {
			boolean user = webActions.isDisplayed(txtUserId);
			if (user) {
				webActions.setValue(txtUserId, userId);
				LogUtility.logInfo("---> enterUserID <---", "Entered " + userId + " as user ID");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterUserID", "Unable to enter User ID in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean updateEmail(String emailId) {
		boolean flag = false;
		try {
			boolean email = webActions.isDisplayed(txtEmailId);
			if (email) {
				webActions.clearValue(txtEmailId);
				updatedEmail = wolWebUtil.dynamicData() + emailId;
				webActions.setValue(txtEmailId, updatedEmail);
				LogUtility.logInfo("---> updateEmail <---", "Entered " + updatedEmail + " as email ID");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("updateEmail", "Unable to update Email in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickSaveButton() {
		boolean flag = false;
		try {
			boolean button = webActions.isDisplayed(btnSave);
			if (button) {
				webActions.clickElement(btnSave);
				LogUtility.logInfo("---> clickSaveButton <---", "Clicked on save button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickSaveButton", "Unable to click on Save button in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyUpdateMessage(String message) {
		boolean flag = false;
		try {
			boolean updateMessage = webActions.isDisplayed(txtUpdateMessage);
			if (updateMessage) {
				String messageUpdated = webActions.getText(txtUpdateMessage);
				String values[] = messageUpdated.split(":");
				fieldValue = values[1];
				return wolWebUtil.verifyTextContains(txtUpdateMessage, message);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyUpdateMessage", "Unable to verify Updated message in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean enterAcctNumber(String accountNumber) {
		boolean flag = false;
		try {
			boolean actNumber = webActions.isDisplayed(txtAcctNumber);
			if (actNumber) {
				webActions.setValue(txtAcctNumber, accountNumber);
				LogUtility.logInfo("---> enterAcctNumber <---", "Entered account number into account number field");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterAcctNumber",
					"Unable to enter Account Number into account number field in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyDetails() {
		boolean flag = false;
		try {
			webActions.isDisplayed(txtSsnNumber);
			webActions.isDisplayed(txtEmailId);
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("verifyDetails", "Unable to verify details in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean enterLastName(String lastName) {
		boolean flag = false;
		try {
			customerLastName = lastName;
			boolean lName = webActions.isDisplayed(txtLastName);
			if (lName) {
				webActions.setValue(txtLastName, lastName);
				LogUtility.logInfo("---> enterLastName <---", "Entered last name into last name field");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterLastName",
					"Unable to enter last name into last name field in Webcom application", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public void customerDetails(String title) {
		try {
			waits.waitUntilElementIsPresent(txtHeader, maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtHeader, title)) {
				webActions.clickElement(btnCustomerDetails);
				LogUtility.logInfo("---> customerDetails <---", "Clicked on Customer Details from " + title + " Page");
			}
		} catch (Exception e) {
			LogUtility.logException("customerDetails", "Unable to enter Customer Details in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyTitle(String title) {
		boolean flag = false;
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			waits.waitUntilElementIsPresent(txtHeader, maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtHeader, title)) {
				LogUtility.logInfo("---> verifyTitle <---", "Verified Customer Details Page title");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTitle", "Unable to verify Customer Details Page title in Webcom application",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyLastName() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtLastNameVal, maxTimeOut);
			boolean lName = webActions.isDisplayed(txtLastNameVal);
			if (lName) {
				String lastNameVal = webActions.getAttributeValue(txtLastNameVal, "value");
				if (lastNameVal.contains(customerLastName)) {
					LogUtility.logInfo("---> verifyLastName <---", "Verified last name value from customer details");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTitle",
					"Unable to verify last name value from customer details in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean enterSsnValue(String ssnValue) {
		boolean flag = false;
		try {
			customerSsn = ssnValue;
			boolean lName = webActions.isDisplayed(txtSsnNumber);
			if (lName) {
				webActions.setValue(txtSsnNumber, ssnValue);
				LogUtility.logInfo("---> enterSsnValue <---", "Entered SSN value into SSN/TIN field");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterSsnValue",
					"Unable to enter SSN value into SSN/TIN field in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifySsnValue() {
		boolean flag = false;
		try {
			boolean ssnVal = webActions.isDisplayed(txtSsnNumber);
			if (ssnVal) {
				String ssnValue = webActions.getAttributeValue(txtSsnNumber, "value");
				if (ssnValue.equalsIgnoreCase(customerSsn)) {
					LogUtility.logInfo("---> verifySsnValue <---", "Verified SSN value from customer details");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifySsnValue",
					"Unable to verify SSN value from customer details in Webcom application", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean updateSsnValue(String updateSsn) {
		boolean flag = false;
		try {
			boolean lName = webActions.isDisplayed(txtSsnNumber);
			if (lName) {
				webActions.clearValue(txtSsnNumber);
				webActions.setValue(txtSsnNumber, updateSsn);
				LogUtility.logInfo("---> updateSsnValue <---", "Updated SSN value into SSN/TIN field");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("updateSsnValue",
					"Unable to update SSN value into SSN/TIN field in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean enterBusinessName(String businessName) {
		boolean flag = false;
		try {
			boolean lName = webActions.isDisplayed(txtBusinessName);
			if (lName) {
				webActions.setValue(txtBusinessName, businessName);
				LogUtility.logInfo("---> enterBusinessName <---", "Entered Business Name successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterBusinessName", "Unable to enter Business Name in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyColumnNames(List<String> listValue) {
		boolean flag = false;
		try {
			boolean header = webActions.isDisplayed(tblHeader);
			if (header) {
				List<WebElement> columns = tblHeader.findElements(By.tagName("tr"));
				List<WebElement> columnNames = columns.get(0).findElements(By.tagName("th"));
				int columnNamesSize = columnNames.size();
				int listValueSize = listValue.size();
				for (int colNum = 0; colNum < columnNamesSize; colNum++) {
					String columnName = columnNames.get(colNum).getText();
					for (int listoption = 0; listoption < listValueSize; listoption++) {
						String listValues = listValue.get(listoption);
						if (listValues.contains(columnName)) {
							LogUtility.logInfo("---> verifyColumnNames <---", "Verified values from column");

						}
					}
				}
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyColumnNames", "Unable to verify Column Names in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickAuthorizedAccess() {
		boolean flag = false;
		try {
			boolean button = webActions.isDisplayed(btnAuthorized);
			if (button) {
				webActions.clickElement(btnAuthorized);
				LogUtility.logInfo("---> clickAuthorizedAccess <---", "Clicked on authorized access button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickAuthorizedAccess",
					"Unable to click on Authorized Access button in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyBusinessDetails() {
		boolean flag = false;
		try {
			boolean business = webActions.isDisplayed(tblBusiness);
			if (business) {
				LogUtility.logInfo("---> verifyBusinessDetails <---", "Verified Business section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyBusinessDetails", "Unable to verify Busines details in Webcom application",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyCustomerDetails() {
		boolean flag = false;
		try {
			boolean business = webActions.isDisplayed(tblCustomer);
			if (business) {
				LogUtility.logInfo("---> verifyCustomerDetails <---", "Verified customer section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyBusinessDetails", "Unable to verify Customer details in Webcom application",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyBusinessInfo() {
		boolean flag = false;
		try {
			boolean businessInfo = webActions.isDisplayed(tblBusinessInfo);
			if (businessInfo) {
				LogUtility.logInfo("---> verifyBusinessInfo <---", "Verified customer business section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyBusinessInfo",
					"Unable to verify Busines Information details in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyStatementPeriod() {
		boolean flag = false;
		try {
			boolean businessInfo = webActions.isDisplayed(lstStatement);
			if (businessInfo) {
				LogUtility.logInfo("---> verifyStatementPeriod <---", "Verified list statement period");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStatementPeriod",
					"Unable to verify List Statement Period in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean enterStatementAcctNumber(String accountNumber) {
		boolean flag = false;
		try {
			boolean acctNumber = webActions.isDisplayed(txtAccountId);
			if (acctNumber) {
				webActions.setValue(txtAccountId, accountNumber);
				LogUtility.logInfo("---> enterStatementAcctNumber <---", "Entered account number");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterStatementAcctNumber",
					"Unable to enter Statement Account Number in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean enterStatementITRTaxID(String taxID) {
		boolean flag = false;
		try {
			boolean acctNumber = webActions.isDisplayed(txtTaxId);
			if (acctNumber) {
				webActions.setValue(txtTaxId, taxID);
				LogUtility.logInfo("---> enterStatementITRTaxID <---", "Entered ITR Tax ID");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterStatementITRTaxID",
					"Unable to enter Statement ITR Tax ID in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickViewStatement() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnViewStatement, maxTimeOut);
			boolean acctNumber = webActions.isDisplayed(btnViewStatement);
			if (acctNumber) {
				webActions.clickElement(btnViewStatement);
				LogUtility.logInfo("---> clickViewStatement <---", "Clicked on view statement button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickViewStatement",
					"Unable to click on View Statement button in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyHeader(String header) {
		boolean flag = false;
		try {
			boolean acctNumber = webActions.isDisplayed(txtCusStatement);
			if (acctNumber) {
				String statement = webActions.getText(txtCusStatement);
				if (statement.equals(header)) {
					LogUtility.logInfo("---> verifyHeader <---", "Verified header of the statement successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyHeader", "Unable to verify Header of the Statement in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean clickPrintPreview() {
		boolean flag = false;
		try {
			boolean acctNumber = webActions.isDisplayed(btnPrintPreview);
			if (acctNumber) {
				webActions.clickElement(btnPrintPreview);
				LogUtility.logInfo("---> clickPrintPreview <---", "Clicked on print preview button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickPrintPreview",
					"Unable to click on Print Preview button in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Ravi Maddula
	 * 
	 */
	public boolean verifyPreviewPageTitle(String pageTitle) {
		boolean flag = false;
		try {
			if (wolWebUtil.verifyPageTitleOfChildWindow(pageTitle)) {
				LogUtility.logInfo("---> verifyPreviewPageTitle <---", "Verified Print Preview Page title");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPreviewPageTitle",
					"Unable to verify Print Preview Page Title in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;

	}

	public boolean searchButtonClick() {
		boolean flag = false;
		try {
			boolean acctNumber = webActions.isDisplayed(btnSearch);
			if (acctNumber) {
				webActions.clickElement(btnSearch);
				LogUtility.logInfo("---> searchButtonClick <---", "Clicked on Search button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("searchButtonClick", "Unable to click on Search button in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyCheckImage() {
		boolean flag = false;
		try {
			boolean checkImage = webActions.isDisplayed(imgCheck);
			if (checkImage) {
				webActions.clickElement(imgCheck);
				LogUtility.logInfo("---> verifyCheckImage <---", "Clicked on Image link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCheckImage", "Unable to click on Image link in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyImagePopUp() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lightBox, maxTimeOut);
			boolean imagePopUp = webActions.isDisplayed(lightBox);
			if (imagePopUp) {
				webActions.clickElement(btnClose);
				LogUtility.logInfo("---> verifyImagePopUp <---", "Verified Pop-up and closed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyImagePopUp", "Unable to verify Pop-up in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyCycleToDate() {
		boolean flag = false;
		try {
			boolean imagePopUp = webActions.isDisplayed(txtCycleToDate);
			if (imagePopUp) {
				cycleToDateFee = webActions.getText(txtCycleToDate);
				if (cycleToDateFee.equals(feeValue)) {
					LogUtility.logInfo("---> verifyCycleToDate <---", "Verified Cycle to date fee " + cycleToDateFee);
					flag = true;
				} else {
					LogUtility.logInfo("---> verifyCycleToDate <---", "Failed to verify Cycle to date fee ");

				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCycleToDate", "Unable to verify Cycle To Date Fee in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyYearToDate() {
		boolean flag = false;
		try {
			boolean imagePopUp = webActions.isDisplayed(txtYearToDate);
			if (imagePopUp) {
				cycleToDateFee = webActions.getText(txtYearToDate);
				if (cycleToDateFee.equals(feeValue)) {
					LogUtility.logInfo("---> verifyYearToDate <---", "Verified year to date fee " + cycleToDateFee);
					flag = true;
				} else {
					LogUtility.logInfo("---> verifyYearToDate <---", "Failed to verify year to date fee ");
					return flag;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyYearToDate", "Unable to verify Year To Date Fee in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectByDate() {
		boolean flag = false;
		try {
			boolean dateBy = webActions.isDisplayed(optByDate);
			if (dateBy) {
				if (!webActions.isChecked(optByDate)) {
					webActions.clickElement(optByDate);
				}
				LogUtility.logInfo("---> selectByDate <---", "Clicked on By Date radio button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectByDate", "Unable to click on By Date radio button in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectByCategory() {
		boolean flag = false;
		try {
			boolean cateBy = webActions.isDisplayed(optByCategory);
			if (cateBy) {
				if (!webActions.isChecked(optByCategory)) {
					webActions.clickElement(optByCategory);
				}
				LogUtility.logInfo("---> selectByCategory <---", "Clicked on By Category radio button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectByCategory",
					"Unable to click on By Category radio button in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyDate() {
		boolean flag = false;
		try {
			boolean cycledate = webActions.isDisplayed(txtCycleDate);
			if (cycledate) {
				cycleDateVal = webActions.getText(txtCycleDate);
				if (cycleDateVal != null) {
					LogUtility.logInfo("---> verifyDate <---", "Cycle Date verified successfully " + cycleDateVal);
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDate", "Unable to verify Cycle Date in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyNameAndAddress() {
		boolean flag = false;
		try {
			boolean checkAddress = webActions.isDisplayed(txtStatAddress);
			if (checkAddress) {
				LogUtility.logInfo("---> verifyNameAndAddress <---", "Verified name and address section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNameAndAddress",
					"Unable to verify Name and Address section in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyAccountActivity() {
		boolean flag = false;
		try {
			boolean checkActivity = webActions.isDisplayed(txtAcctActivity);
			if (checkActivity) {
				activityAcct = webActions.getText(txtAcctActivity);
				if (activityAcct != null) {
					LogUtility.logInfo("---> verifyAccountActivity <---",
							"Verified account activity text " + activityAcct);
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountActivity",
					"Unable to verify Account Activity text in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyCustomerService() {
		boolean flag = false;
		try {
			boolean custService = webActions.isDisplayed(txtCustServiceSection);
			if (custService) {
				LogUtility.logInfo("---> verifyCustomerService <---", "Verified customer service section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCustomerService",
					"Unable to verify Customer Service section in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyAccountNumber() {
		boolean flag = false;
		try {
			acctNumberVal = webActions.getText(txtStatAcctNumber);
			if (acctNumberVal != null) {
				LogUtility.logInfo("---> verifyAccountNumber <---", "Verified account number " + acctNumberVal);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountNumber", "Unable to verify Account Number in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySummary() {
		boolean flag = false;
		try {
			boolean summary = webActions.isDisplayed(txtAcctSummary);
			if (summary) {
				LogUtility.logInfo("---> verifySummary <---", "Verified Account Summary section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySummary", "Unable to verify Account Summary section in Webcom application",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyInterest() {
		boolean flag = false;
		try {
			boolean custService = webActions.isDisplayed(txtInterestTable);
			if (custService) {
				LogUtility.logInfo("---> verifyInterest <---", "Verified Account Interest section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyInterest", "Unable to verify Account Interest section in Webcom application",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyTansactions() {
		boolean flag = false;
		try {
			boolean transTable = webActions.isDisplayed(txtTransactionsTable);
			if (transTable) {
				LogUtility.logInfo("---> verifyTansactions <---", "Verified Transactions Table section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTansactions",
					"Unable to verify Transactions Table section in Webcom application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyChecksPaid() {
		boolean flag = false;
		try {
			boolean custService = webActions.isDisplayed(txtChecksTable);
			if (custService) {
				LogUtility.logInfo("---> verifyChecksPaid <---", "Verified Checks Paid section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyChecksPaid", "Unable to verify Checks Paid section in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyFeeSummary() {
		boolean flag = false;
		try {
			boolean custService = webActions.isDisplayed(txtFeeSummaryTable);
			if (custService) {
				LogUtility.logInfo("---> verifyFeeSummary <---", "Verified Fee Summary section");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFeeSummary", "Unable to verify Fee Summary section in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyPageTitle(String titleOfPage) {
		boolean flag = false;
		try {
			String pageTitle = webActions.getText(txtHeader);
			if (pageTitle.equals("All Customer - Statement Search")) {
				webActions.clickElement(btnViewStatements);
				LogUtility.logInfo("---> verifyPageTitle <---",
						"Clicked on View statements from All Customer - Statement Search page");
				waits.waitForDOMready();
				return wolWebUtil.verifyTextContains(txtHeader, titleOfPage);
			} else {
				waits.waitForDOMready();
				return wolWebUtil.verifyTextContains(txtHeader, titleOfPage);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPageTitle", "Unable to verify page Title in Webcom application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @param ssn
	 * @return
	 */
	public boolean verifyEquifaxSSNValue(String ssn) {
		return wolWebUtil.verifyText(txtEquifaxSSN, ssn, "verifyEquifaxSSNValue");
	}

	/**
	 * @return
	 */
	public boolean verifyEquifaxDOBValue() {

		return wolWebUtil.verifyText(txtEquifaxDOB,
				wolWebUtil.changeTheDatePattern("yyyy-MM-dd", "MM/dd/yyyy", testDataMap.get("Date of Birth")),
				"verifyEquifaxDOBValue");
	}

	/**
	 * @param ssn
	 * @return
	 */
	public boolean verifyEnrollmentSSNValue(String ssn) {
		if (ssn.isEmpty())
			ssn = new EnrollmentPage().ssn;
		return wolWebUtil.verifyText(txtEnrollmentSSN, ssn, "verifyEnrollmentSSNValue");
	}

	/**
	 * @return
	 */
	public boolean verifyEnrollmentDOBValue() {

		return wolWebUtil.verifyText(txtEnrollmentDOB,
				wolWebUtil.changeTheDatePattern("yyyy-MM-dd", "MM/dd/yyyy", testDataMap.get("Date of Birth")),
				"verifyEnrollmentDOBValue");
	}

	/**
	 * @return
	 */
	public boolean verifyEquifaxReasonCodes() {
		return wolWebUtil.verifyText(txtEquifaxReasonCode, "21", "verifyEquifaxSSNValue");
	}

	/**
	 * @return
	 */
	public boolean verifyEquifaxFailReasonCodes() {
		return wolWebUtil.verifyText(txtEquifaxReasonCode, "08", "verifyEquifaxSSNValue");
	}

	/**
	 * To select the Product type
	 *
	 * Veerababu Pedireddi
	 */
	public boolean selectProductType(String selectValue) {
		boolean flag = false;
		try {
			boolean product = webActions.isDisplayed(lstProductType);
			if (product) {
				webActions.selectDropDownByText(lstProductType, selectValue);
				LogUtility.logInfo("---> selectProductType <---",
						"Selected value: " + selectValue + " from Product type drop-down");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectProductType", selectValue + " is not selected", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Product type
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyProductType(String productType) {
		try {
			return wolWebUtil.verifyText(lblProductType, productType);
		} catch (Exception e) {
			LogUtility.logException("verifyProductType", productType + " is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Product update message
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyProductUpdateMessage(String message) {
		try {
			return wolWebUtil.verifyText(msgProductUpdate, message);
		} catch (Exception e) {
			LogUtility.logException("verifyProductUpdateMessage", message + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To click on View Deposit details as No
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean selectNoForDepositDetails() {
		boolean flag = false;
		try {
			boolean depositDetails = webActions.isDisplayed(optViewDepositAsNo);
			if (depositDetails) {
				webActions.clickElement(optViewDepositAsNo);
				LogUtility.logInfo("---> selectNoForDepositDetails <---", "Select No option for Deposit Details");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectNoForDepositDetails", "Unable to select No for Deposit Details", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on View Deposit details as No
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean selectYesForDepositDetails() {
		boolean flag = false;
		try {
			boolean depositDetails = webActions.isDisplayed(optViewDepositAsYes);
			if (depositDetails) {
				webActions.clickElement(optViewDepositAsYes);
				LogUtility.logInfo("---> selectNoForDepositDetails <---", "Select Yes option for Deposit Details");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectYesForDepositDetails", "Unable to select Yes for Deposit Details", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter Account number in Search customer details page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean enterAccountNumber(String accountNumber) {
		boolean flag = false;
		try {
			boolean accNumber = webActions.isDisplayed(txtAcctNumber);
			if (accNumber) {
				webActions.setValue(txtAcctNumber, accountNumber);
				LogUtility.logInfo("---> enterAccountNumber <---", "Account Number entered successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterAccountNumber", accountNumber + " not entered", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the View Deposit Details enrollment as No in Webster Accounts Page
	 * 
	 * Veerababu Pedireddi
	 */

	public boolean verifyViewDepositDetailsFieldAndValue(String viewDepositDetails, String value, String account) {
		boolean flag = false;
		try {
			String depositDetailsField = webActions.getText(lblViewDepositDetailsField);
			WebElement lblDepositDetailsValue = driver
					.findElement(By.xpath(String.format(viewDepositDetailsSts, account)));
			String depositDetailsValue = webActions.getText(lblDepositDetailsValue);
			if (depositDetailsField.equals(viewDepositDetails) && depositDetailsValue.equals(value)) {
				flag = true;
				LogUtility.logInfo("---> verifyViewDepositDetailsFieldAndValue <---",
						"View Deposit Details field and Value is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyViewDepositDetailsFieldAndValue",
					viewDepositDetails + "field displayed " + value + " status " + account, e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the First Table header columns in View Deposit Details Preferences
	 * Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyHeader1ColumnNamesInDepositDetails(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblDepositDetailsHeader1, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyColumnNamesDepositDetails", "Unable to display the values", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Instructions message in View Deposit Details Preferences page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyInstructionsMessage(String message) {
		try {
			return wolWebUtil.verifyText(msgDepositDetailsInstructions, message);
		} catch (Exception e) {
			LogUtility.logException("verifyInstructionsMessage", message + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the View Deposit Details Header message in View Deposit Details
	 * Preferences page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyDepositDetailsHeaderMessage(String message) {
		try {
			return wolWebUtil.verifyText(msgDepositDetailsHeader, message);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositDetailsHeaderMessage", message + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Header columns in View Deposit Details Preferences page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyHeader2ColumnNamesInDepositDetails(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblDepositDetailsHeader2, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyHeader2ColumnNamesInDepositDetails", "Unable to display the values", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Enroll account is checked in View Deposit Details Preferences
	 * page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyEnrollAccountChecked(String account) {
		try {
			WebElement tblDepositDetailsEnrollAcc = driver.findElement(By.xpath(String.format(accountStatus, account)));
			return webActions.isChecked(tblDepositDetailsEnrollAcc);
		} catch (Exception e) {
			LogUtility.logException("verifyEnrollAccountChecked", account + " number is not Checked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Top of the Page Links in Manage Audit Trail Page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyTopLinksInAuditTrailPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(lnkManagerAuditTrailTop, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyTopLinksInAuditTrailPage",
					"Unable to verify Top links in Audit Trail page of webcom application", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * To verify the Bottom of the Page Links in Manage Audit Trail Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyBottomLinksInAuditTrailPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(lnkManagerAuditTrailBottom, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyBottomLinksInAuditTrailPage",
					"Unable to verify Bottom links in Audit Trail page of webcom application", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * To verify the Top of the Page Total Records text in Manage Audit Trail Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyTotalRecordsTextInTopPage(String text) {
		try {
			totalRecodsCount = webActions.getText(lblManagerAuditTrailTopCount);
			return wolWebUtil.verifyTextContains(lblManagerAuditTrailTopCount, text);
		} catch (Exception e) {
			LogUtility.logException("verifyTotalRecordsTextInTopPage",
					"Total Records Text: " + text + " is not displayed in Top of Page", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Bottom of the Page Total Records text in Manage Audit Trail
	 * Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyTotalRecordsTextInBottomPage(String text) {
		try {
			totalRecodsCount = webActions.getText(lblManagerAuditTrailBottomCount);
			return wolWebUtil.verifyTextContains(lblManagerAuditTrailBottomCount, text);
		} catch (Exception e) {
			LogUtility.logException("verifyTotalRecordsTextInBottomPage",
					"Total Records Text: " + text + " is not displayed in Bottom of Page", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the column names in Manage Audit Trail Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyColumnNamesInAuditTrailPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblManagerAuditTrailHeader, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyColumnNamesInAuditTrailPage",
					"Unable to display the column names in Manage Audit Trail Page", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the column values in Manage Audit Trail Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyColumnValuesInAuditTrailPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblManagerAuditTrailHeader, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyTransactioDateInAuditTrailPage",
					"Unable to display the column values in Manage Audit Trail Page", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Transaction Date in Manger Audit Trail Details page
	 * 
	 * Veerababu Pedireddi
	 */

	public boolean verifyTransactioDateInAuditTrailPage() {
		boolean flag = false;
		try {
			String date = wolWebUtil.getCurrentDate();
			auditTrailTransDate = webActions.getText(tblManagerAuditTrailDate);
			if (auditTrailTransDate.contains("-"))
				auditTrailTransDate = wolWebUtil.convertDateFormat(auditTrailTransDate);
			if (auditTrailTransDate.contains(date)) {
				flag = true;
				LogUtility.logInfo("---> verifyTransactioDateInAuditTrailPage <---", "Transaction Date is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTransactioDateInAuditTrailPage",
					"Transaction Date is not displayed in Manage Audit Trail Page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Transaction table column names in Deposit details Page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyColumnNamesInDepositDetailsPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblTransTableHeader, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyColumnNamesInDepositDetailsPage",
					"Unable to verify the Transaction table column names in Deposit Details Page", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Transaction table column values in Deposit details Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyColumnValuesInDepositDetailsPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblTransTableHeaderValues, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyColumnValuesInDepositDetailsPage",
					"Unable to verify the Transaction table column values in Deposit Details Page", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Accounts table column names in Deposit details Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyAccsColumnNamesInDepositDetailsPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblAccsTableHeader, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyAccsColumnNamesInDepositDetailsPage",
					"Unable to verify the Accounts table column names in Deposit Details Page", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * To verify the Accounts table column values in Deposit details Page
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyAccsColumnValuesInDepositDetailsPage(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblAccsTableHeaderValues, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyAccsColumnValuesInDepositDetailsPage",
					"Unable to verify the Accounts table column values in Deposit Details Page", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * To verify Account check box is selected or not, If selected un-check the
	 * check box , If Un-checked, select the check box
	 * 
	 * View Deposit Details Preferences Page in Webcom
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean verifyAccountCheckBoxStatusInWebcom(String accNumber, String checkBoxStatus) {
		boolean flag = false;
		WebElement accDetails;
		try {
			if (checkBoxStatus.equals("Checked")) {
				accDetails = driver.findElement(By.xpath(String.format(accountStatus, accNumber)));
				boolean returnValue = webActions.isChecked(accDetails);
				if (returnValue)
					flag = true;
				else {
					webActions.clickElement(accDetails);
					flag = true;
				}
				LogUtility.logInfo("---> Account checked <---" + accDetails);
			} else if (checkBoxStatus.equals("Unchecked")) {
				accDetails = driver.findElement(By.xpath(String.format(accountStatus, accNumber)));
				boolean returnValue = webActions.isChecked(accDetails);
				if (returnValue) {
					webActions.clickElement(accDetails);
					flag = true;
				} else
					flag = true;
				LogUtility.logInfo("---> Account Un checked <---." + accDetails);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountCheckBoxStatusInWebcom",
					accNumber + "is not displayed for the " + checkBoxStatus + "status", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Enroll/Un-Enroll Account number in Deposit Details Page
	 * 
	 * Veerababu Pedireddi
	 */

	public boolean verifyAccountEnrolledOrUnEnrolledInWebcom(String accNumber, String status) {
		boolean flag = false;
		WebElement accDetails;
		try {
			accDetails = driver.findElement(By.xpath(String.format(accountStatus, accNumber)));
			boolean accStatus = webActions.isChecked(accDetails);
			if (status.equals("Enrolled")) {
				if (accStatus) {
					LogUtility.logInfo("--->verifyAccountEnrolledOrUnEnrolledInWebcom<---", "Account Enrolled");
					flag = true;
				}
			} else if (status.equals("Un-Enrolled")) {
				if (!accStatus) {
					LogUtility.logInfo("--->verifyAccountEnrolledOrUnEnrolledInWebcom<---", "Account UnEnrolled");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountEnrolledOrUnEnrolledInWebcom",
					accountStatus + "is not displayed for the " + accNumber + "account", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickUpdateButton: To click on Update button in View Deposit Details
	 * Preferences page
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean clickOnUpdateButton() {
		boolean flag = false;
		try {
			boolean updateBtn = webActions.isDisplayed(btnUpdateDepositDetails);
			if (updateBtn) {
				webActions.clickElement(btnUpdateDepositDetails);
				LogUtility.logInfo("---> clickUpdateButton <---", "Clicked on Update Button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickUpdateButton", "Unable to click on Update button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyCustomerRole(String customerRole) {
		boolean flag = false;
		try {
			boolean custName = webActions.isDisplayed(lnkUserName);
			if (custName) {
				String userRole = webActions.getText(txtRole);
				if (userRole.equals(customerRole)) {
					LogUtility.logInfo("---> verifyCustomerRole <---", "Verified customer role as admin");
					boolean roleCheck = webActions.isChecked(chkIsAdmin);
					if (roleCheck) {
						LogUtility.logInfo("---> verifyCustomerRole <---", "Verified Make admin check box checked");
						boolean checkBoxDisable = webActions.isDisabled(chkIsAdmin);
						if (checkBoxDisable) {
							LogUtility.logInfo("---> verifyCustomerRole <---",
									"Verified Make admin check box disabled");
							flag = true;
						}
					}
				}

			}
		} catch (Exception e) {
			LogUtility.logException("verifyCustomerRole", "Unable to verify Customer Role", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickUsername() {
		boolean flag = false;
		try {
			boolean custName = webActions.isDisplayed(lnkUserName);
			if (custName) {
				webActions.clickElement(lnkUserName);
				LogUtility.logInfo("---> clickUsername <---", "Clicked on user name successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickUsername", "Unable to click on User Name", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean enterCompanyId(String companyId) {
		boolean flag = false;
		try {
			boolean compId = webActions.isDisplayed(txtCustomerID);
			companyID = companyId;
			if (compId) {
				webActions.setValue(txtCustomerID, companyId);
				LogUtility.logInfo("---> enterCompanyId <---", "Entered Company Id successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterCompanyId", "Unable to enter Company Id", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickManageUsers() {
		boolean flag = false;
		try {
			boolean manageUsers = webActions.isDisplayed(lnkManageUsers);
			if (manageUsers) {
				webActions.clickElement(lnkManageUsers);
				LogUtility.logInfo("---> clickManageUsers <---", "Clicked manage users link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickManageUsers", "Unable to click manage users link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyCompanyId() {
		boolean flag = false;
		try {
			boolean manageUsers = webActions.isDisplayed(txtCompanyID);
			if (manageUsers) {
				String company = webActions.getText(txtCompanyID);
				if (company.equals(companyID)) {
					LogUtility.logInfo("---> verifyCompanyId <---", "Verified Company Id successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCompanyId", "Unable to verify Company Id", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyCompanyInfoAbsence() {
		boolean flag = true;
		try {
			boolean companyInfo = webActions.isDisplayed(tblCompanyInfo);
			if (companyInfo) {
				String cellValue = webActions.getText(tblCompanyInfo);
				if (cellValue.equals("Business Name")) {
					LogUtility.logInfo("---> verifyCompanyInfoAbsence <---",
							"Company Information section available and failed");
					flag = false;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCompanyInfoAbsence", "Unable to verify Company Information section", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyCompanyInfoPresence() {
		boolean flag = false;
		try {
			boolean companyInfo = webActions.isDisplayed(tblCompanyInfo);
			if (companyInfo) {
				String cellValue = webActions.getText(tblCompanyInfo);
				if (cellValue.equals("Business Name")) {
					LogUtility.logInfo("---> verifyCompanyInfoPresence <---",
							"Verified company info section successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCompanyInfoPresence", "Unable to verify Company Info section", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyPaymentHistory(String title) {
		boolean flag = false;
		try {
			Set<String> windows = driver.getWindowHandles();
			Iterator<String> itr = windows.iterator();
			String mainWindow = itr.next();
			String childWindow = itr.next();
			driver.switchTo().window(childWindow);
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(txtPaymentHistory, maxTimeOut);
			boolean paymentHeader = webActions.isDisplayed(txtPaymentHistory);
			if (paymentHeader) {
				String titlePayment = txtPaymentHistory.getText();
				if (titlePayment.equals(title)) {
					LogUtility.logInfo("---> verifyPaymentHistory <---", "Verified Payment History successfully");
					flag = true;
				}
			}
			driver.close();
			driver.switchTo().window(mainWindow);
		} catch (Exception e) {
			LogUtility.logException("verifyPaymentHistory", "Unable to verify Payment History", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyColumnHeaders(List<String> listValue) {
		boolean flag = false;
		try {
			boolean tableInfo = webActions.isDisplayed(tblAddedUsers);
			if (tableInfo) {
				boolean colValues = wolWebUtil.verifyColumnNamesInHeaderLess(tblAddedUsers, listValue);
				if (colValues) {
					LogUtility.logInfo("---> verifyColumnHeaders <---", "Verified Column Headers of the table");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyColumnHeaders", "Unable to verify Column Headers of the table", e,
					LoggingLevel.ERROR, true);

		}
		return flag;
	}

	public boolean verifyDefaultValue() {
		boolean flag = false;
		try {
			boolean userId = webActions.isDisplayed(txtUserId);
			if (userId) {
				defaultValue = webActions.getAttributeValue(txtUserId, "value");
				if (defaultValue != null) {
					LogUtility.logInfo("---> verifyDefaultValue <---",
							"User ID field is displayed with default value successfully and value is " + defaultValue);
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDefaultValue", "User ID field and default value not verified", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickNewSearchLink() {
		boolean flag = false;
		try {
			boolean linkNewSearch = webActions.isDisplayed(lnkStartNewSearch);
			if (linkNewSearch) {
				webActions.clickElement(lnkStartNewSearch);
				LogUtility.logInfo("---> clickNewSearchLink <---", "Clicked on start New Search link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickNewSearchLink", "Failed to click on New Search Link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickModifySearch() {
		boolean flag = false;
		try {
			boolean linkModifySearch = webActions.isDisplayed(lnkModifySearch);
			if (linkModifySearch) {
				webActions.clickElement(lnkModifySearch);
				LogUtility.logInfo("---> clickModifySearch <---", "Clicked on Modify Search link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickNewSearchLink", "Failed to click on Modify Search link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickBrowserBack() {
		boolean flag = false;
		try {
			driver.navigate().back();
			LogUtility.logInfo("---> clickBrowserBack <---", "Navigated to browser back successfully");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("clickBrowserBack", "Failed to navigate the browser back", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickCustomerDetails() {
		boolean flag = false;
		try {
			boolean linkcustomerDetails = webActions.isDisplayed(lnkCustomerDetails);
			if (linkcustomerDetails) {
				webActions.clickElement(lnkCustomerDetails);
				LogUtility.logInfo("---> clickCustomerDetails <---", "Clicked on Customer Details link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickCustomerDetails", "Failed to click on Customer Details link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyConfirmationText() {
		boolean flag = false;
		try {
			boolean textConfirmation = webActions.isDisplayed(txtAddConfirmation);
			if (textConfirmation) {
				String confirmText = webActions.getText(txtAddConfirmation);
				if (confirmText.equals("Add New User Confirmation")) {
					LogUtility.logInfo("---> verifyConfirmationText <---", "Verified Confirmation text successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyConfirmationText", "Failed to verify Confirmation text", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyBranchHeaders(List<String> listValue) {
		boolean flag = false;
		try {
			boolean tableInfo = webActions.isDisplayed(tblBranchHead);
			if (tableInfo) {
				boolean colValues = wolWebUtil.verifyColumnNamesInHeaderLess(tblBranchHead, listValue);
				if (colValues) {
					LogUtility.logInfo("---> verifyBranchHeaders <---", "Verified Branch headers of the table");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyBranchHeaders", "Failed to verify Branch headers", e, LoggingLevel.ERROR,
					true);

		}
		return flag;
	}

	public boolean verifyButtons() {
		boolean flag = false;
		try {
			boolean branchInput = webActions.isDisplayed(txtBranchNumber);
			if (branchInput) {
				LogUtility.logInfo("---> verifyButtons <---", "Verified Branch Number input box successfully");
			}
			boolean buttonSearch = webActions.isDisplayed(btnSearchBranch);
			if (buttonSearch) {
				LogUtility.logInfo("---> verifyButtons <---", "Verified Search button successfully");
			}
			boolean buttonClear = webActions.isDisplayed(btnClearBranch);
			if (buttonClear) {
				LogUtility.logInfo("---> verifyButtons <---", "Verified Clear button successfully");
			}
			boolean buttonAddNew = webActions.isDisplayed(btnAddNewBranch);
			if (buttonAddNew) {
				LogUtility.logInfo("---> verifyButtons <---", "Verified Add New Branch button successfully");
			}
			flag = true;

		} catch (Exception e) {
			LogUtility.logException("verifyButtons", "Failed to verify buttons from Branch Search page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickSearch() {
		boolean flag = false;
		try {
			boolean btnSearch = webActions.isDisplayed(btnSearchBranch);
			if (btnSearch) {
				webActions.clickElement(btnSearchBranch);
				LogUtility.logInfo("---> clickSearch <---", "Clicked on Search button successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickSearch", "Failed to click on Search button from Branch Search page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean invalidBranchId(String invalidId) {
		boolean flag = false;
		try {
			boolean btnSearch = webActions.isDisplayed(btnSearchBranch);
			if (btnSearch) {
				webActions.setValue(txtBranchNumber, invalidId);
				clickSearch();
				LogUtility.logInfo("---> invalidBranchId <---",
						"Clicked on Search button with Invalid Branch ID successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("invalidBranchId", "Failed to click on Search button with Invalid Branch ID", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	// TODO:In IE browser error showing different
	public boolean verifyInvalidBranchError(String errorMessage) {
		boolean flag = false;
		try {
			boolean textError = webActions.isDisplayed(txtBranchError);
			if (textError) {
				return (wolWebUtil.verifyText(txtBranchError, errorMessage));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyInvalidBranchError", "Failed to verify Invalid Branch Error message", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean validBranchSearch(String branchId) {
		boolean flag = false;
		try {
			boolean inputBranch = webActions.isDisplayed(txtBranchNumber);
			if (inputBranch) {
				webActions.clearValue(txtBranchNumber);
				webActions.setValue(txtBranchNumber, branchId);
				clickSearch();
				LogUtility.logInfo("---> validBranchSearch <---",
						"Clicked on Search button with Valid Branch ID successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("validBranchSearch", "Failed to perform search with Valid Branch Id", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickClearButton() {
		boolean flag = false;
		try {
			boolean clearButton = webActions.isDisplayed(btnClearBranch);
			if (clearButton) {
				webActions.clickElement(btnClearBranch);
				return (wolWebUtil.elementNotDisplay(tblBranchHead));
			}
		} catch (Exception e) {
			LogUtility.logException("clickClearButton", "Failed to click on Clear button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyAddNewFields() {
		boolean flag = false;
		try {
			boolean branchInput = webActions.isDisplayed(txtBranchId);
			if (branchInput) {
				LogUtility.logInfo("---> verifyAddNewFields <---", "Verified Branch Number input box successfully");
			}
			boolean routingNumber = webActions.isDisplayed(txtRoutingNumber);
			if (routingNumber) {
				LogUtility.logInfo("---> verifyAddNewFields <---", "Verified Routing Number field successfully");
			}
			boolean description = webActions.isDisplayed(txtDescription);
			if (description) {
				LogUtility.logInfo("---> verifyAddNewFields <---", "Verified Description Text box successfully");
			}
			boolean commercial = webActions.isDisplayed(chkCommercial);
			if (commercial) {
				LogUtility.logInfo("---> verifyAddNewFields <---", "Verified is Commercial check box successfully");
			}

			flag = true;

		} catch (Exception e) {
			LogUtility.logException("verifyAddNewFields", "Failed to verify fields from Add New Branch page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean enterDataIntoFields(String branch, String routingNumber, String description) {
		boolean flag = false;
		try {
			boolean inputBranch = webActions.isDisplayed(txtBranchId);
			if (inputBranch) {
				webActions.setValue(txtBranchId, branch);
				webActions.setValue(txtRoutingNumber, routingNumber);
				webActions.setValue(txtDescription, description);
				webActions.clickElement(btnAdd);
				LogUtility.logInfo("---> enterDataIntoFields <---", "Entered data into fields successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterDataIntoFields", "Failed to Enter data into fields", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickAddNew() {
		boolean flag = false;
		try {
			boolean inputBranch = webActions.isDisplayed(btnAddNewBranch);
			if (inputBranch) {
				webActions.clickElement(btnAddNewBranch);
				LogUtility.logInfo("---> clickAddNew <---", "Click on Add New button is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickAddNew", "Failed to click on Add New button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyDuplicateError(String errorMessage) {
		boolean flag = false;
		try {
			boolean textError = webActions.isDisplayed(txtDuplicateBranchError);
			if (textError) {
				return (wolWebUtil.verifyText(txtDuplicateBranchError, errorMessage));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDuplicateError", "Failed to verify Duplicate Branch Error message", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySortValue(WebElement downButton, WebElement upButton, WebElement cellValue) {
		boolean flag = false;
		try {
			webActions.clickElement(downButton);
			waits.waitUntilElementIsPresent(cellValue, maxTimeOut);
			String cellData = webActions.getText(cellValue);
			webActions.clickElement(upButton);
			waits.waitUntilElementIsPresent(cellValue, maxTimeOut);
			String cellDataSorted = webActions.getText(cellValue);
			if (!cellData.equals(cellDataSorted)) {
				LogUtility.logInfo("---> verifySortValue <---", "Verified Sorted Table values successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySortValue", "Failed to verify Sorted Table values", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyBranchNumberSort() {
		boolean flag = false;
		try {
			boolean textError = webActions.isDisplayed(tblBranchHead);
			if (textError) {
				return (verifySortValue(imgDownBranchNumber, imgUpBranchNumber, cellBranchNumber));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyBranchNumberSort", "Failed to verify Branch Number column sorted values", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyRoutingNumberSort() {
		boolean flag = false;
		try {
			boolean textError = webActions.isDisplayed(tblBranchHead);
			if (textError) {
				return (verifySortValue(imgDownRoutingNumber, imgUpRoutingNumber, cellRoutingNumber));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRoutingNumberSort", "Failed to verify Routing Number column sorted values",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyDescriptionSort() {
		boolean flag = false;
		try {
			boolean textError = webActions.isDisplayed(tblBranchHead);
			if (textError) {
				return (verifySortValue(imgDownDescription, imgUpDescription, cellDescription));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDescriptionSort", "Failed to verify Description column sorted values", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickMenuBack() {
		boolean flag = false;
		try {
			boolean inputBranch = webActions.isDisplayed(btnMenuBack);
			if (inputBranch) {
				webActions.clickElement(btnMenuBack);
				LogUtility.logInfo("---> clickMenuBack <---", "Click on Back button successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickMenuBack", "Failed to click on Back button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickDeleteLink() {
		boolean flag = false;
		try {
			boolean inputBranch = webActions.isDisplayed(lnkDelete);
			if (inputBranch) {
				webActions.clickElement(lnkDelete);
				webActions.clickElement(lightBoxNew);
				waits.waitUntilElementIsPresent(btnDeleteContinue, maxTimeOut);
				webActions.clickElement(btnDeleteContinue);
				LogUtility.logInfo("---> clickDeleteLink <---", "Click on Delete link successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickDeleteLink", "Failed to click on Delete link", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean getDefaultValue() {
		boolean flag = false;
		try {
			boolean inputEmail = webActions.isDisplayed(txtEmailId);
			if (inputEmail) {
				defaultEmail = webActions.getAttributeValue(txtEmailId, "value");
				LogUtility.logInfo("---> getDefaultValue <---", "Captured Default value from Email field");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("getDefaultValue", "Failed to capture Default Email ID", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickReset() {
		boolean flag = false;
		try {
			boolean button = webActions.isDisplayed(btnReset);
			if (button) {
				webActions.clickElement(btnReset);
				LogUtility.logInfo("---> clickReset <---", "Click on Reset button successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickReset", "Failed to click on Reset button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyUpdatedValue() {
		boolean flag = false;
		try {
			boolean inputEmail = webActions.isDisplayed(txtEmailId);
			if (inputEmail) {
				String updatedEmail = webActions.getAttributeValue(txtEmailId, "value");
				if (updatedEmail.equals(defaultEmail)) {
					LogUtility.logInfo("---> verifyUpdatedValue <---", "Email value compared successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyUpdatedValue", "Failed to compare Updated Email value", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyMessage(String message) {
		boolean flag = false;
		try {
			boolean pageLevelMessage = webActions.isDisplayed(txtUpdateMessage);
			if (pageLevelMessage) {
				messagePageLevel = webActions.getText(txtUpdateMessage);
				if (messagePageLevel.equals(message)) {
					LogUtility.logInfo("---> verifyMessage <---", "Page Level message verified successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyMessage", "Failed to verify Page Level message", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyStateValue() {
		boolean flag = false;
		try {
			boolean stateVal = webActions.isDisplayed(lstState);
			if (stateVal) {
				defaultState = wolWebUtil.getDefaultValueForSelect(lstState);
				if (!defaultState.equals("")) {
					LogUtility.logInfo("---> verifyStateValue <---",
							"Verification of default State value is successful");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStateValue", "Failed to verify default State value", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyLicenseStateValue() {
		boolean flag = false;
		try {
			boolean liceState = webActions.isDisplayed(lstLicenseState);
			if (liceState) {
				defaultLicenseState = wolWebUtil.getDefaultValueForSelect(lstLicenseState);
				if (!defaultLicenseState.equals("")) {
					LogUtility.logInfo("---> verifyLicenseStateValue <---",
							"Verification of default License State value is successful");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLicenseStateValue", "Failed to verify default License State value", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectStateValue(String stateVal) {
		boolean flag = false;
		try {
			boolean stateValue = webActions.isDisplayed(lstState);
			if (stateValue) {
				webActions.selectDropDownByText(lstState, stateVal);
				LogUtility.logInfo("---> selectStateValue <---", "State Value selection is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectStateValue", "Failed to select State Value", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectLicenseStateValue(String licStateVal) {
		boolean flag = false;
		try {
			boolean liceState = webActions.isDisplayed(lstLicenseState);
			if (liceState) {
				webActions.selectDropDownByText(lstLicenseState, licStateVal);
				LogUtility.logInfo("---> selectLicenseStateValue <---", "License State Value selection is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectLicenseStateValue", "Failed to select License State Value", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyStateDefaultValues() {
		boolean flag = false;
		try {
			boolean stateValue = webActions.isDisplayed(lstState);
			if (stateValue) {
				String verifyDefaultState = wolWebUtil.getDefaultValueForSelect(lstState);
				if (defaultState.equals(verifyDefaultState)) {
					LogUtility.logInfo("---> verifyStateDefaultValues <---",
							"Verification of default State Value is successful");
				}
			}
			boolean liceState = webActions.isDisplayed(lstLicenseState);
			if (liceState) {
				String verifyDefaultLicenseState = wolWebUtil.getDefaultValueForSelect(lstLicenseState);
				if (defaultLicenseState.equals(verifyDefaultLicenseState)) {
					LogUtility.logInfo("---> verifyStateDefaultValues <---",
							"Verification of default License State Value is successful");
				}
			}
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("verifyStateDefaultValues", "Failed to select License State Value", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyFieldValues(String lastName, String logIn, String userId) {
		boolean flag = false;
		try {
			if (wolWebUtil.verifyText(txtUserLastName, lastName)) {
				LogUtility.logInfo("---> verifyFieldValues <---", "Last Name Text verification successful");
			}
			if (wolWebUtil.verifyText(txtUserLogIn, logIn)) {
				LogUtility.logInfo("---> verifyFieldValues <---", "User Login Text verification successful");
			}
			if (wolWebUtil.verifyText(txtUserIdLock, userId)) {
				LogUtility.logInfo("---> verifyFieldValues <---", "User ID Text verification successful");
			}
			flag = true;

		} catch (Exception e) {
			LogUtility.logException("verifyFieldValues", "Failed to verify Last Name, User Login and User ID text", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyShowDetails(String textDetails) {
		boolean flag = false;
		try {
			boolean showDetails = webActions.isDisplayed(txtShowDetails);
			if (showDetails) {
				return (wolWebUtil.verifyTextContains(txtShowDetails, textDetails));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyShowDetails", "Failed to verify Show Details text", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickShowDetailsUnlockUsers() {
		boolean flag = false;
		try {
			boolean showDetails = webActions.isDisplayed(btnLockShowDetails);
			if (showDetails) {
				webActions.clickElement(btnLockShowDetails);
				LogUtility.logInfo("---> clickShowDetailsUnlockUsers <---",
						"Clicked on Show Details button successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickShowDetailsUnlockUsers", "Failed to click on Show Details button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyUserTableColumnNames(String userId, String userName) {
		boolean flag = false;
		try {
			if (wolWebUtil.verifyText(txtUserNameColumn, userName)) {
				LogUtility.logInfo("---> verifyUserTableColumnNames <---",
						"Verified User Name column header successfully");
			}
			if (wolWebUtil.verifyText(txtUserIdLock, userId)) {
				LogUtility.logInfo("---> verifyUserTableColumnNames <---",
						"Verified User ID column header successfully");
			}
			flag = true;

		} catch (Exception e) {
			LogUtility.logException("verifyUserTableColumnNames",
					"Failed to verify User ID and Uusername Column headers", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySubMenuListValues(List<String> listValue) {
		boolean flag = false;
		try {
			boolean subMenuInfo = webActions.isDisplayed(mnuSubMenu);
			if (subMenuInfo) {
				wolWebUtil.verifyListValues(mnuSubMenu, listValue);
				LogUtility.logInfo("---> verifySubMenuListValues <---",
						"SubMenu values verification successful" + listValue.toString());
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySubMenuListValues", "Failed to verify SubMenu values", e, LoggingLevel.ERROR,
					true);

		}
		return flag;
	}

	public boolean selectProfile(String profileVal) {
		boolean flag = false;
		try {
			boolean profile = webActions.isDisplayed(lstChooseProfile);
			if (profile) {
				webActions.selectDropDownByText(lstChooseProfile, profileVal);
				LogUtility.logInfo("---> selectProfile <---", "Profile Selection is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectProfile", "Failed to select Profile", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectActivity(String activityVal) {
		boolean flag = false;
		try {
			boolean activity = webActions.isDisplayed(lstActivityName);
			if (activity) {
				webActions.selectDropDownByText(lstActivityName, activityVal);
				LogUtility.logInfo("---> selectActivity <---", "Activity Selection is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectActivity", "Failed to select Activity", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectFilterActivity(String activityVal) {
		boolean flag = false;
		try {
			boolean activity = webActions.isDisplayed(lstFilterActivityName);
			if (activity) {
				webActions.selectDropDownByValueJs(lstFilterActivityName, activityVal);
				LogUtility.logInfo("---> selectFilterActivity <---", "Filter Activity Selection is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFilterActivity", "Failed to select Filter Activity", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean enterLastNameFilter(String lastName) {
		boolean flag = false;
		try {
			boolean nameLast = webActions.isDisplayed(txtBoxLastName);
			if (nameLast) {
				webActions.setValue(txtBoxLastName, lastName);
				LogUtility.logInfo("---> enterLastNameFilter <---", "Entered Last Name successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterLastNameFilter", "Failed to enter Last Name", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickViewModify() {
		boolean flag = false;
		try {
			boolean modifyLink = webActions.isDisplayed(lnkViewModify);
			if (modifyLink) {
				webActions.clickElement(lnkViewModify);
				LogUtility.logInfo("---> clickViewModify <---", "Clicked on View/ Modify link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickViewModify", "Failed to click on View/ Modify link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyUserStatus(String status) {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			boolean userStatus = webActions.isDisplayed(txtCurrentStatus);
			if (userStatus) {
				String statusOfUser = webActions.getText(txtCurrentStatus);
				if (statusOfUser.equals(status)) {
					LogUtility.logInfo("---> verifyUserStatus <---", "Verified User Status successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyUserStatus", "Failed to verify User Status", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySubMenuLinkUnlock(String value) {
		boolean flag = true;
		try {
			boolean SubMenu = webActions.isDisplayed(subMenuActions);
			if (SubMenu) {
				return (wolWebUtil.selectListValue(subMenuActions, value));
			}
		} catch (Exception e) {
			LogUtility.logException("verifySubMenuLinkUnlock", "Failed to verify Unlock link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyValueFromHistoryTable(String value, String columnName) {
		boolean flag = false;
		try {
			boolean historyTable = webActions.isDisplayed(tblHistoryBody);
			if (historyTable) {
				if (columnName.equals("Date")) {
					String currentDate = wolWebUtil.getCurrentDate();
					value = currentDate;
				}
				if (wolWebUtil.elementNotDisplay(lnkLast)) {
					return (wolWebUtil.verifyTableLastRowValues(tblHistoryHeader, tblHistoryBody, columnName, value));
				} else {
					webActions.clickElement(lnkLast);
					return (wolWebUtil.verifyTableLastRowValues(tblHistoryHeader, tblHistoryBody, columnName, value));
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyValueFromHistoryTable", "Failed to verify History Table value", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyRecordsCount(String value) {
		boolean flag = false;
		try {
			boolean message = webActions.isDisplayed(txtRecords);
			if (message) {
				return (wolWebUtil.verifyTextContains(txtRecords, value));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRecordsCount", "Failed to verify Records message", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyNextLastLinks() {
		boolean flag = false;
		try {
			boolean histortTable = webActions.isDisplayed(tblHistoryHeader);
			if (histortTable) {
				if (webActions.isDisplayed(lnkLast)) {
					LogUtility.logInfo("---> verifyNextLastLinks <---", "Verified Link Last pagination successfully");
				}
				if (webActions.isDisplayed(lnkNext)) {
					LogUtility.logInfo("---> verifyNextLastLinks <---", "Verified Link Next pagination successfully");
				}
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNextLastLinks", "Failed to verify Next and Last links", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyRelationshipCode(String code, String accountNumber) {
		boolean flag = false;
		WebElement element = null;
		int size = txtAcctNumbers.size();
		try {
			for (int i = 1; i < size; i++) {
				String acct = webActions.getText(txtAcctNumbers.get(i)).trim();
				if (acct.equals(accountNumber)) {
					element = driver
							.findElement(By.cssSelector(relationshipCode.replace("p", Integer.toString(i + 1))));
					break;
				}
			}
			String text = webActions.getText(element).trim();
			if (text.equalsIgnoreCase(code))
				flag = true;
			LogUtility.logInfo("---> verifyRelationshipCode <---",
					"Verified Relationship code of account successfully");
		} catch (Exception e) {
			LogUtility.logException("verifyRelationshipCode", "Failed to verify Relationship code of Account", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyUserAuth(String ssn) {
		boolean flag = false;
		try {
			WebElement element = driver.findElement(By.cssSelector(userTooltip.replace("ssn", ssn)));
			if (element.isDisplayed())
				flag = true;
			LogUtility.logInfo("---> verifyUserAuth <---", "Verified User Authorized successfully");
		} catch (Exception e) {
			LogUtility.logException("verifyUserAuth", "Failed to verify User Authorization", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public void getUserName(String user) {
		try {
			waits.waitUntilElementIsPresent(txtUserName, maxTimeOut);
			webActions.setValue(txtUserName, user);
			wolWebUtil.clickWebElement(btnGetCustomer, "getUserName");
			LogUtility.logInfo("---> getUserName <---", "Get User Name successfully");
		} catch (Exception e) {
			LogUtility.logException("getUserName", "Failed to get User Name", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To Verify the Deposit details Un_enrolled message
	 * 
	 * Veerababu Pedireddi
	 * 
	 */
	public boolean verifyDepositDetailsMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(msgUpdateDepositDetails, message);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositDetailsMsg", "Failed to verify Update Deposit Details message", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Statement Period date range as N/A
	 *
	 * Veerababu Pedireddi
	 */
	public boolean verifyStmtPeriodDateRange(String dateRange) {
		try {
			return wolWebUtil.verifyTextContains(lstStatement, dateRange);
		} catch (Exception e) {
			LogUtility.logException("verifyStmtPeriodDateRange", "Statement Period Date Range not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Important message for Account statements
	 *
	 * Veerababu Pedireddi
	 */
	public boolean verifyAccStmtImportantMsg(String message) {
		try {
			return wolWebUtil.verifyText(msgImportantText, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAccStmtImportantMsg",
					"verifyAccStmtImportantMsg" + message + " not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Important message2 for Account statements
	 *
	 * Veerababu Pedireddi
	 */
	public boolean verifyAccNoStmtMsg(String message) {
		try {
			return wolWebUtil.verifyText(msgNoStatement, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAccNoStmtMsg", "verifyAccNoStmtMsg" + message + " not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Important message3 for Account statements
	 *
	 *
	 * Veerababu Pedireddi
	 */
	public boolean verifyAccNoStmtImpSection(String message) {
		try {
			return wolWebUtil.verifyTextContains(msgNoStatementImpSection, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAccNoStmtImpSection",
					"verifyAccNoStmtImpSection" + message + " not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To select Account from dropdown list
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean selectAccFromDropdownList() {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(cmbAtmtAcc);
			if (selectAccount) {
				wolWebUtil.selectValueByPartialVisibleText(cmbAtmtAcc, (testDataMap.get("SelectN/AAccount")));
				LogUtility.logInfo("---> selectAccFromDropdownList <---", "Account Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectAccFromDropdownList", "Unable to select the Account", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To click on View Selected statement button
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean clickOnStmtButton() {
		boolean flag = false;
		try {
			boolean stmtButton = webActions.isDisplayed(btnLogin);
			if (stmtButton) {
				webActions.clickElement(btnLogin);
				LogUtility.logInfo("---> clickonStmtButton <---", "Account Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickonStmtButton", "Unable to click on the Statement button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on Emergency Message link
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean clickOnEmergencyMsgLink() {
		boolean flag = false;
		try {
			boolean emergencyLnk = webActions.isDisplayed(lnkEmergencyMsg);
			if (emergencyLnk) {
				webActions.clickElement(lnkEmergencyMsg);
				LogUtility.logInfo("---> clickOnEmergencyMsgLink <---", "Clicked on Emergency Message Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnEmergencyMsgLink", "Unable to click on the Emergency Message Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter the Emergency Message Title
	 * 
	 * Veerababu Pedireddi
	 */
	public String enterEmergencyMsgTitle() {
		try {
			emergencyMsgTitle = (testDataMap.get("EmergencyMessageTitle"));
			setValueInRuntimeDataMap("emergencyMsgTitleKey", emergencyMsgTitle);
			webActions.setValue(txtEmergencyMsgTitle, emergencyMsgTitle);
			LogUtility.logInfo("---> enterEmergencyMsgTitle <---", "Enter Emergency Message Title");

		} catch (Exception e) {
			LogUtility.logException("enterEmergencyMsgTitle", "Unable to enter Emergency Message Title", e,
					LoggingLevel.ERROR, true);
		}
		return emergencyMsgTitle;
	}

	/**
	 * To enter the Emergency Message text
	 * 
	 * Veerababu Pedireddi
	 */
	public String enterEmergencyMsgBody() {
		try {
			emergencyMessageBody = (testDataMap.get("EmergencyMessageBody"));
			setValueInRuntimeDataMap("emergencyMsgBodyKey", emergencyMessageBody);
			webActions.setValue(txtEmergencyMsg, emergencyMessageBody);
			LogUtility.logInfo("---> enterEmergencyMsgBody <---", "Enter Emergency Message");

		} catch (Exception e) {
			LogUtility.logException("enterEmergencyMsgBody", "Unable to enter Emergency Message", e, LoggingLevel.ERROR,
					true);
		}
		return emergencyMessageBody;
	}

	/**
	 * To enter the Start date - Month -Date -Year - Hrs-mm
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean enterMessageStartDate() {
		boolean flag = false;
		try {
			boolean msgStartDate = webActions.isDisplayed(txtStartMonth);
			if (msgStartDate) {
				String currentDate = wolWebUtil.getCurrentTimeStamp();
				String Date[] = currentDate.split(" ");
				String Date1[] = Date[0].split("/");
				String Date2[] = Date[1].split(":");
				webActions.setValue(txtStartMonth, Date1[0]);
				webActions.setValue(txtStartDate, Date1[1]);
				webActions.setValue(txtStartYear, Date1[2]);
				webActions.setValue(txtStartHour, Date2[0]);
				webActions.setValue(txtStartMinute, Date2[1]);
				LogUtility.logInfo("---> enterMessageStartDate <---", "Start date entered");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterMessageStartDate", "Unable to enter Start date", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter the End date - Month -Date -Year - Hrs-mm
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean enterMessageEndDate() {
		boolean flag = false;
		try {
			boolean msgEndDate = webActions.isDisplayed(txtEndMonth);
			if (msgEndDate) {
				String currentDate = wolWebUtil.getCurrentDate();
				String Date[] = currentDate.split("/");
				webActions.setValue(txtEndMonth, Date[0]);
				webActions.setValue(txtEndDate, Date[1]);
				webActions.setValue(txtEndYear, Date[2]);
				webActions.setValue(txtEndHour, (testDataMap.get("EndDateHour")));
				webActions.setValue(txtEndMinute, (testDataMap.get("EndDateMinute")));
				LogUtility.logInfo("---> enterMessageStartDate <---", "End date entered");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterMessageEndDate", "Unable to enter End date", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on Emergency Message Private Checkbox
	 * 
	 * Veerababu Pedireddi
	 */
	public boolean clickOnPrivateChkBox() {
		boolean flag = false;
		try {
			boolean privateChkBox = webActions.isDisplayed(chkPrivate);
			if (privateChkBox) {
				webActions.clickElement(chkPrivate);
				LogUtility.logInfo("---> clickOnPrivateChkBox <---", "Clicked on Private Check box");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnPrivateChkBox", "Unable to click on the Private Check box ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Capture the Account number and click on the Account number link
	 * 
	 * Veerababu Pedireddi
	 */
	public String captureAccountNumber() {
		try {
			accountNumber = webActions.getText(lnkAccountNumber);
			webActions.clickElement(lnkAccountNumber);
			LogUtility.logInfo("---> captureAccountNumber <---",
					"Account number captured and Clicked on Account number Link");
		} catch (Exception e) {
			LogUtility.logException("captureAccountNumber", "Unable to capture Account Number", e, LoggingLevel.ERROR,
					true);
		}
		return accountNumber;
	}

	/**
	 * To verify the Account number in Account Details page
	 *
	 *
	 * Veerababu Pedireddi
	 */
	public boolean verifyAccountDetails() {
		try {
			return wolWebUtil.verifyText(lblAccountNumber, accountNumber);
		} catch (Exception e) {
			LogUtility.logException("verifyAccountDetails",
					"verifyAccountDetails" + lblAccountNumber + " not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Current Balance in Account Details page
	 *
	 *
	 * Veerababu Pedireddi
	 */
	public boolean verifyCurrentBalance() {
		boolean flag = false;
		try {
			currentBalance = webActions.getText(lblCurrentBalance);
			if (currentBalance.contains("$")) {
				LogUtility.logInfo("---> verifyCurrentBalance <---", "Current balance displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCurrentBalance", "Current Balance" + currentBalance + " not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Available Balance in Account Details page
	 *
	 *
	 * Veerababu Pedireddi
	 */
	public boolean verifyAvailableBalance() {
		boolean flag = false;
		try {
			availableBalance = webActions.getText(lblAvailableBalance);
			if (currentBalance.contains("$")) {
				LogUtility.logInfo("---> verifyAvailableBalance <---", "Available Balance displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAvailableBalance", "Available Balance" + availableBalance + " not displayed",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectProductCategory - To select value from the Product Category drop-down
	 * Riyaz Ali Baig Mohammad
	 */
	public boolean selectProductCategory(String selectValue) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(lstProductCategory)) {
				webActions.selectDropDownByText(lstProductCategory, selectValue);
				LogUtility.logInfo("---> selectProductCategory <---",
						"Selected " + selectValue + " from Product Category drop down");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectProductCategory", selectValue + " is not selected", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * clearValue - To clear value from the Product Short Name label Riyaz Ali Baig
	 * Mohammad
	 */
	public boolean clearValue(String fieldName) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitForDOMready();
			if (webActions.isDisplayed(lblProductShortName)) {
				webActions.clearValue(lblProductShortName);
				LogUtility.logInfo("---> clearValue <---", "Value is cleared for: " + fieldName);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clearValue", "Unable to clear value", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySourceColumnSort(String value) {
		boolean flag = false;
		try {
			boolean message = webActions.isDisplayed(tblHistoryBody);
			if (message) {
				return (verifySortOrder(tblHistorySourceColumn, value));
			}
		} catch (Exception e) {
			LogUtility.logException("verifySourceColumnSort", "Failed to verify Source Column values sorted order", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyDescriptionColumnSort(String value) {
		boolean flag = false;
		try {
			boolean message = webActions.isDisplayed(tblHistoryBody);
			if (message) {
				return (verifySortOrder(tblHistoryDescriptionColumn, value));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDescriptionColumnSort",
					"Failed to verify Description Column values sorted order", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyActivityColumnSort(String value) {
		boolean flag = false;
		try {
			boolean message = webActions.isDisplayed(tblHistoryBody);
			if (message) {
				return (verifySortOrder(tblHistoryActivityColumn, value));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyActivityColumnSort", "Failed to verify Activity Column values sorted order",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySortOrder(List<WebElement> element, String sortByValue) {
		boolean status = false;
		ArrayList<String> payeeNames = new ArrayList<>();
		ArrayList<String> payeeNamesReverse = new ArrayList<>();
		List<String> payeeNamesAfterSort = new ArrayList<>();
		try {
			if (sortByValue.contains("NORMAL")) {
				waits.waitForDOMready();
				for (WebElement eachPayee : element) {
					payeeNames.add(eachPayee.getText().toUpperCase());
					payeeNamesAfterSort = payeeNames.stream().sorted().collect(Collectors.toList());
				}
				if (!payeeNames.equals(payeeNamesAfterSort)) {
					status = true;
					LogUtility.logInfo("---> verifySortOrder <---",
							"History table values sorted successfully " + payeeNamesAfterSort);
				}
			}
			if (sortByValue.contains("REVERSE")) {
				for (WebElement eachPayee : element) {
					payeeNames.add(eachPayee.getText().toUpperCase());
				}
				webActions.clickElement(headSource);
				for (WebElement eachPayeeReverse : element) {
					payeeNamesReverse.add(eachPayeeReverse.getText().toUpperCase());
				}
				if (!payeeNames.equals(payeeNamesReverse)) {
					status = true;
					LogUtility.logInfo("---> verifySortOrder <---",
							"History table values sorted in reverse order successfully " + payeeNamesReverse);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifySortOrder", "Failed to verify records sorting order", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean verifyTextInColumnCells(String columnName, String cellValue) {
		boolean flag = false;
		try {
			boolean message = webActions.isDisplayed(tblHistoryBody);
			if (message) {
				return (wolWebUtil.verifyTableResults(tblHistoryHeader, tblHistoryBody, columnName, cellValue));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTextInColumnCells", "Failed to verify given values in column", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyPassMarkLinkPresence(String link) {
		boolean flag = false;
		try {
			boolean linkMark = webActions.isDisplayed(lnkPassMarkCSRTool);
			if (linkMark) {
				LogUtility.logInfo("---> verifyPassMarkLinkPresence <---",
						"Verified " + link + " link presence successfully ");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPassMarkLinkPresence", "Failed to verify Pass Mark CSR tool link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyPassMarkLinkNotPresent(String link) {
		boolean flag = false;
		try {
			boolean linkPsr = wolWebUtil.elementNotDisplay(lnkPassMarkCSRTool);
			if (linkPsr) {
				LogUtility.logInfo("---> verifyPassMarkLinkNotPresent <---", "Verified " + link + " link not present");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPassMarkLinkNotPresent",
					"Failed to verify Pass Mark CSR tool link not present", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyDeleteMessage(String value) {
		boolean flag = false;
		try {
			boolean message = webActions.isDisplayed(txtMessageDeleteAdd);
			if (message) {
				return (wolWebUtil.verifyTextContains(txtMessageDeleteAdd, value));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDeleteMessage", "Failed to verify Delete message", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyAddMessage(String value) {
		boolean flag = false;
		try {
			boolean message = webActions.isDisplayed(txtMessageDeleteAdd);
			if (message) {
				return (wolWebUtil.verifyTextContains(txtMessageDeleteAdd, value));
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAddMessage", "Failed to verify Add message", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean deleteRsaUser(String value) {
		boolean flag = false;
		int size = tblCsaNameColumn.size();
		try {
			for (int i = 0; i < size; i++) {
				String userName = tblCsaNameColumn.get(i).getText();
				if (userName.equals(value)) {
					tblCsaDeleteColumn.get(i - 1).click();
					break;
				}
			}
			waits.staticWait(2);
			webActions.clickElement(btnDeleteRSAUser);
			LogUtility.logInfo("---> deleteRsaUser <---", "Selected user to delete from the list successfully");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("deleteRsaUser", "Failed to select User from the list", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean selectRsaUser(String value) {
		boolean flag = false;
		try {
			boolean userList = webActions.isDisplayed(lstRsaUserId);
			if (userList) {
				webActions.selectDropDownByText(lstRsaUserId, value);
				LogUtility.logInfo("---> selectRsaUser <---", "Selected User from the list successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectRsaUser", "Failed to select User from the list", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickAddRsaUser() {
		boolean flag = false;
		try {
			boolean userList = webActions.isDisplayed(btnDeleteRSAUser);
			if (userList) {
				webActions.clickElement(btnDeleteRSAUser);
				waits.waitForDOMready();
				LogUtility.logInfo("---> clickAddRsaUser <---", "Clicked on add RSA User button successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickAddRsaUser", "Failed to click on RSA User button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyProductCategory(String category) {
		boolean flag = false;
		try {
			boolean labelProductCategory = webActions.isDisplayed(lblProductCategory);
			boolean fieldProductCategory = webActions.isDisplayed(lstProductCategory);
			if (labelProductCategory && fieldProductCategory) {
				return wolWebUtil.verifyTextContains(lblProductCategory, category);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyProductCategory", "Failed to verify Product Category field", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyProductName(String name) {
		boolean flag = false;
		try {
			boolean labelProductName = webActions.isDisplayed(lblProductName);
			boolean fieldProductName = webActions.isDisplayed(lstProductName);
			if (labelProductName && fieldProductName) {
				return wolWebUtil.verifyTextContains(lblProductName, name);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyProductName", "Failed to verify Product Name field", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyApplCode(String name) {
		boolean flag = false;
		try {
			boolean labelApplCode = webActions.isDisplayed(lblApplCode);
			boolean fieldApplCode = webActions.isDisplayed(lstApplCode);
			if (labelApplCode && fieldApplCode) {
				return wolWebUtil.verifyTextContains(lblApplCode, name);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyApplCode", "Failed to verify Application code field", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyAccountType(String type) {
		boolean flag = false;
		try {
			boolean labelAccountType = webActions.isDisplayed(lblAccountType);
			boolean fieldAccountType = webActions.isDisplayed(txtBoxAccountType);
			if (labelAccountType && fieldAccountType) {
				return wolWebUtil.verifyTextContains(lblAccountType, type);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountType", "Failed to verify Account Type field", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyProductStatus(String status) {
		boolean flag = false;
		try {
			boolean labelProductStatus = webActions.isDisplayed(lblProductStatus);
			boolean fieldProductStatus = webActions.isDisplayed(lstProductStatus);
			if (labelProductStatus && fieldProductStatus) {
				return wolWebUtil.verifyTextContains(lblProductStatus, status);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyProductStatus", "Failed to verify Product Status field", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyRequestStatus(String status) {
		boolean flag = false;
		try {
			boolean labelRequestStatus = webActions.isDisplayed(lblRequestStatus);
			boolean fieldRequestStatus = webActions.isDisplayed(lstRequestStatus);
			if (labelRequestStatus && fieldRequestStatus) {
				return wolWebUtil.verifyTextContains(lblRequestStatus, status);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRequestStatus", "Failed to verify Request Status field", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyRecomProduct(String product) {
		boolean flag = false;
		try {
			boolean labelRecomProduct = webActions.isDisplayed(lblRecommProduct);
			boolean fieldRecomProduct = webActions.isDisplayed(lstRecommProduct);
			if (labelRecomProduct && fieldRecomProduct) {
				return wolWebUtil.verifyTextContains(lblRecommProduct, product);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRecomProduct", "Failed to verify Recommended Product field", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySearchButton(String searchButton) {
		boolean flag = false;
		try {
			boolean button = webActions.isDisplayed(btnSearch);
			if (button) {
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySearchButton", "Failed to verify Search button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyClearButton(String clearButton) {
		boolean flag = false;
		try {
			boolean button = webActions.isDisplayed(btnClearBranch);
			if (button) {
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyClearButton", "Failed to verify Clear button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectRecommProduct(String product) {
		boolean flag = false;
		try {
			boolean recommProduct = webActions.isDisplayed(lstRecommProduct);
			if (recommProduct) {
				webActions.selectDropDownByText(lstRecommProduct, product);
				LogUtility.logInfo("---> selectRecommProduct <---",
						"Selected recommended product from the list successfully ");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectRecommProduct", "Failed to select Recommended Product", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean searchClick() {
		boolean flag = false;
		try {
			boolean buttonSearch = webActions.isDisplayed(btnSearch);
			if (buttonSearch) {
				webActions.clickElement(btnSearch);
				LogUtility.logInfo("---> searchClick <---", "Click on Search button is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("searchClick", "Failed to click on Search button ", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyProductShortName(String shortName) {
		boolean flag = false;
		try {
			boolean productName = webActions.isDisplayed(tblProductShortName);
			if (productName) {
				return wolWebUtil.verifyTextContains(tblProductShortName, shortName);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyProductShortName", "Failed to verify Product Short Name", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyTypeOfAccount(String account) {
		boolean flag = false;
		try {
			boolean typeOfAcct = webActions.isDisplayed(tblActType);
			if (typeOfAcct) {
				return wolWebUtil.verifyTextContains(tblActType, account);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTypeOfAccount", "Failed to verify type of Account", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyRecommendedProductLabel(String label) {
		boolean flag = false;
		try {
			boolean lableOfProduct = webActions.isDisplayed(txtRecommendedProduct);
			if (lableOfProduct) {
				return wolWebUtil.verifyTextContains(txtRecommendedProduct, label);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRecommendedProductLabel", "Failed to recommended Product Label", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyRecommendedProductYes() {
		boolean flag = false;
		try {
			boolean recommProductYes = webActions.isDisplayed(optionYes);
			if (recommProductYes) {
				LogUtility.logInfo("---> verifyRecommendedProductYes <---", "Verified Yes radio option successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRecommendedProductYes", "Failed to verify Yes radio option", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyRecommendedProductNo() {
		boolean flag = false;
		try {
			boolean recommProductYes = webActions.isDisplayed(optionNo);
			if (recommProductYes) {
				LogUtility.logInfo("---> verifyRecommendedProductNo <---", "Verified No radio option successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRecommendedProductNo", "Failed to verify No radio option", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectProdCategory(String product) {
		boolean flag = false;
		try {
			boolean recommProduct = webActions.isDisplayed(lstProductCategory);
			if (recommProduct) {
				webActions.selectDropDownByText(lstProductCategory, product);
				LogUtility.logInfo("---> selectProductCategory <---",
						"Selected Product Category from the list successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectProductCategory", "Failed to select Product Category from the list", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean selectYesOption() {
		boolean flag = false;
		try {
			boolean recommProductYes = webActions.isDisplayed(optionYes);
			if (recommProductYes) {
				webActions.clickElement(optionYes);
				LogUtility.logInfo("---> selectYesOption <---", "Selected Yes radio option successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectYesOption", "Failed to select Yes radio option", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickButtonUpdate() {
		boolean flag = false;
		try {
			boolean recommProductYes = webActions.isDisplayed(btnUpdate);
			if (recommProductYes) {
				webActions.clickElement(btnUpdate);
				LogUtility.logInfo("---> clickButtonUpdate <---", "Click on Update button is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickButtonUpdate", "Failed to Click on Update button ", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyRecommProductError(String error) {
		boolean flag = false;
		try {
			boolean lableOfProduct = webActions.isDisplayed(txtApproveError);
			if (lableOfProduct) {
				errorMessage = webActions.getText(txtApproveError);
				return wolWebUtil.verifyTextContains(txtApproveError, error);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyRecommProductError", "Failed to verify Approve error ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickSort() {
		boolean flag = false;
		try {
			boolean recommProductYes = webActions.isDisplayed(optionAcctSort);
			if (recommProductYes) {
				webActions.clickElement(optionAcctSort);
				LogUtility.logInfo("---> clickSort <---", "Click on Sort button is successful");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickSort", "Failed to click on Sort button ", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyApplyEligibilityRules(String field) {
		boolean flag = false;
		try {
			boolean lableOfProduct = webActions.isDisplayed(txtApplyEligibilityRules);
			if (lableOfProduct) {
				return wolWebUtil.verifyTextContains(txtApplyEligibilityRules, field);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyApplyEligibilityRules", "Failed to verify Apply Eligibility Rules", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifySubMenuValues(List<String> listValue) {
		boolean flag = false;
		try {
			boolean subMenuInfo = webActions.isDisplayed(subMnuRight);
			if (subMenuInfo) {
				wolWebUtil.verifyListValues(subMnuRight, listValue);
				LogUtility.logInfo("---> verifySubMenuValues <---",
						"Verified sub menu values success fully" + listValue);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySubMenuValues", "Failed to verify Sub Menu values", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}
}
