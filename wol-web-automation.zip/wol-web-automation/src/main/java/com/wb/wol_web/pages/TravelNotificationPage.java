
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class TravelNotificationPage extends ObjectBase {

	public TravelNotificationPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "error-travel-notification-no-cards__pageErrors__error-travel-notification-no-cards__pageError__body")
	protected WebElement txtTravelAccessMessage;

	@FindBy(id = "travel-notification__form__button--submit__actualButton")
	protected WebElement btnContinueTravelNotification;

	@FindBy(id = "travel-notification__form__button--cancel")
	protected WebElement btnCancelTravelNotification;

	@FindBy(css = "p.error-message-text")
	protected List<WebElement> listErrorMessages;

	@FindBy(css = "#cardholderName__display>span")
	protected WebElement txtCustomerName;

	@FindBy(id = "phone__input")
	protected WebElement inputPhoneNumber;

	@FindBy(id = "dateStart__input")
	protected WebElement inputStartDate;

	@FindBy(id = "dateEnd__input")
	protected WebElement inputEndDate;

	@FindBy(id = "locations__input")
	protected WebElement inputTravelLocation;

	@FindBy(id = "cardList__option1__input")
	protected WebElement checkboxDebitCard;

	@FindBy(id = "travel-notification-verify__form__button--submit__actualButton")
	protected WebElement btnContinueTravelNotifVerify;

	@FindBy(id = "travel-notification-verify__form__button--cancel")
	protected WebElement btnCancelTravelNotifVerify;

	List<String> listNotificationMessages = new ArrayList<String>();
	String txtMessage = "";

	/**
	 * checkAccessMessage: To check the access message
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkAccessMessage(String message) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		try {
			if (wolWebUtil.verifyTextContains(txtTravelAccessMessage, message)) {
				LogUtility.logInfo("-->checkAccessMessage<--", "Message: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkAccessMessage<--", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButtonTravelNotification: To click on the buttons in Travel
	 * Notification page
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButtonTravelNotification(String btnName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement btnToBeClicked = null;
		try {
			switch (btnName) {
			case "Continue":
				btnToBeClicked = btnContinueTravelNotification;
				break;
			case "Cancel":
				btnToBeClicked = btnCancelTravelNotification;
				break;
			default:
				LogUtility.logInfo("-->clickOnButtonTravelNotification<--", "no case match found");
				break;
			}
			if (webActions.isDisplayed(btnToBeClicked)) {
				webActions.clickElement(btnToBeClicked);
				LogUtility.logInfo("-->clickOnButtonTravelNotification<--", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButtonTravelNotification<--", "Button: " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForErrorMessage: To check the error messages of label
	 * 
	 * @param pageName
	 * @param testDataMap
	 * @return
	 */
	public List<String> checkForErrorMessage(String pageName, Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement errorMessage : listErrorMessages) {
				txtMessage = webActions.getText(errorMessage);
				if (testDataMap.containsValue(txtMessage)) {
					LogUtility.logInfo("-->checkForErrorMessage<--", "Message: " + txtMessage + " is present");
				} else
					listNotificationMessages.add(txtMessage);
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForErrorMessage--",
					"Some of the messages: " + listNotificationMessages.toString() + " are not present", e,
					LoggingLevel.ERROR, true);
		}
		return listNotificationMessages;
	}

	/**
	 * checkCustomerName: To check the customer name
	 * 
	 * @return
	 */
	public String checkCustomerName() {
		String customerName = null;
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(txtCustomerName)) {
				customerName = webActions.getText(txtCustomerName);
				LogUtility.logInfo("-->checkCustomerName<--", "Customer Name: " + customerName + " is displayed");
				return customerName;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkCustomerName<--", "Customer Name is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return customerName;
	}

	public boolean enterValueInField(String value, String fieldName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement fieldToEnter = null;
		try {
			switch (fieldName) {
			case "Preferred Phone Number":
				fieldToEnter = inputPhoneNumber;
				value = wolWebUtil.getRandomNumber(10);
				break;
			case "Travel Start Date":
				fieldToEnter = inputStartDate;
				value = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 7);
				break;
			case "Travel End Date":
				fieldToEnter = inputEndDate;
				value = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 14);
				break;
			case "Travel Locations":
				fieldToEnter = inputTravelLocation;
				value = wolWebUtil.getRandomString(7);
				break;

			default:
				LogUtility.logInfo("-->enterValueInField<--", "No case match found");
				break;
			}
			if (webActions.isDisplayed(fieldToEnter)) {
				webActions.setValue(fieldToEnter, value);
				LogUtility.logInfo("-->enterValueInField<--", "Value: " + value + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterValueInField<--", "Value: " + value + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public boolean clickOnDebitCardCheckbox() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(checkboxDebitCard)) {
				webActions.clickElement(checkboxDebitCard);
				LogUtility.logInfo("-->clickOnDebitCardCheckbox<--", "Debit card checkbox is checked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnDebitCardCheckbox<--", "Debit card checkbox is not checked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public boolean clickOnButtonTravelNotifVerification(String btnName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement btnToBeClicked = null;
		try {
			switch (btnName) {
			case "Continue":
				btnToBeClicked = btnContinueTravelNotifVerify;
				break;
			case "Cancel":
				btnToBeClicked = btnCancelTravelNotifVerify;
				break;
			default:
				LogUtility.logInfo("-->clickOnButtonTravelNotifVerification<--", "no case match found");
				break;
			}
			if (webActions.isDisplayed(btnToBeClicked)) {
				webActions.clickElement(btnToBeClicked);
				LogUtility.logInfo("-->clickOnButtonTravelNotifVerification<--", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButtonTravelNotifVerification<--",
					"Button: " + btnName + " is not clicked", e, LoggingLevel.ERROR, true);
		}
		return false;
	}
}
