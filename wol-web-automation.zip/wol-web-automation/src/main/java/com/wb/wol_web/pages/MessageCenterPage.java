package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.testbases.WOLTestBase;

/**
 * @author rpagadala-adm
 *
 */
public class MessageCenterPage extends ObjectBase {

	public MessageCenterPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "form[name='read_mail'] div")
	protected List<WebElement> listLabelDetails;

	@FindBy(css = "ul#megaMenuSectionSidebar__SubMenuForSidebar3__list a")
	protected List<WebElement> listRelatedLinks;

	@FindBy(css = "form[name='read_mail'] label")
	protected List<WebElement> listSendMessageDetails;

	@FindBy(css = "div#pageContent td:nth-child(1)")
	protected List<WebElement> listReviewSentMessageDetails;

	@FindBy(css = "div#pageContent th>div")
	protected List<WebElement> listReviewSentMessages;

	@FindBy(css = "div#pageContent>ul>li>a")
	protected List<WebElement> listQuickLinks;

	@FindBy(css = "div#next-steps-panel>ul>li>a")
	protected List<WebElement> listImportantNotification;

	@FindBy(name = "delete")
	protected WebElement btnDeleteReviewMessage;

	@FindAll({ @FindBy(name = "cancel"), @FindBy(name = "cancel.x") })
	protected WebElement btnCancelMessage;

	@FindBy(name = "delete.x")
	protected WebElement btnDeleteReadMessage;

	@FindBy(name = "reply.x")
	protected WebElement btnReplayMessage;

	@FindBy(css = "[value='Reply']")
	protected WebElement btnReplayMessageWC;

	@FindBy(css = "[value='Print']")
	protected WebElement btnPrintMessageWC;

	@FindBy(css = "[value='Delete']")
	protected WebElement btnDeleteMessageWC;

	@FindBy(css = "[value='Forward Loan']")
	protected WebElement btnFwdMessageWC;

	@FindBy(name = "submit")
	protected WebElement btnSubmitSendMessage;

	@FindBy(name = "no")
	protected WebElement btnNoConfirmation;

	@FindBy(name = "yes")
	protected WebElement btnYesConfirmation;

	@FindBy(css = "form[name='read_mail'] td:nth-child(1)>a")
	protected WebElement linkSentMessage;

	@FindBy(css = "form[name='read_mail'] td>a")
	protected List<WebElement> listLinks;

	@FindBy(css = "div[data-wbst-message-key='send_mail_customer_service']")
	protected WebElement txtServiceCenterMessage;

	@FindBy(css = "form[name='read_mail']>table + p")
	protected WebElement txtReadMessage;

	@FindBy(css = "div.errorInline")
	protected List<WebElement> listErrors;

	@FindBy(name = "subject")
	protected WebElement txtSubjectBox;

	@FindBy(name = "message_text")
	protected WebElement txtMessageBox;

	@FindBy(css = "div#pageContent>div")
	protected WebElement txtUpdateMessage;

	@FindBy(id = "selectedAccount")
	protected List<WebElement> listAccounts;

	@FindBy(id = "menuCompose")
	protected WebElement menuCompose;

	@FindBy(id = "menuGetNext")
	protected WebElement menuGetNext;

	@FindBy(id = "composeTo")
	protected WebElement inputTo;

	@FindBy(id = "composeSubj")
	protected WebElement inputSubject;

	@FindBy(id = "composeMsg")
	protected WebElement inputMessage;

	@FindBy(css = "input[value='Send']")
	protected WebElement btnSendWebcom;

	@FindBy(css = "input[value='Send Reply']")
	protected WebElement btnSendReplayWebcom;

	@FindBy(css = "table>tbody>tr>td:nth-child(1)>b")
	protected List<WebElement> listComposeMessage;

	@FindBy(name = "stdReply")
	protected WebElement listStdReplay;

	@FindBy(css = "td>table td>b")
	protected List<WebElement> listMessageDetails;

	@FindBy(css = "#content b")
	protected List<WebElement> listReplayMessageDetails;

	@FindBy(id = "Inbox")
	protected WebElement txtInboxMessages;

	@FindBy(css = "#pageContent [name='read_mail'] tbody td>a")
	protected List<WebElement> listReviewSubjectLinks;

	@FindBy(name = "reply.x")
	protected WebElement btnReplayReadMessage;

	@FindBy(css = "div#pageContent tr:nth-child(5)>td:nth-child(2)")
	protected WebElement txtAccountNumber;

	public String linkName = "";
	public String txtSubject = "";
	public String basePath = "#pageContent [name='read_mail'] tbody tr:nth-child(";
	public String boldLinkPath = ")>td>a>b";
	public String deleteCheckboxPath = ")>td:nth-child(4)>input[type='checkbox']";
	public List<WebElement> listLink = new ArrayList<WebElement>();
	public List<WebElement> listDeleteCheckbox = new ArrayList<WebElement>();
	public String txtSubjectReadMessage = "";
	public String accountNumber = "";

	/**
	 * checkForDetails- To verify the label names
	 * 
	 * @param pageName
	 * @param testDataMap
	 * @return
	 */
	public int checkForDetails(String pageName, Map<String, String> testDataMap) {
		int count = 0;
		waits.waitForDOMready();
		waits.waitForPageToLoad(maxTimeOut);
		try {
			List<WebElement> listofValues = null;
			switch (pageName) {
			case "Review Messages":
				listofValues = listLabelDetails;
				break;
			case "Send Message":
				listofValues = listSendMessageDetails;
				break;
			case "Read Message":
			case "Review Sent Message":
				listofValues = listReviewSentMessageDetails;
				break;
			case "Review Sent Messages":
				listofValues = listReviewSentMessages;
				break;
			case "QuickLinks":
				listofValues = listQuickLinks;
				break;
			case "Important Notification":
				listofValues = listImportantNotification;
				break;
			case "Compose Mail":
				listofValues = listComposeMessage;
				break;
			case "Message Details":
				listofValues = listMessageDetails;
				break;
			case "Replay Message":
				listofValues = listReplayMessageDetails;
				break;
			default:
				LogUtility.logInfo("-->checkForDetails<--", "No case is matched");
				break;
			}
			waits.waitForPageReadyState();
			for (WebElement detail : listofValues) {
				for (String label : testDataMap.values()) {
					if (wolWebUtil.verifyTextContains(detail, label)) {
						LogUtility.logInfo("-->checkForDetails<--", detail + " is present");
						count++;
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForDetails--", "Details are not present", e, LoggingLevel.ERROR, true);
		}
		return count;
	}

	/**
	 * clickOnLink -- To click on the link
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickOnRelatedLink(String linkName) {
		try {
			for (WebElement link : listRelatedLinks) {
				if (wolWebUtil.verifyTextContains(link, linkName)) {
					webActions.clickElement(link);
					LogUtility.logInfo("-->clickOnRelatedLink<--", linkName + " is clicked");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnRelatedLink<--", linkName + " is not clicked", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * clickOnLink - To click on the given link
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickOnLink(String linkName) {
		try {
			waits.waitForDOMready();
			// TODO Page taking time to load the links in the page
			waits.staticWait(3);
			WebElement btnTobeClicked = null;
			switch (linkName) {
			case "First":
				btnTobeClicked = linkSentMessage;
				txtSubjectReadMessage = webActions.getText(linkSentMessage);
				break;
			case "Cancel":
				btnTobeClicked = btnCancelMessage;
				break;
			case "No":
				btnTobeClicked = btnNoConfirmation;
				break;
			case "Yes":
				btnTobeClicked = btnYesConfirmation;
				break;
			case "Delete button":
				btnTobeClicked = btnDeleteReadMessage;
				break;
			case "Submit":
				btnTobeClicked = btnSubmitSendMessage;
				break;
			case "Replay":
				btnTobeClicked = btnReplayMessage;
				break;
			case "Replay Message":
				btnTobeClicked = btnReplayMessageWC;
				break;
			case "Send":
				btnTobeClicked = btnSendWebcom;
				break;
			case "Send Replay":
				btnTobeClicked = btnSendReplayWebcom;
				break;
			default:
				LogUtility.logInfo("-->clickOnLink<--", "No case is matched");
				break;
			}
			waits.waitForPageReadyState();
			if (webActions.isDisplayed(btnTobeClicked)) {
				webActions.clickElement(btnTobeClicked);
				//static wait to handle alert in firefox
				waits.staticWait(5);
				if (wolWebUtil.isAlertPresent())
					alerts.acceptAlert();
				LogUtility.logInfo("-->clickOnLink<--", "Link: " + linkName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnLink<--", "Link: " + linkName + " is not clicked", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkServiceMessage - To check the service message
	 * 
	 * @param serviceMessage
	 * @return
	 */
	public boolean checkServiceMessage(String serviceMessage) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			if (wolWebUtil.verifyTextContains(txtServiceCenterMessage, serviceMessage)) {
				LogUtility.logInfo("-->checkServiceMessage<--", serviceMessage + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkServiceMessage<--", serviceMessage + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkDisplay - To verify the display of the button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean checkDisplay(String btnName) {
		try {
			WebElement btnTobeChecked = null;
			switch (btnName) {
			case "Cancel":
				btnTobeChecked = btnCancelMessage;
				break;
			case "Submit":
				btnTobeChecked = btnSubmitSendMessage;
				break;
			case "Delete":
				btnTobeChecked = btnDeleteReviewMessage;
				break;
			case "Delete of Read":
				btnTobeChecked = btnDeleteReadMessage;
				break;
			default:
				LogUtility.logInfo("-->checkDisplay<--", "No case is matched");
				break;
			}
			waits.waitForDOMready();
			if (webActions.isDisplayed(btnTobeChecked)) {
				LogUtility.logInfo("-->checkDisplay<--", "Button: " + btnName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkDisplay<-", "Button: " + btnName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * getText-- To get the text of the webelement
	 * 
	 * @param msgElement
	 * @return
	 */
	public String getText(String msgElement) {
		waits.waitForDOMready();
		waits.waitForPageToLoad(maxTimeOut);
		try {
			return webActions.getText(txtReadMessage);
		} catch (Exception e) {
			LogUtility.logException("-->getText<--", "Element text is not present", e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkLinkDisplay : To check the display of links
	 * 
	 * @return
	 */
	public boolean checkLinkDisplay() {
		try {
			waits.waitForDOMready();
			if (listLinks.size() == 0) {
				LogUtility.logInfo("-->checkLinkDisplay<--",
						txtSubjectReadMessage + " is not displayed as there are not accounts");
				return true;
			}
			for (WebElement link : listLinks) {
				if (!wolWebUtil.verifyTextContains(link, txtSubjectReadMessage)) {
					LogUtility.logInfo("-->checkLinkDisplay<--", txtSubjectReadMessage + " is not displayed");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->checkLinkDisplay<-", txtSubjectReadMessage + " is displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * getLabelErrorText -- To get the error message at label
	 * 
	 * @param labelName
	 * @param errorMessage
	 * @return
	 */
	public boolean getLabelErrorText(String labelName, String errorMessage) {
		try {
			waits.waitForDOMready();
			for (WebElement txtError : listErrors)
				if (wolWebUtil.verifyTextContains(txtError, jsonDataParser.getTestDataMap().get(errorMessage))) {
					LogUtility.logInfo("-->getLabelErrorText<--", errorMessage + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->getLabelErrorText<-", errorMessage + " is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * enterRandomText : To Enter the random text in text filed
	 * 
	 * @param textAreaName
	 * @param size
	 * @return
	 */
	public boolean enterRandomText(String textAreaName, int size) {
		waits.waitForPageReadyState();
		String text = wolWebUtil.getRandomString(size);
		try {
			WebElement txtBox = null;
			switch (textAreaName) {
			case "Subject":
				txtBox = txtSubjectBox;
				txtSubject = text;
				break;
			case "Message":
				txtBox = txtMessageBox;
				break;
			default:
				LogUtility.logInfo("-->enterRandomText<--", "No case is matched");
				break;
			}
			waits.waitForDOMready();
			if (webActions.isDisplayed(txtBox)) {
				if (listAccounts.size() > 0)
					accountNumber = webActions.getText(listAccounts.get(0));
				webActions.setValue(txtBox, text);
				LogUtility.logInfo("-->enterRandomText<--", "Text: " + text + " is entered");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterRandomText<--", "Text: " + text + " is not entered", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkUpdateMessage : To verify for the update message
	 * 
	 * @param updatedMessage
	 * @return
	 */
	public boolean checkUpdateMessage(String updatedMessage) {
		waits.waitForDOMready();
		try {
			if (wolWebUtil.verifyTextContains(txtUpdateMessage, updatedMessage))
				LogUtility.logInfo("-->checkUpdateMessage<--", updatedMessage + " is displayed");
			return true;
		} catch (Exception e) {
			LogUtility.logException("->checkUpdateMessage<--", updatedMessage + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectAccount : To select the first account from drop-down list
	 * 
	 * @return
	 */
	public boolean selectAccount() {
		waits.waitForDOMready();
		waits.waitForPageToLoad(maxTimeOut);
		try {
			if (webActions.isDisplayed(listAccounts.get(0))) {
				webActions.selectDropDownByIndex(listAccounts.get(0), 1);
				LogUtility.logInfo("-->selectAccount<--", "Selected the questions");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->selectAccount<-", "not selected the questions", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnComposeWC: To click on compose in Webcom
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickOnLinksWC(String linkName) {
		waits.waitForDOMready();
		waits.waitForPageToLoad(maxTimeOut);
		try {
			waits.waitForDOMready();
			if (webActions.isDisplayed(menuCompose)) {
				webActions.clickElement(menuCompose);
				LogUtility.logInfo("-->clickOnComposeWC<---", "Clicked on Menu: " + linkName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnComposeWC<-", "not clicked on Menu: " + linkName, e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * clickOnComposeWC: To click on compose in Webcom
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickOnLinkGetNext(String linkName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(menuGetNext)) {
				webActions.clickElement(menuGetNext);
				waits.waitForDOMready();
				// TODO: To load the messages count it is taking time
				waits.staticWait(5);
				while (!wolWebUtil.verifyText(txtInboxMessages, "0")) {
					waits.waitForPageReadyState();
					webActions.clickElement(menuGetNext);
				}
				LogUtility.logInfo("-->clickOnLinkGetNext<---", "Clicked on Menu: " + linkName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnLinkGetNext<-", "not clicked on Menu: " + linkName, e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * enterDataInField: Enter the data in field
	 * 
	 * @param data
	 * @param fieldName
	 * @return
	 */
	public String enterDataInField(String data, String fieldName) {
		waits.waitForDOMready();
		if (data.equalsIgnoreCase("Random"))
			data = wolWebUtil.getRandomString(6);
		try {
			WebElement txtBox = null;
			switch (fieldName) {
			case "To":
				txtBox = inputTo;
				data = WOLTestBase.envProps.getProperty(data);
				break;
			case "Subject":
				txtBox = inputSubject;
				txtSubject = data;
				break;
			case "Message":
				txtBox = inputMessage;
				break;
			default:
				LogUtility.logInfo("-->enterDataInField<--", "No case is matched");
				break;
			}
			waits.waitForDOMready();
			webActions.setValue(txtBox, data);
			LogUtility.logInfo("-->enterDataInField<--", "Data: " + data + " is entered at field:" + fieldName);
			return data;
		} catch (Exception e) {
			LogUtility.logException("->enterDataInField<--", "Data: " + data + " is not entered at field:" + fieldName,
					e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkInboxSubject: To check the subject in inbox
	 * 
	 * @return
	 */
	public boolean checkInboxSubject() {
		try {
			waits.waitForDOMready();
			WebElement updateMessage = driver
					.findElement(By.xpath(String.format("//*[contains(text(),'%s')]", txtSubject)));
			// TODO: Element is taking time to load
			waits.staticWait(5);
			if (webActions.isDisplayed(updateMessage)) {
				webActions.clickElement(updateMessage);
				LogUtility.logInfo("--->checkInboxSubject<---", "Subject is present in inbox");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkInboxSubject<--", "Subject is not present in inbox", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * selectDataInField: To select the value from drop-down
	 * 
	 * @param data
	 * @param fieldName
	 * @return
	 */
	public boolean selectDataInField(String data, String fieldName) {
		waits.waitForDOMready();
		String index = null;
		if (data.equalsIgnoreCase("Random"))
			index = wolWebUtil.getRandomNumber(1);
		try {
			if (webActions.isDisplayed(listStdReplay)) {
				webActions.selectDropDownByIndex(listStdReplay, Integer.parseInt(index));
				LogUtility.logInfo("-->selectDataInField<--",
						"Index Value: " + index + " is selected at field:" + fieldName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->selectDataInField<--",
					"Index Value: " + index + " is not selected at field:" + fieldName, e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyButton: To verify the buttons in message center
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean verifyButton(String btnName) {
		waits.waitForPageReadyState();
		try {
			WebElement btnToBeCheck = null;
			switch (btnName) {
			case "Replay":
				btnToBeCheck = btnReplayMessageWC;
				break;
			case "Print":
				btnToBeCheck = btnPrintMessageWC;
				break;
			case "Delete":
				btnToBeCheck = btnDeleteMessageWC;
				break;
			case "Forward Loan":
				btnToBeCheck = btnFwdMessageWC;
				break;
			default:
				LogUtility.logInfo("-->verifyButton<--", "No case is matched");
				break;
			}
			waits.waitForDOMready();
			if (webActions.isDisplayed(btnToBeCheck)) {
				LogUtility.logInfo("-->verifyButton<--", "Button: " + btnName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyButton<--", "Button: " + btnName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifySubjectClickable: To verify subject is clickable
	 * 
	 * @return
	 */
	public boolean verifySubjectClickable() {
		waits.waitForDOMready();
		try {
			for (WebElement link : listReviewSubjectLinks)
				if (webActions.isDisplayed(link) && webActions.isEnabled(link)) {
					waits.waitToBeClickable(link, maxTimeOut.intValue());
					LogUtility.logInfo("-->verifySubjectClickable<--", "Link: " + link.getText() + " is clickable ");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->verifySubjectClickable<--", "Some of the links is/are not clickable ", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyBlueLinksDeleteCheckbox: To verify the links are displaying as bold-no
	 * check-box, not bold- check-box
	 * 
	 * @return
	 */
	public boolean verifyBlueLinksDeleteCheckbox() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			int linksCorrectCount = 0;
			for (int linkCount = 1; linkCount <= listReviewSubjectLinks.size(); linkCount++) {
				listLink = driver.findElements(By.cssSelector(String.format(basePath + linkCount + boldLinkPath)));
				listDeleteCheckbox = driver
						.findElements(By.cssSelector(String.format(basePath + linkCount + deleteCheckboxPath)));
				if (listLink.size() == 0) {
					if (listDeleteCheckbox.size() == 1) {
						LogUtility.logInfo("-->verifySubjectClickable<--",
								linkCount + " link is not in bold and has a delete checkbox");
						linksCorrectCount++;
					} else if (listDeleteCheckbox.size() == 0)
						LogUtility.logInfo("-->verifySubjectClickable<--",
								linkCount + " link is not in bold and has not a delete checkbox");
				} else if (listLink.size() == 1)
					if (listDeleteCheckbox.size() == 0) {
						LogUtility.logInfo("-->verifySubjectClickable<--",
								linkCount + " link is in bold and has not a delete checkbox");
						linksCorrectCount++;
					} else if (listDeleteCheckbox.size() == 1)
						LogUtility.logInfo("-->verifySubjectClickable<--",
								linkCount + " link is in bold and has a delete checkbox");
			}
			if (linksCorrectCount == listReviewSubjectLinks.size())
				return true;
			else
				return false;
		} catch (Exception e) {
			LogUtility.logException("-->verifySubjectClickable<--", "Some of the links is/are not clickable ", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyReplayButton: To verify the replay button for the message which is not
	 * related to payment and transaction
	 * 
	 * @param replayButton
	 * @return
	 */
	public boolean verifyReplayButton(String replayButton) {
		waits.waitForPageReadyState();
		try {
			if (txtSubjectReadMessage.equalsIgnoreCase("payment")
					|| txtSubjectReadMessage.equalsIgnoreCase("transaction")) {
				LogUtility.logInfo("-->verifyReplayButton<--", "Message is related to either payment or transaction");
				return true;
			} else if (webActions.isDisplayed(btnReplayReadMessage)) {
				LogUtility.logInfo("-->verifyReplayButton<--", "Button: " + replayButton + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyReplayButton<--", "Button: " + replayButton + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkAccountNumber : To verify the account number
	 * 
	 * @return accountNumber
	 */
	public String checkAccountNumber() {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtAccountNumber, accountNumber)) {
				LogUtility.logInfo("-->checkAccountNumber<--", "Account: " + accountNumber + " is displayed");
				return accountNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkAccountNumber<--", "Account: " + accountNumber + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return accountNumber;
	}
}