package com.wb.wol_web.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.wol_web.pages.LoginPageObject;
import com.wb.wol_web.utilities.ActionsHolder;

public class LoginPageActions {
	
	ActionsHolder actions;
	LoginPageObject page;
	WebDriver driver;
	
	public LoginPageActions(ActionsHolder actions) {
		this.actions = actions;
		page = new LoginPageObject();
		driver = ConcurrentEngines.getEngine().getWebDriver();
		
		PageFactory.initElements(driver, page);
	}
	
	public void enterUserName(String userName){
		page.usernameTextBox.sendKeys(userName);
		
	}
	
	public void clickGoButton(){
		page.goButton.click();
	}
	
	public void enterPassword(String password){
		page.passwordTextBox.sendKeys(password);
	}
	
	public void clickContinue(){
		page.continueButton.click();
	}
	
}