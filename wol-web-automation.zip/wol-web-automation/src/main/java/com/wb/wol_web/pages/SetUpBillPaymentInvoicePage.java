
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class SetUpBillPaymentInvoicePage extends ObjectBase {

	public SetUpBillPaymentInvoicePage() {
		PageFactory.initElements(driver, this);
	}

	PaymentCenterPage paymentCentre = new PaymentCenterPage();
	ArrayList<String> payeesFromInvoicePage = new ArrayList<String>();
	ArrayList<String> payeesFromManagePayeesPage = new ArrayList<String>();

	@FindBy(css = "[id*='relationshipid'][class='payee  js-designation-toggle']")
	protected WebElement lstPayeeName;

	@FindBy(name = "invoice_number")
	protected WebElement txtInvoiceNumber;

	@FindBy(name = "item_description1")
	protected WebElement txtDesc;

	@FindBy(name = "item_amount1")
	protected WebElement txtAmount;

	@FindBy(id = "addressform")
	protected WebElement formAddress;

	@FindBy(name = "item_description6")
	protected WebElement txtAddedDesc;

	@FindBy(name = "item_amount6")
	protected WebElement txtAddedAmount;

	@FindBy(id = "button_edit_impl")
	protected WebElement btnEdit;

	@FindBy(id = "addDescButtonImpl")
	protected WebElement btnAddDescription;

	@FindBy(id = "duplicatebtn")
	protected WebElement btnDuplicateBills;

//	@FindAll(@FindBy(xpath = "//*[@class='showDesc']"))
	@FindAll(@FindBy(css = "tr.showDesc"))
	protected List<WebElement> lstDescRows;

	@FindAll(@FindBy(css = "#addressform input[name='address_id']"))
	protected List<WebElement> lstAddresses;

	@FindBy(css = "[data-wbst-message-key*='eu.paymentsWI.title']")
	protected WebElement pageTitle;

//	@FindBy(xpath = "//*[text()='Setup Payment']")
	@FindBy(id = "setupWIAction")
	protected WebElement btnSetUpPayment;

//	@FindAll(@FindBy(xpath = "//optgroup[@label='Business Accounts']/option"))
	@FindAll(@FindBy(css = "optgroup[label='Business Accounts'] option"))
	protected List<WebElement> lstBusinessAccc;

//	@FindAll(@FindBy(xpath = "//optgroup[@label='Personal Accounts']/option"))
	@FindAll(@FindBy(css = "optgroup[label='Personal Accounts'] option"))
	protected List<WebElement> lstPersonalAccc;

//	@FindBy(xpath = "//*[@data-wbst-message-key='eu.payment.no_payees.P']")
	@FindBy(css = "[data-wbst-message-key='eu.payment.no_payees.P']")
	protected WebElement errorMesgNoPayeeP;

//	@FindBy(xpath = "//*[@data-wbst-message-key='eu.payment.no_payees.B']")
	@FindBy(css = "[data-wbst-message-key='eu.payment.no_payees.B']")
	protected WebElement errorMesgNoPayeeB;

	@FindBy(id = "payment_date")
	protected WebElement paymentDate;

	@FindBy(id = "account_id")
	protected WebElement selAccount;

	@FindBy(id = "account_id")
	protected WebElement dialogLightBox;

	@FindBy(id = "check_notice")
	protected WebElement chkNotice;

	@FindBy(id = "managePayees_table__filter__input")
	protected WebElement lstShowOnly;

	@FindBy(xpath = "//div[@class='lightbox-wrap is-visible is-top']//button[@aria-label=\"Close the dialog\"]")
	protected WebElement btnCloseDialogBox;

	@FindAll(@FindBy(css = "[id='relationshipid_B'][class='payee  js-designation-toggle'] option"))
	protected List<WebElement> lstPayeesDisplayed;

	@FindAll(@FindBy(css = "li[id*='managePayees_table_row'][data-mm-hidden='false'] span[aria-label='Payee']"))
	protected List<WebElement> lstPayeesDisplayedMP;

	/**
	 * To enter the invoice details
	 * 
	 * @param desc
	 * @param amount
	 * @param payeeName
	 * @throws Exception
	 */
	public void enterInvoiceDetails(String desc, String amount, String payeeName) throws Exception {
		try {

			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(lstPayeeName, maxTimeOut);
			wolWebUtil.selectValueByPartialVisibleText(lstPayeeName, payeeName);
			webActions.setValue(txtInvoiceNumber, wolWebUtil.getRandomNumber(6));
			webActions.setValue(txtDesc, desc);
			webActions.setValue(txtAmount, amount);
			if (waits.waitUntilElementIsPresent(formAddress, maxTimeOut)) {
				webActions.clickElement(lstAddresses.get(0));
			}
			LogUtility.logInfo("---> enterInvoiceDetails <---", "Entered the invoice details");
		} catch (Exception e) {
			LogUtility.logException("enterInvoiceDetails", "Failed to enter invoice payment details", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Click on the button based on the buttonname
	 * 
	 * @param buttonName
	 */
	public boolean clickOnTheButton(String buttonName) {
		boolean status = false;
		try {
			WebElement eleToClick = null;
			waits.waitForDOMready();
			switch (buttonName) {
			case "Continue":
				eleToClick = paymentCentre.btnDeleteInVerficationPage;
				break;
			case "Edit":
				eleToClick = btnEdit;
				break;
			case "AddDescription":
				eleToClick = btnAddDescription;
				break;
			case "SetUpPayment":
				eleToClick = btnSetUpPayment;
				break;
			}
			if (webActions.isDisplayed(eleToClick)) {
				webActions.clickElement(eleToClick);
				status = true;
			}
			if (buttonName.equals("Continue")) {
				if (waits.waitUntilElementIsPresent(btnDuplicateBills, maxTimeOut)) {
					webActions.clickElement(btnDuplicateBills);
				}
			}
			LogUtility.logInfo("---> clickOnTheButton <---", "Clicked on " + buttonName);
		} catch (Exception e) {
			LogUtility.logException("clickOnTheButton", "Failed to click on the button", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Check if the extra rows of description are added
	 * 
	 * @return
	 */
	public boolean checkExtraAddDescriptions() {
		if (lstDescRows.size() > 5) {

			return true;
		} else
			return false;
	}

	/**
	 * To enter the extra details in descriptions and amount fields
	 * 
	 * @param desc
	 * @param amount
	 * @throws Exception
	 */
	public void enterExtraDescriptionAndAmount(String desc, String amount) throws Exception {
		try {
			webActions.setValue(txtAddedDesc, desc);
			webActions.setValue(txtAddedAmount, amount);
			LogUtility.logInfo("---> enterExtraDescriptionAndAmount <---", "Entered the extra invoice details");
		} catch (Exception e) {
			LogUtility.logException("enterExtraDescriptionAndAmount", "Failed to add extra description", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * To check the page tilte against the param
	 * 
	 * @param Title
	 * @return
	 */
	public boolean checkPageTitle(String title) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(pageTitle, maxTimeOut);
			if (title.equals(webActions.getText(pageTitle)))
				status = true;
		} catch (Exception e) {
			LogUtility.logException("checkPageTitle", "Failed to check pageTitle", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To select from account dropdown
	 * 
	 * @param Title
	 * @return
	 */
	public void selectFromAccountDropdown(String accType) {
		try {
			List<WebElement> eleList = new ArrayList<>();
			if (accType.equals("Personal Accounts"))
				eleList = lstPersonalAccc;
			else
				eleList = lstBusinessAccc;

			webActions.clickElement(selAccount);
			waits.waitVisibilityOfAllElements(eleList);
			webActions.clickElement(eleList.get(0));
			waits.waitForPageToLoad(maxTimeOut);

			LogUtility.logInfo("---> selectFromAccountDropdown <---", "Selected " + accType + " from account dropdown");
		} catch (Exception e) {
			LogUtility.logException("selectFromAccountDropdown",
					"Failed to select " + accType + " from account dropdown", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To check for the error messages in a page
	 * 
	 * @param lookFor determines which type of message
	 * @param message - expected message
	 * @return
	 */
	public boolean checkTheErrorMessageInPage(String lookFor, String message) {
		boolean status = false;
		try {
			WebElement eleToGetText = null;
			switch (lookFor) {
			case "NoPersonalpayees":
				eleToGetText = errorMesgNoPayeeP;
				break;
			case "NoBusinessPayees":
				eleToGetText = errorMesgNoPayeeB;
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (webActions.getText(eleToGetText).equals(message)) {
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheErrorMessageInPage", "Failed to check the error message", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check the format of delivery date
	 * 
	 * @return
	 */
	public boolean checkForDeliveryDate() {
		boolean status = false;
		try {
			webActions.selectDropDownByIndex(lstPayeeName, 2);
			String date = webActions.getText(paymentDate);
			if (!date.equals("//")) {
				if (wolWebUtil.dateValidation(date))
					status = true;
				LogUtility.logInfo("---> checkForDeliveryDate <---", "Date  is in correct format " + date);
			}
			return status;
		} catch (Exception e) {
			LogUtility.logException("checkForDeliveryDate", "Failed to check delivery date", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * Checks for the dialog box which comes intermittently based on the user type
	 * and closes it
	 * 
	 * @throws Exception
	 * 
	 */
	public void checkForDialogBox() throws Exception {
		try {
			waits.waitUntilElementIsPresent(chkNotice, maxTimeOut);
			if (webActions.isDisplayed(chkNotice)) {
				webActions.clickElement(chkNotice);
				webActions.clickElement(btnCloseDialogBox);
			}
		} catch (Exception e) {
			LogUtility.logException("checkForDialogBox", "Failed to check for DialogBox", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public ArrayList<String> getListOfSelectPayeesDisplayed() {
		try {
			for (WebElement ele : lstPayeesDisplayed) {
				if (!ele.getText().equals("Select a payee")) {
					if (ele.getText().contains("\n"))
						payeesFromInvoicePage.add(ele.getText().split("\n")[0].trim());
					else
						payeesFromInvoicePage.add(ele.getText().split("xxxx")[0].replace(" (", "").trim());

				}
			}
			LogUtility.logInfo("getListOfSelectPayeesDisplayed",
					"List of payees in manage payees : " + payeesFromInvoicePage);
		} catch (Exception e) {
			LogUtility.logException("getListOfSelectPayeesDisplayed", "Failed to get the list of payees", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		return payeesFromInvoicePage;
	}

	public ArrayList<String> getListOfPayeesInManagePayees() {
		try {
			for (WebElement ele : lstPayeesDisplayedMP) {
				payeesFromManagePayeesPage.add(ele.getText().trim());
			}
			LogUtility.logInfo("getListOfPayeesInManagePayees",
					"List of payees in manage payees : " + payeesFromManagePayeesPage);
		} catch (Exception e) {
			LogUtility.logException("getListOfPayeesInManagePayees",
					"Failed to get the list of payees in manage payees page", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return payeesFromManagePayeesPage;
	}

	public boolean comparePayees() {
		boolean status = false;
		try {
			status = payeesFromInvoicePage.equals(payeesFromManagePayeesPage);
		} catch (Exception e) {
			LogUtility.logException("comparePayees", "Failed to compare the payees", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean selectFromShowOnlyList(String type) {
		boolean status = false;
		try {
			webActions.selectDropDownByText(lstShowOnly, type);
			if (wolWebUtil.getDefaultValueForSelect(lstShowOnly).equals(type)) {
				status = true;
				LogUtility.logInfo("selectFromShowOnlyList", "Selected " + type + " from the showonly dropdown");
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromShowOnlyList", "Failed to select the type from showonly dropdown", e,
					LoggingLevel.ERROR, true);
		}
		return status;

	}

}
