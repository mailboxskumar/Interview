
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class NAOPage extends ObjectBase {

	public NAOPage() {
		PageFactory.initElements(driver, this);
	}

	public String accountNameLink = "//a[@title='ReplaceMe' or @title='ReplaceMe >>' ]";
	public String mainTab = "//nav[@aria-label='Menu Navigation']//a[text()='ReplaceMe']";
	HashMap<String, String> confirmationDetails = new HashMap<String, String>();
	public String rateRange = "section[data-bdm-account-type='%s'] article div:nth-child(2) span[class=' display']";
	public String interestRate = "section[data-bdm-account-type='%s'] article div:nth-child(3) span[class=' display']";
	public String aypRate = "section[data-bdm-account-type='%s'] article div:nth-child(4) span[class=' display']";
	public List<WebElement> eleRateRange = null;
	public List<WebElement> eleinterestRate = null;
	public List<WebElement> eleaypRate = null;
	public List<String> lstRateRange = new ArrayList<String>();
	public List<String> lstInterestRate = new ArrayList<String>();
	public List<String> lstApyRate = new ArrayList<String>();
	public String tblBasepath = "//tbody//tr[";
	public String tblTermPath = "]//td[3]/input[1]";
	public String rateRangePath = "]//td[8]/input[1]";
	public String interestPath = "]//td[9]/input[1]";
	public String apyPath = "]//td[10]/input[1]";

	@FindBy(id = "existingCustomerLink")
	protected WebElement linkExistingCustomer;

	@FindBy(name = "username")
	private WebElement txtUserName;

	@FindBy(id = "nao-disclosures__pageErrors_gen__DISCLOSURES__ERROR__body")
	protected WebElement txtDisclosureMessage;

	@FindBy(id = "nao-error-with-info__pageNote_gen__body")
	protected WebElement txtFailEquifaxMessage;

	@FindBy(id = "open_account_form__formSectionIdentification__section-title")
	protected WebElement txtIndentInfoTitle;

	@FindBy(id = "open_account_form__formSectionDriverLicense__section-title")
	protected WebElement txtLicensePageTitle;

	@FindBy(id = "open_account_form__formSectionEmployment__section-title")
	protected WebElement txtEmploymentInfoTitle;

	@FindBy(id = "open_account_form__formSectionSelectAccount__section-title")
	protected WebElement txtReviewAccountTitle;

	@FindBy(id = "open_account_form__formSectionPersonal__section-title")
	protected WebElement txtPersonalInfoTitle;

	@FindBy(id = "accountInformationSection__section-title")
	protected WebElement txtOCAccInfoTitle;

	@FindBy(id = "residency_block__label")
	protected WebElement txtResidentTitle;

	@FindBy(id = "accountOptions__label")
	protected WebElement txtAccOptionsTitle;

	@FindBy(id = "enroll_edelivery__input")
	protected WebElement btnOCEDelivery;

	@FindBy(id = "open_account_form__formSectionVerifyPromoInvalid__section-note")
	protected WebElement txtPromoErrorMsg;

	@FindBy(id = "ok")
	protected WebElement btnPromoOK;

	@FindBy(id = "visa_check_card__input")
	protected WebElement btnOCDebitCard;

	@FindBy(css = "#opportunityTermsAndRates__selectedAccount__display  span")
	protected WebElement txtAccNameInOCPage;

	@FindBy(xpath = "//div[@id='lightBoxContent1']//p/b")
	protected WebElement txtOverDraftLightBox;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle1']//button[text()='Close']")
	protected WebElement btnDisclosureClose;

	@FindBy(xpath = "//legend[@id='overdraft__label']/a")
	protected WebElement linkOverDraft;

	@FindBy(id = "accountOptions__label--with-tooltip-0")
	protected WebElement statementToolTip;

	@FindBy(id = "nao-confirmation-error__pageAffirmativeNotice_gen__body")
	protected WebElement txtSuccessfullyApplied;

	@FindBy(xpath = "//div[@aria-describedby='lightBoxContent1']//button[@aria-label='Close the dialog']")
	protected WebElement btnOverDraftClose;

	@FindBy(xpath = "//span[contains(@id,'__selectedAccount__display')]/span")
	protected WebElement txtAccountNameInReview;

	@FindBy(id = "open_account_form__formSectionInternationalWireServices__section-title")
	protected WebElement txtInternationalWireTitle;

	@FindBy(id = "open_account_form__formSectionAccountInformation__section-title")
	protected WebElement txtAccInfoTitle;

	@FindBy(id = "personalInfoFormSection__section-title")
	protected WebElement txtVerifyInfoPage;

	@FindBy(id = "debitCardDisclosure")
	protected WebElement txtDisclosureContent;

	@FindBy(id = "username__input")
	protected WebElement inputUserName;

	@FindBy(id = "password__input")
	protected WebElement inputPassword;

	@FindBy(id = "reenterPassword__input")
	protected WebElement inputConfirmPassword;

	@FindBy(id = "formSectionDisclosuresMain__section-title")
	protected WebElement txtDisclosurePageTitle;

	@FindBy(id = "open_account_form__formSectionPersonal__section-title")
	protected WebElement txtRevPersonalInfoPageTitle;

	@FindBy(xpath = "//*[text()='Debit Card Overdraft Services']")
	protected WebElement txtOverDraftTitle;

	@FindBy(id = "cardStockTypeCode__label")
	protected WebElement txtChooseDBCard;

	@FindBy(id = "intendtoWire__radio__Range5Kto10K__input")
	protected WebElement btnIntendWire5KRange;

	@FindBy(id = "odp-12__input")
	protected WebElement btnOverdraftYes;

	@FindBy(id = "odp-13__input")
	protected WebElement btnOverdraftNo;

	@FindBy(id = "visa_check_card__input")
	protected WebElement btnEstatementEnroll;

	@FindBy(id = "domestic__input")
	protected WebElement btnDomestic;

	@FindBy(id = "nao-confirmation-auth__pageAffirmativeNotice_gen__body")
	protected WebElement txtConfirmation;

	@FindBy(id = "nao-confirmation-cd-auth__pageAffirmativeNotice_gen__body")
	protected WebElement txtConfirmationCD;

	@FindBy(xpath = "//span[text()='Bank']")
	protected WebElement btnBank;

	@FindBy(xpath = "//span[text()='Banking']")
	protected WebElement btnBanking;

	@FindBy(xpath = "//li[@id='om-leaf-om-u1-1501127809-1']//div[@style='display: block;']")
	protected WebElement btnBankBlock;

	@FindBy(css = "#block-system-main p")
	protected WebElement txtSSNAlreadyExistsLogin;

	@FindBy(id = "cdd_pep_question2__label")
	protected WebElement txtPEPQues2Label;

	@FindBy(id = "cdd_pep_question1__label")
	protected WebElement txtPEPQues1Label;

	@FindBy(id = "citizenship__label")
	protected WebElement txtCitizenShipLabel;

	@FindBy(id = "cdd_pep_question2__label--with-tooltip-0")
	protected WebElement toolTipPEPQues2;

	@FindBy(id = "cdd_pep_question1__label--with-tooltip-0")
	protected WebElement toolTipPEPQues1;

	@FindBy(xpath = "//ul[@id='om-menu-personal']//a[text()='CDs']")
	protected WebElement linkCDs;

	@FindBy(xpath = "//ul[@id='om-menu-personal']//a[text()='Checking Accounts']")
	protected WebElement linkChecking;

	@FindBy(xpath = "//ul[@id='om-menu-personal']//a[text()='Savings Accounts']")
	protected WebElement linkSavings;

	@FindBy(xpath = "//ul[@id='om-menu-business']//a[text()='Checking']")
	protected WebElement linkBusinessChecking;

	@FindBy(xpath = "//a[text()='Open an account ']")
	protected WebElement btnOpenAccount;

	@FindBy(xpath = "//*[@data-mm-template='pageTitle']")
	protected WebElement txtStartPageHeading;

	@FindBy(id = "custemail__input")
	protected WebElement inputCustEmail;

	@FindBy(id = "fullNameTextInputField__inputFirstName")
	protected WebElement inputFirstName;

	@FindBy(id = "fullNameTextInputField__inputMiddleInitial")
	protected WebElement inputMiddleName;

	@FindBy(id = "fullNameTextInputField__inputLastName")
	protected WebElement inputLastName;

	@FindBy(id = "hero_module_cta")
	protected WebElement linkOpenAnAccount;

	@FindBy(id = "address1__input")
	protected WebElement inputAddress1;

	@FindBy(id = "address2__input")
	protected WebElement inputAddress2;

	@FindBy(id = "city__input")
	protected WebElement inputCity;

	@FindBy(id = "zipCode__input")
	protected WebElement inputZipCode;

	@FindBy(id = "ssn__input")
	protected WebElement inputSSN;

	@FindBy(id = "states__input")
	protected WebElement inputStates;

	@FindBy(id = "date__input")
	protected WebElement inputDOB;

	@FindBy(id = "homephone__input")
	protected WebElement inputHomePhone;

	@FindBy(id = "citizenship__input")
	protected WebElement selCitizenShip;

	@FindBy(id = "cdd_pep_question1_yes__input")
	protected WebElement btnPep1YesOption;

	@FindBy(id = "cdd_pep_question1_no__input")
	protected WebElement btnPep1NoOption;

	@FindBy(id = "cdd_pep_question2_yes__input")
	protected WebElement btnPep2YesOption;

	@FindBy(id = "cdd_pep_question2_no__input")
	protected WebElement btnPep2NoOption;

	@FindBy(id = "dlstate__input")
	protected WebElement selDLState;

	@FindBy(id = "empstatus__input")
	protected WebElement selEmpStatus;

	@FindBy(id = "dlnumber__input")
	protected WebElement inputDLNumber;

	@FindBy(id = "dlissuedate__input")
	protected WebElement inputDLIssueDate;

	@FindBy(id = "dlexpirydate__input")
	protected WebElement inputDLExpireDate;

	@FindBy(id = "empname__input")
	protected WebElement inputEmpName;

	@FindBy(id = "jobTitle__input")
	protected WebElement inputJobTitle;

	@FindBy(id = "cashin_transact__radio__LessThan5K__input")
	protected WebElement btnCashInLessThan5K;

	@FindBy(id = "personalInfoEditTopButton")
	protected WebElement btnToEditTopPersonal;

	@FindBy(id = "personalInfoEditBottomButton")
	protected WebElement btnToEditBottomPersonal;

	@FindBy(id = "accountInfoEditTopButton")
	protected WebElement btnToEditTopAccountInfo;

	@FindBy(id = "accountInfoEditBottomButton")
	protected WebElement btnToEditBotAccountInfo;

	@FindAll(@FindBy(xpath = "//input[contains(@id,'cashout_transact__radio__')]"))
	List<WebElement> lstCashOutOptions;

	@FindBy(id = "cashout_transact__radio__LessThan5K__input")
	protected WebElement btnCashOutLessThan5K;

	@FindBy(id = "wire_service_y__input")
	protected WebElement btnWireServiceY;

	@FindBy(id = "wire_service_n__input")
	protected WebElement btnWireServiceN;

	@FindBy(xpath = "//button[contains(@id,'__actualButton')]")
	protected WebElement btnContinue;

	@FindAll(@FindBy(css = "#open_account_form__formSectionVerifyDriverLicense__section-note p"))
	protected List<WebElement> txtDLErrorMsg;

	@FindBy(id = "promo_code__input")
	protected WebElement inputPromoCode;

	@FindBy(id = "accountName__label")
	protected WebElement txtAccNameLabelPromo;

	@FindBy(id = "offerInfo__label")
	protected WebElement txtOfferInfoLabel;

	@FindBy(id = "close")
	protected WebElement btnClose;

	@FindBy(id = "cashin_transact__label--with-tooltip-0")
	protected WebElement btnCashInToolTip;

	@FindBy(id = "cashout_transact__label--with-tooltip-0")
	protected WebElement btnCashOutToolTip;

	@FindBy(id = "accountOptions__label--with-tooltip-0")
	protected WebElement btnStatementEDelivery;

	@FindBy(id = "ssn__label")
	protected WebElement btnSSNToolTip;

	@FindBy(id = "dlnumber__label")
	protected WebElement btnLicenseNumToolTip;

	@FindBy(id = "cardStockTypeCode")
	protected WebElement debitCardBlock;

	@FindBy(id = "bussinessname__input")
	protected WebElement inputBusName;

	@FindBy(id = "busestdate__input")
	protected WebElement inputBusStartDate;

	@FindBy(id = "bussinessactivity__input")
	protected WebElement inputBusActivity;

	@FindBy(id = "cardStockTypeCode__defaultChoice__input")
	protected WebElement rdBtnNoCard;

	@FindBy(id = "nao-error-auth__pageNote_gen__body")
	protected WebElement txtUnableToOpenAcc;

	@FindBy(id = "nao-error-with-info__pageNote_gen__body")
	protected WebElement txtNegOpenAcc;

	@FindBy(id = "nao-error__pageNote_gen__body")
	protected WebElement txtNonResNonUSNotice;

	@FindBy(id = "nao-opportunity-offer__pageNote_gen__body")
	protected WebElement txtOCFailedMsg;

	@FindBy(id = "nao-personal-info__pageAffirmativeNotice_gen__body")
	protected WebElement txtAlreadyEnrolledNotice;

	@FindBy(id = "nao-start-auth-preconditions-error__pageErrors_gen__openaccount__premier__checking__required__body")
	protected WebElement txtPremierSavingErrorMsgExistingUser;

	@FindBy(id = "nao-start-preconditions-error__pageErrors_gen__openaccount__premier__savings__login__body")
	protected WebElement txtPremierSavingErrorMsg;

	@FindBy(xpath = "//div[@id='nao-personal-info__pageAffirmativeNotice_gen__body']/a")
	protected WebElement linkSignIn;

	@FindAll({ @FindBy(id = "cardStockTypeCode__DFLTVISA__input"), @FindBy(id = "cardStockTypeCode__DFLTPREM__input") })
	protected WebElement rdBtnDebitCard;

	@FindBy(id = "cardStockTypeCode__DFLTPREM__input")
	protected WebElement rdBtnPremierDebitCard;

	@FindBy(css = "input[name='odp']")
	protected List<WebElement> rdBtnsODP;

	@FindBy(id = "residency_block_no__labelCaption")
	protected WebElement rdBtnNonResAlien;

	@FindBy(id = "residency_block_yes__labelCaption")
	protected WebElement rdBtnResAlien;

	@FindBy(id = "overdraft__label")
	protected WebElement txtOverDraftHeading;

	@FindBy(xpath = "//p[@id='cdd_pep_question1__error-message-text']")
	protected WebElement txtPepQes2ErrorMsg;

	@FindBy(xpath = "//p[@id='cdd_pep_question2__error-message-text']")
	protected WebElement txtPepQes1ErrorMsg;

	@FindBy(css = "p[id='cashin_transact__error-message-text']")
	protected WebElement txtCashInErrorMsg;

	@FindBy(css = "p[id='cashout_transact__error-message-text']")
	protected WebElement txtCashOutErrorMsg;

	@FindBy(id = "pageError_gen_0__body")
	protected WebElement txtPageLevelMsg;

	@FindBy(xpath = "//a[contains(@title,'Opportunity Checking')]/ancestor::div[@class='row product-description-module']//a[text()='Open An Account']")
	protected WebElement btnOCOpenAccount;

	@FindAll(@FindBy(css = "[data-has-error='true'] [id*='__error-message-text']"))
	protected List<WebElement> txtPersonalInfoError;

	@FindBy(css = "div[data-has-error='true'] div[class*='error-message'] p")
	protected WebElement txtErrorMessage;

	@FindBy(css = "#promo_code__label")
	protected WebElement txtPromoLabel;

	@FindBy(css = "#continue__buttonText,#continue__actualButton")
	protected WebElement btnContinuePromo;

	@FindBy(css = "#custemail__error-message-text")
	protected WebElement txtEmailErrorMsg;

	@FindBy(id = "cancelButton")
	protected WebElement btnCancel;

	@FindBy(id = "doNotCancelButton")
	protected WebElement btnCancelNo;

	@FindBy(id = "confirmCancelButton")
	protected WebElement btnCancelYes;

	@FindAll(@FindBy(css = "[id*='__labelarea'] p"))
	protected List<WebElement> lstProgressBarLabels;

	@FindBy(id = "goBackLink")
	protected WebElement btnReturnHome;

	@FindBy(id = "Back")
	protected WebElement btnBack;

	@FindBy(id = "dlstate__error-message-text")
	protected WebElement txtDLStateError;

	@FindBy(id = "dlnumber__error-message-text")
	protected WebElement txtDLNumberError;

	@FindBy(id = "dlissuedate__error-message-text")
	protected WebElement txtDLStartDateError;

	@FindBy(id = "dlexpirydate__error-message-text")
	protected WebElement txtDLExpiryDateError;

	@FindBy(xpath = "//*[contains(text(),'Husky')]")
	protected WebElement txtHuskyCard;

	@FindBy(css = "div[class*='is-visible is-top'] #agreementContent h1")
	protected WebElement txtDisclosureHeading;

	@FindBy(css = "div[class*='is-visible is-top'] [aria-label='Close the dialog']")
	protected WebElement btnDiscloreClose;

	@FindBy(css = "#open_account_form__formSectionVerifyDriverLicense__section-note")
	protected WebElement txtLicenseLBText;

	@FindBy(css = "div p")
	protected WebElement txtSignInForExistingCust;

	@FindAll(@FindBy(css = "a[id*='disclosureList']"))
	protected List<WebElement> lstDisclosureLinks;

	@FindAll(@FindBy(css = "label[id*='disclosureList']"))
	protected List<WebElement> lstDisclosureLabels;

	@FindAll(@FindBy(xpath = "//div[contains(@data-mm-help-message-key,'nao-verify-info')]/label"))
	protected List<WebElement> lstVerifyLabels;

	@FindAll(@FindBy(xpath = "//div[contains(@data-mm-help-message-key,'nao-verify-info')]/span"))
	protected List<WebElement> lstVerifyValues;

	@FindAll(@FindBy(xpath = "//input[contains(@id,'question1__Emulation Answer')]"))
	protected List<WebElement> lstEmulation1RadioBtns;

	@FindAll(@FindBy(xpath = "//input[contains(@id,'question2__Emulation Answer')]"))
	protected List<WebElement> lstEmulation2RadioBtns;

	@FindAll(@FindBy(xpath = "//input[contains(@id,'disclosureList') and @type='checkbox']"))
	protected List<WebElement> lstDisclosuresCheckBox;

	@FindBy(xpath = "//*[@id='naoConfirmMainMessagingArea']/div[contains(@style,'margin')][2]")
	protected WebElement txtConfirmContent;

	@FindAll(@FindBy(xpath = "//div[contains(@data-mm-label-key,'nao-confirmation-auth')]/label"))
	protected List<WebElement> lstConfirmLabels;

	@FindAll(@FindBy(xpath = "//section[@id='naoConfirmMainMessagingArea']//p"))
	protected List<WebElement> lstConfirmMessages;

	@FindAll(@FindBy(xpath = "//div[contains(@data-mm-label-key,'nao-confirmation-auth')]//span[@class=' value']"))
	protected List<WebElement> lstConfirmValues;

	@FindAll(@FindBy(xpath = "//div[contains(@id,'__pageNote_gen__body')]//li"))
	protected List<WebElement> lstBulletPoints;

	@FindAll(@FindBy(xpath = "//span[contains(@id,'__display')]/span"))
	protected List<WebElement> lstPersonalInfoData;

	@FindAll(@FindBy(xpath = "//span[contains(@id,'__display')]/parent::div/label"))
	protected List<WebElement> lstPersonalInfoLabels;

	@FindAll(@FindBy(xpath = "//fieldset[@id='international_wire']//span"))
	protected List<WebElement> lstTransactionType;

	@FindAll(@FindBy(xpath = "//fieldset[@id='international_wire']//span/preceding-sibling::input"))
	protected List<WebElement> lstTransactionTypeCb;

	@FindAll(@FindBy(xpath = "//fieldset[@id='intendtoWire']//input//following-sibling::span"))
	protected List<WebElement> lstIntendToWire;

	@FindAll(@FindBy(xpath = "//fieldset[@id='intendtoWire']//span/preceding-sibling::input"))
	protected List<WebElement> lstIntendToWireCb;

	@FindAll(@FindBy(xpath = "//div[@id='selectAccountCdRatesTableWidget__buttonLayoutArea']/button"))
	protected List<WebElement> lstCDAccTypes;

	@FindAll(@FindBy(css = "#nao-start-main-disclosure>p"))
	protected List<WebElement> lstStartPageContent;

	@FindAll(@FindBy(xpath = "//span[contains(@id,'cashin_transact__radio__') and @class=' labelCaption']/../../input"))
	protected List<WebElement> lstCashInOptionsRdBtn;

	@FindAll(@FindBy(xpath = "//span[contains(@id,'cashin_transact__radio__') and @class=' labelCaption']"))
	protected List<WebElement> lstCashInOptionsTxt;

	@FindAll(@FindBy(xpath = "//span[contains(@id,'cashout_transact__radio__') and @class=' labelCaption']/../../input"))
	protected List<WebElement> lstCashOutOptionsRdBtn;

	@FindAll(@FindBy(xpath = "//span[contains(@id,'cashout_transact__radio__') and @class=' labelCaption']"))
	protected List<WebElement> lstCashOutOptionsTxt;

	@FindAll(@FindBy(css = "label[id*='odp'] span[class=' labelCaption']"))
	protected List<WebElement> lstOverDraftText;

	@FindAll(@FindBy(css = "div[id*='RatesTableWidget__tableHeaders__headerItem'] span"))
	protected List<WebElement> lstAPYRatesHeaders;

	@FindAll(@FindBy(css = "div[id*='RatesTableWidget__conditionsHeaders__headerItem'] span"))
	protected List<WebElement> lstConditionalHeaders;

	@FindAll(@FindBy(css = "table.dataTable tbody tr td a:nth-child(1)"))
	protected List<WebElement> lstViewLinks;

	@FindAll(@FindBy(css = "table.dataTable tbody tr td:nth-child(2)"))
	protected List<WebElement> lstSSNWebcom;

	@FindAll(@FindBy(css = "table tr td"))
	protected List<WebElement> lstAuditSteps;

	@FindBy(xpath = "//tbody//tr")
	protected List<WebElement> lstDepositTableRows;

	@FindBy(id = "cancelButton")
	protected WebElement btnDontKnowAnswer;

	@FindBy(id = "YesSure")
	protected WebElement btnImSure;

	@FindBy(id = "letMeTry")
	protected WebElement btnTryAgain;

	@FindBy(css = "[class='lightbox-wrap lightbox--dialog is-visible is-top'] [aria-label='Close the dialog']")
	protected WebElement btnClosePopup;

	/**
	 * To click on the main menu and click on the submenu element from the list
	 * 
	 * @param mainElement
	 * @param subElement
	 * @throws Exception
	 */
	public boolean selectFromHomepage(String mainElement, String subElement) throws Exception {
		boolean status = false;
		WebElement eleToClick = null;
		WebElement mainTabElement = null;
		if (mainElement.equals("Bank"))
			mainTabElement = btnBank;
		else
			mainTabElement = btnBanking;
		try {
			switch (subElement) {
			case "Savings":
				eleToClick = linkSavings;
				break;
			case "CD":
				eleToClick = linkCDs;
				break;
			case "Checking":
				eleToClick = linkChecking;
				break;
			case "Checking Tab":
				eleToClick = linkBusinessChecking;
				break;

			default:
				LogUtility.logInfo("selectFromHomepage", "Invalid option" + subElement);
			}
			waits.waitUntilElementExistence(mainTabElement);
			if (webActions.isDisplayed(mainTabElement)) {
				wolWebUtil.hoverOnTheElement(mainTabElement);
			}
			waits.staticWait(5);// Need to use this as mouse hovering is not working for other waits

			if (waits.waitUntilElementIsPresent(eleToClick, maxTimeOut)) {
				webActions.clickElement(eleToClick);
				status = true;
			} else {
				// this block is for IE hovering
				wolWebUtil.doubleClickOnTheElement(mainTabElement);
				waits.staticWait(2);
				webActions.clickElement(eleToClick);
				status = true;
			}

			LogUtility.logInfo("selectFromHomepage",
					"Clicked on the submenu " + subElement + " from " + mainElement + " tab");
		} catch (Exception e) {
			LogUtility.logException("selectFromHomepage", "Failed to click on the menu ", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To click on the account from the list of accounts displayed
	 * 
	 * @param accountName
	 * @throws Exception
	 */
	public void clickOnTheAccount(String accountName) throws Exception {
		try {
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			waits.staticWait(5);// Firefox takes more time to load this page
			driver.findElement(By.xpath(accountNameLink.replace("ReplaceMe", accountName))).click();
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(linkOpenAnAccount, maxTimeOut);
			webActions.clickElement(linkOpenAnAccount);
			LogUtility.logInfo("clickOnTheAccount", "Clicked on the Account " + accountName);
		} catch (Exception e) {
			LogUtility.logException("clickOnTheAccount", "Exception in Clicking the Account ", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * verify page heading
	 * 
	 * @param pageHeading
	 * @return
	 */
	public boolean checkForStartPageHeading(String pageHeading) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(txtStartPageHeading, maxTimeOut);
			if (wolWebUtil.verifyText(txtStartPageHeading, pageHeading)) {
				status = true;
				LogUtility.logInfo("checkForStartPageHeading", "Found the heading " + pageHeading);
			} else
				LogUtility.logError("checkForStartPageHeading", "could not find the message " + pageHeading);
		} catch (Exception e) {
			LogUtility.logException("checkForStartPageHeading", "Failed to find the heading ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * Enters the email details in NAO flow
	 * 
	 * @throws Exception
	 * 
	 */
	public boolean enterEmailDetails(Map<String, String> testDaMap) throws Exception {
		boolean status = false;
		waits.waitUntilElementIsPresent(inputCustEmail, maxTimeOut);
		try {
			if (webActions.isDisplayed(inputCustEmail)) {
				webActions.setValue(inputCustEmail, jsonDataParser.getTestDataMap().get("Email"));
				LogUtility.logInfo("enterEmailDetails", "Entered all email details");
				status = true;
			} else
				LogUtility.logError("enterEmailDetails", "could not enter the email details");
		} catch (Exception e) {
			LogUtility.logException("enterEmailDetails", "Exception in entering email id ", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
		return status;
	}

	/**
	 * Enters all the personal information
	 * 
	 * @throws Exception
	 */
	public void enterPersonalInformationDetails(Map<String, String> testDaMap) throws Exception {
		try {
			String ssn = "";
			String firstName = wolWebUtil.getRandomString(5);
			String lastName = wolWebUtil.getRandomString(5);
			String middleName = wolWebUtil.getRandomString(1);
			if (jsonDataParser.getTestDataMap().get("Social Security Number").equals("ReplaceMe"))
				ssn = wolWebUtil.getRandomNumber(9);
			else
				ssn = jsonDataParser.getTestDataMap().get("Social Security Number");

			String homePhone = "860" + wolWebUtil.getRandomNumber(7);

			jsonDataParser.getTestDataMap().put("Name", jsonDataParser.getTestDataMap().get("Date of Birth")
					.replaceAll("ReplaceMe", firstName + " " + middleName + " " + lastName));
			jsonDataParser.getTestDataMap().put("Social Security Number",
					jsonDataParser.getTestDataMap().get("Social Security Number").replaceAll("ReplaceMe", ssn));
			jsonDataParser.getTestDataMap().put("Best Phone Number",
					jsonDataParser.getTestDataMap().get("Best Phone Number").replaceAll("ReplaceMe", homePhone));

			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(inputSSN, maxTimeOut);
			webActions.setValue(inputSSN, ssn);
			webActions.setValue(inputFirstName, firstName);
			webActions.setValue(inputMiddleName, middleName);
			webActions.setValue(inputLastName, lastName);
			webActions.setValue(inputDOB, jsonDataParser.getTestDataMap().get("Date of Birth"));
			webActions.setValue(inputHomePhone, homePhone);
			webActions.setValue(inputAddress1, jsonDataParser.getTestDataMap().get("Address1"));
			webActions.setValue(inputAddress2, jsonDataParser.getTestDataMap().get("Address2"));
			webActions.setValue(inputCity, jsonDataParser.getTestDataMap().get("City"));
			webActions.selectDropDownByText(inputStates, jsonDataParser.getTestDataMap().get("State Full Name"));
			webActions.setValue(inputZipCode, jsonDataParser.getTestDataMap().get("Zipcode"));
			if (webActions.getAttributeValue(inputSSN, "value").equals(ssn)) {
				LogUtility.logInfo("enterPersonalInformationDetails",
						"Entered all personal details successfully" + jsonDataParser.getTestDataMap());
			}

		} catch (Exception e) {
			LogUtility.logException("enterPersonalInformationDetails", "Exception in entering personal details", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Enters all the personal information
	 * 
	 * @throws Exception
	 */
	public void enterPersonalInformationDetailsForErrors(Map<String, String> testDaMap) throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(inputSSN, maxTimeOut);
			webActions.setValue(inputSSN, jsonDataParser.getTestDataMap().get("Social Security Number"));
			webActions.setValue(inputFirstName, jsonDataParser.getTestDataMap().get("First Name"));
			webActions.setValue(inputMiddleName, jsonDataParser.getTestDataMap().get("Middle Name"));
			webActions.setValue(inputLastName, jsonDataParser.getTestDataMap().get("Last Name"));
			webActions.setValue(inputDOB, jsonDataParser.getTestDataMap().get("Date of Birth"));
			webActions.setValue(inputHomePhone, jsonDataParser.getTestDataMap().get("Best Phone Number"));
			webActions.setValue(inputAddress1, jsonDataParser.getTestDataMap().get("Address1"));
			webActions.setValue(inputAddress2, jsonDataParser.getTestDataMap().get("Address2"));
			webActions.setValue(inputCity, jsonDataParser.getTestDataMap().get("City"));
			webActions.setValue(inputCustEmail, jsonDataParser.getTestDataMap().get("Email"));
			webActions.selectDropDownByText(inputStates, jsonDataParser.getTestDataMap().get("State Full Name"));
			webActions.setValue(inputZipCode, jsonDataParser.getTestDataMap().get("Zipcode"));
			if (webActions.getAttributeValue(inputSSN, "value").equals(jsonDataParser.getTestDataMap().get(""))) {
				LogUtility.logInfo("enterPersonalInformationDetailsForErrors",
						"Entered all personal details successfully" + jsonDataParser.getTestDataMap());
			}

		} catch (Exception e) {
			LogUtility.logException("enterPersonalInformationDetails", "Exception in entering personal details", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Enter SSn and DOB
	 * 
	 * @throws Exception
	 */
	public void enterSsnAndDob() throws Exception {
		try {
			waits.waitUntilElementIsPresent(inputSSN, maxTimeOut);
			webActions.setValue(inputSSN, jsonDataParser.getTestDataMap().get("Social Security Number"));
			webActions.setValue(inputDOB, jsonDataParser.getTestDataMap().get("Date of Birth"));
			LogUtility.logInfo("enterSsnAndDob", "Entered SSN and DOB successfully" + jsonDataParser.getTestDataMap());
		} catch (Exception e) {
			LogUtility.logException("enterSsnAndDob", "Exception in entering personal details", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * Enters all the driving license information
	 * 
	 * @throws Exception
	 */
	public void enterDLInformationDetails(Map<String, String> testDaMap) throws Exception {
		try {
			String dlNumber = "";
			if (jsonDataParser.getTestDataMap().get("State Full Name").equals("Rhode Island"))
				dlNumber = wolWebUtil.getRandomNumber(7);
			else
				dlNumber = wolWebUtil.getRandomNumber(9);
			if (jsonDataParser.getTestDataMap().get("Driver's License Number").equals("ReplaceMe"))
				jsonDataParser.getTestDataMap().put("Driver's License Number", jsonDataParser.getTestDataMap()
						.get("Driver's License Number").replaceAll("ReplaceMe", dlNumber));
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(selDLState, maxTimeOut);
			webActions.selectDropDownByText(selDLState, jsonDataParser.getTestDataMap().get("State Full Name"));
			if (jsonDataParser.getTestDataMap().get("Driver's License Number").equals("ReplaceMe"))
				webActions.setValue(inputDLNumber, dlNumber);
			else
				webActions.setValue(inputDLNumber, jsonDataParser.getTestDataMap().get("Driver's License Number"));
			webActions.setValue(inputDLIssueDate, jsonDataParser.getTestDataMap().get("Driver's License Issue Date"));
			webActions.setValue(inputDLExpireDate,
					jsonDataParser.getTestDataMap().get("Driver's License Expiration Date"));
			LogUtility.logInfo("enterDLInformationDetails", "Entered all DL details" + jsonDataParser.getTestDataMap());

		} catch (Exception e) {
			LogUtility.logException("enterDLInformationDetails", "Exception in entering driving license details", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Enters all the driving license information
	 * 
	 * @throws Exception
	 */
	public void enterInvalidDLInformationDetails(String number, String state) throws Exception {
		try {

			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(selDLState, maxTimeOut);
			webActions.selectDropDownByText(selDLState, jsonDataParser.getTestDataMap().get(state));
			webActions.setValue(inputDLNumber, jsonDataParser.getTestDataMap().get(number));
			webActions.setValue(inputDLIssueDate, jsonDataParser.getTestDataMap().get("Driver's License Issue Date"));
			webActions.setValue(inputDLExpireDate,
					jsonDataParser.getTestDataMap().get("Driver's License Expiration Date"));
			LogUtility.logInfo("enterDLInformationDetails", "Entered all DL details" + jsonDataParser.getTestDataMap());

		} catch (Exception e) {
			LogUtility.logException("enterDLInformationDetails", "Exception in entering driving license details", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * checks the page title of each page in NAO flow
	 * 
	 * @param pageTitle
	 * @return
	 */
	public boolean checkThePageTitle(String pageTitle) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (pageTitle) {
			case "Identification Information":
				eleToGetText = txtIndentInfoTitle;
				break;
			case "Personal Information":
				eleToGetText = txtPersonalInfoTitle;
				break;
			case "Driver's License Information":
				eleToGetText = txtLicensePageTitle;
				break;
			case "Employment Information":
				eleToGetText = txtEmploymentInfoTitle;
				break;
			case "Employment Informations":
				eleToGetText = txtEmploymentInfoTitle;
				break;
			case "Review the account you selected":
				eleToGetText = txtReviewAccountTitle;
				break;
			case "International Wire Services":
				eleToGetText = txtInternationalWireTitle;
				break;
			case "Debit Card Overdraft Services":
				eleToGetText = txtOverDraftTitle;
				break;
			case "Account Information":
				eleToGetText = txtAccInfoTitle;
				break;
			case "Verify Personal Information":
				eleToGetText = txtVerifyInfoPage;
				break;
			case "I have read these Disclosures and I Agree":
				eleToGetText = txtDisclosurePageTitle;
				break;
			case "Review Personal Information":
				eleToGetText = txtRevPersonalInfoPageTitle;
				break;
			case "Choose my Debit Card":
				eleToGetText = txtChooseDBCard;
				break;
			case "Opportunity Checking Account Information":
				eleToGetText = txtOCAccInfoTitle;
				break;
			case "Are you a Non Resident or Resident alien?":
				eleToGetText = txtResidentTitle;
				break;
			case "Account Options":
				eleToGetText = txtAccOptionsTitle;
				break;

			default:
				LogUtility.logInfo("checkThePageTitle", "Invalid page title " + pageTitle);
			}
			for (int i = 0; i < 4; i++) {
				if (waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut))
					break;
			}
			waits.waitForPageToLoad(maxTimeOut);
			if (wolWebUtil.verifyText(eleToGetText, pageTitle)) {
				status = true;
				LogUtility.logInfo("checkThePageTitle", " Page Title is same as expected " + pageTitle);
			} else
				LogUtility.logError("checkThePageTitle", "could not find the page title" + pageTitle);
			waits.staticWait(5);
		} catch (Exception e) {
			LogUtility.logException("checkThePageTitle", " Page Title is not same as expected " + pageTitle, e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * returns true if the data entered in all the pages is same as the data
	 * displayed in verification page enteredDetails- map formed at every step by
	 * adding the values entered in the pages uiDetails - map formed by the data
	 * retrieved from the html page
	 * 
	 * @return
	 */
	public boolean verifyDataKeyedInWithDataDisplayedInDOM() {
		boolean status = false;
		LinkedHashMap<String, String> uiDetails = new LinkedHashMap<>();
		LinkedHashMap<String, String> enteredData = new LinkedHashMap<>(jsonDataParser.getTestDataMap());

		try {
			for (int i = 0; i < lstVerifyLabels.size(); i++) {
				try {
					uiDetails.put(webActions.getText(lstVerifyLabels.get(i)),
							webActions.getText(lstVerifyValues.get(i)));
				} catch (Exception e) {
					continue;
				}
			}
			if (wolWebUtil.mapValuesComaparison(uiDetails, enteredData)) {
				status = true;
				LogUtility.logInfo("verifyDataKeyedInWithDatadisplayedinDOM", "Data displayed is same as data entered");
			} else
				LogUtility.logError("verifyDataKeyedInWithDatadisplayedinDOM",
						"Data displayed is not same as data entered");
		} catch (Exception e) {
			LogUtility.logException("verifyDataKeyedInWithDatadisplayedinDOM", "Failed to compare the data", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * selects the citizen ship exposed person
	 * 
	 * @param ques1
	 * @param ques2
	 * @throws Exception
	 */
	public void selectCitizenship(String citizenship) throws Exception {

		waits.waitForPageToLoad(maxTimeOut);
		waits.waitUntilElementIsPresent(selCitizenShip, maxTimeOut);
		try {
			webActions.selectDropDownByText(selCitizenShip, citizenship);
			LogUtility.logInfo("selectCitizenship", "Selected all the citizenship");

		} catch (Exception e) {
			LogUtility.logException("selectCitizenship", "Exception in selecting citizenship", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * selects the answers to the questions to determine if the user is a political
	 * exposed person
	 * 
	 * @param ques1
	 * @param ques2
	 * @throws Exception
	 */
	public void selectIdentificationInfo(String ques1, String ques2) throws Exception {

		waits.waitForPageToLoad(maxTimeOut);
		try {

			if (ques1.equalsIgnoreCase("yes")) {
				webActions.clickElement(btnPep1YesOption);
			} else {
				webActions.clickElement(btnPep1NoOption);
			}

			if (ques2.equalsIgnoreCase("yes")) {
				webActions.clickElement(btnPep2YesOption);
			} else {
				webActions.clickElement(btnPep2NoOption);
			}
			LogUtility.logInfo("selectIdentificationInfo", "Selected all the questions according to the inputs given");

		} catch (Exception e) {
			LogUtility.logException("selectIdentificationInfo", "Exception in selecting identification info", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * checks the tool tip text for the cashin and cashout questions
	 * 
	 * @throws Exception
	 */
	public boolean checkTheToolTipForAnyLabel(String labelType, String message) throws Exception {
		boolean status = false;
		WebElement element = null;
		try {
			switch (labelType) {
			case "CashIn Question":
				element = btnCashInToolTip;
				break;
			case "CashOut Question":
				element = btnCashOutToolTip;
				break;
			case "License Number":
				element = btnLicenseNumToolTip;
				break;
			case "Social Security Number":
				element = btnSSNToolTip;
				break;
			case "Statement eDelivery":
				element = btnStatementEDelivery;
				break;
			case "PEPQuestion1":
				element = toolTipPEPQues1;
				break;
			case "PEPQuestion2":
				element = toolTipPEPQues2;
				break;
			case "Citizenship":
				element = txtCitizenShipLabel;
				break;
			default:
				LogUtility.logInfo("checkTheToolTipForAnyLabel", "invalid labeltype for tootltip " + labelType);
			}
			waits.waitUntilElementIsPresent(element, maxTimeOut);
			status = wolWebUtil.checkTheTooltipMessage(element, message);
			if (status)
				LogUtility.logInfo("checkTheToolTipForAnyLabel", "Tool tip message is correct" + element.getText());
			else
				LogUtility.logError("checkTheToolTipForAnyLabel",
						"Tool tip message is not correct " + element.getText());
		} catch (Exception e) {
			LogUtility.logException("checkTheToolTipForAnyLabel", "Exception in cheking tool tip", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Enters the employment details based on the employment status of the user
	 * 
	 * @throws Exception
	 */
	public void enterEmploymentDetails() throws Exception {
		try {
			waits.waitUntilElementIsPresent(inputEmpName, maxTimeOut);
			webActions.setValue(inputEmpName, jsonDataParser.getTestDataMap().get("Employer Name"));
			webActions.setValue(inputJobTitle, jsonDataParser.getTestDataMap().get("Job Title"));
			LogUtility.logInfo("enterEmploymentDetails", "Entered the employment details");
		} catch (Exception e) {
			LogUtility.logException("enterEmploymentDetails", "Exception in entering employment info", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Selects the employment status of the user
	 * 
	 * @throws Exception
	 */
	public void selectEmpStatusInfo(String empStatus) throws Exception {
		try {
			waits.waitUntilElementIsPresent(selEmpStatus, maxTimeOut);
			webActions.selectDropDownByText(selEmpStatus, empStatus);
			LogUtility.logInfo("selectEmpStatusInfo", "Selected employment info as " + empStatus);
		} catch (Exception e) {
			LogUtility.logException("selectEmpStatusInfo", "Exception in selecting employment info", e,
					LoggingLevel.ERROR, true);
			throw e;

		}
	}

	/**
	 * check if the account name in review page is same as the param given and
	 * clicks on continue button
	 * 
	 * @param accountname
	 * @return
	 */
	public boolean checkAccountNameInReviewPage(String accountName) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtAccountNameInReview, maxTimeOut);
			LogUtility.logInfo("checkAccountnameInReviewPage",
					"Account displayed as " + txtAccountNameInReview.getText());
			for (String accName : accountName.split(",")) {
				if (wolWebUtil.verifyTextContains(txtAccountNameInReview, accName)) {
					status = true;
					LogUtility.logInfo("checkAccountnameInReviewPage", "Account Name is " + accountName);
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkAccountnameInReviewPage", "Failed to find the account name in review page ",
					e, LoggingLevel.ERROR, true);
		}
		return status;

	}

	/**
	 * To select the answers to the questions related to cashin and cashout flow
	 * 
	 * @param cashIn
	 * @param cashOut
	 * @param wiredService
	 * @throws Exception
	 */
	public boolean selectCashFlowAndWiredServices(String cashIn, String cashOut) throws Exception {
		boolean status = false;
		try {
			for (int i = 0; i < lstCashOutOptionsTxt.size(); i++) {
				if (lstCashInOptionsTxt.get(i).getText().equals(cashIn)) {
					lstCashInOptionsTxt.get(i).click();
					LogUtility.logInfo("selectCashFlowAndWiredServices", "Selected cashIn as " + cashIn);
					break;
				}
			}
			for (int i = 0; i < lstCashOutOptionsTxt.size(); i++) {
				if (lstCashOutOptionsTxt.get(i).getText().equals(cashOut)) {
					lstCashOutOptionsTxt.get(i).click();
					LogUtility.logInfo("selectCashFlowAndWiredServices", "Selected cashOut as " + cashOut);
					break;
				}
			}
			LogUtility.logInfo("selectCashFlowAndWiredServices",
					"Selected cashIn as " + cashIn + " and cash out as " + cashOut);
		} catch (Exception e) {
			LogUtility.logException("selectCashFlowAndWiredServices", "Exception in selecting Accounting info", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		return status;
	}

	/**
	 * selects the type of international wire service
	 * 
	 * @param wiredService
	 * @return
	 */
	public boolean selectInternatonalWiredServies(String wiredService) {
		boolean status = false;
		waits.waitUntilElementIsPresent(btnWireServiceY, maxTimeOut);
		try {
			if (wiredService.equalsIgnoreCase("yes")) {
				webActions.clickElement(btnWireServiceY);
				status = true;
			} else {
				webActions.clickElement(btnWireServiceN);
				status = true;
			}
			if (status)
				LogUtility.logInfo("selectInternatonalWiredServies", "Selected the wired service as " + wiredService);
			else
				LogUtility.logError("selectInternatonalWiredServies", "Failed to select wired service");
		} catch (Exception e) {
			LogUtility.logException("selectInternatonalWiredServies", "exception in selecting  wired service : ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Selects the range of amount to international wire service
	 * 
	 * @throws Exception
	 */
	public void selectInternationalWiredServicesForYes() throws Exception {
		try {
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(btnDomestic, maxTimeOut);
			for (WebElement transactionType : lstTransactionType) {
				if (jsonDataParser.getTestDataMap().containsKey(transactionType.getText())) {
					if (jsonDataParser.getTestDataMap().get(transactionType.getText()).equals("Y"))
						webActions.clickElement(transactionType);
				}
			}
			for (WebElement wireIntend : lstIntendToWire) {
				if (jsonDataParser.getTestDataMap().get("Average Monthly Wire Amount").contains(wireIntend.getText())) {
					webActions.clickElement(wireIntend);
					break;
				}
			}
			LogUtility.logInfo("selectInternationalWiredServicesForYes",
					"Selected the options " + jsonDataParser.getTestDataMap().get("Average Monthly Wire Amount"));
		} catch (Exception e) {
			LogUtility.logException("selectInternationalWiredServicesForYes",
					"Exception in selecting international wired services info", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Selects yes/no for the overdraft and statement edelivery services
	 * 
	 * @param overdraft
	 * @param edelivery
	 * @throws Exception
	 */
	public void selectOverdraftAndeDeliveryServices(String overdraft, String edelivery) throws Exception {
		try {
			if (overdraft.equalsIgnoreCase("yes") && !webActions.isChecked(btnOverdraftYes)) {
				webActions.clickElement(btnOverdraftYes);
				LogUtility.logInfo("selectOverdraftAndeDeliveryServices", "Checked the the Overdraft option");
			} else {
				webActions.clickElement(btnOverdraftNo);
				LogUtility.logInfo("selectOverdraftAndeDeliveryServices", "UnChecked the the Overdraft option");
			}
			if (edelivery.equalsIgnoreCase("yes") && !webActions.isChecked(btnEstatementEnroll)) {
				webActions.clickElement(btnEstatementEnroll);
				LogUtility.logInfo("selectOverdraftAndeDeliveryServices", "Opted for the estatement enroll ");
			} else {
				webActions.clickElement(btnEstatementEnroll);
				LogUtility.logInfo("selectOverdraftAndeDeliveryServices", "Unchecked the estatement enroll option");
			}
		} catch (Exception e) {
			LogUtility.logException("selectOverdraftAndeDeliveryServices", "Exception in selecting Overdraft info", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Clicks on continue button in every page in NAO functionality
	 * 
	 * @throws Exception
	 */
	public boolean clickOnContinue() throws Exception {
		boolean status = false;
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(btnContinue, maxTimeOut)) {
				webActions.clickElement(btnContinue);
				waits.staticWait(5);
				LogUtility.logInfo("clickOnContinue", "Clicked on continue button");
				status = true;

			} else
				LogUtility.logError("clickOnContinue", "Failed to click on continue button");
		} catch (Exception e) {
			LogUtility.logException("clickOnContinue", "Exception while clicking continue ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * Selects the answers to emulation questions
	 * 
	 * @param question1
	 * @param question2
	 * @throws Exception
	 */
	public void selectEmulationQuestions(String question1, String question2) throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			for (WebElement ques1 : lstEmulation1RadioBtns) {
				String value = webActions.getAttributeValue(ques1, "value");
				if (value.equalsIgnoreCase(question1)) {
					webActions.clickElement(ques1);
					LogUtility.logInfo("selectEmulationQuestions",
							"Selected option " + question1 + " to emaulation question1");
					break;
				}
			}
			for (WebElement ques2 : lstEmulation2RadioBtns) {
				if (webActions.getAttributeValue(ques2, "value").equalsIgnoreCase(question2)) {
					webActions.clickElement(ques2);
					LogUtility.logInfo("selectEmulationQuestions",
							"Selected option " + question2 + "to emaulation question2");
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("selectEmulationQuestions", "Exception while selecting emulation questions ", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * checks for the debit card section
	 * 
	 * @return
	 */
	public boolean checkForCardBlock() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(debitCardBlock, maxTimeOut)) {
				status = true;
				LogUtility.logInfo("checkForCardBlock", "Debit card section is present");
			} else
				LogUtility.logError("checkForCardBlock", "Debit card section is not present");
		} catch (Exception e) {
			LogUtility.logException("checkForCardBlock", "Failed to find Debit card section", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean selectTheDebitCardType(String dbCardType) {
		boolean status = false;
		try {
			if (dbCardType.equalsIgnoreCase("Yes")) {
				if (!webActions.isChecked(rdBtnDebitCard)) {
					webActions.clickElement(rdBtnDebitCard);
					status = true;
					LogUtility.logInfo("selectTheDebitCardType", "Selected yes for the debit card");
				} else if (webActions.isChecked(rdBtnDebitCard)) {
					status = true;
					LogUtility.logInfo("selectTheDebitCardType", "Selected yes for the debit card");
				}
			} else {
				webActions.clickElement(rdBtnNoCard);
				status = true;
				LogUtility.logInfo("selectTheDebitCardType", "Selected no for the debit card");
			}
		} catch (Exception e) {
			LogUtility.logException("selectTheDebitCardType", "Failed to select debit card selection", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Selects all the disclosures in the page
	 * 
	 * @param question1
	 * @param question2
	 * @throws Exception
	 */
	public void selectAllDisclosures() throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			for (WebElement disclosure : lstDisclosuresCheckBox) {
				wolWebUtil.scrollToElement(disclosure);
				webActions.clickElement(disclosure);
			}
			LogUtility.logInfo("selectAllDisclosures", "Selected all the disclosures options");
		} catch (Exception e) {
			LogUtility.logException("selectAllDisclosures", "Failed to select disclosure", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Enters the username and password
	 * 
	 * @param question1
	 * @param question2
	 * @throws Exception
	 */
	public void enterUserNameDetails(Map<String, String> testDaMap) throws Exception {
		try {
			waits.waitUntilElementIsPresent(inputUserName, maxTimeOut);
			if (testDaMap.containsKey("User Name"))
				webActions.setValue(inputUserName, testDaMap.get("User Name"));
			else
				webActions.setValue(inputUserName, wolWebUtil.getRandomString(9));
			if (testDaMap.containsKey("Password"))
				webActions.setValue(inputPassword, testDaMap.get("Password"));
			else
				webActions.setValue(inputPassword, "password");
			if (testDaMap.containsKey("Confirm Password"))
				webActions.setValue(inputConfirmPassword, testDaMap.get("Confirm Password"));
			else
				webActions.setValue(inputConfirmPassword, "password");
			LogUtility.logInfo("enterUserNameDetails", "Entered the new username and password");
		} catch (Exception e) {
			LogUtility.logException("enterUserNameDetails", "Failed to enter new username and password", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * validates the confirmation message for the order
	 * 
	 * @param question1
	 * @param question2
	 * @throws Exception
	 */
	public boolean validateConfirmationMessage() {
		boolean status = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtConfirmation, maxTimeOut);
			if (txtConfirmation.getText()
					.equals(jsonDataParser.getTestDataMap().get("Confirmation Message").replace("ReplaceMe",
							jsonDataParser.getTestDataMap().get("Account Requested")))
					|| txtConfirmation.getText().equals(jsonDataParser.getTestDataMap().get("Confirmation Message")
							.replace("ReplaceMe", jsonDataParser.getTestDataMap().get("Account Type")))) {
				status = true;
				LogUtility.logInfo("validateConfirmationMessage", "Congratulations message is found");
			} else
				LogUtility.logError("validateConfirmationMessage", "Congratulations message is not found");
		} catch (Exception e) {
			LogUtility.logException("validateConfirmationMessage", "Failed to find Congratulations message", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * validates the confirmation message for the order
	 * 
	 * @param question1
	 * @param question2
	 * @throws Exception
	 */
	public boolean validateConfirmationMessageForCD() {
		boolean status = false;
		try {

			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtConfirmationCD, maxTimeOut);
			if (txtConfirmationCD.getText().equals(jsonDataParser.getTestDataMap().get("Confirmation Message")
					.replace("ReplaceMe", jsonDataParser.getTestDataMap().get("Account Requested")))) {
				status = true;
				LogUtility.logInfo("validateConfirmationMessageForCD",
						"Congratulations message is found for CD account");
			} else
				LogUtility.logError("validateConfirmationMessageForCD",
						"Congratulations message is not found for CD account");
		} catch (Exception e) {
			LogUtility.logException("validateConfirmationMessageForCD",
					"Failed to find Congratulations message for CD account", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * return the confirmation details after successfully placing the order
	 * 
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> getSystemGeneratedConfirmationDetails() throws Exception {
		waits.waitUntilElementIsPresent(lstConfirmValues.get(0), maxTimeOut);
		try {
			for (int i = 0; i < lstConfirmLabels.size(); i++) {
				confirmationDetails.put(lstConfirmLabels.get(i).getText(), lstConfirmValues.get(i).getText());
				LogUtility.logInfo("getSystemGeneratedConfirmationDetails",
						lstConfirmLabels.get(i).getText() + "***" + lstConfirmValues.get(i).getText());
			}

		} catch (Exception e) {
			LogUtility.logException("getSystemGeneratedConfirmationDetails",
					"Exception while selecting fetching data from confirmation page", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return confirmationDetails;
	}

	/**
	 * To click on existing customer link
	 * 
	 * @return
	 */
	public boolean clickExistingCustomer() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(linkExistingCustomer, maxTimeOut);
			webActions.clickElement(linkExistingCustomer);
			if (waits.waitUntilElementIsPresent(txtUserName, maxTimeOut)) {
				flag = true;
				LogUtility.logInfo("clickExistingCustomer", "Clicked on Existing customer? Link");
			} else
				LogUtility.logError("clickExistingCustomer", "Failed to click on existing customer link");
		} catch (Exception e) {
			LogUtility.logException("clickExistingCustomer", "Failed to click on existing customer link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Checks the error messages for PEP questions
	 * 
	 * @return
	 */
	public String checkForThePEPErrorMessages() {
		String status = "";
		try {
			if (wolWebUtil.verifyText(txtPepQes1ErrorMsg, jsonDataParser.getTestDataMap().get("PEP Error Message"))) {
				status = "true1";
				LogUtility.logInfo("checkForThePEPErrorMessages", "Found the message for question 1");
			} else
				LogUtility.logError("--->checkForThePEPErrorMessages<---",
						"Failed to find the error message for question 1 ");
			if (wolWebUtil.verifyText(txtPepQes2ErrorMsg, jsonDataParser.getTestDataMap().get("PEP Error Message"))) {
				status = status + "," + "true2";
				LogUtility.logInfo("checkForThePEPErrorMessages", "Found the message for question 2");
			} else
				LogUtility.logError("--->checkForThePEPErrorMessages<---",
						"Failed to find the error message for question 2 ");
		} catch (Exception e) {
			LogUtility.logException("checkForThePEPErrorMessages", "Failed to find the error message for PEP question ",
					e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Checks the error messages for cash questions
	 * 
	 * @return
	 */
	public String checkForTheCashErrorMessages() {
		String status = "";
		try {
			if (wolWebUtil.verifyText(txtCashInErrorMsg, jsonDataParser.getTestDataMap().get("Cash Error Message"))) {
				status = "true1";
				LogUtility.logInfo("checkForTheCashErrorMessages", "Found the error message for cash in question ");
			} else
				LogUtility.logError("--->checkForTheCashErrorMessages<---",
						"Failed to find the error message for question 1 ");
			if (wolWebUtil.verifyText(txtCashOutErrorMsg, jsonDataParser.getTestDataMap().get("Cash Error Message"))) {
				status = status + "," + "true2";
				LogUtility.logInfo("checkForTheCashErrorMessages", "Found the message for cash out question ");
			} else
				LogUtility.logError("--->checkForTheCashErrorMessages<---",
						"Failed to find the error message for question 2 ");
		} catch (Exception e) {
			LogUtility.logException("checkForTheCashErrorMessages",
					"Failed to find the error message for cash question ", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Checks the three bullet points available or not
	 * 
	 * @return
	 */
	public String checkForTheBulletPoints() {
		String status = "";
		try {
			for (WebElement bulletPoint : lstBulletPoints) {
				if (jsonDataParser.getTestDataMap().get("List of Bullet Points")
						.contains(webActions.getText(bulletPoint))) {
					status = status + webActions.getText(bulletPoint) + ",";
				}
			}
			LogUtility.logInfo("checkForTheBulletPoints", "Bullet points  present in the page are " + status);
		} catch (Exception e) {
			LogUtility.logException("checkForTheBulletPoints", "Failed to get bullet points ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * Gets all the personal details from UI and replaces them in
	 * jsonDataParser.getTestDataMap()
	 * 
	 * @throws Exception
	 */
	public void getAllThePersonalDetails() throws Exception {
		int i = 0;
		try {
			for (WebElement eachLabel : lstPersonalInfoLabels) {
				jsonDataParser.getTestDataMap().put(webActions.getText(eachLabel),
						lstPersonalInfoData.get(i).getText());
				i++;
			}
			LogUtility.logInfo("getAllThePersonalDetails",
					"personal details for existing customer are " + jsonDataParser.getTestDataMap());
		} catch (Exception e) {
			LogUtility.logException("getAllThePersonalDetails", "Failed to get personal details for existing customer ",
					e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * checks for different confirmation messages
	 * 
	 * @param type
	 * @return
	 */
	public boolean checkForNegativeConfirmationText(String type) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (type) {
			case "InvalidEmulatorQuestions":
				eleToGetText = txtNegOpenAcc;
				break;
			case "ExistingCustomerNewCDD":
				eleToGetText = txtUnableToOpenAcc;
				break;
			case "NonUSNonResident":
				eleToGetText = txtNonResNonUSNotice;
				break;
			case "":
				eleToGetText = txtOCFailedMsg;
				break;
			}
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (wolWebUtil.verifyText(eleToGetText,
					jsonDataParser.getTestDataMap().get("Negative Confirmation Text"))) {
				status = true;
				LogUtility.logInfo("checkForNegativeConfirmationText", "Found the message " + eleToGetText.getText());
			} else
				LogUtility.logError("checkForNegativeConfirmationText",
						"Could not find the message " + eleToGetText.getText());
		} catch (Exception e) {
			LogUtility.logException("checkForNegativeConfirmationText", "Failed to find the confirmation text", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks for the already enrolled notice
	 * 
	 * @return
	 */
	public boolean checkForAlreadyEnrolledNotice() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtAlreadyEnrolledNotice, maxTimeOut);
			if (wolWebUtil.verifyText(txtAlreadyEnrolledNotice,
					jsonDataParser.getTestDataMap().get("Already Enrolled Text"))) {
				status = true;
				LogUtility.logInfo("checkForAlreadyEnrolledNotice",
						"Found the message " + txtAlreadyEnrolledNotice.getText());
			} else
				LogUtility.logError("checkForAlreadyEnrolledNotice",
						"Could not find the message " + txtAlreadyEnrolledNotice.getText());
		} catch (Exception e) {
			LogUtility.logException("checkForAlreadyEnrolledNotice", "Failed to find the already enrolled notice text",
					e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * clicks on sign in link
	 * 
	 * @return
	 */
	public boolean clickOnSignInLink() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			if (waits.waitUntilElementIsPresent(linkSignIn, maxTimeOut)) {
				webActions.clickElement(linkSignIn);
				status = true;
				LogUtility.logInfo("clickOnSignInLink", "Found and clicked on the link sign In ");
			} else
				LogUtility.logError("clickOnSignInLink", "Could not find the link sign in ");
		} catch (Exception e) {
			LogUtility.logException("clickOnSignInLink", "Failed to find the link sign in", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * clicks on the resident type
	 * 
	 * @return
	 */
	public boolean clickOnResidentAlienType() {
		boolean status = false;
		WebElement eleToClick = null;
		if (jsonDataParser.getTestDataMap().get("Resident Status").equals("Non Resident Alien"))
			eleToClick = rdBtnNonResAlien;
		else
			eleToClick = rdBtnResAlien;
		try {
			if (waits.waitUntilElementIsPresent(eleToClick, maxTimeOut)) {
				webActions.clickElement(eleToClick);
				status = true;
				LogUtility.logInfo("clickOnResidentAlienType", "Found and clicked on Alien Type ");
			} else
				LogUtility.logError("clickOnResidentAlienType", "Could not find Alien Type ");
		} catch (Exception e) {
			LogUtility.logException("clickOnResidentAlienType", "Failed to find Alien Type", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * checks for the overdraft text
	 * 
	 * @return
	 */

	/**
	 * checks for the overdraft text
	 * 
	 * @return
	 */
	public boolean closeOverDraftDisclosure() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnDisclosureClose, maxTimeOut)) {
				webActions.clickElement(btnOverDraftClose);
				waits.staticWait(3);// Continue will be in unclickable state until this wait is over
				status = true;
			} else
				LogUtility.logError("closeOverdraftDisclosure", "Clicked on the close button");
		} catch (Exception e) {
			LogUtility.logException("closeOverdraftDisclosure", "Failed to click on the close button", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * clicks on debit card service link
	 * 
	 * @return
	 */
	public boolean clickOnOverDraftLink() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(linkOverDraft, maxTimeOut)) {
				wolWebUtil.clickWebElement(linkOverDraft, "clickOnOverDraftLink");
				status = true;
				LogUtility.logInfo("clickOnDebitCardServiceLink", "Clicked on the  debitcard service link");
			} else
				LogUtility.logError("clickOnDebitCardServiceLink", "Could not find debitcard service link");
		} catch (Exception e) {
			LogUtility.logException("clickOnDebitCardServiceLink", "Failed to find debitcard service link", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks for the successfully applied message
	 * 
	 * @return
	 */
	public boolean checkForSuccessfulAppliedMessage() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(txtSuccessfullyApplied, maxTimeOut)) {
				if (wolWebUtil.verifyText(txtSuccessfullyApplied,
						jsonDataParser.getTestDataMap().get("Successfully Applied For Account")))
					status = true;
				LogUtility.logInfo("checkForSuccessfulAppliedMessage",
						"Found the text :" + jsonDataParser.getTestDataMap().get("Successfully Applied For Account"));
			} else
				LogUtility.logError("checkForSuccessfulAppliedMessage", "Could not find the text "
						+ jsonDataParser.getTestDataMap().get("Successfully Applied For Account"));
		} catch (Exception e) {
			LogUtility.logException("checkForSuccessfulAppliedMessage",
					"Failed to find the text "
							+ jsonDataParser.getTestDataMap().get("Successfully Applied For Account"),
					e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks for the successfully applied message
	 * 
	 * @return
	 */
	public boolean verifyTheDisclosureContent() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtDisclosureContent, maxTimeOut)) {
				for (String eachText : jsonDataParser.getTestDataMap().get("Disclosure Content").split(",")) {
					if (wolWebUtil.verifyTextContains(txtDisclosureContent, eachText)) {
						status = true;
						LogUtility.logInfo("verifyTheDisclosureContent", "Found the text :" + eachText);
					}
				}
			} else
				LogUtility.logError("verifyTheDisclosureContent", "Could not find the disclosure content ");
		} catch (Exception e) {
			LogUtility.logException("verifyTheDisclosureContent", "Failed to find the disclosure content ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public String checkForTheEditButtons(String buttons, boolean clickOrNot) {
		String status = "";
		WebElement elementToCheck = null;
		try {
			waits.waitForDOMready();
			for (String eachButton : buttons.split(",")) {
				switch (eachButton) {
				case "Bottom Edit Personal Information":
					elementToCheck = btnToEditBottomPersonal;
					break;
				case "Top Edit Personal Information":
					elementToCheck = btnToEditTopPersonal;
					break;
				case "Bottom Edit Account Information":
					elementToCheck = btnToEditBotAccountInfo;
					break;
				case "Top Edit Account Information":
					elementToCheck = btnToEditTopAccountInfo;
					break;
				}
				if (webActions.isDisplayed(elementToCheck)) {
					status = status + eachButton + ",";
					LogUtility.logInfo("checkForTheEditButtons", "Found the button :" + eachButton);
					if (clickOrNot) {
						webActions.clickElement(elementToCheck);
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkForTheEditButtons", "Failed to find the edit buttons ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To click on the CD account type
	 * 
	 * @return
	 */
	public boolean clickOnCDAccType() {
		boolean status = false;
		try {
			for (WebElement eachCDAcc : lstCDAccTypes) {
				if (webActions.getText(eachCDAcc).equals(jsonDataParser.getTestDataMap().get("Account Requested"))) {
					webActions.clickElement(eachCDAcc);
					status = true;
					LogUtility.logInfo("clickOnCDAccType",
							"Clicked on the account " + jsonDataParser.getTestDataMap().get("CD Account Type"));
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCDAccType", "Failed to click on CD account in review page", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To click on the CD account type
	 * 
	 * @return
	 */
	public boolean checkForTheTextHusky() {
		boolean status = false;
		try {
			if (wolWebUtil.elementNotDisplay(txtHuskyCard)) {
				status = true;
				LogUtility.logInfo("checkForTheTextHusky", "Element with husky text is not found");
			}
		} catch (Exception e) {
			LogUtility.logException("checkForTheTextHusky", "Found the element with text husky", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean checkThePrepopulatedData() {
		boolean status = false;
		try {
			waits.waitUntilElementExistence(inputSSN);
			if (webActions.getAttributeValue(inputSSN, "value")
					.equals(jsonDataParser.getTestDataMap().get("Social Security Number"))) {
				if (webActions.getAttributeValue(inputDOB, "value")
						.equals(jsonDataParser.getTestDataMap().get("Date of Birth"))) {
					status = true;
					LogUtility.logInfo("checkThePrepopulatedData", "Data prepopulated correctly");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkThePrepopulatedData", "Data check failed", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks cash in and cash out options are preselected
	 * 
	 * @param cashIn
	 * @param cashOut
	 * @return
	 */
	public boolean checkCashOptionsArePreSelected(String cashIn, String cashOut) {
		boolean status = false;
		try {
			for (int i = 0; i < lstCashInOptionsRdBtn.size(); i++) {
				if (lstCashInOptionsTxt.get(i).getText().equals(cashIn)) {
					if (webActions.isChecked(lstCashInOptionsRdBtn.get(i))) {
						status = true;
						LogUtility.logInfo("checkThePrepopulatedData", "Cash in option is preselected");
						break;
					}
				}
			}
			for (int i = 0; i < lstCashOutOptionsRdBtn.size(); i++) {
				if (lstCashOutOptionsTxt.get(i).getText().equals(cashIn)) {
					if (webActions.isChecked(lstCashOutOptionsRdBtn.get(i))) {
						status = true;
						LogUtility.logInfo("checkThePrepopulatedData", "Cash out option is preselected");
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkCashOptionsArePreSelected", "Cash options preselection check failed ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean selectNewCashOptions(String cashIn, String cashOut) {
		boolean status = false;
		try {
			for (int i = 0; i < lstCashInOptionsTxt.size(); i++) {
				if (!lstCashInOptionsTxt.get(i).getText().equals(cashIn)) {
					webActions.clickElement(lstCashInOptionsRdBtn.get(i));
					LogUtility.logInfo("selectNewCashOptions", "New Cash In option is selected");
					jsonDataParser.getTestDataMap().put("Average Monthly Cash Deposit Amount",
							lstCashInOptionsTxt.get(i).getText());
					break;
				}
			}
			for (int i = 0; i < lstCashOutOptionsTxt.size(); i++) {
				if (!lstCashOutOptionsTxt.get(i).getText().equals(cashOut)) {
					webActions.clickElement(lstCashOutOptionsRdBtn.get(i));
					status = true;
					jsonDataParser.getTestDataMap().put("Average Monthly Cash Withdrawal Amount",
							lstCashOutOptionsTxt.get(i).getText());
					LogUtility.logInfo("selectNewCashOptions", "New Cash out option is selected");
					break;
				}

			}
		} catch (Exception e) {
			LogUtility.logException("selectNewCashOptions", "Failed to select new cash options", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean checkDefaultDebitCard(String cardType) {
		boolean status = false;
		try {
			WebElement eleToCheck = null;
			if (cardType.equals("Premier"))
				eleToCheck = rdBtnPremierDebitCard;
			else
				eleToCheck = rdBtnDebitCard;
			waits.waitUntilElementIsPresent(eleToCheck, maxTimeOut);
			if (webActions.isChecked(eleToCheck)) {
				status = true;
				LogUtility.logInfo("checkDefaultDebitCard", cardType + "Debit card is preselected");
			}
		} catch (Exception e) {
			LogUtility.logException("checkDefaultDebitCard", "Failed to debitcard preselection", e, LoggingLevel.ERROR,
					true);
		}

		return status;
	}

	public void enterExistingUsername() throws Exception {
		try {
			waits.waitUntilElementIsPresent(inputUserName, maxTimeOut);
			webActions.setValue(inputUserName, jsonDataParser.getTestDataMap().get("Existing Username"));
			webActions.setValue(inputPassword, "password");
			webActions.setValue(inputConfirmPassword, "password");
			LogUtility.logInfo("enterUserNameDetails", "Entered the new username and password");
		} catch (Exception e) {
			LogUtility.logException("enterExistingUsername", "Failed to enter existing username and password", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public boolean checkForTheErrorMessage() {
		return wolWebUtil.verifyText(txtErrorMessage, jsonDataParser.getTestDataMap().get("Error Message"),
				"checkForTheErrorMessage");
	}

	/**
	 * @return
	 */
	public boolean checkForPremierSavingsErrorMsg() {
		boolean status = false;

		try {
			if (waits.waitUntilElementIsPresent(txtPremierSavingErrorMsgExistingUser))
				status = wolWebUtil.verifyText(txtPremierSavingErrorMsgExistingUser,
						jsonDataParser.getTestDataMap().get("Premier Saving Error Message"),
						"checkForPremierSavingsErrorMsg");
			else
				status = wolWebUtil.verifyText(txtPremierSavingErrorMsg,
						jsonDataParser.getTestDataMap().get("Premier Saving Error Message"),
						"checkForPremierSavingsErrorMsg");
		} catch (Exception e) {
			LogUtility.logException("checkForPremierSavingsErrorMsg",
					"Failed to find the precondition message for premier savings account", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForReturnHomeButton(boolean clickOrNot) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnReturnHome, maxTimeOut);

			if (clickOrNot) {
				if (webActions.isDisplayed(btnReturnHome)) {
					webActions.clickElement(btnReturnHome);
					status = true;
					LogUtility.logInfo("checkForReturnHomeButton", "Clicked on the Return Home button");
				}
			} else if (webActions.isDisplayed(btnReturnHome)) {
				status = true;
				LogUtility.logInfo("checkForReturnHomeButton", "Found the Return Home button");
			}
		} catch (Exception e) {
			LogUtility.logException("checkForReturnHomeButton", "Failed to find Return To Home buton", e,
					LoggingLevel.ERROR, true);
		}

		return status;
	}

	public boolean enterOrClearPromoCode(String promoCode, boolean clearOrNot) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(inputPromoCode, maxTimeOut);
			if (webActions.isDisplayed(inputPromoCode)) {
				if (clearOrNot) {
					webActions.clearValue(inputPromoCode);
					LogUtility.logInfo("enterOrClearPromoCode", "Cleared the promo code");
				} else {
					webActions.clearValue(inputPromoCode);
					webActions.setValue(inputPromoCode, promoCode);
					LogUtility.logInfo("enterOrClearPromoCode",
							"Entered value in promocode " + jsonDataParser.getTestDataMap().get("Promo code applied"));
				}
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterOrClearPromoCode", "Failed to enterOrClear PromoCode", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean waitForPromoCodeLightBox(boolean closeOrNot) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(btnClose, maxTimeOut);
			if (webActions.isDisplayed(btnClose)) {
				if (closeOrNot) {
					webActions.clickElement(btnClose);
					LogUtility.logInfo("waitForPromoCodeLightBox", "Clicked on close button in promocode light box");
				}
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("waitForPromoCodeLightBox", "Failed to find promocode light box", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkODPRadioBtnsDisabled() {
		boolean status = false;
		try {
			for (WebElement rdBtn : rdBtnsODP) {
				status = false;
				if (webActions.isDisabled(rdBtn)) {
					status = true;
					LogUtility.logInfo("checkODPRadioBtnsDisabled",
							rdBtn.getAttribute("value") + " radiobutton is disabled");
				} else
					LogUtility.logError("checkODPRadioBtnsDisabled",
							rdBtn.getAttribute("value") + " radiobutton is not disabled");
			}
		} catch (Exception e) {
			LogUtility.logException("waitForPromoCodeLightBox", "Failed to find overdraft radio  buttons", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkOverDraftHeading() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(txtOverDraftHeading, maxTimeOut)) {
				if (txtOverDraftHeading.getText().contains(jsonDataParser.getTestDataMap().get("OverDraft Heading"))) {
					status = true;
					LogUtility.logInfo("checkOverDraftHeading", "Overdraft Heading is present");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkOverDraftHeading", "Failed to find overdraft heading", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean checkTheOverDraftServicesContent() {
		boolean status = false;
		try {
			for (WebElement rdBtnContent : lstOverDraftText) {
				status = false;
				if (jsonDataParser.getTestDataMap().get("OverDraft Content").contains(rdBtnContent.getText())) {
					status = true;
					LogUtility.logInfo("checkTheOverDraftServicesContent",
							rdBtnContent.getText() + " content is present");
				} else
					LogUtility.logError("checkTheOverDraftServicesContent",
							rdBtnContent.getText() + " content is not present");
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheOverDraftServicesContent",
					"Failed to find overdraft radio buttons content", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForProgressBarSteps() {
		boolean status = true;
		try {
			for (WebElement eachStep : lstProgressBarLabels) {
				if (!jsonDataParser.getTestDataMap().get("ProgressBar Steps").contains(eachStep.getText())) {
					status = false;
					LogUtility.logInfo("checkForProgressBarSteps",
							eachStep.getText() + " is not present in the progress bar steps");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkForProgressBarSteps", "Failed to find progress bar steps", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForPromoCodeLabel() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(txtPromoLabel, maxTimeOut)) {
				if (wolWebUtil.verifyText(txtPromoLabel, jsonDataParser.getTestDataMap().get("Promo Label"))) {
					status = true;
					LogUtility.logInfo("checkForPromoCodeLabel", "Promo code label is present in the page");
				}
			}

		} catch (Exception e) {
			LogUtility.logException("checkForPromoCodeLabel", "Failed to find promo code label", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean clickOnContinueInPromoLightBox() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnContinuePromo, maxTimeOut)) {
				wolWebUtil.clickWebElement(btnContinuePromo, "clickOnContinueInPromoLightBox");
				waits.staticWait(5);
				status = true;
				LogUtility.logInfo("clickOnContinueInPromoLightBox", "Clicked on continue in promo light box");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnContinueInPromoLightBox", "Failed to find continue in promo code label", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean validateOCAccInfoPage() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtAccNameInOCPage, maxTimeOut);
			if (txtAccNameInOCPage.getText().equals(jsonDataParser.getTestDataMap().get("Account Requested"))) {
				status = true;
				LogUtility.logInfo("validateOCAccInfoPage", "Opportunity checking label is present in the page");
			}
		} catch (Exception e) {
			LogUtility.logException("validateOCAccInfoPage", "Failed to find opportunity checking  label", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean selectAccDebitCardOptionForOC() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnOCDebitCard, maxTimeOut);
			if (jsonDataParser.getTestDataMap().get("Send Free Webster Visa Debit Card").equals("Yes")) {
				webActions.clickElement(btnOCDebitCard);
				status = true;
				LogUtility.logInfo("selectAccDebitCardOptionForOC",
						"Clicked on the debit card option in opportunity checking page");
			}
		} catch (Exception e) {
			LogUtility.logException("selectAccDebitCardOptionForOC",
					"Failed to find debit card option in opportunity checking page", e, LoggingLevel.ERROR, true);
		}

		return status;
	}

	public boolean selectAccEDeliveryOptionForOC() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnOCEDelivery, maxTimeOut);
			if (jsonDataParser.getTestDataMap().get("Sign up for eDelivery").equals("Yes")) {
				webActions.clickElement(btnOCEDelivery);
				status = true;
				LogUtility.logInfo("selectAccEDeliveryOptionForOC",
						"Clicked on the edelivery option in opportunity checking page");
			}
		} catch (Exception e) {
			LogUtility.logException("selectAccEDeliveryOptionForOC",
					"Failed to find edelivery button in opportunity checking page", e, LoggingLevel.ERROR, true);
		}

		return status;
	}

	public boolean checkPromoErrorMessage(String message) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.staticWait(3);
			waits.waitForDOMready();
			for (int i = 0; i < 2; i++) {
				if (waits.waitUntilElementIsPresent(txtPromoErrorMsg, maxTimeOut))
					break;
			}
			if (wolWebUtil.verifyText(txtPromoErrorMsg, jsonDataParser.getTestDataMap().get(message))) {
				status = true;
				LogUtility.logInfo("checkPromoErrorMessage",
						"Found the promo error message " + jsonDataParser.getTestDataMap().get(message));

			}
		} catch (Exception e) {
			LogUtility.logException("checkPromoErrorMessage", "Failed to find promo error message", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOkButtonInPromo() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnPromoOK, maxTimeOut);
			if (webActions.isDisplayed(btnPromoOK)) {
				webActions.clickElement(btnPromoOK);
				status = true;
				LogUtility.logInfo("checkPromoErrorMessage", "Clicked on the OK button in promo lightbox");

			}
		} catch (Exception e) {
			LogUtility.logException("checkPromoErrorMessage", "Failed to find ok button in promo light box", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForThePromoOfferLabels() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtAccNameLabelPromo, maxTimeOut);
			if (webActions.isDisplayed(txtAccNameLabelPromo)) {
				if (webActions.isDisplayed(txtOfferInfoLabel)) {
					status = true;
					LogUtility.logInfo("checkForThePromoOfferLabels", "Offer Info and Account Name labels are present");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkForThePromoOfferLabels", "Failed to find promo offer labels in light box", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForTheHeadersInReviewAccPage(String headersType) {
		List<WebElement> headerList = null;
		boolean status = true;
		try {
			if (headersType.equals("Conditional Headers"))
				headerList = lstConditionalHeaders;
			else
				headerList = lstAPYRatesHeaders;
			status = true;
			for (WebElement eachHeader : headerList) {
				if (!jsonDataParser.getTestDataMap().get(headersType).contains(eachHeader.getText())) {
					status = false;
				}
			}
			if (status)
				LogUtility.logInfo("checkForTheHeadersInReviewAccPage",
						"All the headers are present : " + jsonDataParser.getTestDataMap().get(headersType));
			else
				LogUtility.logError("checkForTheHeadersInReviewAccPage",
						"All the headers are not present : " + jsonDataParser.getTestDataMap().get(headersType));
		} catch (Exception e) {
			LogUtility.logException("checkForTheHeadersInReviewAccPage", "Failed to find the headers ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOnBack() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnBack, maxTimeOut);
			if (webActions.isDisplayed(btnBack)) {
				webActions.clickElement(btnBack);
				status = true;
				LogUtility.logInfo("clickOnBack", "Clicked on the back button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnBack", "Failed to find back button ", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForTermsErrorMessage(String messageType) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtDisclosureMessage, maxTimeOut);
			if (wolWebUtil.verifyText(txtDisclosureMessage, jsonDataParser.getTestDataMap().get(messageType))) {
				status = true;
				LogUtility.logInfo("checkForTermsErrorMessage",
						"Found the error message " + jsonDataParser.getTestDataMap().get(messageType));
			}
		} catch (Exception e) {
			LogUtility.logException("checkForTermsErrorMessage", "Failed to find back button ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public String checkTheDisclosureLinks() {
		String status = "";
		String linkName = "";
		try {
			for (WebElement eachLink : lstDisclosureLinks) {
				waits.staticWait(3);
				webActions.clickElement(eachLink);
				waits.waitUntilElementIsPresent(txtDisclosureHeading, maxTimeOut);
				if (!jsonDataParser.getTestDataMap().get("Disclosure Terms Labels").contains(eachLink.getText())
						&& jsonDataParser.getTestDataMap().get("Disclosure Lightbox Heading")
								.contains(txtDisclosureHeading.getText().toUpperCase())) {
					status = status + linkName + ",";
				}
				webActions.clickElement(btnDiscloreClose);

			}
			if (status.equals("")) {
				LogUtility.logInfo("checkTheDisclosureLinks",
						"All the disclosure links are clicked and opened successfully");
			} else
				LogUtility.logError("checkTheDisclosureLinks",
						"Failed to click the links " + linkName + " and check them");
		} catch (Exception e) {
			LogUtility.logException("checkTheDisclosureLinks", "Failed to click on the disclosure link", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public void selectSomeDisclosures() throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			int i = 1;
			for (WebElement disclosure : lstDisclosuresCheckBox) {
				wolWebUtil.scrollToElement(disclosure);
				webActions.clickElement(disclosure);
				i++;
				if (i == lstDisclosuresCheckBox.size() - 1)
					break;
			}
			LogUtility.logInfo("selectSomeDisclosures", "Selected only some of the disclosures options");
		} catch (Exception e) {
			LogUtility.logException("selectSomeDisclosures", "Failed to select disclosure", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	public String checkTheDisclosurePageContent(String discLabels, String discLinkText) {
		String status = "";
		try {
			waits.waitUntilElementIsPresent(btnContinue, maxTimeOut);
			for (int i = 0; i < lstDisclosureLabels.size(); i++) {
				if (!(discLinkText.contains(lstDisclosureLabels.get(i).getText())
						&& discLabels.contains(lstDisclosureLinks.get(i).getText()))) {
					status = status + lstDisclosureLabels.get(i).getText() + ",";
				}
			}
			if (status.equals("")) {
				LogUtility.logInfo("checkTheDisclosurePageContent",
						"All the disclosure content is present as expected");
			} else
				LogUtility.logError("checkTheDisclosurePageContent",
						"Could not find the disclosure content for the links " + status);
		} catch (Exception e) {
			LogUtility.logException("checkTheDisclosurePageContent", "Failed to check disclosure page content", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public String checkContentInConfirmatioPage() {
		String status = "";
		String textFromUI = txtConfirmContent.getText();
		try {
			for (String eachKey : jsonDataParser.getTestDataMap().keySet()) {
				if (eachKey.contains("Confirmation Header")) {
					for (String testData : jsonDataParser.getTestDataMap().get(eachKey).split(";")) {
						if (!textFromUI.contains(testData)) {
							status = status + jsonDataParser.getTestDataMap().get(eachKey) + ",";
							break;
						}

					}
				}
			}
			if (status.equals("")) {
				LogUtility.logInfo("checkContentInConfirmatioPage",
						"All the confirmation page headers and content  is present as expected");
			} else
				LogUtility.logError("checkContentInConfirmatioPage",
						"Could not find the confirmation page headers and content for " + status);
		} catch (Exception e) {
			LogUtility.logException("checkContentInConfirmatioPage", "Failed to check content in confirmation page", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkDrivingLicenseErrorMsg() {
		boolean status = true;
		try {
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(btnDiscloreClose, maxTimeOut);
			for (WebElement eleError : txtDLErrorMsg) {
				if (!jsonDataParser.getTestDataMap().get("Driving License Error Message")
						.contains(eleError.getText())) {
					status = false;
				} else
					LogUtility.logInfo("checkDrivingLicenseErrorMsg", eleError.getText() + ": is present in the page");
			}
		} catch (Exception e) {
			LogUtility.logException("checkDrivingLicenseErrorMsg", "Failed to find DL error message", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkEmailErrorMsg(String msgType) {
		boolean status = false;
		try {
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(txtEmailErrorMsg, maxTimeOut);
			if (wolWebUtil.verifyText(txtEmailErrorMsg, msgType, "checkEmailErrorMsg")) {
				status = true;
				LogUtility.logInfo("checkEmailErrorMsg", "Error message is present in the page");
			}

		} catch (Exception e) {
			LogUtility.logException("checkEmailErrorMsg", "Failed to find DL error message", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean clickOnCancelButton() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(btnCancel, maxTimeOut);
			if (webActions.isDisplayed(btnCancel)) {
				status = true;
				webActions.clickElement(btnCancel);
				LogUtility.logInfo("clickOnCancelButton", "Clicked on the cancel button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCancelButton", "Failed to find cancel button", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkContentInStartPage() {
		boolean status = true;
		try {
			for (WebElement ele : lstStartPageContent) {
				if (!jsonDataParser.getTestDataMap().get("Start Page Content").contains(ele.getText())) {
					status = false;
					LogUtility.logInfo("checkContentInStartPage",
							"{" + ele.getText() + "} content is not found in start page");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkContentInStartPage", "Failed to find content in start page", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean enterInvalidEmailDetails(String emailData) throws Exception {
		boolean status = false;
		waits.waitUntilElementIsPresent(inputCustEmail, maxTimeOut);
		try {
			if (webActions.isDisplayed(inputCustEmail)) {
				webActions.clearValue(inputCustEmail);
				webActions.setValue(inputCustEmail, emailData);
				LogUtility.logInfo("enterEmailDetails", "Entered all email details");
				status = true;
			} else
				LogUtility.logError("enterEmailDetails", "could not enter the invalid email details");
		} catch (Exception e) {
			LogUtility.logException("enterEmailDetails", "Exception in entering invalid email id ", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		return status;
	}

	public boolean clickOnCancelLightBox(String button, boolean clickOrNot) {
		boolean status = false;
		WebElement eleToClick = null;
		if (button.equals("Yes"))
			eleToClick = btnCancelYes;
		else
			eleToClick = btnCancelNo;
		waits.waitForPageToLoad(maxTimeOut);
		waits.waitUntilElementIsPresent(eleToClick, maxTimeOut);
		try {
			if (webActions.isDisplayed(eleToClick)) {
				if (clickOrNot) {
					webActions.clickElement(eleToClick);
					waits.waitForPageToLoad(maxTimeOut);
					waits.waitForDOMready();
					LogUtility.logInfo("clickOnCancelPromo",
							"Clciked on the button " + clickOrNot + " in cancel button ");
				}
				LogUtility.logInfo("clickOnCancelPromo", "Found the light box for cancel button ");
				status = true;
			} else
				LogUtility.logError("clickOnCancelPromo", "could not find the light box for cancel button");
		} catch (Exception e) {
			LogUtility.logException("clickOnCancelPromo", "Exception in finding the light box for cancel button", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean bankButtonIsDisplayed() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnBank, maxTimeOut);
			if (webActions.isDisplayed(btnBank)) {
				status = true;
				LogUtility.logInfo("bankButtonIsDisplayed", "Bank  tab is displayed");
			}
		} catch (Exception e) {
			LogUtility.logException("bankButtonIsDisplayed", "Exception in finding Bank tab", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean checkContentForExistCustSSN(String msg) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtSSNAlreadyExistsLogin, maxTimeOut);
			if (wolWebUtil.verifyText(txtSSNAlreadyExistsLogin, msg)) {
				status = true;
				LogUtility.logInfo("checkContentForExistCustSSN", "Message {" + msg + "} is found");
			}
		} catch (Exception e) {
			LogUtility.logException("checkContentForExistCustSSN", "Exception in finding the message", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkContentInIdentificationPage(String msg1, String msg2, String citizenship) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtPEPQues2Label, maxTimeOut);
			if (wolWebUtil.verifyText(txtPEPQues1Label, msg1) && wolWebUtil.verifyText(txtPEPQues2Label, msg2)
					&& wolWebUtil.verifyText(txtCitizenShipLabel, citizenship)) {
				status = true;
				LogUtility.logInfo("checkContentInIdentificationPage",
						"PEP Questions and citizenship content is displayed correct");
			}
		} catch (Exception e) {
			LogUtility.logException("checkContentInIdentificationPage",
					"Exception in finding the content in identification page", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public String checkTheListOptions(String selectBox) {
		String status = "";
		String[] list = jsonDataParser.getTestDataMap().get(selectBox).split(",");
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(selEmpStatus, maxTimeOut);
			for (String eachOption : list) {
				if (!wolWebUtil.verifyListValues(selEmpStatus, eachOption)) {
					status = status + eachOption + ",";
				}
			}
			if (!status.equals(""))
				LogUtility.logError("checkTheListOptions",
						"Some of the options " + status + " are missing in the dropdown " + selectBox);
			else
				LogUtility.logInfo("checkTheListOptions", "All the options are present in the dropdown " + selectBox);
		} catch (Exception e) {
			LogUtility.logException("checkTheListOptions", "Exception in checkTheListOptions function", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public void enterSelfEmploymentData(String business, String date, String activity) {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(inputBusName, maxTimeOut);
			webActions.setValue(inputBusName, business);
			webActions.setValue(inputBusStartDate, date);
			webActions.setValue(inputBusActivity, activity);
			LogUtility.logInfo("enterSelfEmploymentData", "Entered the self employment data");
		} catch (Exception e) {
			LogUtility.logException("enterSelfEmploymentData", "Exception in enterSelfEmplymentData function", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	public boolean checkThePersonalErrorMessage(String errorMsg) {
		boolean status = false;
		boolean flag = true;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();

			if (txtPersonalInfoError.size() > 1) {
				for (WebElement ele : txtPersonalInfoError) {
					if (!errorMsg.contains(ele.getText())) {
						flag = false;
					}
				}
				if (flag == true)
					status = true;
				else
					status = false;
			} else {
				if (wolWebUtil.verifyText(txtPersonalInfoError.get(0), errorMsg)) {
					status = true;
				}
			}

			if (status)
				LogUtility.logError("checkThePersonalErrorMessage", "Found the error message " + errorMsg);
			else
				LogUtility.logInfo("checkThePersonalErrorMessage", "Failed to find the error message " + errorMsg);
		} catch (Exception e) {
			LogUtility.logException("checkThePersonalErrorMessage",
					"Exception in checkThePersonalErrorMessage function", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkTheDLErrorMessage(String field) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (field) {
			case "License State":
				eleToGetText = txtDLStateError;
				break;
			case "License Number":
				eleToGetText = txtDLNumberError;
				break;
			case "Issue Date":
				eleToGetText = txtDLStartDateError;
				break;
			case "Expiration Date":
				eleToGetText = txtDLExpiryDateError;
				break;
			default:
				LogUtility.logError("Invalid column name in DL page");

			}
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (wolWebUtil.verifyText(eleToGetText, jsonDataParser.getTestDataMap().get(field))) {
				status = true;
				LogUtility.logError("checkTheDLErrorMessage",
						"Found the DL error message " + jsonDataParser.getTestDataMap().get(field));
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheDLErrorMessage", "Exception in checkTheDLErrorMessage function", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkThePageLevelErrorMessage(String errorMsg) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtPageLevelMsg, maxTimeOut);
			if (wolWebUtil.verifyText(txtPageLevelMsg, errorMsg)) {
				status = true;
			}
			if (status)
				LogUtility.logError("checkThePageLevelErrorMessage", "Found the page level error message " + errorMsg);
			else
				LogUtility.logInfo("checkThePageLevelErrorMessage",
						"Failed to find the page level error message " + errorMsg);
		} catch (Exception e) {
			LogUtility.logException("checkThePageLevelErrorMessage",
					"Exception in checkThePageLevelErrorMessage function", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForOCOpenButton() {
		boolean status = false;
		try {
			if (!waits.waitUntilElementIsPresent(btnOCOpenAccount, maxTimeOut)) {
				status = true;
				LogUtility.logError("checkForOCOpenButton",
						"Open button for opportunity checking button is not present ");
			}

		} catch (Exception e) {
			status = true;
			LogUtility.logException("checkForOCOpenButton", "Exception in checkForOCOpenButton function", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOnTabFromMainMenu(String tab) {
		boolean status = false;
		try {
			WebElement eleTab = driver.findElement(By.xpath(mainTab.replace("ReplaceMe", tab)));
			if (waits.waitUntilElementIsPresent(eleTab, maxTimeOut)) {
				webActions.clickElement(eleTab);
				status = true;
				LogUtility.logError("clickOnTabFromMainMenu", "Clicked on the tab " + tab);
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnTabFromMainMenu", "Exception in clickOnTabFromMainMenu function", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOnViewLink(String value) {
		boolean status = false;
		try {
			for (int i = 0; i < lstSSNWebcom.size(); i++) {
				value = testDataMap.get("Social Security Number");
				if (lstSSNWebcom.get(i).getText().equals(value)) {
					lstViewLinks.get(i).click();
					status = true;
					LogUtility.logError("clickOnViewLink", "Clicked on the view link");
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewLink", "Exception in clickOnViewLink function", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean checkTheAuditStepMsg(String msg) {
		boolean status = false;
		try {
			for (int i = 0; i < lstAuditSteps.size(); i++) {
				if (lstAuditSteps.get(i).getText().contains(msg)) {
					status = true;
					LogUtility.logInfo("checkTheAuditStepMsg", "Found the message " + msg);
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheAuditStepMsg", "Exception in checkTheAuditStepMsg function", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkTheSignInMsg(String msg) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			for (int i = 0; i < 2; i++) {
				if (waits.waitUntilElementIsPresent(txtSignInForExistingCust, maxTimeOut))
					break;
			}
			if (txtSignInForExistingCust.getText().equals(msg)) {
				status = true;
				LogUtility.logInfo("checkTheSignInMsg", "Found the message :" + msg);
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheSignInMsg", "Exception in checkTheAuditStepMsg function", e,
					LoggingLevel.ERROR, true);
		}
		return status;

	}

	public boolean checkTheLicenseLightBoxText(String msg) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			for (int i = 0; i < 2; i++) {
				if (waits.waitUntilElementIsPresent(txtLicenseLBText, maxTimeOut))
					break;
			}
			if (txtLicenseLBText.getText().equals(msg)) {
				status = true;
				LogUtility.logInfo("checkTheLicenseLightBoxText", "Found the message :" + msg);
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheLicenseLightBoxText", "Exception in checkTheLicenseLightBoxText function",
					e, LoggingLevel.ERROR, true);
		}
		return status;

	}

	/**
	 * getInterestRate: To get the interest rate
	 * 
	 * @param term
	 * @return boolean
	 */
	public boolean getInterestRate(String term) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			eleRateRange = driver.findElements(By.cssSelector(String.format(rateRange, term)));
			eleinterestRate = driver.findElements(By.cssSelector(String.format(interestRate, term)));
			eleaypRate = driver.findElements(By.cssSelector(String.format(aypRate, term)));
			for (WebElement rateRangeElement : eleRateRange)
				lstRateRange.add(webActions.getText(rateRangeElement));
			for (WebElement interestRateElement : eleinterestRate)
				lstInterestRate.add(webActions.getText(interestRateElement));
			for (WebElement apyRateElement : eleaypRate)
				lstApyRate.add(webActions.getText(apyRateElement));
			LogUtility.logInfo("-->getInterestRate<--", "Rate Ranges, Interest Rates and APY Rates are captured");
			return true;
		} catch (Exception e) {
			LogUtility.logException("-->getInterestRate<--",
					"Failed to capture Rate Ranges, Interest Rates and APY Rates", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyRatesInWebcom: To verify the rates in Webcom
	 * 
	 * @param term
	 * @return boolean
	 */
	public boolean verifyRatesInWebcom(String term) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement rowTermPath = null;
		WebElement ratePath = null;
		WebElement interestRatePath = null;
		WebElement apyRatePath = null;
		int count = 0;
		try {
			int tableDepositSize = lstDepositTableRows.size();
			for (int i = 1; i < tableDepositSize; i++) {
				rowTermPath = driver.findElement(By.xpath(String.format(tblBasepath + i + tblTermPath)));
				if (term.equalsIgnoreCase(webActions.getText(rowTermPath))) {
					ratePath = driver.findElement(By.xpath(String.format(tblBasepath + i + rateRangePath)));
					interestRatePath = driver.findElement(By.xpath(String.format(tblBasepath + i + interestPath)));
					apyRatePath = driver.findElement(By.xpath(String.format(tblBasepath + i + apyPath)));
					if (lstRateRange.contains(webActions.getText(ratePath)))
						if (lstInterestRate.contains(webActions.getText(interestRatePath)))
							if (lstApyRate.contains(webActions.getText(apyRatePath)))
								count++;
				}
			}
			if (count == lstRateRange.size())
				return true;
			LogUtility.logInfo("-->verifyRatesInWebcom<--", "Rate Ranges, Interest Rates and APY Rates are captured");
		} catch (Exception e) {
			LogUtility.logException("-->verifyRatesInWebcom<--",
					"Failed to capture Rate Ranges, Interest Rates and APY Rates", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnNAOButton: To click on the button in NAO page
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnNAOButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			WebElement btnToClick = null;
			switch (btnName) {
			case "I DON'T KNOW THE ANSWERS":
				btnToClick = btnDontKnowAnswer;
				break;
			case "Yes,I'm Sure":
				btnToClick = btnImSure;
				break;
			case "Let Me Try Again":
				btnToClick = btnTryAgain;
				break;
			case "Close":
				btnToClick = btnClosePopup;
				break;
			default:
				LogUtility.logInfo("clickOnNAOButton", "No case match found");
				break;
			}
			if (webActions.isDisplayed(btnToClick)) {
				webActions.clickElement(btnToClick);
				LogUtility.logInfo("clickOnNAOButton", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnNAOButton", "Button: " + btnName + " is clicked", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyNAOButton: To verify the buttons in NAO flow
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean verifyNAOButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		waits.staticWait(5);
		try {
			WebElement btnToClick = null;
			switch (btnName) {
			case "Yes,I'm Sure":
				btnToClick = btnImSure;
				break;
			case "Let Me Try Again":
				btnToClick = btnTryAgain;
				break;
			case "Close":
				btnToClick = btnClosePopup;
				break;

			default:
				LogUtility.logInfo("-->verifyNAOButton<--", "No case match found");
				break;
			}
			if (webActions.isDisplayed(btnToClick)) {
				LogUtility.logInfo("-->verifyNAOButton<--", "Button: " + btnName + " is verified");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNAOButton", "Button: " + btnName + " is clicked", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyMessage : To verify the message
	 * 
	 * @param testDataMap.get
	 * @return boolean
	 */
	public boolean verifyMessage(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtFailEquifaxMessage, testDataMap.get("ErrorMessage1")))
				if (wolWebUtil.verifyTextContains(txtFailEquifaxMessage, testDataMap.get("ErrorMessage2"))) {
					LogUtility.logInfo("-->verifyMessage<--", "Message: " + testDataMap.get("ErrorMessage1")
							+ testDataMap.get("ErrorMessage2") + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->verifyMessage<--", "Message is not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

}