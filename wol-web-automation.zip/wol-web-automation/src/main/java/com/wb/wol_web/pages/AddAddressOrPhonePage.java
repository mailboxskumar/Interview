
package com.wb.wol_web.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class AddAddressOrPhonePage extends ObjectBase {

	public AddAddressOrPhonePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "address-phone-change__formSection--phone__section-title")
	protected WebElement editPhoneTitle;

	@FindBy(id = "mobilePhone__input")
	protected WebElement inputMobilePhoneNumber;

	@FindBy(id = "homePhone__input")
	protected WebElement inputHomePhoneNumber;

	@FindBy(id = "workPhone__input")
	protected WebElement inputWorkPhoneNumber;

	@FindBy(id = "address-phone-change__form__button--submit__buttonText")
	protected WebElement btnContinue;

	@FindBy(id = "address-phone-change-verify__form__button--submit__buttonText")
	protected WebElement btnContinueInVerifyPage;

	@FindAll(@FindBy(xpath = "//li[@class='accordion__item']"))
	protected List<WebElement> lstAccountDetails;

	@FindBy(id = "address-phone-change-confirm__pageTitle")
	protected WebElement txtConfirmationpageHeading;

	@FindBy(id = "address-phone-change-confirm__pageAffirmativeNotice__body")
	protected WebElement txtConfirmationTitleHeading;

	/**
	 * To click on the edit phone Number heading
	 * 
	 * @Author:Sneha K
	 * @Created on: May 10th 2019
	 * @Modified on:
	 * @param msg , errorType
	 * @return
	 */
	public boolean clickOnEditPhoneTitle() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(editPhoneTitle, 5);
			if (webActions.isDisplayed(editPhoneTitle)) {
				webActions.clickElement(editPhoneTitle);
				flag = true;
				LogUtility.logInfo("--->clickOnEditPhoneTitle<---", "Clicked on phone Number title");
			} else
				LogUtility.logError("clickOnEditPhoneTitle", "Could not Click on phone Number title");
		} catch (Exception e) {
			LogUtility.logError("--->clickOnEditPhoneTitle<---", e.getMessage());
		}
		return flag;
	}

	/**
	 * To enter new phone details
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param msg , errorType
	 * @return
	 * @throws Exception
	 */
	public void enterNewPhoneNumber() throws Exception {
		try {
			waits.waitUntilElementIsPresent(inputHomePhoneNumber, 5);
			webActions.setValue(inputHomePhoneNumber, wolWebUtil.getRandomNumber(10));
			LogUtility.logInfo("--->enterNewPhoneNumber<---", "Entered new phone Number");
		} catch (Exception e) {
			LogUtility.logError("--->enterNewPhoneNumber<---", e.getMessage());
			throw new Exception("Exception while entering new phone number");
		}
	}

	/**
	 * To enter new phone details
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param msg , errorType
	 * @return
	 */
	public boolean clickOnTheButton(String btnName) {
		WebElement eleToClick = null;
		boolean status = false;
		try {
			switch (btnName) {
			case "Continue":
				eleToClick = btnContinue;
				break;
			case "ContinueinVerifyPage":
				eleToClick = btnContinueInVerifyPage;
				break;
			default:
				break;
			}
			waits.waitUntilElementIsPresent(eleToClick);
			if (webActions.isDisplayed(eleToClick)) {
				webActions.clickElement(eleToClick);
				status = true;
				LogUtility.logInfo("--->clickOnTheButton<---", "Clicked on the button " + btnName);
			} else
				LogUtility.logError("clickOnTheButton", "Could not Click on the button " + btnName);

		} catch (Exception e) {
			LogUtility.logError("--->clickOnTheButton<---", e.getMessage());
		}
		return status;
	}

	/**
	 * To check the confirmation page heading
	 * 
	 * @Author:Sneha K
	 * @Created on: Jul 3rd 2019
	 * @Modified on:
	 * @param text
	 * @return
	 */
	public boolean checkForConfirmationPage(String text) {
		boolean status = false;
		try {

			waits.waitUntilElementIsPresent(txtConfirmationpageHeading);
			if (wolWebUtil.verifyText(txtConfirmationpageHeading, text)) {
				status = true;
				LogUtility.logInfo("--->checkForConfirmationPage<---", "Found the page heading " + text);
			} else {
				LogUtility.logError("checkForConfirmationPage", "Could not reach the destination page " + text);
			}
		} catch (Exception e) {
			LogUtility.logError("--->checkForConfirmationPage<---", e.getMessage());
		}
		return status;
	}

	/**
	 * To check the confirmation page heading text
	 * 
	 * @Author:Sneha K
	 * @Created on: Jul 3rd 2019
	 * @Modified on:
	 * @param text
	 * @return
	 */
	public boolean checkForConfirmationPageTitle(String text) {
		boolean status = false;
		try {

			waits.waitUntilElementIsPresent(txtConfirmationTitleHeading);
			if (wolWebUtil.verifyText(txtConfirmationTitleHeading, text)) {
				status = true;
				LogUtility.logInfo("--->checkForConfirmationPageTitle<---", "Found the page title " + text);
			} else
				LogUtility.logError("checkForConfirmationPageTitle", "Could not reach the page " + text);
		} catch (Exception e) {
			LogUtility.logError("--->checkForConfirmationPageTitle<---", e.getMessage());
		}
		return status;
	}

}
