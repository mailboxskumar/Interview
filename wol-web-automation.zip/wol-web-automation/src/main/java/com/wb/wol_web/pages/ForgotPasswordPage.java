package com.wb.wol_web.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class ForgotPasswordPage extends ObjectBase {

	public ForgotPasswordPage() {
		PageFactory.initElements(driver, this);
	}

	public String stepNumber = "//p[@id='stepn__label']";

	@FindBy(xpath = "//img[@alt='Webster Bank. Living up to you.']")
	protected WebElement imgWebsterLogo;

	@FindBy(xpath = "//a[contains(text(),'Password?')]")
	protected WebElement lnkForgotPassword;

	@FindBy(xpath = "//h1[contains(text(),'Reset')]")
	protected WebElement txtPageTitle;

	@FindBy(xpath = "//label[@id = 'fieldUsername__label']")
	protected WebElement txtUsernameLabel;

	@FindBy(xpath = "//input[@id = 'fieldUsername__input']")
	protected WebElement txtUsernameField;

	@FindBy(xpath = "//*[contains(text(),'Continue')]")
	protected WebElement btnContiue;

	@FindBy(id = "formSectionLoginPasswordResetChallenge__section-title")
	protected WebElement txtChallengeQuestion;

	@FindBy(id = "answer__input")
	protected WebElement txtChallengeQuestionField;

	@FindBy(id = "login-password-reset-conf-standard__pageAffirmativeNotice_gen__body")
	protected WebElement txtResetPasswordConfirmation;

	@FindBy(id = "login-password-reset-conf-standard__pageNote_gen__body")
	protected WebElement txtToolTip;

	@FindBy(id = "nextStepsReturn__link")
	protected WebElement lnkNextStep;

	@FindBy(id = "password__error-message")
	protected WebElement txtPasswordErr;

	@FindBy(id = "passwordResetSteps__stepdetailstext")
	protected WebElement txtStepDetails;

	/**
	 * verifyStepLabels: to verify progress bar step labels in Reset Password pages
	 * 
	 * @param number
	 * @param message
	 * @return
	 */
	public boolean verifyStepLabels(Integer number, String message) {
		try {
			WebElement stepLabel = driver.findElement(By.xpath(stepNumber.replace("n", String.valueOf(number))));
			waits.waitUntilElementIsPresent(stepLabel);
			return wolWebUtil.verifyText(stepLabel, message);
		} catch (Exception e) {
			LogUtility.logException("verifyStepLabels", "Failed to verify Steps Label Names", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyStepDetails: to verify progress bar step details in Reset Password
	 * pages
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyStepDetails(String message) {
		try {
			waits.waitUntilElementIsPresent(txtStepDetails);
			return wolWebUtil.verifyTextContains(txtStepDetails, message);
		} catch (Exception e) {
			LogUtility.logException("verifyStepDetails", "Failed to verify Steps Label Content", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	public boolean verifyResetPasswordTitle(String rpTitle) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(txtPageTitle, maxTimeOut);
			return wolWebUtil.verifyText(txtPageTitle, rpTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyResetPasswordTitle", "Failed to verify Reset Password Page Title", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyUserNameLabel- To verify the user name label is displayed or not
	 * 
	 * @param userName
	 * @return
	 */
	public boolean verifyUserNameLabel(String userName) {
		try {
			return wolWebUtil.verifyText(txtUsernameLabel, userName);
		} catch (Exception e) {
			LogUtility.logException("verifyUserNameLabel", "Failed to verify Username Label", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * enterUserName: To enter user name Value
	 * 
	 * @param userName
	 */
	public boolean enterUserName(String userName) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtUsernameField);
			webActions.setValue(txtUsernameField, userName);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtUsernameField, "value").equalsIgnoreCase(userName)) {
				flag = true;
				LogUtility.logInfo("enterUserName", "Entered username in Reset Password Page");
			} else
				LogUtility.logInfo("enterUserName", "Failed to Enter username in Reset Password Page");
		} catch (Exception e) {
			LogUtility.logException("enterUserName", "Failed to Enter username in Reset Password Page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnContinueButton: To click on continue button in Reset Password pages
	 */
	public void clickOnContinueButton() {
		try {
			waits.waitUntilElementIsPresent(btnContiue);
			webActions.clickElement(btnContiue);
			LogUtility.logInfo("clickOnContinueButton", "Clicked on Continue Button");
		} catch (Exception e) {
			LogUtility.logException("clickOnContinueButton", "Failed to Click on Continue Button", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * verifyChallengeQuestionLabel: To verify Challenge Question Label is displayed
	 * or not
	 * 
	 * @param challengeQuestion
	 * @return
	 */
	public boolean verifyChallengeQuestionLabel(String challengeQuestion) {
		try {
			return wolWebUtil.verifyText(txtChallengeQuestion, challengeQuestion);
		} catch (Exception e) {
			LogUtility.logException("verifyChallengeQuestionLabel", "Failed to verify Challenge Question label", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * enterAnswer: To enter answer value
	 * 
	 * @param answer
	 */
	public boolean enterAnswer(String answer) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtChallengeQuestionField);
			webActions.setValue(txtChallengeQuestionField, answer);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtChallengeQuestionField, "value").equalsIgnoreCase(answer)) {
				flag = true;
				LogUtility.logInfo("enterAnswer", "Entered answer in Reset Password Page");
			}
			LogUtility.logInfo("enterAnswer", "Failed to Enter answer in Reset Password Page");
		} catch (Exception e) {
			LogUtility.logException("enterAnswer", "Failed to Enter answer in Reset Password Page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyToolTip:To verify tool tip message in confirmation page
	 * 
	 * @param toolTip
	 * @return
	 */
	public boolean verifyToolTip(String toolTip) {
		try {
			return wolWebUtil.verifyTextContains(txtToolTip, toolTip);
		} catch (Exception e) {
			LogUtility.logException("verifyToolTip", "Failed to tooltip content", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyConfirmationMessage: To verify confirmation message
	 * 
	 * @param confirmationMessage
	 * @return
	 */
	public boolean verifyConfirmationMessage(String confirmationMessage) {
		try {
			return wolWebUtil.verifyText(txtResetPasswordConfirmation, confirmationMessage);
		} catch (Exception e) {
			LogUtility.logException("verifyConfirmationMessage", "Failed to verify confirmation message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyNextStepLink: To verify Sign In Your account link is displayed or not
	 * 
	 * @return
	 */
	public boolean verifyNextStepLink() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(lnkNextStep)) {
				flag = true;
				LogUtility.logInfo("verifyNextStepLink", "Next Step Link is displayed");
			} else
				LogUtility.logInfo("verifyNextStepLink", "Next Step Link is not displayed");
		} catch (Exception e) {
			LogUtility.logException("verifyNextStepLink", "Failed to Next Step Link ", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickForgotPasswordLink: To click on Forgot Password Link
	 */
	public void clickForgotPasswordLink() {
		try {
			waits.waitUntilElementIsPresent(lnkForgotPassword);
			webActions.clickElement(lnkForgotPassword);
			waits.staticWait(2);
			LogUtility.logInfo("clickForgotPasswordLink", "Clicked on Forgot Password Link");
		} catch (Exception e) {
			LogUtility.logException("clickForgotPasswordLink", "Failed to Click on Forgot Password Link", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickWebsterLogo: To click on Webster Logo image
	 * 
	 * @return
	 */
	public boolean clickWebsterLogo() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(imgWebsterLogo);
			webActions.clickElement(imgWebsterLogo);
			if (waits.waitUntilElementIsPresent(lnkForgotPassword)) {
				flag = true;
				LogUtility.logInfo("clickWebsterLogo", "Clicked on Webster Logo Image");
			} else
				LogUtility.logInfo("clickWebsterLogo", "Failed to Click on Webster Logo Image");
		} catch (Exception e) {
			LogUtility.logException("clickWebsterLogo", "Failed to Click on Webster Logo Image", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * checkResetPasswordURL: To check the reset password url
	 * 
	 * @param content
	 * @return
	 */
	public boolean checkResetPasswordURL(String content) {
		boolean flag = false;
		try {
			String value = driver.getCurrentUrl();
			if (value.contains(content)) {
				flag = true;
				LogUtility.logInfo("checkResetPasswordURL", "Checked Reset password url");
			} else
				LogUtility.logInfo("checkResetPasswordURL", "Failed to Check Reset password url");

		} catch (Exception e) {
			LogUtility.logException("checkResetPasswordURL", "Failed to verify Reset Password url", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyPasswordErrMessage: To verify the error message of password
	 * 
	 * @param errMessage
	 * @return
	 */
	public boolean verifyPasswordErrMessage(String errMessage) {
		try {
			return wolWebUtil.verifyTextContains(txtPasswordErr, errMessage);
		} catch (Exception e) {
			LogUtility.logException("verifyPasswordErrMessage", "Failed to verify password error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

}