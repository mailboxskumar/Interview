
/**
 * @author VSomalaraju-adm
 */
package com.wb.wol_web.pages;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class SetUpTaxPaymentsPage extends ObjectBase {

	public SetUpTaxPaymentsPage() {
		PageFactory.initElements(driver, this);
	}

	public String taxConfirmNo;
	public String taxPayeeName;
	public String validTaxPayeeName;
	public String taxAmountErrMsgForHugeAmount;
	public String taxEndDateErrMsgForWrongDate;
	public String taxEndDateErrMsgFor10YearsBefore;
	public String pmtDeliveryDate;
	public String currentMonthName;
	public String calWidgetMonthName;
	public LinkedHashMap<String, String> taxPmtEnteredValue;
	public LinkedHashMap<String, String> confirmTaxDetails;

	@FindBy(xpath = "//h1[contains(text(),'Set Up Tax Payment')]")
	protected WebElement ttlSetUpTaxPmt;

	@FindBy(xpath = "//select[@id='form-field__value--select-account']")
	protected WebElement lstSelectFromAccount;

	@FindBy(xpath = "//select[@id='form-field__value--select-payeeb']")
	protected WebElement lstTaxPayeeName;

	@FindBy(xpath = "//input[@id='form-field__value--payment-date']")
	protected WebElement txtTaxPmtDeliveryDate;

	@FindBy(xpath = "//input[@id='form-field__value--item_amount1']")
	protected WebElement txtTaxPeriodEndDate;

	@FindBy(xpath = "//input[@id='form-field__value--tax-amount']")
	protected WebElement txtTaxAmount;

	@FindBy(xpath = "//input[@id='form-field__value--taxpayer-name']")
	protected WebElement txtTaxPayerName;

	@FindBy(xpath = "//input[@id='form-field__value--access-code']")
	protected WebElement txtTaxPmtAccessCode;

	@FindBy(xpath = "//input[@id='form-field__value--ny-state-tax-amount']")
	protected WebElement txtNyStateTaxAmount;

	@FindBy(xpath = "//div[@class='buttonHolder']//input[@id='btnSubmit' and @value='Continue']")
	protected WebElement btnTaxPmtContinue;

	@FindBy(xpath = "//input[@value='Pay Duplicate Bills' and @id='btnDup']")
	protected WebElement btnPayDuplicateBills;

	// Tax Payment VerifiCation

	@FindBy(xpath = "//h3[contains(text(),'Set Up Tax Payment Verification')]")
	protected WebElement ttlTaxPmtVerification;

	@FindBy(xpath = "//div//input[@id='button_edit_impl' and @value='Edit']")
	protected WebElement btnTaxPmtEdit;

	@FindBy(xpath = "//div[@class='lightbox']//div[@class='formRowButtons']//button[@id='cancelNoBtn']")
	protected WebElement btnTaxPmtNo;

	@FindBy(xpath = "//div[@class='lightbox']//div[@class='formRowButtons']//a[@id='cancelYesBtn']")
	protected WebElement btnTaxPmtYes;

	@FindBy(xpath = "//div[@class='buttonHolder']//input[@id='btnSubmit']")
	protected WebElement btnSetupTaxPayment;

	@FindBy(xpath = "//div[@class='buttonHolder']//button[@id='btnCancel']")
	protected WebElement btnTaxPmtCancel;

	// Tax Payment Confirmation

	@FindBy(xpath = "//h3[contains(text(),'Set Up Tax Payment Confirmation')]")
	protected WebElement ttlTaxPaymentConfirmation;

	@FindBy(xpath = "//div[@class='border_box enforce_border']//dd[@id='form-field__value--confirmation-number']")
	protected WebElement txtTaxConfirmationNo;

	@FindBy(xpath = "//div[@class='border_box enforce_border']//dd[@id='form-field__value--payee-name']")
	protected WebElement txtTaxPayeeName;

	@FindBy(xpath = "//div[@class='border_box enforce_border']//dd[@id='form-field__value--payment-date']")
	protected WebElement txtPaymentDate;

	@FindBy(xpath = "//div[@class='border_box enforce_border']//dd[@id='form-field__value--tax-period-end-date']")
	protected WebElement txtTaxEndDate;

	@FindBy(xpath = "//div[@class='border_box enforce_border']//dd[@id='form-field__value--tax-amount']")
	protected WebElement txtTaxAmountGiven;

	@FindAll(@FindBy(xpath = "//select[@id='form-field__value--select-payeeb']//option[@class='select-option']"))
	protected List<WebElement> taxPayeeList;

	@FindBy(xpath = "//div[@class='border_box enforce_border']//dt")
	protected List<WebElement> taxConfirmLabels;

	@FindBy(xpath = "//div[@class='border_box enforce_border']//dd")
	protected List<WebElement> taxConfirmValues;

	// Pending Payments

	@FindBy(xpath = "//h3[contains(text(),'Manage Pending Payments')]")
	protected WebElement ttlPendingPayments;

	@FindBy(xpath = "//form[@name='payment']/table/thead")
	protected WebElement tblPendingPaymentsHead;

	@FindBy(xpath = "//form[@name='payment']/table/tbody")
	protected WebElement tblPendingPaymentsBody;

	// Tax Payment Error Messages Locators
	@FindBy(xpath = "//div[@class='errorIndicator']/div/p")
	protected WebElement txtTaxPaymentErrMsg;

	@FindBy(xpath = "//dd[contains(@id,'form-field__value--select-payee')]")
	protected WebElement txtNoPayeeErrMsg;

	@FindBy(xpath = "//button[@data-invoice-date='y']")
	protected WebElement taxEndDateCalWidget;

	@FindBy(xpath = "//span[@class='month']")
	protected WebElement calWidgetMonth;;

	/**
	 * Verify Tax Payments Page
	 * 
	 * @author VSomalaraju-adm
	 * @param txPmtTtlVerify
	 * @return
	 */
	public boolean verifyTaxPaymentTtl(String txPmtTtlVerify) {
		try {
			return wolWebUtil.verifyText(ttlSetUpTaxPmt, txPmtTtlVerify);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxPaymentTtl <---", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Used for Entering Tax Payment Details
	 * 
	 * @author VSomalaraju-adm
	 * @param taxPayeeName
	 * @param taxPaymentDetails
	 */
	public void inputTaxPaymentDetails(String taxPayeeName, Map<String, String> taxPaymentDetails) {
		try {
			List<WebElement> selectList = lstTaxPayeeName.findElements(By.tagName("option"));
			int listCount = selectList.size();
			for (int taxPayeeCount = 1; taxPayeeCount <= listCount; taxPayeeCount++) {
				String listData = selectList.get(taxPayeeCount).getText();
				if (listData.contains(taxPayeeName)) {
					selectList.get(taxPayeeCount).click();
					break;
				}
			}
			waits.waitUntilElementIsPresent(txtTaxPeriodEndDate);
			switch (taxPayeeName) {
			case "CT":
				webActions.setValue(txtTaxPeriodEndDate, taxPaymentDetails.get("taxPeriodEndDate"));
				waits.waitUntilElementIsPresent(txtTaxAmount, 3);
				webActions.setValue(txtTaxAmount, taxPaymentDetails.get("taxAmount"));
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputTaxPaymentDetails <---",
						"Entered tax end date { " + taxPaymentDetails.get("taxPeriodEndDate") + " } and tax amount{ "
								+ taxPaymentDetails.get("taxAmount") + " } successfully");
				break;
			case "FED":
				webActions.setValue(txtTaxPeriodEndDate, taxPaymentDetails.get("taxPeriodEndDate"));
				waits.waitUntilElementIsPresent(txtTaxAmount);
				webActions.setValue(txtTaxAmount, taxPaymentDetails.get("taxAmount"));
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputTaxPaymentDetails <---",
						"Entered tax end date { " + taxPaymentDetails.get("taxPeriodEndDate") + " } and tax amount{ "
								+ taxPaymentDetails.get("taxAmount") + " } successfully");
				break;
			case "MA":
				webActions.setValue(txtTaxPeriodEndDate, taxPaymentDetails.get("taxPeriodEndDate"));
				waits.waitUntilElementIsPresent(txtTaxPayerName);
				webActions.setValue(txtTaxPayerName, taxPaymentDetails.get("taxPayerName"));
				webActions.setValue(txtTaxAmount, taxPaymentDetails.get("taxAmount"));
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputTaxPaymentDetails <---",
						"Entered tax end date { " + taxPaymentDetails.get("taxPeriodEndDate") + " } , tax amount { "
								+ taxPaymentDetails.get("taxAmount") + " } and tax payer name { "
								+ taxPaymentDetails.get("taxPayerName") + " } successfully");
				break;
			case "NY":
				webActions.setValue(txtTaxPeriodEndDate, taxPaymentDetails.get("taxPeriodEndDate"));
				waits.waitUntilElementIsPresent(txtTaxPayerName);
				webActions.setValue(txtTaxPayerName, taxPaymentDetails.get("taxPayerName"));
				waits.waitUntilElementIsPresent(txtTaxPmtAccessCode);
				webActions.setValue(txtTaxPmtAccessCode, taxPaymentDetails.get("accessCode"));
				waits.waitUntilElementIsPresent(txtNyStateTaxAmount);
				webActions.setValue(txtNyStateTaxAmount, taxPaymentDetails.get("taxAmount"));
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputTaxPaymentDetails <---",
						"Entered tax end date { " + taxPaymentDetails.get("taxPeriodEndDate") + " } , tax amount { "
								+ taxPaymentDetails.get("taxAmount") + " } and tax payer name { "
								+ taxPaymentDetails.get("taxPayerName") + " } successfully");
				break;
			case "RI":
				webActions.setValue(txtTaxPeriodEndDate, taxPaymentDetails.get("taxPeriodEndDate"));
				waits.waitUntilElementIsPresent(txtTaxAmount);
				webActions.setValue(txtTaxAmount, taxPaymentDetails.get("taxAmount"));
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputTaxPaymentDetails <---",
						"Entered tax end date { " + taxPaymentDetails.get("taxPeriodEndDate") + " } and tax amount{ "
								+ taxPaymentDetails.get("taxAmount") + " } successfully");
				break;
			default:
				LogUtility.logInfo(" Given Tax Payee is Not Available in the tax payee list");
			}
		} catch (Exception e) {
			LogUtility.logException("---> inputTaxPaymentDetails <---",
					" Unable to enter tax payment details in { Set Up Tax Payments Page }", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * Used for Click continue under Tax Payments Functionality
	 * 
	 * @author VSomalaraju-adm
	 */
	public boolean clickContinueTaxPayment() {
		boolean flag = false;
		try {
			boolean taxPmtContinue = webActions.isDisplayed(btnTaxPmtContinue);
			if (taxPmtContinue) {
				webActions.clickElement(btnTaxPmtContinue);
				// Have to wait to refresh the page to check any duplicate payments are exist or
				// not
				waits.staticWait(3);
				if (waits.waitUntilElementIsPresent(btnPayDuplicateBills)) {
					webActions.clickElement(btnPayDuplicateBills);
					LogUtility.logInfo("Clicked : Pay Duplicate Bills : successfully");
				}
				LogUtility.logInfo(" ---> clickContinueTaxPayment <---", "Clicked : Continue : button successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> clickContinueTaxPayment <---", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify User Navigated to Tax Payment Verification Page
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlTxPmtVeri
	 * @return
	 */
	public boolean verifyTaxPaymentVerificationPage(String pgTtlTxPmtVeri) {
		try {
			return wolWebUtil.verifyText(ttlTaxPmtVerification, pgTtlTxPmtVeri);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxPaymentVerificationPage <---", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Click on Edit Button in Tax payments Page
	 * 
	 * @author VSomalaraju-adm
	 */
	public void clickEditonTaxPayment() {
		try {
			waits.waitUntilElementIsPresent(btnTaxPmtEdit);
			webActions.clickElement(btnTaxPmtEdit);
			LogUtility.logInfo("---> clickEditonTaxPayment <---", "Clicked on  Edit button successfully");
		} catch (Exception e) {
			LogUtility.logException("---> clickEditonTaxPayment <---", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * Used to Click on Cancel Button
	 * 
	 * @author VSomalaraju-adm
	 */
	public void clickCancelButtonTaxPayment() throws Throwable {
		try {
			waits.waitUntilElementIsPresent(btnTaxPmtCancel);
			webActions.clickElement(btnTaxPmtCancel);
			LogUtility.logInfo("---> clickCancelButtonTaxPayment <---", "Clicked on Cancel button successfully");
		} catch (Exception e) {
			LogUtility.logException("---> clickCancelButtonTaxPayment <---", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * Used to Click on No Button in Light Box
	 */
	public void clickNoButtonTaxPaymentLgtBox() throws Throwable {
		try {
			waits.waitUntilElementIsPresent(btnTaxPmtNo);
			webActions.clickElement(btnTaxPmtNo);
			LogUtility.logInfo("---> clickNoButtonTaxPaymentLgtBox <---",
					"Clicked No Button in Light Box Successfully");
		} catch (Exception e) {
			LogUtility.logException("---> clickNoButtonTaxPaymentLgtBox <---", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * Used to Click on Yes Button in Light Box
	 */
	public void clickYesButtonTaxPaymentLgtBox() throws Throwable {
		try {
			waits.waitUntilElementIsPresent(btnTaxPmtYes);
			webActions.clickElement(btnTaxPmtYes);
			LogUtility.logInfo("---> clickYesButtonTaxPaymentLgtBox <---",
					"Clicked Yes Button in Light Box Successfully");
		} catch (Exception e) {
			LogUtility.logException("---> clickYesButtonTaxPaymentLgtBox <---", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * User Click on Setup Payment Button
	 */
	public boolean clickSetUpPaymentButton() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnSetupTaxPayment);
			boolean clickSetupPayment = webActions.isDisplayed(btnSetupTaxPayment);
			if (clickSetupPayment) {
				webActions.clickElement(btnSetupTaxPayment);
				LogUtility.logInfo("---> clickSetUpPaymentButton <---",
						"Clicked {Setup Payment } Button in Successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> clickSetUpPaymentButton <---", e, LoggingLevel.ERROR, true);
			throw (e);
		}
		return flag;
	}

	/**
	 * Verify User Navigated to Tax Payment Confirmation Page
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlConfirm
	 * @return
	 */
	public boolean verifyTaxConfirmPage(String pgTtlConfirm) {
		try {
			return wolWebUtil.verifyText(ttlTaxPaymentConfirmation, pgTtlConfirm);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxConfimPage <---", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Used for Get the Tax Payment Confirmation No
	 * 
	 * @author VSomalaraju-adm
	 * @return
	 * @throws Exception
	 */
	public String getTaxConfirmationNo() throws Exception {
		try {
			taxConfirmNo = webActions.getText(txtTaxConfirmationNo);
			if (!taxConfirmNo.isEmpty())
				LogUtility.logInfo("Retrieved the Tax Confirmation No:" + taxConfirmNo + ": Successfully");
			else
				LogUtility.logError("Unable to retrieve tax confirm no from confirmation page");
		} catch (Exception e) {
			LogUtility.logException("---> getConfirmationNo <---",
					"Unable to retrieve the confirmation no from tax payment confirmation page", e, LoggingLevel.ERROR,
					true);
			throw new Exception();
		}
		return taxConfirmNo;
	}

	/**
	 * Verify Pending Payments Section
	 * 
	 * @author VSomalaraju-adm
	 * @param pgTtlPenPmt
	 * @return flag
	 */
	public boolean verifyPendingPaymentsPageTtl(String pgTtlPenPmt) {
		try {
			return wolWebUtil.verifyText(ttlPendingPayments, pgTtlPenPmt);
		} catch (Exception e) {
			LogUtility.logException("---> verifyPendingPaymentsPageTtl <---",
					"Unable to navigate { " + pgTtlPenPmt + " }", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	public boolean verifyTaxPmtConfirmationNoInPendingPayments() {
		try {
			String colName = "# Remaining";
			return wolWebUtil.verifyTableResults(tblPendingPaymentsHead, tblPendingPaymentsBody, colName, taxConfirmNo);
		} catch (Exception e) {
			LogUtility.logException("--->checkTheDetailsInPendingPayments<---",
					"Unable to verify confirmation no in Pending payments", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Verify Pending Payments Section
	 * 
	 * @author VSomalaraju-adm
	 * @param Payee Name and value to be passed
	 * @return flag
	 */
	public void inputInvalidTaxPaymentDetails(String payeeName, Map<String, String> invalidTaxDetails) {
		try {
			List<WebElement> selectList = lstTaxPayeeName.findElements(By.tagName("option"));
			int listCount = selectList.size();
			for (int taxPayeesCount = 1; taxPayeesCount <= listCount; taxPayeesCount++) {
				String listData = selectList.get(taxPayeesCount).getText();
				if (listData.contains(payeeName)) {
					selectList.get(taxPayeesCount).click();
					taxPayeeName = selectList.get(taxPayeesCount).getText();
					break;
				}
			}
			waits.waitUntilElementIsPresent(txtTaxPeriodEndDate);
			switch (payeeName) {
			case "CT":
				if (invalidTaxDetails.get("deliveryDate").equals("null"))
					webActions.clearValue(txtTaxPmtDeliveryDate);
				if (invalidTaxDetails.get("taxPeriodEndDate").equals("null"))
					webActions.clearValue(txtTaxPeriodEndDate);
				else {
					waits.waitUntilElementIsPresent(txtTaxPeriodEndDate);
					webActions.setValue(txtTaxPeriodEndDate, invalidTaxDetails.get("taxPeriodEndDate"));
				}
				if (invalidTaxDetails.get("taxAmount").equals("null"))
					webActions.clearValue(txtTaxAmount);
				else {
					waits.waitUntilElementIsPresent(txtTaxAmount);
					webActions.setValue(txtTaxAmount, invalidTaxDetails.get("taxAmount"));
				}
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputInvalidTaxPaymentDetails <---",
						"Entered tax end date { " + invalidTaxDetails.get("taxPeriodEndDate") + " } and tax amount { "
								+ invalidTaxDetails.get("taxAmount") + " } successfully");
				break;
			case "FED":
				if (invalidTaxDetails.get("deliveryDate").equals("null"))
					webActions.clearValue(txtTaxPmtDeliveryDate);
				if (invalidTaxDetails.get("taxPeriodEndDate").equals("null"))
					webActions.clearValue(txtTaxPeriodEndDate);
				else
					webActions.setValue(txtTaxPeriodEndDate, invalidTaxDetails.get("taxPeriodEndDate"));
				if (invalidTaxDetails.get("taxAmount").equals("null"))
					webActions.clearValue(txtTaxAmount);
				else {
					waits.waitUntilElementIsPresent(txtTaxAmount);
					webActions.setValue(txtTaxAmount, invalidTaxDetails.get("taxAmount"));
				}
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputInvalidTaxPaymentDetails <---",
						"Entered tax end date { " + invalidTaxDetails.get("taxPeriodEndDate") + " } and tax amount { "
								+ invalidTaxDetails.get("taxAmount") + " } successfully");
				break;
			case "RI":
				if (invalidTaxDetails.get("deliveryDate").equals("null"))
					webActions.clearValue(txtTaxPmtDeliveryDate);
				if (invalidTaxDetails.get("taxPeriodEndDate").equals("null"))
					webActions.clearValue(txtTaxPeriodEndDate);
				else
					webActions.setValue(txtTaxPeriodEndDate, invalidTaxDetails.get("taxPeriodEndDate"));
				if (invalidTaxDetails.get("taxAmount").equals("null"))
					webActions.clearValue(txtTaxAmount);
				else {
					waits.waitUntilElementIsPresent(txtTaxAmount);
					webActions.setValue(txtTaxAmount, invalidTaxDetails.get("taxAmount"));
				}
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputInvalidTaxPaymentDetails <---",
						"Entered tax end date { " + invalidTaxDetails.get("taxPeriodEndDate") + " } and tax amount { "
								+ invalidTaxDetails.get("taxAmount") + " } successfully");
				break;
			case "MA":
				if (invalidTaxDetails.get("deliveryDate").equals("null"))
					webActions.clearValue(txtTaxPmtDeliveryDate);
				if (invalidTaxDetails.get("taxPeriodEndDate").contentEquals("null"))
					webActions.clearValue(txtTaxPeriodEndDate);
				else
					webActions.setValue(txtTaxPeriodEndDate, invalidTaxDetails.get("taxPeriodEndDate"));
				if (invalidTaxDetails.get("taxAmount").contentEquals("null"))
					webActions.clearValue(txtTaxAmount);
				else {
					waits.waitUntilElementIsPresent(txtTaxAmount);
					webActions.setValue(txtTaxAmount, invalidTaxDetails.get("taxAmount"));
				}

				if (invalidTaxDetails.get("taxPayerName").contentEquals("null"))
					webActions.clearValue(txtTaxPayerName);
				else {
					waits.waitUntilElementIsPresent(txtTaxPayerName);
					webActions.setValue(txtTaxPayerName, invalidTaxDetails.get("taxPayerName"));
				}
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputInvalidTaxPaymentDetails <---",
						"Entered tax end date { " + invalidTaxDetails.get("deliveryDate") + " } , tax amount { "
								+ invalidTaxDetails.get("taxAmount") + " } and tax payer name { "
								+ invalidTaxDetails.get("taxPayerName") + " } successfully");
				break;
			case "NY":
				if (invalidTaxDetails.get("deliveryDate").equals("null"))
					webActions.clearValue(txtTaxPmtDeliveryDate);
				if (invalidTaxDetails.get("taxPeriodEndDate").contentEquals("null"))
					webActions.clearValue(txtTaxPeriodEndDate);
				else
					webActions.setValue(txtTaxPeriodEndDate, invalidTaxDetails.get("taxPeriodEndDate"));
				if (invalidTaxDetails.get("taxAmount").contentEquals("null"))
					webActions.clearValue(txtNyStateTaxAmount);
				else {
					waits.waitUntilElementIsPresent(txtNyStateTaxAmount);
					webActions.setValue(txtNyStateTaxAmount, invalidTaxDetails.get("taxAmount"));
				}
				if (invalidTaxDetails.get("taxPayerName").contentEquals("null"))
					webActions.clearValue(txtTaxPayerName);
				else {
					waits.waitUntilElementIsPresent(txtTaxPayerName);
					webActions.setValue(txtTaxPayerName, invalidTaxDetails.get("taxPayerName"));
				}
				if (invalidTaxDetails.get("accessCode").equals("null"))
					webActions.clearValue(txtTaxPmtAccessCode);
				else {
					waits.waitUntilElementIsPresent(txtTaxPmtAccessCode);
					webActions.setValue(txtTaxPmtAccessCode, invalidTaxDetails.get("accessCode"));
				}
				clickContinueTaxPayment();
				LogUtility.logInfo("---> inputInvalidTaxPaymentDetails <---",
						"Entered tax end date { " + invalidTaxDetails.get("taxPeriodEndDate") + " } , tax amount { "
								+ invalidTaxDetails.get("taxAmount") + " } and tax payer name { "
								+ invalidTaxDetails.get("taxPayerName") + " } successfully");
				break;

			default:
				LogUtility.logInfo(" Given Tax Payee { " + taxPayeeName + " }is Not Available");
			}
		} catch (Exception e) {
			LogUtility.logException("---> inputInvalidTaxPaymentDetails <---",
					"Unable to enter values in Tax payments Page", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Verify all error messages related to Tax Payment Page
	 * 
	 * @param delDateErrMsg
	 * @return
	 */
	public boolean verifyTaxPaymentsErrMsg(String errorMessage) {
		try {
			return wolWebUtil.verifyText(txtTaxPaymentErrMsg, errorMessage);
		} catch (Exception e) {
			LogUtility.logException("---> verifyDelDateErrMsg <---",
					"Unable to verify error mesage { " + errorMessage + " }", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Verify Tax Period End Date Error Message on Tax Payment Page
	 * 
	 * @param taxEndDtErrMsg
	 * @return
	 */
	public boolean verifyTaxEndDatetErrMsg(String taxEndDtErrMsg) {
		try {
			return wolWebUtil.verifyTextContains(txtTaxPaymentErrMsg, taxEndDtErrMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxEndDatetErrMsg <---",
					" { " + taxEndDtErrMsg + " } error message is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	public boolean verifyTaxEndDateErrMsgFor10YearsBefore(String taxEndDateErrMsg) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date currentDate = (Date) dateFormat.parse(wolWebUtil.getCurrentDate());
			Calendar cal = Calendar.getInstance();
			cal.setTime(currentDate);
			cal.add(Calendar.YEAR, -10);
			Date currentDateMinus10 = cal.getTime();
			taxEndDateErrMsgFor10YearsBefore = taxEndDateErrMsg.replace("{Value to Replace}",
					dateFormat.format(currentDateMinus10).toString());
			return wolWebUtil.verifyTextContains(txtTaxPaymentErrMsg, taxEndDateErrMsgFor10YearsBefore);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxEndDateByWrongDate <---", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * Verify Tax amount field error message on Tax Payment Page
	 * 
	 * @param taxAmountErrMsg
	 * @return
	 */
	public boolean verifyTaxAmountErrMsg(String taxAmountErrMsg) {
		try {
			return wolWebUtil.verifyText(txtTaxPaymentErrMsg, taxAmountErrMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxAmountErrMsg <---",
					"Tax amount error message { " + taxAmountErrMsg + " } is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * Verify Tax Amount Error Message while provide Huge amount
	 * 
	 * @author VSomalaraju-adm
	 * @param taxAmountErrMsg
	 * @return
	 */
	public boolean verifyTaxAmountErrMsgForHugeAmount(String taxAmountErrMsg) {
		try {
			taxAmountErrMsgForHugeAmount = taxAmountErrMsg.replace("{ValueToReplace}", taxPayeeName);
			return wolWebUtil.verifyText(txtTaxPaymentErrMsg, taxAmountErrMsgForHugeAmount);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxAmountErrMsgForHugeAmount <---",
					"Tax amount error message { " + taxAmountErrMsg + " } is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * Verify Tax Payer Name Error Message
	 * 
	 * @author VSomalaraju-adm
	 * @param taxPayerNameErrMsg
	 * @return
	 */
	public boolean verifyTaxPayerNameErrMsg(String taxPayerNameErrMsg) {
		try {
			return wolWebUtil.verifyText(txtTaxPaymentErrMsg, taxPayerNameErrMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxPayerNameErrMsg <---",
					" Tax payer error message { " + taxPayerNameErrMsg + " } is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * Verify Tax Access code Error Message for NY State
	 * 
	 * @param taxPayerNameErrMsg
	 * @return
	 */
	public boolean verifyAccessCodeErrMsg(String accessCodeErrMsg) {
		try {
			return wolWebUtil.verifyText(txtTaxPaymentErrMsg, accessCodeErrMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyAccessCodeErrMsg <---",
					"Access code error message { " + accessCodeErrMsg + " } is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * Select account from the drop down for Tax Payments
	 * 
	 * @param lstSelectAccount
	 */
	public boolean selectAccountForTaxPayment(String lstSelectAccount) {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(lstSelectFromAccount);
			if (selectAccount) {
				wolWebUtil.selectValueByPartialVisibleText(lstSelectFromAccount, lstSelectAccount);
				LogUtility.logInfo("---> selectAccountForTaxPayment <---",
						"User Successfully selected acount : " + lstSelectAccount + " : from the dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> selectAccountForTaxPayment <---",
					" { " + lstSelectAccount + " } is not selected from the drop down", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify Tax Payment error message no payees
	 * 
	 * @param verNoPayeeErrMsg
	 * @return
	 */
	public boolean verifyNoTaxPayeeErrorMessage(String verNoPayeeErrMsg) {
		try {
			return wolWebUtil.verifyTextContains(txtNoPayeeErrMsg, verNoPayeeErrMsg);
		} catch (Exception e) {
			LogUtility.logException("---> verifyAccessCodeErrMsg <---",
					"Error message { " + verNoPayeeErrMsg + " } is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify tax period End date error messages for invalid dates
	 * 
	 * @param errDetails
	 * @return
	 * @throws Throwable
	 */
	public boolean verifyTaxEndDateErrMsgForWrongDate() throws Throwable {
		boolean flag = false;
		try {
			String newDateValueToreplace = wolWebUtil
					.dateAddorSubstract(jsonDataParser.getTestDataMap().get("yearstoAddSub"));
			String taxEndDateErrMsg = jsonDataParser.getTestDataMap().get("ErrorMessage");
			taxEndDateErrMsgForWrongDate = taxEndDateErrMsg.replace("{Value to Replace}", newDateValueToreplace);
			flag = wolWebUtil.verifyTextContains(txtTaxPaymentErrMsg, taxEndDateErrMsgForWrongDate);
		} catch (Exception e) {
			LogUtility.logException("---> verifyTaxEndDateErrMsgForWrongDate <---", " Error message is not displayed",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Used for fetch the given details in confirmation page
	 * 
	 * @throws Throwable
	 */
	public void getGivenTaxPaymentValues() throws Throwable {
		try {
			taxPmtEnteredValue = new LinkedHashMap<String, String>();
			taxPmtEnteredValue.put("Payee Name", wolWebUtil.getDefaultValueForSelect(lstTaxPayeeName));
			taxPmtEnteredValue.put("Delivery Date", webActions.getText(txtTaxPmtDeliveryDate));
			taxPmtEnteredValue.put("Tax Period End Date", webActions.getText(txtTaxPeriodEndDate));
			taxPmtEnteredValue.put("Tax Amount", webActions.getText(txtTaxAmount));
			LogUtility.logInfo("getGivenTaxPaymentValues", "Retrieved given value successfully");
		} catch (Exception e) {
			LogUtility.logException("---> getGivenTaxPaymentValue <---", "Failed to retrieve  provoded values", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Verify confirmation details values
	 * 
	 */
	public void getTaxPaymentConfirmDetails() {
		try {
			confirmTaxDetails = new LinkedHashMap<String, String>();
			for (int taxConfirmDetails = 0; taxConfirmDetails < taxConfirmLabels.size(); taxConfirmDetails++)
				confirmTaxDetails.put((taxConfirmLabels).get(taxConfirmDetails).getText(),
						taxConfirmValues.get(taxConfirmDetails).getText());
			LogUtility.logInfo("getTaxPaymentConfirmDetails", "Retrieved all the Tax Confirmation details");
		} catch (Exception e) {
			LogUtility.logException("--->getTransferCnfrmDetails<---", "Failed to get the tax amount value", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Verify Tax Payment Confirmation Details in Tax Payment Confirmation details
	 * 
	 * @author VSomalaraju-adm
	 * @param confirmationDetails
	 */
	public boolean verifyTaxPaymentConfirmationDetails() {
		try {
			return wolWebUtil.mapValuesComaparison(taxPmtEnteredValue, confirmTaxDetails);
		} catch (Exception e) {
			LogUtility.logException("--->verifyTaxPaymentConfirmationDetails<---",
					" Failed to verify confirmation details", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	public void selectTaxPayeeName(String taxPayeeName) {
		try {
			List<WebElement> selectList = lstTaxPayeeName.findElements(By.tagName("option"));
			int listCount = selectList.size();
			for (int taxPayeeCount = 1; taxPayeeCount <= listCount; taxPayeeCount++) {
				String listData = selectList.get(taxPayeeCount).getText();
				if (listData.contains(taxPayeeName)) {
					selectList.get(taxPayeeCount).click();
					break;
				}
			}
			LogUtility.logInfo("---> selectTaxPayeeName <---",
					"Selected : " + taxPayeeName + " : from the list successfully");
		} catch (Exception e) {
			LogUtility.logException("---> selectTaxPayeeName <---", "Unable to select payeename from the list", e,
					LoggingLevel.ERROR, true);
		}
	}

	public void clickTaxEndDateCalender() {
		try {
			webActions.clickElement(taxEndDateCalWidget);
			LogUtility.logInfo("---> clickTaxEndDateCalender <---",
					"Successfully clicked on Tax End Date Calender Widget");
		} catch (Exception e) {
			LogUtility.logException("---> clickTaxEndDateCalender <---",
					"Failed to click on calender widget next to tax end date", e, LoggingLevel.ERROR, true);
		}
	}

	public void getCurrentMonthName() {
		try {
			Format formatter = new SimpleDateFormat("MMMM");
			currentMonthName = formatter.format(new Date());
			LogUtility.logInfo("---> getCurrentMonthName <---",
					"Retrieved current month from the system : " + currentMonthName + ": ");
		} catch (Exception e) {
			LogUtility.logException("---> getCurrentMonthName <---", "Not able to get current month name", e,
					LoggingLevel.ERROR, true);
		}
	}

	public void getMonthNameFromCalenderWidget() {
		try {
			calWidgetMonthName = webActions.getText(calWidgetMonth);
			LogUtility.logInfo("---> getMonthNameFromCalenderWidget ---<",
					"Retrieved month name: " + calWidgetMonthName + " : from calender widget");
		} catch (Exception e) {
			LogUtility.logException("---> getMonthNameFromCalenderWidget <---", "not able to get current month name", e,
					LoggingLevel.ERROR, true);
		}
	}

	public void enterTaxPeriodEndDate(String taxEndDate) {
		try {
			webActions.setValue(txtTaxPeriodEndDate, taxEndDate);
			LogUtility.logInfo("---> enterTaxPeriodEndDate <---", "Tax period end date entered successfully");
		} catch (Exception e) {
			LogUtility.logException("---> enterTaxPeriodEndDate <---",
					"Unable to enter tax period end date in tax payments page", e, LoggingLevel.ERROR, true);
		}
	}

	public boolean compareGivenMonthWithWidgetMonth(String month) {
		boolean flag = false;
		try {
			if (calWidgetMonthName.contains(month))
				LogUtility.logInfo("---> compareGivenMonthWithWidgetMonth <---",
						"Calender widget months are compared successfully");
			return flag = true;
		} catch (Exception e) {
			LogUtility.logException("---> compareGivenMonthWithWidgetMonth <---",
					"Calender widget months Comparison failed", e, LoggingLevel.ERROR, true);
			return flag;
		}
	}

	public boolean compareTaxEndDateCurrnetMonths() {
		boolean flag = false;
		try {
			if (calWidgetMonthName.contains(currentMonthName))
				LogUtility.logInfo("---> compareTaxEndDateCurrnetMonths <---",
						"Calender widget months compared successfully");
			return flag = true;
		} catch (Exception e) {
			LogUtility.logException("---> compareTaxEndDateCurrnetMonths <---", "Calender widget months Comparison failed",
					e, LoggingLevel.ERROR, true);
			return flag;
		}

	}
}
