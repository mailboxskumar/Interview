
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class PendingPaymentsPage extends ObjectBase {

	List<String> confirmationList = new ArrayList<>();
	public String confirmationNumber = "";

	public PendingPaymentsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[contains(@data-wbst-message-key,'eu.deletepayment') ]")
	protected WebElement pageTitledeletePayment;

	@FindBy(css = "div.pageHeaderBlock > h3")
	protected WebElement pageTitlePendingPayment;

//	@FindAll(@FindBy(xpath = "//table[@class='table_bg']//tr//a/ancestor::tr[contains(@class,'table_row')]"))
	@FindAll(@FindBy(css = "table > tbody > tr:not([class='table_row_alternate_bold'])"))

	protected List<WebElement> pendingPaymentList;

	@FindBy(id = "focusAction")
	protected WebElement btnDelete;

	/**
	 * To check the page Title in Pending Payment Functionality
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param pageHeading
	 * @return
	 */
	public boolean checkPageTitleForPendingPayment(String pageHeading) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(pageTitlePendingPayment, 3);
			if (wolWebUtil.verifyText(pageTitlePendingPayment, pageHeading)) {
				LogUtility.logInfo("---> checkPageTitleForPendingPayment <---",
						"Heading verified Successfully " + pageHeading);
				return true;
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logError("--->checkPageTitleForPendingPayment<---", e.getMessage());
			return false;
		}
	}

	/**
	 * To check the page Title in Pending Payment Functionality
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param pageHeading
	 * @return
	 */
	public boolean deletePendingPayments(boolean deleteorNot, String dataTypeFromMap) {
		boolean status = false;
		try {

			if (confirmationNumber.equalsIgnoreCase("") && !dataTypeFromMap.equals("")) {
				confirmationNumber = getValueFromRuntimeDataMap(dataTypeFromMap);
			}
			for (String eachConfirmNumber : confirmationNumber.split(",")) {
				for (int i = 0; i < pendingPaymentList.size(); i++) {
					String actConfimNumber = pendingPaymentList.get(i).findElement(By.cssSelector("td:nth-child(4)"))
							.getText();
					if (actConfimNumber.contains(eachConfirmNumber) && !eachConfirmNumber.equals("")) {
						if (deleteorNot) {
							webActions.clickElement(pendingPaymentList.get(i).findElement(By.tagName("img")));
							status = true;
							LogUtility.logInfo("---> deletePendingPayments <---", "Clicked on delete pending payment");
							break;
						} else {
							LogUtility.logInfo("---> deletePendingPayments <---",
									"Found the pending payment with confirmation number " + eachConfirmNumber);
							status = true;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->deletePendingPayments<---", e.getMessage());
		}
		return status;
	}

	/**
	 * To check the page Title in delete pending Payment Functionality
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param pageHeading
	 * @return
	 */
	public boolean checkTitleForDeletePendingPayment(String pageHeading) {
		try {
			waits.waitUntilElementIsPresent(pageTitledeletePayment, 4);
			if (wolWebUtil.verifyText(pageTitledeletePayment, pageHeading)) {
				LogUtility.logInfo("---> checkTitleForDeletePendingPayment <---",
						"Heading verified Successfully " + pageHeading);
				return true;
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logError("--->checkTitleForDeletePendingPayment<---", e.getMessage());
			return false;
		}
	}

	/**
	 * To click on the button
	 * 
	 * @Author:Sneha K
	 * @Created on: May 7th 2019
	 * @Modified on:
	 * @param btnName
	 * @return
	 */
	public void clickOnButton(String btnName) {
		try {
			WebElement eleToClick = null;
			switch (btnName) {
			case "Delete":
				eleToClick = btnDelete;
				break;
			default:
				LogUtility.logInfo("---> checkTitleForDeletePendingPayment <---", "Invalid button Name");
				break;
			}
			webActions.clickElement(eleToClick);
			waits.waitForPageToLoad(3);

			LogUtility.logInfo("---> checkTitleForDeletePendingPayment <---", "Clicked on the button " + btnName);

		} catch (Exception e) {
			LogUtility.logError("--->checkTitleForDeletePendingPayment<---", e.getMessage());
		}
	}

}
