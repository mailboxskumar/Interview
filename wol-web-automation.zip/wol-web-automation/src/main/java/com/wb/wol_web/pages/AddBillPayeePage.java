
package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class AddBillPayeePage extends ObjectBase {

	public LinkedHashMap<String, String> confirmDetails;
	public String address;
	public String acctNum;

	public AddBillPayeePage() {
		PageFactory.initElements(driver, this);
	}

	@FindAll(@FindBy(xpath = "//span[@id='div_edit_address']/preceding-sibling::div[@class='dataRow']/label[not(@style)]"))
	protected List<WebElement> lstEPayeeCol;

	@FindAll(@FindBy(xpath = "//span[@id='div_edit_address']//div[@class='dataRow']/label"))
	protected List<WebElement> lstCPayeeCol;

	@FindBy(xpath = "//*[contains(@id,'ConfirmAccountNumber__error-message-text')]")
	private WebElement txtCnfrmAcctNumErr;

	@FindBy(xpath = "//*[contains(@id,'paymentAccountNumber__error-message-text')]")
	private WebElement txtAcctNumErr;

	@FindBy(xpath = "//*[contains(@id,'AddressLine1__error-message-text')]")
	private WebElement txtAddrOneErr;

	@FindBy(xpath = "//*[contains(@id,'City__error-message-text')]")
	private WebElement txtCityErr;

	@FindBy(xpath = "//*[contains(@id,'State__error-message-text')]")
	private WebElement txtStateErr;

	@FindBy(xpath = "//*[contains(@id,'ZipCode__error-message-text')]")
	private WebElement txtZipErr;

	@FindBy(xpath = "//*[contains(@id,'service__error__unableToValidateAccount__body')]")
	private WebElement txtPayeeLightBoxErr;

	@FindBy(id = "payeeName__label")
	private WebElement txtPayeeNameLbl;

	@FindBy(xpath = "//div[@id='lightBoxContent3']//label[contains(text(),'Narrow Down by Address')]")
	private WebElement txtAddressMorelblLightBox;

	@FindBy(xpath = "//*[contains(text(),'Narrow Down by Address')]")
	private WebElement txtAddressMoreLbl;

	@FindAll({ @FindBy(id = "transactionCancelMessage"), @FindBy(id = "cancelBoxText") })
	private WebElement txtLghtBoxCancelMsg;

	@FindBy(id = "cancelBoxText")
	private WebElement txtLghtBoxCancelMsgManage;

	@FindBy(xpath = "//div[@id='lightBoxContent3']//*[@id='addressChooser__label']")
	private WebElement txtLghtBoxAddressMsg;

	@FindBy(xpath = "//*[contains(text(),'Payee Address')]")
	private WebElement txtAddressLbl;

	@FindBy(xpath = "//*[contains(@id,'pageTitle')]")
	public WebElement txtTitleAddNewPayee;

	@FindBy(xpath = "//*[contains(@id,'confirmation__pageAffirmativeNotice__body')]")
	private WebElement txtConfrmMsg;

	@FindBy(css = "#page_title")
	private WebElement txtPageTitle;

	@FindBy(css = "#brochure_message span")
	private WebElement txtCnfrmMsgDeletePayee;

	@FindBy(id = "text_accno")
	private WebElement txtUpdateAcctNum;

	@FindBy(xpath = "//*[contains(@id,'add-payee-verification__pageTitle')]")
	private WebElement txtAddVerficationPayee;

	@FindBy(xpath = "//*[contains(@id,'browsePayeesSection__tabSection')]")
	private WebElement lnkTab;

	@FindBy(xpath = "//*[contains(@id,'browsePayeesSection__contentSection')]")
	private WebElement lnkSection;

	@FindBy(xpath = "//*[@id='payeeName__input' and @class=' input']")
	private WebElement txtPayeeName;

	@FindBy(xpath = "//a[contains(text(),'Browse Available Payees')]")
	private WebElement lnkBrowsePayee;

	@FindBy(xpath = "//*[@id='submit_button__buttonText']")
	private WebElement btnContinuel;

	@FindBy(id = "addressChooser__label")
	private WebElement txtAddressLabel;

	@FindBy(xpath = "//*[contains(text(),'Continue')]")
	private WebElement btnContinue;

	@FindAll({ @FindBy(id = "button_cancel"), @FindBy(id = "cancel") })
	private WebElement btnCancel;

	@FindBy(xpath = "//*[contains(text(),'Edit')]")
	private WebElement btnEdit;

	@FindAll({ @FindBy(id = "doNotCancelButton"), @FindBy(id = "cancelNoBtn") })
	private WebElement btnNo;

	@FindAll({ @FindBy(id = "cancelYesBtn"), @FindBy(id = "confirmCancelButton") })
	private WebElement btnYes;

	@FindBy(xpath = "//input[contains(@id,'noAccountNumber__option1__input')]")
	private WebElement chkNoAcctNum;

	@FindBy(xpath = "//input[contains(@id,'AccountNumber__input')]")
	private WebElement txtPayeeAcctNum;

	@FindBy(xpath = "//input[contains(@id,'AccountNumberConfirm__input') or contains(@id,'ConfirmAccountNumber__input')]")
	private WebElement txtPayeeCnfrmAcctNum;

	@FindBy(xpath = "//input[contains(@id,'payeeNickname__input')]")
	private WebElement txtPayeeNickName;

	@FindBy(xpath = "//input[contains(@id,'shortList__option--Y__input')]")
	private WebElement rdbtnShortListY;

	@FindBy(xpath = "//input[contains(@id,'shortList__option--N__input')]")
	private WebElement rdbtnShortListN;

	@FindBy(xpath = "//input[contains(@id,'payeeDesignationType__option--P__input') or contains(@id,'payeeType__option--P__input')]")
	private WebElement rdbtnPayeeTypePer;

	@FindBy(xpath = "//input[contains(@id,'payeeDesignationType__option--B__input') or contains(@id,'payeeType__option--B__input')]")
	private WebElement rdbtnPayeeTypeBus;

	@FindBy(xpath = "//*[contains(@id,'payeeAddressLine1__input')]")
	private WebElement txtPayeeAdrss1;

	@FindBy(xpath = "//*[contains(@id,'payeeAddressLine2__input')]")
	private WebElement txtPayeeAdrss2;

	@FindBy(xpath = "//*[contains(@id,'payeeCity__input')]")
	private WebElement txtPayeeCity;

	@FindBy(xpath = "//*[contains(@id,'payeeState__input')]")
	private WebElement lstPayeeState;

	@FindBy(xpath = "//*[contains(@id,'payeeZipCode__input')]")
	private WebElement txtPayeeZip;

	@FindBy(xpath = "//input[contains(@id,'disclosure__input')]")
	private WebElement chkPayeeDisc;

	@FindBy(xpath = "//*[contains(@id,'payeeName__display')]")
	private WebElement txtDisPayeeName;

	@FindBy(xpath = "//*[contains(@id,'selectPayeeAddressSubmit__buttonText')]")
	private WebElement btnPayeeAddress;

	@FindBy(xpath = "(//input[contains(@id,'addressChooser__option')])[1]")
	private WebElement rdbtnPayeeAddress;

	@FindBy(xpath = "//*[@id = 'payeeType__label']")
	private WebElement lblPayeeType;

	@FindBy(id = "managePayees_table__filter__input")
	private WebElement lstShowOnly;

	@FindBy(id = "managePayees_table__filterByText__input")
	private WebElement txtPayeeSearch;

	@FindBy(xpath = "(//li[@data-mm-hidden='false']//a)[1]")
	private WebElement imgEdit;

	@FindBy(id = "text_nick")
	private WebElement txtNickName;

	@FindBy(css = "[value*=Delete]")
	private WebElement btnDelete;

	@FindBy(css = "input[value*=Continue]")
	private WebElement btnContinueUpdate;

	@FindBy(id = "addPayee")
	private WebElement lnkAddPayee;

	@FindBy(xpath = "//section[@id='confirmationFormSection']//span//span")
	protected List<WebElement> txtCnfrmValues;

	@FindBy(xpath = "//section[@id='confirmationFormSection']//label")
	protected List<WebElement> txtCnfrmLabels;

	@FindBy(xpath = "//span[@id='payeeAddressDisplay__display']//span")
	protected WebElement txtAddressValue;

	/**
	 * updateAcctNum:To Update Account number
	 * 
	 * @param acctNum
	 */
	public boolean updateAcctNum(String acctNum) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtUpdateAcctNum);
			webActions.setValue(txtUpdateAcctNum, acctNum);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtUpdateAcctNum, "value").equalsIgnoreCase(acctNum)) {
				flag = true;
				LogUtility.logInfo("updateAcctNum", "Updated Account Number");
			} else
				LogUtility.logError("updateAcctNum", "Failed to Update Account Number");
		} catch (Exception e) {
			LogUtility.logException("updateAcctNum", "Failed to Update Account Number", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the page title among the Update Payee page
	 * 
	 * @param pageTitle
	 * @return
	 */
	public boolean verifyUpdtPayeePageTitle(String pageTitle) {
		try {
			return wolWebUtil.verifyText(txtPageTitle, pageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyUpdtPayeePageTitle", "Failed to verify the Page Title", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To click on Add Payee link in Manage Payees page
	 */
	public boolean clickAddPayee() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkAddPayee);
			webActions.clickElement(lnkAddPayee);
			if (waits.waitUntilElementIsPresent(lnkBrowsePayee)) {
				flag = true;
				LogUtility.logInfo("clickAddPayee", "Clicked on Add Payee Link");
			} else
				LogUtility.logError("clickAddPayee", "Failed to Click on Add Payee Link");
		} catch (Exception e) {
			LogUtility.logException("clickAddPayee", "Failed to Click on Add Payee Link", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Update nick name for a payee in Update payee details page
	 */
	public boolean updateNickname() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtNickName);
			String nickName = wolWebUtil.getRandomString(5);
			webActions.setValue(txtNickName, nickName);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtNickName, "value").equalsIgnoreCase(nickName)) {
				flag = true;
				LogUtility.logInfo("updateNickname", "Updated nick name for a payee in update payee details page");
			} else
				LogUtility.logError("updateNickname",
						"Failed to Update nick name for a payee in update payee details page");
		} catch (Exception e) {
			LogUtility.logException("updateNickname",
					"Failed to Update nick name for a payee in update payee details page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on Delete Button in Update Payee details page
	 */
	public void clickDeleteButton() {
		try {
			waits.waitUntilElementIsPresent(btnDelete);
			webActions.clickElement(btnDelete);
			waits.staticWait(3);
			LogUtility.logInfo("clickDeleteButton", "Clicked on Delete Button");
		} catch (Exception e) {
			LogUtility.logException("clickDeleteButton", "Failed to Click on Delete Button", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * To click on continue Button in Update Payee details page
	 */
	public void clickUpdateButton() {
		try {
			waits.waitUntilElementIsPresent(btnContinueUpdate);
			webActions.clickElement(btnContinueUpdate);
			waits.staticWait(3);
			LogUtility.logInfo("clickUpdateButton", "Clicked on Continue Button");
		} catch (Exception e) {
			LogUtility.logException("clickUpdateButton", "Failed to Click on Continue Button", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}

	}

	/**
	 * To click on Edit icon to update required payee in manage payees page
	 * 
	 * @param payeeType
	 */
	public boolean clickEditIcon(String payeeType) {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(imgEdit, maxTimeOut);
			switch (payeeType) {
			case "Electronic":
				webActions.selectDropDownByText(lstShowOnly, payeeType);
				break;
			case "Check":
				webActions.selectDropDownByText(lstShowOnly, payeeType);
				break;
			case "Tax":
				webActions.setValue(txtPayeeSearch, payeeType);
				break;
			default:
				webActions.setValue(txtPayeeSearch, payeeType);
				break;
			}
			waits.staticWait(3);
			webActions.clickElementJS(imgEdit);
			waits.waitForPageToLoad(maxTimeOut);
			if (waits.waitUntilElementIsPresent(txtNickName)) {
				flag = true;
				LogUtility.logInfo("clickEditIcon", "Clicked on Edit icon");
			} else
				LogUtility.logError("clickEditIcon", "Failed to Click on Edit icon");
		} catch (Exception e) {
			LogUtility.logException("clickEditIcon", "Failed to Click on Edit icon", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on Pay from Account label for validating tooltip text of label
	 */
	public void clickPayFromLabel() {
		try {
			waits.waitUntilElementIsPresent(lblPayeeType);
			webActions.clickElement(lblPayeeType);
			LogUtility.logInfo("clickPayFromLabel", "Clicked on Pay From Account Label");
		} catch (Exception e) {
			LogUtility.logException("clickPayFromLabel", "Failed to Click on Pay From Account Label", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Validating text displayed in tooltip of Pay From Accounts in Add A New Payee
	 * Page
	 * 
	 * @param tooltipContent
	 * @return
	 */
	public boolean verifyTooltip(String tooltipContent) {
		try {
			waits.waitUntilElementIsPresent(lblPayeeType);
			String displayContent = webActions.getAttributeValue(lblPayeeType, "data-title");
			if (displayContent.contains(tooltipContent)) {
				LogUtility.logInfo("verifyTooltip",
						"The Tooltip Pay From Which Accounts content is displaying properly");
				return true;
			} else {
				LogUtility.logError("verifyTooltip",
						"The Tooltip Pay From Which Accounts content is not displaying properly");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTooltip",
					"The Tooltip Pay From Which Accounts content is not displaying properly", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Click on Select Address button in Add a New Payee Page
	 */
	public boolean clickSelectAddress() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnPayeeAddress);
			webActions.clickElement(btnPayeeAddress);
			waits.staticWait(3); // To Load Lightbox taking time
			if (waits.waitUntilElementIsPresent(rdbtnPayeeAddress)) {
				flag = true;
				LogUtility.logInfo("clickSelectAddress", "Clicked on Select Address Button");
			} else
				LogUtility.logError("clickSelectAddress", "Failed to Click on Select Address Button");
		} catch (Exception e) {
			LogUtility.logException("clickSelectAddress", "Failed to Click on Select Address Button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Select address for a Payee in a Lightbox
	 */
	public void selectPayeeAddress() {
		try {
			waits.waitUntilElementIsPresent(rdbtnPayeeAddress);
			webActions.clickElement(rdbtnPayeeAddress);
			LogUtility.logInfo("selectPayeeAddress", "Select address for a Payee");
		} catch (Exception e) {
			LogUtility.logException("selectPayeeAddress", "Failed to Select address for a Payee", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * Entering payee name to add a check payee
	 * 
	 * @param payeeName
	 */
	public boolean enterPayeeName(String payeeName) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtPayeeName);
			webActions.setValue(txtPayeeName, payeeName);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtPayeeName, "value").equalsIgnoreCase(payeeName)) {
				flag = true;
				LogUtility.logInfo("enterPayeeName", "Entered Payee Name");
			} else
				LogUtility.logError("enterPayeeName", "Failed to Enter Payee Name");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeName", "Failed to Enter Payee Name", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Updating Payee name in a Add a New Payee Page
	 * 
	 * @param payeeName
	 */
	public boolean reEnterPayeeName(String payeeName) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtPayeeName);
			webActions.setValue(txtPayeeName, payeeName);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtPayeeName, "value").equalsIgnoreCase(payeeName)) {
				flag = true;
				LogUtility.logInfo("reEnterPayeeName", "Re-Entered Payee Name");
			} else
				LogUtility.logError("reEnterPayeeName", "Failed to Re-Enter Payee Name");
		} catch (Exception e) {
			LogUtility.logException("reEnterPayeeName", "Failed to Re-Enter Payee Name", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on Browse Available Payees link
	 */
	public boolean clickAvailablePayees() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkBrowsePayee, maxTimeOut);
			webActions.clickElement(lnkBrowsePayee);
			if (waits.waitUntilElementIsPresent(lnkTab)) {
				flag = true;
				LogUtility.logInfo("clickAvailablePayees", "Clicked on Browse Available Payees link");
			} else
				LogUtility.logError("clickAvailablePayees", "Failed to Click on Browse Available Payees link");
		} catch (Exception e) {
			LogUtility.logException("clickAvailablePayees", "Failed to Click on Browse Available Payees link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on required Payee name link to add a new payee
	 * 
	 * @param payeeName
	 * @throws InterruptedException
	 */
	public void clickPayeeName(String payeeName) throws InterruptedException {

		char first = payeeName.charAt(0);
		List<WebElement> charlist = lnkTab.findElements(By.tagName("a"));
		try {
			for (WebElement c : charlist) {
				if (first == 'P') {
					webActions.clickElementJS(driver.findElement(By.id("payeeCharactersLink_P")));
					break;
				} else if (first == webActions.getText(c).charAt(0)) {
					webActions.clickElement(c);
					break;
				}
			}
			waits.staticWait(2);
			List<WebElement> linkList = lnkSection.findElements(By.tagName("a"));
			for (WebElement linkname : linkList) {
				if (payeeName.equalsIgnoreCase(webActions.getText(linkname))) {
					webActions.clickElementJS(linkname);
					break;
				}
			}
			LogUtility.logInfo("clickPayeeName", "Clicked on Payee Name: " + payeeName + " link");
		} catch (Exception e) {
			LogUtility.logException("clickPayeeName", "Failed to Click on Payee Name Link", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * To Enter Payee Account Number from feature file in a Add a New Payee Page
	 * 
	 * @param acctNum
	 */
	public boolean enterPayeeAcctNum(String acctNum) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtPayeeAcctNum);
			webActions.setValue(txtPayeeAcctNum, acctNum);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtPayeeAcctNum, "value").equalsIgnoreCase(acctNum)) {
				flag = true;
				LogUtility.logInfo("enterPayeeAcctNum", "Entered Payee Account Number");
			} else
				LogUtility.logError("enterPayeeAcctNum", "Failed to Enter Payee Account Number");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeAcctNum", "Failed to Enter Payee Account Number", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To Enter Payee confirm Account number from feature file in a Add a New Payee
	 * Page
	 * 
	 * @param cnfrmAcctNum
	 */
	public void enterCnfrmPayeeAcctNum(String cnfrmAcctNum) {
		try {
			waits.waitUntilElementIsPresent(txtPayeeCnfrmAcctNum);
			webActions.setValue(txtPayeeCnfrmAcctNum, cnfrmAcctNum);
			LogUtility.logInfo("enterCnfrmPayeeAcctNum", "Entered Payee Confirm Account Number");
		} catch (Exception e) {
			LogUtility.logException("enterCnfrmPayeeAcctNum", "Failed to Enter Payee Confirm Account Number", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To Enter Payee Account & Re enter confirm account numbers based on the payee
	 * name given in feature file
	 * 
	 * @throws InterruptedException
	 */
	public boolean enterPayeeAcctDetails() throws InterruptedException {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtPayeeAcctNum);
			String payee = null;
			if (waits.waitUntilElementIsPresent(txtDisPayeeName) == true) {

				payee = webActions.getText(txtDisPayeeName);
			} else if (waits.waitUntilElementIsPresent(txtPayeeName) == true) {
				payee = webActions.getAttributeValue(txtPayeeName, "value");
			}
			switch (payee) {
			case "Connecticut Natural Gas":
				webActions.setValue(txtPayeeAcctNum, wolWebUtil.getRandomNumber(10));
				break;
			case "Comcast":
				webActions.setValue(txtPayeeAcctNum, getTestProperty("Comcast") + wolWebUtil.getRandomNumber(10));
				break;
			case "Walmart":
				webActions.setValue(txtPayeeAcctNum, getTestProperty("Walmart") + wolWebUtil.getRandomNumber(10));
				break;
			case "Capital One":
				webActions.setValue(txtPayeeAcctNum, getTestProperty("CapitalOne") + wolWebUtil.getRandomNumber(10));
				break;
			case "Verizon":
				webActions.setValue(txtPayeeAcctNum, getTestProperty("Verizon") + wolWebUtil.getRandomNumber(16));
				break;
			case "PFS Financing Corporation":
				webActions.setValue(txtPayeeAcctNum, wolWebUtil.getRandomNumber(14));
				break;
			case "Webster Safe Deposit":
				webActions.setValue(txtPayeeAcctNum, wolWebUtil.getRandomNumber(10));
				break;
			default:
				webActions.setValue(txtPayeeAcctNum, wolWebUtil.getRandomNumber(10));
				break;
			}
			waits.staticWait(1);
			acctNum = webActions.getAttributeValue(txtPayeeAcctNum, "value");
			if (!acctNum.isEmpty())
				flag = true;
			webActions.setValue(txtPayeeCnfrmAcctNum, acctNum);
			LogUtility.logInfo("enterPayeeAcctDetails", "Entered Payee Account Details");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeAcctDetails", "Failed to Enter Payee Account Details", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter nick name in Add a New Payee page
	 */
	public void enterPayeeNick() {
		try {
			waits.waitUntilElementIsPresent(txtPayeeNickName);
			webActions.setValue(txtPayeeNickName, wolWebUtil.getRandomString(5));
			LogUtility.logInfo("enterPayeeNick", "Entered Nick Name");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeNick", "Failed to Enter Payee Nick Name", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To select Shortlist yes/No to add a new payee
	 * 
	 * @param Shortlist
	 */
	public void selectPayeeshortlist(String Shortlist) {
		try {
			waits.waitUntilElementIsPresent(rdbtnShortListY);
			if (Shortlist == "yes")
				webActions.clickElement(rdbtnShortListY);
			else
				webActions.clickElement(rdbtnShortListN);
			LogUtility.logInfo("selectPayeeshortlist", "Selected short list value");
		} catch (Exception e) {
			LogUtility.logException("selectPayeeshortlist", "Failed to Select short list value", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * To Select Pay From account to add a new payee for a comingled user
	 * 
	 * @param PayeeFrom
	 */
	public void selectPayeeFrom(String PayeeFrom) {
		try {
			waits.waitUntilElementIsPresent(rdbtnPayeeTypeBus);
			if (waits.waitUntilElementIsPresent(rdbtnPayeeTypeBus) == true) {
				if (PayeeFrom == "Personal")
					webActions.clickElement(rdbtnPayeeTypePer);
				else
					webActions.clickElement(rdbtnPayeeTypeBus);
			}
			LogUtility.logInfo("selectPayeeFrom", "Selected Pay From Which Account value" + PayeeFrom);
		} catch (Exception e) {
			LogUtility.logException("selectPayeeFrom", "Failed to Select Pay From Which Account value", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To Click On Coninue button
	 * 
	 * @throws InterruptedException
	 */
	public void clickContinueButton() throws InterruptedException {
		try {
			wolWebUtil.clickWebElement(btnContinue, "clickContinueButton");
			LogUtility.logInfo("clickContinueButton", "Clicked on Continue Button");
		} catch (Exception e) {
			LogUtility.logException("selectPayeeFrom", "Failed to Click on Continue Button", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * To Click On Coninue button
	 * 
	 * @throws InterruptedException
	 */
	public void clickContinueButtonLightBox() throws InterruptedException {
		try {
			wolWebUtil.clickWebElement(btnContinuel, "clickContinueButton");
			LogUtility.logInfo("clickContinueButtonLightBox", "Clicked on Continue Button in a Light box");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButtonLightBox", "Failed to Click on Continue Button in a Light box",
					e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * To click on Cancel Button
	 * 
	 * @throws InterruptedException
	 */
	public boolean clickCancelButton() throws InterruptedException {
		boolean flag = true;
		try {
			wolWebUtil.clickWebElement(btnCancel, "clickCancelButton");
			if (waits.waitUntilElementIsPresent(btnNo)) {
				flag = true;
				LogUtility.logInfo("clickCancelButton", "Clicked on Cancel Button");
			} else
				LogUtility.logError("clickCancelButton", "Failed to Click on Cancel Button");
		} catch (Exception e) {
			LogUtility.logException("clickCancelButton", "Failed to Click on Cancel Button in a Light box", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on No Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickNoButton() throws InterruptedException {
		try {
			waits.waitUntilElementIsPresent(btnNo);
			webActions.clickElementJS(btnNo);
			waits.staticWait(3);
			LogUtility.logInfo("clickNoButton", "Clicked on No Button");
		} catch (Exception e) {
			LogUtility.logException("clickNoButton", "Failed to Click on No Button in a Light box", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * To Click on Yes Button
	 * 
	 * @throws InterruptedException
	 */
	public void clickYesButton() throws InterruptedException {
		try {
			waits.waitUntilElementIsPresent(btnYes);
			wolWebUtil.clickWebElement(btnYes, "clickYesButton");
			LogUtility.logInfo("clickYesButton", "Clicked on Yes Button");
		} catch (Exception e) {
			LogUtility.logException("clickYesButton", "Failed to Click on Yes Button in a Light box", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * To Click on Edit Button
	 */
	public void clickEditButton() {
		try {
			waits.waitUntilElementIsPresent(btnEdit);
			webActions.clickElement(btnEdit);
			LogUtility.logInfo("clickEditButton", "Clicked on Edit Button");
		} catch (Exception e) {
			LogUtility.logException("clickEditButton", "Failed to Click on Edit Button in a Light box", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * To Select I don't have account number check box
	 */
	public void selectNoAcctNumOption() {
		try {
			waits.waitUntilElementIsPresent(chkNoAcctNum);
			webActions.clickElement(chkNoAcctNum);
			LogUtility.logInfo("selectNoAcctNumOption", "Selected I don't have account number check box");
		} catch (Exception e) {
			LogUtility.logException("selectNoAcctNumOption", "Failed to Select I don't have account number check box",
					e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To Enter Payee Address1 value
	 * 
	 * @param address1
	 */
	public boolean enterPayeeAddressOne(String address1) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtPayeeAdrss1);
			webActions.setValue(txtPayeeAdrss1, address1);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtPayeeAdrss1, "value").equalsIgnoreCase(address1)) {
				flag = true;
				LogUtility.logInfo("enterPayeeAddressOne", "Entered Payee Address One value");
			} else
				LogUtility.logError("enterPayeeAddressOne", "Failed to Enter Payee Address One value");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeAddressOne", "Failed to Enter Payee Address One value", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Enter Payee Adress2 value
	 * 
	 * @param address2
	 */
	public void enterPayeeAddressTwo(String address2) {
		try {
			waits.waitUntilElementIsPresent(txtPayeeAdrss2);
			webActions.setValue(txtPayeeAdrss2, address2);
			LogUtility.logInfo("enterPayeeAddressTwo", "Entered Payee Address Two value");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeAddressTwo", "Failed to Enter Payee Address Two value", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To Enter Payee City value
	 * 
	 * @param city
	 */
	public void enterPayeeCity(String city) {
		try {
			waits.waitUntilElementIsPresent(txtPayeeCity);
			webActions.setValue(txtPayeeCity, city);
			LogUtility.logInfo("enterPayeeCity", "Entered Payee City value");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeCity", "Failed to Enter Payee City value", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To Enter Payee State value
	 */
	public void selectPayeeState() {
		try {
			waits.waitUntilElementIsPresent(lstPayeeState);
			webActions.selectDropDownByValueJs(lstPayeeState, "CT");
			LogUtility.logInfo("selectPayeeState", "Entered Payee State value");
		} catch (Exception e) {
			LogUtility.logException("selectPayeeState", "Failed to Enter Payee State value", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * To Enter Payee Zip value
	 * 
	 * @param zip
	 */
	public void enterPayeeZip(String zip) {
		try {
			waits.waitUntilElementIsPresent(txtPayeeZip);
			webActions.setValue(txtPayeeZip, zip);
			LogUtility.logInfo("enterPayeeZip", "Entered Payee Zip value");
		} catch (Exception e) {
			LogUtility.logException("enterPayeeZip", "Failed to Enter Payee zip value", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To select disclosure agreement to add a new payee for comingled user
	 * 
	 * @return
	 */
	public void selectDisclosure() {
		try {
			if (waits.waitUntilElementIsPresent(chkPayeeDisc)) {
				webActions.clickElement(chkPayeeDisc);
				LogUtility.logInfo("selectDisclosure",
						"selected disclosure agreement to add a new payee for comingled user");
			}
		} catch (Exception e) {
			LogUtility.logException("selectDisclosure",
					"Failed to select disclosure agreement to add a new payee for comingled user", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * verifyAddBillPayeeTitles:- To verify the page header/Titles in Add a Bill
	 * Payee pages
	 * 
	 * @param text:- The text need to verify
	 * @return
	 */
	public boolean verifyAddBillPayeeTitles(String text) {
		try {
			waits.waitUntilElementIsPresent(txtTitleAddNewPayee, maxTimeOut);
			return wolWebUtil.verifyText(txtTitleAddNewPayee, text);
		} catch (Exception e) {
			LogUtility.logException("verifyAddBillPayeeTitles", "Failed to verify page title", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyPayeeNameselected:- To verify the Selected payee name to add a new
	 * payee
	 * 
	 * @param payeeName:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeNameSelected(String payeeName) {
		try {
			waits.waitUntilElementIsPresent(txtDisPayeeName);
			return wolWebUtil.verifyText(txtDisPayeeName, payeeName);
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeNameSelected", "Failed to verify selected payee name", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyConfrmmsgadding:- To verify confirmation message in add a bill pay page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyConfrmMsgAdding(String message) {
		try {
			waits.waitUntilElementIsPresent(txtConfrmMsg);
			return wolWebUtil.verifyText(txtConfrmMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyConfrmMsgAdding", "Failed to verify Payee add confirmation message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyConfrmmsgDeleting:- To verify confirmation message in delete payee page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyConfrmMsgDeleting(String message) {
		try {
			waits.waitUntilElementIsPresent(txtCnfrmMsgDeletePayee);
			return wolWebUtil.verifyText(txtCnfrmMsgDeletePayee, message);
		} catch (Exception e) {
			LogUtility.logException("verifyConfrmMsgDeleting", "Failed to verify Payee delete confirmation message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyAddressLghtboxMsg:- To verify text displayed in Select Address lightbox
	 * in Add a new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAddressLghtBoxMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtLghtBoxAddressMsg);
			return wolWebUtil.verifyText(txtLghtBoxAddressMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAddressLghtBoxMsg", "Failed to verify the text in Light box", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyAddressMsg:- To verify text displayed in Select Address in Add a new
	 * pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAddressMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtAddressLbl);
			return wolWebUtil.verifyText(txtAddressLbl, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAddressMsg", "Failed to verify the Address Text", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyCancelLghtboxMsg:- To verify text displayed in Cancel Button lightbox
	 * in Add a new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyCancelLghtBoxMsg(String message) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(txtLghtBoxCancelMsg))
				flag = wolWebUtil.verifyText(txtLghtBoxCancelMsg, message);
			else if (waits.waitUntilElementIsPresent(txtLghtBoxCancelMsgManage))
				flag = wolWebUtil.verifyText(txtLghtBoxCancelMsgManage, message);
		} catch (Exception e) {
			LogUtility.logException("verifyCancelLghtBoxMsg", "Failed to verify the Cancel Light box text", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyAddressMoreLabel:- To verify Label displayed for payee having more than
	 * 7 addresses in Add a new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAddressMoreLabel(String message) {
		try {
			waits.waitUntilElementIsPresent(txtAddressMoreLbl);
			return wolWebUtil.verifyText(txtAddressMoreLbl, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAddressMoreLabel", "Failed to verify the Address label", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyAddressMoreLabelLightbox:- To verify Label displayed for payee having
	 * more than 7 addresses in Add a new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAddressMoreLabelLightBox(String message) {
		try {
			waits.waitUntilElementIsPresent(txtAddressMorelblLightBox);
			return wolWebUtil.verifyText(txtAddressMorelblLightBox, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAddressMoreLabelLightBox", "Failed to verify the Address label Light box", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPayeeNameLabel:- To verify Payee Name Label displayed in Add a new pay
	 * payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeNameLabel(String message) {
		try {
			waits.waitUntilElementIsPresent(txtPayeeNameLbl);
			return wolWebUtil.verifyText(txtPayeeNameLbl, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeNameLabel", "Failed to verify the Payee Name Label", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPayeeAcctError:- To verify Payee Account Number error message displayed
	 * in Add a new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeAcctError(String message) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAcctNumErr);
			if (webActions.getAttributeValue(txtAcctNumErr, "innerText").equals(message)) {
				flag = true;
				LogUtility.logInfo("verifyPayeeAcctError", "Payee account error message " + message + " is displayed");
			} else
				LogUtility.logError("verifyPayeeAcctError", "Payee account error message is not displayed");
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeAcctError", "Failed to verify Payee account error message ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyPayeeAddress1Error:- To verify Payee Address 1 error message displayed
	 * in Add a new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeAddressOneError(String message) {
		try {
			waits.waitUntilElementIsPresent(txtAddrOneErr);
			return wolWebUtil.verifyText(txtAddrOneErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeAddressOneError", "Failed to verify Payee Address One error message ",
					e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPayeeCityError:- To verify Payee City error message displayed in Add a
	 * new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeCityError(String message) {
		try {
			waits.waitUntilElementIsPresent(txtCityErr);
			return wolWebUtil.verifyText(txtCityErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeCityError", "Failed to verify Payee City error message ", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPayeeStateError:- To verify Payee State error message displayed in Add
	 * a new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeStateError(String message) {
		try {
			waits.waitUntilElementIsPresent(txtStateErr);
			return wolWebUtil.verifyText(txtStateErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeStateError", "Failed to verify Payee State error message ", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPayeeZipError:- To verify Payee Zip error message displayed in Add a
	 * new pay payee page.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeZipError(String message) {
		try {
			waits.waitUntilElementIsPresent(txtZipErr);
			return wolWebUtil.verifyText(txtZipErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeZipError", "Failed to verify Payee Zip error message ", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPayeeInvalidAcctError:- To verify error message displayed in Add a new
	 * pay payee Light box when click on select address button after entering
	 * invalid account mask.
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeInvalidAcctError(String message) {
		boolean flag = false;
		try {

			waits.waitUntilElementIsPresent(txtPayeeLightBoxErr);
			if (webActions.getAttributeValue(txtPayeeLightBoxErr, "innerText").equals(message)) {
				flag = true;
				LogUtility.logInfo("verifyPayeeInvalidAcctError",
						"Payee aInvalid ccount error message " + message + " is displayed");
			} else
				LogUtility.logError("verifyPayeeInvalidAcctError",
						"Payee aInvalid ccount error message " + message + " is not displayed");
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeInvalidAcctError", "Failed to verify Payee Account error message ", e,
					LoggingLevel.ERROR, true);

		}
		return flag;
	}

	/**
	 * verifyPayeeCnfrmAcctError:- To verify Confirm Account Number Error message
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPayeeCnfrmAcctError(String message) {
		try {
			waits.waitUntilElementIsPresent(txtCnfrmAcctNumErr);
			return wolWebUtil.verifyText(txtCnfrmAcctNumErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPayeeCnfrmAcctError",
					"Failed to verify Payee Account Confirmation error message ", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check if the filed names are same as the expected names from feature file
	 * 
	 * @param           details[list of expected col names]
	 * @param payeeType
	 * @return
	 */
	public List<String> checkPayeeLabelsInUPDPage(List<String> details, String payeeType) {
		List<String> colPresent = new ArrayList<>();
		try {
			if (payeeType.equalsIgnoreCase("Check")) {
				for (WebElement ele : lstCPayeeCol) {
					String colLabel = webActions.getText(ele).replace("#", "").trim();
					if (details.contains(colLabel))
						colPresent.add(colLabel);
				}
			}
			for (WebElement ele : lstEPayeeCol) {
				String colLabel = webActions.getText(ele).replace("#", "").trim();
				if (details.contains(colLabel)) {
					colPresent.add(colLabel);
				}
			}
			LogUtility.logInfo("checkPayeeLabelsInUPDPage", "Labels present in the page are " + colPresent);
		} catch (Exception e) {
			LogUtility.logException("checkPayeeLabelsInUPDPage", "Failed to verify Labels ", e, LoggingLevel.ERROR,
					true);
		} finally {
			return colPresent;
		}
	}

	/**
	 * getPayeeCnfrmDetails- To get details of Payee in Add New Payee Confirmation
	 * page
	 */
	public void getPayeeCnfrmDetails() {
		try {
			confirmDetails = new LinkedHashMap<String, String>();
			for (int i = 0; i < txtCnfrmLabels.size(); i++)
				confirmDetails.put(txtCnfrmLabels.get(i).getText(), txtCnfrmValues.get(i).getText());
			LogUtility.logInfo("getPayeeCnfrmDetails", "Retrieved all the Add Payee Confirmation details");
		} catch (Exception e) {
			LogUtility.logException("getPayeeCnfrmDetails", "Failed to Get Confirmation details ", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * verifyAddressValue: To verify the address value
	 * 
	 * @return
	 */
	public boolean verifyAddressValue() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAddressValue);
			address = webActions.getText(txtAddressValue);
			if (address.equals(""))
				LogUtility.logInfo("verifyAddressValue", "Address value is empty");
			else {
				flag = true;
				LogUtility.logInfo("verifyAddressValue", "Address value is displayed");
			}

		} catch (Exception e) {
			LogUtility.logException("verifyAddressValue", "Failed to Verify Payee Address ", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * verifyConfirmDetails: To verify the details in confirmation page
	 * 
	 * @param payeeName
	 * @return
	 */
	public boolean verifyConfirmDetails(String payeeName) {
		boolean flag = false;
		try {
			if (confirmDetails.get("Payee Name").equalsIgnoreCase(payeeName)
					&& confirmDetails.get("Payee Account Number").equalsIgnoreCase(acctNum)) {
				flag = true;
				LogUtility.logInfo("verifyConfirmDetails", "Verified Confirmation details");
			} else
				LogUtility.logInfo("verifyConfirmDetails", "Confirmation details are invalid");
		} catch (Exception e) {
			LogUtility.logException("verifyConfirmDetails", "Failed to Verify Payee Confirmation Details ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

}
