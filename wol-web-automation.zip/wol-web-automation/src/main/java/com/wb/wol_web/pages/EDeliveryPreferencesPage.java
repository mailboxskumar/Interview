package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * @author Veerababu Pedireddi
 * @Modified by : Ramesh Pagadala
 */

public class EDeliveryPreferencesPage extends ObjectBase {

	public EDeliveryPreferencesPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "continue_button")
	protected WebElement btnContinueeDeliveryPrefPage;

	@FindBy(css = "h1 + p")
	protected WebElement titleeDeliveryPreferenceConfMsg;

	@FindBy(id = "edelivery.online_banking_notices")
	protected WebElement chkOnlineBankingNotices;

	@FindBy(css = "[id*='online_banking_notices'] + label")
	protected WebElement msgOtherDepositAccNotice;

	@FindBy(css = "form#edelivery > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(3) > div > div:nth-of-type(1) > div:nth-of-type(3) > img")
	protected WebElement toolTipeDelivery;

	@FindBy(css = "form#edelivery > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(3) > div > div:nth-of-type(2)")
	protected WebElement msgSendNotificationsTo;

	@FindBy(id = "emailUpdateTarget")
	protected WebElement lblSendNotificationsEmailId;

	@FindBy(name = "editEmail")
	protected WebElement btnEmailIdEdit;

	@FindBy(css = "h2:contains('Accounts enrolled for online statements only')")
	protected WebElement msgAccountsOnlineStmts;

	@FindBy(css = "h2:contains('Accounts to Receive Paper Statements')")
	protected WebElement msgAccountsPaperStmts;

	@FindBy(css = "input[id='edelivery.online_banking_notices'] + label")
	protected WebElement msgOtherDepositAccNoticeHeader;

	@FindBy(css = "h2:contains('Electronic')")
	protected WebElement headerElectronicSts;

	@FindBy(css = "#pageContent > table:nth-child(8) > tbody > tr > td:nth-child(1)")
	protected WebElement textDeliveredNotifications;

	@FindBy(css = "#pageContent > table:nth-child(8) > tbody > tr > td:nth-child(2)")
	protected WebElement textNotificationsDeliveredEmailId;

	@FindBy(id = "cancel_button")
	protected WebElement btnCancel;

	@FindBy(id = "continue_button")
	protected WebElement btnContinue;

	@FindBy(name = "editEmail")
	protected WebElement btnEditMail;

	@FindBy(id = "emailUpdateTarget")
	protected WebElement txtCurrentMailId;

	@FindBy(css = "strong[id='emailUpdateTarget']>parent")
	protected WebElement labelMailId;

	@FindBy(id = "edelivery.online_banking_notices")
	protected WebElement checkboxNotices;

	@FindBy(css = "input[id='edelivery.online_banking_notices'] + label")
	protected WebElement labelNotices;

	@FindBy(css = "[id*=online_banking_notices] ~img")
	protected WebElement imgTooltipNotices;

	@FindBy(css = "div[id='bodyContent'] h1")
	protected WebElement txtPageTitle;

	@FindBy(css = "div[id='pageContent'] input ~ label")
	protected List<WebElement> listAccountNames;

	@FindBy(css = "div[id='pageContent'] input[type='checkbox']")
	protected List<WebElement> listCheckboxes;

	@FindBy(css = "div[id='pageContent'] h2")
	protected List<WebElement> listHeaderNames;

	@FindBy(id = "selectAll")
	protected WebElement linkSelectAll;

	@FindBy(css = "div[id='pageContent'] a")
	protected List<WebElement> listLinks;

	@FindBy(css = "div[id='subHeaderContainer'] h1")
	protected WebElement txtAgreementHeader;

	@FindBy(css = "div[id='lightboxContent0'] strong")
	protected List<WebElement> txtAgreementSideHeaders;

	@FindBy(css = "div#pageContent > ul:nth-of-type(1) > li > a")
	protected List<WebElement> listAllAccounts;

	@FindBy(css = "div.lightbox-wrap.is-visible.is-top  button[aria-label='Close the dialog']")
	protected WebElement btnCloseAgreement;

	@FindBy(css = "button[aria-label='Print the dialog']")
	protected WebElement btnPrintAgreement;

	@FindBy(css = "td>input[type='checkbox']")
	protected List<WebElement> listcheckboxAccounts;

	@FindBy(css = "input[value='Update']")
	protected WebElement btnUpdate;

	@FindBy(id = "accountDetailsSubmitButton")
	protected WebElement btnSubmit;

	@FindBy(css = "#edelivery div:nth-child(1) > img")
	protected WebElement imgToolTipAccountStmts;

	@FindBy(css = "#edelivery div:nth-child(6) > img")
	protected WebElement imgToolTipOtherDepositAccounts;

	@FindBy(css = "div[id='lightboxContent0'] a[name='cancel']")
	protected WebElement btnMailCancel;

	@FindBy(css = "div[id='lightboxContent0'] input[name='continue']")
	protected WebElement btnMailContinue;

	@FindBy(css = "div[id='lightboxContent0'] div.note")
	protected WebElement txtEditMailNote;

	@FindBy(css = "label[data-wbst-message-key='emailEdit.email1']")
	protected WebElement txtNewMailLabel;

	@FindBy(css = "div[data-wbst-message-key='emailEdit.email.invalid']")
	protected WebElement txtNewMailLabelError;

	@FindBy(css = "label[data-wbst-message-key='emailEdit.email2']")
	protected WebElement txtVerifyNewMailLabel;

	@FindBy(id = "email1-2")
	protected WebElement inputNewMail;

	@FindBy(id = "email2-3")
	protected WebElement inputVerifyNewMail;

	@FindBy(css = "div[id='bodyContent'] h1+p")
	protected WebElement txtUnderEDeliveryPreferenceHeader;

	@FindBy(css = "div[id='bodyContent'] div[id='pageContent'] div.note ")
	protected WebElement txtEDeliveryPreferencePageNote;

	@FindBy(css = "form[name='WebcomServlet']  td:nth-child(2) > b > font")
	protected WebElement txtEDeliveryPreferenceLightboxNote;

	protected String accCheckBoxXpath = "//form[@id='edelivery']/div[1]/div[1]/div[3]/div/div[1]/div[2]/div/label[contains(text(),'%s')]/preceding::input[1]";
	public List<String> listAccounts;
	public int count = 0;
	public String txtMessage = "";
	public String txtTooltip = "";
	public WebElement iconTooltip;
	public String messageTooltip;
	public String txtMailId = "";
	public String updatedMail = "";

	/**
	 * To verify Account check box is selected or not, If selected un-check the
	 * check box , If Un-checked, select the check box
	 */
	public boolean verifyAccountCheckBoxStatus(String accNumber, String checkBoxStatus) {
		waits.waitForPageReadyState();
		boolean flag = false;
		WebElement accDetails;
		try {
			if (checkBoxStatus.equals("Checked")) {
				accDetails = driver.findElement(By.xpath(String.format(accCheckBoxXpath, accNumber)));
				boolean returnValue = webActions.isChecked(accDetails);
				if (returnValue)
					flag = true;
				else {
					webActions.clickElement(accDetails);
					flag = true;
				}
				LogUtility.logInfo("---> Account checked <---" + accDetails);
			} else if (checkBoxStatus.equals("Unchecked")) {
				accDetails = driver.findElement(By.xpath(String.format(accCheckBoxXpath, accNumber)));
				boolean returnValue = webActions.isChecked(accDetails);
				if (returnValue) {
					webActions.clickElement(accDetails);
					flag = true;
				} else
					flag = true;
				LogUtility.logInfo("---> Account Un checked <---." + accDetails);
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyAccountCheckBoxStatus<--", "Unable to verify Account CheckBox Status", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on the Continue button in eDelivery Preferences Page
	 */

	public boolean clickOnContinueBtnIneDeliveryPrefPage() {
		boolean flag = false;
		try {
			boolean continueBtn = webActions.isDisplayed(btnContinueeDeliveryPrefPage);
			if (continueBtn) {
				webActions.clickElement(btnContinueeDeliveryPrefPage);
				LogUtility.logInfo("--->clickOnContinueBtnIneDeliveryPrefPage<---", "Clicked on Continue button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnContinueBtnIneDeliveryPrefPage<--",
					"Unable to click on continue button in eDelivery Prefrence page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/*
	 * To Verify the eDelivery Preferences Confirmation message
	 */

	public boolean verifyeDeliveryPrefConfMsg(String eDeliveryPrefConfMsg) {
		try {
			waits.waitUntilElementIsPresent(titleeDeliveryPreferenceConfMsg, maxTimeOut);
			return wolWebUtil.verifyText(titleeDeliveryPreferenceConfMsg, eDeliveryPrefConfMsg);
		} catch (Exception e) {
			LogUtility.logException("-->verifyeDeliveryPrefConfMsg<--",
					"Unable to verify eDelivery Prefernce Confirmatin message", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify "Other Deposit Account Notices" check box is displayed or not
	 * 
	 * @return
	 */
	public boolean otherDepositAccNoticesChkBox() {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(chkOnlineBankingNotices, maxTimeOut);
			return webActions.isDisplayed(chkOnlineBankingNotices);
		} catch (Exception e) {
			LogUtility.logException("-->otherDepositAccNoticesChkBox<--",
					"Unable to verify other Deposit Account Notices CheckBox", e, LoggingLevel.ERROR, true);
			return false;
		}
	}
	/*
	 * To Verify the "Other Deposit Account Notices" text displayed or not
	 */

	public boolean verifyOtherDepositAccNoticeMsg(String otherDepositAccMsg) {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(msgOtherDepositAccNotice, maxTimeOut);
			return wolWebUtil.verifyText(msgOtherDepositAccNotice, otherDepositAccMsg);
		} catch (Exception e) {
			LogUtility.logException("-->verifyOtherDepositAccNoticeMsg<--",
					"Unable to verify Other Deposit Account Notice message", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify eDelivery tool tip image displayed or not
	 * 
	 * @return
	 */
	public boolean toolTipForeDelivery() {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(toolTipeDelivery, maxTimeOut);
			return webActions.isDisplayed(toolTipeDelivery);
		} catch (Exception e) {
			LogUtility.logException("-->toolTipForeDelivery<--", "Unable to verify tooltip for eDelivery", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/*
	 * To Verify the "Send notifications to:" text displayed or not
	 */

	public boolean verifySendNotificationsMsg(String sendNotificationMsg) {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(msgSendNotificationsTo, maxTimeOut);
			return wolWebUtil.verifyTextContains(msgSendNotificationsTo, sendNotificationMsg);
		} catch (Exception e) {
			LogUtility.logException("-->verifySendNotificationsMsg<--", "Unable to verify send notification message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/*
	 * To Verify the "Send notifications Email address" displayed or not
	 */

	public boolean verifySendNotificationsEmailId(String sendNotificationsEmailId) {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(lblSendNotificationsEmailId, maxTimeOut);
			return wolWebUtil.verifyTextContains(lblSendNotificationsEmailId, sendNotificationsEmailId);
		} catch (Exception e) {
			LogUtility.logException("-->verifySendNotificationsEmailId<--",
					"Unable to verify send notifications email id", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify eDelivery Edit button displayed or not
	 */
	public boolean emailIdEditButton() {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(btnEmailIdEdit, maxTimeOut);
			return webActions.isDisplayed(btnEmailIdEdit);
		} catch (Exception e) {
			LogUtility.logException("-->emailIdEditButton<--", "Unable to verify email id edit button", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/*
	 * To Verify the "Electronic" header displayed or not
	 */

	public boolean verifyElectronicStatus(String electronicStatus) {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(headerElectronicSts, maxTimeOut);
			return wolWebUtil.verifyText(headerElectronicSts, electronicStatus);
		} catch (Exception e) {
			LogUtility.logException("-->verifyElectronicStatus<--", "Unable to verify electronic status", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/*
	 * To Verify the "Notifications Delivered to :" text displayed or not
	 */

	public boolean verifyNotificationsDeliveredTo(String notificationDelivered) {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(textDeliveredNotifications, maxTimeOut);
			return wolWebUtil.verifyText(textDeliveredNotifications, notificationDelivered);
		} catch (Exception e) {
			LogUtility.logException("-->verifyNotificationsDeliveredTo<--",
					"Unable to verify the notifications deliverd to account", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/*
	 * To Verify the "Notifications Delivered To Email address" displayed or not
	 */

	public boolean verifyNotificationsDeliveredEmailId(String notificationsDeliveredEmailId) {
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(textNotificationsDeliveredEmailId, maxTimeOut);
			return wolWebUtil.verifyTextContains(textNotificationsDeliveredEmailId, notificationsDeliveredEmailId);
		} catch (Exception e) {
			LogUtility.logException("-->verifyNotificationsDeliveredEmailId<--",
					"Unable to verify the notifications deliverd email id", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * checkForButtons: To check the presence of buttons
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean checkForButtons(String btnName) {
		waits.waitForPageReadyState();
		try {
			WebElement btnToBeCheck = null;
			switch (btnName) {
			case "Cancel":
				btnToBeCheck = btnCancel;
				break;
			case "Continue":
				btnToBeCheck = btnContinue;
				break;
			case "Mail Cancel":
				btnToBeCheck = btnMailCancel;
				break;
			case "Mail Continue":
				btnToBeCheck = btnMailContinue;
				break;
			default:
				LogUtility.logInfo("--->checkForButtons<---", "No case match found");
				break;
			}
			if (webActions.isDisplayed(btnToBeCheck)) {
				LogUtility.logInfo("--->checkForButtons<---", "Button: " + btnName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForButtons<--", "Unable to verify the buttons", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyMailEditButton: To Verify the mail edit button
	 * 
	 * @param labelName
	 * @return
	 */
	public boolean verifyMailEditButton(String labelName) {
		waits.waitForPageReadyState();
		try {
			txtMailId = webActions.getText(txtCurrentMailId);
			if (webActions.isDisplayed(btnEditMail) && txtMailId.length() > 0) {
				LogUtility.logInfo("--->verifyMailEditButton<---",
						"Mail ID is " + txtMailId + "Mail Id label mail id and Edit button are present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyMailEditButton<--", "Unable to verify the mail edit button", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyCheckboxTooltipOtherDeposits : To verify the tooltip of the other
	 * Deposits
	 * 
	 * @param labelName
	 * @return
	 */
	public boolean verifyCheckboxTooltipOtherDeposits(String labelName) {
		try {
			if (wolWebUtil.verifyTextContains(labelNotices, labelName)) {
				if (webActions.isDisplayed(checkboxNotices) && webActions.isDisplayed(imgTooltipNotices)) {
					LogUtility.logInfo("-->verifyCheckboxTooltipOtherDeposits<--",
							" Notices checkbox and tooltip are present");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyCheckboxTooltipOtherDeposits<--",
					"Unable to verify the checkbox tooltip of other deposits", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyAccountsCheckboxes: To get the number of accounts and checkboxes
	 * 
	 * @param listHeaders
	 * @return
	 */
	public boolean verifyAccountsCheckboxes(Collection<String> listHeaders) {
		waits.waitForPageReadyState();
		try {
			int accounts = listAccountNames.size();
			int checkboxes = listCheckboxes.size();
			if (accounts == checkboxes) {
				LogUtility.logInfo("--->verifyAccountsCheckboxes<---", "Accounts and checkboxes are present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyAccountsCheckboxes<--", "Unable to verify the accounts checkboxes", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyHeaderConfirmation: To verify the header names
	 * 
	 * @param listHeaders
	 * @return
	 */
	public boolean verifyHeaderConfirmation(List<String> listHeaders) {
		waits.waitForPageReadyState();
		try {
			for (WebElement header : listHeaderNames) {
				if (wolWebUtil.verifyTextContains(header, listHeaders.toString())) {
					LogUtility.logInfo("--->verifyHeaderConfirmation<---", "Header names are present");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyHeaderConfirmation<--", "Unable to verify the header confirmation", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickSelectAll: To click on select all link
	 * 
	 * @return
	 */
	public boolean clickSelectAll() {
		waits.waitForPageReadyState();
		try {
			webActions.clickElement(linkSelectAll);
			LogUtility.logInfo("--->clickSelectAll<----", "clicked on Select All link");
			return true;
		} catch (Exception e) {
			LogUtility.logException("-->clickSelectAll<--", "Unable to click on select all", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyCheckedCheckboxes: To verify checkboxes checked
	 * 
	 * @return
	 */
	public boolean verifyCheckedCheckboxes() {
		waits.waitForPageReadyState();
		try {
			for (WebElement checkbox : listCheckboxes) {
				if (!webActions.isChecked(checkbox)) {
					LogUtility.logError("--->verifyCheckedCheckboxes<---", "Checkbox is unchecked");
					return false;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyCheckedCheckboxes<--", "Unable to verify the checked checkboxes", e,
					LoggingLevel.ERROR, true);
		}
		LogUtility.logInfo("--->verifyCheckedCheckboxes<----", "All checkboxes are checked");
		return true;
	}

	/**
	 * clickContinueButton: Click on continue button
	 * 
	 * @return
	 */
	public boolean clickContinueButton() {
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(btnContinue)) {
				webActions.clickElement(btnContinue);
				LogUtility.logInfo("--->clickContinueButton<----", "clicked on Continue button");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickContinueButton<--", "Unable to click on continue button", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickLink: To click on link
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickLink(String linkName) {
		try {
			for (WebElement link : listLinks) {
				if (wolWebUtil.verifyTextContains(link, linkName)) {
					webActions.clickElement(link);
					LogUtility.logInfo("--->clickLink<----", "Clicked on " + linkName + " link");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickLink<--", "Unable to click on link", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkLightboxTitle: To verify the light box title
	 * 
	 * @param pageName
	 * @return
	 */
	public boolean checkLightboxTitle(String pageName) {
		try {
			waits.waitUntilElementIsPresent(txtAgreementHeader);
			if (wolWebUtil.verifyTextContains(txtAgreementHeader, pageName)) {
				LogUtility.logInfo("----->checkLightboxTitle<----", pageName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkLightboxTitle<--", "Unable to check the light box title", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyPrintCloseButtons: To verify the print, close buttons
	 * 
	 * @param btnPrint
	 * @param btnClose
	 * @return
	 */
	public boolean verifyPrintCloseButtons(String btnPrint, String btnClose) {
		waits.waitForPageReadyState();
		try {
			if (!webActions.isDisplayed(btnPrintAgreement))
				return false;
			if (!webActions.isDisplayed(btnCloseAgreement))
				return false;
		} catch (Exception e) {
			LogUtility.logException("-->verifyPrintCloseButtons<--", "Unable to verify the print and close buttons", e,
					LoggingLevel.ERROR, true);
		}
		LogUtility.logInfo("--->verifyPrintCloseButtons<---", btnClose + ", " + btnPrint + " are displayed");
		return true;
	}

	/**
	 * VerifyAgreementHeadings: To get the heading in agreement
	 * 
	 * @param listSideHeaders
	 * @return
	 */
	public boolean VerifyAgreementHeadings(List<String> listSideHeaders) {
		waits.waitForPageReadyState();
		try {
			for (WebElement sideHeader : txtAgreementSideHeaders)
				if (wolWebUtil.verifyTextContains(sideHeader, listSideHeaders.toString()))
					LogUtility.logInfo("--->VerifyAgreementHeadings<---", "Agreement Side Headers are displayed");
		} catch (Exception e) {
			LogUtility.logException("-->VerifyAgreementHeadings<--", "Unable to verify the agreements headings", e,
					LoggingLevel.ERROR, true);
			return false;
		}
		return true;
	}

	/**
	 * verifyAccountsNotChecked: To verify the account checkboxes are not checked
	 * 
	 * @return
	 */
	public boolean verifyAccountsNotChecked() {
		waits.waitForPageReadyState();
		try {
			for (WebElement checkBoxAccounts : listCheckboxes)
				if (webActions.isChecked(checkBoxAccounts))
					return false;
		} catch (Exception e) {
			LogUtility.logException("-->verifyAccountsNotChecked<--", "Unable to verify the accounts not checked", e,
					LoggingLevel.ERROR, true);
		}
		LogUtility.logInfo("--->verifyAccountsNotChecked<---", "Accounts are not checked");
		return true;
	}

	/**
	 * deseletAllAccounts: To uncheck the all the accounts in eDeliveryPrefernce
	 * page
	 * 
	 * @return
	 */
	public boolean clickAllAccounts() {
		waits.waitForPageReadyState();
		try {
			for (WebElement checkBoxAccounts : listCheckboxes)
				webActions.clickElement(checkBoxAccounts);
			LogUtility.logInfo("--->clickAllAccounts<---", "clicked on all accounts");
			return true;
		} catch (Exception e) {
			LogUtility.logException("-->clickAllAccounts<--", "Unable to click all accounts", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * deseletAllAccounts: To get and add the all the accounts of user
	 * 
	 * @return
	 */
	public List<String> checkAllAccounts() {
		waits.waitForPageReadyState();
		listAccounts = new ArrayList<String>();
		try {
			for (WebElement account : listAllAccounts)
				listAccounts.add(account.getText().trim());
			LogUtility.logInfo("---> checkAllAccounts <---", "checked Accounts: " + listAccounts.toString());
		} catch (Exception e) {
			LogUtility.logException("-->checkAllAccounts<--", "Unable to check  all accounts", e, LoggingLevel.ERROR,
					true);
		}
		return listAccounts;
	}

	/**
	 * checkAccountsWithCheckboxes: To check the accounts displayed in page and
	 * corresponding checkeboxes
	 * 
	 * @return
	 */
	public boolean checkAccountsWithCheckboxes() {
		waits.waitForPageReadyState();
		count = 0;
		try {
			for (WebElement account : listAccountNames) {
				CharSequence accountName = account.getText().trim().subSequence(7, 11);
				if (listAccounts.toString().contains(accountName)) {
					LogUtility.logInfo("--->checkAccountsWithCheckboxes<---",
							"Account Number: " + accountName + " is displayed");
					count++;
				}
			}
			if (count == (listCheckboxes.size() - 1))
				return true;
		} catch (Exception e) {
			LogUtility.logException("-->checkAccountsWithCheckboxes<--", "Unable to check accounts with checkboxes", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyAccountCheckboxes : To perform action on account checkboxes in
	 * eDeliveryPreference Page
	 * 
	 * @param typeAction
	 * @return
	 */
	public boolean verifyAccountCheckboxes(String typeAction) {
		waits.waitForPageReadyState();
		try {
			for (WebElement checkbox : listcheckboxAccounts)
				if (typeAction.equalsIgnoreCase("Unchecked")) {
					if (webActions.isChecked(checkbox))
						webActions.clickElement(checkbox);
				} else if (typeAction.equalsIgnoreCase("Checked"))
					if (!webActions.isChecked(checkbox))
						webActions.clickElement(checkbox);
		} catch (Exception e) {
			LogUtility.logException("-->verifyAccountCheckboxes<--", "Unable to verify account checkboxes", e,
					LoggingLevel.ERROR, true);
			return false;
		}
		LogUtility.logInfo("--->verifyAccountCheckboxes<---", "Account Number checkboxes: " + typeAction);
		return true;
	}

	/**
	 * clickOnButton: To click on Button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForDOMready();
		WebElement eleToBeClicked = null;
		try {
			switch (btnName) {
			case "Update":
				eleToBeClicked = btnUpdate;
				break;
			case "Submit":
				eleToBeClicked = btnSubmit;
				break;
			case "Close":
				eleToBeClicked = btnCloseAgreement;
				break;
			case "Other Deposit Account Notices tooltip":
				eleToBeClicked = imgTooltipNotices;
				break;
			case "Mail Edit":
				eleToBeClicked = btnEditMail;
				break;
			case "Mail Continue":
				eleToBeClicked = btnMailContinue;
				break;
			case "Mail Cancel":
				eleToBeClicked = btnMailCancel;
				break;
			default:
				LogUtility.logInfo("--->clickOnButton<---", "No case match found");
				break;
			}
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(eleToBeClicked, maxTimeOut)) {
				webActions.clickElement(eleToBeClicked);
				LogUtility.logInfo("--->clickOnButton<---", "Clicked on " + btnName + " button");
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnButton<--", "Unable to click on button", e, LoggingLevel.ERROR, true);
			return false;
		}
		return true;
	}

	/**
	 * checkForMessage: To check the update message
	 * 
	 * @param txtUpdateMessage
	 * @return
	 */
	public boolean checkForMessage(String txtUpdateMessage) {
		try {
			txtMessage = "//*[contains(text(),'%s')]";
			WebElement updateMessage = driver.findElement(By.xpath(String.format(txtMessage, txtUpdateMessage)));
			if (webActions.isDisplayed(updateMessage)) {
				LogUtility.logInfo("--->checkForMessage<---", "Message: " + txtUpdateMessage + " is present");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForMessage<--", "Unable to check for message", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForMessageLightbox: To check the update message
	 * 
	 * @param txtUpdateMessage
	 * @return
	 */
	public boolean checkForMessageLightbox(String txtUpdateMessage) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		// Taking to load the update message in IE
		waits.staticWait(5);
		try {
			if (waits.waitUntilElementIsPresent(txtEDeliveryPreferenceLightboxNote))
				if (wolWebUtil.verifyTextContains(txtEDeliveryPreferenceLightboxNote, txtUpdateMessage)) {
					LogUtility.logInfo("--->checkForMessageLightbox<---",
							"Message: " + txtUpdateMessage + " is present");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("-->checkForMessageLightbox<--", "Unable to check for message lightbox", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnTooltip: To click on Account StatementTooltip
	 * 
	 * @param txtTooltipName
	 * @return
	 */
	public boolean clickOnTooltip(String txtTooltipName) {
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(imgToolTipAccountStmts)) {
				webActions.clickElement(imgToolTipAccountStmts);
				LogUtility.logInfo("--->clickOnTooltip<---", "Clicked on: " + txtTooltipName + " tooltip icon");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnTooltip<--", "Unable to click on tooltip", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForTooltipMessage: To check the message after mouse-hovering on tooltip
	 * 
	 * @param accountType
	 * @param txtMessage
	 * @return
	 */
	public boolean checkForTooltipMessage(String accountType, String txtMessage) {
		waits.waitForPageReadyState();
		try {
			switch (accountType) {
			case "Account Statement":
				messageTooltip = webActions.getAttributeValue(imgToolTipAccountStmts, "data-title");
				break;
			case "Other Deposit Account Notices":
				messageTooltip = webActions.getAttributeValue(imgTooltipNotices, "data-title");
				break;
			case "eDeliveryAgreement Options":
				messageTooltip = webActions.getText(txtUnderEDeliveryPreferenceHeader);
				break;
			case "eDeliveryAgreement Note":
				messageTooltip = webActions.getText(txtEDeliveryPreferencePageNote);
				break;
			default:
				LogUtility.logInfo("--->checkForTooltipMessage<---", "No case match found");
				break;
			}
			if (messageTooltip.contains(txtMessage)) {
				LogUtility.logInfo("--->checkForTooltipMessage<---",
						"Label: " + accountType + " with Message: " + txtMessage + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForTooltipMessage<--", "Unable to check for tooltip message", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForNote : To check the note on the edit mail id lightbox
	 * 
	 * @param txtNote
	 * @return
	 */
	public boolean checkForNote(String txtNote) {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtEditMailNote, txtNote)) {
				LogUtility.logInfo("--->checkForNote<---", "Note: " + txtNote + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForNote<--", "Unable to check for note message", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForLabelAndTextbox: To check the label along with textbox
	 * 
	 * @param fieldName
	 * @return
	 */
	public boolean checkForLabelAndTextbox(String fieldName) {
		waits.waitForPageReadyState();
		try {
			WebElement labelName = null;
			switch (fieldName) {
			case "New Email Address":
				labelName = txtNewMailLabel;
				break;
			case "Verify New Email Address":
				labelName = txtVerifyNewMailLabel;
				break;
			default:
				LogUtility.logInfo("--->checkForLabelAndTextbox<---", "No case match found");
				break;
			}
			if (wolWebUtil.verifyTextContains(labelName, fieldName)) {
				LogUtility.logInfo("--->checkForLabelAndTextbox<---",
						"Label: " + fieldName + " with textbox is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForLabelAndTextbox<--", "Unable to check for along with text box", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterNewMailID: to enter new mail id in edit mail lightbox
	 * 
	 * @param mailType
	 * @param mailNew
	 * @param mailVerifyNew
	 * @return
	 */
	public boolean enterNewMailID(String mailType, String mailNew, String mailVerifyNew) {
		waits.waitForPageReadyState();
		try {
			if (mailType.equalsIgnoreCase("Valid"))
				updatedMail = wolWebUtil.getRandomString(6) + "@websterbank.com";
			else
				updatedMail = wolWebUtil.getRandomString(6) + "@websterbank";
			if (webActions.isDisplayed(inputNewMail)) {
				webActions.setValue(inputNewMail, updatedMail);
				webActions.setValue(inputVerifyNewMail, updatedMail);
				LogUtility.logInfo("--->enterNewMailID<---", "Mail: " + updatedMail + " is Entered in new mail");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterNewMailID<--", "Unable to enter new mail id", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * 
	 * checkForUpdatedMail: To verify the updated mail ID
	 * 
	 * @return
	 */
	public String checkForUpdatedMail() {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtCurrentMailId, updatedMail)) {
				LogUtility.logInfo("--->checkForUpdatedMail<---", "Mail ID is " + updatedMail + " is displayed");
				return updatedMail;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForUpdatedMail<--", "Unable to check for updated mail", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkForErrorMessage: To check the error message
	 * 
	 * @param labelName
	 * @param errorMessage
	 * @return
	 */
	public boolean checkForErrorMessage(String labelName, String errorMessage) {
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtNewMailLabelError, errorMessage)) {
				LogUtility.logInfo("--->checkForErrorMessage<---",
						"Label: " + labelName + " is displayed with error message as: " + errorMessage);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkForErrorMessage<--", "Unable to check for error message", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}
}
