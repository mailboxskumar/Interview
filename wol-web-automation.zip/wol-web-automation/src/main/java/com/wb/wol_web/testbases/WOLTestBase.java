package com.wb.wol_web.testbases;

import java.lang.reflect.Method;

import org.testng.ITestContext;

import com.wb.java_af.testbases.CucumberTestBase;

/**
 * This class is supplied to override some of the default behaviour of java-af
 * CucumberBase if desired.
 * 
 * @author Bharat Pandey
 *
 */
public class WOLTestBase extends CucumberTestBase {

	@Override
	public void beforeMethod(ITestContext context, Method method) throws Exception {
		super.beforeMethod(context, method);
	}

}
