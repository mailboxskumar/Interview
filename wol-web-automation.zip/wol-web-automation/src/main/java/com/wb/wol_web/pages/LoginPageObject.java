package com.wb.wol_web.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class LoginPageObject {
	
	@FindBy(how = How.NAME, using = "username")
	public WebElement usernameTextBox;

	@FindBy(how = How.NAME, using = "submit1")
	public WebElement goButton;
	
	@FindBy(how = How.ID, using = "password__input")
	public WebElement passwordTextBox;
	
	@FindBy(how = How.ID, using = "continueButton_ff__buttonText")
	public WebElement continueButton;
}
