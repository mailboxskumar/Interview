
package com.wb.wol_web.utilities;

import com.aventstack.extentreports.Status;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.utilities.LogUtility;

public class GenericLibrary {

	public static void reportInfo(String message) {
		ExtentTestManager.getTest().log(Status.INFO, message);
		LogUtility.logInfo(message);
	}

	public static void reportPass(String message) {
		ExtentTestManager.getTest().log(Status.PASS, message);
		LogUtility.logInfo(message);
	}

	public static void reportFail(String message) {
		ExtentTestManager.getTest().log(Status.FAIL, message);
		LogUtility.logInfo(message);
	}
}

