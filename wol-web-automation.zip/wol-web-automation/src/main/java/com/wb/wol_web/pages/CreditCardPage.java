package com.wb.wol_web.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author: Ravi kumar Maddula
 *
 */

public class CreditCardPage extends ObjectBase {

	public CreditCardPage() {
		PageFactory.initElements(driver, this);
	}

	public String alertText = "";

	@FindBy(id = "link-om-u1-1501127809-1")
	protected WebElement menuBank;

	@FindBy(linkText = "Credit Cards")
	protected WebElement lnkCreditCards;

	@FindBy(xpath = "//a[@class='external-link yellow-button']")
	protected WebElement lnkApplyNow;

	@FindBy(id = "link-om-u1-1173871000-2")
	protected WebElement menuFinancing;

	@FindBy(xpath = "//h1")
	protected WebElement txtBusinessCCHeader;

	@FindBy(xpath = "//div[@class='large-3 columns block block-menu_block block-menu_block-id-57']")
	protected WebElement lnkBusinessCreditCards;

	@FindBy(id = "webster_visa_business_platinum_card_apply_now")
	protected WebElement btnApplyNow;

	@FindBy(linkText = "Cancel")
	protected WebElement btnCancel;

	@FindBy(xpath = "//div[@id='node-35991']//a[2]")
	protected WebElement btnContinue;

	@FindBy(xpath = "//nav[@aria-label='Menu Navigation']")
	protected WebElement mnuMain;

	@FindBy(css = "#credit_accounts_row0__col_0 a")
	protected WebElement lnkCreditCard;

	@FindBy(xpath = "//div[@class='col--locked  col--primary  ']//table[3]/tbody/tr/td[2]/strong/a")
	protected WebElement lnkCreditCardNumber;

	@FindBy(xpath = "//table[@class='data-table detail-table']/tbody/tr/td[1]")
	protected List<WebElement> tblCardInfo;

	@FindBy(xpath = "//table[@class='data-table detail-table']")
	protected WebElement tblCreditCardInfo;

	public boolean moveToBank() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(menuBank)) {
				wolWebUtil.hoverOnTheElement(menuBank);
				LogUtility.logInfo("---> moveToBank <---",
						"Mouse move action performed and moved to Bank menu successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("moveToBank", "Failed to move cursor to Bank menu ", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyAlertText(String fieldText) {
		boolean flag = false;
		try {
			if (alerts.isAlertPresent()) {
				alertText = alerts.getTextFromAlert();
				if (alertText.contains(fieldText)) {
					LogUtility.logInfo("---> verifyAlertText <---", "Verified text from alert successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAlertText", "Failed to verify text from alert", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickCreditCard() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(lnkCreditCards)) {
				webActions.clickElement(lnkCreditCards);
				LogUtility.logInfo("---> clickCreditCard <---", "Clicked on credit card link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickCreditCard", "Failed to click on credit card link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickApplyNow() {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			// Must wait till page load
			waits.staticWait(3);
			webActions.clickElement(lnkApplyNow);
			// Need to wait to load alert
			waits.staticWait(3);
			LogUtility.logInfo("---> clickApplyNow <---", "Clicked on apply now button");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("clickApplyNow", "Failed to click on apply now button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean acceptAlert() {
		boolean flag = false;
		try {
			if (alerts.isAlertPresent()) {
				alerts.acceptAlert();
				LogUtility.logInfo("---> acceptAlert <---", "Accepted alert successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("acceptAlert", "Failed to accept alert", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean dismissAlert() {
		boolean flag = false;
		try {
			if (alerts.isAlertPresent()) {
				alerts.dismissAlert();
				LogUtility.logInfo("---> dismissAlert <---", "Dismissed alert successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("dismissAlert", "Failed to dismiss alert", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyElanWindow(String pageTiltle) {
		boolean flag = false;
		try {
			if (wolWebUtil.verifyPageTitleOfChildWindow(pageTiltle)) {
				LogUtility.logInfo("---> verifyElanWindow <---", "Elan window verified successfully");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("dismissAlert", "Failed to dismiss alert", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickCancel() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(btnCancel)) {
				webActions.clickElement(btnCancel);
				LogUtility.logInfo("---> clickCancel <---", "Clicked on cancel button successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickCancel", "Failed to click on cancel button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickContinue() {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			// Need to wait to load button
			waits.staticWait(3);
			if (webActions.isDisplayed(btnContinue)) {
				webActions.clickElement(btnContinue);
				LogUtility.logInfo("---> clickContinue <---", "Clicked on continue button successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickContinue", "Failed to click on continue button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickOnApplyNow() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(btnApplyNow)) {
				webActions.clickElement(btnApplyNow);
				LogUtility.logInfo("---> clickOnApplyNow <---", "Clicked on Apply now button successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnApplyNow", "Failed to click on Apply now button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyBusinessCreditCardHeader(String header) {
		boolean flag = false;
		String txtWithBrTag = "";
		try {
			waits.waitForPageReadyState();
			// Need to wait to load page
			waits.staticWait(2);
			if (webActions.isDisplayed(txtBusinessCCHeader)) {
				txtWithBrTag = txtBusinessCCHeader.getText().replaceAll("\\r\\n|\\r|\\n", " ");
				return txtWithBrTag.contains(alertText);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyBusinessCreditCardHeader", "Failed to verify header", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickBusinessCreditCardLink(String link) {
		boolean flag = false;
		try {
			// Need to wait to load page
			waits.staticWait(3);
			if (webActions.isDisplayed(lnkBusinessCreditCards)) {
				wolWebUtil.selectLinkFromList(lnkBusinessCreditCards, link);
				LogUtility.logInfo("---> clickBusinessCreditCardLink <---", "Clicked on Business Credit Card Link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickBusinessCreditCardLink", "Failed to click on Business Credit Card Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;

	}

	public boolean moveToFinancing() {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			// Need to wait to load page
			waits.staticWait(3);
			boolean menuFinancingItem = webActions.isDisplayed(menuFinancing);
			if (menuFinancingItem) {
				wolWebUtil.hoverOnTheElement(menuFinancing);
				LogUtility.logInfo("---> moveToFinancing <---",
						"Mouse move action performed and moved to Financing menu successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("moveToFinancing", "Failed to move cursor to Financing menu", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickMenuBank(String linkName) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(mnuMain)) {
				wolWebUtil.selectLinkFromList(mnuMain, linkName);
				LogUtility.logInfo("---> clickMenuBank <---", "Clicked on Business menu");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickMenuBank", "Failed to click on Business menu", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickCreditCardLink() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(lnkCreditCardNumber)) {
				webActions.clickElement(lnkCreditCardNumber);
				LogUtility.logInfo("---> clickOnApplyNow <---", "Clicked on credit card successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnApplyNow", "Failed to click on credit card link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyCardInfo(List<String> listValue) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(tblCreditCardInfo)) {
				for (int colNum = 0; colNum < tblCardInfo.size(); colNum++) {
					String columnName = tblCardInfo.get(colNum).getText();
					for (int listoption = 0; listoption < listValue.size(); listoption++) {
						String listValues = listValue.get(listoption);
						if (listValues.contains(columnName)) {
							LogUtility.logInfo("---> verifyCardInfo <---", "Verified values from column" + columnName);
						}
					}
				}
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("verifyCardInfo", "Failed to click on credit card link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyElanSiteWindow(String title) {
		boolean flag = false;
		try {
			Set<String> windows = driver.getWindowHandles();
			Iterator<String> itr = windows.iterator();
			String mainWindow = itr.next();
			String childWindow = itr.next();
			driver.switchTo().window(childWindow);
			waits.waitForDOMready();
			String titlePage = driver.getTitle();
			if (titlePage.equals(title)) {
				LogUtility.logInfo("---> verifyElanSiteWindow <---", "Verified payment history successfully");
				flag = true;
			}
			driver.close();
			driver.switchTo().window(mainWindow);

		} catch (Exception e) {
			LogUtility.logException("verifyElanSiteWindow", "Failed to verify Elan Site Window", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean verifyElanSite(String title) {
		boolean flag = false;
		try {
			// Need to wait to load new window
			waits.staticWait(3);
			if (verifyElanSiteWindow(title)) {
				LogUtility.logInfo("---> verifyElanSite <---", "Elan window verified successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyElanSite", "Failed to verify and close Elan site page", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

}
