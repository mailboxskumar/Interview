package com.wb.wol_web.pages;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class EnrollmentPage extends ObjectBase {

	public String user;
	public String ssn;
	public LinkedHashMap<String, String> enrollDetails;

	public EnrollmentPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "div.notification")
	protected WebElement txtCompleteMsg;

	@FindBy(xpath = "//a[contains(text(),'Enroll')]")
	protected WebElement lnkEnroll;

	@FindBy(id = "no_of_years_in_business-8")
	protected WebElement txtBusinessYears;

	@FindBy(name = "sic_industry_id")
	protected WebElement lstIndustry;

	@FindBy(id = "no_of_employees-10")
	protected WebElement txtEmployeesNo;

	@FindBy(id = "banking_p")
	protected WebElement rdbtnPersonal;

	@FindBy(id = "banking_b")
	protected WebElement rdbtnBusiness;

	@FindBy(name = "firstname")
	protected WebElement txtFirstName;

	@FindBy(id = "middlename-2")
	protected WebElement txtMiddleName;

	@FindBy(id = "lastname-3")
	protected WebElement txtLastName;

	@FindBy(id = "address1-5")
	protected WebElement txtAddress1;

	@FindBy(id = "address2-6")
	protected WebElement txtAddress2;

	@FindBy(id = "city-7")
	protected WebElement txtCity;

	@FindBy(id = "zip-9")
	protected WebElement txtZip;

	@FindBy(id = "state")
	protected WebElement lstState;

	@FindBy(id = "ssn")
	protected WebElement txtSSN;

	@FindBy(id = "hphone")
	protected WebElement txtHphone;

	@FindBy(id = "bphone")
	protected WebElement txtBphone;

	@FindBy(id = "dob")
	protected WebElement txtDOB;

	@FindBy(id = "drivers_license_state")
	protected WebElement lstDLState;

	@FindBy(id = "lissuedate-16")
	protected WebElement txtDLIssueDate;

	@FindBy(id = "lexpdate-17")
	protected WebElement txtDLExpiryDate;

	@FindBy(id = "dln-15")
	protected WebElement txtDLNumber;

	@FindBy(id = "email-18")
	protected WebElement txtEmail;

	@FindBy(id = "nusername-1")
	protected WebElement txtUserName;

	@FindBy(id = "password1-2")
	protected WebElement txtPassword;

	@FindBy(id = "password2-3")
	protected WebElement txtCnfrmPassword;

	@FindBy(name = "bus_acct_type")
	protected WebElement lstBusinessAcctType;

	@FindBy(name = "tin")
	protected WebElement txtTIN;

	@FindBy(name = "bus_acct_num")
	protected WebElement txtBusinessAcctNumber;

	@FindBy(id = "account_type")
	protected WebElement lstPersonalAcctType;

	@FindBy(id = "account-20")
	protected WebElement txtPersonalAcctNumber;

	@FindBy(css = "input[type=submit]")
	protected WebElement btnContinue;

	@FindBy(css = "input[id*='A2']")
	protected List<WebElement> rdbtnQuestionnaire2;

	@FindBy(css = "input[id*='A1']")
	protected List<WebElement> rdbtnQuestionnaire1;

	@FindBy(css = "tbody > tr > td:nth-child(1)")
	protected List<WebElement> txtVerifyLabels;

	@FindBy(css = "tbody > tr > td:nth-child(2)")
	protected List<WebElement> txtVerifyValues;

	@FindBy(css = "#continue")
	protected WebElement lnkContinue;

	@FindBy(css = "input[id*='disclosure']")
	protected List<WebElement> chkDisclosures;

	@FindBy(css = "h1[data-wbst-message-key*='enrollment']")
	protected WebElement txtPageTitle;

	@FindBy(css = "ul > li:nth-child(3) > a")
	protected WebElement lnkViewAcctBalances;

	@FindBy(id = "signOutLink")
	protected WebElement lnkSignOut;

	@FindBy(name = "username")
	private WebElement txtUserNameEnroll;

	@FindBy(id = "other_phone1")
	private WebElement txtBusPhone1;

	@FindBy(id = "other_phone2")
	private WebElement txtBusPhone2;

	@FindBy(id = "other_phone3")
	private WebElement txtBusPhone3;

	@FindBy(css = "div[class*='errorInline']")
	private List<WebElement> txtErrMsgs;

	@FindBy(css = "div[class*='errorInline']")
	private WebElement txtErrMsg;

	@FindBy(css = "#business-account-must-exist-message > div")
	private WebElement txtBusEnrollWarning;

	@FindBy(css = "#business-account-must-exist-message > div > a")
	private WebElement lnkClickHere;

	@FindBy(id = "page-title")
	private WebElement txtPageHeader;

	@FindBy(css = "div[class*='errorInline longInput js-input']")
	private WebElement txtExistingUserErr;

	@FindBy(css = "div.errorIndicator > p")
	private WebElement txtPageErrMsg;

	@FindBy(css = "div.ProdBodyBgShadow > div > p")
	private List<WebElement> txtNoteMsgs;

	@FindBy(css = "div.ProdBodyBgShadow > div > p")
	private WebElement txtNoteMsg;

	@FindBy(css = "div.ProdNameDisplay2")
	private List<WebElement> txtStepNames;

	@FindBy(css = "div.note")
	private WebElement txtAuthNote;

	@FindBy(css = "#pageContent > p:nth-child(3)")
	private WebElement txtAuthContentTwo;

	@FindBy(css = "div.midTopHeadingHolder > div > div > p")
	private WebElement txtAuthContentOne;

	@FindBy(css = "div.midTopHeadingHolder > div > div > p")
	private List<WebElement> txtContents;

	@FindBy(css = "#pageContent > p:nth-child(1)")
	private WebElement txtCustAuthContent;

	@FindBy(css = "a[alt=OK]")
	private WebElement lnkOK;

	@FindBy(css = "div.errorIndicator")
	private WebElement txtQuestionnaireErr;

	@FindBy(id = "edit")
	private WebElement lnkEdit;

	@FindBy(css = "span.tooltip")
	private WebElement txtTooltip;

	@FindBy(css = "#pageContent > ul > li > a")
	private WebElement lnkReturn;

	@FindBy(css = "div.formRow > div >span")
	private WebElement txtStartNote;

	/**
	 * clickOnEnrollLink: To Click on Enroll Link
	 */
	public void clickOnEnrollLink() {
		try {
			waits.waitUntilElementIsPresent(lnkEnroll);
			webActions.clickElementJS(lnkEnroll);
			LogUtility.logInfo("clickOnEnrollLink", "Clicked on Enroll Link");
		} catch (Exception e) {
			LogUtility.logException("clickOnEnrollLink", "Failed to Click on Enroll Link", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickOnProfileType: To select user role to enroll
	 * 
	 * @param ProfileType
	 */
	public void clickOnProfileType(String profileType) {
		try {
			waits.waitUntilElementIsPresent(rdbtnPersonal);
			if (profileType.equalsIgnoreCase("Personal"))
				webActions.clickElement(rdbtnPersonal);
			else
				webActions.clickElement(rdbtnBusiness);
			LogUtility.logInfo("clickOnProfileType", "Selected User role to enroll");
		} catch (Exception e) {
			LogUtility.logException("clickOnProfileType", "Failed to Select User role to enroll", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * clickOnContinuebutton: To Click on continue button
	 */
	public void clickOnContinueButton() {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(btnContinue))
				webActions.clickElementJS(btnContinue);
			else if (waits.waitUntilElementIsPresent(lnkContinue, maxTimeOut)) {
				waits.waitToBeClickable(lnkContinue, maxTimeOut.intValue());
				webActions.clickElementJS(lnkContinue);
			}
			waits.staticWait(5); // Taking time to load next page in Firefox and IE browsers
			waits.waitForDOMready();
			LogUtility.logInfo("clickOnContinuebutton", "Clicked on Continue Button");
		} catch (Exception e) {
			LogUtility.logException("clickOnContinuebutton", "Failed to Click on Continue Button", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * enterUserPersonalInfo
	 */
	public boolean enterUserPersonalInfo(Map<String, String> personalInfo) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtSSN);
			webActions.setValue(txtFirstName, personalInfo.get("First Name"));
			webActions.setValue(txtMiddleName, personalInfo.get("Middle Initial"));
			webActions.setValue(txtLastName, personalInfo.get("Last Name"));
			webActions.setValue(txtAddress1, personalInfo.get("Street Address"));
			webActions.setValue(txtAddress2, personalInfo.get("Street Address Line 2"));
			webActions.setValue(txtCity, personalInfo.get("City"));
			webActions.selectDropDownByValueJs(lstState, personalInfo.get("State"));
			webActions.setValue(txtZip, personalInfo.get("Zip"));
			webActions.setValue(txtHphone, personalInfo.get("Home Phone"));
			webActions.setValue(txtBphone, personalInfo.get("Office Phone"));
			ssn = personalInfo.get("Social Security #");
			if (ssn.equalsIgnoreCase("random")) {
				ssn = wolWebUtil.getRandomNumber(9);
				webActions.setValue(txtSSN, ssn);
			} else
				webActions.setValue(txtSSN, ssn);
			webActions.setValueJs(txtDOB, personalInfo.get("Date of Birth"));
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtSSN, "value").equalsIgnoreCase(ssn)) {
				flag = true;
				LogUtility.logInfo("enterUserPersonalInfo", "Entered personal Information to enroll a user");
			} else
				LogUtility.logInfo("enterUserPersonalInfo", "Failed to Enter personal Information to enroll a user");
		} catch (Exception e) {
			LogUtility.logException("enterUserPersonalInfo", "Failed to Enter personal Information to enroll a user", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * enterUserDriverLicenseInfo
	 */
	public boolean enterUserDriverLicenseInfo(Map<String, String> dlInfo) {
		boolean flag = false;
		try {
			webActions.selectDropDownByValueJs(lstDLState, dlInfo.get("Driver's License state"));
			webActions.setValue(txtDLNumber, dlInfo.get("Driver's License #"));
			webActions.setValueJs(txtDLIssueDate, dlInfo.get("License Issue date"));
			webActions.setValueJs(txtDLExpiryDate, dlInfo.get("License Expiration Date"));
			webActions.setValue(txtEmail, dlInfo.get("Email Address"));
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtEmail, "value").equalsIgnoreCase(dlInfo.get("Email Address"))) {
				flag = true;
				LogUtility.logInfo("enterUserDriverLicenseInfo", "Entered Driver License Information to enroll a user");
			} else
				LogUtility.logInfo("enterUserDriverLicenseInfo",
						"Failed to Enter Driver License Information to enroll a user");
		} catch (Exception e) {
			LogUtility.logException("enterUserDriverLicenseInfo",
					"Failed to Enter Driver License Information to enroll a user", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * enterBusinessInformation
	 */
	public boolean enterBusinessInformation(Map<String, String> busInfo) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtEmployeesNo);
			if (txtBusPhone1.isDisplayed()) {
				webActions.setValueJs(txtBusPhone1, wolWebUtil.getRandomNumber(3));
				webActions.setValueJs(txtBusPhone2, wolWebUtil.getRandomNumber(3));
				webActions.setValueJs(txtBusPhone3, wolWebUtil.getRandomNumber(4));
			}
			webActions.selectDropDownByValueJs(lstIndustry, busInfo.get("Industry"));
			webActions.setValueJs(txtBusinessYears, busInfo.get("Years In Business"));
			String employees = busInfo.get("# of Employees");
			webActions.setValueJs(txtEmployeesNo, employees);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtEmployeesNo, "value").equalsIgnoreCase(employees)) {
				flag = true;
				LogUtility.logInfo("enterBusinessInformation", "Entered Business Information to enroll user");
			} else
				LogUtility.logInfo("enterBusinessInformation", "Failed to Enter Business Information to enroll user");
		} catch (Exception e) {
			LogUtility.logException("enterBusinessInformation", "Failed to Enter Business Information to enroll user",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * enterUserAccountInfo
	 */
	public void enterUserAccountInfo(Map<String, String> accountInfo) {
		try {
			if (waits.waitUntilElementIsPresent(txtPersonalAcctNumber)) {
				webActions.selectDropDownByValueJs(lstPersonalAcctType, accountInfo.get("Account Type"));
				webActions.setValue(txtPersonalAcctNumber, accountInfo.get("Webster Bank Account #"));
			} else if (waits.waitUntilElementIsPresent(txtBusinessAcctNumber)) {
				webActions.setValue(txtTIN, accountInfo.get("Taxpayer ID#"));
				webActions.selectDropDownByValueJs(lstBusinessAcctType, accountInfo.get("Account Type"));
				webActions.setValue(txtBusinessAcctNumber, accountInfo.get("Business Account #"));
			}
			LogUtility.logInfo("enterUserAccountInfo", "Entered Account Information to enroll a user");
		} catch (Exception e) {
			LogUtility.logException("enterUserAccountInfo", "Failed to Enter Account Information to enroll a user", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * selectEmulatorQuestions:
	 */
	public void selectEmulatorQuestions(Map<String, String> emulatorInfo) {
		try {
			waits.waitForDOMready();
			for (WebElement question1 : rdbtnQuestionnaire1) {
				String value = webActions.getAttributeValue(question1, "value");
				if (value.equalsIgnoreCase(emulatorInfo.get("qusetion1"))) {
					webActions.clickElementJS(question1);
					break;
				}
			}
			waits.waitForDOMready();
			for (WebElement question2 : rdbtnQuestionnaire2) {
				String value = webActions.getAttributeValue(question2, "value");
				if (value.equalsIgnoreCase(emulatorInfo.get("question2"))) {
					webActions.clickElementJS(question2);
					break;
				}
			}
			LogUtility.logInfo("selectEmulatorQuestions", "Selected Emulator questions");
		} catch (Exception e) {
			LogUtility.logException("selectEmulatorQuestions", "Failed to Select Emulator questions", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * enterUserCredentails
	 */
	public boolean enterUserCredentails(Map<String, String> userInfo) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtUserName);
			user = userInfo.get("User Name");
			if (user.equalsIgnoreCase("random")) {
				user = wolWebUtil.getRandomString(9);
				webActions.setValue(txtUserName, user);
			} else
				webActions.setValue(txtUserName, user);
			webActions.setValue(txtPassword, userInfo.get("Password"));
			webActions.setValue(txtCnfrmPassword, userInfo.get("CnfrmPassword"));
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtUserName, "value").equalsIgnoreCase(user)) {
				flag = true;
				LogUtility.logInfo("enterUserCredentails", "Entered User Credentials");
			} else
				LogUtility.logInfo("enterUserCredentails", "Failed to Enter User Credentials");
		} catch (Exception e) {
			LogUtility.logException("enterUserCredentails", "Failed to Enter User Credentials", e, LoggingLevel.ERROR,
					true);
		}
		setValueInRuntimeDataMap("enrollmentUser", user);
		return flag;
	}

	/**
	 * selectDisclosures
	 */
	public boolean selectDisclosures() {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			for (WebElement disclosure : chkDisclosures) {
				webActions.clickElementJS(disclosure);
				waits.waitForDOMready();
				if (webActions.isChecked(disclosure))
					flag = true;
				else
					flag = false;
			}
			LogUtility.logInfo("selectDisclosures", "Selected Disclosure agreements for a User to Enroll");
		} catch (Exception e) {
			LogUtility.logException("selectDisclosures", "Failed to Select Disclosure agreements for a User to Enroll",
					e, LoggingLevel.ERROR, true);
			flag = false;
		}
		return flag;
	}

	/**
	 * getEnrollmentDetails
	 */
	public void getEnrollmentDetails() {
		try {
			enrollDetails = new LinkedHashMap<String, String>();
			for (int i = 0; i < txtVerifyLabels.size(); i++)
				enrollDetails.put(txtVerifyLabels.get(i).getText(), txtVerifyValues.get(i).getText());
			LogUtility.logInfo("getEnrollmentDetails", "Retrieved all the Enrollment details");
		} catch (Exception e) {
			LogUtility.logException("getEnrollmentDetails", "Failed to Retrieve all the Enrollment details", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * verifyMsg: To verify the content in Verification page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyEnrollmentPageTitles(String message) {
		for (int i = 0; i < 10; i++) {
			boolean flag = wolWebUtil.verifyText(txtPageTitle, message, "verifyEnrollmentPageTitles");
			if (flag == false)
				waits.staticWait(3);
			else
				break;
		}
		return wolWebUtil.verifyText(txtPageTitle, message, "verifyEnrollmentPageTitles");
	}

	/**
	 * verifyEnrollmentConfirmationMsg: To verify the content in confirmation page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyEnrollmentConfirmationMsg(String message) {
		return wolWebUtil.verifyText(txtCompleteMsg, message, "verifyEnrollmentConfirmationMsg");
	}

	/**
	 * clickOnAcctBalancesLink: To Click on View Account Balances Link
	 */
	public boolean clickOnAcctBalancesLink() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkViewAcctBalances);
			webActions.clickElementJS(lnkViewAcctBalances);
			if (waits.waitUntilElementIsPresent(lnkSignOut)) {
				flag = true;
				LogUtility.logInfo("clickOnAcctBalancesLink", "Clicked on View Account Balances Link");
			} else
				LogUtility.logInfo("clickOnAcctBalancesLink", "Failed to Click on View Account Balances Link");
		} catch (Exception e) {
			LogUtility.logException("clickOnAcctBalancesLink", "Failed to Click on View Account Balances Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter Username
	 * 
	 * @param userName
	 */
	public boolean enterUserName() {
		boolean flag = false;
		try {
			webActions.setValue(txtUserNameEnroll, user);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtUserNameEnroll, "value").equalsIgnoreCase(user)) {
				flag = true;
				LogUtility.logInfo("---> enterUserName <---", "Entered the username " + user);
			} else
				LogUtility.logInfo("---> enterUserName <---", "Failed to Enter the username ");
		} catch (Exception e) {
			LogUtility.logException("enterUserName", "Failed to Enter the username ", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyWarningMessage: To verify the Business warning message in Start page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyWarningMessage(Map<String, String> message) {
		return wolWebUtil.verifyText(txtBusEnrollWarning, message.get("Message"), "verifyWarningMessage");
	}

	/**
	 * verifyPageHeader: To verify Page Headers of Enrollment Pages
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyPageHeader(Map<String, String> message) {
		return wolWebUtil.verifyText(txtPageHeader, message.get("Title"), "verifyPageHeader");
	}

	/**
	 * clickOnHereLink: To Click on Click Here Link
	 */
	public void clickOnHereLink() {
		try {
			waits.waitUntilElementIsPresent(lnkClickHere);
			webActions.clickElementJS(lnkClickHere);
			LogUtility.logInfo("clickOnHereLink", "Clicked on Click Here Link");
		} catch (Exception e) {
			LogUtility.logException("clickOnHereLink", "Failed to Click on Click Here Link", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
	}

	/**
	 * verifyEnrollmentErrMessage: To verify the error message in Enrollment
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyEnrollmentErrMessage(Map<String, String> message) {
		return wolWebUtil.verifyText(txtErrMsg, message.get("Message"), "verifyEnrollmentErrMessage");
	}

	/**
	 * verifyAlreadyEnrollErrMessage: to verify the Existing user error message
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyAlreadyEnrollErrMessage(Map<String, String> message) {
		return wolWebUtil.verifyText(txtExistingUserErr, message.get("Message"), "verifyAlreadyEnrollErrMessage");
	}

	/**
	 * verifyPageErrMessage: To verify the page level error message
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyPageErrMessage(Map<String, String> message) {
		return wolWebUtil.verifyText(txtPageErrMsg, message.get("Page Error"), "verifyPageErrMessage");
	}

	/**
	 * verifyListMesagses: To verify the List of error messages in Enrollment
	 * 
	 * @param            elements- List of WebElement
	 * @param message
	 * @param keyName
	 * @param methodName
	 * @return
	 */
	public boolean verifyListMesagses(List<WebElement> elements, Map<String, String> message, String keyName,
			String methodName) {
		boolean flag = false;
		int count = 0;
		try {
			waits.waitForDOMready();
			String[] value = message.get(keyName).split(";");
			for (WebElement element : elements) {
				String text = element.getText();
				if (text.equalsIgnoreCase(value[count]))
					count = count + 1;
			}
			if (count == elements.size()) {
				flag = true;
				LogUtility.logInfo(methodName + ": Text verified Successfully " + message.get(keyName));
			} else
				LogUtility.logInfo(methodName + ":Text not verified " + message.get(keyName));

		} catch (Exception e) {
			LogUtility.logException("" + methodName + "", "Failed to Verify the text", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyTooltip: To verify the tooltip text
	 * 
	 * @param element
	 * @param message
	 * @param keyName
	 * @param methodName
	 * @return
	 */
	public boolean verifyTooltip(WebElement element, Map<String, String> message, String keyName, String methodName) {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			String text = webActions.getAttributeValue(element, "data-title");
			if (text.equalsIgnoreCase(message.get(keyName))) {
				flag = true;
				LogUtility.logInfo(methodName + ": Text verified Successfully " + message.get(keyName));
			} else
				LogUtility.logInfo(methodName + ":Text not verified " + message.get(keyName));
		} catch (Exception e) {
			LogUtility.logException("" + methodName + "", "Failed to Verify the text", e, LoggingLevel.ERROR, true);
		}
		return flag;

	}

	/**
	 * verifyPasswordTooltip: To verify the password tooltip text
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyPasswordTooltip(Map<String, String> message) {
		return verifyTooltip(txtTooltip, message, "Tooltip", "verifyPasswordTooltip");
	}

	/**
	 * verifyStepNames: To verify the step number labels
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyStepNames(Map<String, String> message) {
		return verifyListMesagses(txtStepNames, message, "Step Name", "verifyStepNames");
	}

	/**
	 * verifyMissingInfoErrMsgs: To verify the list of Missing info error messages
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyMissingInfoErrMsgs(Map<String, String> message) {
		return verifyListMesagses(txtErrMsgs, message, "Message", "verifyMissingInfoErrMsgs");
	}

	/**
	 * verifyNoteMsgs: To verify the Note messages in a page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNoteMsgs(Map<String, String> message) {
		return verifyListMesagses(txtNoteMsgs, message, "Note", "verifyNoteMsgs");
	}

	/**
	 * verifyAuthNote:To verify note in Authorization page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyAuthNote(Map<String, String> message) {
		return wolWebUtil.verifyText(txtAuthNote, message.get("Note"), "verifyAuthNote");
	}

	/**
	 * verifyReEnterAccountNote: To verify note message in Re enter account
	 * information page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyReEnterAccountNote(Map<String, String> message) {
		return wolWebUtil.verifyText(txtNoteMsg, message.get("Note"), "verifyAuthNote");
	}

	/**
	 * verifyStartPageNote: To verify the note message in Start page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyStartPageNote(Map<String, String> message) {
		return wolWebUtil.verifyText(txtStartNote, message.get("Note"), "verifyStartPageNote");
	}

	/**
	 * verifyAuthContentMsgOne: To verify content
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyAuthContentMsgOne(Map<String, String> message) {
		return wolWebUtil.verifyText(txtAuthContentOne, message.get("Content One"), "verifyAuthContentMsgOne");
	}

	/**
	 * verifyAuthContentMsgOne: To verify content
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyAuthContentMsgTwo(Map<String, String> message) {
		return wolWebUtil.verifyText(txtAuthContentTwo, message.get("Content Two"), "verifyAuthContentMsgTwo");
	}

	/**
	 * verifyInfoContentMsg:To veify content of verify Info Page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyInfoContentMsg(Map<String, String> message) {
		return wolWebUtil.verifyText(txtAuthContentOne, message.get("Verify Content"), "verifyInfoContentMsg");
	}

	/**
	 * verifyInfoContentMsgs:To veify contents of verify Info Page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyInfoContentMsgs(Map<String, String> message) {
		return verifyListMesagses(txtContents, message, "Verify Content", "verifyInfoContentMsgs");
	}

	/**
	 * verifyCustAuthContentMsg: To verify page content
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyCustAuthContentMsg(Map<String, String> message) {
		return wolWebUtil.verifyText(txtCustAuthContent, message.get("Content"), "verifyCustAuthContentMsg");
	}

	/**
	 * verifyQuestionnaireErr: To verify the emulator Question error message
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyQuestionnaireErr(Map<String, String> message) {
		return wolWebUtil.verifyText(txtQuestionnaireErr, message.get("Questionnaire"), "verifyQuestionnaireErr");
	}

	/**
	 * verifyEnrollmentDetails: To verify the Enrollment details
	 * 
	 * @return
	 */
	public boolean verifyEnrollmentDetails() {
		return wolWebUtil.mapValuesComaparison(enrollDetails, testDataMap);
	}

	/**
	 * clickOnOKLink: To Click on OK Link
	 */
	public void clickOnOKLink() {
		try {
			waits.waitUntilElementIsPresent(lnkOK, maxTimeOut);
			webActions.clickElementJS(lnkOK);
			waits.waitForDOMready();
			waits.staticWait(5);// Taking time to load next page in Firefox and IE browsers
			LogUtility.logInfo("clickOnOKLink", "Clicked on OK Link");
		} catch (Exception e) {
			LogUtility.logException("clickOnOKLink", "Failed to Click  Ok Link", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickOnEditLink: To Click on Edit Link
	 */
	public void clickOnEditLink() {
		try {
			waits.waitUntilElementIsPresent(lnkEdit);
			webActions.clickElementJS(lnkEdit);
			LogUtility.logInfo("clickOnEditLink", "Clicked on Edit Link");
		} catch (Exception e) {
			LogUtility.logException("clickOnEditLink", "Failed to Click  Edit Link", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickOnReturnLink: To Click on Return Link
	 */
	public void clickOnReturnLink() {
		try {
			waits.waitUntilElementIsPresent(lnkReturn);
			webActions.clickElementJS(lnkReturn);
			LogUtility.logInfo("clickOnReturnLink", "Clicked on Return Link");
			waits.staticWait(5); // Taking time to load next page in Firefox and IE browsers
		} catch (Exception e) {
			LogUtility.logException("clickOnReturnLink", "Failed to Click  Return Link", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

}
