package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author: Ravi kumar Maddula
 *
 */

public class ExportTransactionsPage extends ObjectBase {

	public ExportTransactionsPage() {
		PageFactory.initElements(driver, this);
	}

	public String fromDt = "";
	public String toDate = "";
	public String dateVal = "";

	@FindBy(id = "account_select__input")
	protected WebElement selAccount;

	@FindBy(id = "export_type__input")
	protected WebElement selFormat;

	@FindBy(id = "dateRange__input")
	protected WebElement selTimePeriod;

	@FindBy(xpath = "//*[@id='from_date__dateInput']/input[2]")
	protected WebElement txtFromDate;

	@FindBy(xpath = "//*[@id='to_date__dateInput']/input[2]")
	protected WebElement txtToDate;

	@FindBy(xpath = "//*[@id='submit_button__actualButton']")
	protected WebElement btnContinue;

	@FindBy(xpath = "//*[@data-mm-template='pageTitle']")
	protected WebElement pageHeading;

	@FindBy(xpath = "//*[@id='bodyContent']//h1")
	protected WebElement txtHeader;

	@FindBy(xpath = "//*[@id='transactionPreview']")
	protected WebElement tblTransctions;

	@FindBy(xpath = "//*[@id='continue']")
	protected WebElement btnExport;

	@FindBy(xpath = "//*[@id='transactionPreview']")
	protected WebElement tblPreview;

	@FindBy(xpath = "//*[@id='export-history-landing__pageErrors__EXPORT-NO-HISTORY__body']")
	protected WebElement txtError;

	@FindBy(xpath = "//*[@id='transactionPreview']/tbody/tr/td[2]")
	protected List<WebElement> tblDateColumn;

	@FindBy(xpath = "//*[@id='accountNav__submenu-title']")
	protected WebElement selectAcc;

	@FindBy(id = "accountNav__list")
	protected WebElement selectAccList;

	@FindBy(id = "dateRange__input")
	protected WebElement lstDateRange;

	@FindBy(id = "from_date__input")
	protected WebElement txtfromDt;

	@FindBy(id = "from_date__calendar-button")
	protected WebElement btnfromDate;

	@FindBy(id = "to_date__input")
	protected WebElement txttoDt;

	@FindBy(id = "to_date__calendar-button")
	protected WebElement btnToDate;

	@FindBy(id = "date_range_submit_button__actualButton")
	protected WebElement btnUpdate;

	@FindBy(id = "export_transactions__submenu-title")
	protected WebElement lstDownload;

	@FindBy(xpath = "//*[@id='export_transactions__list']")
	protected WebElement lstExportTransactions;

	@FindBy(xpath = "//*[@id='transaction-history__pageTitle']")
	protected WebElement txtTransPageHeader;

	@FindBy(xpath = "//*[@id='clearAll']")
	protected WebElement lnkClearAll;

	@FindBy(xpath = "//table[@id='transactionPreview']/tbody/tr/td[1]/input")
	protected WebElement chkTansaction;

	@FindBy(xpath = "//ul[@id='pending_transactions__body']")
	protected WebElement lstPendingTrans;

	@FindBy(xpath = "//section[@id='pending_transactions']/ul/li[1]/span[1]")
	protected WebElement txtValPendingTrans;

	@FindBy(xpath = "//table[@id='transactionPreview']/thead")
	protected WebElement tblPendingTransHead;

	@FindBy(xpath = "//table[@id='transactionPreview']/tbody")
	protected WebElement tblPendingTransBody;

	@FindBy(xpath = "//p[@id='from_date__error-message-text']")
	protected WebElement txtFromdateError;

	@FindBy(xpath = "//p[@id='to_date__error-message-text']")
	protected WebElement txtTodateError;

	@FindBy(xpath = "//div[@id='export-history-landing__pageErrors__EXPORT-NO-HISTORY__body']")
	protected WebElement txtTransError;

	@FindBy(id = "export-history-landing__pageNote__body")
	protected WebElement txtPageHead;

	@FindBy(xpath = "//div[@id='pageContent']/div[2]/div")
	protected WebElement txtPeriodError;

	@FindBy(xpath = "//div[@id='pageContent']/div[1]/div")
	protected WebElement txtDaysError;

	@FindBy(id = "accountNav__submenu-title-content")
	protected WebElement txtDefaultAcct;
	
	@FindBy(id = "cancel_button")
	protected WebElement btnCancel;
	
	@FindBy(id = "doNotCancelButton")
	protected WebElement btnNotCancel;
	
	@FindBy(id = "confirmCancelButton")
	protected WebElement btnConfirmCancel;
	
	@FindBy(css = "tr:nth-child(2) td table tbody tr  td  table  thead tr th")
	protected List<WebElement> lblTransFields;
	
	

	String noResultsError = "There are no transactions for the time period selected. Please select a different time period.";

	/**
	 * checkThePageHeading - To check the page heading
	 * 
	 */
	public boolean checkThePageHeading(String text) {
		try {
			waits.staticWait(2);
			return wolWebUtil.verifyText(pageHeading, text);
		} catch (Exception e) {
			LogUtility.logException("checkThePageHeading", "Page Heading is not verified", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkTransPreviewHeading -To check the transaction preview heading
	 * 
	 */
	public boolean checkTransPreviewHeading(String text) {
		try {
			return wolWebUtil.verifyText(txtHeader, text);
		} catch (Exception e) {
			LogUtility.logException("checkTransPreviewHeading", "Transaction Preview Heading is not verified", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * checkTransHistoryHeading -To check the transaction history heading
	 * 
	 * @return
	 */
	public boolean checkTransHistoryHeading(String text) {
		try {
			return wolWebUtil.verifyText(txtTransPageHeader, text);
		} catch (Exception e) {
			LogUtility.logException("checkTransHistoryHeading", "Transaction History Heading is not verified", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * selectAccount- To select account drop down
	 * 
	 * @return flag
	 */
	public boolean selectAccount(String account) {
		boolean flag = false;
		try {
			wolWebUtil.selectValueByPartialVisibleText(selAccount, account);
			LogUtility.logInfo("---> selectAccount <---", "Selected " + account + " from dropdown");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("selectAccount", "Account is not selected", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnAccount- To click the account
	 * 
	 */
	public void clickOnAccount() {
		try {
			webActions.clickElement(selectAcc);
			LogUtility.logInfo("---> clickOnAccount <---", "Clicked on Account dropdown");
		} catch (Exception e) {
			LogUtility.logException("clickOnAccount", "Account is not clicked", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectCheckAccount-To select default account from drop down
	 * 
	 * @return flag
	 */
	public boolean selectCheckAccount(String account) {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			if (txtDefaultAcct.getText().contains(account)) {
				LogUtility.logInfo("---> selectAccount <---", "Selected default " + account + " from dropdown");
				flag = true;
			} else {
				if (webActions.isDisplayed(selectAccList)) {
					wolWebUtil.selectListValue(selectAccList, account);
					LogUtility.logInfo("---> selectAccount <---", "Selected " + account + " from dropdown");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("selectCheckAccount", "Failed to select account", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectFormat - To select format from drop down
	 * 
	 * @return flag
	 */
	public boolean selectFormat(String format) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(selFormat)) {
				webActions.selectDropDownByText(selFormat, format);
				LogUtility.logInfo("---> selectFormat <---", "Selected " + format + " from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFormat", "Failed to select format", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectTimePeriod- To select time period from drop down
	 * 
	 * @return flag
	 */
	public boolean selectTimePeriod(String period) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(selTimePeriod)) {
				webActions.selectDropDownByText(selTimePeriod, period);
				LogUtility.logInfo("---> selectTimePeriod <---", "Selected " + period + " from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectTimePeriod", "Failed to select time period", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectPreviousStatement- To select previousStatement from drop down
	 * 
	 * @return flag
	 */
	public boolean selectPreviousStatement() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(selTimePeriod)) {
				wolWebUtil.selectByTextContains(selTimePeriod);
				LogUtility.logInfo("---> selectpreviousStatement <---", "Selected previous statement from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectPreviousStatement", "Failed to select Previous Statement", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectDateRange- To select DateRange from drop down
	 * 
	 * @return flag
	 */
	public boolean selectDateRange(String range) {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			webActions.isDisplayed(lstDateRange);
			webActions.selectDropDownByText(lstDateRange, range);
			LogUtility.logInfo("---> selectDaterange <---", "Selected " + range + " from dropdown");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("selectDateRange", "Failed to select Date Range", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * enterFromDate - To enter FromDate from drop down
	 * 
	 * @return fromDt
	 */
	public String enterFromDate(String day) {
		try {
			fromDt = wolWebUtil.getOldDate(day);
			webActions.setValue(txtfromDt, fromDt);
			LogUtility.logInfo("---> enterFromDate <---", "Entered " + fromDt + " from dropdown");
		} catch (Exception e) {
			LogUtility.logException("enterFromDate", "Failed to enter From Date", e, LoggingLevel.ERROR, true);
		}
		return fromDt;

	}

	/**
	 * enterToDate -To enter ToDate from drop down
	 * 
	 * @return toDate
	 */
	public String enterToDate(String day) {
		try {
			toDate = wolWebUtil.getOldDate(day);
			webActions.setValue(txttoDt, toDate);
			LogUtility.logInfo("---> enterFromDate <---", "Entered " + toDate + " from dropdown");
		} catch (Exception e) {
			LogUtility.logException("enterToDate", "Failed to enter To Date", e, LoggingLevel.ERROR, true);
		}
		return toDate;
	}

	/**
	 * clickOnContinueButton-To click on Continue button
	 */
	public void clickOnContinueButton() {
		try {
			webActions.clickElement(btnContinue);
			LogUtility.logInfo("---> clickOnContinueButton <---", "Clicked on continue button");
		} catch (Exception e) {
			LogUtility.logException("clickOnContinueButton", "Failed to click on Continue button", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * clickOnClearAll- To click on ClearAll link return flag
	 */
	public boolean clickOnClearAll() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(lnkClearAll)) {
				webActions.clickElement(lnkClearAll);
				// Taking time to uncheck all the check boxes boxes at a time
				waits.staticWait(1);
				LogUtility.logInfo("---> clickOnClearAll <---", "Clicked on clear all link");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("clickOnClearAll", "Failed to click on Clear all", e, LoggingLevel.ERROR, true);
		}
		return flag;

	}

	/**
	 * selectTransactions - To select transaction
	 * 
	 * @return flag
	 */
	public boolean selectTransactions() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(chkTansaction)) {
				webActions.clickElement(chkTansaction);
				LogUtility.logInfo("---> selectTransactions <---", "Selected record from transaction preview table");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectTransactions", "Failed to select transaction", e, LoggingLevel.ERROR, true);
		}
		return flag;

	}

	/**
	 * clickOnExportButton - To click on Export button
	 * 
	 * @return flag
	 */
	public boolean clickOnExportButton() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(btnExport)) {
				webActions.clickElement(btnExport);
				// File downloading is taking time, so added static wait
				waits.staticWait(5);
				LogUtility.logInfo("---> clickOnContinueButton <---", "Clicked on Export button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnExportButton", "Failed to click on Export button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * verifyDateRangeFromTable - To check date range from table
	 * 
	 * @return flag
	 */
	public boolean verifyDateRangeFromTable() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(tblPreview)) {
				wolWebUtil.verifyDateInWebTable(tblDateColumn, fromDt, toDate);
				LogUtility.logInfo("---> verifyDateRangeFromTable <---", "Verified table data");
				flag = true;
			}

		} catch (Exception e) {
			if (webActions.isDisplayed(txtError)) {
				if (webActions.getText(txtError).contains(noResultsError)) {
					LogUtility.logException("verifyDateRangeFromTable",
							"Transactions table is not available,Error validated", e, LoggingLevel.ERROR, true);
				}
			}
			LogUtility.logException("verifyDateRangeFromTable", "Failed to verify export transactions table data", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyFromDateDisable - To check From Date disable or not
	 * 
	 * @return flag
	 */
	public boolean verifyFromDateDisable() {
		boolean flag = false;
		try {
			fromDt = wolWebUtil.convertDateFormat(webActions.getAttributeValue(txtFromDate, "value"));
			if (webActions.isDisabled(btnfromDate)) {
				LogUtility.logInfo("---> fromDateDisable <---", "From Calender icon disabled and passed");
				flag = true;
			} else {
				LogUtility.logInfo("---> fromDateDisable <---", "From Calender icon Enabled and failed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFromDateDisable", "Failed to verify calender icon ", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * verifyToDateDisable -To check To Date is disable or not
	 * 
	 * @return flag
	 */
	public boolean verifyToDateDisable() {
		boolean flag = false;
		try {
			toDate = wolWebUtil.convertDateFormat(webActions.getAttributeValue(txtToDate, "value"));
			if (webActions.isDisabled(btnToDate)) {
				LogUtility.logInfo("---> toDateDisable <---", "To Calender icon disabled and passed");
				flag = true;
			} else {
				LogUtility.logInfo("---> toDateDisable <---", "To Calender icon Enabled and failed");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyToDateDisable", "Failed to verify calender icon ", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * clickOnDownLoad - Clicking on Download drop down
	 * 
	 */
	public void clickOnDownLoad() {
		try {
			webActions.clickElement(lstDownload);
			// Taking time to display list values
			waits.staticWait(1);
			LogUtility.logInfo("---> lstDownload <---", "Clicked on Down load dropdown");
		} catch (Exception e) {
			LogUtility.logException("clickOnDownLoad", "Failed to click on DownLoad drop down ", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * verifyDownLoadListValues- To check values from download
	 * 
	 * @return flag
	 */
	public boolean verifyDownLoadListValues(List<String> values) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(lstExportTransactions)) {
				wolWebUtil.verifyListValues(lstExportTransactions, values);
				LogUtility.logInfo("---> verifyDownLoadListValues <---", "Verified values from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDownLoadListValues", "Failed to verify values from download ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectValueFromList - To select value from From drop down
	 * 
	 * @return flag
	 */
	public boolean selectValueFromList(String downloadValue) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(lstExportTransactions)) {
				wolWebUtil.selectLinkFromList(lstExportTransactions, downloadValue);
				waits.waitUntilElementIsPresent(txtHeader, 10);
				LogUtility.logInfo("---> selectValueFromList <---", "Selected " + downloadValue + " from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectValueFromList", "Failed to select value", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyFileData - To verify File data
	 * 
	 * @return flag
	 */
	public boolean verifyFileData(String file, String extension) {
		boolean flag = false;
		try {
			if (wolWebUtil.verifyFileContent(file, extension)) {
				LogUtility.logInfo("---> verifyFileData <---", "Verified downloaded file content successfully ");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFileData", "Failed to verify file data", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyFileIsEmpty - To verify File is empty or not
	 *
	 * 
	 * @return flag
	 */
	public boolean verifyFileIsEmpty(String file, String extension) {
		boolean flag = false;
		try {
			if (wolWebUtil.verifyFileContent(file, extension)) {
				LogUtility.logError("---> verifyFileIsEmpty <---", "Failed to verify downloaded file");
			} else {
				LogUtility.logInfo("---> verifyFileIsEmpty <---",
						"Verified downloaded file successfully and file is empty ");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFileIsEmpty", "Failed to verify downloaded file", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * clickOnUpdateButton - To click on Update button
	 * 
	 * @return flag
	 */
	public boolean clickOnUpdateButton() {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(btnUpdate)) {
				webActions.clickElement(btnUpdate);
				LogUtility.logInfo("---> clickOnUpdateButton <---", "Clicked on update button");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("clickOnUpdateButton", "Failed to click on update button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * verifyPendingTarnsactions - To Check Pending Transactions
	 * 
	 * @return flag
	 */
	public boolean verifyPendingTarnsactions() {
		boolean flag = false;
		try {
			try {
				if (webActions.isDisplayed(lstPendingTrans)) {
					LogUtility.logInfo("---> verifyPendingTarnsactions <---",
							"Verified pending transction are available");
					String dateValue = webActions.getText(txtValPendingTrans);
					String value[] = dateValue.split(" ");
					dateVal = value[0];
					LogUtility.logInfo("---> verifyPendingTarnsactions <---",
							"Pending transaction date value is" + dateVal);
					flag = true;
				}
			} catch (Exception e) {
				LogUtility.logException("verifyPendingTarnsactions", "Failed to Verify pending transactions", e,
						LoggingLevel.ERROR, true);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPendingTarnsactions", "Failed to Verify pending transactions", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyPendingTransactionTable - To verify Pending Transaction Table
	 * 
	 * @return flag
	 */
	public boolean verifyPendingTransactionTable() {
		boolean flag = true;
		try {
			if (wolWebUtil.verifyTableResults(tblPendingTransHead, tblPendingTransBody,
					"Date Sort Ascending Sort Descending", dateVal)) {
				LogUtility.logError("---> Failed -  pending transactions available in table<---");
				flag = false;
			} else {
				LogUtility.logInfo("---> verifyPendingTransactionTable <---",
						"Verified pending transctions are not available in table");
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPendingTransactionTable", "Failed to Verify pending transactions", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyDefaultValues - Verify Default values from Account,Format and Time
	 * Period
	 * @return flag
	 */
	public boolean verifyDefaultValues(String account, String format, String timePeriod) {
		boolean flag = false;
		try {
			String accountVal = wolWebUtil.getDefaultValueForSelect(selAccount);
			if (accountVal.contains(account)) {
				LogUtility.logInfo("---> verifyDefaultValues <---",
						"Verified default value from account dropdown. Default value is --" + accountVal);
			}
			String formatVal = wolWebUtil.getDefaultValueForSelect(selFormat);
			if (formatVal.equals(format)) {
				LogUtility.logInfo("---> verifyDefaultValues <---",
						"Verified default value from format dropdown. Default value is --" + formatVal);
			}
			String timeVal = wolWebUtil.getDefaultValueForSelect(selTimePeriod);
			if (timeVal.equals(timePeriod)) {
				LogUtility.logInfo("---> verifyDefaultValues <---",
						"Verified default value from time period dropdown. Default value is --" + timeVal);
			}
			flag = true;

		} catch (Exception e) {
			LogUtility.logException("verifyDefaultValues", "Failed to Verify defailt values from drop downs", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyFromError - To Check From Date error
	 * 
	 * @return
	 */
	public boolean verifyFromError(String error) {
		try {
			return wolWebUtil.verifyText(txtFromdateError, error);
		} catch (Exception e) {
			LogUtility.logException("verifyFromError", "Failed to Verify From Date error", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyToError- To Check To Date error
	 * 
	 */
	public boolean verifyToError(String error) {
		try {
			return wolWebUtil.verifyText(txtTodateError, error);
		} catch (Exception e) {
			LogUtility.logException("verifyToError", "Failed to Verify TO Date error", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPageError - To Check Page error
	 * 
	 * @return
	 */
	public boolean verifyPageError(String error) {
		try {
			return wolWebUtil.verifyText(txtTransError, error);
		} catch (Exception e) {
			LogUtility.logException("verifyPageError", "Failed to Verify Page error", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyVerbiage - To check Verbiage
	 * 
	 * @return
	 */
	public boolean verifyVerbiage(String verbiage) {
		try {
			return wolWebUtil.verifyText(txtPageHead, verbiage);
		} catch (Exception e) {
			LogUtility.logException("verifyVerbiage", "Failed to Verify Verbiage", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyFirstMessage - To check FirstMessage
	 * 
	 * @return
	 */
	public boolean verifyFirstMessage(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtDaysError, message);
		} catch (Exception e) {
			LogUtility.logException("verifyFirstMessage", "Failed to Verify First Message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifySecondMessage - To check Second Message 
	 * 
	 * @return
	 */
	public boolean verifySecondMessage(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtPeriodError, message);
		} catch (Exception e) {
			LogUtility.logException("verifySecondMessage", "Failed to Verify Second Message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}
	
	/**
	 * To verify the Format type Dropdown values
	 */
	
	public boolean verifyFormatDropdownValues() {
		boolean flag = false;
		try {
			int count = 0;
			String[] list = testDataMap.get("FormatOptions").split(";");
			waits.waitForPageToLoad(20);
			waits.waitUntilElementIsPresent(selFormat);
			for (String eachOption : list) {
				if (wolWebUtil.verifyListValues(selFormat, eachOption)) {
					count = count + 1;
				}
			}
			if (count == list.length) {
				LogUtility.logInfo("--->verifyFormatDropdownValues<---", "Format options were present in the list");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFormatDropdownValues", " Format options were not present in the list", e,
					LoggingLevel.ERROR, true);
			return false;
		}
		return flag;
	}

	
	/**
	 * Click on the Yes button in Close pop up
	 */
	public boolean clickOnYesButton() {
		boolean flag = false;
		try {
			boolean selectYes = webActions.isDisplayed(btnConfirmCancel);
			if (selectYes) {
				webActions.clickElement(btnConfirmCancel);
				LogUtility.logInfo("---> clickOnYesButton <---", "Clicked on Yes button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> Failed to Click on Yes button <---", e.getMessage());
		}
		return flag;
	}
	
	/**
	 * Click on the No button in Close pop up
	 */
	public boolean clickOnNoButton() {
		boolean flag = false;
		try {
			boolean selectYes = webActions.isDisplayed(btnNotCancel);
			if (selectYes) {
				webActions.clickElement(btnNotCancel);
				LogUtility.logInfo("---> clickOnNoButton <---", "Clicked on No button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> Failed to Click on No button <---", e.getMessage());
		}
		return flag;
	}
	
	/**
	 * Click on the No button in Close pop up
	 */
	public boolean clickOnCancelButton() {
		boolean flag = false;
		try {
			boolean cancelBtn = webActions.isDisplayed(btnCancel);
			if (cancelBtn) {
				webActions.clickElement(btnCancel);
				LogUtility.logInfo("---> clickOnCancelButton <---", "Clicked on Cancel button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> Failed to Click on Cancel button <---", e.getMessage());
		}
		return flag;
	}
	
	/**
	 * To verify the Transaction table fields should display
	 */
	public boolean verifyTransTableFields(Map<String, String> transFields) {
		try {
			return wolWebUtil.verifyListOfItems(lblTransFields, transFields, "TransactionFields",
					"verifyTransTableFields");
		} catch (Exception e) {
			LogUtility.logException("verifyTransTableFields", "Transaction table Information not present", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}
	

}
