package com.wb.wol_web.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class LoginPage extends ObjectBase {

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	public String registering;
	public String unregistered;

	@FindBy(xpath = "//div[contains(@id,'pageErrors_gen__generic_error_msg__body')]")
	protected WebElement txtPageErrMsg;

	@FindBy(id = "login-error-rsa-weblink-locked-subsequent.pageError__body")
	protected WebElement txtWebLinkLockedMsg;

	@FindBy(name = "password")
	private WebElement txtPassword;

	@FindBy(xpath = "//*[contains(text(),'Continue') and contains(@id,'button')]")
	private WebElement btnContinue;

	@FindBy(xpath = "//div[contains(@id,'assword__error-message')]")
	protected WebElement txtPasswordErrMsg;

	@FindBy(xpath = "//p[contains(text(),'It is a good idea')]")
	protected WebElement txtSecurityInfoContent;

	@FindBy(xpath = "//h1[contains(text(),'Security') or contains(text(),'Sorry')]")
	// @FindBy(css="h1")
	protected WebElement txtPageTitle;

	@FindBy(xpath = "//b[contains(text(),'unable')]")
	protected WebElement txtWeblinkNAOErr;

	@FindBy(id = "login-register-standard__pageNote_gen__body")
	protected WebElement txtRegisterNote;

	@FindBy(id = "challengeQuestionsSection__section-note")
	protected WebElement txtChallengeNote;

	@FindBy(id = "challengeQuestionsSection__section-note--with-tooltip-0")
	protected WebElement txtChallengeQuestionTooltip;

	@FindBy(id = "recognizeMeSection__section-note")
	protected WebElement txtRecognizeNote;

	@FindBy(id = "recognizeMeSection__section-note--with-tooltip-0")
	protected WebElement txtRecognizeTooltip;

	@FindBy(id = "updateEmailSection__section-note")
	protected WebElement txtEmailSectionNote;

	@FindBy(id = "recognizeMeChooser__label")
	protected WebElement txtRecognizeLabel;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement btnSubmit;

	@FindBy(xpath = "//*[@id='answer__error-message' or @id='login-error-rsa-wol-locked.pageError__body' or contains(@id,'weblink-locked')]")
	protected WebElement txtAnswerErr;

	@FindBy(xpath = "//a[text()='sign in']")
	protected WebElement lnkSignIn;

	@FindBy(name = "username")
	private WebElement txtUserName;

	@FindBy(id = "new_username__label")
	private WebElement txtNewUsernameLabelText;

	@FindBy(id = "newPassword__label")
	private WebElement txtNewPasswordText;

	@FindBy(id = "currentUsername__label")
	private WebElement txtCurrentUsernameLabel;

	@FindBy(id = "currentUsername__display")
	private WebElement txtCurrentUserValue;

	@FindBy(id = "new_username__error-message-text")
	private WebElement txtNewUsernameErr;

	@FindBy(id = "newPassword__error-message-text")
	private WebElement txtNewPasswordErr;

	@FindBy(id = "retypePassword__error-message-text")
	private WebElement txtConfirmPasswordErr;

	@FindBy(name = "new_username")
	private WebElement txtNewUsername;

	@FindBy(name = "password1")
	private WebElement txtPassword1;

	@FindBy(name = "password2")
	private WebElement txtPassword2;

	@FindBy(id = "currentEmail__label")
	protected WebElement txtCurrentEmailLabel;

	@FindBy(id = "is_email_address_correct__label")
	protected WebElement txtIsEmailCorrectLabel;

	@FindBy(id = "is_email_address_correct__error-message-text")
	protected WebElement txtEmailErrorMsg;

	@FindBy(id = "newEmail__label")
	protected WebElement txtNewEmailLabel;

	@FindBy(id = "login-register-confirm__pageAffirmativeNotice_gen__body")
	protected WebElement txtRegisterConfirmMsg;

	@FindBy(id = "question1__error-message-text")
	protected WebElement txtQuestionErrMsg;

	@FindBy(xpath = "//div[@id='answer1__error-message']//p")
	protected WebElement txtAnswerOneErrMsg;

	/**
	 * clickSignIn: To click on sign In link in Sign out page
	 * 
	 * @return
	 */
	public boolean clickSignIn() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkSignIn);
			webActions.clickElementJS(lnkSignIn);
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(btnSubmit)) {
				LogUtility.logInfo("---> clickSignIn <---", "Clicked on Sign In link");
				flag = true;
			} else
				LogUtility.logInfo("---> clickSignIn <---", "Failed to click on Sign In link");
		} catch (Exception e) {
			LogUtility.logException("clickSignIn", "Failed to click on Sign In link", e, LoggingLevel.ERROR, true);
		}

		return flag;
	}

	/**
	 * clickContinueButton: To click on continue button
	 */
	public void clickContinueButton() {
		try {
			waits.waitUntilElementIsPresent(btnSubmit);
			webActions.clickElementJS(btnSubmit);
			LogUtility.logInfo("---> clickContinueButton <---", "clicked on Continue button");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to click on Continue button", e, LoggingLevel.ERROR,
					true);
		}

	}

	public boolean verifyAnswerErr(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtAnswerErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAnswerErr", "Failed to verify Answer error message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyWebLinkNAOErr:- To verify the error message displayed when Weblink user
	 * tried to open NAO
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyWebLinkNAOErr(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtWeblinkNAOErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyWebLinkNAOErr", "Failed to Weblink NAO error message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifySecurityInfoTitle:- To verify the Content of Security Information Page
	 * Title in WOL application
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifySecurityInfoTitle(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtPageTitle, message);
		} catch (Exception e) {
			LogUtility.logException("verifySecurityInfoTitle", "Failed to Verify Security Information Title Page", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifySecurityInfoContent:- To verify the Content of Security Information in
	 * WOL application
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifySecurityInfoContent(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtSecurityInfoContent, message);
		} catch (Exception e) {
			LogUtility.logException("verifySecurityInfoContent", "Failed to verify security Info Content", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyWebLinkLockMsg:- To verify the Weblink customer Lock out message in WOL
	 * application
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyWebLinkLockMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtWebLinkLockedMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyWebLinkLockMsg", "Failed to Weblink user Lock message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	public boolean enterPassword(String passwordValue) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(txtPassword)) {
				webActions.setValue(txtPassword, passwordValue);
				waits.waitForDOMready();
				if (webActions.getAttributeValue(txtPassword, "value").equalsIgnoreCase(passwordValue)) {
					flag = true;
					LogUtility.logInfo("---> enterPassword <---", "Entered password");
				}
				webActions.clickElement(btnContinue);

			}
		} catch (Exception e) {
			LogUtility.logException("enterPassword", "Failed to enter Password", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyPasswordErrMessage: To verify the error message of password
	 * 
	 * @param errMessage
	 * @return
	 */
	public boolean verifyPasswordErrMessage(String errMessage) {
		try {
			return wolWebUtil.verifyTextContains(txtPasswordErrMsg, errMessage);
		} catch (Exception e) {
			LogUtility.logException("verifyPasswordErrMessage", "Failed to Verify Password Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyRegisterNoteMsg:- To verify the Content of Register for Enhanced Online
	 * Security page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyRegisterNoteMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtRegisterNote, message);
		} catch (Exception e) {
			LogUtility.logException("verifyRegisterNoteMsg", "Failed to Verify registering  Note message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyChallengeNoteMsg:- To verify the Content of Step 1 in Register for
	 * Enhanced Online Security page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyChallengeNoteMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtChallengeNote, message);
		} catch (Exception e) {
			LogUtility.logException("verifyChallengeNoteMsg", "Failed to Verify Challenge Question Note message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyRecognizeNoteMsg:- To verify the Content of Step 2 in Register for
	 * Enhanced Online Security page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyRecognizeNoteMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtRecognizeNote, message);
		} catch (Exception e) {
			LogUtility.logException("verifyRecognizeNoteMsg", "Failed to Verify Recognize Note message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyEmailSectionNoteMsg:- To verify the Content of Step 3 in Register for
	 * Enhanced Online Security page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyEmailSectionNoteMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtEmailSectionNote, message);
		} catch (Exception e) {
			LogUtility.logException("verifyEmailSectionNoteMsg", "Failed to Verify registering Email Note message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyChallengeTooltipMsg:- To verify the Content of tool tip of Unregistered
	 * in Register for Enhanced Online Security page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyChallengeTooltipMsg(String message) {
		boolean flag = false;
		try {
			String unRegistered = webActions.getAttributeValue(txtChallengeQuestionTooltip, "data-title");
			if (unRegistered.contains(message)) {
				flag = true;
				LogUtility.logInfo("verifyChallengeTooltipMsg", "Verified Challenge Question tooltip message");
			} else
				LogUtility.logInfo("verifyChallengeTooltipMsg", "Failed to Verify Challenge Question tooltip message");

		} catch (Exception e) {
			LogUtility.logException("verifyChallengeTooltipMsg", "Failed to Verify challenge Question tooltip message",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyRecognizeTooltipMsg:- To verify the Content of tool tip of registering
	 * in Register for Enhanced Online Security page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyRecognizeTooltipMsg(String message) {
		boolean flag = false;
		try {
			String registering = webActions.getAttributeValue(txtRecognizeTooltip, "data-title");
			if (registering.contains(message)) {
				flag = true;
				LogUtility.logInfo("verifyRecognizeTooltipMsg", "Verified registering tooltip message");
			} else
				LogUtility.logInfo("verifyRecognizeTooltipMsg", "Failed to Verify registering tooltip message");

		} catch (Exception e) {
			LogUtility.logException("verifyRecognizeTooltipMsg", "Failed to Verify registering tooltip message", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyRecognizeLabel:- To verify the Register Your Device label
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyRecognizeLabel(String message) {
		try {
			return wolWebUtil.verifyText(txtRecognizeLabel, message);
		} catch (Exception e) {
			LogUtility.logException("verifyRecognizeLabel", "Failed to Verify Recognize label message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPageLevelErr:- To verify the Page Level Error message in Login Pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPageLevelErr(String message) {
		try {
			return wolWebUtil.verifyText(txtPageErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPageLevelErr", "Failed to Page Level Error message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To enter Username
	 * 
	 * @param userName
	 */
	public boolean enterUserName() {
		boolean flag = false;
		try {
			String userName = getValueFromRuntimeDataMap("newCustomer-webcom");
			webActions.setValue(txtUserName, userName);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtUserName, "value").equalsIgnoreCase(userName)) {
				flag = true;
				LogUtility.logInfo("---> enterUserName <---", "Entered the username " + userName);
			} else
				LogUtility.logInfo("---> enterUserName <---", "Failed to Enter the username ");
		} catch (Exception e) {
			LogUtility.logException("enterUserName", "Failed to enter username", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean enterPassword() {
		boolean flag = false;
		try {
			String password = getValueFromRuntimeDataMap("firstPassword-webcom");
			if (webActions.isDisplayed(txtPassword)) {
				webActions.setValue(txtPassword, password);
				waits.waitForDOMready();
				if (webActions.getAttributeValue(txtPassword, "value").equalsIgnoreCase(password)) {
					flag = true;
					LogUtility.logInfo("---> enterPassword <---", "Entered password");
				}
				webActions.clickElement(btnContinue);

			}
		} catch (Exception e) {
			LogUtility.logException("enterPassword", "Failed to enter Password", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To set the new username and password
	 */
	public boolean enterDetailsInNewUsernamePage(String userName, String password, String cnfrmPassword) {
		boolean flag = false;
		try {
			webActions.setValue(txtNewUsername, userName);
			webActions.setValue(txtPassword1, password);
			webActions.setValue(txtPassword2, cnfrmPassword);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtPassword2, "value").equalsIgnoreCase(cnfrmPassword)) {
				flag = true;
				LogUtility.logInfo("---> enterDetailsInNewusernamePage <---", "Entered New User name values");
			} else
				LogUtility.logInfo("---> enterDetailsInNewusernamePage <---", "Failed to Enter New User name values");
			webActions.clickElement(btnContinue);
		} catch (Exception e) {
			LogUtility.logException("enterDetailsInNewUsernamePage", "Failed to Enter New User name values", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyNewUsernameErrMsg: To verify the error message of new username
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNewUsernameErrMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtNewUsernameErr);
			return wolWebUtil.verifyText(txtNewUsernameErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyNewUsernameErrMsg", "Failed to verify New Username Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyNewPasswordErrMsg: To verify the error message of new password
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNewPasswordErrMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtNewPasswordErr);
			return wolWebUtil.verifyText(txtNewPasswordErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyNewPasswordErrMsg", "Failed to verify New Password Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyCnfrmPasswordErrMsg: To verify the error message of Retypr password
	 * value
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyCnfrmPasswordErrMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtConfirmPasswordErr);
			return wolWebUtil.verifyText(txtConfirmPasswordErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyCnfrmPasswordErrMsg", "Failed to verify Confirm Password Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyCurrentUsernameLabel: To verify the Current Username Label
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyCurrentUsernameLabel(String message) {
		try {
			waits.waitUntilElementIsPresent(txtCurrentUsernameLabel);
			return wolWebUtil.verifyText(txtCurrentUsernameLabel, message);
		} catch (Exception e) {
			LogUtility.logException("verifyCurrentUsernameLabel", "Failed to verify Current Username Label", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyNewUsernameHelpMsg: To verify the Help text New Username Label
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNewUsernameHelpMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtNewUsernameLabelText);
			String text = webActions.getAttributeValue(txtNewUsernameLabelText, "data-title");
			return text.equalsIgnoreCase(message);
		} catch (Exception e) {
			LogUtility.logException("verifyNewUsernameHelpMsg", "Failed to verify New USername Help message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyNewPasswordHelpMsg: To verify the Help text New Password Label
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNewPasswordHelpMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtNewPasswordText);
			String text = webActions.getAttributeValue(txtNewPasswordText, "data-title");
			return text.equalsIgnoreCase(message);
		} catch (Exception e) {
			LogUtility.logException("verifyNewPasswordHelpMsg", "Failed to verify New Password Help message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyFirstLoginConfrmMsg: To verify the First Login Confirmation Message
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyFirstLoginConfrmMsg(String message) {
		try {
			waits.waitUntilElementIsPresent(txtRegisterConfirmMsg);
			return wolWebUtil.verifyText(txtRegisterConfirmMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyFirstLoginConfrmMsg", "Failed to verify First Login Confirmation message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyCurrentEmailLabel: To verify the Current Email Label
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyCurrentEmailLabel(String message) {
		try {
			waits.waitUntilElementIsPresent(txtCurrentEmailLabel);
			return wolWebUtil.verifyText(txtCurrentEmailLabel, message);
		} catch (Exception e) {
			LogUtility.logException("verifyCurrentEmailLabel", "Failed to verify current Email Label message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyIsEmailCorrectLabel: To verify the Is Email Address correct Label
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyIsEmailCorrectLabel(String message) {
		try {
			waits.waitUntilElementIsPresent(txtIsEmailCorrectLabel);
			return wolWebUtil.verifyText(txtIsEmailCorrectLabel, message);
		} catch (Exception e) {
			LogUtility.logException("verifyIsEmailCorrectLabel", "Failed to verify Is Email correct Label message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyEmailError: To verify the Email Error message
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyEmailError(String message) {
		try {
			waits.waitUntilElementIsPresent(txtEmailErrorMsg);
			return wolWebUtil.verifyText(txtEmailErrorMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyEmailError", "Failed to verify Email Error message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyNewEmailLabel: To verify the New Email Label
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNewEmailLabel(String message) {
		try {
			waits.waitUntilElementIsPresent(txtNewEmailLabel);
			return wolWebUtil.verifyText(txtNewEmailLabel, message);
		} catch (Exception e) {
			LogUtility.logException("verifyNewEmailLabel", "Failed to verify New Email Label message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyQuestionOneErr: To verify the Question Error message
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyQuestionOneErr(String message) {
		try {
			waits.waitUntilElementIsPresent(txtQuestionErrMsg);
			return wolWebUtil.verifyText(txtQuestionErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyQuestionOneErr", "Failed to verify First Question Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyAnswerOneErr: To verify the Answer Err Message
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyAnswerOneErr(String message) {
		try {
			waits.waitUntilElementIsPresent(txtAnswerOneErrMsg);
			return wolWebUtil.verifyText(txtAnswerOneErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAnswerOneErr", "Failed to verify First Answer Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

}