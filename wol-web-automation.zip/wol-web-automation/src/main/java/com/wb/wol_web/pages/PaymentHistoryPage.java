package com.wb.wol_web.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author: Vinodh Somalaraju
 *
 */
public class PaymentHistoryPage extends ObjectBase {

	public PaymentHistoryPage() {
		PageFactory.initElements(driver, this);
	}

	public String confirmationNo;
	public String payeeName;
	public String fromDate;
	public String toDate = wolWebUtil.getCurrentDate();
	protected String deliverDateXpath = "//table[@class='table_bg']//span[contains(text(),'%s')]/../..//a[contains(@href,'PaymentHistoryDetails')]";
	public LinkedHashMap<String, String> billPaymentDetails;

	@FindBy(xpath = "//form[@name='paymentdetails']//label")
	protected List<WebElement> txtPaymentsValues;

	@FindBy(xpath = "//span[@id='mainSiteNav__submenu3__menuLabel']")
	protected WebElement paymentsTab;

	@FindBy(xpath = "//a[contains(text(),'Payment History')]")
	protected WebElement paymentHistoryLink;

	// paymentHistory
	@FindBy(xpath = "//h3[contains(text(),'Payment History')]")
	protected WebElement titlePaymentHistory;

	@FindBy(xpath = "//*[@class='relatedLinks']//a[contains(text(),'Search for Payments')]")
	protected WebElement lnkSearchForPaymentsFooter;

	@FindBy(xpath = "//table[@class='table_bg']//span[contains(text(),'+paymentStatus+')]/../..//a[contains(@href,'PaymentHistoryDetails')]")
	protected WebElement clickDeliveryDate_PaymentHistorytbl;

	@FindBy(xpath = "//h3[contains(text(),'Payment Details')]")
	protected WebElement pgTtlBillPaymentDetails;

	@FindBy(xpath = "//label[contains(text(),'Remittance Address')]")
	protected WebElement lblRemitanceAddress;

	// Request Payment Research Page
	@FindBy(xpath = "//*[@class='relatedLinks']//a[contains(text(),'Request Research on this payment')]")
	protected WebElement lnkRequestResearchPaymentFooter;

	@FindBy(xpath = "//h3[contains(text(),'Request Research')]")
	protected WebElement ttlRequestResearch;

	@FindBy(xpath = "//input[@name='researchReason' and @value='latefee']")
	protected WebElement rdbReserachReason;

	@FindBy(xpath = "//input[@name='payeeAccount' and @value='Yes']")
	protected WebElement rdbAddReqInfo;

	@FindBy(xpath = "//input[@id='dueDate']")
	protected WebElement txtDueDate;

	@FindBy(xpath = "//select[@id='paymentType']")
	protected WebElement lstPaymentType;

	@FindBy(xpath = "//input[@value='Research Request' and @type='submit']")
	protected WebElement btnRequestResearch;

	@FindBy(xpath = "//h3[contains(text(),'Research Request Confirmation')]")
	protected WebElement txtRequestResearchConfirmPage;

	// Search for Payments
	@FindBy(xpath = "//h1[contains(text(),'Search for Payments')]")
	protected WebElement ttlSerachforPayments;

	@FindBy(xpath = "//a[contains(@id,'paymentInfoLink')]")
	protected WebElement lnkPaymentInformation;

	@FindBy(xpath = "//div[@id='paymentInfoFields']")
	protected WebElement paymentInfoDetails;

	@FindBy(xpath = "//input[@id='date_from']")
	protected WebElement txtPaymentInfoFromDate;

	@FindBy(id = "searchAction")
	protected WebElement btnSearch;

	@FindBy(xpath = "//table[@id='table0']/tbody/tr/td[1]")
	protected List<WebElement> tblDateColumn;

	@FindBy(xpath = "//table[@id='table0']")
	protected WebElement tblPaymentResults;

	@FindBy(xpath = "//h3[contains(text(),'Payment Search Results')]")
	protected WebElement ttlPaymentSearchResults;

	// Search by confirmation no
	@FindBy(xpath = "//a[contains(@id,'paymentConfNumLink')]")
	protected WebElement lnkSerachByConfirmation;

	@FindBy(xpath = "//table[@id='table0']//tbody//tr//td[4]")
	protected WebElement txtConfirmationNo;

	@FindBy(xpath = "//table[@id='table0']//tbody//tr//td[3]")
	protected WebElement txtPayeeName;

	@FindBy(xpath = "//input[@name='confNum']")
	protected WebElement txtConfimationNo;

	/**
	 * To Verify the Payment History Title
	 * 
	 * @param: pgTtlTxt
	 * @return: Return the boolean value
	 */
	public boolean verifyPaymentHistoryTitle(String pgTtlTxt) {
		try {
			return wolWebUtil.verifyText(titlePaymentHistory, pgTtlTxt);
		} catch (Exception e) {
			LogUtility.logError("---> verifyPaymentHistoryTitle <---" + e.getMessage());
			return false;
		}
	}

	/**
	 * This is to Click on the Search for Payments Link on the Payment History Page
	 */
	public boolean clickSearchForPaymentsLink() {
		boolean flag = false;
		try {
			boolean searchForPayments = webActions.isDisplayed(lnkSearchForPaymentsFooter);
			if (searchForPayments) {
				webActions.clickElement(lnkSearchForPaymentsFooter);
				LogUtility.logInfo("---> clickSearchForPaymentslnk <---",
						"User clicked { Search for Payments } link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> clickSearchForPaymentslnk <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * To verify the Search for Payments Page Title
	 * 
	 * @param: pgTtlTxt
	 * @return: Return the boolean value
	 */
	public boolean verifySearchForPayments(String pgTtlTxt) {
		try {
			return wolWebUtil.verifyText(ttlSerachforPayments, pgTtlTxt);
		} catch (Exception e) {
			LogUtility.logError("---> verifySearchForPayments <---" + e.getMessage());
			return false;
		}
	}

	/**
	 * To Click the Search by Payment Information Link
	 */
	public boolean clickSearchByPaymentInfoLink() {
		boolean flag = false;
		try {
			boolean clickSearchPaymentInfo = webActions.isDisplayed(lnkPaymentInformation);
			if (clickSearchPaymentInfo) {
				webActions.clickElement(lnkPaymentInformation);
				LogUtility.logInfo("---> clickSearchByPaymentinfolnk <---",
						"Clicked { Serach By Payment Information } link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> clickSearchbyPaymentinfolnk <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * This Function is used for Entering the Payment Information Details
	 * 
	 * @param: dateVal
	 * @throws Throwable
	 */
	public boolean enterSearchByPaymentInfoDetails() throws Throwable {
		boolean flag = false;
		try {
			boolean enterSearchDetails = webActions.isDisplayed(txtPaymentInfoFromDate);
			String years = "-2";
			fromDate = wolWebUtil.dateAddorSubstract(years);
			if (enterSearchDetails) {
				webActions.setValue(txtPaymentInfoFromDate, fromDate);
				LogUtility.logInfo("---> enterSearchByPaymentInfoDetails <---",
						"Entered date value { " + fromDate + " } successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> enterSearchByPaymentInfoDetails <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * Clicking on the Search Button
	 */
	public boolean clickSearchButton() {
		boolean flag = false;
		try {
			boolean clickSearchButton = webActions.isDisplayed(btnSearch);
			if (clickSearchButton) {
				webActions.clickElement(btnSearch);
				LogUtility.logInfo("---> clickSearchButton <---", "licked Serach Button Successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> clickSearchButton <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * Verify title of Payment Search Results page
	 * 
	 * @param:pgTtlTxt
	 * @return: Returning the boolean Value
	 */
	public boolean verifyPaymentSearchResultsPageTtl(String pgTtlTxt) {
		try {
			return wolWebUtil.verifyText(ttlPaymentSearchResults, pgTtlTxt);
		} catch (Exception e) {
			LogUtility.logError("---> verifyPaymentSearchResultsPageTtl <---" + e.getMessage());
			return false;
		}
	}

	/**
	 * Verify the Search for Payments Link is present in the Page
	 * 
	 * @param: lnkText
	 * @return: Return the boolean vale
	 */
	public boolean verifySearchForPaymentsLink(String lnkText) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(lnkSearchForPaymentsFooter, maxTimeOut)) {
				flag = wolWebUtil.verifyTextContains(lnkSearchForPaymentsFooter, lnkText);
				LogUtility.logInfo("---> verifySearchForPaymentsLink <--- ",
						" Serach for Payments Link is Present in payment details page");
			}
		} catch (Exception e) {
			LogUtility.logError("---> verifySearchForPaymentsLink <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * To click the Delivery Date in The Payment History Table
	 * 
	 * @param: pmtStatus
	 */
	public boolean clickDeliveryDateLink(String pmtStatus) {
		boolean flag = false;
		try {
			WebElement deliveryDate = driver.findElement(By.xpath(String.format(deliverDateXpath, pmtStatus)));
			boolean deliveryDate1 = webActions.isDisplayed(deliveryDate);
			if (deliveryDate1) {
				deliveryDate.click();
				LogUtility.logInfo("---> clickDeliveryDateLink <---",
						" Clicked on Delivery Date for Payment Status as { " + pmtStatus + " }successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> clickDeliveryDateLink <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * This Function is used for Validate the Bill Payment Details Page
	 * 
	 * @param: pgTtlTxt
	 * @return: Return the boolean Value
	 */
	public boolean verifyBillPaymentDetailsPage(String pgTtlTxt) {
		boolean flag = true;
		try {
			boolean billPaymentPage = waits.waitUntilElementIsPresent(pgTtlBillPaymentDetails,maxTimeOut);
			if (billPaymentPage) {
				flag = wolWebUtil.verifyTextContains(pgTtlBillPaymentDetails, pgTtlTxt);
				LogUtility.logInfo("---> verifyBillPaymentDetailsPage <---", "User is in Payment Details Page");
			}
		} catch (Exception e) {
			LogUtility.logError("---> verifyBillPaymentDetailsPage <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * To Validate the Remittance address label in Bill Payment Details Page
	 * 
	 * @return: Return the boolean Value
	 */
	public boolean verifyRemittanceAddressLbl() {
		boolean flag = false;
		try {
			boolean remitanceAdd = waits.waitUntilElementIsPresent(lblRemitanceAddress,maxTimeOut);
			if (remitanceAdd) {
				wolWebUtil.verifyText(lblRemitanceAddress, "Remittance Address");
				LogUtility.logInfo("---> verifyRemittanceAddressLbl <---", " Remittance Address lable is present");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("verifyRemittanceAddressLbl" + e.getMessage());
		}
		return flag;
	}

	/**
	 * To click the Request Research on this Payment Link
	 */
	public boolean clickRequestResearchLink() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(lnkRequestResearchPaymentFooter, maxTimeOut)) {
				webActions.clickElement(lnkRequestResearchPaymentFooter);
				LogUtility.logInfo("---> clickRequestResearchLink <---",
						"Clicked on Request Research on this payment link successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("clickRequestResearchLink" + e.getMessage());
		}
		return flag;
	}

	/**
	 * To Verify the Request Research Page exist or not
	 * 
	 * @param pgTtlTxt
	 * @return: boolean
	 */
	public boolean verifyRequestResearchPage(String pgTtlTxt) {
		try {
			return wolWebUtil.verifyText(ttlRequestResearch, pgTtlTxt);
		} catch (Exception e) {
			LogUtility.logError("verifyRequestResearchPage" + e.getMessage());
			return false;
		}
	}

	/**
	 * To Enter Required details in Request Research Page Due to test data
	 * maintenance activity we are not using this function
	 */
	public boolean inputRequestResearchDetails(List<String> researchDetails) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(rdbReserachReason, maxTimeOut)) {
				webActions.clickElement(rdbReserachReason);
				webActions.clickElement(rdbAddReqInfo);
				webActions.setValue(txtDueDate, researchDetails.get(0));
				webActions.selectDropDownByText(lstPaymentType, researchDetails.get(1));
				webActions.clickElement(btnRequestResearch);
				LogUtility.logInfo("---> inputRequestResearchDetails <---",
						" Entered all details in { Request Research Details } Page");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> Error in entering reserach detail <--- " + e.getMessage());
			e.printStackTrace();
		}
		return flag;
	}

	/**
	 * To Verify the Request Research Confirmation Page
	 * 
	 * @param: pgTtlTxt
	 * @return: Boolean value Due to test data maintenance activity we are not using
	 *          this function
	 */
	public boolean verifyRequestResearchConfirmationPage(String pgTtlTxt) {
		try {
			return wolWebUtil.verifyText(txtRequestResearchConfirmPage, pgTtlTxt);
		} catch (Exception e) {
			LogUtility
					.logError("---> Unable to navigate { Request Research Confirmation } Page <--- " + e.getMessage());
			return false;
		}
	}

	/**
	 * To Click Search By Confirmation Number Link
	 * 
	 * @return
	 */
	public boolean clickSearchByConfirmationNoLink() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(lnkSerachByConfirmation, maxTimeOut)) {
				webActions.clickElement(lnkSerachByConfirmation);
				LogUtility.logInfo("---> clickSearchByConfirmationNoLink <---",
						" Search By Confirmation link clicked successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> clickSearchByConfirmationNoLink <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * To Get the application value
	 * 
	 * @return: Application Value and Stored globally
	 * @throws Exception
	 */
	public String getConfirmationNo() throws Exception {
		try {
			confirmationNo = webActions.getText(txtConfirmationNo).split("\n", 2)[1];
			payeeName = webActions.getText(txtPayeeName).split("\n", 2)[0];
			if (!confirmationNo.isEmpty())
				LogUtility.logInfo("---> getConfirmationNo <---", "Retrieved confirmation No :" + confirmationNo
						+ " : and payee name : " + payeeName + " : Successfully");
			else
				LogUtility.logInfo("---> getConfirmationNo <---",
						"Unable to retrieve confirmation no from payment history table");
		} catch (Exception e) {
			LogUtility.logError("---> getConfirmationNo <---" + e.getMessage());
			throw new Exception();
		}
		return confirmationNo;
	}

	/**
	 * To input the confirmation No
	 * 
	 * @return
	 */
	public boolean inputConfirmationNo() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(txtConfimationNo,maxTimeOut)) {
				String confirmationNo1 = confirmationNo;
				webActions.setValueJs(txtConfimationNo, confirmationNo1);
				LogUtility.logInfo("---> inputConfirmationNo <---",
						"ConfirmationNo :" + confirmationNo1 + " Entered Successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("---> inputConfirmationNo <---" + e.getMessage());
		}
		return flag;
	}

	/**
	 * to get the confirm details
	 */
	public void getBillPaymentConfirmDetails() {
		try {
			billPaymentDetails = new LinkedHashMap<String, String>();
			for (int paymentDetails = 0; paymentDetails < txtPaymentsValues.size(); paymentDetails = paymentDetails + 2)
				billPaymentDetails.put((txtPaymentsValues).get(paymentDetails).getText(),
						txtPaymentsValues.get(paymentDetails + 1).getText());
			LogUtility.logInfo("---> getBillPaymentConfirmDetails <---",
					"Retrieved all the bill payment confirmation details {" + billPaymentDetails + " } Successfully");
		} catch (Exception e) {
			LogUtility.logError("--->getTransferCnfrmDetails<---", e.getMessage());
		}
	}

	/**
	 * to verify the confirmation details in bill payments page
	 * 
	 * @return
	 */
	public boolean verifyBillPaymentConfirmatinDetails() {
		boolean flag = false;
		try {
			flag = confirmationNo.equalsIgnoreCase(billPaymentDetails.get("Confirmation #"))
					&& payeeName.equalsIgnoreCase(billPaymentDetails.get("Payee Name")) ? true : false;
			LogUtility.logInfo("---> verifyBillPaymentConfirmatinDetails <---",
					"Verified given values in bill payments details page " + billPaymentDetails.get("Confirmation #")
							+ "and " + billPaymentDetails.get("Payee Name"));
		} catch (Exception e) {
			LogUtility.logError("---> verifyBillPaymentConfirmatinDetails <---",
					"Confirmation details not present in the payment details page");
			;
		}
		return flag;
	}

	/**
	 * @param dateValue
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws Exception
	 */
	public boolean verifyGivenDateRange(String dateValue, String startDate, String endDate) throws Exception {
		boolean flag = false;
		String sDate = dateValue;
		try {
			SimpleDateFormat objSDF = new SimpleDateFormat("mm/dd/yyyy");
			Date dt_1 = objSDF.parse(sDate);
			Date dt_2 = objSDF.parse(startDate);
			Date dt_3 = objSDF.parse(endDate);
			if ((dt_1.after(dt_2)) || (dt_1.before(dt_3)) || (dt_1.equals(dt_2)) || (dt_1.equals(dt_3))) {
				flag = true;
			}
		} catch (Exception e) {
			throw new Exception("Date range failed");

		}
		return flag;
	}

	/**
	 * @param element
	 * @param startDate
	 * @param endDate
	 */
	public void verifyDateValuesInWebTable(List<WebElement> element, String startDate, String endDate) {
		try {
			for (int values = 0; values < element.size(); values++) {
				String dateValue = ((WebElement) element.get(values)).getText();
				boolean resultValue = verifyGivenDateRange(dateValue, startDate, endDate);
				if (resultValue) {
					LogUtility.logInfo("Passed -" + dateValue + " Present in range");
				} else {
					LogUtility.logInfo("Failed -" + dateValue + " Not Present in range");
				}
			}

		} catch (Exception e) {
			LogUtility.logError("---> Failed to Verify date range in table  <---", e.getMessage());

		}
	}

	/**
	 * 
	 */
	public boolean verifyPaymentSearchResults() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(tblPaymentResults,maxTimeOut)) {
				verifyDateValuesInWebTable(tblDateColumn, fromDate, toDate);
				LogUtility.logInfo("---> verifyDateRangeFromTable <---", "Verified table data");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logError("---> verifyPaymentSearchResults <---", " Failed to verify values");
		}
		return flag;
	}
}