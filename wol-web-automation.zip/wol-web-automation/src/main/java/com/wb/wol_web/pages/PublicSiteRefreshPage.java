
package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class PublicSiteRefreshPage extends ObjectBase {

	public PublicSiteRefreshPage() {
		PageFactory.initElements(driver, this);
	}

	public String linkCalculatePath = "//*[@style='display: block;']//a[contains(text(),%s)]";
	public WebElement linkCalculateElement = null;
	public List<WebElement> listlinkCalculateElements = null;
	public String labelName = null;
	public String linkName = null;
	public int count = 0;

	@FindBy(css = "a[class='accordion__item__header  account']")
	protected List<WebElement> lstAccountHeaders;

	@FindBy(css = "li[class='accordion__item js-account is-open'] a[class='accordion__item__header  account']")
	protected WebElement linkFirstAccountHeader;

	@FindBy(css = "div[style='display: block;']")
	protected WebElement openBlock;

	@FindBy(tagName = "h2")
	protected WebElement txtPersonalDisclosure;

	@FindBy(css = "#savings_accounts_hero h1")
	protected WebElement txtPageTitle;

	@FindBy(css = "p>b")
	protected List<WebElement> listDisclosureLabels;

	@FindBy(css = "h2+p>a")
	protected List<WebElement> listPersonalDisclosureLinks;

	@FindBy(css = "[property='content:encoded']>p:nth-child(4)>a")
	protected List<WebElement> listBusinessDisclosureLinks;

	@FindBy(css = "[property='content:encoded']>p:nth-child(6)>a")
	protected List<WebElement> listMiscDisclosureLinks;

	/**
	 * clickOnLinkUnderHeader: To click on the given text header
	 * 
	 * @param linkText
	 * @return
	 */
	public boolean clickOnLinkUnderHeader(String linkText, String accountType) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			webActions.clickElement(linkFirstAccountHeader);
			for (WebElement accountHeader : lstAccountHeaders) {
				if (webActions.getText(accountHeader).contains(accountType)) {
					webActions.clickElement(accountHeader);
					waits.waitForDOMready();
					listlinkCalculateElements = driver.findElements(By.partialLinkText(linkText));
					waits.waitForPageToLoad(maxTimeOut);
					if (listlinkCalculateElements.size() > 0) {
						webActions.clickElement(listlinkCalculateElements.get(0));
						LogUtility.logInfo("-->clickOnAllHeaders<--",
								"Link: " + linkText + " is clicked under accounts open block");
						return true;
					} else {
						webActions.clickElement(accountHeader);
						LogUtility.logInfo("-->clickOnAllHeaders<--", "Account is collapsed");
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnAllHeaders<--",
					"Link: " + linkText + " is not clicked under saving accounts open block", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * clickOnAllHeaders: To click on the headers and click on linkText
	 * 
	 * @param linkText
	 * @return
	 */
	public boolean clickOnAllHeaders(String linkText) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			webActions.clickElement(linkFirstAccountHeader);
			for (WebElement accountHeader : lstAccountHeaders) {
				webActions.clickElement(accountHeader);
				waits.staticWait(5);
				listlinkCalculateElements = openBlock.findElements(By.partialLinkText(linkText));
				if (listlinkCalculateElements.size() > 0) {
					webActions.clickElement(listlinkCalculateElements.get(0));
					LogUtility.logInfo("-->clickOnAllHeaders<--",
							"Link: " + linkText + " is clicked under accounts open block");
					return true;
				} else {
					webActions.clickElement(accountHeader);
					LogUtility.logInfo("-->clickOnAllHeaders<--", "Account is collapsed");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnAllHeaders<--",
					"Link: " + linkText + " is not clicked under saving accounts open block", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForPersonalLabel: TO check the personal disclosure label
	 * 
	 * @param labelName
	 * @return
	 */
	public boolean checkForPersonalLabel(String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtPersonalDisclosure, labelName)) {
				LogUtility.logInfo("-->checkForPersonalLabel<--", "Label: " + labelName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForPersonalLabel<--", "Label: " + labelName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForLabels: To check the label
	 * 
	 * @param testDataMap
	 * @return
	 */
	public boolean checkForLabels(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			for (WebElement label : listDisclosureLabels) {
				labelName = webActions.getText(label);
				if (testDataMap.containsValue(labelName))
					count++;
			}
			if (count == testDataMap.size()) {
				LogUtility.logInfo("-->checkForLabels<--",
						"Label: " + testDataMap.values().toString() + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForLabels<--",
					"One or many Label(s): " + testDataMap.values().toString() + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkForLinks: To check the links under header
	 * 
	 * @param testDataMap
	 * @param headerName
	 * @return
	 */
	public boolean checkForLinks(Map<String, String> testDataMap, String headerName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		List<WebElement> listToCheck = null;
		count=0;
		try {
			switch (headerName) {
			case "Personal Disclosures":
				listToCheck = listPersonalDisclosureLinks;
				break;
			case "Business Disclosures":
				listToCheck = listBusinessDisclosureLinks;
				break;
			case "Miscellaneous":
				listToCheck = listMiscDisclosureLinks;
				break;
			default:
				LogUtility.logInfo("-->checkForLinks<--", "No case match found");
				break;
			}
			for (WebElement link : listToCheck) {
				labelName = webActions.getText(link);
				if (testDataMap.containsValue(labelName))
					count++;
			}
			if (count == testDataMap.size()) {
				LogUtility.logInfo("-->checkForLinks<--", "Link: " + testDataMap.values().toString() + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForLinks<--",
					"One or many Link(s): " + testDataMap.values().toString() + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkPageName: To check the page name
	 * 
	 * @param pageName
	 * @return
	 */
	public boolean checkPageName(String pageName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (wolWebUtil.verifyTextContains(txtPageTitle, pageName)) {
				LogUtility.logInfo("-->checkPageName<--", "Page: " + pageName + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkPageName<--", "Page: " + pageName + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}
}