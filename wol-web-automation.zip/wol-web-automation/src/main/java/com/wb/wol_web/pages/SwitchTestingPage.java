
package com.wb.wol_web.pages;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class SwitchTestingPage extends ObjectBase {

	public SwitchTestingPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "#confirmationNumber__display>span")
	protected WebElement txtConfirmationNumber;

	@FindBy(css = "td:nth-child(9)")
	protected List<WebElement> listScheduleConfirmationNumbers;

	@FindBy(css = "td:nth-child(7)")
	protected List<WebElement> listHistoryConfirmationNumbers;

	@FindBy(id = "accountDetailsSubmitButton")
	protected WebElement btnSubmit;

	@FindBy(css = "td>select")
	protected WebElement listUpdateMode;

	@FindBy(css = "div.message")
	protected WebElement txtUpdateMessage;

	@FindBy(css = "[name='frmAccounts'] td:nth-child(4)")
	protected WebElement txtAccountNumber;

	@FindBy(id = "fromaccount")
	protected WebElement listTransferFrom;

	@FindBy(id = "toaccount")
	protected WebElement listTransferTo;

	public String confirmationNumber = null;
	public String accountNumber = "";

	/**
	 * getConfirmationNumber: To get the confirmation number of transfer
	 * 
	 * @return
	 */
	public String getConfirmationNumber() {
		waits.waitForPageReadyState();
		try {
			waits.waitUntilElementIsPresent(txtConfirmationNumber, maxTimeOut);
			if (webActions.isDisplayed(txtConfirmationNumber)) {
				confirmationNumber = webActions.getText(txtConfirmationNumber);
				LogUtility.logInfo("-->getConfirmationNumber<--",
						"Confirmation Number: " + confirmationNumber + " is present");
				return confirmationNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("->getConfirmationNumber<--", "Confirmation Number is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return confirmationNumber;
	}

	/**
	 * verifyConfirmationNumber: To verify the confirmation number in webcom
	 * 
	 * @return
	 */
	public String verifyConfirmationNumber() {
		waits.waitForPageReadyState();
		try {
			for (WebElement confNumber : listScheduleConfirmationNumbers)
				if (wolWebUtil.verifyTextContains(confNumber, confirmationNumber)) {
					LogUtility.logInfo("-->verifyConfirmationNumber<--",
							"Confirmation Number: " + confirmationNumber + " is present");
					return confirmationNumber;
				}
		} catch (Exception e) {
			LogUtility.logException("->verifyConfirmationNumber<--", "Confirmation Number is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * verifyTransferHistoryConfirmationNumber: To verify the transfer history
	 * confirmation number
	 * 
	 * @return
	 */
	public String verifyTransferHistoryConfirmationNumber() {
		waits.waitForPageReadyState();
		try {
			for (WebElement confNumber : listHistoryConfirmationNumbers)
				if (wolWebUtil.verifyTextContains(confNumber, confirmationNumber)) {
					LogUtility.logInfo("-->verifyConfirmationNumber<--",
							"Confirmation Number: " + confirmationNumber + " is present");
					return confirmationNumber;
				}
		} catch (Exception e) {
			LogUtility.logException("->verifyConfirmationNumber<--", "Confirmation Number is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * selectUpdateMode: To select the remove account from update mode drop-down
	 * 
	 * @param listValue
	 * @return
	 */
	public boolean selectUpdateMode(String listValue) {
		waits.waitForPageReadyState();
		try {
			waits.waitUntilElementIsPresent(listUpdateMode, maxTimeOut);
			if (webActions.isDisplayed(listUpdateMode)) {
				webActions.selectDropDownByText(listUpdateMode, listValue);
				LogUtility.logInfo("-->selectUpdateMode<--", "Value: " + listValue + " is selected");
				return true;
			} else {
				LogUtility.logError("-->selectUpdateMode<--", "Account is not present");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logException("->selectUpdateMode<--", "Value: " + listValue + " is not selected", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButton : To click on the button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForPageReadyState();
		try {
			waits.waitUntilElementIsPresent(btnSubmit, maxTimeOut);
			if (webActions.isDisplayed(btnSubmit)) {
				webActions.clickElement(btnSubmit);
				LogUtility.logInfo("-->clickOnButton<--", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButton<--", "Button: " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	public boolean checkForMessage(String message) {
		waits.waitForPageReadyState();
		try {
			waits.waitUntilElementIsPresent(txtUpdateMessage, maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtUpdateMessage, message)) {
				LogUtility.logInfo("-->checkForMessage<--", "Message: " + message + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForMessage<--", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * captureAccountNumber: To capture the account number
	 * 
	 * @return
	 */
	public String captureAccountNumber() {
		waits.waitForPageReadyState();
		try {
			waits.waitUntilElementIsPresent(txtAccountNumber, maxTimeOut);
			if (webActions.isDisplayed(txtAccountNumber)) {
				accountNumber = webActions.getText(txtAccountNumber);
				LogUtility.logInfo("-->captureAccountNumber<--", "Account: " + accountNumber + " is displayed");
				return accountNumber;
			}
		} catch (Exception e) {
			LogUtility.logException("->captureAccountNumber<--", "Account: " + accountNumber + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return accountNumber;
	}

	/**
	 * checkForAccountNotPresent: To check for the deleted account is not displayed
	 * 
	 * @param accountNumber
	 * @param labelName
	 * @return
	 */
	public boolean checkForAccountNotPresent(String accountNumber, String labelName) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		WebElement txtLabel = null;
		try {
			switch (labelName) {
			case "From":
				txtLabel = listTransferFrom;
				break;
			case "To":
				txtLabel = listTransferTo;
				break;
			default:
				LogUtility.logInfo("-->checkForAccountNotPresent<--", "No matching case found");
				break;
			}
			if (wolWebUtil.valueNotInList(txtLabel, accountNumber)) {
				LogUtility.logInfo("-->checkForAccountNotPresent<--",
						"Account: " + accountNumber + " is not displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkForAccountNotPresent<--", "Account: " + accountNumber + " is displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}
}
