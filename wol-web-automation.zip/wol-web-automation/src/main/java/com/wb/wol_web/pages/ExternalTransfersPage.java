package com.wb.wol_web.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class ExternalTransfersPage extends ObjectBase {

	public String confirmNumber;
	public static LinkedHashMap<String, String> confirmDetails;
	public LinkedHashMap<String, String> enteredDetails;
	public LinkedHashMap<String, String> updatedDetails;
	public String type;
	public String tablepath = "table";

	public ExternalTransfersPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "//div[@class='errorIndicator']//div//p")
	protected WebElement txtExternalTransferErrMsg;

	@FindBy(id = "ContinueButton")
	protected WebElement btnContinue;

	@FindBy(css = "table")
	protected WebElement tblName;

	@FindBy(id = "button_edit_impl")
	protected WebElement btnEdit;

	@FindBy(id = "cancelYesBtn")
	protected WebElement btnYes;

	@FindBy(id = "cancelNoBtn")
	protected WebElement btnNo;

	@FindBy(id = "CancelButton")
	protected WebElement btnCancel;

	@FindBy(id = "DuplicateButton")
	protected WebElement btnDuplicate;

	@FindBy(css = "form[id='externalTransfer'] label")
	protected List<WebElement> txtCnfrmLabels;

	@FindBy(css = "#externalTransfer div.data")
	protected List<WebElement> txtCnfrmValues;

	@FindBy(css = "div[class='lightbox-wrap is-visible is-top'] button.lightbox-controls__button.lightbox-controls__button--close")
	protected WebElement btnDisclosureClose;

	@FindBy(css = "div[class='topControls'] a[class='closeButton']")
	protected WebElement btnDisclosureCloseIE;

	@FindBy(css = "div.lightbox-wrap.is-visible.is-top  div.lightbox-controls > button.lightbox-controls__button.lightbox-controls__button--print")
	protected WebElement btnDisclosurePrint;

	@FindBy(css = "a[href*='DepositAcc']")
	protected WebElement linkTransferDisclosure;

	@FindBy(css = "div[class='errorIndicator'] p")
	protected WebElement txtErrorMessage;

	@FindBy(css = "div.col.col--primary > h2")
	protected WebElement txtSearchOptions;

	@FindBy(css = "div[data-wbst-message-key='transfers.manage_pending_transfers.notransfersmessage']")
	protected WebElement txtNoPendindgTransfers;

	@FindBy(css = "div[data-wbst-message-key='transfers_transferhistory_unabletoprocessrequest']")
	protected WebElement txtNoTransferHistory;

	@FindBy(id = "transferdate")
	protected WebElement txtTransferDate;

	@FindBy(id = "freqTR")
	protected WebElement labelFrequency;

	@FindBy(id = "transTR")
	protected WebElement labelNoofTransfers;

	@FindBy(id = "DeleteButton")
	protected WebElement btnDelete;

	@FindBy(id = "ContinueButton")
	protected WebElement btnContinueInTransfers;

	@FindBy(css = "#disclosureContainer h2")
	protected List<WebElement> txtDisclosureTitles;

	@FindBy(css = "div[id='transfer_complete__pageAffirmativeNotice__body']")
	protected WebElement txtTransferConfrmMsg;

	@FindBy(id = "fromaccount")
	protected WebElement lstTransferFrom;

	@FindBy(css = "select[id='fromaccount']>option")
	protected List<WebElement> lstTransferFromOptions;

	@FindBy(id = "toaccount")
	protected WebElement lstTransferTo;

	@FindBy(id = "transfertype")
	protected List<WebElement> rdbtnTransferType;

	@FindBy(css = "input[value='R']")
	protected WebElement rdBtnRecurring;

	@FindBy(css = "input[value='O']")
	protected WebElement rdBtnOneTime;

	@FindBy(id = "amttransfer")
	protected WebElement txtTransferAmount;

	@FindBy(id = "transfertype_NWBST")
	protected WebElement rdbtnNonWebTransWebcom;

	@FindBy(id = "transfertype_WBST")
	protected WebElement rdbtnWebTransWebcom;

	@FindBy(id = "FromTransactionDate")
	protected WebElement inputFromDate;

	@FindBy(id = "ToTransactionDate")
	protected WebElement inputToDate;

	@FindBy(css = "input[value='Search']")
	protected WebElement btnSearchWebcom;

	@FindBy(css = "table:nth-child(4) table td:nth-child(1)")
	protected List<WebElement> tableSearchResults;

	@FindBy(css = "caption span following-sibling::a")
	protected WebElement btnNext;

	@FindBy(id = "frequency")
	protected WebElement lstFrequency;

	@FindBy(id = "nooftrans")
	protected WebElement txtRemainTransfers;

	@FindBy(xpath = "//h6/..")
	protected WebElement txtTransferConfrmNote;

	@FindBy(css = "div.pageHeaderBlock>h3")
	protected WebElement txtPageTitle;

	@FindBy(css = "td[class='valid']")
	protected List<WebElement> validDates;

	@FindBy(css = "td[class='active']")
	protected WebElement today;

	@FindBy(css = "button[class='calendar']")
	protected WebElement btnCalendar;

	@FindBy(css = "div.pageHeaderBlock p")
	protected WebElement txtVerifyMsg;

	@FindBy(css = "div[id='pageContent']>div[class='note']")
	protected WebElement txtNoteMsgVerify;

	@FindBy(css = "div[class='note']")
	protected WebElement txtNoteMsgCnfrm;

	@FindBy(css = "div[class='errorIndicator'] p")
	protected WebElement txtErrorMsg;

	@FindBy(css = "div[class='errorIndicator'] li")
	protected List<WebElement> txtErrorMessageSet;

	/**
	 * getTransferConfirmationNumber: To get confirmation number value from External
	 * Transfer Confirmation Page
	 */
	public void getTransferConfirmationNumber() {
		try {
			confirmNumber = confirmDetails.get("Confirmation Number");
			LogUtility.logInfo("getTransferConfirmationNumber", "Got Transfer Confirmation number " + confirmNumber);
		} catch (Exception e) {
			LogUtility.logException("getTransferConfirmationNumber", "Failed to get confirmation number", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * clickContinueToTransfer: To click on continue button among transfer pages
	 */
	public void clickContinueToTransfer() {
		try {
			waits.waitUntilElementIsPresent(btnContinue);
			webActions.clickElement(btnContinue);
			if (waits.waitUntilElementIsPresent(btnDuplicate))
				webActions.clickElement(btnDuplicate);
			LogUtility.logInfo("clickContinueToTransfer", "Clicked on Continue Button");
		} catch (Exception e) {
			LogUtility.logException("clickContinueToTransfer", "Failed to click on Continue Button", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * clickEditTransfer: To click on Edit button among transfer pages
	 */
	public boolean clickEditTransfer() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnEdit);
			webActions.clickElement(btnEdit);
			if (waits.waitUntilElementIsPresent(lstTransferFrom)) {
				flag = true;
				LogUtility.logInfo("clickEditTransfer", "Clicked on Continue Button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickEditTransfer", "Failed to click on Continue Button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * getUpdatedDetails: To get all the updated details in a map
	 */
	public void getUpdatedDetails() {
		try {
			updatedDetails = new LinkedHashMap<String, String>();
			updatedDetails.put("Transfer From", wolWebUtil.getDefaultValueForSelect(lstTransferFrom));
			updatedDetails.put("Transfer To", wolWebUtil.getDefaultValueForSelect(lstTransferTo));
			updatedDetails.put("Amount", webActions.getAttributeValue(txtTransferAmount, "value"));
			if (type.contains("O")) {
				updatedDetails.put("Transfer Type", "One Time");
				updatedDetails.put("Transfer Start Date", webActions.getAttributeValue(txtTransferDate, "value"));
			} else if (type.contains("R")) {
				updatedDetails.put("Transfer Type", "Recurring");
				updatedDetails.put("Transfer Start Date", webActions.getAttributeValue(txtTransferDate, "value"));
				updatedDetails.put("Frequency", wolWebUtil.getDefaultValueForSelect(lstFrequency));
				updatedDetails.put("# of Transfers", webActions.getAttributeValue(txtRemainTransfers, "value"));
			}
			LogUtility.logInfo("getUpdatedDetails", "Retrieved updated details" + updatedDetails);
		} catch (Exception e) {
			LogUtility.logException("getUpdatedDetails", "Failed to get updated detaisl", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * getEnteredDetails: To get all the entered details in a map
	 */
	public void getEnteredDetails() {
		try {
			enteredDetails = new LinkedHashMap<String, String>();
			enteredDetails.put("Transfer From", wolWebUtil.getDefaultValueForSelect(lstTransferFrom));
			enteredDetails.put("Transfer To", wolWebUtil.getDefaultValueForSelect(lstTransferTo));
			enteredDetails.put("Amount", webActions.getAttributeValue(txtTransferAmount, "value"));
			if (type.contains("O")) {
				enteredDetails.put("Transfer Type", "One Time");
				enteredDetails.put("Transfer Start Date", webActions.getAttributeValue(txtTransferDate, "value"));
			} else if (type.contains("R")) {
				enteredDetails.put("Transfer Type", "Recurring");
				enteredDetails.put("Transfer Start Date", webActions.getAttributeValue(txtTransferDate, "value"));
				enteredDetails.put("Frequency", wolWebUtil.getDefaultValueForSelect(lstFrequency));
				enteredDetails.put("# of Transfers", webActions.getAttributeValue(txtRemainTransfers, "value"));
			}
			LogUtility.logInfo("getEnteredDetails", "Retrieved entered details " + enteredDetails);
		} catch (Exception e) {
			LogUtility.logException("getEnteredDetails", "Failed to get entered details", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectTransferFromAcct: To Select account in Transfer From Drop down
	 * 
	 * @param transferDetails: Account Number
	 * @throws Exception
	 */
	public void selectTransferFromAcct(List<Map<String, String>> transferDetails) throws Exception {
		try {
			wolWebUtil.selectValueByPartialVisibleText(lstTransferFrom, transferDetails.get(0).get("fromAcct"));
			LogUtility.logInfo("selectTransferFromAcct", "Selected Account in the Transfer From Drop down");
		} catch (Exception e) {
			LogUtility.logException("selectTransferFromAcct", "Failed to select transfer from dropdown", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * selectTransferToAcct:-To Select account in Transfer To Drop down
	 * 
	 * @param transferDetails
	 * @throws Exception
	 */
	public void selectTransferToAcct(List<Map<String, String>> transferDetails) throws Exception {
		try {
			wolWebUtil.selectValueByPartialVisibleText(lstTransferTo, transferDetails.get(0).get("toAcct"));
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			LogUtility.logInfo("selectTransferToAcct", "Selected Account in Transfer To Drop down");
		} catch (Exception e) {
			LogUtility.logException("selectTransferToAcct", "Failed to select transfer to dropdown", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * enterAmount:- To Enter amount
	 * 
	 * @param transferDetails
	 * @throws Exception
	 */
	public boolean enterAmount(List<Map<String, String>> transferDetails) throws Exception {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtTransferAmount);
			webActions.setValue(txtTransferAmount, transferDetails.get(0).get("amount"));
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtTransferAmount, "value")
					.equalsIgnoreCase(transferDetails.get(0).get("amount"))) {
				flag = true;
				LogUtility.logInfo("enterAmount", "Entered value in Transfer Amount Field");
			}
		} catch (Exception e) {
			LogUtility.logException("enterAmount", "Failed to enter amount", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return flag;
	}

	/**
	 * selectTransferTypeDetails:- To select transfer type to do external Transfer
	 * 
	 * @param transferDetails:- Transfer Type
	 * @throws Exception
	 */
	public void selectTransferType(List<Map<String, String>> transferDetails) throws Exception {
		try {
			for (WebElement transferType : rdbtnTransferType) {
				String value = webActions.getAttributeValue(transferType, "value");
				if (value.equalsIgnoreCase(transferDetails.get(0).get("transferType"))) {
					webActions.clickElement(transferType);
					break;
				}
			}
			type = transferDetails.get(0).get("transferType");
			LogUtility.logInfo("selectTransferType", "Selected transfer Type" + type);
		} catch (Exception e) {
			LogUtility.logException("selectTransferType", "Failed to select transfer type", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * selectRecurringDetails- To select recurring external transfer details
	 * 
	 * @param transferDetails- Frequency , no.of Transfers
	 * @throws Exception
	 */
	public void selectRecurringDetails(List<Map<String, String>> transferDetails) throws Exception {
		try {
			waits.waitUntilElementIsPresent(lstFrequency);
			if (!transferDetails.get(0).get("frequency").equals("")) {
				webActions.selectDropDownByText(lstFrequency, transferDetails.get(0).get("frequency"));
				webActions.setValue(txtRemainTransfers, transferDetails.get(0).get("Transfers"));
			}
			LogUtility.logInfo("selectRecurringDetails", "Selected Recurring Transfer Details");
		} catch (Exception e) {
			LogUtility.logException("selectRecurringDetails", "Failed to select Recurring Transfer Details", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * verifyExternalTransfersPageTitle:- To verify page headers among external
	 * Transfers pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyExternalTransfersPageTitle(String message) {
		boolean status = false;
		waits.waitForDOMready();
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtPageTitle, maxTimeOut);
			status = wolWebUtil.verifyText(txtPageTitle, message);
			if (status)
				LogUtility.logInfo("verifyExternalTransfersPageTitle", "Found the title " + message);
		} catch (Exception e) {
			LogUtility.logException("verifyExternalTransfersPageTitle", "Failed to find the title", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * enterTransferDate: To Enter Date in Transfer Date text field
	 * 
	 * @param days: Days
	 */
	public void enterTransferDate(int days) {
		try {
			waits.waitUntilElementIsPresent(btnCalendar, maxTimeOut);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			LocalDate date = LocalDate.now();
			LocalDate date1 = date.plusDays(Long.valueOf(days));
			date1 = wolWebUtil.isWeekendOrHoliday(date1, jsonDataParser.getTestDataMap().get("Public Holidays"));
			webActions.setValue(txtTransferDate, date1.format(formatter));

			LogUtility.logInfo("enterTransferDate", "Entered Required Date in Transfer Date field");
		} catch (Exception e) {
			LogUtility.logException("clickContinueToTransfer", "Failed to click on Continue Button", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * TODO : Check if the window handle functionc can be updated with framework
	 * functions clickTransferDisclosure:- To Click on Disclosure Link in Transfer
	 * Page
	 */
	public boolean clickTransferDisclosure() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(linkTransferDisclosure, maxTimeOut);
			webActions.clickElement(linkTransferDisclosure);
			if (browserName.equals("internet explorer")) {
				waits.staticWait(3);
				waits.waitForDOMready();
				wolWebUtil.switchToNewWindow();
				waits.waitForDOMready();
				waits.staticWait(5);// need static wait in IE to handle new tab
				if (waits.waitUntilElementIsPresent(btnDisclosureCloseIE))
					flag = true;
			} else if (waits.waitUntilElementIsPresent(btnDisclosureClose)) {
				flag = true;
				LogUtility.logInfo("clickTransferDisclosure", "Clicked on Disclosure Link");
			}
		} catch (Exception e) {
			LogUtility.logException("clickTransferDisclosure", "Failed to click on Disclosure Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickDisclosureCloseButton:- To Click on Close button in Disclosure Lightbox
	 */
	public boolean checkDisclosurePrintButton() {
		boolean flag = false;
		try {
			if (browserName.equals("internet explorer")) {
				waits.staticWait(3);
				waits.waitForDOMready();
				wolWebUtil.switchToNewWindow();
				waits.waitForDOMready();
				waits.staticWait(5);// need static wait in IE to handle new tab
				if (waits.waitUntilElementIsPresent(btnDisclosurePrint))
					flag = true;
			} else if (waits.waitUntilElementIsPresent(btnDisclosurePrint, maxTimeOut)) {
				flag = true;
				LogUtility.logInfo("clickDisclosurePrintButton", "Clicked on the print button in disclosure");

			}
		} catch (Exception e) {
			LogUtility.logException("clickContinueToTransfer", "Failed to click on Continue Button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickDisclosureCloseButton:- To Click on Close button in Disclosure Lightbox
	 */
	public boolean clickOnCanceltButtonInPrint() {
		boolean flag = false;
		try {
			try {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				flag = true;
			} catch (AWTException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCanceltButtonInPrint", "Failed to click on print Button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickDisclosureCloseButton:- To Click on Close button in Disclosure Lightbox
	 */
	public void clickDisclosureCloseButton() {
		try {
			if (browserName.equals("internet explorer")) {
				waits.waitUntilElementIsPresent(btnDisclosureCloseIE, maxTimeOut);
				webActions.clickElement(btnDisclosureCloseIE);
				waits.waitForDOMready();
				wolWebUtil.switchToMainWindow();
			} else {
				waits.waitUntilElementIsPresent(btnDisclosureClose, maxTimeOut);
				wolWebUtil.clickWebElement(btnDisclosureClose, "clickDisclosureCloseButton");
				waits.waitForDOMready();
				if (waits.waitUntilElementIsPresent(btnDisclosureClose, maxTimeOut)) {
					wolWebUtil.clickWebElement(btnDisclosureClose, "clickDisclosureCloseButton");
				}
			}
			waits.staticWait(5); // to navigate disclosure lightbox top
			LogUtility.logInfo("clickDisclosureCloseButton",
					"Clicked on Close button in Disclosure Light box of transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickDisclosureCloseButton", "Failed to click on close Button", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * getTransferCnfrmDetails- To get details of Transfer in Transfer Confirmation
	 * page
	 */
	public void getTransferCnfrmDetails() {
		try {
			confirmDetails = new LinkedHashMap<String, String>();
			for (int i = 0; i < txtCnfrmLabels.size(); i++)
				confirmDetails.put(txtCnfrmLabels.get(i).getText(), txtCnfrmValues.get(i).getText());
			LogUtility.logInfo("getTransferCnfrmDetails", "Retrieved all the transfer Confirmation details");
		} catch (Exception e) {
			LogUtility.logException("getTransferCnfrmDetails", "Failed to get transfer Confirmation details", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * getDisclosureDetails-To get Disclosure headers
	 * 
	 * @return
	 */

	public String getDisclosureDetails() {
		String textValue = "";
		try {
			if (!browserName.equals("internet explorer")) {

				for (WebElement headers : txtDisclosureTitles) {
					textValue = textValue + webActions.getText(headers) + " , ";
				}
			}
			LogUtility.logInfo("getDisclosureDetails", "Retrieved all the Disclosure details");

		} catch (Exception e) {
			LogUtility.logException("getDisclosureDetails", "Failed to get disclosure details", e, LoggingLevel.ERROR,
					true);
		}
		return textValue;
	}

	/**
	 * validatevVerificationDetails-To compare transfer entered details &
	 * Verification page
	 * 
	 * @return
	 */
	public boolean validateVerificationDetails() {
		boolean status = false;
		try {
			status = wolWebUtil.mapValuesComaparison(enteredDetails, confirmDetails);
			if (status)
				LogUtility.logInfo("--->validatevVerificationDetails<---",
						"Both the entered detais and displayed details are same ");
		} catch (Exception e) {
			LogUtility.logException("validatevVerificationDetails", "Failed to compare updated details", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * validatevVerificationDetails-To compare transfer entered details &
	 * Verification page
	 * 
	 * @return
	 */
	public boolean validateUpdatedDetails() {
		boolean status = false;
		try {
			status = wolWebUtil.mapValuesComaparison(enteredDetails, updatedDetails);
			if (status)
				LogUtility.logInfo("--->validateUpdatedDetails<---",
						"Both the entered detais and displayed details are same ");
		} catch (Exception e) {
			LogUtility.logException("validateUpdatedDetails", "Failed to compare updated details", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * validateConfirmationDetails-To compare transfer entered details &
	 * Confirmation page
	 * 
	 * @return
	 */
	public boolean validateConfirmationDetails() {
		boolean status = false;
		try {
			status = wolWebUtil.mapValuesComaparison(enteredDetails, confirmDetails);
			if (status)
				LogUtility.logInfo("--->validateConfirmationDetails<---",
						"Both the entered detais and displayed details are same ");
		} catch (Exception e) {
			LogUtility.logException("validateConfirmationDetails", "Failed to click on confirmation details", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * clickDateLinkinTablebyvalue: To click on Date link in pending transfers page
	 * 
	 * @throws Exception
	 */
	public void clickDateLinkinTableByValue() throws Exception {
		try {
			waits.waitUntilElementIsPresent(tblName);
			wolWebUtil.clickOnTableCell(tblName, confirmNumber);
			LogUtility.logInfo("clickDateLinkinTableByValue", "Clicked on Date Link in Manage Pending Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickDateLinkinTableByValue", "Failed to click on date link", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * clickDeleteLinkinTableByValue: To click on delete link in pending transfers
	 * page
	 * 
	 * @throws Exception
	 */
	public void clickDeleteLinkinTableByValue() throws Exception {
		try {
			waits.waitUntilElementIsPresent(tblName);
			Map<Integer, String> map = new HashMap<>();
			map.put(5, confirmNumber);
			wolWebUtil.checkFromTableDataWithColNumbers(tablepath, map, 7);
			LogUtility.logInfo("clickDeleteLinkinTableByValue",
					"Clicked on Date Link in Manage Pending Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickDeleteLinkinTableByValue",
					"Failed to click on Date Link in Manage Pending Transfers Pag", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * verifyMsg: To verify the content in Verification page
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyMsg(String message) {
		boolean status = false;
		try {
			status = wolWebUtil.verifyTextContains(txtVerifyMsg, message);
			if (status)
				LogUtility.logInfo("--->verifyMsg<---", "Found the message " + message);
		} catch (Exception e) {
			LogUtility.logException("verifyMsg", "Failed to find the message " + message, e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * verifyNoteMsg: To verify the note content in Transfer pages
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNoteMsg(String message) {
		boolean flag = false;
		try {
			String expMessage = jsonDataParser.getTestDataMap().get(message);
			if (waits.waitUntilElementIsPresent(txtNoteMsgVerify)) {
				if (txtNoteMsgVerify.getText().contains(expMessage)) {
					flag = true;
				}
			} else if (waits.waitUntilElementIsPresent(txtNoteMsgCnfrm)) {
				flag = wolWebUtil.verifyTextContains(txtNoteMsgCnfrm, expMessage);
			}
			LogUtility.logInfo("--->verifyNoteMsg<---", "Note message " + expMessage);
		} catch (Exception e) {
			LogUtility.logException("verifyNoteMsg", "Failed to find the message ", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyNoteMsgConfirmation: To verify the note content in Transfer pages
	 * 
	 * @param message
	 * @return
	 */
	public boolean verifyNoteMsgConfirmation(String message) {
		boolean flag = false;
		try {
			String expMessage = jsonDataParser.getTestDataMap().get(message);
			if (waits.waitUntilElementIsPresent(txtNoteMsgCnfrm)) {
				if (txtNoteMsgCnfrm.getText().contains(expMessage)) {
					flag = true;
					LogUtility.logInfo("--->verifyNoteMsgConfirmation<---",
							"Found the message " + txtNoteMsgCnfrm.getText());
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNoteMsgConfirmation", "Failed to ding the message " + message, e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyExtTransferErrorMessage: To verify error messages for external transfer
	 * 
	 * @param errMessage
	 * @return
	 */
	public boolean verifyExtTransferErrorMessage(String errMessage) {
		boolean flag = false;
		try {

			for (WebElement message : txtErrorMessageSet) {
				String text = message.getText();
				if (text.contains(errMessage)) {
					flag = true;
					LogUtility.logInfo("--->verifyExtTransferErrorMessage<---", "Found the message " + errMessage);
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyExtTransferErrorMessage", "Failed to find the message", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyExtTransferErrorMessageList(String errMessage) {
		boolean flag = false;
		try {
			String text = "";
			if (waits.waitUntilElementIsPresent(txtErrorMsg, maxTimeOut)) {
				text = txtErrorMsg.getText();
			} else {
				for (WebElement ele : txtErrorMessageSet) {
					text = text + ele.getText() + "\n";
				}
			}
			if (text.contains(errMessage)) {
				flag = true;
				LogUtility.logInfo("--->verifyExtTransferErrorMessageList<---", "Found the message " + errMessage);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyExtTransferErrorMessageList", "Failed to find the message", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public void enterTheDate(String dateValue) {
		try {
			switch (dateValue) {
			case "Empty":
				webActions.clearValue(txtTransferDate);
				LogUtility.logInfo("--->enterTheDate<---", "Cleared the date value");
				break;

			case "Past Date":
				String date = wolWebUtil.getDateInTheFormat("MM/dd/YYYY", -7);
				webActions.setValue(txtTransferDate, date);
				LogUtility.logInfo("--->enterTheDate<---", "Entered the date value " + date);
				break;
			case "Invalid Date":
				webActions.setValue(txtTransferDate, "^*()");
				LogUtility.logInfo("--->enterTheDate<---", "Entered the invalid date value : *^()");
				break;
			default:
				LogUtility.logError("Invalid date type " + dateValue);
			}
			LogUtility.logInfo("--->enterTheDate<---", "");

		} catch (Exception e) {
			LogUtility.logException("enterTheDate", "Failed to find the message", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * clickOnCancelButton: To click on the transfer button
	 * 
	 * @param errMessage
	 * @return
	 */
	public boolean clickOnCancelButton() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnCancel)) {
				webActions.clickElement(btnCancel);
				LogUtility.logInfo("--->clickOnCancelButton<---", "Clicked on the cancel button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCancelButton", "Failed to click on cancel Button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * enterInvalidDate: To enter invalid date
	 * 
	 * @param message
	 * @return
	 */
	public boolean enterInvalidDate(String date) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(txtTransferDate)) {
				webActions.clearValue(txtTransferDate);
				webActions.setValue(txtTransferDate, date);
				flag = true;
				LogUtility.logInfo("--->enterInvalidDate<---", "Entered invalid date " + date);
			}
		} catch (Exception e) {
			LogUtility.logException("enterInvalidDate", "Failed to enter date", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * checks for the error message
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean checkForErrorMessage(String errorMsg) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtErrorMessage);
			if (wolWebUtil.verifyText(txtErrorMessage, errorMsg)) {
				flag = true;
				LogUtility.logInfo("--->checkForErrorMessage<---", "Found the message : " + errorMsg);
			}
		} catch (Exception e) {
			LogUtility.logException("checkForErrorMessage", "Failed to find the message " + errorMsg, e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * checks for the frequency and no.of transfers labels
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean checkForFrequencyAndNoOfTransfers() {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(labelFrequency);
			String freqStyle = webActions.getAttributeValue(labelFrequency, "style");
			String transacStyle = webActions.getAttributeValue(labelNoofTransfers, "style");
			if (freqStyle.equals("display: table-row;") && transacStyle.equals("display: table-row;")) {
				flag = true;
				LogUtility.logInfo("checkForFrequencyAndNoofTransfers",
						"Frequency and number of transfers labels are found");
			}
		} catch (Exception e) {
			LogUtility.logException("checkForFrequencyAndNoofTransfers",
					"Failed to find Frequency and number of transfers labels", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Click on the continue button in manage transfers flow
	 * 
	 * @return
	 */
	public boolean clickOnContinueInManageTransfers() {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			if (webActions.isDisplayed(btnContinueInTransfers)) {
				webActions.clickElement(btnContinueInTransfers);
				flag = true;
				LogUtility.logInfo("clickOnContinueInManageTransfers", "Clicked on continue button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnContinueInManageTransfers", "Failed to click on Continue Button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * checkIfPreselected:- To check if the transfer type is pre selected
	 * 
	 * @param transferDetails:- Transfer Type
	 */
	public boolean checkIfPreselected(String transferType) {
		boolean flag = false;
		WebElement eleTogetValue = null;
		try {
			if (transferType.equals("Recurring"))
				eleTogetValue = rdBtnRecurring;
			else
				eleTogetValue = rdBtnOneTime;
			if (webActions.getAttributeValue(eleTogetValue, "checked").equals("true")) {
				LogUtility.logInfo("--->checkIfPreselected<---", transferType + " is pre selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkIfPreselected", "Failed to find transfer type", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on the transfer type in webcom transaction search page
	 * 
	 * @param transferType
	 * @return
	 */
	public boolean clickOnTransferTypeInWebcom(String transferType) {
		boolean flag = false;
		WebElement eleTogetValue = null;
		try {
			if (transferType.contains("Non")) {
				eleTogetValue = rdbtnNonWebTransWebcom;
			} else {
				eleTogetValue = rdbtnWebTransWebcom;
			}
			if (waits.waitUntilElementIsPresent(eleTogetValue)) {
				wolWebUtil.scrollToElement(eleTogetValue);
				webActions.clickElement(eleTogetValue);
				flag = true;
				LogUtility.logInfo("--->clickOnTransferTypeInWebcom<---",
						"Clicked on the transaction type " + transferType);
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnTransferTypeInWebcom", "Failed to click on transferType", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter the to and from dates in search criteria
	 * 
	 * @throws Exception
	 */
	public String enterToAndFromDateValuesInWebcom() throws Exception {
		String dates = wolWebUtil.getDateInTheFormat("MM/dd/yyyy", -15) + ", "
				+ wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 0);
		try {
			webActions.setValue(inputFromDate, wolWebUtil.getDateInTheFormat("MMddyyyy", -15));
			webActions.setValue(inputToDate, wolWebUtil.getDateInTheFormat("MMddyyyy", 0));
			LogUtility.logInfo("enterToAndFromDateValuesInWebcom", "Entered the dates in search options");

		} catch (Exception e) {
			LogUtility.logException("enterToAndFromDateValuesInWebcom", "Exception while enterting to and from date", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		return dates;
	}

	public boolean clickOnSearchButtonInWebcom() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnSearchWebcom)) {
				webActions.clickElement(btnSearchWebcom);
				flag = true;
				LogUtility.logInfo("--->clickOnSearchButtonInWebcom<---", "Clicked on the search button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnSearchButtonInWebcom", "Failed to click on search Button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public String compareDatesInWebcomSearch() {
		String outRangeDates = "";
		waits.waitVisibilityOfAllElements(tableSearchResults);
		try {
			for (WebElement eachRowDate : tableSearchResults) {
				if (wolWebUtil.verifyDateGivenRange(eachRowDate.getText(),
						wolWebUtil.getDateInTheFormat("MM/dd/YYYY", -15),
						wolWebUtil.getDateInTheFormat("MM/dd/YYYY", 0))) {
					LogUtility.logInfo("--->compareDatesInWebcomSearch<---", "All the dates are in the range");
				} else {
					outRangeDates = outRangeDates + eachRowDate + ",";
				}
			}
		} catch (Exception e) {
			LogUtility.logException("compareDatesInWebcomSearch", "Failed to compare dates in webcom", e,
					LoggingLevel.ERROR, true);
		}
		return outRangeDates;
	}

	/**
	 * Check if the title is present in the page or not
	 * 
	 * @param title
	 * @return
	 */
	public boolean verifySearchOptionsTitle(String title) {
		boolean flag = false;

		try {
			if (waits.waitUntilElementIsPresent(txtSearchOptions)) {
				flag = true;
				LogUtility.logInfo("--->verifySearchOptionsTitle<---", "Found the title " + title);
			}

		} catch (Exception e) {
			LogUtility.logException("verifySearchOptionsTitle", "Failed to find the title", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * checks for the error message
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean checkForTheMessages(String errorMsg, String errorType) {
		boolean flag = false;
		WebElement eleToGetText = null;
		try {
			switch (errorType) {
			case "NoTransferHistory":
				eleToGetText = txtNoTransferHistory;
				break;
			case "NoPendingTransfers":
				eleToGetText = txtNoPendindgTransfers;
				break;
			default:
				LogUtility.logInfo("checkForTheMessages", "Invalid Error Type " + errorType);
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText);
			if (wolWebUtil.verifyText(eleToGetText, errorMsg)) {
				flag = true;
				LogUtility.logInfo("checkForTheMessages", "Message " + errorMsg + " is found");
			}
		} catch (Exception e) {
			LogUtility.logException("checkForTheMessages", "Failed to find the message", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clicks on cancel button
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean clickOnCancel() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnCancel)) {
				webActions.clickElement(btnCancel);
				flag = true;
				LogUtility.logInfo("clickOnCancel", "Clicked on cancel button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCancel", "Failed to click on cancel", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clicks on delete button
	 * 
	 * @param errorMsg
	 * @return
	 */
	public String checkForTheButtonsExistence(String buttons) {
		WebElement eleToCheck = null;
		String buttonsDisplayed = "";
		try {
			for (String eachButton : buttons.split(",")) {
				switch (eachButton) {
				case "Delete":
					eleToCheck = btnDelete;
					break;
				case "Edit":
					eleToCheck = btnEdit;
					break;
				case "Cancel":
					eleToCheck = btnCancel;
					break;
				case "Continue":
					eleToCheck = btnContinue;
					break;
				case "Update":
					eleToCheck = btnContinueInTransfers;
					break;
				default:
					LogUtility.logInfo("checkForTheButtonsExistence", "Invalid button " + buttons);
					break;
				}
				waits.waitUntilElementIsPresent(eleToCheck);
				if (webActions.isDisplayed(eleToCheck)) {
					buttonsDisplayed = buttonsDisplayed + eachButton + ",";
					LogUtility.logInfo("--->checkForTheButtonsExistence<---", eleToCheck + " button is displayed");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkForTheButtonsExistence", "Failed to find the button " + buttonsDisplayed, e,
					LoggingLevel.ERROR, true);
		}
		return buttonsDisplayed;
	}

	/**
	 * clicks on delete button
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean clickOnDelete() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnContinueInTransfers)) {
				webActions.clickElement(btnContinueInTransfers);
				flag = true;
				LogUtility.logInfo("clickOnDelete", "Clicked on delete button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnDelete", "Failed to click on delete button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clicks on cancel button
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean clickOnCancelYesOrNo(String yesOrNo) {
		boolean flag = false;
		WebElement eleToclick = null;
		try {
			if (yesOrNo.equals("yes"))
				eleToclick = btnYes;
			else
				eleToclick = btnNo;
			if (waits.waitUntilElementIsPresent(eleToclick)) {
				webActions.clickElement(eleToclick);
				flag = true;
				LogUtility.logInfo("clickOnCancelYesOrNo", "Clicked on cancel " + yesOrNo + " button");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCancelYesOrNo", "Failed to click on cancel " + yesOrNo, e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public String getFromAccount() {
		String fromAcc = "";
		try {
			fromAcc = enteredDetails.get("Transfer From").split("  ")[0].replaceAll("x", "");
			setValueInRuntimeDataMap("ExternalTransfersAccount", fromAcc);
		} catch (Exception e) {
			LogUtility.logException("getFromAccount", "Failed to get from Account ", e, LoggingLevel.ERROR, true);
		}
		return fromAcc;
	}
}