package com.wb.wol_web.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class InternalTransfersPage extends ObjectBase {

	public String confirmNumber;
	public String disclosurelnkText;
	public String txtdisclosurelightbox;
	public LinkedHashMap<String, String> confirmDetails;
	public LinkedHashMap<String, String> historyDetails;
	public String acctvalue;

	public InternalTransfersPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "from_account__error-message-text")
	protected WebElement txtFromErrMsg;

	@FindBy(id = "frequency__error-message-text")
	protected WebElement txtFrequencyErrMsg;

	@FindBy(id = "transfers_remaining__error-message-text")
	protected WebElement txtRemainingErrMsg;

	@FindBy(id = "transfer_date__error-message-text")
	protected WebElement txtDateErrMsg;

	@FindBy(id = "to_account__error-message-text")
	protected WebElement txtToErrMsg;

	@FindBy(id = "transfer_amount__error-message-text")
	protected WebElement txtAmountErrMsg;

	@FindBy(id = "immediate_transfer_timing_warning_message__body")
	protected WebElement txtImmediateContent;

	@FindBy(id = "transfer_verification-edit__buttonText")
	protected WebElement btnEdit;

	@FindBy(id = "scheduled_transfer_timing_warning_message__body")
	protected WebElement txtFutureContent;

	@FindBy(css = "table")
	protected WebElement txtHistoryDetails;

	@FindBy(xpath = "//a[@id='transfers']")
	protected WebElement lnkMoneyTransfers;

	@FindBy(xpath = "//section[@id='confirmationFormSection']//div//div//label")
	protected List<WebElement> txtCnfrmLabels;

	@FindBy(xpath = "//section[@id='confirmationFormSection']//div//div//span//span")
	protected List<WebElement> txtCnfrmValues;

	@FindBy(xpath = "//*[contains(@id,'transfer_between_webster_accounts__pageErrors__transfers_invalidbwloanaccounts__body')]")
	protected WebElement txtLoanAcctsErrMsg;

	@FindBy(xpath = "//*[contains(@id,'transfer_no_accounts__pageErrors__transfer_no_accounts__pageError__body')]")
	protected WebElement txtNoAcctsErrMsg;

	@FindBy(xpath = "//h1[contains(text(),'Disclosure')]/..//button[text()='Close']")
	protected WebElement btnDisclosureClose;

	@FindBy(xpath = "//a[@id='inlineLightbox_1']")
	protected WebElement lnkTransferDisclosure;

	@FindBy(xpath = "//*[@id='date1__input']")
	protected WebElement txtTransferDate;

	@FindBy(xpath = "//*[@id='transfers_note_payments_msp__body']")
	protected WebElement txtMSPAccountContent;

	@FindBy(xpath = "//*[@id='not_current_message__body']")
	protected WebElement txtPrincipalContent;

	// @FindBy(xpath = "//table/tbody//tr")
	@FindBy(css = "table > tbody tr")
	protected List<WebElement> tblRows;

	// @FindBy(xpath = "//table//thead/tr/th")
	@FindBy(css = "table thead > tr > th")
	protected List<WebElement> tblColumns;

	// @FindBy(xpath = "//table")
	@FindBy(css = "table")
	protected WebElement tblName;

	@FindBy(css = "h1[data-wbst-message-key*='transfer'],h1[data-mm-template*='pageTitle'],h3[data-wbst-message-key*='transfer']")
	protected WebElement txtTransferPageTitles;

	@FindBy(css = "div.pageHeaderBlock h3")
	protected WebElement txtPendingTransferPageTitles;

	@FindBy(xpath = "//div[@id='transfer_complete__pageAffirmativeNotice__body']")
	protected WebElement txtTransferConfrmMsg;

	@FindBy(xpath = "//select[@id='from_account__input']")
	protected WebElement lstTransferFrom;

	@FindBy(xpath = "//select[@id='from_account__input']/option")
	protected List<WebElement> lstTransferFromOptions;

	@FindBy(xpath = "//select[@id='to_account__input']")
	protected WebElement lstTransferTo;

	@FindBy(xpath = "//input[@id='transfer_amount__input']")
	protected WebElement txtTransferAmount;

	@FindBy(xpath = "//button[@id='date1__calendar-button']")
	protected WebElement iconTransferClndr;

	@FindBy(xpath = "//div[@class='picker__nav--next']")
	protected WebElement btnNext;

	@FindBy(xpath = "//input[@id='repeat__option1__input']")
	protected WebElement chkRepeatTransfer;

	@FindBy(xpath = "//select[@id='frequency__input']")
	protected WebElement lstFrequency;

	@FindBy(xpath = "//input[@id='transfers_remaining__input']")
	protected WebElement txtRemainTransfers;

	@FindBy(xpath = "//table//tbody//tr//td//div[not(@aria-disabled='true')]")
	protected List<WebElement> lnkDateElement;

	@FindBy(xpath = "//legend[@id='paymenttype__label']")
	protected WebElement txtloanTransferTypelbl;

	@FindBy(xpath = "//input[@id='paymenttype__option--REGULAR__input']")
	protected WebElement rdbtnRegular;

	@FindBy(xpath = "//input[@id='paymenttype__option--PRINCIPAL__input' and not(@disabled='disabled')]")
	protected WebElement rdbtnPrincipal;

	@FindBy(xpath = "//input[@id='paymenttype__option--ESCROW__input']")
	protected WebElement rdbtnEscrow;

	@FindBy(xpath = "//*[contains(@id,'confirmationNumber')]/span")
	protected WebElement txtTransferConfrmNum;

	@FindBy(xpath = "//*[@value='continue']")
	protected WebElement btnTransferContinue;

	/**
	 * getTransferConfirmationNumber: To get confirmation number value from Transfer
	 * Confirmation Page
	 */
	public boolean getTransferConfirmationNumber() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtTransferConfrmNum);
			confirmNumber = webActions.getText(txtTransferConfrmNum);
			if (!confirmNumber.isEmpty()) {
				flag = true;
				LogUtility.logInfo("getTransferConfirmationNumber", "Get Transfer Confirmation number ");
			} else
				LogUtility.logInfo("getTransferConfirmationNumber", "Failed to Get Transfer Confirmation number ");
		} catch (Exception e) {
			LogUtility.logException("getTransferConfirmationNumber", "Failed to Get Transfer Confirmation number ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectLoanPaymentType: To Select Payment type for loan account
	 * 
	 * @param transferDetails: Type of the payment
	 */
	public void selectLoanPaymentType(Map<String, String> transferDetails) {
		try {
			if (webActions.isDisplayed(txtloanTransferTypelbl) == true) {
				switch (transferDetails.get("loanPayType")) {
				case "Regular":
					webActions.clickElement(rdbtnRegular);
					break;
				case "Escrow":
					webActions.clickElement(rdbtnEscrow);
					break;
				case "Principal":
					waits.waitUntilElementIsPresent(rdbtnPrincipal, 10);
					webActions.clickElementJS(rdbtnPrincipal);
					break;
				}
			}
			LogUtility.logInfo("selectLoanPaymentType", "Selcted Payment Type of Loan account");
		} catch (Exception e) {
			LogUtility.logException("selectLoanPaymentType", "Failed to Selct Payment Type of Loan account", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * clickContinueToTransfer: To click on continue button among transfer pages
	 */
	public void clickContinueToTransfer() {
		try {
			waits.waitUntilElementIsPresent(btnTransferContinue);
			webActions.clickElement(btnTransferContinue);
			LogUtility.logInfo("clickContinueToTransfer", "Clicked on Continue Button in Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickContinueToTransfer", "Failed to Continue Button in Transfers Page", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickEditTransfer: To click on Edit button among transfer pages
	 */
	public void clickEditTransfer() {
		try {
			waits.waitUntilElementIsPresent(btnEdit, 10);
			webActions.clickElement(btnEdit);
			LogUtility.logInfo("clickEditTransfer", "Clicked on Edit Button in Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickEditTransfer", "Failed to Edit Button in Transfers Page", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickLinkinTablebyvalue: To click on Date Link in Pending Transfers Page
	 */
	public boolean clickLinkinTablebyvalue() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(tblName);
			wolWebUtil.clickOnTableCell(tblName, confirmNumber);
			if (waits.waitUntilElementIsPresent(txtTransferPageTitles)) {
				flag = true;
				LogUtility.logInfo("clickLinkinTablebyvalue", "Clicked on Date Link in Manage Pending Transfers Page");
			} else
				LogUtility.logInfo("clickLinkinTablebyvalue",
						"Failed to Click on Date Link in Manage Pending Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickLinkinTablebyvalue",
					"Failed to Click on Date Link in Manage Pending Transfers Page", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectTransferFromAcct: To Select account in Transfer From Drop down
	 * 
	 * @param transferDetails: Account Number
	 */
	public void selectTransferFromAcct(Map<String, String> transferDetails) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			wolWebUtil.selectValueByPartialVisibleText(lstTransferFrom, transferDetails.get("FromAcct"));
			LogUtility.logInfo("selectTransferFromAcct", "Selected Account in Transfer From Drop down");
		} catch (Exception e) {
			LogUtility.logException("selectTransferFromAcct", "Failed to Select Account in Transfer From Drop down", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectTransferToAcct:-To Select account in Transfer To Drop down
	 * 
	 * @param transferDetails
	 */
	public void selectTransferToAcct(Map<String, String> transferDetails) {
		try {
			wolWebUtil.selectValueByPartialVisibleText(lstTransferTo, transferDetails.get("ToAcct"));
			LogUtility.logInfo("selectTransferToAcct", "Selected Account in Transfer To Drop down");
		} catch (Exception e) {
			LogUtility.logException("selectTransferFromAcct", "Failed to Select Account in Transfer To Drop down", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectTransferFromAcct: To Select account in Transfer From Drop down
	 * 
	 * @param transferDetails: Account Number
	 */
	public void selectTransferFromAcct(String acctno) {
		try {
			wolWebUtil.selectValueByPartialVisibleText(lstTransferFrom, acctno);
			acctvalue = wolWebUtil.getDefaultValueForSelect(lstTransferFrom);
			LogUtility.logInfo("selectTransferFromAcct", "Selected Account in Transfer From Drop down");
		} catch (Exception e) {
			LogUtility.logException("selectTransferFromAcct", "Failed to Select Account in Transfer From Drop down", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * clearTransferFromAcct: To Select account in Transfer From Drop down
	 * 
	 * @param transferDetails: Account Number
	 */
	public void clearTransferFromAcct() {
		try {
			webActions.selectDropDownByIndex(lstTransferFrom, 0);
			LogUtility.logInfo("clearTransferFromAcct", "Account is cleared in Transfer From Drop down");
		} catch (Exception e) {
			LogUtility.logException("clearTransferFromAcct", "Account is is not cleared in Transfer From Drop down", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * getTransferToAcct:-To get account number from Transfer To Drop down
	 * 
	 * @param transferDetails
	 */
	public String getTransferToAcct() {
		try {
			String acctno = wolWebUtil.getDefaultValueForSelect(lstTransferTo);
			if (acctno.isEmpty())
				LogUtility.logInfo("getTransferToAcct", "Account is cleared in Transfer To Drop down");
			else
				LogUtility.logInfo("getTransferToAcct", "Account is auto populated in Transfer To Drop down");
			return acctno;
		} catch (Exception e) {
			LogUtility.logException("enterAmount", "Account is auto populated in Transfer To Drop down", e,
					LoggingLevel.ERROR, true);
			return "Null";
		}
	}

	/**
	 * enterAmount:- To Enter amount in Transfers Page
	 * 
	 * @param transferDetails
	 */
	public boolean enterAmount(Map<String, String> transferDetails) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtTransferAmount);
			String value = webActions.getAttributeValue(txtTransferAmount, "value");
			if (value.isEmpty()) {
				value = transferDetails.get("Amount");
			}
			webActions.setValueJs(txtTransferAmount, value);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtTransferAmount, "value").equalsIgnoreCase(value)) {
				flag = true;
				LogUtility.logInfo("enterAmount", "Entered value in Transfer Amount Field");
			} else
				LogUtility.logInfo("enterAmount", "Failed to Enter value in Transfer Amount Field");
		} catch (Exception e) {
			LogUtility.logException("enterAmount", "Failed to Enter value in Transfer Amount Field", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickonTransferCal:- To click on Calendar button in Transfers
	 */
	public void clickonTransferCal() {
		try {
			waits.waitUntilElementIsPresent(iconTransferClndr);
			webActions.clickElement(iconTransferClndr);
			Date date = new Date();
			String strDateFormat = "dd";
			SimpleDateFormat dateFormat = new SimpleDateFormat(strDateFormat);
			String CurrDate = dateFormat.format(date);
			if (Integer.parseInt(CurrDate) > 27) {
				webActions.clickElement(btnNext);
			}
			LogUtility.logInfo("clickonTransferCal", "Clicked on Calendar Button");
		} catch (Exception e) {
			LogUtility.logException("clickonTransferCal", "Failed to Click on Calendar Button", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * selectTransferTypeDetails:- To Enter required details to do internal Transfer
	 * 
	 * @param transferDetails:- Transfer Type,Frequency,No.of Transfers,Date
	 */
	public void selectTransferTypeDetails(Map<String, String> transferDetails) {
		try {
			switch (transferDetails.get("Type")) {
			case "Future":
				clickonTransferCal();
				webActions.clickElement(lnkDateElement.get(Integer.parseInt(transferDetails.get("Days"))));
				break;
			case "Recurring":
				clickonTransferCal();
				webActions.clickElement(lnkDateElement.get(Integer.parseInt(transferDetails.get("Days"))));
				waits.waitUntilElementIsPresent(chkRepeatTransfer);
				webActions.clickElementJS(chkRepeatTransfer);
				waits.waitUntilElementIsPresent(lstFrequency);
				webActions.selectDropDownByText(lstFrequency, transferDetails.get("Frequency"));
				webActions.setValue(txtRemainTransfers, transferDetails.get("Transfers"));
				break;
			}
			LogUtility.logInfo("selectTransferTypeDetails", "Selected Transfer Details");
		} catch (Exception e) {
			LogUtility.logException("selectTransferTypeDetails", "Failed to Select Internal Transfer Type", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * verifyInternalTransfersPageTitle:- To verify page headers among internal
	 * Transfers pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyInternalTransfersPageTitle(String message) {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtTransferPageTitles))
				flag = wolWebUtil.verifyText(txtTransferPageTitles, message);
			else if (waits.waitUntilElementIsPresent(txtPendingTransferPageTitles))
				flag = wolWebUtil.verifyText(txtPendingTransferPageTitles, message);
			LogUtility.logInfo("verifyInternalTransfersPageTitle", "verified Internal Transfer Page Title message");
		} catch (Exception e) {
			LogUtility.logException("verifyInternalTransfersPageTitle",
					"Failed to verify Internal Transfer Page Title message", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyInternalTransfersConfrmMsg:- To verify confirmation message in Transfer
	 * Confirmation page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyInternalTransfersConfrmMsg(String message) {
		try {
			return wolWebUtil.verifyText(txtTransferConfrmMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyInternalTransfersConfrmMsg",
					"Failed to verify Internal Transfer confirmation message", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyNoAccountsError:- To verify the error message in Transfers page for
	 * theuser has no account
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyNoAccountsError(String message) {
		try {
			return wolWebUtil.verifyText(txtNoAcctsErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyNoAccountsError", "Failed to verify  No Account Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyLoanAccountsError:- To verify the error message in Transfers page for
	 * Loan to Loan transfer
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyLoanAccountsError(String message) {
		try {
			return wolWebUtil.verifyText(txtLoanAcctsErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyLoanAccountsError", "Failed to verify  Loan Account Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyMSPAccountContent:- To verify the note content displayed for MSP
	 * account
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyMSPAccountContent(String message) {
		try {
			return wolWebUtil.verifyText(txtMSPAccountContent, message);
		} catch (Exception e) {
			LogUtility.logException("verifyMSPAccountContent", "Failed to verify  MSP Account content message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyPrincipalContent:- To verify the note content displayed for Principal
	 * only option for loan accounts
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPrincipalContent(String message) {
		try {
			return wolWebUtil.verifyText(txtPrincipalContent, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPrincipalContent", "Failed to verify  Principal content message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * enterTransferDate: To Enter Date in Transfer Date text field
	 * 
	 * @param days: Days
	 */
	public void enterTransferDate(int days) {
		try {
			waits.waitUntilElementIsPresent(txtTransferDate, 10);
			wolWebUtil.setRequireDate(txtTransferDate, "Days", days);
			LogUtility.logInfo("enterTransferDate", "Entered Required Date in Transfer Date field");
		} catch (Exception e) {
			LogUtility.logException("clickTransferDisclosure", "Failed to click  Transfer Disclosure Link", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickTransferDisclosure:- To Click on Disclosure Link in Transfer Page
	 */
	public boolean clickTransferDisclosure() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkTransferDisclosure, 10);
			webActions.clickElement(lnkTransferDisclosure);
			disclosurelnkText = webActions.getText(lnkTransferDisclosure);
			if (waits.waitUntilElementIsPresent(btnDisclosureClose)) {
				flag = true;
				LogUtility.logInfo("clickTransferDisclosure", "Clicked on Disclosure Link in transfers Page");
			} else
				LogUtility.logInfo("clickTransferDisclosure", "Failed to Click on Disclosure Link in transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickTransferDisclosure", "Failed to click  Transfer Disclosure Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyTransfersLink-To Verify Money Market Transfers Link is displayed or not
	 * in Disclosure Light Box
	 * 
	 * @return- True/False
	 */
	public boolean verifyTransfersLink() {
		try {
			waits.waitUntilElementIsPresent(lnkMoneyTransfers, 20);
			txtdisclosurelightbox = webActions.getText(lnkMoneyTransfers);
			return webActions.isDisplayed(lnkMoneyTransfers);
		} catch (Exception e) {
			LogUtility.logException("verifyTransfersLink", "Failed to verify Transfer Link", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * clickDisclosureCloseButton:- To Click on Close button in Disclosure Lightbox
	 */
	public void clickDisclosureCloseButton() {
		try {
			waits.waitUntilElementIsPresent(btnDisclosureClose, 10);
			webActions.clickElementJS(btnDisclosureClose);
			waits.staticWait(5);
			LogUtility.logInfo("clickDisclosureCloseButton",
					"Clicked on Close button in Disclosure Light box of transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickDisclosureCloseButton", "Failed to click Disclosure Close button", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * getTransferCnfrmDetails- To get details of Transfer in Transfer Confirmation
	 * page
	 */
	public void getTransferCnfrmDetails() {
		try {
			confirmDetails = new LinkedHashMap<String, String>();
			for (int i = 0; i < txtCnfrmLabels.size(); i++)
				confirmDetails.put(txtCnfrmLabels.get(i).getText(), txtCnfrmValues.get(i).getText());
			LogUtility.logInfo("getTransferCnfrmDetails", "Retrieved all the transfer Confirmation details");
		} catch (Exception e) {
			LogUtility.logException("getTransferCnfrmDetails", "Failed to get Transfer confirmation details", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * verifyTransferDetails- To get details of Transfer in Transfer history page
	 */
	public void verifyTransferDetails() {
		try {
			historyDetails = new LinkedHashMap<String, String>();
			List<WebElement> labels = txtHistoryDetails.findElements(By.cssSelector(" tr"));
			for (int i = 0; i < labels.size(); i++) {
				WebElement labelName = labels.get(i).findElement(By.cssSelector(" td:nth-child(1)"));
				WebElement value = labels.get(i).findElement(By.cssSelector(" td:nth-child(2)"));
				historyDetails.put(labelName.getText(), value.getText());
			}
			LogUtility.logInfo("verifyTransferDetails", "verified all the transfer Confirmation details");
		} catch (Exception e) {
			LogUtility.logException("verifyTransferDetails", "Failed to verify Transfer confirmation details", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * validateTransferDetails-To compare transfer details in Confirmation page &
	 * History page
	 * 
	 * @return
	 */
	public boolean validateTransferDetails() {
		try {
			return wolWebUtil.mapValuesComaparison(historyDetails, confirmDetails);
		} catch (Exception e) {
			LogUtility.logException("validateTransferDetails", "Failed to validate Transfer details", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyImmediateContent:- To verify the note content displayed for Immediate
	 * Transfer in Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyImmediateContent(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtImmediateContent, message);
		} catch (Exception e) {
			LogUtility.logException("verifyImmediateContent", "Failed to Verify Immediate Transfer Content Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyFutureContent:- To verify the note content displayed for Future
	 * Transfer in Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyFutureContent(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtFutureContent, message);
		} catch (Exception e) {
			LogUtility.logException("verifyFutureContent", "Failed to Verify Future Transfer Content Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	public boolean verifyTransferFromValues(String value) {
		return wolWebUtil.verifyListValues(lstTransferFrom, value);
	}

	public boolean verifyTransferToValues(String value) {
		return wolWebUtil.verifyListValues(lstTransferTo, value);
	}

	/**
	 * verifyFromErrMsg:- To verify the error message for Transfer from field in
	 * Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyFromErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtFromErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyFromErrMsg", "Failed to Verify Transfer From Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyToErrMsg:- To verify the error message for Transfer To field in
	 * Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyToErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtToErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyToErrMsg", "Failed to Verify Transfer To Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyAmountErrMsg:- To verify the error message for Transfer Amount field in
	 * Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAmountErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtAmountErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAmountErrMsg", "Failed to Verify Amount Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyFrequencyErrMsg:- To verify the error message for Transfer frequency
	 * field in Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyFrequencyErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtFrequencyErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyFrequencyErrMsg", "Failed to Verify Frequency Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyRemainingTransfersErrMsg:- To verify the error message for Transfer
	 * RemainingTransfers field in Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyRemainingTransfersErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtRemainingErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyRemainingTransfersErrMsg",
					"Failed to Verify Remaining Transfers Error Message", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyDateErrMsg:- To verify the error message for Transfer Date field in
	 * Transfers page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyDateErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtDateErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyDateErrMsg", "Failed to Verify Date Error Message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

}
