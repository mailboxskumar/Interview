package com.wb.wol_web.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author Veerababu Pedireddi
 *
 */
public class SearchForTransactionsPage extends ObjectBase {

	public SearchForTransactionsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = ".pageHeaderBlock>h1")
	protected WebElement titleSearchForTrans;

	@FindBy(css = ".pageHeaderBlock>p")
	protected WebElement msgSearchForTransKeyContent;

	@FindBy(css = ".errorIndicator>p")
	protected WebElement msgDefaultError;

	@FindBy(css = "#accounts")
	protected WebElement cmbWebsterAccount;

	@FindBy(css = "#dateRange")
	protected WebElement optDateRange;

	@FindBy(css = ".errorInline")
	protected WebElement msgDateError;

	@FindBy(css = "#from_date")
	protected WebElement txtFromDate;

	@FindBy(css = "#to_date")
	protected WebElement txtToDate;

	@FindBy(css = "#trans_type")
	protected WebElement cmbTransType;

	@FindBy(css = "#submit")
	protected WebElement btnSearch;

	@FindBy(css = "div.ProdBodyBgShadow div div:nth-child(3) div")
	protected WebElement optTimePeriod;

	@FindBy(id = "cancel")
	protected WebElement btnCancel;

	protected String fromDateValue = "";
	protected String toDateValue = "";

	/**
	 * To verify the Title in Search for Transactions page
	 *
	 */
	public boolean verifySearchForTransPage(String pageTitle) {
		try {
			return wolWebUtil.verifyText(titleSearchForTrans, pageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifySearchForTransPage", pageTitle + " Page is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Key Content in Search for Transactions page
	 *
	 */
	public boolean verifyKeyContentInSearchForTransPage(String keyContent) {
		try {
			return wolWebUtil.verifyText(msgSearchForTransKeyContent, keyContent);
		} catch (Exception e) {
			LogUtility.logException("verifyKeyContentInSearchForTransPage", keyContent + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Default error message
	 */
	public boolean verifyDefaultErrorMsg(String defaultErrorMsg) {
		try {
			return wolWebUtil.verifyText(msgDefaultError, defaultErrorMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyDefaultErrorMsg", defaultErrorMsg + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To select the WebSter Account from drop down
	 */
	public boolean selectWebsterAccount(String websterAccount) {
		boolean flag = false;
		try {
			boolean websterAcc = webActions.isDisplayed(cmbWebsterAccount);
			if (websterAcc) {
				wolWebUtil.selectValueByPartialVisibleText(cmbWebsterAccount, websterAccount);
				LogUtility.logInfo("--->selectWebsterAccount<---", "Webster Account Selected from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectWebsterAccount", "Unable to select " + websterAccount, e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Date Range option is selected or not
	 * 
	 */
	public boolean verifyDateRangeOptionSelected() {
		try {
			return webActions.isChecked(optDateRange);
		} catch (Exception e) {
			LogUtility.logException("verifyDateRangeOptionSelected", "Unable to select the Date Range option", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Dates error message
	 */
	public boolean verifyDatesErrorMsg(String dateErrorMsg) {
		try {
			return wolWebUtil.verifyTextContains(msgDateError, dateErrorMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyDatesErrorMsg", dateErrorMsg + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Enter the from date given in the from date field
	 *
	 */
	public String enterFromDate(String fromDate) {
		try {
			boolean fromDateField = webActions.isDisplayed(txtFromDate);
			if (fromDateField) {
				fromDateValue = wolWebUtil.getOldDate(fromDate);
				webActions.setValue(txtFromDate, fromDateValue);
				LogUtility.logInfo("--->enterFromDate<---", "From date entered");
			}
		} catch (Exception e) {
			LogUtility.logException("enterFromDate", "Unable to enter the " + fromDate, e, LoggingLevel.ERROR, true);
		}
		return fromDateValue;

	}

	/**
	 * To Enter the to date given in the from date field
	 *
	 */
	public String enterToDate(String toDate) {
		try {
			boolean toDateField = webActions.isDisplayed(txtToDate);
			if (toDateField) {
				toDateValue = wolWebUtil.getOldDate(toDate);
				webActions.setValue(txtToDate, toDateValue);
				LogUtility.logInfo("--->enterToDate<---", "To date entered");
			}
		} catch (Exception e) {
			LogUtility.logException("enterToDate", "Unable to enter the " + toDate, e, LoggingLevel.ERROR, true);
		}
		return toDateValue;
	}

	/**
	 * To select the Transaction Type from drop down
	 */
	public boolean selectTransactionType(String transactionType) {
		boolean flag = false;
		try {
			boolean websterAcc = webActions.isDisplayed(cmbTransType);
			if (websterAcc) {
				webActions.selectDropDownByText(cmbTransType, transactionType);
				LogUtility.logInfo("--->selectTransactionType<---", "Transaction Type Selected from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectTransactionType", "Unable to select " + transactionType, e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on the Search button in Search for Transaction page
	 */
	public boolean clickOnSearchButton() {
		boolean flag = false;
		try {
			boolean searchButton = webActions.isDisplayed(btnSearch);
			if (searchButton) {
				webActions.clickElement(btnSearch);
				LogUtility.logInfo("---> clickOnSearchButton <---", "Clicked on Search button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnSearchButton", "Unable to click on Search button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the WebSter Account drop down
	 */
	public boolean verifyWebsterAccount() {
		boolean flag = false;
		try {
			boolean websterAcc = webActions.isDisplayed(cmbWebsterAccount);
			if (websterAcc) {
				LogUtility.logInfo("--->verifyWebsterAccount<---", "Webster Account dropdown field displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyWebsterAccount", "Unable to display Webster Account dropdown field ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Search button should display
	 */
	public boolean verifySearchButton() {
		boolean flag = false;
		try {
			boolean searchButton = webActions.isDisplayed(btnSearch);
			if (searchButton) {
				LogUtility.logInfo("---> verifySearchButton <---", " Search button displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySearchButton", "Unable to display the Search button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Cancel button should display
	 */
	public boolean verifyCancelButton() {
		boolean flag = false;
		try {
			boolean cancelButton = webActions.isDisplayed(btnCancel);
			if (cancelButton) {
				LogUtility.logInfo("---> verifyCancelButton <---", " Cancel button displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCancelButton", "Unable to display the Cancel button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To Verify given options in the list
	 * 
	 * 
	 */
	public boolean verifyGivenOptionsInTheList(List<String> listValue) {
		boolean flag = false;
		try {
			int count = 0;
			List<WebElement> columnNames = optTimePeriod.findElements(By.tagName("label"));
			for (int colNum = 0; colNum < columnNames.size(); colNum++) {
				String columnName = columnNames.get(colNum).getText();
				for (int listoption = 0; listoption < listValue.size(); listoption++) {
					String listValues = listValue.get(listoption);
					if (listValues.contains(columnName)) {
						count++;
					}
				}
			}
			if (count == listValue.size()) {
				LogUtility.logInfo(listValue + " ---->  Value Matched--->");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyGivenOptionsInTheList", "Given values were not in the lis", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the From and To dates should display
	 */
	public boolean verifyFromAndToDates() {
		boolean flag = false;
		try {
			boolean fromdate = webActions.isDisplayed(txtFromDate);
			boolean toDate = webActions.isDisplayed(txtToDate);
			if (fromdate && toDate) {
				LogUtility.logInfo("---> verifyFromAndToDates <---", " From and To dates fields displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFromAndToDates", "Unable to display the Froma nd To date fields", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

}
