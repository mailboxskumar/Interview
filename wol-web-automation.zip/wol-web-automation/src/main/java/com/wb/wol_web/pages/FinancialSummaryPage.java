package com.wb.wol_web.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author Veerababu Pedireddi
 *
 */

public class FinancialSummaryPage extends ObjectBase {

	public FinancialSummaryPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "nickname__display")
	protected WebElement lblAccountNickNameDisplay;

	@FindBy(xpath = "(//button[contains(.,'Print')])[2]")
	protected WebElement btnPrintInLightBox;

	@FindBy(xpath = "(//button[contains(.,'Close')])[9]")
	protected WebElement btnCloseInLightBox;

	@FindBy(xpath = "(//button[contains(.,'Print')])[3]")
	protected WebElement btnInvestmentAccPrintInLightBox;

	@FindBy(xpath = "(//button[contains(.,'Close')])[10]")
	protected WebElement btnInvestmentAccCloseInLightBox;

	protected String accountNickNamePath = "//a[contains(text(),'%s')]/following::a[1]";

	protected String updatedAccountNickName = "";

	/**
	 * To Select the updated nick name Account and Click on the Account Details link
	 */

	public boolean clickOnAccountDetailsInSummaryPage() {
		boolean flag = false;
		try {
			updatedAccountNickName = AddOrMangeWebsterAccountsPage.accountNickNameInPreviewPage;
			WebElement accDetails = driver
					.findElement(By.xpath(String.format(accountNickNamePath, updatedAccountNickName)));
			// After clicked on Summary tab, page loading takes time
			waits.staticWait(3);
			boolean accountDetails = webActions.isDisplayed(accDetails);
			if (accountDetails) {
				webActions.clickElement(accDetails);
				LogUtility.logInfo("---> clickOnAccountDetailsInSummaryPage<---", "Clicked On Account details link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnAccountDetailsInSummaryPage", "Unable to click on Account Details link",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Updated Nick name in Account Details page
	 */

	public boolean verifyNickNameInAccDetailsPage() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lblAccountNickNameDisplay, 20);
			String nickNameAccPage = webActions.getText(lblAccountNickNameDisplay);
			updatedAccountNickName = AddOrMangeWebsterAccountsPage.accountNickNameInPreviewPage;
			if (updatedAccountNickName.equals(nickNameAccPage)) {
				LogUtility.logInfo("---> verifyNickNameInAccDetailsPage<---", "Updated Nick Name is Displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyNickNameInAccDetailsPage", "Unable to displaye Nick name", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Select the Account Details link in Summary Page
	 */

	public boolean clickOnAccountDetailsLink(String accountNumber) {
		boolean flag = false;
		try {
			WebElement accDetails = driver.findElement(By.xpath(String.format(accountNickNamePath, accountNumber)));
			// After clicked on Summary tab, page loading takes time
			waits.staticWait(3);
			boolean accountDetails = webActions.isDisplayed(accDetails);
			if (accountDetails) {
				webActions.clickElement(accDetails);
				LogUtility.logInfo("---> clickOnAccountDetailsLink<---", "Clicked On Account details link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnAccountDetailsLink", "Unable to click on Account Details link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Close the Light Box
	 */

	public boolean clickOnCloseButton() {
		boolean flag = false;
		try {
			boolean closeButton = webActions.isDisplayed(btnCloseInLightBox);
			if (closeButton) {
				webActions.clickElement(btnCloseInLightBox);
				LogUtility.logInfo("---> clickOnCloseButton<---", "Clicked On Close button for Lightbox");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCloseButton", "Unable to click on Close button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To Verify Print button present in the Light Box
	 */

	public boolean isDisplayPrintButton() {
		boolean flag = false;
		try {
			boolean printButton = webActions.isDisplayed(btnPrintInLightBox);
			if (printButton) {
				LogUtility.logInfo("---> isDisplayPrintButton<---", "Print button displayed in Lightbox");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("isDisplayPrintButton", "Unable to click on Print button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To Verify Close button present in the Light Box
	 */

	public boolean isDisplayCloseButton() {
		boolean flag = false;
		try {
			boolean closeButton = webActions.isDisplayed(btnCloseInLightBox);
			if (closeButton) {
				LogUtility.logInfo("---> isDisplayCloseButton<---", "Close button displayed in Lightbox");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("isDisplayCloseButton", "Unable to click on Close button", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To Verify Print button present in the Light Box for Investment Account
	 */

	public boolean isDisplayPrintButtonForInvestmentAcc() {
		boolean flag = false;
		try {
			boolean printButton = webActions.isDisplayed(btnInvestmentAccPrintInLightBox);
			if (printButton) {
				LogUtility.logInfo("---> isDisplayPrintButtonForInvestmentAcc<---",
						"Print button displayed in Lightbox");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("isDisplayPrintButtonForInvestmentAcc", "Unable to display Print button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify Close button present in the Light Box for Investment Account
	 */

	public boolean isDisplayCloseButtonForInvestmentAcc() {
		boolean flag = false;
		try {
			boolean closeButton = webActions.isDisplayed(btnInvestmentAccCloseInLightBox);
			if (closeButton) {
				LogUtility.logInfo("---> isDisplayCloseButtonForInvestmentAcc<---",
						"Close button displayed in Lightbox");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("isDisplayCloseButtonForInvestmentAcc", "Unable to display Close button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

}