package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class EducationConsolidationLoanPage extends ObjectBase {

	public EducationConsolidationLoanPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "submit")
	protected WebElement btnViewStatement;

	@FindBy(css = "table:nth-child(3)  tbody  tr  td:nth-child(4)  strong  a")
	protected List<WebElement> lstStudentLoan;

	@FindBy(css = "#details_form div span")
	protected List<WebElement> lstAccountValues;

	@FindBy(css = "#details_form div span")
	protected List<WebElement> lstAccountFields;

	@FindBy(css = "table > tbody:nth-child(4) > tr td:nth-child(2)")
	protected List<WebElement> lstAccountValuesWebCom;

	@FindBy(css = "table > tbody:nth-child(4) > tr td:nth-child(1)")
	protected List<WebElement> lstAccountFieldsWebCom;

	@FindBy(css = "table > tbody:nth-child(4) > tr td:nth-child(2)")
	protected List<WebElement> lstPaymentAcctValuesWebCom;

	@FindBy(css = "table > tbody:nth-child(4) > tr td:nth-child(1)")
	protected List<WebElement> lstPaymentAcctFieldsWebCom;

	@FindBy(css = "#pageContent > ul.accordion.js-accordion > li > a")
	protected List<WebElement> lstStudentLoanWOL;

	@FindBy(css = "#pageContent  ul.accordion.js-accordion  li:nth-child(4)  div form  div.checkmark")
	protected WebElement msgStudentLoanWOL;

	@FindBy(css = "#pageContent  ul.accordion.js-accordion  li:nth-child(4)  div  form  div.formRow  div label")
	protected WebElement lblNickName;

	@FindBy(css = "#pageContent  ul.accordion.js-accordion  li:nth-child(4)  div  form  div.formRowButtons  input")
	protected WebElement btnContinue;

	@FindBy(css = "#pageContent > ul.accordion.js-accordion > li:nth-child(4) > div > div > h2")
	protected WebElement txtHeaderAcctServices;

	@FindBy(css = "#pageContent  ul.accordion.js-accordion  li:nth-child(4) form li a")
	protected WebElement lnkRemoveAccount;

	@FindBy(css = "#pageContent ul.accordion.js-accordion  li:nth-child(4)  div  ul  li:nth-child(2)  a")
	protected WebElement lnkUpdateEDeliveryPreferences;

	@FindBy(css = ".errorIndicator")
	protected WebElement msgRemoveAccountInd;

	@FindBy(css = "#address-phone-change__formSection--mailing__section-title")
	protected WebElement txtAddressAlternateMailing;

	@FindBy(css = "#address-phone-change__formSection--seasonal__section-title")
	protected WebElement txtAddressSeasonal;

	@FindBy(css = "#mailingAccountList label")
	protected List<WebElement> lstAddressAlternateMailingAcct;

	@FindBy(css = "#seasonalAccountList label")
	protected List<WebElement> lstAddressSeasonalAcct;

	@FindBy(css = ".content div h1")
	protected WebElement txtNameOfPage;

	@FindAll({ @FindBy(css = ".message"), @FindBy(css = ".errorIndicator") })
	protected WebElement msgRemoveAccount;

	@FindBy(css = "table:nth-child(2)  tbody  tr  th")
	protected List<WebElement> lstHeaderName;

	@FindBy(css = "table  tbody  tr  td  table  tbody:nth-child(4)  tr:nth-child(8)  td")
	protected List<WebElement> lstLabelNameValue;

	@FindBy(css = "#loan_accounts__section-title")
	protected WebElement txtLoanAccountHeader;

	@FindBy(css = "#loan_accounts__columnTotals span")
	private List<WebElement> lstLoanAccountHeaderFields;

	@FindBy(css = "#loan_accounts__body li span")
	private List<WebElement> lstLoanAccountBodyFields;

	@FindBy(css = "#rd00005002016511")
	protected WebElement chkLoanAccount;

	@FindBy(css = "#selectedAccount")
	protected WebElement lstStudentLoanAcct;

	@FindBy(css = "#accountLink2")
	protected WebElement chkLoanAcct;

	@FindBy(css = "#accounts")
	protected WebElement lstWebsterAccounts;

	@FindBy(css = ".accountNumber")
	protected WebElement lblLoanStatement;

	@FindBy(css = "tr:nth-child(1)  td:nth-child(2)  input[type=text][name=account_id]")
	protected WebElement txtAccountNumber;

	@FindBy(css = "tr:nth-child(1)  td:nth-child(2)  input[type=text][name=tax_id]")
	protected WebElement txtTaxID;

	@FindBy(css = "table  thead  tr  th")
	private List<WebElement> lstCustomerStatementFields;

	@FindBy(css = "table  thead  tr  th")
	protected WebElement txtEdelivery;

	@FindBy(css = "input[name='customer_id']")
	protected WebElement txtCustomerId;

	@FindBy(css = "input[type='button']")
	protected WebElement btnGetCustomer;

	@FindBy(css = "select[name='category']")
	protected WebElement lstProductCategory;

	@FindBy(css = "select[name='product']")
	protected WebElement lstProductsManualAddAccount;

	@FindBy(css = "input[name='account_number']")
	protected WebElement txtAccountNumberManualAddAccount;

	@FindBy(css = "input[name='nickname']")
	protected WebElement txtNickNameManualAddAccount;

	@FindBy(css = "input[value='Add Account']")
	protected WebElement btnAddAccount;

	@FindBy(css = "table:nth-child(1) tbody tr td b font")
	protected WebElement msgStudentLoanAddAccount;

	@FindBy(xpath = "//input[@name='username']")
	protected WebElement txtUserName;

	@FindBy(css = "#edelivery_N")
	protected WebElement radioeDeliveryNo;

	@FindBy(css = "input[name='e_00005002016511']")
	protected WebElement chkStudentLoanAcct;

	@FindBy(css = ".message")
	protected WebElement msgUpdateAccount;

	@FindBy(css = "#selectedAccount")
	protected WebElement lstSecureAccounts;
	
	@FindBy(css = "li:nth-child(4)  div  div.checkmark")
	protected WebElement msgEnrollError;

	public String fieldPath = "//td[contains(text(),'%s')]/preceding-sibling::td/input[@type='checkbox']";

	/**
	 * getLabelValues - To get Student Loan labels and values in WOL
	 * 
	 * @return
	 */
	public Map<String, String> getLabelValues() {
		Map<String, String> acctFieldsValues = new HashMap<String, String>();
		int lstSize = lstAccountFields.size();
		WebElement key = null;
		WebElement value = null;
		try {
			for (int index = 0; index < lstSize; index++) {
				key = lstAccountFields.get(index);
				value = lstAccountFields.get(index);
				if ((key != null) && (value != null))
					acctFieldsValues.put(key.getText(), value.getText());
			}
			if (!(acctFieldsValues.isEmpty()))
				LogUtility.logInfo("---> getLabelValues <---", "Student Loan details captured");
		} catch (Exception e) {
			LogUtility.logException("getLabelValues", "Unable to read Student Loan details", e, LoggingLevel.ERROR,
					true);
		}
		return acctFieldsValues;
	}

	/**
	 * clickOnStudentLoan - To click on Student Loan
	 * 
	 * @param acctName
	 * @return flag
	 */
	public boolean clickOnStudentLoan(String acctName, String appName) {
		boolean flag = false;
		List<WebElement> element = null;
		try {
			switch (appName) {
			case "WOL":
				element = lstStudentLoanWOL;
				break;
			case "Webcom":
				element = lstStudentLoan;
				break;
			default:
				LogUtility.logInfo("--->clickOnStudentLoan<---", "Default condition is matched");
				break;
			}
			if (element != null) {
				for (WebElement ele : element) {
					if (wolWebUtil.verifyTextContains(ele, acctName)) {
						webActions.clickElement(ele);
						LogUtility.logInfo("---> clickOnStudentLoan <---",
								"Student Loan Account: " + acctName + " is clicked in: " + appName);
						flag = true;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnStudentLoan", "Unable to click on the Student Loan", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * verifyStudentLoanDetails - To verify Student Loan WOL and WEBCOM labels and
	 * values
	 * 
	 * @param acctFieldValuesWOL
	 * @return unmatchedValues
	 */
	public Map<String, String> verifyStudentLoanDetails(Map<String, String> acctFieldValuesWOL) {
		Map<String, String> acctFieldsValuesWebCom = new HashMap<String, String>();
		int lstSize = acctFieldsValuesWebCom.size();
		WebElement keyElement = null;
		WebElement valueElement = null;
		String value = "";
		Map<String, String> unmatchedValues = new HashMap<String, String>();
		try {
			for (int index = 0; index < lstSize; index++) {
				keyElement = lstAccountFields.get(index);
				valueElement = lstAccountFields.get(index);
				if ((keyElement != null) && (valueElement != null))
					acctFieldsValuesWebCom.put(keyElement.getText(), valueElement.getText());
			}
			lstSize = lstPaymentAcctValuesWebCom.size();
			for (int index = 0; index < lstSize; index++) {
				keyElement = lstPaymentAcctFieldsWebCom.get(index);
				valueElement = lstPaymentAcctValuesWebCom.get(index);
				if ((keyElement != null) && (valueElement != null))
					acctFieldsValuesWebCom.put(keyElement.getText(), valueElement.getText());
			}
			Set<String> acctFieldsValuesKey = acctFieldsValuesWebCom.keySet();
			for (String ele : acctFieldsValuesKey) {
				if (acctFieldValuesWOL.containsKey(ele)) {
					value = acctFieldValuesWOL.get(ele);
					if (acctFieldValuesWOL.containsValue(value))
						LogUtility.logInfo("---> verifyStudentLoanDetails <---",
								"Key and Value is matched. Key: " + ele + ", value is: " + value);
					else {
						LogUtility.logInfo("---> verifyStudentLoanDetails <---",
								"Key is matched: " + ele + ", value is not matched: " + value);
						unmatchedValues.put(ele, value);
					}
				} else {
					value = acctFieldValuesWOL.get(ele);
					LogUtility.logInfo("---> verifyStudentLoanDetails <---",
							"Key is not matched " + ele + ", value is: " + value);
					unmatchedValues.put(ele, value);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStudentLoanDetails", "Unable to verify Student Loan details", e,
					LoggingLevel.ERROR, true);
		}
		return unmatchedValues;
	}

	/**
	 * verifyStudentLoanMessage - To verify Student Loan message
	 * 
	 * @param msgOfStudentLoan
	 * @return flag
	 */
	public boolean verifyStudentLoanMessage(String msgOfStudentLoan) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(msgStudentLoanWOL, maxTimeOut);
			if (wolWebUtil.verifyTextContains(msgStudentLoanWOL, msgOfStudentLoan)) {
				LogUtility.logInfo("---> verifyStudentLoanMessage <---",
						"Student Loan message is verified: " + msgOfStudentLoan);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStudentLoanMessage", "Unable to verify message of Student Loan WOL", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyStudentLoanLabels - To verify Student Loan section fields, header and
	 * links
	 * 
	 * @param labelNickName
	 * @param buttonContinue
	 * @param headerAcctServs
	 * @param removeAcctLink
	 * @param updateEPreferLink
	 * @return flag
	 */
	public boolean verifyStudentLoanLabels(String fieldName) {
		boolean flag = false;
		WebElement element = null;
		String value = "";
		try {
			switch (fieldName) {
			case "Nickname":
				element = lblNickName;
				value = fieldName;
				break;
			case "Continue":
				element = btnContinue;
				break;
			case "Additional Account Services":
				element = txtHeaderAcctServices;
				value = fieldName;
				break;
			case "Remove this account":
				element = lnkRemoveAccount;
				value = fieldName;
				break;
			case "Update eDelivery Preferences":
				element = lnkUpdateEDeliveryPreferences;
				value = fieldName;
				break;
			default:
				LogUtility.logInfo("--->verifyStudentLoanLabels<---", "Default condition is matched");
				break;
			}
			if (element != null) {
				if ((fieldName.equalsIgnoreCase("Continue"))) {
					waits.waitUntilElementIsPresent(element, maxTimeOut);
					LogUtility.logInfo("---> verifyStudentLoanLabels <---", fieldName + ": is present");
					flag = true;
				} else {
					if (wolWebUtil.verifyTextContains(element, value)) {
						LogUtility.logInfo("---> verifyStudentLoanLabels <---", fieldName + ": is present");
						flag = true;
					} else
						LogUtility.logInfo("---> verifyStudentLoanLabels <---", fieldName + " is not present");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStudentLoanLabels", "Unable to verify message of Student Loan details WOL",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyLabelsInBlock - To verify labels in a block
	 *
	 * @param labelLoanPrincipalBalance
	 * @param labelDueNow
	 * @param blockName
	 * @return flag
	 */
	public boolean verifyLabelsInBlock(String labelLoanPrincipalBalance, String labelDueNow, String blockName) {
		boolean flag = false;
		int count = 0;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(txtLoanAccountHeader, maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtLoanAccountHeader, blockName)) {
				LogUtility.logInfo("--->verifyLabelsInBlock<---", "Header Label: " + blockName + " is matched");
				flag = true;
			} else {
				LogUtility.logInfo("--->verifyLabelsInBlock<---" + "Header Label: " + blockName + " is not matched");
				flag = false;
			}
			int lstSize = lstLoanAccountHeaderFields.size();
			for (WebElement element : lstLoanAccountHeaderFields) {
				if (wolWebUtil.verifyTextContains(element, labelLoanPrincipalBalance)) {
					LogUtility.logInfo("--->verifyLabelsInBlock<---",
							"Header Field: " + labelLoanPrincipalBalance + " is matched");
					count++;
				}
				if (wolWebUtil.verifyTextContains(element, labelDueNow)) {
					LogUtility.logInfo("--->verifyLabelsInBlock<---", "Header Field: " + labelDueNow + " is matched");
					count++;
				}
			}
			if ((lstSize == count) && (flag != false))
				flag = true;
		} catch (Exception e) {
			LogUtility.logException("verifyLabelsInBlock", "Unable to verify labels in block", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * verifyLabelsUnderBlock - To verify labels under a block
	 * 
	 * @param lstBodyFields
	 * @return lstBodyField
	 */
	public List<String> verifyLabelsUnderBlock(List<String> lstBodyFields) {
		int lstSize = lstLoanAccountBodyFields.size();
		List<String> lstBodyField = new ArrayList<String>();
		String txtBodyField = "";
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			for (int index = 0; index < lstSize; index++) {
				txtBodyField = lstBodyFields.get(index);
				if (wolWebUtil.verifyTextContains(lstLoanAccountBodyFields.get(index), txtBodyField)
						|| lstLoanAccountBodyFields.get(index).getAttribute("aria-label")
								.equalsIgnoreCase(txtBodyField))
					LogUtility.logInfo("--->verifyLabelsUnderBlock<---", "Label is present: " + txtBodyField);
				else {
					LogUtility.logInfo("--->verifyLabelsUnderBlock<---" + "Label is not present: " + txtBodyField);
					lstBodyField.add(txtBodyField);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLabelsUnderBlock", "Unable to verify labels under block", e,
					LoggingLevel.ERROR, true);
		}
		return lstBodyField;
	}

	/**
	 * clickOnStudentLoan - To click on check box of Student Loan
	 * 
	 * @return flag
	 */
	public boolean clickOnChkBoxStudentLoan() {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(chkLoanAccount, maxTimeOut);
			chkLoanAccount.click();
			LogUtility.logInfo("--->clickOnStudentLoan<---", "Checkbox is clicked.");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("clickOnStudentLoan", "Unable to click the student loan", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * selectFromDropdown - To select account number from drop-down
	 * 
	 * @param acctNo
	 * @param pageName
	 * @return flag
	 */
	public boolean selectFromDropdown(String acctNo, String pageName) {
		boolean flag = false;
		WebElement element = null;
		try {
			switch (pageName) {
			case "Account Information":
				element = lstStudentLoanAcct;
				break;
			case "Online Statement":
				element = lstWebsterAccounts;
				break;
			case "Send Secure Message":
				element = lstSecureAccounts;
				break;
			default:
				LogUtility.logInfo("--->selectFromDropdown<---", "Default condition is matched");
				break;
			}
			if (element != null) {
				waits.waitUntilElementIsPresent(element, maxTimeOut);
				wolWebUtil.selectValueByPartialVisibleText(element, acctNo);
				LogUtility.logInfo("--->selectFromDropdown<---", "Account number selected is: " + acctNo);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromDropdown", "Unable to select student loan account number", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * selectStudentLoanAccount - To select Student Loan Account
	 * 
	 * @param acctNo
	 * @return flag
	 */
	public boolean selectStudentLoanAccount(String acctNo) {
		boolean flag = false;
		WebElement element = null;
		try {
			if (waits.waitUntilElementIsPresent(chkLoanAcct, maxTimeOut))
				element = chkLoanAcct;
			else
				element = chkLoanAccount;
			if (element != null) {
				waits.waitUntilElementIsPresent(element, maxTimeOut);
				wolWebUtil.selectValueByPartialVisibleText(element, acctNo);
				LogUtility.logInfo("--->selectStudentLoanAccount<---", "Account number selected is: " + acctNo);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logError("--->selectStudentLoanAccount<---", e.getMessage());
		}
		return flag;
	}

	/**
	 * clickOnRemoveAcctLink - To click on Remove Account link
	 * 
	 * @param removeAcctLink
	 * @return
	 */
	public boolean clickOnRemoveAcctLink(String removeAcctLink) {
		boolean flag = false;
		try {
			webActions.clickElement(lnkRemoveAccount);
			LogUtility.logInfo("---> clickOnRemoveAcctLink <---", "Remove Account link is clicked.");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("clickOnRemoveAcctLink", "Unable to verify message of Student Loan details WOL", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyMsgStudentLoan - To verify Student Loan error message when remove
	 * account link is clicked
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean verifyMsgStudentLoan(String errorMsg) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(msgRemoveAccountInd, maxTimeOut);
			if (wolWebUtil.verifyTextContains(msgRemoveAccountInd, errorMsg)) {
				LogUtility.logInfo("---> verifyMsgStudentLoan <---", "Error message is verified: " + errorMsg);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyMsgStudentLoan", "Unable to verify message of Student Loan details WOL", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnAddressSection - To click on address section
	 * 
	 * @param sectionName
	 * @return
	 */
	public boolean clickOnAddressSection(String sectionName) {
		boolean flag = false;
		WebElement element = null;
		try {
			switch (sectionName) {
			case "Alternate Mailing Address":
				element = txtAddressAlternateMailing;
				break;
			case "Seasonal Address":
				element = txtAddressSeasonal;
				break;
			default:
				LogUtility.logInfo("--->clickOnAddressSection<---", "Default condition is matched");
				break;
			}
			waits.waitUntilElementIsPresent(element, maxTimeOut);
			wolWebUtil.scrollToElement(element);
			webActions.clickElement(element);
			LogUtility.logInfo("--->clickOnAddressSection<---", "Account number selected is: " + sectionName);
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("clickOnAddressSection", "Unable to click on Address section", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyAcctInAddressSection - To verify Customer Account in address section
	 * 
	 * @param acctNo
	 * @param sectionName
	 * @return
	 */
	public boolean verifyAcctInAddressSection(String acctNo, String sectionName) {
		boolean flag = false;
		List<WebElement> element = null;
		try {
			switch (sectionName) {
			case "Alternate Mailing Address":
				element = lstAddressAlternateMailingAcct;
				break;
			case "Seasonal Address":
				element = lstAddressSeasonalAcct;
				break;
			default:
				LogUtility.logInfo("--->verifyAcctInAddressSection<---", "Default condition is matched");
				break;
			}
			if (element != null) {
				for (WebElement ele : element) {
					waits.waitUntilElementIsPresent(ele, maxTimeOut);
					if (wolWebUtil.verifyTextContains(ele, acctNo)) {
						wolWebUtil.scrollToElement(ele);
						LogUtility.logInfo("--->verifyAcctInAddressSection<---",
								"Account number: " + acctNo + " is present in section: " + sectionName);
						flag = true;
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAcctInAddressSection",
					"Unable to verify Student Loan Account in address section", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyPageName - To verify Page Name
	 * 
	 * @param pageName
	 * @return
	 */
	public boolean verifyPageName(String pageName) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtNameOfPage, maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtNameOfPage, pageName)) {
				LogUtility.logInfo("---> verifyPageName <---", "Page name is verified.");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPageName", "Page name is not verified", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyErrorMsg - To verify error message
	 * 
	 * @param errorMsg
	 * @return flag
	 */
	public boolean verifyErrorMsg(String errorMsg) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(msgRemoveAccount, maxTimeOut);
			if (wolWebUtil.verifyTextContains(msgRemoveAccount, errorMsg)) {
				LogUtility.logInfo("---> verifyErrorMsg <---",
						"Remove account checkbox for student loan account: " + errorMsg + " is clicked.");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyErrorMsg", "Error message is not verified", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickOnCheckbox - To click on check box of preceding sibling when text is
	 * matched
	 * 
	 * @param fieldName
	 * @param accountNumber
	 * @return flag
	 */
	public boolean clickOnCheckbox(String fieldName, String accountNumber) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		boolean flag = false;
		try {
			WebElement targetedField = driver.findElement(By.xpath(String.format(fieldPath, accountNumber)));
			if (webActions.isDisplayed(targetedField)) {
				webActions.clickElement(targetedField);
				LogUtility.logInfo("--->clickOnCheckbox<---",
						"Account Number: " + accountNumber + " corresponding account field is " + fieldName);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->clickOnCheckbox<--",
					"Account Number: " + accountNumber + " corresponding account field is not " + fieldName, e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyCheckboxValue - To verify a student account check box value
	 * 
	 * @param fieldName
	 * @param accountNumber
	 * @return flag
	 */
	public boolean verifyCheckboxValue(String fieldName, String accountNumber) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		boolean flag = false;
		try {
			WebElement targetedField = driver.findElement(By.xpath(String.format(fieldPath, accountNumber)));
			if (webActions.isDisplayed(targetedField)) {
				if (webActions.isChecked(targetedField)) {
					LogUtility.logInfo("--->verifyCheckboxValue<---",
							"Account Number: " + accountNumber + " ," + fieldName + " is checked.");
					flag = true;
				} else
					LogUtility.logInfo("--->verifyCheckboxValue<---",
							"Account Number: " + accountNumber + " ," + fieldName + " is not checked.");
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyCheckboxValue<--",
					"Account Number: " + accountNumber + " corresponding account field is not checked: " + fieldName, e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyHeaderInformation - To verify student loan header names or statement
	 * edelivery label name and value
	 * 
	 * @param lstHeaderNames
	 * @param txtHeader
	 * @return lstHeaderNameNotMatched
	 */
	public List<String> verifyHeaderInformation(List<String> lstHeaderNames, String txtHeader) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		List<WebElement> lstElement = null;
		int lstSize = 0;
		List<String> lstHeaderNameNotMatched = new ArrayList<String>();
		String txtHeaderName = "";
		try {
			switch (txtHeader) {
			case "Header":
				lstElement = lstHeaderName;
				lstSize = lstHeaderName.size();
				break;
			case "Label Value":
				lstElement = lstLabelNameValue;
				lstSize = lstLabelNameValue.size();
				break;
			case "Customer Statement List":
				lstElement = lstCustomerStatementFields;
				lstSize = lstCustomerStatementFields.size();
				break;
			default:
				LogUtility.logInfo("--->verifyHeaderInformation<---", "Default condition is matched");
				break;
			}
			if (lstElement != null) {
				for (int index = 0; index < lstSize; index++) {
					txtHeaderName = lstHeaderNames.get(index);
					if (wolWebUtil.verifyTextContains(lstElement.get(index), txtHeaderName))
						LogUtility.logInfo("--->verifyHeaderInformation<---",
								"Header/ Label/ Value is present: " + txtHeaderName);
					else {
						LogUtility.logInfo("--->verifyHeaderInformation<---" + "Header/ Label/ Value is not present: "
								+ txtHeaderName);
						lstHeaderNameNotMatched.add(txtHeaderName);
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyHeaderInformation<--", "Header fields are not verified", e,
					LoggingLevel.ERROR, true);
		}
		return lstHeaderNameNotMatched;
	}

	public boolean verifyStudentLoanStatement(String acctNo) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lblLoanStatement, maxTimeOut);
			if (wolWebUtil.verifyTextContains(lblLoanStatement, acctNo)) {
				LogUtility.logInfo("---> verifyStudentLoanStatement <---",
						"Student Loan Account: " + acctNo + " statement is verified.");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyStudentLoanStatement<--", "Student Loan Statement is not verified", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean enterStudentLoanAcctNumber(String studentLoanAccountNumber) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAccountNumber, maxTimeOut);
			webActions.setValue(txtAccountNumber, studentLoanAccountNumber);
			LogUtility.logInfo("---> enterStudentLoanAcctNumber <---",
					"Student Loan Account Number: " + studentLoanAccountNumber + " is entered.");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->enterStudentLoanAcctNumber<--",
					"Student Loan Account not entered in Account Number field", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyLabelValue(String value) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtEdelivery, maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtEdelivery, value))
				LogUtility.logInfo("---> verifyLabelValue <---", "Edelivery label value: " + value + " is verified.");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->verifyLabelValue<--", "Edelivery label value is not verified", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean navigateToMainWindow() {
		boolean flag = false;
		try {
			wolWebUtil.switchToMainWindow();
			LogUtility.logInfo("---> navigateToMainWindow <---", "Navigation to main window is successful.");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->navigateToMainWindow<--", "Navigation to main window is not successful.", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean enterCustomerId(String customerID) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtCustomerId, maxTimeOut);
			webActions.setValue(txtCustomerId, customerID);
			LogUtility.logInfo("---> enterCustomerId <---", "Customer ID entered successfully");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->enterCustomerId<--", "Unable to enter Customer ID", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	public boolean clickOnCustomerButton() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnGetCustomer, maxTimeOut);
			webActions.clickElement(btnGetCustomer);
			LogUtility.logInfo("---> clickOnCustomerButton <---", "Get Customer button clicked successfully");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->clickOnCustomerButton<--", "Unable to click on Get Consumer button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean enterStudentLoanDetails(String selectionText, String fieldName) {
		boolean flag = false;
		WebElement element = null;
		try {
			switch (fieldName) {
			case "Product Category":
				element = lstProductCategory;
				break;
			case "Products":
				element = lstProductsManualAddAccount;
				break;
			case "Account Number":
				element = txtAccountNumberManualAddAccount;
				break;
			case "Nick Name":
				element = txtNickNameManualAddAccount;
				break;
			default:
				LogUtility.logInfo("--->enterStudentLoanDetails<---", "Default condition is matched");
				break;
			}
			if (element != null) {
				if ((fieldName.equalsIgnoreCase("Product Category")) || (fieldName.equalsIgnoreCase("Products"))) {
					wolWebUtil.selectValueByPartialVisibleText(element, selectionText);
					LogUtility.logInfo("---> enterStudentLoanDetails <---", "Student Loan Detail entered for field: "
							+ fieldName + " ans selected value is: " + selectionText);
					flag = true;
				}
				if ((fieldName.equalsIgnoreCase("Account Number")) || (fieldName.equalsIgnoreCase("Nick Name"))) {
					webActions.setValue(element, selectionText);
					LogUtility.logInfo("---> enterStudentLoanDetails <---", "Student Loan Detail entered for field: "
							+ fieldName + " ans selected value is: " + selectionText);
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->enterStudentLoanDetails<--", "Unable to enter Student Loan details", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickOnAddAccountButton() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnAddAccount, maxTimeOut);
			webActions.clickElement(btnAddAccount);
			LogUtility.logInfo("---> clickOnAddAccountButton <---", "Add Account button clicked successfully");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->clickOnAddAccountButton<--", "Unable to click on Add Account button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyStudentLoanAccountAddMessage(String acctAdditionMsg) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(msgStudentLoanAddAccount, maxTimeOut);
			wolWebUtil.verifyText(msgStudentLoanAddAccount, acctAdditionMsg);
			LogUtility.logInfo("---> verifyStudentLoanAccountAddMessage <---",
					"Student Loan Account Add Message verified successfully");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->verifyStudentLoanAccountAddMessage<--",
					"Unable to verify Student Loan Account Add Message", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyValueOfStatementeDelivery(String value) {
		boolean flag = false;
		try {
			if (webActions.isDisplayed(radioeDeliveryNo)) {
				if (webActions.isChecked(radioeDeliveryNo)) {
					LogUtility.logInfo("---> verifyValueOfStatementeDelivery <---",
							"Statement EDelivery value selected is No");
					flag = true;
				} else
					LogUtility.logInfo("---> verifyValueOfStatementeDelivery <---",
							"Statement EDelivery value selected is Yes");
			}
		} catch (Exception e) {
			LogUtility.logException("-->verifyValueOfStatementeDelivery<--",
					"Unable to verify Statement eDelivery value", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean clickOnStudentLoanAccountIneDelivery(String value) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(chkStudentLoanAcct, maxTimeOut);
			webActions.clickElement(chkStudentLoanAcct);
			LogUtility.logInfo("---> clickOnStudentLoanAccountIneDelivery <---", "Checked the Student Loan Account");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException("-->clickOnStudentLoanAccountIneDelivery<--",
					"Unable to chceck the Student Loan Account", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyStudentLoanAccountUpdateMessage(String updateAcctErrorMsg) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(msgUpdateAccount, maxTimeOut);
			if (wolWebUtil.verifyTextContains(msgUpdateAccount, updateAcctErrorMsg)) {
				LogUtility.logInfo("---> verifyErrorMsg <---",
						"Update account message verified successfully: " + updateAcctErrorMsg);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyErrorMsg", "Error message is not verified", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public boolean verifyEnrollementErrorMsg(String enrolledInEdeliveryMessage) {
		waits.waitForPageReadyState();
		waits.waitForDOMready();
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(msgEnrollError, maxTimeOut);
			if (wolWebUtil.verifyTextContains(msgEnrollError, enrolledInEdeliveryMessage)) {
				LogUtility.logInfo("---> verifyErrorMsg <---", "Remove account checkbox for student loan account: "
						+ enrolledInEdeliveryMessage + " is clicked.");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyErrorMsg", "Error message is not verified", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

}
