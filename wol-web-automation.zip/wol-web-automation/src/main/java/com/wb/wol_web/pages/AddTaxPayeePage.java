package com.wb.wol_web.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class AddTaxPayeePage extends ObjectBase {

	public AddTaxPayeePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "div#pageinstruction_note span a")
	protected WebElement lnkhere;

	@FindBy(css = "#div_edit > div:nth-child(4) > div > div > img")
	private WebElement lblPayeeFromHelpIcon;

	@FindBy(css = "#group_holder a.group-link")
	private List<WebElement> lnksTaxPayeeParentGroup;

	@FindBy(css = "#relationship_holder a")
	private List<WebElement> lnksTaxPayeeChildGroup;

	@FindBy(css = "#div_edit > div:nth-child(1) > div")
	private WebElement txtTaxPayeeName;

	@FindBy(css = "input[name=tin]")
	private WebElement txtTaxPayeeID;

	@FindBy(css = "input[name=nick]")
	private WebElement txtTaxPayeeNickName;

	@FindBy(css = "input[id*=payeeDesignationOptions_P]")
	private WebElement rdbtnTaxPayeeTypePer;

	@FindBy(css = "input[id*=payeeDesignationOptions_B]")
	private WebElement rdbtnTaxPayeeTypeBus;

	@FindBy(css = "[data-wbst-message-key*=payeeDesignationOptions.label]")
	private WebElement txtPayFromLabel;

	@FindBy(css = "#disclosure_agreed")
	private WebElement chkTaxDisclosure;

	@FindBy(css = "[id*=ContinueButton]")
	private WebElement btnContinueTax;

	@FindBy(css = ".pageHeaderBlock > h1")
	private WebElement txtPagettleTaxPayee;

	@FindBy(css = "h3")
	private WebElement txtErrPageTitlTaxPayee;

	@FindBy(css = "h1#page-title")
	private WebElement txtTaxAgencyTitle;

	@FindBy(css = "p.strong")
	private WebElement txtErrMsgViewOnlyTaxPayee;

	@FindBy(css = "#pageContent > div.errorIndicator > div > p")
	protected WebElement txtDisclosErrMsg;

	/**
	 * clickTaxContinueButton:To click on continue Button in Update Payee details
	 * page
	 */
	public void clickTaxContinueButton() {
		try {
			webActions.clickElement(btnContinueTax);
			waits.waitForPageToLoad(maxTimeOut);
			LogUtility.logInfo("clickTaxContinueButton", "Clicked on Continue Button");
		} catch (Exception e) {
			LogUtility.logException("clickTaxContinueButton", "Failed to Click on Continue Button", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}

	}

	/**
	 * selectTaxPayeeName:To Select Tax Parent name and Tax Payee name
	 * 
	 * @param parentTaxGroup :- Tax Payee Parent Link name
	 * @param                taxPayeeName:- Tax Payee Link Name
	 */
	public void selectTaxPayeeName(String parentTaxGroup, String taxPayeeName) {
		try {
			for (WebElement lnkTaxGroup : lnksTaxPayeeParentGroup) {
				String lnkText = webActions.getText(lnkTaxGroup);
				if (lnkText.contains(parentTaxGroup)) {
					webActions.clickElement(lnkTaxGroup);
					LogUtility.logInfo("selectTaxPayeeName", "Clicked on Tax Payee Group Name Link");
					break;
				}
			}
			waits.staticWait(3);
			for (WebElement lnkTaxPayee : lnksTaxPayeeChildGroup) {
				String lnkTextPayee = webActions.getText(lnkTaxPayee);
				if (lnkTextPayee.contains(taxPayeeName)) {
					webActions.clickElement(lnkTaxPayee);
					LogUtility.logInfo("selectTaxPayeeName", "Clicked on Tax Payee Name Link");
					break;
				}
			}

		} catch (Exception e) {
			LogUtility.logException("selectTaxPayeeName", "Failed to Click on Tax Payee Name Link", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * enterTaxPayeeID:To enter Tax Payee ID Number to add different types of Tax
	 * Payees
	 * 
	 * @param Tin:- Tax Payee ID -Tin of User
	 */
	public boolean enterTaxPayeeID(String Tin) {
		boolean flag = false;
		try {
			String payeeName = webActions.getText(txtTaxPayeeName);
			if (payeeName.contains("CT")) {
				webActions.setValue(txtTaxPayeeID, wolWebUtil.getRandomNumber(10));
			} else
				webActions.setValue(txtTaxPayeeID, Tin);
			if (webActions.getAttributeValue(txtTaxPayeeID, "value").isEmpty()) {
				flag = false;
				LogUtility.logError("enterTaxPayeeID", "Failed to Enter Tax Payee ID Number");
			} else {
				flag = true;
				LogUtility.logInfo("enterTaxPayeeID", "Entered Tax Payee ID Number");
			}
		} catch (Exception e) {
			LogUtility.logException("enterTaxPayeeID", "Failed to Enter Tax Payee ID Number", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * enterTaxPayeeNickName: To Enter Tax Payee Nick name in Add a New Tax Payee
	 * Page
	 */
	public void enterTaxPayeeNickName() {
		try {
			webActions.setValue(txtTaxPayeeNickName, wolWebUtil.getRandomString(5));
			LogUtility.logInfo("enterTaxPayeeNickName", "Entered Tax Payee Nick Name");
		} catch (Exception e) {
			LogUtility.logException("enterTaxPayeeNickName", "Failed to Enter Tax Payee Nick Name", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectTaxPayeeType: To Select Tax Payee From which account radio button for
	 * comingled user
	 * 
	 * @param payeeType :- Pay From Account(Personal/Business)
	 */
	public void selectTaxPayeeType(String payeeType) {
		try {
			if (waits.waitUntilElementIsPresent(rdbtnTaxPayeeTypePer)) {
				if (payeeType.contains("Personal")) {
					webActions.clickElement(rdbtnTaxPayeeTypePer);
					LogUtility.logInfo("selectTaxPayeeType", "Selected Pay From Which Account value as Personal");
				} else if (payeeType.contains("Business")) {
					webActions.clickElement(rdbtnTaxPayeeTypeBus);
					LogUtility.logInfo("selectTaxPayeeType", "Selected Pay From Which Account value as Business");
				} else
					LogUtility.logInfo("selectTaxPayeeType", "Given Pay From Which Account value is not valid");
			}
			waits.staticWait(2);
		} catch (Exception e) {
			LogUtility.logException("selectTaxPayeeType", "Failed to select Pay From Which Account", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectDisclosureCheckbox:-To Select check box of disclosure agreement to add
	 * new tax payee for comingled user
	 */
	public void selectDisclosureCheckbox() {
		try {
			if (waits.waitUntilElementIsPresent(chkTaxDisclosure)) {
				webActions.clickElement(chkTaxDisclosure);
				LogUtility.logInfo("selectDisclosureCheckbox", "Selected Tax Payee Disclosure check box");
			}

		} catch (Exception e) {
			LogUtility.logException("selectDisclosureCheckbox", "Failed to select Tax Payee Disclosure check box", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * verifyAddTaxPayeePageTitle:- To verify Page Titles among Add a Tax Payee
	 * pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAddTaxPayeePageTitle(String message) {
		try {
			return wolWebUtil.verifyText(txtPagettleTaxPayee, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAddTaxPayeePageTitle", "Failed to verify page title text", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyTaxPayeeErrPageTitle:- To verify Error Page Title for a view only user
	 * to adda new Tax Payee
	 * 
	 * @param pageTitle:- The text need to verify
	 * @return
	 */
	public boolean verifyTaxPayeeErrPageTitle(String pageTitle) {
		try {
			return wolWebUtil.verifyText(txtErrPageTitlTaxPayee, pageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyTaxPayeeErrPageTitle", "Failed to verify Error page title text", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyTaxPayeeErrMsgViewOnly:- To verify Page Titles among Add a Tax Payee
	 * pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyTaxPayeeErrMsgViewOnly(String message) {
		try {
			return wolWebUtil.verifyText(txtErrMsgViewOnlyTaxPayee, message);
		} catch (Exception e) {
			LogUtility.logException("verifyTaxPayeeErrMsgViewOnly",
					"Failed to verify Error message for the View-Only user", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyTaxPayeeErrMsgDisclosure:- To verify Disclosure error message in Tax
	 * Payee Verification page for a comingled user
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyTaxPayeeErrMsgDisclosure(String message) {
		try {
			return wolWebUtil.verifyText(txtDisclosErrMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyTaxPayeeErrMsgDisclosure",
					"Failed to verify Error message for the Disclosure", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyTooltipTaxPayee: Validating text displayed in tooltip of Pay From
	 * Accounts in Add A New Tax Payee Page
	 * 
	 * @param tooltipContent
	 * @return
	 */
	public boolean verifyTooltipTaxPayee(String tooltipContent) {
		try {
			webActions.clickElement(lblPayeeFromHelpIcon);
			String displayContent = webActions.getAttributeValue(lblPayeeFromHelpIcon, "data-title");
			if (displayContent.contains(tooltipContent)) {
				LogUtility.logInfo("verifyTooltipTaxPayee",
						"The Tooltip Pay From Which Accounts content is displaying properly");
				return true;
			} else {
				LogUtility.logInfo("verifyTooltipTaxPayee",
						"The Tooltip Pay From Which Accounts content is not displaying properly");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTooltipTaxPayee", "Failed to verify Tooltip content", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyTaxAgncyLnknavigation-to verify Tax Agency Information page when click
	 * on here link
	 * 
	 * @param pageTitle- text need to verify
	 * @return
	 */
	public boolean verifyTaxAgncyLnknavigation(String pageTitle) {
		try {
			webActions.clickElement(lnkhere);
			waits.staticWait(4);
			return wolWebUtil.verifyPageTitleOfChildWindow(pageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyTaxAgncyLnknavigation", "Failed to verify Tax Agency Link Navigation", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}
}