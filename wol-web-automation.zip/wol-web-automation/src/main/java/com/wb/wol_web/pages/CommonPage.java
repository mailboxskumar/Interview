package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class CommonPage extends ObjectBase {

	public String userName = "";

	public CommonPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "new_username")
	private WebElement txtNewUsername;

	@FindBy(id = "mainSiteNav")
	private WebElement mainMenu;

	@FindBy(xpath = "//label[contains(@id,'sername__label')]")
	private WebElement txtUsernameLabel;

	@FindBy(id = "new_email__input")
	private WebElement txtNewEmail;

	@FindBy(id = "new_email_conf__input")
	private WebElement txtConfirmEmail;

	@FindBy(id = "mainSiteNav__navTabs")
	private WebElement lnkSubMenu;

	@FindBy(id = "mainSiteNav__submenu3__megaMenu")
	protected WebElement paymentSubMenu;

	@FindBy(id = "mainSiteNav__submenu1__megaMenu")
	protected WebElement accountsSubMenu;

	@FindBy(id = "mainSiteNav__submenu4__megaMenu")
	protected WebElement servicesSubMenu;

	@FindBy(id = "mainSiteNav__submenu5__megaMenu")
	protected WebElement supportSubMenu;

	@FindBy(id = "mainSiteNav__submenu2__megaMenu")
	protected WebElement transfersSubMenu;

	@FindBy(name = "password1")
	@CacheLookup
	private WebElement txtPassword1;

	@FindBy(xpath = "//h1[contains(text(),'Pay Bills')]")
	@CacheLookup
	private WebElement setupBillHeading;

	@FindBy(xpath = "//h1[contains(text(),'Add a New Payee')]")
	@CacheLookup
	private WebElement addANewPayeeHeading;

	@FindBy(xpath = "//*[@data-mm-template='pageTitle']")
	private WebElement pageHeading;

	@FindBy(xpath = "//*[@data-wbst-message-key='authorization_access.unauthorized']")
	private WebElement unauthorizedPageHeading;

	@FindBy(css = "div.pageHeaderBlock > h3")
	private WebElement alertsPageHeading;

	@FindBy(name = "password2")
	private WebElement txtPassword2;

	@FindBy(xpath = "//select[@id='question1__input']")
	private WebElement lstQuestion1;

	@FindBy(xpath = "//select[@id='question2__input']")
	private WebElement lstQuestion2;

	@FindBy(xpath = "//select[@id='question3__input']")
	private WebElement lstQuestion3;

	@FindBy(name = "answer1")
	private WebElement txtAnswer1;;

	@FindBy(name = "answer2")
	private WebElement txtAnswer2;

	@FindBy(name = "answer3")
	private WebElement txtAnswer3;

	@FindBy(name = "password")
	private WebElement txtPassword;

	@FindBy(xpath = "//*[contains(text(),'Having trouble')")
	private WebElement txtHavingTrouble;

	@FindBy(xpath = "//*[contains(text(),'Continue') and contains(@id,'button')]")
	private WebElement btnContinue;

	@FindBy(xpath = "//*[contains(text(),'My Quick Links') ]")
	private WebElement quickLinks;

	@FindBy(xpath = "//input[@id='userid' or @name='username']")
	private WebElement txtUserName;

	@FindBy(xpath = "//strong[text()='Your Account']")
	protected WebElement btnYourAccount;

	@FindBy(name = "submit1")
	private WebElement btnGo;

	@FindBy(id = "buttonSubmit_formLoginUser__actualButton")
	private WebElement btnSubmitUsername;

	@FindBy(id = "answer__input")
	private WebElement txtAnswerBox;

	@FindAll({ @FindBy(id = "logout-link"), @FindBy(id = "signOutLink") })
	private WebElement btnSignOut;

	@FindBy(id = "page-title")
	private WebElement txtSignout;

	@FindBy(id = "profileWidget__profileIcon")
	protected WebElement btnCustomerProfileIcon;

	@FindBy(xpath = "//span[@class='name']")
	private WebElement txtUsernameFromProfile;

	@FindBy(xpath = "//span[@class='screen-reader']/parent::a")
	private WebElement linkMsgCount;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement btnSubmit;

	@FindBy(xpath = "//input[contains(@name,'disclosure')]")
	private List<WebElement> checkboxDisclosure;

	@FindBy(id = "chooseYes__input")
	@CacheLookup
	private WebElement radioEmailYes;

	@FindBy(id = "chooseNo__input")
	@CacheLookup
	private WebElement radioEmailNo;

	@FindBy(xpath = "//*[contains(text(),'Update User Name and Password')]")
	@CacheLookup
	private WebElement updateUsernameHeading;

	@FindBy(id = "mainSiteNav__homeLink__smallLabel")
	private WebElement summaryTab;

	@FindBy(id = "editButton")
	private WebElement btnEdit;

	@FindBy(xpath = "//h1[contains(text(),'Agree to Disclosures')]")
	@CacheLookup
	private WebElement disclosurePageHeading;

	@FindBy(xpath = "//h1[contains(text(),'Verify Email Address')]")
	@CacheLookup
	private WebElement verifyEmailHeading;

	@FindBy(xpath = "//h1[contains(text(),'Confirmation')]")
	@CacheLookup
	private WebElement confirmationHeading;

	@FindBy(xpath = "//*[contains(text(),'You have successfully registered for Enhanced Online Security')]")
	@CacheLookup
	private WebElement msgInConfirmationPage;

	@FindBy(xpath = "//*[contains(text(),'WOLTestDefaultEmail@websterbank.com')]")
	@CacheLookup
	private WebElement defaultMailCheck;

	@FindBy(xpath = "//*[@href='javascript:showAlert()']")
	@CacheLookup
	private WebElement linkToAlertsPage;

	@FindBy(xpath = "//a[@href='ManagePendingPayment' and @class='relatedLink']")
	@CacheLookup
	private WebElement linkToPendingPayments;

	@FindBy(xpath = "//a[contains(@href,'PaymentCenter') and @class='relatedLink']")
	@CacheLookup
	private WebElement linkToPaymentCenter;

	@FindBy(id = "login-challenge__pageTitle_gen")
	protected WebElement txtChallengePage;

	@FindBy(id = "login-rsa-password__pageTitle_gen")
	protected WebElement txtPasswordPage;

	@FindBy(id = "chooseNo__input")
	protected WebElement rdbtnRegisterNo;

	@FindBy(id = "chooseYes__input")
	protected WebElement rdbtnRegisterYes;

	@FindAll({ @FindBy(css = "#bodyContent h1"), @FindBy(id = "travel-notification__pageTitle") })
	protected WebElement txtPageTitle1;

	@FindAll({ @FindBy(css = "#bodyContent h3"), @FindBy(id = "page-title") })
	protected WebElement txtPageHeaderH3;

	@FindBy(id = "mainSiteNav__submenu1__menuSection")
	protected WebElement menuAccounts;

	@FindBy(css = "#megaMenuSectionFooter__SubMenuForFooter1_Heading1_Item2 a")
	protected WebElement linkEqualHousingLender;

	/**
	 * To load URL
	 */
	public void loadURL() {
		try {
			navigator.goToUrl(appURL);

		} catch (Exception e) {
			LogUtility.logException("->loadURL<--", "Unable to load URL", e, LoggingLevel.ERROR, true);
		}
	}

	public boolean isUserNameDisplayed() {
		try {
			waits.waitUntilElementIsPresent(txtUserName, maxTimeOut);
			return webActions.isDisplayed(txtUserName);
		} catch (Exception e) {
			LogUtility.logException("->isUserNameDisplayed<--", "Username is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	public boolean isYourAccountDisplayed() {
		try {
			waits.waitUntilElementIsPresent(btnYourAccount, maxTimeOut);
			return webActions.isDisplayed(btnYourAccount);
		} catch (Exception e) {
			LogUtility.logException("->isYourAccountDisplayed<--", "YourAccount is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To enter Username
	 * 
	 * @param userName
	 */
	public boolean enterUserName(String userName) {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(txtUserName);
			if (webActions.isDisplayed(txtUserName)) {
				webActions.setValue(txtUserName, userName);
			}
			LogUtility.logInfo("---> enterUserName <---", "Entered the username " + userName);
			if (webActions.getText(txtUserName).equals(userName))
				flag = true;
		} catch (Exception e) {
			LogUtility.logException("->enterUserName<--", "username is not entered", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on GO Button
	 */
	public void clickOnGoButton() {
		try {
			if (waits.waitUntilElementIsPresent(btnGo, maxTimeOut))
				webActions.clickElement(btnGo);
			else if (waits.waitUntilElementIsPresent(btnSubmitUsername, maxTimeOut))
				webActions.clickElement(btnSubmitUsername);
			LogUtility.logInfo("---> clickOnGoButton <---", "Clicked on GO Button");
		} catch (Exception e) {
			LogUtility.logException("->clickOnGoButton<--", "Not clicked on GO button", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To signout from the application
	 */
	public void signOut() {
		try {
			waits.staticWait(5);
			webActions.clickElement(btnSignOut);
			waits.waitForPageToLoad(maxTimeOut);
			if (webActions.isDisplayed(btnSignOut)) {
				webActions.clickElement(btnSignOut);
			}
			LogUtility.logInfo("---> SignOut <---", "Signed Out successfully");
		} catch (Exception e) {
			LogUtility.logException("->SignOut<--", "Not Signed Out successfully", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To enter answers to security questions if exists in the flow
	 */
	public void enterInAnswerTextBoxIfExists() {
		try {
			if (waits.waitUntilElementIsPresent(txtAnswerBox)) {
				webActions.setValue(txtAnswerBox, "answer");
				webActions.clickElement(btnSubmit);
				LogUtility.logInfo("---> enterInAnswerTextBoxIfExists <---", "Entered answers to security questions");
			}
		} catch (Exception e) {
			LogUtility.logException("->enterInAnswerTextBoxIfExists<--", "Not entered answers to security questions", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * selectRegisterDevice: To select Register device
	 * 
	 * @param value
	 * @return
	 */
	public boolean selectRegisterDevice(String value) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(rdbtnRegisterNo)) {
				if (value.equalsIgnoreCase("No"))
					webActions.clickElement(rdbtnRegisterNo);
				else
					webActions.clickElement(rdbtnRegisterYes);
				waits.waitForDOMready();
				if (value.equalsIgnoreCase("No")) {
					flag = rdbtnRegisterNo.isSelected() ? true : false;
				} else {
					flag = rdbtnRegisterYes.isSelected() ? true : false;
				}
			}
			webActions.clickElement(btnSubmit);
			LogUtility.logInfo("---> selectRegisterDevice <---", "Selected Register Device as" + value);
		} catch (Exception e) {
			LogUtility.logException("->selectRegisterDevice<--", "Not selected Register Device as" + value, e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter answers to security questions if exists in the flow
	 * 
	 * @return
	 */
	public boolean enterInAnswerTextBoxIfExists(String answer) {
		boolean flag = false;
		try {
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(txtAnswerBox,maxTimeOut);
			if (webActions.isDisplayed(txtAnswerBox)) {
				webActions.setValue(txtAnswerBox, answer);
				waits.waitForDOMready();
				if (webActions.getAttributeValue(txtAnswerBox, "value").equalsIgnoreCase(answer)) {
					flag = true;
					LogUtility.logInfo("---> answer <---", "Entered answer value");
				} else
					LogUtility.logInfo("---> enterInAnswerTextBoxIfExists <---",
							"Failed to Entered answer to security question");
			}
		} catch (Exception e) {
			LogUtility.logException("->enterInAnswerTextBoxIfExists<--", "Not entered answer value", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter password
	 * 
	 * @throws Exception
	 */
	public boolean enterPassword(String passwordValue) throws Exception {
		boolean flag = false;
		try {
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			if (webActions.isDisplayed(txtPassword)) {
				if (passwordValue.equals("Resetpassword"))
					passwordValue = getValueFromRuntimeDataMap("resetPassword-webcom");
				webActions.setValue(txtPassword, passwordValue);
				waits.waitForDOMready();
				if (webActions.getAttributeValue(txtPassword, "value").equalsIgnoreCase(passwordValue)) {
					flag = true;
					LogUtility.logInfo("---> enterPassword <---", "Entered password");
				}
				webActions.clickElement(btnContinue);
			} else if (webActions.isDisplayed(txtHavingTrouble)) {
				throw new Exception("Reached having trouble singing in page");
			}
		} catch (Exception e) {
			LogUtility.logException("->enterPassword<--", "Not entered answer value", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return flag;
	}

	/**
	 * To check if the summary page is reached or not
	 * 
	 * @throws Exception
	 */
	public boolean waitForSummaryPage() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			if (waits.waitUntilElementIsPresent(btnSignOut)) {
				waits.staticWait(2);
				status = true;
				LogUtility.logInfo("-->waitForSummaryPage<--", "Reached Summary Page");
			}
		} catch (Exception e) {
			LogUtility.logException("->waitForSummaryPage<--", "Not Reached Summary Page", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return status;
	}

	/**
	 * To navigate through all the security pages
	 * 
	 * @param testDataMap
	 * @throws Exception
	 */
	public void navigateAllSecurityPages(Map<String, String> testDataMap) throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			enterInAnswerTextBoxIfExists(testDataMap.get("Answer1"));
			selectRegisterDevice(testDataMap.get("Register"));
			if (testDataMap.get("Password").equalsIgnoreCase("Resetpassword"))
				enterPassword(runtimeDataMap.get("resetPassword-webcom"));
			else
				enterPassword(testDataMap.get("Password"));
			if (waits.waitUntilElementIsPresent(btnSignOut))
				LogUtility.logInfo("---> navigateAllSecurityPages <---", "Navigated all sceurity pages successfully");
			else {
				enterDetailsInNewUsernamePage();
				selectFromEnhancedSecurityQuestionsPage(testDataMap);
				selectRegisterDevice(testDataMap.get("Register"));
				checkInConfirmationPage();
				selectFromDisclosuresPage();
				verifyEmailAddressPage(testDataMap.get("Email"), testDataMap.get("EmailID"));
				LogUtility.logInfo("---> navigateAllSecurityPages <---", "Navigated all sceurity pages successfully");
			}
		} catch (Exception e) {
			LogUtility.logException("->navigateAllSecurityPages<--", "Failed to Navigate all sceurity pages", e,
					LoggingLevel.ERROR, true);
			throw new Exception("Login Failure ");
		}
	}

	/**
	 * To select the agreements from disclosures page
	 */
	public void selectFromDisclosuresPage() {
		try {
			if (waits.waitUntilElementIsPresent(disclosurePageHeading, maxTimeOut)) {
				for (WebElement disclosure : checkboxDisclosure) {
					webActions.clickElement(disclosure);
				}
				webActions.clickElement(btnContinue);
				LogUtility.logInfo("-->selectFromDisclosuresPage<--",
						"All agreements are selected from disclosures page");
			}
		} catch (Exception e) {
			LogUtility.logException("->selectFromDisclosuresPage<--",
					"All agreements are not selected from disclosures page", e, LoggingLevel.ERROR, true);
		}

	}

	/**
	 * To verify if the email given should be set to default id or not
	 * 
	 * @param verifyMail
	 */
	public void verifyEmailAddressPage(String verifyMail, String email) {
		try {
			if (waits.waitUntilElementIsPresent(verifyEmailHeading, maxTimeOut)) {
				if (verifyMail.equalsIgnoreCase("Yes")) {
					webActions.clickElement(radioEmailYes);
				} else {
					if (waits.waitUntilElementIsPresent(radioEmailNo, maxTimeOut))
						webActions.clickElement(radioEmailNo);
					webActions.setValue(txtNewEmail, email);
					webActions.setValue(txtConfirmEmail, email);
				}
				webActions.clickElement(btnContinue);
			}
			LogUtility.logInfo("---> verifyEmailAddressPage <---", "Verified Email Address Successfully");
		} catch (Exception e) {
			LogUtility.logException("->verifyEmailAddressPage<--", "Not verified Email Address", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * To check confirmation page for registration
	 */
	public void checkInConfirmationPage() {
		try {
			if (waits.waitUntilElementIsPresent(confirmationHeading, maxTimeOut)) {
			}
			if (waits.waitUntilElementIsPresent(msgInConfirmationPage, maxTimeOut)) {
				webActions.clickElement(btnContinue);
			}
			LogUtility.logInfo("---> checkInConfirmationPage <---", "Reached Confirmation page for registration");
		} catch (Exception e) {
			LogUtility.logException("->checkInConfirmationPage<--", "Not Reached Confirmation page for registration", e,
					LoggingLevel.ERROR, true);
		}

	}

	/**
	 * To enter password
	 */
	public void enterPassword() {
		try {
			if (waits.waitUntilElementIsPresent(txtPassword)) {
				webActions.setValue(txtPassword, "password");
				webActions.clickElement(btnContinue);
				LogUtility.logInfo("---> enterPassword <---", "Entered password");
			}
		} catch (Exception e) {
			LogUtility.logException("->enterPassword<--", "Not entered password", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To click on Summary Tab
	 * 
	 * @throws Exception
	 */
	public void clickOnSummaryTab() throws Exception {
		try {
			webActions.clickElement(summaryTab);
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(btnEdit);
			LogUtility.logInfo("Clicked on summary tab");
		} catch (Exception e) {
			LogUtility.logException("->clickOnSummaryTab<--", "Failed to click on Summary tab", e, LoggingLevel.ERROR,
					true);
		}

	}

	/**
	 * To verify if the email given should be set to default id or not
	 * 
	 * @param verifyMail
	 */
	public void verifyEmailAddressPage(String verifyMail) {
		try {
			if (waits.waitUntilElementIsPresent(verifyEmailHeading, maxTimeOut)) {
				if (verifyMail.equalsIgnoreCase("Yes")) {
					webActions.clickElement(radioEmailYes);
				} else {
					webActions.clickElement(radioEmailNo);
				}
				webActions.clickElement(btnContinue);
			}
			LogUtility.logInfo("---> verifyEmailAddressPage <---", "Verified Email Address Successfully");
		} catch (Exception e) {
			LogUtility.logException("->verifyEmailAddressPage<--", "Failed to Verify Email Address", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To set the new username and password
	 */
	public boolean enterDetailsInNewUsernamePage() {
		boolean flag = false;
		try {
			webActions.setValue(txtNewUsername, wolWebUtil.getRandomString(10));
			webActions.setValue(txtPassword1, "password");
			webActions.setValue(txtPassword2, "password");
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtPassword2, "value").equalsIgnoreCase("password")) {
				flag = true;
				LogUtility.logInfo("---> enterDetailsInNewUsernamePage <---", "New username and password are set");
			} else
				LogUtility.logError("---> enterDetailsInNewUsernamePage <---",
						"Failed to set New username and password ");
			webActions.clickElement(btnContinue);
		} catch (Exception e) {
			LogUtility.logException("->enterDetailsInNewUsernamePage<--", "Failed to Verify Email Address", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To set all the security questions and their answers for security
	 * 
	 * @param ques1
	 * @param que2
	 * @param que3
	 */
	public boolean selectFromEnhancedSecurityQuestionsPage(Map<String, String> testDataMap) {
		boolean flag = false;
		try {
			webActions.selectDropDownByIndex(lstQuestion1, Integer.parseInt(testDataMap.get("Question1")));
			webActions.setValue(txtAnswer1, testDataMap.get("Answer1"));
			webActions.selectDropDownByIndex(lstQuestion2, Integer.parseInt(testDataMap.get("Question2")));
			webActions.setValue(txtAnswer2, testDataMap.get("Answer2"));
			webActions.selectDropDownByIndex(lstQuestion3, Integer.parseInt(testDataMap.get("Question3")));
			webActions.setValue(txtAnswer3, testDataMap.get("Answer3"));
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtAnswer3, "value").equalsIgnoreCase(testDataMap.get("Answer3"))) {
				flag = true;
				LogUtility.logInfo("---> selectFromEnhancedSecurityQuestionsPage <---",
						"Selected all the security questions ");
			} else
				LogUtility.logError("---> selectFromEnhancedSecurityQuestionsPage <---",
						"Failed to Select all the security questions");
		} catch (Exception e) {
			LogUtility.logException("->selectFromEnhancedSecurityQuestionsPage<--",
					"Failed to Select all the security questions", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To set all the security questions and their answers for security
	 * 
	 * @param question
	 * @param question
	 */
	public boolean selectFromEnhancedSecurityQuestionsPage(int question, String answer) {
		boolean flag = false;
		try {
			webActions.selectDropDownByIndex(lstQuestion1, question);
			webActions.selectDropDownByIndex(lstQuestion2, question);
			webActions.selectDropDownByIndex(lstQuestion3, question);
			webActions.setValue(txtAnswer1, answer);
			webActions.setValue(txtAnswer2, "answer");
			webActions.setValue(txtAnswer3, "answer");
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtAnswer1, "value").equalsIgnoreCase(answer)) {
				flag = true;
				LogUtility.logInfo("---> selectFromEnhancedSecurityQuestionsPage <---",
						"Selected all the security questions ");
			} else
				LogUtility.logError("---> selectFromEnhancedSecurityQuestionsPage <---",
						"Failed to Select all the security questions ");
			webActions.clickElement(btnContinue);
		} catch (Exception e) {
			LogUtility.logException("->selectFromEnhancedSecurityQuestionsPage<--",
					"Failed to Select all the security questions", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on submenu items displayed on clicking the main menu items
	 * 
	 * @param Menu
	 * @param SubMenu
	 * @throws InterruptedException
	 */
	public void selectFromTheMenu(String Menu, String SubMenu) throws InterruptedException {
		waits.waitForPageReadyState();
		try {
			WebElement subMenu = null;
			switch (Menu) {
			case "Accounts":
				subMenu = accountsSubMenu;
				break;
			case "Payments":
				subMenu = paymentSubMenu;
				break;
			case "Transfers":
				subMenu = transfersSubMenu;
				break;
			case "Services":
				subMenu = servicesSubMenu;
				break;
			case "Support":
				subMenu = supportSubMenu;
				break;
			default:
				LogUtility.logInfo("---> selectFromTheMenu <---", "No case match found");
				break;
			}
			wolWebUtil.clickMenu(mainMenu, subMenu, Menu, SubMenu);
			LogUtility.logInfo("---> selectFromTheMenu <---", "Selected " + SubMenu + " from " + Menu);
		} catch (Exception e) {
			LogUtility.logException("->selectFromTheMenu<--", "Failed to Selecte " + SubMenu + " from " + Menu, e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To check if the Unauthorized User Access page
	 * 
	 * @param Menu
	 * @return
	 */
	public boolean checkTheUnathorizedUserAccessPage(String Menu) {
		try {
			if (webActions.getText(unauthorizedPageHeading).equalsIgnoreCase(Menu)) {
				LogUtility.logInfo("---> checkTheUnathorizedUserAccessPage <---",
						"Reached Unauthorized User Access page");
				return true;
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logException("->checkTheUnathorizedUserAccessPage<--",
					"Failed to Reach Unauthorized User Access page", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check for a link in a page with text same as param
	 * 
	 * @param Menu
	 * @return
	 */
	public boolean checkForLinkInAPage(String Menu) {
		try {
			WebElement element = ConcurrentEngines.getEngine().getWebDriver()
					.findElement(By.xpath("//a[contains(text(),'" + Menu + "')]"));
			if (waits.waitUntilElementIsPresent(element)) {
				LogUtility.logInfo("---> checkForLinkInAPage <---", "Link " + Menu + " is present");
				return true;
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logException("->checkForLinkInAPage<--", "Failed to Verify the link in a page", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check the page heading for Alerts Page
	 * 
	 * @return
	 */
	public boolean checkAlertsPageTitle() {
		try {
			if (waits.waitUntilElementIsPresent(alertsPageHeading, maxTimeOut)) {
				LogUtility.logInfo("---> checkAlertsPageTitle <---", "Alerts Page Title is displayed correct");
				return true;
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logException("->checkAlertsPageTitle<--", "Failed to Verify the Alerts Page Title", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To click on the link with text as linktext
	 * 
	 * @param linktext
	 */
	public void clickOnLink(String linktext) {
		try {
			WebElement clicklink;
			waits.waitForPageReadyState();
			if (linktext.equalsIgnoreCase("Security Information"))
				clicklink = ConcurrentEngines.getEngine().getWebDriver()
						.findElement(By.cssSelector("a[href*='Security']"));
			else if (linktext.equalsIgnoreCase("Equal Housing Lender"))
				clicklink = linkEqualHousingLender;
			else
				clicklink = ConcurrentEngines.getEngine().getWebDriver().findElement(By.linkText(linktext));
			webActions.clickElement(clicklink);
			LogUtility.logInfo("---> clickOnLink <---", "Clicked on the link " + linktext);
		} catch (Exception e) {
			LogUtility.logException("->clickOnLink<--", "Failed to click on the link " + linktext, e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To check for a heading in a page with text same as param
	 * 
	 * @param Menu
	 * @return
	 */
	public boolean checkThePageHeading(String Menu) {
		try {
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			waits.staticWait(3);
			waits.waitUntilElementIsPresent(pageHeading, maxTimeOut);
			if (webActions.getText(pageHeading).equalsIgnoreCase(Menu)) {
				{
					LogUtility.logInfo("---> checkThePageHeading <---", "Heading  " + Menu + " is present");
					return true;
				}
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logException("->checkThePageHeading<--", "Failed to verify the Heading " + Menu, e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check the title is same as param
	 * 
	 * @param title
	 * @return
	 */
	public boolean checkTheTitle(String title) {
		try {
			if (waits.waitUntilElementIsPresent(addANewPayeeHeading, maxTimeOut)) {
				LogUtility.logInfo("---> checkTheTitle <---", "Title " + title + " is present");
				return true;
			} else
				return false;
		} catch (Exception e) {
			LogUtility.logException("->checkTheTitle<--", "Failed to verify the Title " + title, e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To click on the setup alerts link after successful payment
	 */
	public void clickOnAlertsLinkInConfirmationPage() {
		try {
			webActions.clickElement(linkToAlertsPage);
			LogUtility.logInfo("---> clickOnAlertsLinkInConfirmationPage <---", "Clicked on setup alerts link");
		} catch (Exception e) {
			LogUtility.logException("->clickOnAlertsLinkInConfirmationPage<--", "Failed to Click on setup alerts link",
					e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To click on the Pending payments link after successful payment
	 */
	public void clickOnPendingPaymentsLinkInConfirmationPage() {
		try {
			webActions.clickElement(linkToPendingPayments);
			LogUtility.logInfo("---> clickOnPendingPaymentsLinkInConfirmationPage <---",
					"Clicked on Pending payments link");
		} catch (Exception e) {
			LogUtility.logException("->clickOnPendingPaymentsLinkInConfirmationPage<--",
					"Failed to Click on Pending payments link", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To click on the payment center link after successful payment
	 */
	public void clickOnPaymentCenterLinkInConfirmationPage() {
		try {
			webActions.clickElement(linkToPaymentCenter);
			LogUtility.logInfo("---> clickOnPaymentCenterLinkInConfirmationPage <---",
					"Clicked on Payment Center link");
		} catch (Exception e) {
			LogUtility.logException("->clickOnAlertsLinkInConfirmationPage<--",
					"Failed to Click on Payment Center link", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * verifySignOuttxt:- To verify Sign Out text message
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifySignOutTxt(String message) {
		try {
			waits.staticWait(5);
			waits.waitUntilElementIsPresent(txtSignout);
			return wolWebUtil.verifyTextContains(txtSignout, message);
		} catch (Exception e) {
			LogUtility.logException("->verifySignOutTxt<--", "Failed to verify SignOut Text", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * getTheUserName:- To get the username from UI and set it into a global
	 * variable
	 * 
	 * @return
	 * @throws Exception
	 */
	public void getTheUserName() throws Exception {
		try {
			webActions.clickElement(btnCustomerProfileIcon);
			setValueInRuntimeDataMap("UserName", webActions.getText(txtUsernameFromProfile));
		} catch (Exception e) {
			LogUtility.logException("->getTheUserName<--", "Exception while getting the username" + userName, e,
					LoggingLevel.ERROR, true);
			throw new Exception("Exception while getting the username" + userName);
		}
	}

	/**
	 * To click on the message number to get the messages view variable
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean clickOnMessageFromCustomerIcon() throws Exception {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(btnCustomerProfileIcon)) {
				wolWebUtil.clickWebElement(btnCustomerProfileIcon, "clickOnMessageFromCustomerIcon");
				wolWebUtil.clickWebElement(linkMsgCount, "clickOnMessageFromCustomerIcon");
				status = true;
				LogUtility.logInfo("--->clickOnMessageFromCustomerIcon<---",
						"Clicked on the message count link from customer profile icon ");
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnMessageFromCustomerIcon<--",
					"Failed to click on message count link from Customer icon", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * verifyUserNameLabel:- To verify username label in Log in pages
	 * 
	 * @return
	 */
	public boolean verifyUserNameLabel() {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			return webActions.isDisplayed(txtUsernameLabel);
		} catch (Exception e) {
			LogUtility.logException("->verifyUserNameLabel<--", "Failed to verify the username label", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * checkPageTitle: To get the page title
	 *
	 */
	public boolean checkPageTitle(String pageName) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			//TODO: Firefox is taking longer time to load
			waits.staticWait(5);
			waits.waitForPageToLoad(maxTimeOut);
			if (wolWebUtil.verifyTextContains(txtPageTitle1, pageName)
					|| wolWebUtil.verifyTextContains(txtPageHeaderH3, pageName)) {
				LogUtility.logInfo("--->checkPageTitle<---", "redirected to " + pageName + " page");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkPageTitle<--", "Failed to verify the page " + pageName, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * switchToFrameIndex : Switch to frame based on Index
	 * 
	 * @param index
	 * @return
	 */
	public boolean switchToFrameByIndex(String index) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			driver.switchTo().frame(Integer.parseInt(index));
			LogUtility.logInfo("--->switchToFrameByIndex<---", "Switched to " + index + " frame");
			return true;
		} catch (Exception e) {
			LogUtility.logException("->switchToFrameByIndex<--", "Failed to switch to frame by index", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * switchToDefaultContent: To switch back to Default content
	 * 
	 * @return
	 */
	public boolean switchToDefaultContent() {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			driver.switchTo().defaultContent();
			LogUtility.logInfo("--->switchToDefaultContent<---", "Switched to default content");
			return true;
		} catch (Exception e) {
			LogUtility.logException("->switchToDefaultContent<--", "Failed to switch to Default content", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnAccountsTab: To click on the accounts Tab
	 * 
	 * @return
	 * @author rpagadala-adm
	 */
	public boolean clickOnAccountsTab() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(menuAccounts)) {
				webActions.clickElement(menuAccounts);
				LogUtility.logInfo("-->clickOnAccountsTab<--", "Clicked on Accounts tab");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("--->clickOnAccountsTab<---", "NOt clicked on Accounts tab", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifySubLinkUndertAccountsTab: To verify the subMenu is displayed under
	 * Accounts tab
	 * 
	 * @return
	 * @author rpagadala-adm
	 * @param subLinkName
	 */
	public boolean verifySubLinkUndertAccountsTab(String subLinkName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(menuAccounts)) {
				List<WebElement> linksSubMenu = menuAccounts.findElements(By.tagName("a"));
				for (int i = 0; i < linksSubMenu.size(); i++) {
					String linkName = linksSubMenu.get(i).getText();
					if (linkName.equalsIgnoreCase(subLinkName)) {
						LogUtility.logInfo("-->verifySubLinkUndertAccountsTab<--",
								"Sub Menu: " + subLinkName + " is displayed");
						return true;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("--->verifySubLinkUndertAccountsTab<---",
					"Sub Menu: " + subLinkName + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * switchToChildWindow : To switch to child window
	 * 
	 * @return boolean
	 * @author rpagadala-adm
	 */
	public boolean switchToChildWindow() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			wolWebUtil.switchToNewWindow();
			LogUtility.logInfo("-->switchToChildWindow<--", "Switched to Child Window");
			return true;
		} catch (Exception e) {
			LogUtility.logException("--->switchToChildWindow<---", "Failed in switch to Child Window", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * switchToParentWindow: To switch to parent window
	 * 
	 * @return boolean
	 * @author rpagadala-adm
	 */
	public boolean switchToParentWindow() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			wolWebUtil.switchToMainWindow();
			LogUtility.logInfo("-->switchToParentWindow<--", "Switched to Parent Window");
			return true;
		} catch (Exception e) {
			LogUtility.logException("--->switchToParentWindow<---", "Failed in switch to Parent Window", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}
}