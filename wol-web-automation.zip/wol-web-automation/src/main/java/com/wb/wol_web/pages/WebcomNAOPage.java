package com.wb.wol_web.pages;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class WebcomNAOPage extends ObjectBase {

	public WebcomNAOPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "cust_promo_code")
	protected WebElement inputOLServicesCode;

	@FindBy(name = "miser_promo_code")
	protected WebElement inputSystemCode;

	@FindBy(name = "end_date")
	protected WebElement inputEndDate;

	@FindBy(name = "campaign_code")
	protected WebElement inputCampaignCode;

	@FindBy(name = "start_date")
	protected WebElement inputStartDate;

	@FindBy(css = "h1")
	protected WebElement txtHeader;

	@FindBy(name = "promo_name")
	protected WebElement inputPromoName;

	@FindBy(name = "promo_product_name")
	protected WebElement inputPromoProduct;

	@FindBy(name = "promo_min_open_dep")
	protected WebElement inputPromoMin;

	@FindBy(name = "promo_rate")
	protected WebElement inputPromoRate;

	@FindBy(name = "promo_apy")
	protected WebElement inputPromoAPY;

	@FindBy(name = "channel")
	protected WebElement selChannel;

	@FindBy(name = "promo_desc")
	protected WebElement inputPromoDesc;

	@FindBy(name = "tac_0001")
	protected WebElement inputTAC;

	@FindBy(name = "conf_message")
	protected WebElement inputConfMsg;

	@FindBy(css = "[value='Continue']")
	protected WebElement btnContinue;

	@FindBy(css = "[value='Create Promotion']")
	protected WebElement btnCreatePromo;

	@FindBy(css = "[value='OK']")
	protected WebElement btnOK;

	@FindBy(css = "[value='Search']")
	protected WebElement btnSearch;

	@FindBy(css = "td a")
	protected WebElement linkView;

	@FindBy(id = "sdate")
	protected WebElement inputNAOStartDate;

	@FindBy(id = "edate")
	protected WebElement inputNAOEndDate;

	@FindBy(css = "[value=' Submit ']")
	protected WebElement btnSubmit;

	@FindBy(css = "textarea")
	protected WebElement inputResponse;

	@FindBy(name = "productCategoryId")
	protected WebElement selCategory;

	@FindBy(css = "#wil_service")
	protected WebElement selWILService;

	@FindBy(css = "#soap_action")
	protected WebElement selReqAction;

	@FindBy(css = "[name='cif']")
	protected WebElement inputCIF;

	@FindBy(css = "div>table>tbody>tr>td:nth-child(1)[align='right']")
	protected List<WebElement> lstVerificatnLabels;

	@FindBy(css = "div>table>tbody>tr>td:nth-child(2) input[disabled='true']")
	protected List<WebElement> tableVerificationValues;

	@FindBy(css = "div>table>tbody>tr>td[bgcolor='#FFFFFF']")
	protected List<WebElement> tableVerifyTextAreaValues;

	@FindBy(css = "td a:nth-child(1)")
	protected List<WebElement> lstNAODataRows;

	@FindBy(css = "div.right_side div.data")
	protected List<WebElement> lstOrderDataRight;

	@FindBy(css = "div.right_side div.label")
	protected List<WebElement> lstOrderLabelsRight;

	@FindBy(css = "div.left_side div.data")
	protected List<WebElement> lstOrderDataLeft;

	@FindBy(css = "div.left_side div.label")
	protected List<WebElement> lstOrderLabelsLeft;

	@FindBy(css = "li a[href*='NewAccount&menu']")
	protected List<WebElement> lstNAOMenu;

	public void enterPromoData(Map<String, String> testDataMap) throws Exception {
		waits.waitForPageToLoad(maxTimeOut);
		waits.waitUntilElementIsPresent(inputOLServicesCode, maxTimeOut);
		String code = wolWebUtil.getRandomNumber(4);
		try {
			webActions.setValue(inputOLServicesCode, testDataMap.get("Online Services Code") + code);
			webActions.setValue(inputSystemCode, testDataMap.get("System Promo Code") + code);
			inputEndDate.sendKeys(testDataMap.get("End Date"));
			if (!testDataMap.get("Start Date").equals(""))
				inputStartDate.sendKeys(testDataMap.get("Start Date"));
			else
				inputStartDate.sendKeys(wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 0));
			webActions.setValue(inputCampaignCode, testDataMap.get("System Campaign Code"));
			webActions.setValue(inputPromoName, testDataMap.get("Promotion/Campaign Name"));
			webActions.setValue(inputPromoProduct, testDataMap.get("Promotion Product"));
			webActions.setValue(inputPromoMin, testDataMap.get("Min Open Dep"));
			webActions.setValue(inputPromoRate, testDataMap.get("Promotion Rate"));
			webActions.setValue(inputPromoAPY, testDataMap.get("Promotion APY"));
			webActions.setValue(inputPromoDesc, testDataMap.get("Promo Description"));
			webActions.setValue(inputTAC, testDataMap.get("T & C"));
			webActions.setValue(inputConfMsg, testDataMap.get("Confirmation Page"));
			LogUtility.logInfo("enterPromoData", "Entered the promo details as " + testDataMap);

			jsonDataParser.getTestDataMap().put("Online Services Code", testDataMap.get("Online Services Code") + code);

			jsonDataParser.getTestDataMap().put("System Promo Code",
					jsonDataParser.getTestDataMap().get("System Promo Code") + code);
			jsonDataParser.getTestDataMap().put("Start Date", wolWebUtil.changeTheDatePattern("MM/dd/yyyy",
					"yyyy-MM-dd", wolWebUtil.getDateInTheFormat("MM/dd/yyyy", 0)));
			jsonDataParser.getTestDataMap().put("End Date", wolWebUtil.changeTheDatePattern("MM/dd/yyyy", "yyyy-MM-dd",
					jsonDataParser.getTestDataMap().get("End Date")));
		} catch (Exception e) {
			LogUtility.logException("enterPromoData", "Exception in entering promo details", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	public boolean clickOnContinue() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnContinue, maxTimeOut);
			if (webActions.isDisplayed(btnContinue)) {
				webActions.clickElement(btnContinue);
				status = true;
				LogUtility.logInfo("clickOnContinue", "Clicked on the button continue");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnContinue", "Exception in clickOnContinue function in webcom promo page", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOnSearch() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnSearch, maxTimeOut);
			if (webActions.isDisplayed(btnSearch)) {
				webActions.clickElement(btnSearch);
				status = true;
				LogUtility.logInfo("clickOnSearch", "Clicked on the button continue");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnSearch", "Exception in clickOnSearch function in webcom promo page", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOnCreatePromotion() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnCreatePromo, maxTimeOut);
			if (webActions.isDisplayed(btnCreatePromo)) {
				webActions.clickElement(btnCreatePromo);
				status = true;
				LogUtility.logInfo("clickOnCreatePromotion", "Clicked on the button create promotion");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCreatePromotion",
					"Exception in clickOnCreatePromotion function in webcom promo page", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOnViewLink() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(linkView, maxTimeOut);
			if (webActions.isDisplayed(linkView)) {
				webActions.clickElement(linkView);
				status = true;
				LogUtility.logInfo("clickOnViewLink", "Clicked on the linkView");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewLink", "Exception in clickOnViewLink function in webcom promo page", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public Map<String, String> checkData(Map<String, String> jsonDetails) {
		LinkedHashMap<String, String> uiDetails = new LinkedHashMap<>();
		waits.waitForPageToLoad(maxTimeOut);
		waits.waitForDOMready();
		try {
			for (int i = 0; i < lstVerificatnLabels.size(); i++) {
				String key = lstVerificatnLabels.get(i).getText();
				if (key.equals("Promo Description") || key.equals("T & C") || key.equals("Confirmation Page")) {
					switch (key) {
					case "Promo Description":
						if (tableVerifyTextAreaValues.get(0).getText().equals(jsonDetails.get(key)))
							uiDetails.put(key, jsonDetails.get(key));
						break;
					case "T & C":
						if (tableVerifyTextAreaValues.get(1).getText().equals(jsonDetails.get(key)))
							uiDetails.put(key, jsonDetails.get(key));
						break;
					case "Confirmation Page":
						if (tableVerifyTextAreaValues.get(2).getText().equals(jsonDetails.get(key)))
							uiDetails.put(key, jsonDetails.get(key));
						break;
					default:
						LogUtility.logError("", "Invalid key " + key);
						break;
					}
				} else {
					if (tableVerificationValues.get(i).getAttribute("value").equalsIgnoreCase(jsonDetails.get(key))) {
						uiDetails.put(key, jsonDetails.get(key));
					}

				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkData", "Exception in checkData function in webcom promo page", e,
					LoggingLevel.ERROR, true);
		}

		return uiDetails;
	}

	public void enterPromoDataToSearch(String field) throws Exception {
		waits.waitForPageToLoad(maxTimeOut);
		waits.waitUntilElementIsPresent(inputOLServicesCode, maxTimeOut);
		try {
			webActions.setValue(inputOLServicesCode, jsonDataParser.getTestDataMap().get("Online Services Code"));

		} catch (Exception e) {
			LogUtility.logException("enterPromoDataToSearch", "Exception in enterPromoDataToSearch function", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public boolean enterSearchDates(String startDate) {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(inputNAOStartDate, maxTimeOut)) {
				inputNAOStartDate.clear();
				inputNAOStartDate.sendKeys(startDate);
				status = true;
				LogUtility.logInfo("enterSearchDates", "Entered the search dates as " + startDate + " ");
			}
		} catch (Exception e) {
			LogUtility.logException("enterSearchDates", "Exception in enterSearchDates function", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public void clickAnyRowInNAOResults() throws Exception {
		Random randomGenerator = new Random();
		try {
			int randomInt = randomGenerator.nextInt(lstNAODataRows.size()) + 1;
			lstNAODataRows.get(randomInt).click();

		} catch (Exception e) {
			LogUtility.logException("enterSearchDates", "Exception in enterSearchDates function", e, LoggingLevel.ERROR,
					true);
			throw e;
		}

	}

	public boolean checkTheLabelsInOrderDetails(String side, String labelsfromJSON) {
		boolean status = false;
		List<WebElement> labels = null;
		List<WebElement> data = null;
		String statusString = "";
		try {
			if (side.equals("Left")) {
				labels = lstOrderLabelsLeft;
				data = lstOrderDataLeft;
			} else {
				labels = lstOrderLabelsRight;
				data = lstOrderDataRight;
			}
			for (String eachLabelFromJSON : labelsfromJSON.split(",")) {
				for (int i = 0; i < labels.size(); i++) {
					if (labels.get(i).getText().trim().equals(eachLabelFromJSON)
							&& !data.get(i).getText().trim().equals(" ")) {
						statusString = statusString + ",";
					}

				}
			}
			if (statusString.equals("")) {
				status = true;
				LogUtility.logInfo("checkTheLabelsInOrderDetails", "All the labels are present " + labelsfromJSON);
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheLabelsInOrderDetails",
					"Exception in checkTheLabelsInOrderDetails function", e, LoggingLevel.ERROR, true);
		}

		return status;
	}

	public void enterSearchCriteria(String category, String startDate) throws Exception {
		try {

			webActions.selectDropDownByValueJs(selCategory, "5");
			waits.waitForDOMready();
			waits.staticWait(2);
			inputNAOStartDate.sendKeys(startDate);
			LogUtility.logInfo("enterSearchCriteria", "Entered the data: " + category + " in category");

		} catch (Exception e) {
			LogUtility.logException("enterSearchCriteria", "Exception in enterSearchCriteria function", e,
					LoggingLevel.ERROR, true);
			throw e;
		}

	}

	public boolean verifyPageHeader(String message) {
		try {
			waits.waitUntilElementIsPresent(txtHeader, maxTimeOut);
			return wolWebUtil.verifyTextContains(txtHeader, message);
		} catch (Exception e) {
			LogUtility.logException("verifyPageHeader", "Exception in verifyPageHeader function", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	public boolean clickOnNAOMenu(String link) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			for (WebElement eachLink : lstNAOMenu) {
				if (eachLink.getText().equals(link)) {
					webActions.clickElementJS(eachLink);
					status = true;
					LogUtility.logInfo("clickOnNAOMenu", "Clicked on the link " + link);
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnNAOMenu", "Exception in clickOnNAOMenu function", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean selectFromWILService(String msg) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(selWILService);

			if (selWILService.isDisplayed()) {
				webActions.selectDropDownByText(selWILService, msg);
				LogUtility.logInfo("selectFromWILService", "Selected the value :" + msg + " from WIL service");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromWILService",
					"Exception in selecting the value :" + msg + " from WIL service", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean selectFromReqAction(String msg) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(selReqAction);

			if (selReqAction.isDisplayed()) {
				webActions.selectDropDownByText(selReqAction, msg);
				LogUtility.logInfo("selectFromReqAction",
						"Selected the value :" + msg + " from Request Action dropdown");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromReqAction",
					"Exception in selecting the value :" + msg + " from Request Action dropdown", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	public boolean enterCIFNumber(String number) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(inputCIF, maxTimeOut);
			if (inputCIF.isDisplayed()) {
				webActions.setValue(inputCIF, number);
				LogUtility.logInfo("enterCIFNumber", "Entered the value :" + number + " in CIF input box");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromReqAction",
					"Exception in entering the value :" + number + "  in CIF input box", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean clickOnSubmitButton() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnSubmit, maxTimeOut);
			if (btnSubmit.isDisplayed()) {
				wolWebUtil.clickWebElement(btnSubmit, "clickOnSubmitButton");
				LogUtility.logInfo("enterCIFNumber", "Clicked on the button - submit");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromReqAction", "Exception in clicking the submit button", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkSOAPResonse(String tag, String value) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(inputResponse, maxTimeOut);
			String response = webActions.getText(inputResponse);
			if (response.contains("<" + tag + ">" + value + "</" + tag + ">")) {
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromReqAction", "Exception in clicking the submit button", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}
}