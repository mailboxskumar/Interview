
package com.wb.wol_web.pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class FeesInitiativePage extends ObjectBase {

	public FeesInitiativePage() {
		PageFactory.initElements(driver, this);
	}

	public String transactionRowPath = "#transactionsTable tbody:nth-child(2) tr:nth-child(";
	public String transactionNamePath = ")>td:nth-child(3)";
	public String transactionWithdrawlAmountPath = ")>td:nth-child(5)";
	public WebElement eleTransactionName = null;
	public WebElement eleTransactionAmount = null;

	@FindBy(css = "#transactionsTable tbody:nth-child(2) tr")
	protected List<WebElement> listRowsTransactionTable;

	/**
	 * verifyTransactionAmount: To verify the transaction name and amount
	 * 
	 * @param transactionName
	 * @param amount
	 * @return
	 */
	public boolean verifyTransactionAmount(String transactionName, String amount) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			int tableSize = listRowsTransactionTable.size();
			for (int row = 1; row <= tableSize; row++) {
				eleTransactionName = driver
						.findElement(By.cssSelector(String.format(transactionRowPath + row + transactionNamePath)));
				if (wolWebUtil.verifyTextContains(eleTransactionName, transactionName)) {
					eleTransactionAmount = driver.findElement(
							By.cssSelector(String.format(transactionRowPath + row + transactionWithdrawlAmountPath)));
					if (wolWebUtil.verifyTextContains(eleTransactionAmount, amount)) {
						LogUtility.logInfo("-->verifyTransactionAmount<--",
								"Transaction Name : " + transactionName + " and Amount :" + amount + " is displayed");
						return true;
					} else {
						LogUtility.logInfo("-->verifyTransactionAmount<--", "Transaction Name : " + transactionName
								+ " is displayed but Amount :" + amount + " is not displayed");
					}
				} else {
					LogUtility.logInfo("-->verifyTransactionAmount<--",
							"Transaction Name : " + transactionName + " is not displayed ");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyTransactionAmount<--",
					"Transaction Name : " + transactionName + " and Amount :" + amount + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

}