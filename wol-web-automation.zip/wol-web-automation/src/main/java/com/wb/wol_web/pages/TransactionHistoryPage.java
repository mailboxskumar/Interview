package com.wb.wol_web.pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

import edu.emory.mathcs.backport.java.util.Collections;

/**
 * @author Veerababu Pedireddi
 *
 */
public class TransactionHistoryPage extends ObjectBase {

	public TransactionHistoryPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//h1[contains(.,'Transaction History')]")
	protected WebElement titleTransHisPage;

	@FindBy(id = "accountNav__submenu-title")
	protected WebElement lstSelectAcc;

	@FindBy(id = "accountNav__list")
	protected WebElement lstSelectAccList;

	@FindBy(id = "accountNav__list")
	protected List<WebElement> lstAccList;

	@FindBy(id = "dateRange__label")
	protected WebElement lblDateRangeLabel;

	@FindBy(id = "dateRange__input")
	protected WebElement lstDateRange;

	@FindBy(id = "from_date__input")
	protected WebElement txtFromDate;

	@FindBy(id = "to_date__input")
	protected WebElement txtToDate;

	@FindBy(id = "date_range_submit_button__actualButton")
	protected WebElement btnUpdate;

	@FindBy(css = "#bodyContent h1")
	protected WebElement titleAccLoanStmtsPage;

	@FindBy(id = "from_date__error-message-text")
	protected WebElement errFromDate;

	@FindBy(id = "to_date__error-message-text")
	protected WebElement errToDate;

	@FindBy(xpath = "//*[@id='posted_transactions']/ul/li/span[1]")
	protected List<WebElement> lblDateValidation;

	@FindBy(xpath = "//*[@id='posted_transactions']/ul/li/span")
	protected WebElement tablePostedTrans;

	@FindBy(id = "adBanner__image")
	protected WebElement bannerImage;

	@FindBy(id = "posted_transactions__filter__input")
	protected WebElement lstPostTransFilter;

	@FindBy(xpath = "//*[@id='posted_transactions']/ul/li/span[2]")
	protected List<WebElement> lblFilterValidation;

	@FindBy(xpath = "//*[@id='posted_transactions']/ul/li/span[6]")
	protected List<WebElement> lblBalanceValidation;

	@FindBy(id = "posted_transactions__filterByText__input")
	protected WebElement txtSearchBar;

	@FindBy(id = "posted_transactions__sort__input")
	protected WebElement lstSortingValues;

	@FindBy(id = "submenu-title-content")
	protected WebElement lstAccountselect;

	@FindBy(xpath = "//*[@id='posted_transactions']/ul/li/span[3]")
	protected List<WebElement> imageLink;

	@FindBy(xpath = "(//section[@id='posted_transactions']/ul/li/span[3]/preceding::a/img)")
	protected List<WebElement> linkDeposit;

	@FindBy(xpath = "//h1[contains(.,'View Deposit Details')]")
	protected WebElement titleDepositPage;

	@FindBy(xpath = "//h1[contains(.,'Check Image - Front and Back')]")
	protected WebElement titleChkWithDrawal;

	@FindBy(id = "view-deposit-details-opt-out__pageInstructions")
	protected WebElement msgDepositPage;

	@FindBy(css = "#print_button")
	protected WebElement btnPrint;

	@FindBy(css = "#back_button")
	protected WebElement btnBackToPreviousPage;

	@FindBy(css = "#account__display span")
	protected WebElement lblAccFormatTxt;

	@FindBy(css = "#date__display span")
	protected WebElement lblTransDate;

	@FindBy(css = "#amount__display span")
	protected WebElement lblTransAmt;

	@FindBy(xpath = "//span[@id='check_number__display']/span")
	protected WebElement lblChkNumber;

	@FindBy(id = "front_image_0__image")
	protected WebElement imgFront;

	@FindBy(id = "back_image_0__image")
	protected WebElement imgBack;

	@FindBy(xpath = "//div[@id='lightBoxContent1']/img")
	protected WebElement imgEnlargeFront;

	@FindBy(xpath = "//div[@id='lightBoxContent2']/img")
	protected WebElement imgEnlargeBack;

	@FindBy(xpath = "(//button[contains(.,'Print')])[2]")
	protected WebElement btnPrintOnFrontImage;

	@FindBy(css = "#content div.lightbox-wrap.lightbox--dialog.is-visible.is-top div div.lightbox div.lightbox-controls button.lightbox-controls__button.lightbox-controls__button--close")
	protected WebElement btnCloseOnFrontImage;

	@FindBy(xpath = "(//button[contains(.,'Print')])[3]")
	protected WebElement btnPrintOnBackImage;

	@FindBy(xpath = "(//button[contains(.,'Close')])[9]")
	protected WebElement btnCloseOnBackImage;

	@FindBy(xpath = "//div[@id='pageContent']/h2[1]/span")
	protected WebElement lblAccNumber;

	@FindBy(xpath = "//*[@id='accountSummaryTable']/tbody/tr[2]/td[2]/strong")
	protected WebElement lblTrnAmount;

	@FindBy(id = "transactionsTable")
	protected WebElement lblTrnDetails;

	@FindBy(id = "advanced_search")
	protected WebElement btnAdvSearch;

	@FindBy(id = "accounts")
	protected WebElement cmbAccSelect;

	@FindBy(id = "from_date")
	protected WebElement txtFromDateAdvSearch;

	@FindBy(id = "to_date")
	protected WebElement txtToDateAdvSearch;

	@FindBy(id = "trans_type")
	protected WebElement cmbTrnTypeAdvSearch;

	@FindBy(id = "posted_transactions__emptyListMessage")
	protected WebElement msgNoPostedTrans;

	@FindBy(id = "posted_transactions_row0__col_0")
	protected WebElement lblPostedTransDate;

	@FindBy(id = "from_date__calendar-button")
	protected WebElement btnFromDateCalendar;

	@FindBy(id = "to_date__calendar-button")
	protected WebElement btnToDateCalendar;

	@FindBy(xpath = "//div[@id='from_date__input_root']/div")
	protected WebElement iconFromDateCalendar;

	@FindBy(xpath = "//div[@id='to_date__input_root']/div")
	protected WebElement iconToDateCalendar;

	@FindBy(css = "#view-deposit-details__pageInstructions__body p")
	protected WebElement msgDepositDetailsEnroll;

	@FindBy(css = "#images_table__filterByText__input")
	protected WebElement txtFilterByText;

	@FindBy(css = "#images_table__row0__col_1")
	protected WebElement lblDescription;

	@FindBy(css = "#images_table__row0__col_2")
	protected WebElement lblAmount;

	@FindBy(css = "#view-deposit-details__pageInstructions__body p")
	protected WebElement msgEnrollDepositDetails;

	@FindBy(css = "#depositImage0__image")
	protected WebElement imgFrontDeposit;

	@FindBy(css = "#images_table__emptyListMessage")
	protected WebElement tableEmptyMesssage;

	@FindBy(css = "#view-deposit-details-opt-out__pageInstructions__body  p  a")
	protected WebElement lnkOptInDepositDetails;

	@FindBy(css = "#view-deposit-details__pageInstructions__body  p a")
	protected WebElement lnkOptOutDepositDetails;

	@FindBy(css = "#back_to_previous_page")
	protected WebElement btnBack;

	@FindBy(id = "dateRange__input")
	protected List<WebElement> cmbDateRange;

	@FindBy(id = "primary_balance__display")
	protected WebElement lblAvailableBalance;

	@FindBy(id = "print_transactions")
	protected WebElement iconPrintTransaction;

	@FindBy(css = "#posted_transactions__headings")
	protected WebElement tblPostedTransactionsHeaders;

	@FindBy(css = "#posted_transactions_row0")
	protected WebElement tblPostedTransactionsValues;

	@FindBy(id = "back_to_top")
	protected WebElement btnBackToTop;

	@FindBy(id = "print")
	protected WebElement btnPrintViewDeposit;

	@FindBy(css = "#account_display__display")
	protected WebElement txtAccFormat;

	@FindBy(css = "#cleared_date__display span")
	protected WebElement lblTransactionDate;

	@FindBy(css = "#check_amount__display span")
	protected WebElement lblTransactionAmt;

	@FindBy(css = "#posted_transactions_row0__col_0")
	protected WebElement lblFirstTransactionDate;

	@FindBy(css = "#posted_transactions_row0__col_2 a img")
	protected WebElement lblFirstTransactionIcon;

	@FindBy(css = "#posted_transactions_row0__col_4")
	protected WebElement lblFirstTransactionAmt;

	@FindBy(css = "#posted_transactions_row1__col_0")
	protected WebElement lblSecondTransactionDate;

	@FindBy(css = "#posted_transactions_row1__col_2 a img")
	protected WebElement lblSecondTransactionIcon;

	@FindBy(css = "#posted_transactions_row1__col_4")
	protected WebElement lblSecondTransactionAmt;

	@FindBy(css = "#depositImage1__image")
	protected WebElement imgBackDeposit;

	@FindBy(css = "#lightBoxContent3 img")
	protected WebElement imgFrontEnlargeDeposit;

	@FindBy(css = "#lightBoxContent4 img")
	protected WebElement imgBackEnlargeDeposit;

	@FindBy(css = "#posted_transactions_row2__col_0")
	protected WebElement lblThirdTransactionDate;

	@FindBy(css = "#posted_transactions_row2__col_2 a img")
	protected WebElement lblThirdTransactionIcon;

	@FindBy(css = "#posted_transactions_row2__col_4")
	protected WebElement lblThirdTransactionAmt;

	@FindBy(css = "#posted_transactions_row3__col_0")
	protected WebElement lblFourthTransactionDate;

	@FindBy(css = "#posted_transactions_row3__col_2 a img")
	protected WebElement lblFourthTransactionIcon;

	@FindBy(css = "#posted_transactions_row3__col_4")
	protected WebElement lblFourthTransactionAmt;

	@FindBy(css = "#posted_transactions img")
	protected WebElement lblPostedTransImg;

	@FindBy(css = "#more_transactions_button")
	protected WebElement btnMoreTransactions;

	@FindBy(css = "#depositImage2__image")
	protected WebElement lnkCheckImageIcon;

	@FindBy(css = "#content div.lightbox-wrap.lightbox--dialog.is-visible.is-top div div.lightbox div.lightbox-controls button.lightbox-controls__button.lightbox-controls__button--print")
	protected WebElement btnChkImagePrint;

	@FindBy(css = "#lightBoxContent5 img")
	protected WebElement imgCheckImgEnlarge;

	@FindBy(xpath = "//span[4][contains(.,'$')]")
	protected List<WebElement> lblWithdrawalAmounts;

	@FindBy(xpath = "//span[5][contains(.,'$')]")
	protected List<WebElement> lblDepositAmounts;

	@FindBy(xpath = "//span[3][contains(.,'$')]")
	protected List<WebElement> lblTransAmounts;

	protected String imgLink1Xpath = "//*[@id='posted_transactions_row";
	protected String imgLink2Xpath = "__col_2']/a";
	protected String transDateXpath = "__col_0']";
	protected String depositAmtXpath = "__col_4']";
	protected String withDraAmtXpath = "__col_3']";
	protected String tranDateXpath = null;
	protected String tranAmtXpath = null;
	protected String depositLinkXpath = null;
	protected String withDraLinkXpath = null;
	protected String actionMenuXpath = null;
	protected String viewDetailsXpath = null;

	protected String fromDateValue = null;
	protected String toDateValue = null;
	protected String transDateFromList = null;
	public String transAmtFromList = null;
	protected String transactionDate = null;
	protected String postedTransDesc = null;
	protected String postedTransDetails = null;
	protected String dateRange = null;
	protected String accountNumber = null;
	public String availableBalance = null;
	public String duplicateTransDate = null;
	public String duplicateTransAmount = null;

	/**
	 * To Verify the Transaction History Page Title
	 */
	public boolean verifyTransHistoryPage(String message) {
		try {
			waits.staticWait(3);
			return wolWebUtil.verifyText(titleTransHisPage, message);
		} catch (Exception e) {
			LogUtility.logException("verifyTransHistoryPage", message + " Page is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Verify the first account is selected or not
	 */
	public boolean verifyFirstAccSelected() {
		boolean flag = false;
		try {
			String value = webActions.getVisibleElement(lstAccList).getText();
			if (value != (""))
				flag = true;
			LogUtility.logInfo("--->verifyFirstAccSelected<---", "First Account Selected");
		} catch (Exception e) {
			LogUtility.logException("verifyFirstAccSelected", "Unable to select the First Account", e,
					LoggingLevel.ERROR, true);
			return flag;
		}
		return flag;
	}

	/**
	 * To Click on the Account dropdown list
	 */
	public boolean clickOnAccList() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lstSelectAcc, maxTimeOut);
			boolean accountList = webActions.isDisplayed(lstSelectAcc);
			if (accountList) {
				webActions.clickElement(lstSelectAcc);
				LogUtility.logInfo("---> clickOnAccList <---", "Clicked On AccList");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnAccList", "Unable to click on Accounts List", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To select Account from dropdown list
	 */
	public boolean selectAccFromDropdown(String account) {
		boolean flag = false;
		waits.waitForPageReadyState(maxTimeOut);
		waits.waitForDOMready();
		try {
			boolean selectAccount = webActions.isDisplayed(lstSelectAccList);
			if (selectAccount) {
				wolWebUtil.selectListValue(lstSelectAccList, account);
				waits.waitForPageReadyState(maxTimeOut);
				waits.waitForDOMready();
				waits.staticWait(5);
				LogUtility.logInfo("---> Seelct Account From Dropdown <---", "Account Selected");
				flag = true;
				// After select the account, fields loading takes time
				waits.staticWait(5);
			}
		} catch (Exception e) {
			LogUtility.logException("selectAccFromDropdown", "Unable to select the Account", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To Verify the Date Range Label in Transaction History Page
	 */
	public boolean verifyDateRangeLable(String label) {
		try {
			return wolWebUtil.verifyText(lblDateRangeLabel, label);
		} catch (Exception e) {
			LogUtility.logException("verifyDateRangeLable", label + " lable is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To click on the Date range option in Transaction History page
	 */
	public boolean clickOnDateRangeOption() {
		boolean flag = false;
		try {
			boolean dateRange = webActions.isDisplayed(lstDateRange);
			if (dateRange) {
				webActions.clickElement(lstDateRange);
				LogUtility.logInfo("---> clickOnDateRangeOption <---", "Clicked on Date Range option");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnDateRangeOption", "Unable to click on Date range Option", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To select the Custom range option from Date Range drop down
	 */
	public boolean selectCustomRange(String customRange) {
		boolean flag = false;
		try {
			boolean dateRange = webActions.isDisplayed(lstDateRange);
			if (dateRange) {
				webActions.selectDropDownByText(lstDateRange, customRange);
				LogUtility.logInfo("--->selectCustomRange<---", "Custom Range Selected from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectCustomRange", "Unable to select " + customRange + "Option", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter the data given in the From date field
	 *
	 */
	public String enterFromDate(String fromDt) {
		try {
			fromDateValue = wolWebUtil.getOldDate(fromDt);
			webActions.setValue(txtFromDate, fromDateValue);
			LogUtility.logInfo("--->enterFromDate<---", " From Date entered ");
		} catch (Exception e) {
			LogUtility.logException("enterFromDate", "Unable to enter from date", e, LoggingLevel.ERROR, true);
		}
		return fromDateValue;
	}

	/**
	 * To enter the data given in the To date field
	 *
	 */
	public String enterToDate(String toDt) {
		try {
			toDateValue = wolWebUtil.getOldDate(toDt);
			webActions.setValue(txtToDate, toDateValue);
			LogUtility.logInfo("--->enterToDate <---", "To Date entered");
		} catch (Exception e) {
			LogUtility.logException("enterToDate", "Unable to enter to date", e, LoggingLevel.ERROR, true);
		}
		return toDateValue;
	}

	/**
	 * To click on the Update button in Transaction History page
	 */
	public boolean clickOnUpdate() {
		boolean flag = false;
		try {
			boolean updateButton = webActions.isDisplayed(btnUpdate);
			if (updateButton) {
				webActions.clickElement(btnUpdate);
				LogUtility.logInfo("---> clickOnUpdate <---", "Clicked on Update button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnUpdate", "Unable to click on update button", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To select the Account Statement from dropdown
	 */
	public boolean selectAccStmt() {
		boolean flag = false;
		try {
			boolean dateRange = webActions.isDisplayed(lstDateRange);
			if (dateRange) {
				wolWebUtil.selectByTextContains(lstDateRange);
				LogUtility.logInfo("---> selectAccStmt------>", "Value selected from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectAccStmt", " Unable to select Account statment", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Accounts Loan Statements Page title
	 */

	public boolean verifyAccStmtsPage(String accLoanStmts) {
		try {
			return wolWebUtil.verifyText(titleAccLoanStmtsPage, accLoanStmts);
		} catch (Exception e) {
			LogUtility.logException("verifyAccStmtsPage", accLoanStmts + " Page is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Dropdown values
	 */
	public boolean verifyDropdownValues(List<String> Values) {
		try {
			return wolWebUtil.verifyGivenValuesInDropDown(lstDateRange, Values);
		} catch (Exception e) {
			LogUtility.logException("verifyDropdownValues", " Unable to select the values", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify From Date is disabled or not
	 * 
	 */
	public boolean fromDateDisabled() {
		try {
			return webActions.isDisabled(txtFromDate);
		} catch (Exception e) {
			LogUtility.logException("fromDateDisabled", " From date is enabled", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify To Date is disabled or not
	 * 
	 */
	public boolean toDateDisabled() {
		try {
			return webActions.isDisabled(txtToDate);
		} catch (Exception e) {
			LogUtility.logException("toDateDisabled", " To date is enabled", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the From date error message
	 */
	public boolean verifyFromDateErrorMsg(String fromDateErrorMsg) {
		try {
			return wolWebUtil.verifyText(errFromDate, fromDateErrorMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyFromDateErrorMsg", fromDateErrorMsg + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the To date error message
	 */
	public boolean verifyToDateErrorMsg(String toDateErrorMsg) {
		try {
			return wolWebUtil.verifyText(errToDate, toDateErrorMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyToDateErrorMsg", toDateErrorMsg + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To select the Value Not in the Drop down list
	 * 
	 */
	public boolean valueNotInDropdown(String value) {
		try {
			return wolWebUtil.valueNotInList(lstDateRange, value);
		} catch (Exception e) {
			LogUtility.logException("valueNotInDropdown", value + " displayed in drop down list", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Verify the Date Range in the list
	 */

	public boolean verifyDateInRange() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(tablePostedTrans, maxTimeOut);
			boolean transTable = webActions.isDisplayed(tablePostedTrans);
			if (transTable) {
				wolWebUtil.verifyDateIntheList(lblDateValidation, fromDateValue, toDateValue);
				LogUtility.logInfo("--->verifyDateInRange---->", " verifyDateInRangeDate Range verified Successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDateInRange", "Unable to verify date range", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Banner is displayed or not
	 * 
	 * @return
	 */
	public boolean bannerDisplayed() {
		try {
			return webActions.isDisplayed(bannerImage);
		} catch (Exception e) {
			LogUtility.logException("bannerDisplayed", "Banner is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Date Range in the list when select Since Last Statement option
	 */
	public boolean verifyDateInRangeStatement() {
		boolean flag = false;
		try {
			fromDateValue = webActions.getText(txtFromDate);
			toDateValue = webActions.getText(txtToDate);
			boolean transTable = webActions.isDisplayed(tablePostedTrans);
			if (transTable) {
				wolWebUtil.verifyDateIntheList(lblDateValidation, fromDateValue, toDateValue);
				LogUtility.logInfo("---> verifyDateInRangeStatemtnt---->", "Date Range verified Successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDateInRangeStatemtnt", "Unable to verify Date range", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Show Only Drop drown values
	 */
	public boolean verifyValuesInList(List<String> Values) {
		try {
			return wolWebUtil.verifyGivenValuesInDropDown(lstPostTransFilter, Values);
		} catch (Exception e) {
			LogUtility.logException("verifyValuesInList", "Unable to display the values", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Verify the Data in the list
	 */
	public boolean verifyFilterDataInTheList(String filterType) {
		try {
			return verifyDataInTheList(lblFilterValidation, filterType);
		} catch (Exception e) {
			LogUtility.logException("verifyFilterDataInTheList", "Unable to display the values " + filterType, e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Enter Data in the Search bar field
	 */
	public boolean enterValueInSearchBar(String searchBar) {
		boolean flag = false;
		try {
			boolean searchOption = webActions.isDisplayed(txtSearchBar);
			if (searchOption) {
				webActions.setValue(txtSearchBar, searchBar);
				LogUtility.logInfo("--->enterValueInSearchBar<---", "Entered value in Search Bar");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterValueInSearchBar",
					"Unable to enter the " + searchBar + " value in the search bar text box", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To select the Show Only dropdown options
	 */
	public boolean selectTypeFilter(String typeFilter) {
		boolean flag = false;
		try {
			boolean filterType = webActions.isDisplayed(lstPostTransFilter);
			if (filterType) {
				webActions.selectDropDownByText(lstPostTransFilter, typeFilter);
				LogUtility.logInfo("---> selectTypeFilter<---", " Type of filter selected from dropdown");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectTypeFilter", "Unable to select the " + typeFilter, e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To Verify the $ Balance in the list
	 */
	public boolean verifyBalanceInTheList(String balance) {
		try {
			return verifyDataInTheList(lblBalanceValidation, balance);
		} catch (Exception e) {
			LogUtility.logException("verifyBalanceInTheList", balance + " is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the List ,value is present or not
	 * 
	 */
	public boolean verifyDataInTheList(List<WebElement> element, String value) {
		boolean flag = false;
		try {
			for (int values = 1; values < element.size(); values++) {
				String dataValue = ((WebElement) element.get(values)).getText().trim();
				if (dataValue.contains(value) || (dataValue.contains(""))) {
					LogUtility.logInfo("---->verifyDataInTheList<----", "Data is Present in the list");
					flag = true;
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDataInTheList", "Unable to display the values in the list", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on the Enroll/Un-enroll Account from dropdown list
	 */
	public boolean clickOnAccount() {
		boolean flag = false;
		try {
			boolean unEnrollAcc = webActions.isDisplayed(lstSelectAcc);
			if (unEnrollAcc) {
				webActions.clickElement(lstSelectAcc);
				LogUtility.logInfo("---> clickOnAccList <---", "Clicked On AccList");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnUnEnrollAcc", " Unable to click on Account", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on Deposit/Check Withdrawal link and capture the Transaction date,
	 * Transaction Amount
	 */
	public boolean clickOnImageLink(String value) {
		boolean flag = false;
		try {
			if (value.equals("DEPOSIT")) {
				for (int values = 1; values < imageLink.size(); values++) {
					postedTransDesc = ((WebElement) imageLink.get(values)).getText().trim();
					if (postedTransDesc.equals(value)) {
						depositLinkXpath = imgLink1Xpath + (values - 1) + imgLink2Xpath;
						tranDateXpath = imgLink1Xpath + (values - 1) + transDateXpath;
						tranAmtXpath = imgLink1Xpath + (values - 1) + depositAmtXpath;
						transAmtFromList = driver.findElement(By.xpath(tranAmtXpath)).getText().trim();
						transactionDate = driver.findElement(By.xpath(tranDateXpath)).getText().trim();
						dateToStringConvertion();
						WebElement depositLink = driver.findElement(By.xpath(depositLinkXpath));
						boolean depositLinkImage = webActions.isDisplayed(depositLink);
						if (depositLinkImage) {
							webActions.clickElement(depositLink);
							LogUtility.logInfo("--->clickOnImageLink<-----", "Deposit details page displayed");
							flag = true;
							break;
						}
					}
				}
			} else if (value.contains("CHECK NBR")) {
				for (int values = 1; values < imageLink.size(); values++) {
					postedTransDesc = ((WebElement) imageLink.get(values)).getText().trim();
					if (postedTransDesc.contains(value)) {
						withDraLinkXpath = imgLink1Xpath + (values - 1) + imgLink2Xpath;
						tranDateXpath = imgLink1Xpath + (values - 1) + transDateXpath;
						tranAmtXpath = imgLink1Xpath + (values - 1) + withDraAmtXpath;
						transAmtFromList = driver.findElement(By.xpath(tranAmtXpath)).getText().trim();
						transactionDate = driver.findElement(By.xpath(tranDateXpath)).getText().trim();
						dateToStringConvertion();
						WebElement withDrawLink = driver.findElement(By.xpath(withDraLinkXpath));
						boolean withDrawLinkImage = webActions.isDisplayed(withDrawLink);
						if (withDrawLinkImage) {
							webActions.clickElement(withDrawLink);
							LogUtility.logInfo("--->clickOnImageLink<-----", "Check Withdrawal details page displayed");
							flag = true;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnImageLink", " Unable to click on Image link", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Dependent method for clickOnImageLink -- Converted data from Date to String
	 * format
	 */
	public void dateToStringConvertion() {
		try {
			DateFormat formatter = new SimpleDateFormat("MM/dd/yy");
			Date date = (Date) formatter.parse(transactionDate);
			String ModsDate = formatter.format(date);
			String sDate[] = ModsDate.split("/");
			transDateFromList = sDate[0] + "/" + sDate[1] + "/" + "20" + sDate[2];
			LogUtility.logInfo("--->dateToStringConvertion<---", "Date not converted to String");
		} catch (Exception e) {
			LogUtility.logException("dateToStringConvertion", " Unable to convert the date", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * To verify Check number is displayed or not
	 *
	 */
	public boolean verifyCheckNumber() {
		try {
			return wolWebUtil.verifyValueIsNotEmpty(lblChkNumber);
		} catch (Exception e) {
			LogUtility.logException("verifyCheckNumber", " Unable to display the check number", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the View Deposit Details Page Title
	 *
	 */
	public boolean verifyDepositPageTitle(String depositDetails) {
		try {
			return wolWebUtil.verifyText(titleDepositPage, depositDetails);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositPageTitle", depositDetails + "  Page is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the View Deposit Details Message
	 *
	 */
	public boolean verifyDepositDetailsPageMsg(String depositDetailsMsg) {
		try {
			return wolWebUtil.verifyTextContains(msgDepositPage, depositDetailsMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositDetailsPageMsg", depositDetailsMsg + "  message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify Print button is present or not
	 * 
	 */
	public boolean isPrintBtnPresent() {
		try {
			return webActions.isDisplayed(btnPrint);
		} catch (Exception e) {
			LogUtility.logException("isPrintBtnPresent", " Print button is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify Back button is present or not
	 * 
	 */
	public boolean isBackBtnPresent() {
		try {
			return webActions.isDisplayed(btnBackToPreviousPage);
		} catch (Exception e) {
			LogUtility.logException("isPrintBtnPresent", " Back button is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Transaction Amount for Deposit/WithDraw Details
	 *
	 */
	public boolean verifyTransAmt() {
		try {
			return wolWebUtil.verifyText(lblTransAmt, transAmtFromList);
		} catch (Exception e) {
			LogUtility.logException("verifyTransAmt", " Transaction Amount is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Transaction Date for Deposit/WithDraw Details
	 *
	 */
	public boolean verifyTransDate() {
		try {
			return wolWebUtil.verifyText(lblTransDate, transDateFromList);
		} catch (Exception e) {
			LogUtility.logException("verifyTransDate", " Transaction Date is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Click on the Front image, verify the front Image object presented or not
	 * 
	 */
	public boolean isImageFrontSideDisplay() {
		try {
			webActions.clickElement(imgFront);
			// After clicked on FrontSide image link, image loading takes time
			waits.staticWait(2);
			return webActions.isDisplayed(imgEnlargeFront);
		} catch (Exception e) {
			LogUtility.logException("isImageFrontSideDisplay", " Front side image is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the Back image, verify the back Image object presented or not
	 * 
	 */
	public boolean isImageBackSideDisplay() {
		try {
			// After clicked on FrontSide image closed link, image closing takes time
			waits.staticWait(2);
			webActions.clickElement(imgBack);
			// After clicked on BackSide image link, image loading takes time
			waits.staticWait(2);
			return webActions.isDisplayed(imgEnlargeBack);
		} catch (Exception e) {
			LogUtility.logException("isImageBackSideDisplay", " Back side image is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Print icon is presented or not in Front image
	 * 
	 */
	public boolean isPrintIconDisplayFrontImg() {
		try {
			return webActions.isDisplayed(btnPrintOnFrontImage);
		} catch (Exception e) {
			LogUtility.logException("isPrintIconDisplayFrontImg", " Print Icon is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Click on Close button in Front image
	 */
	public boolean clickonCloseBtnFrontImg() {
		boolean flag = false;
		try {
			boolean closeFrontButton = webActions.isDisplayed(btnCloseOnFrontImage);
			if (closeFrontButton) {
				webActions.clickElement(btnCloseOnFrontImage);
				LogUtility.logInfo("---> clickonCloseBtnFrontImg--->", "Close button is clicked");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickonCloseBtnFrontImg", " Close button front side image is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Print icon is presented or not in Back side image
	 * 
	 */
	public boolean isPrintIconDisplayBackSideImg() {
		try {
			return webActions.isDisplayed(btnPrintOnBackImage);
		} catch (Exception e) {
			LogUtility.logException("isPrintIconDisplayBackSideImg", " Close button back side image is not displayed",
					e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on Close button in Back side image
	 */
	public boolean clickonCloseBtnBackSideImg() {
		boolean flag = false;
		try {
			boolean closeBackButton = webActions.isDisplayed(btnCloseOnBackImage);
			if (closeBackButton) {
				webActions.clickElement(btnCloseOnBackImage);
				// After clicked on BackSide image closed link, image closing takes time
				waits.staticWait(2);
				LogUtility.logInfo("--->clickonCloseBtnBackSideImg --->", "Close button is clicked");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickonCloseBtnBackSideImg", " Unable to click on Close button back side image", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on Back to Previous Page button
	 */
	public boolean clickonBackBtn() {
		boolean flag = false;
		try {
			boolean backButton = webActions.isDisplayed(btnBackToPreviousPage);
			if (backButton) {
				webActions.clickElementJS(btnBackToPreviousPage);
				LogUtility.logInfo("---> clickonBackBtn<--- ", "Back button is working");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickonCloseBtnBackSideImg", " Unable to click on Back button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Verify the Account Number format details
	 */
	public boolean verifyAccNumberFormat(String accFormat) {
		try {
			return wolWebUtil.verifyTextContains(lblAccFormatTxt, accFormat);
		} catch (Exception e) {
			LogUtility.logException("verifyAccNumberFormat", accFormat + " number not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Verify the Check Withdrawal details page title
	 */
	public boolean verifyChkWithDrawalMsg(String chkWithDrawalMsg) {
		try {
			return wolWebUtil.verifyText(titleChkWithDrawal, chkWithDrawalMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyChkWithDrawalMsg", chkWithDrawalMsg + " Page is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Account details in the transaction table
	 *
	 */
	public boolean verifyAccDetails(String accNumber) {
		try {
			return wolWebUtil.verifyTextContains(lblAccNumber, accNumber);
		} catch (Exception e) {
			LogUtility.logException("verifyAccDetails", accNumber + " number is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Transaction Balance in the transaction table
	 *
	 */
	public boolean verifyTrnBalance(String trnAmount) {
		try {
			return wolWebUtil.verifyTextContains(lblTrnAmount, trnAmount);
		} catch (Exception e) {
			LogUtility.logException("verifyTrnBalance", trnAmount + " amount is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To retrieve the Transaction details in the transaction table
	 *
	 */
	public boolean retrieveTrnDetails() {
		boolean flag = false;
		try {
			boolean transTable = webActions.isDisplayed(lblTrnDetails);
			if (transTable) {
				wolWebUtil.getTableValues(lblTrnDetails);
				LogUtility.logInfo("---->retrieveTrnDetails<----", "Transaction Details Displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("retrieveTrnDetails", " Transction details not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To click on Action Menu, Deposit Details Page displayed
	 *
	 */
	public boolean clickOnActionMenu(String value) {
		boolean flag = false;
		try {
			for (int values = 1; values < imageLink.size(); values++) {
				postedTransDesc = ((WebElement) imageLink.get(values)).getText().trim();
				if (postedTransDesc.equals(value)) {
					depositLinkXpath = imgLink1Xpath + (values - 1) + imgLink2Xpath;
					tranDateXpath = imgLink1Xpath + (values - 1) + transDateXpath;
					tranAmtXpath = imgLink1Xpath + (values - 1) + depositAmtXpath;
					transAmtFromList = driver.findElement(By.xpath(tranAmtXpath)).getText().trim();
					transactionDate = driver.findElement(By.xpath(tranDateXpath)).getText().trim();
					dateToStringConvertion();
					actionMenuXpath = depositLinkXpath + "/following::h1";
					viewDetailsXpath = depositLinkXpath + "/following::a[contains(.,'View Details')]";
					driver.findElement(By.xpath(actionMenuXpath)).click();
					WebElement viewDetails = driver.findElement(By.xpath(viewDetailsXpath));
					boolean viewDetailsPage = webActions.isDisplayed(viewDetails);
					if (viewDetailsPage) {
						driver.findElement(By.xpath(viewDetailsXpath)).click();
						LogUtility.logInfo("--->clickOnActionMenu<----", "Deposit details page displayed");
						flag = true;
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnActionMenu", " Unable to click on Action menu", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To get the from date and To date
	 */
	public boolean captureFrmDateTodate() {
		boolean flag = false;
		try {
			fromDateValue = webActions.getText(txtFromDate);
			boolean toDate = webActions.isDisplayed(txtToDate);
			if (toDate) {
				toDateValue = webActions.getText(txtToDate);
				LogUtility.logInfo("--->getFrmDateTodate---->", "Captured From Date and To Dates");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("captureFrmDateTodate", " Unable to captured From and To date", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on the Advance Search button in Transaction History page
	 */
	public boolean clickOnAdvSearch() {
		boolean flag = false;
		try {
			boolean advanceSearch = webActions.isDisplayed(btnAdvSearch);
			if (advanceSearch) {
				webActions.clickElement(btnAdvSearch);
				LogUtility.logInfo("--->clickOnAdvSearch<----", "Clicked on Advance Search button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnAdvSearch", " Unable to click on Advance search button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Verify the Webster Account from Accounts list
	 */
	public boolean verifyDefaultAccFrmDropDown(String account) {
		boolean flag = false;
		try {
			String getAccount = wolWebUtil.getDefaultValueForSelect(cmbAccSelect);
			if (account.contains(getAccount) || (getAccount.contains(account)))
				flag = true;
			LogUtility.logInfo("---> verifyDefaultAccFrmDropDown---->", "Default Account not selected");
		} catch (Exception e) {
			LogUtility.logException("verifyDefaultAccFrmDropDown", account + " number is not selected", e,
					LoggingLevel.ERROR, true);
			return flag;
		}
		return flag;
	}

	/**
	 * Verify the Transaction Type from the list
	 */
	public boolean verifyDefaultTranTypeFrmDropDown(String option) {
		boolean flag = false;
		try {
			String getTrnType = wolWebUtil.getDefaultValueForSelect(cmbTrnTypeAdvSearch);
			if (option.equals(getTrnType))
				flag = true;
			LogUtility.logInfo("--->verifyDefaultTranTypeFrmDropDown---->", " Default Transaction matched");
		} catch (Exception e) {
			LogUtility.logException("verifyDefaultTranTypeFrmDropDown", option + " Transaction type is not displayed",
					e, LoggingLevel.ERROR, true);
			return flag;
		}
		return flag;
	}

	/**
	 * Verify the From date and To date in Advance Search
	 */
	public boolean verifyFrmToDates() {
		boolean flag = false;
		try {
			String fromDateAdvSrch = webActions.getText(txtFromDateAdvSearch);
			String toDateAdvSrch = webActions.getText(txtToDateAdvSearch);
			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date frmDate = (Date) formatter.parse(fromDateAdvSrch);
			String frmDateVal = formatter.format(frmDate);
			Date toDate = (Date) formatter.parse(toDateAdvSrch);
			String toDateVal = formatter.format(toDate);
			if (frmDateVal.equals(fromDateAdvSrch) && (toDateVal.equals(toDateAdvSrch)))
				flag = true;
			LogUtility.logInfo("--->verifyFrmToDates---->", "From and To dates matched");
		} catch (Exception e) {
			LogUtility.logException("verifyFrmToDates", " Unable to verify from and to dates", e, LoggingLevel.ERROR,
					true);
			return flag;
		}
		return flag;
	}

	/**
	 * To verify the Account number in the Transaction History page
	 *
	 */
	public boolean verifyAccNumber(String accNumber) {
		try {
			return wolWebUtil.verifyTextContains(lstSelectAcc, accNumber);
		} catch (Exception e) {
			LogUtility.logException("verifyAccNumber", accNumber + " number is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To capture the Posted Transaction details are displayed or not in the
	 * transaction table
	 *
	 */

	public String capturePostedTransDetails() {
		try {
			postedTransDetails = webActions.getText(lblPostedTransDate);
			LogUtility.logInfo("---->verifyPostedTransDetails<----", "Transaction details displayed");
		} catch (Exception e) {
			postedTransDetails = webActions.getText(msgNoPostedTrans);
			LogUtility.logInfo("---->verifyPostedTransDetails<----", "Transaction details not displayed");
		}
		return postedTransDetails;
	}

	/**
	 * To verify the Posted Transaction details are displayed or not in the
	 * transaction table
	 *
	 */

	public boolean verifyPostedTransDetails(String noTransMessage) {
		boolean flag = false;
		capturePostedTransDetails();
		try {
			try {
				String transDate = webActions.getText(lblPostedTransDate);
				if (postedTransDetails.equals(transDate)) {
					flag = true;
					LogUtility.logInfo("---->verifyPostedTransDetails<----", "Transaction details displayed");
				}
			} catch (Exception e) {
				if (postedTransDetails.equals(noTransMessage)) {
					flag = true;
					LogUtility.logInfo("---->verifyPostedTransDetails<----",
							"No transaction details message displayed");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPostedTransDetails", noTransMessage + " message is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Date range field is active or not in Transaction History page
	 */
	public boolean verifyDateRangeField() {
		boolean flag = false;
		try {
			boolean dateRange = webActions.isEnabled(lstDateRange);
			if (dateRange) {
				LogUtility.logInfo("---> verifyDateRangeField <---", "Date Range field should be active");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDateRangeField", " Date Range field is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To click on the From Date Calendar Icon in Transaction History page
	 */
	public boolean clickOnFromDateCalendarIcon() {
		boolean flag = false;
		try {
			boolean fromDateCalendarIcon = webActions.isDisplayed(btnFromDateCalendar);
			if (fromDateCalendarIcon) {
				webActions.clickElement(btnFromDateCalendar);
				LogUtility.logInfo("--->clickOnFromDateCalendarIcon<----", "Clicked on From Date Calendar Icon");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnFromDateCalendarIcon", " Unable to click on From date calendar icon", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on the To Date Calendar Icon in Transaction History page
	 */
	public boolean clickOnToDateCalendarIcon() {
		boolean flag = false;
		try {
			boolean toDateCalendarIcon = webActions.isDisplayed(btnToDateCalendar);
			if (toDateCalendarIcon) {
				webActions.clickElement(btnToDateCalendar);
				LogUtility.logInfo("--->clickOnToDateCalendarIcon<----", "Clicked on To Date Calendar Icon");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnToDateCalendarIcon", " Unable to click on To date calendar icon", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the From Date Calendar Icon in Transaction History page
	 *
	 */
	public boolean verifyFromDateCalendarIcon() {
		boolean flag = false;
		try {
			boolean fromDateCalendarIcon = webActions.isDisplayed(iconFromDateCalendar);
			if (fromDateCalendarIcon) {
				LogUtility.logInfo("---->verifyFromDateCalendarIcon<----", "From Date Calendar Icon displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyFromDateCalendarIcon", " From date calendar icon is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the To Date Calendar Icon in Transaction History page
	 *
	 */
	public boolean verifyToDateCalendarIcon() {
		boolean flag = false;
		try {
			boolean toDateCalendarIcon = webActions.isDisplayed(iconToDateCalendar);
			if (toDateCalendarIcon) {
				LogUtility.logInfo("---->verifyToDateCalendarIcon<----", "To Date Calendar Icon displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyToDateCalendarIcon", " To date calendar icon is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Search Text box should be displayed
	 *
	 */
	public boolean verifySearchTextBox() {
		boolean flag = false;
		try {
			boolean searchTextBox = webActions.isDisplayed(txtFilterByText);
			if (searchTextBox) {
				LogUtility.logInfo("---->verifySearchTextBox<----", "Search Text Box displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySearchTextBox", " Search text box is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Deposit Text description
	 *
	 */
	public boolean verifyTextDescription(String description) {
		try {
			return wolWebUtil.verifyText(lblDescription, description);
		} catch (Exception e) {
			LogUtility.logException("verifyTextDescription", description + "  text is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Transaction Amount
	 *
	 */
	public boolean verifyTransAmtInTable() {
		try {
			return wolWebUtil.verifyText(lblAmount, transAmtFromList);
		} catch (Exception e) {
			LogUtility.logException("verifyTransAmt", "Transaction amount is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Enter Transaction Amount in Search text box
	 *
	 */
	public String enterTransactionAmount() {
		try {
			webActions.setValue(txtFilterByText, transAmtFromList);
			LogUtility.logInfo("--->enterTransactionAmount<---", " Transaction Amount entered ");
		} catch (Exception e) {
			LogUtility.logException("enterTransactionAmount", "Transaction amount is not entered", e,
					LoggingLevel.ERROR, true);
		}
		return transAmtFromList;
	}

	/**
	 * To verify the Enroll Account Deposit details message
	 *
	 */
	public boolean verifyEnrollAccDepositText(String depositMsg) {
		try {
			return wolWebUtil.verifyTextContains(msgEnrollDepositDetails, depositMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyEnrollAccDepositText", depositMsg + " text is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Click on the Deposit Front image, verify the front Image object presented
	 * or not
	 * 
	 */
	public boolean isDepositImageFrontSideDisplay() {
		try {
			webActions.clickElement(imgFrontDeposit);
			// After clicked on FrontSide image link, image loading takes time
			waits.staticWait(2);
			return webActions.isDisplayed(imgFrontEnlargeDeposit);
		} catch (Exception e) {
			LogUtility.logException("isDepositImageFrontSideDisplay", " Front side image is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the empty table should display
	 * 
	 */
	public boolean verifyEmptyTable() {
		boolean flag = false;
		try {
			boolean emptyTable = webActions.isDisplayed(tableEmptyMesssage);
			if (emptyTable) {
				LogUtility.logInfo("---->verifyEmptyTable<----", "Empty Table displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterInvalidTransactionAmount", " Unable to display empty table", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Enter Invalid Transaction Amount in Search text box
	 *
	 */
	public boolean enterInvalidTransactionAmount(String transAmount) {
		boolean flag = false;
		try {
			boolean invalidAmount = webActions.isDisplayed(txtFilterByText);
			if (invalidAmount) {
				webActions.setValue(txtFilterByText, transAmount);
				LogUtility.logInfo("--->enterInvalidTransactionAmount<---", " Transaction Amount entered ");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterInvalidTransactionAmount", " Unable to enter Transaction amount", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on Opt in to View Deposit Details Icon
	 * 
	 */
	public boolean clickOnOptInDepositDetailsIcon() {
		boolean flag = false;
		try {
			boolean depositIcon = webActions.isDisplayed(lnkOptInDepositDetails);
			if (depositIcon) {
				webActions.clickElement(lnkOptInDepositDetails);
				LogUtility.logInfo("--->clickOnOptInDepositDetailsIcon<---", " Clicked On View Deposit Details Icon");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnOptInDepositDetailsIcon", " Unable to click on Deposit details icon", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on Opt Out to View Deposit Details Icon
	 * 
	 */
	public boolean clickOnOptOutDepositDetailsIcon() {
		boolean flag = false;
		try {
			boolean depositIcon = webActions.isDisplayed(lnkOptOutDepositDetails);
			if (depositIcon) {
				webActions.clickElement(lnkOptOutDepositDetails);
				LogUtility.logInfo("--->clickOnOptOutDepositDetailsIcon<---", " Clicked On View Deposit Details Icon");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnOptOutDepositDetailsIcon", " Unable to click on Deposit details icon ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To get the Statement Date range
	 * 
	 */
	public String captureStmtDateRange() {
		try {
			boolean listDateRange = webActions.isDisplayed(lstDateRange);
			if (listDateRange) {
				dateRange = wolWebUtil.getDefaultValueForSelect(lstDateRange);
				setValueInRuntimeDataMap("dateRangeKey", dateRange);
				LogUtility.logInfo("--->captureStmtDateRange<---", " Captured Statement Date Range");
			}
		} catch (Exception e) {
			LogUtility.logException("captureStmtDateRange", " Unable to capture Statement Date Range ", e,
					LoggingLevel.ERROR, true);
		}
		return dateRange;
	}

	/**
	 * To Click on Back to Previous Page button in Check Image - Front and Back Page
	 */
	public boolean clickOnBackToPreviousPageButton() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(btnBack, maxTimeOut);
			boolean backButton = webActions.isDisplayed(btnBack);
			if (backButton) {
				webActions.clickElement(btnBack);
				LogUtility.logInfo("---> clickOnBackToPreviousPageButton<--- ", "Back button is working");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnBackToPreviousPageButton", " Unable to click on Back button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Available balance
	 */
	public String verifyAvailableBalance() {
		try {
			availableBalance = webActions.getText(lblAvailableBalance);
			if (availableBalance.contains("$"))
				LogUtility.logInfo("---> verifyAvailableBalance<--- ", "Available Balance displayed");
		} catch (Exception e) {
			LogUtility.logException("verifyAvailableBalance", "Unable to display the balance", e, LoggingLevel.ERROR,
					true);
		}
		return availableBalance;
	}

	/**
	 * To verify the Print Icon is displayed
	 */
	public boolean verifyPrintTransactionIcon() {
		boolean flag = false;
		try {
			boolean printButton = webActions.isDisplayed(iconPrintTransaction);
			if (printButton) {
				LogUtility.logInfo("---> verifyPrintTransactionIcon<--- ", "Print Icon is displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPrintTransactionIcon", " Unable to display Print Icon", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Back to Top button displayed
	 */
	public boolean verifyBackToTopButton() {
		boolean flag = false;
		try {
			boolean printButton = webActions.isDisplayed(btnBackToTop);
			if (printButton) {
				LogUtility.logInfo("---> verifyBackToTopButton<--- ", "Back to Top button is displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyBackToTopButton", " Unable to display Back to Top button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * 
	 * To verify the Posted Transaction Table column names
	 * 
	 */

	public boolean verifyPostedTransTableHeaders(List<String> listValue) {
		try {
			waits.waitUntilElementIsPresent(tblPostedTransactionsHeaders, maxTimeOut);
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblPostedTransactionsHeaders, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyPostedTransTableHeaders", "Unable to display the values", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the Advance Search Button displayed
	 */
	public boolean verifyAdvanceSearchButton() {
		boolean flag = false;
		try {
			boolean advanceSearchButton = webActions.isDisplayed(btnAdvSearch);
			if (advanceSearchButton) {
				LogUtility.logInfo("---> verifyAdvanceSearchButton<--- ", "Advance Search button is displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAdvanceSearchButton", " Unable to display Advance Search button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * 
	 * To verify the Posted Transaction Table column values
	 * 
	 */

	public boolean verifyPostedTransTableValues(List<String> listValue) {
		try {
			return wolWebUtil.verifyColumnNamesInHeaderLess(tblPostedTransactionsValues, listValue);
		} catch (Exception e) {
			LogUtility.logException("verifyPostedTransTableHeaders", "Unable to display the values", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify Print button is present or not for View deposit details page
	 * 
	 */
	public boolean verifyPrintButton() {
		try {
			return webActions.isDisplayed(btnPrintViewDeposit);
		} catch (Exception e) {
			LogUtility.logException("verifyPrintButton", " Print button is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify Back button is present or not for View deposit details page
	 * 
	 */
	public boolean verifyBackButton() {
		try {
			return webActions.isDisplayed(btnBack);
		} catch (Exception e) {
			LogUtility.logException("verifyBackButton", " Back button is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Account Number format in details page
	 */
	public boolean verifyAccountNumber(String accFormat) {
		try {
			return wolWebUtil.verifyTextContains(txtAccFormat, accFormat);
		} catch (Exception e) {
			LogUtility.logException("verifyAccountNumber", accFormat + " number not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Transaction Date for Deposit Details page
	 *
	 */
	public boolean verifyTransactionDate() {
		try {
			return wolWebUtil.verifyText(lblTransactionDate, transDateFromList);
		} catch (Exception e) {
			LogUtility.logException("verifyTransactionDate", " Transaction Date is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Transaction Amount for Deposit Details page
	 *
	 */
	public boolean verifyTransactionAmt() {
		try {
			return wolWebUtil.verifyText(lblTransactionAmt, transAmtFromList);
		} catch (Exception e) {
			LogUtility.logException("verifyTransactionAmt", " Transaction Amount is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To click on Deposit/Check Withdrawal link and capture the Transaction date,
	 * Transaction Amount
	 */
	public boolean clickOnDuplicateImagesLink(String value1, String value2) {
		boolean flag = false;
		try {
			if (value1.equals("CASH")) {
				if (value2.equals("First")) {
					duplicateTransAmount = webActions.getText(lblFirstTransactionAmt).trim();
					String date[] = webActions.getText(lblFirstTransactionDate).trim().split(" ");
					duplicateTransDate = date[0];
					if (duplicateTransAmount.equals(jsonDataParser.getTestDataMap().get("TransAmount"))
							&& duplicateTransDate.equals(jsonDataParser.getTestDataMap().get("TransDate"))) {
						boolean depositLinkImage = webActions.isDisplayed(lblFirstTransactionIcon);
						if (depositLinkImage) {
							webActions.clickElement(lblFirstTransactionIcon);
							LogUtility.logInfo("--->clickOnDuplicateImagesLink<-----",
									"Deposit details page displayed");
							flag = true;
						}
					}
				} else if (value2.equals("Duplicate")) {
					duplicateTransAmount = webActions.getText(lblSecondTransactionAmt).trim();
					duplicateTransDate = webActions.getText(lblSecondTransactionDate).trim();
					String date[] = webActions.getText(lblSecondTransactionDate).trim().split(" ");
					duplicateTransDate = date[0];
					if (duplicateTransAmount.equals(jsonDataParser.getTestDataMap().get("TransAmount"))
							&& duplicateTransDate.equals(jsonDataParser.getTestDataMap().get("TransDate"))) {
						boolean depositLinkImage = webActions.isDisplayed(lblSecondTransactionIcon);
						if (depositLinkImage) {
							webActions.clickElement(lblSecondTransactionIcon);
							LogUtility.logInfo("--->clickOnDuplicateImagesLink<-----",
									"Deposit details page displayed");
							flag = true;
						}
					}
				}
			} else if (value1.equals("CHECK")) {
				if (value2.equals("First")) {
					duplicateTransAmount = webActions.getText(lblThirdTransactionAmt).trim();
					String date[] = webActions.getText(lblThirdTransactionDate).trim().split(" ");
					duplicateTransDate = date[0];
					if (duplicateTransAmount.equals(jsonDataParser.getTestDataMap().get("TransAmount"))
							&& duplicateTransDate.equals(jsonDataParser.getTestDataMap().get("TransDate"))) {
						boolean depositLinkImage = webActions.isDisplayed(lblThirdTransactionIcon);
						if (depositLinkImage) {
							webActions.clickElement(lblThirdTransactionIcon);
							LogUtility.logInfo("--->clickOnDuplicateImagesLink<-----",
									"Deposit details page displayed");
							flag = true;
						}
					}
				} else if (value2.equals("Duplicate")) {
					duplicateTransAmount = webActions.getText(lblFourthTransactionAmt).trim();
					duplicateTransDate = webActions.getText(lblFourthTransactionDate).trim();
					String date[] = webActions.getText(lblFourthTransactionDate).trim().split(" ");
					duplicateTransDate = date[0];
					if (duplicateTransAmount.equals(jsonDataParser.getTestDataMap().get("TransAmount"))
							&& duplicateTransDate.equals(jsonDataParser.getTestDataMap().get("TransDate"))) {
						boolean depositLinkImage = webActions.isDisplayed(lblFourthTransactionIcon);
						if (depositLinkImage) {
							webActions.clickElement(lblFourthTransactionIcon);
							LogUtility.logInfo("--->clickOnDuplicateImagesLink<-----",
									"Deposit details page displayed");
							flag = true;
						}
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnImageLink", " Unable to click on Image link", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Duplicate Transaction Amount for Deposit/WithDraw Details
	 *
	 */
	public boolean verifyDuplicateTransAmt() {
		try {
			return wolWebUtil.verifyText(lblTransAmt, duplicateTransAmount);
		} catch (Exception e) {
			LogUtility.logException("verifyDuplicateTransAmt", " Transaction Amount is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Duplicate Transaction Date for Deposit/WithDraw Details
	 *
	 */
	public boolean verifyDuplicateTransDate() {
		try {
			return wolWebUtil.verifyText(lblTransDate, testDataMap.get("FromToDate"));
		} catch (Exception e) {
			LogUtility.logException("verifyDuplicateTransDate", " Transaction Date is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Duplicate Account Number format details
	 */
	public boolean verifyDuplicateAccNumber() {
		try {
			return wolWebUtil.verifyTextContains(lblAccFormatTxt, testDataMap.get("Account"));
		} catch (Exception e) {
			LogUtility.logException("verifyDuplicateAccNumber", " Account number not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To enter the Transaction From date
	 *
	 */
	public boolean enterTransFromDate() {
		boolean flag = false;
		try {
			boolean fromDate = webActions.isDisplayed(txtFromDate);
			if (fromDate) {
				webActions.setValue(txtFromDate, jsonDataParser.getTestDataMap().get("FromToDate"));
				LogUtility.logInfo("--->enterTransFromDate<---", " From Date entered ");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterTransFromDate", "Unable to enter from date", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To enter the Transaction To date
	 *
	 */
	public boolean enterTransToDate() {
		boolean flag = false;
		try {
			boolean toDate = webActions.isDisplayed(txtToDate);
			if (toDate) {
				webActions.setValue(txtToDate, jsonDataParser.getTestDataMap().get("FromToDate"));
				LogUtility.logInfo("--->enterTransToDate<---", " To Date entered ");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("enterTransToDate", "Unable to enter to date", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on the Deposit Back image, verify the back Image object presented or
	 * not
	 * 
	 */
	public boolean isDepositImageBackSideDisplay() {
		try {
			webActions.clickElementJS(imgBackDeposit);
			waits.waitUntilElementIsPresent(imgBackEnlargeDeposit, maxTimeOut);
			return webActions.isDisplayed(imgBackEnlargeDeposit);
		} catch (Exception e) {
			LogUtility.logException("isDepositImageBackSideDisplay", " Back side image is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Deposit Ticket is not present
	 */
	public boolean depositTicketNotPresent() {
		try {
			return wolWebUtil.elementNotDisplay(lblPostedTransImg);
		} catch (Exception e) {
			LogUtility.logException("depositTicketNotPresent", " Deposit Ticket is not present", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Click on More Transactions button
	 * 
	 */
	public boolean clickOnMoreTransactions() {
		boolean flag = false;
		try {
			boolean moreTrans = webActions.isDisplayed(btnMoreTransactions);
			if (moreTrans) {
				webActions.clickElement(btnMoreTransactions);
				LogUtility.logInfo("--->clickOnMoreTransactions<---", " Clicked On More transactions button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnMoreTransactions", " Unable to click On More transactions button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on Check Image Icon
	 * 
	 */
	public boolean clickOnCheckImageIcon() {
		boolean flag = false;
		try {
			webActions.clickElementJS(lnkCheckImageIcon);
			// After clicked on Check image link, image loading takes time
			waits.staticWait(2);
			return webActions.isDisplayed(imgCheckImgEnlarge);
		} catch (Exception e) {
			LogUtility.logException("clickOnCheckImageIcon", " Unable to click On Check Image Icon", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Check image Print button is present or not
	 * 
	 */
	public boolean checkImagePrintButton() {
		try {
			return webActions.isDisplayed(btnChkImagePrint);
		} catch (Exception e) {
			LogUtility.logException("checkImagePrintButton", " Print button is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Sort By options should display
	 */

	public boolean verifySortByOptions() {
		boolean flag = false;
		try {
			int count = 0;
			String[] list = jsonDataParser.getTestDataMap().get("SortByOptions").split(";");
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(lstSortingValues, maxTimeOut);
			for (String eachOption : list) {
				if (wolWebUtil.verifyListValues(lstSortingValues, eachOption)) {
					count = count + 1;
				}
			}
			if (count == list.length) {
				LogUtility.logInfo("--->verifySortByOptions<---", "Sort By options were present in the list");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifySortByOptions", " Sort By options were not present in the list", e,
					LoggingLevel.ERROR, true);
			return false;
		}
		return flag;
	}

	/**
	 * To verify the values in ascending order
	 */

	public boolean verifyValuesInAscendingOrder(List<WebElement> element) {
		try {
			float x = 0;
			String fieldValue = "";
			int size = element.size();
			int count = 0;
			float list[] = new float[size];
			List<Float> originalListValues = new ArrayList<>();
			List<Float> sortedListValues = new ArrayList<>();

			for (int value = 0; value < size; value++) {
				fieldValue = webActions.getText(element.get(value));
				fieldValue = fieldValue.replace("$", "");
				fieldValue = fieldValue.replace("-", "");
				fieldValue = fieldValue.replace(",", "");

				x = Float.parseFloat(fieldValue);
				list[value] = x;
				originalListValues.add(x);
				sortedListValues.add(x);
			}
			Collections.sort(sortedListValues);

			for (int value = 0; value < size; value++) {
				if (originalListValues.get(value).equals(sortedListValues.get(value))) {
					count = count + 1;
				} else {
					LogUtility.logInfo("--->verifyValuesInAscendingOrder<---",
							"Values are not displayed in Ascending order");
					return false;
				}
			}
			if (count == size) {
				LogUtility.logInfo("--->verifyValuesInAscendingOrder<---", "Values are displayed in Ascending order");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyValuesInAscendingOrder", "Values are not displayed in Ascending order", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To verify the values in Descending order
	 */

	public boolean verifyValuesIDescendingOrder(List<WebElement> element) {
		try {
			float x = 0;
			String fieldValue = "";
			int size = element.size();
			int count = 0;
			float list[] = new float[size];
			List<Float> originalListValues = new ArrayList<>();
			List<Float> sortedListValues = new ArrayList<>();

			for (int value = 0; value < size; value++) {
				fieldValue = webActions.getText(element.get(value));
				fieldValue = fieldValue.replace("$", "");
				fieldValue = fieldValue.replace("-", "");
				fieldValue = fieldValue.replace(",", "");

				x = Float.parseFloat(fieldValue);
				list[value] = x;
				originalListValues.add(x);
				sortedListValues.add(x);
			}
			Collections.sort(sortedListValues);
			Collections.reverse(sortedListValues);

			for (int value = 0; value < size; value++) {
				if (originalListValues.get(value).equals(sortedListValues.get(value))) {
					count = count + 1;
				} else {
					LogUtility.logInfo("--->verifyValuesIDescendingOrder<---",
							"Values are not displayed in Descending order");
					return false;
				}
			}
			if (count == size) {
				LogUtility.logInfo("--->verifyValuesIDescendingOrder<---", "Values are displayed in Descending order");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyValuesIDescendingOrder", "Values are not displayed in Descending order", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * To select the Sort by value from dropdown
	 */

	public boolean selectSortedValue(String option) {
		boolean flag = false;
		try {
			boolean options = webActions.isDisplayed(lstSortingValues);
			if (options) {
				wolWebUtil.selectValueByPartialVisibleText(lstSortingValues, option);
				LogUtility.logInfo("---> selectSortedValue <---", "Sorted value selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectSortedValue", "Unable to select the Sorted value", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To verify the Deposits/Withdrawals Ascending order
	 */

	public boolean verifySortingOrder(String paymentType, String order) {
		try {
			if (paymentType.equals("Withdrawals")) {
				if (order.equals("Ascending")) {
					return verifyValuesInAscendingOrder(lblWithdrawalAmounts);
				} else if (order.equals("Descending")) {
					return verifyValuesIDescendingOrder(lblWithdrawalAmounts);
				}
			} else if (paymentType.equals("Deposits")) {
				if (order.equals("Ascending")) {
					return verifyValuesInAscendingOrder(lblDepositAmounts);
				} else if (order.equals("Descending")) {
					return verifyValuesIDescendingOrder(lblDepositAmounts);
				}
			} else if (paymentType.equals("TransAmount")) {
				if (order.equals("Ascending")) {
					return verifyValuesInAscendingOrder(lblTransAmounts);
				} else if (order.equals("Descending")) {
					return verifyValuesIDescendingOrder(lblTransAmounts);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifySortingOrder", " Unable to display sorting order", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

}
