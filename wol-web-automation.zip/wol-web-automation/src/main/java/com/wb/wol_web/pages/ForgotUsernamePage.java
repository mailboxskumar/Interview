package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class ForgotUsernamePage extends ObjectBase {

	public String user;
	public String question1;
	public String question2;

	public ForgotUsernamePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),'User Name?')]")
	protected WebElement lnkForgotUsername;

	@FindBy(xpath = "//a[contains(text(),'Password?')]")
	protected WebElement lnkForgotPassword;

	@FindBy(id = "ssn__input")
	protected WebElement txtSSN;

	@FindBy(id = "acctNumber__input")
	protected WebElement txtAcctNumber;

	@FindBy(id = "selectedChannel__personal__input")
	protected WebElement rdbtnPersonal;

	@FindBy(id = "selectedChannel__business__input")
	protected WebElement rdbtnBusiness;

	@FindBy(id = "ssn__error-message-text")
	protected WebElement txtSSNErr;

	@FindBy(id = "acctNumber__error-message-text")
	protected WebElement txtAcctNumErr;

	@FindBy(xpath = "//span[contains(text(),'Continue')]")
	protected WebElement btnContinue;

	@FindBy(xpath = "//a[text()='No']")
	protected WebElement btnNo;

	@FindBy(xpath = "//a[text()='Yes']")
	protected WebElement btnYes;

	@FindBy(xpath = "//a[contains(text(),'Cancel')]")
	protected WebElement btnCancel;

	@FindBy(id = "transactionCancelMessage")
	protected WebElement txtCancelMsg;

	@FindBy(xpath = "(//button[text()='Close'])[2]")
	protected WebElement btnClose;

	@FindBy(id = "answer__input")
	protected WebElement txtAnswer;

	@FindBy(xpath = "//*[@id ='answer__error-message-text' or @id='login-error-rsa-wol-locked-subsequent.pageError__body' or @id ='login-auth-error.pageError__body' or @id ='login-password-reset__pageErrors_gen__login__err__resetPass__body' or @id ='login-error-rsa-wol-locked.pageError__body']")
	protected WebElement txtAnswerErr;

	@FindBy(xpath = "//div[contains(@id,'error.pageError__body')]")
	protected WebElement txtUserErr;

	@FindBy(id = "returnHome__link")
	protected WebElement lnkReturn;

	@FindBy(id = "nextStepsReturn__link")
	protected WebElement lnkNextStepReturn;

	@FindBy(id = "nextStepsResetPassword__link")
	protected WebElement lnkNextStepResetPwd;

	@FindBy(id = "req-username-success__pageAffirmativeNotice_gen__body")
	protected WebElement txtCnfrmMsg;

	@FindBy(xpath = "//span[@id='username__display']//span")
	protected WebElement txtUserValue;

	@FindBy(xpath = "//h1[contains(text(),'User') or contains(text(),'Sign' ) or contains(text(),'Reset')]")
	protected WebElement txtPageTitle;

	@FindBy(xpath = "//div[contains(@id,'error__unp__body')]")
	protected WebElement txtSignInErrMsg;

	@FindBy(id = "retryLogin__link")
	protected WebElement lnkStartAgain;

	@FindBy(id = "answer__label")
	protected WebElement txtChallengeQuestion;

	@FindBy(xpath = "//div[contains(@id,'sername-error') or contains(@id,'login-password-reset-auth-error--weblink.pageError__body') or contains(@id,'sername__error')]")
	protected WebElement txtUsernameErr;

	@FindBy(xpath = "//label[@id='answer__label']")
	protected WebElement txtChallengeQuestion1;

	@FindBy(id = "fieldUsername__input")
	protected WebElement txtUsernameField;

	public boolean requestUsernameDetails(Map<String, String> userDetails) {
		boolean flag = false;
		try {
			if (userDetails.get("UserType").equals("Personal")) {
				waits.waitUntilElementIsPresent(rdbtnPersonal);
				webActions.clickElement(rdbtnPersonal);
			} else if (userDetails.get("UserType").equals("Business")) {
				waits.waitUntilElementIsPresent(rdbtnBusiness);
				webActions.clickElement(rdbtnBusiness);
			}
			String ssn = userDetails.get("SSN");
			webActions.setValue(txtSSN, ssn);
			webActions.setValue(txtAcctNumber, userDetails.get("Acct Number"));
			waits.waitForDOMready();
			String actualSSN = webActions.getAttributeValue(txtSSN, "value");
			actualSSN = actualSSN.replaceAll("-", "");
			if (actualSSN.contains(ssn)) {
				flag = true;
				LogUtility.logInfo("requestUsernameDetails", "Entered request username details");
			}
		} catch (Exception e) {
			LogUtility.logException("requestUsernameDetails", "Failed to Enter request username details", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * clickContinueButton: To click on continue button among Request User Name
	 * pages
	 */
	public void clickContinueButton() {
		try {
			waits.waitUntilElementIsPresent(btnContinue);
			webActions.clickElement(btnContinue);
			LogUtility.logInfo("clickContinueButton", "Clicked on Continue Button in Request Username Page");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton",
					"Failed to Click on Continue Button in Request Username Page", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickCancelButton: To click on cancel button among Request User Name pages
	 */
	public void clickCancelButton() {
		try {
			waits.waitUntilElementIsPresent(btnCancel);
			webActions.clickElement(btnCancel);
			LogUtility.logInfo("clickCancelButton", "Clicked on cancel Button in Request User Name Page");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to Click on Cancel Button in Request Username Page",
					e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * clickNoButton: To click on no button among Request User Name pages
	 */
	public void clickNoButton() {
		try {
			waits.waitUntilElementIsPresent(btnNo);
			webActions.clickElement(btnNo);
			LogUtility.logInfo("clickNoButton", "Clicked on no Button in Pending Transfers Page");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to Click on No Button in Request Username Page", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickYesButton: To click on yes button among Request User Name pages
	 */
	public void clickYesButton() {
		try {
			waits.waitUntilElementIsPresent(btnYes);
			webActions.clickElement(btnYes);
			LogUtility.logInfo("clickYesButton", "Clicked on yes Button in Request User Name Page");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to Click on Yes Button in Request Username Page", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickCloseButton: To click on yes button among Request User Name pages
	 */
	public void clickCloseButton() {
		try {
			waits.waitUntilElementIsPresent(btnClose);
			webActions.clickElement(btnClose);
			LogUtility.logInfo("clickCloseButton", "Clicked on close Button in Request User Name Page");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to Click on Close Button in Request Username Page",
					e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickForgotUsernameLink: To click on Forgot User name Link
	 */
	public void clickForgotUsernameLink() {
		try {
			waits.waitUntilElementIsPresent(lnkForgotUsername, maxTimeOut);
			webActions.clickElement(lnkForgotUsername);
			waits.staticWait(2); // To load next page taking time
			LogUtility.logInfo("clickForgotUsernameLink", "Clicked on Forgot Username Link");
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to Click on Forgot Username Link", e,
					LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	/**
	 * clickReturnSignInLink: To click on Return Sign In Link
	 */
	public boolean clickReturnSignInLink() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkNextStepReturn);
			webActions.clickElement(lnkNextStepReturn);
			if (waits.waitUntilElementIsPresent(lnkForgotUsername)) {
				flag = true;
				LogUtility.logInfo("clickReturnSignInLink", "Clicked on Return Sign In Link");
			}
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to Click on Return Sign In Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyPageTiitle:- To verify the Page Title among Login Pages
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyPageTiitle(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtPageTitle, message);
		} catch (Exception e) {
			LogUtility.logException("clickContinueButton", "Failed to verify request username page title", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifySSNErrMsg:- To verify the Error message displayed for SSN Text field in
	 * Request User name page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifySSNErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtSSNErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifySSNErrMsg", "Failed to verify SSN Error Message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyAcctErrMsg:- To verify the Error message displayed for Account Number
	 * Text field in Request User name page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAcctErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtAcctNumErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyAcctErrMsg", "Failed to verify Account Number Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyAnswerErrMsg:- To verify the Error message displayed for Answer Text
	 * field in Request User name page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyAnswerErrMsg(String message) {
		try {
			boolean flag = false;
			if (waits.waitUntilElementIsPresent(txtAnswerErr, 10))
				flag = wolWebUtil.verifyTextContains(txtAnswerErr, message);
			return flag;
		} catch (Exception e) {
			LogUtility.logException("verifyAnswerErrMsg", "Failed to verify challenge Question Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyUserErrMsg:- To verify the Error message displayed in Request User name
	 * page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyUserErrMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtUserErr, message);
		} catch (Exception e) {
			LogUtility.logException("verifyUserErrMsg", "Failed to verify Username Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyCnfrmMsg:- To verify the confirmation message displayed in Request User
	 * name page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyCnfrmMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtCnfrmMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyCnfrmMsg", "Failed to verify Confirmation Message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyCancelMsg:- To verify the cancel message displayed in Request User name
	 * page
	 * 
	 * @param message:- The text need to verify
	 * @return
	 */
	public boolean verifyCancelMsg(String message) {
		try {
			return wolWebUtil.verifyTextContains(txtCancelMsg, message);
		} catch (Exception e) {
			LogUtility.logException("verifyCancelMsg", "Failed to verify cancellation Message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyReturnHomeLink:- To verify the Return Home Page displayed or not in
	 * Request User name page
	 * 
	 * @return
	 */
	public boolean verifyReturnHomeLink() {
		try {
			return webActions.isDisplayed(lnkReturn);
		} catch (Exception e) {
			LogUtility.logException("verifyReturnHomeLink", "Failed to click on Return to Home Link", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyForgotUsernameLink:- To verify the Forgot Username displayed or not in
	 * Request User name page
	 * 
	 * @return
	 */
	public boolean verifyForgotUsernameLink() {
		try {
			return webActions.isDisplayed(lnkForgotUsername);
		} catch (Exception e) {
			LogUtility.logException("verifyForgotUsernameLink", "Failed to click on Forgot Username Link", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyReturnLink:- To verify the Return Home Page displayed or not in Request
	 * User name page
	 * 
	 * @return
	 */
	public boolean verifyReturnLink() {
		try {
			return webActions.isDisplayed(lnkNextStepReturn);
		} catch (Exception e) {
			LogUtility.logException("verifyReturnLink", "Failed to click on Return Link", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifyResetPasswordLink:- To verify the Reset Password displayed or not in
	 * Request User name page
	 * 
	 * @return
	 */
	public boolean verifyResetPasswordLink() {
		try {
			return webActions.isDisplayed(lnkNextStepResetPwd);
		} catch (Exception e) {
			LogUtility.logException("verifyReturnLink", "Failed to click on Reset Password Link", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * verifyForgotPasswordLink:- To verify the Forgot Password displayed or not
	 * 
	 * @return
	 */
	public boolean verifyForgotPasswordLink() {
		try {
			return webActions.isDisplayed(lnkForgotPassword);
		} catch (Exception e) {
			LogUtility.logException("verifyReturnLink", "Failed to click on Forgot Password Link", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * enterAnswer: To enter value in answer text field
	 */
	public boolean enterAnswer(String value) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAnswer);
			webActions.setValue(txtAnswer, value);
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtAnswer, "value").equalsIgnoreCase(value)) {
				flag = true;
				LogUtility.logInfo("enterAnswer", "Entered value in answer text field");
			}
		} catch (Exception e) {
			LogUtility.logException("enterAnswer", "Failed to enter Answer", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * getUserValue: To retrieved user value
	 */
	public boolean getUserValue() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtUserValue);
			user = webActions.getText(txtUserValue);
			if (!user.isEmpty()) {
				flag = true;
				LogUtility.logInfo("getUserValue", "Retrieved User Value");
			}
		} catch (Exception e) {
			LogUtility.logException("getUserValue", "Failed to get User Value", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyStartAgainLink:- To verify the Start Again Link is displayed or not
	 * 
	 * @return
	 */
	public boolean verifyStartAgainLink() {
		try {
			return webActions.isDisplayed(lnkStartAgain);
		} catch (Exception e) {
			LogUtility.logException("verifyStartAgainLink", "Failed to click on Start Again Link", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * verifySignInErrMsg:- To verify the Error Message of Sign In Error Page
	 * 
	 * @return
	 */
	public boolean verifySignInErrMsg() {
		try {
			return webActions.isDisplayed(txtSignInErrMsg);
		} catch (Exception e) {
			LogUtility.logException("verifySignInErrMsg", "Failed to verify Sign in Error Message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * getChallengeQuestion: To get challenge Question text in Request Username page
	 */
	public void getChallengeQuestion() {
		try {
			waits.waitUntilElementIsPresent(txtChallengeQuestion);
			question1 = webActions.getText(txtChallengeQuestion);
			LogUtility.logInfo("getChallengeQuestion", "Retrieved Challenge Question text");
		} catch (Exception e) {
			LogUtility.logException("getChallengeQuestion", "Failed to get challenge Question text", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * verifyChallengeQuestion- To verify the displayed challenge question is
	 * changed or not
	 * 
	 * @return
	 */
	public boolean verifyChallengeQuestion() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtChallengeQuestion1);
			question2 = webActions.getText(txtChallengeQuestion1);
			if (!question1.equalsIgnoreCase(question2))
				flag = true;
		} catch (Exception e) {
			LogUtility.logException("getChallengeQuestion", "Failed to get challenge Question text", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * verifyUsernameErrMsg:- To verify the Error Message of username
	 * 
	 * @return
	 */
	public boolean verifyUsernameErrMsg(String error) {
		try {
			return wolWebUtil.verifyTextContains(txtUsernameErr, error);
		} catch (Exception e) {
			LogUtility.logException("verifyUsernameErrMsg", "Failed to verify username Error message", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * clickStartAgainLink: To click on Start Again Link
	 */
	public boolean clickStartAgainLink() {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(lnkStartAgain);
			webActions.clickElement(lnkStartAgain);
			waits.waitForPageToLoad(20);
			if (waits.waitUntilElementIsPresent(lnkForgotUsername)) {
				flag = true;
				LogUtility.logInfo("clickStartAgainLink", "Clicked on Start Again Link");
			}
		} catch (Exception e) {
			LogUtility.logException("clickStartAgainLink", "Failed to click on start Again Link", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * verifyUsernameField:- To verify the Username Field in enter Username page
	 * 
	 * @return
	 */
	public boolean verifyUsernameField() {
		try {
			return webActions.isDisplayed(txtUsernameField);
		} catch (Exception e) {
			LogUtility.logException("verifyUsernameField", "Failed to verify username text box", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

}
