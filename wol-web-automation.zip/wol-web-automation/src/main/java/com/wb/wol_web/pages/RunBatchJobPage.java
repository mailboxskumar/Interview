
package com.wb.wol_web.pages;

import java.net.MalformedURLException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.testbases.WOLTestBase;

/**
 * @author Sneha K
 *
 */

public class RunBatchJobPage extends ObjectBase {

	public RunBatchJobPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@id='btnClass']/button")
	protected WebElement btnRunJob;

	@FindBy(xpath = "//select[@ng-model='jobList']")
	protected WebElement selBatchJob;

	@FindBy(xpath = "//b[text()='Job Submitted']")
	protected WebElement txtJobSubmitted;

	/**
	 * To sleect the job from the list
	 * 
	 * @param batchJob -- batch job name
	 * @return
	 */
	public boolean selectTheBatchJob(String batchJob) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(20);
			waits.waitUntilElementIsPresent(selBatchJob);
			webActions.selectDropDownByText(selBatchJob, batchJob);
			waits.waitForDOMready();
			if (wolWebUtil.getDefaultValueForSelect(selBatchJob).equals(batchJob)) {
				status = true;
				LogUtility.logInfo("Selected the batch  job " + batchJob);
			} else
				LogUtility.logError("---> selectTheBatchJob <---", "Failed to select run job");
		} catch (Exception e) {
			LogUtility.logInfo(
					"Failed to Select the batch job " + batchJob + " because of the exception " + e.getMessage());
		}
		return status;
	}

	/**
	 * To click on the button RunJob
	 * 
	 * @return
	 */
	public boolean clickOnRubJobButton() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(20);
			if (waits.waitUntilElementIsPresent(btnRunJob)) {
				webActions.clickElement(btnRunJob);
				status = true;
				LogUtility.logInfo("clickOnRubJobButton", "Clicked on run job status");
			} else
				LogUtility.logError("---> clickOnRubJobButton <---", "Failed to Click on run job status");
		} catch (Exception e) {
			LogUtility.logError("clickOnRubJobButton", e.getMessage());
		}
		return status;
	}

	/**
	 * Waits for the job submitted status after clicking on the run job butoon
	 * 
	 * @return
	 */
	public boolean checkForSubmitStatus() {
		boolean status = false;
		try {
			waits.waitForPageToLoad(20);
			if (waits.waitUntilElementIsPresent(txtJobSubmitted)) {
				status = true;
				LogUtility.logInfo("checkForSubmitStatus", "Received the jobsubmitted status");
			} else
				LogUtility.logError("---> checkForSubmitStatus <---", "Failed to Receive the jobsubmitted status");
		} catch (Exception e) {
			LogUtility.logError("checkForSubmitStatus", e.getMessage());
		}
		return status;
	}

	/**
	 * To load the batch job url
	 * 
	 * @return
	 * @throws Exception
	 */
	public void loadBatchJobURL() throws Exception {
		try {

			navigator.goToUrl(WOLTestBase.envProps.getProperty("batchjob.url"));
			LogUtility.logInfo("loadBatchJobURL", "URL loaded");
		} catch (MalformedURLException e) {
			LogUtility.logError("loadBatchJobURL", e.getMessage());
			throw new Exception("Exception while loading bacth job URL");
		}

	}
}
