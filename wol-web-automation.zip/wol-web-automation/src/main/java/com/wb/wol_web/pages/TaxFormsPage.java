
package com.wb.wol_web.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author rpagadala-adm
 *
 */
public class TaxFormsPage extends ObjectBase {

	public TaxFormsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "taxId")
	protected WebElement inputTaxID;

	@FindBy(name = "accountNumber")
	protected WebElement inputAccountNumber;

	@FindBy(name = "search")
	protected WebElement btnSearch;

	@FindBy(name = "taxYear")
	protected WebElement cmbYear;

	@FindBy(css = ".message--error p")
	protected WebElement txtNoFormsErrorMessage;

	@FindBy(id = "formList")
	protected WebElement tableTaxFormList;

	@FindBy(css = "#formList td>a.windowPopup")
	protected WebElement linkPrintPreview;

	@FindBy(css = "[name='defaultform'] p")
	protected WebElement txtNotOpenTaxform;

	@FindBy(css = "#formList th")
	protected List<WebElement> lstTaxFormLabels;

	/**
	 * enterDataInField: To enter the data in field
	 * 
	 * @param data
	 * @param labelName
	 * @return boolean
	 */
	public boolean enterDataInField(String data, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement fieldName = null;
		try {
			switch (labelName) {
			case "Account Number":
			case "Invalid Account Number":
				fieldName = inputAccountNumber;
				break;
			case "Taxpayer ID":
				fieldName = inputTaxID;
				break;
			default:
				LogUtility.logInfo("-->enterDataInField<--", "No case match found");
				break;
			}
			if (webActions.isDisplayed(fieldName)) {
				webActions.setValue(fieldName, data);
				LogUtility.logInfo("-->enterDataInField<--",
						"Data: " + data + " is entered at Field: " + labelName + " in taxforms page");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterDataInField<--",
					"Data is not entered at Field: " + labelName + " in taxforms page", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectDataInField: To select the value from the list
	 * 
	 * @param data
	 * @param labelName
	 * @return boolean
	 */
	public boolean selectDataInField(String data, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(cmbYear)) {
				webActions.selectDropDownByValue(cmbYear, data);
				LogUtility.logInfo("-->selectDataInField<--",
						"Data: " + data + " is selected at Field: " + labelName + " in taxforms page");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->selectDataInField<--",
					"Data is not selected at Field: " + labelName + " in taxforms page", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clickOnButton: To click on the button
	 * 
	 * @param btnName
	 * @return boolean
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement eleToClick = null;
		try {
			switch (btnName) {
			case "Search":
				eleToClick = btnSearch;
				break;
			case "Print Preview":
				eleToClick = linkPrintPreview;
				break;
			default:
				LogUtility.logInfo("-->clickOnButton<--", "No case match found");
				break;
			}
			if (webActions.isDisplayed(eleToClick)) {
				webActions.clickElement(eleToClick);
				LogUtility.logInfo("-->clickOnButton<--", "Button: " + btnName + " is clicked");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButton<--", "Button: " + btnName + " is not clicked", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyErrorMessage: To verify the error message
	 * 
	 * @param data
	 * @param labelName
	 * @return boolean
	 */
	public boolean verifyMessage(String data, String labelName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement eleToCheck = null;
		try {
			if (labelName.equalsIgnoreCase("Not Open Taxform"))
				eleToCheck = txtNotOpenTaxform;
			else
				eleToCheck = txtNoFormsErrorMessage;
			if (wolWebUtil.verifyTextContains(eleToCheck, data)) {
				LogUtility.logInfo("-->clickOnButton<--", "Message: " + data + " is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButton<--", "Message: " + data + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * clearValuesInFields: To clear the values in Fields
	 * 
	 * @param fieldName
	 * @return boolean
	 */
	public boolean clearValuesInFields(String fieldName) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		WebElement fieldToClear = null;
		try {
			switch (fieldName) {
			case "Account Number":
				fieldToClear = inputAccountNumber;
				break;
			case "Taxpayer ID":
				fieldToClear = inputTaxID;
				break;
			default:
				LogUtility.logInfo("-->clearValuesInFields<--", "No case match found");
				break;
			}
			if (webActions.isDisplayed(fieldToClear)) {
				webActions.setValue(fieldToClear, "");
				LogUtility.logInfo("-->clearValuesInFields<--", "Field Name :" + fieldToClear + " is cleared");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clearValuesInFields<--", "Field Name :" + fieldToClear + " is not cleared", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyTaxForms : To verify the tax forms table is displayed
	 * 
	 * @return boolean
	 */
	public boolean verifyTaxForms() {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		try {
			if (webActions.isDisplayed(tableTaxFormList)) {
				LogUtility.logInfo("-->verifyTaxForms<--", "Tax Forms table is displayed");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyTaxForms<--", "Tax forms table is not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * verifyLabels: To verify the labels in taxforms table
	 * 
	 * @param testDataMap
	 * @return boolean
	 */
	public boolean verifyLabels(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageReadyState();
		String labelName = "";
		try {
			for (WebElement label : lstTaxFormLabels) {
				labelName = webActions.getText(label);
				if (testDataMap.containsValue(labelName)) {
					LogUtility.logInfo("-->verifyLabels<--", "Tax Forms lables are displayed");
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->verifyLabels<--", "Tax forms labels are not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

}