package com.wb.wol_web.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author Veerababu Pedireddi
 *
 */
public class StatementsPage extends ObjectBase {

	public StatementsPage() {
		PageFactory.initElements(driver, this);
	}

	EnrollmentPage enrollmentPage = new EnrollmentPage();

	@FindBy(xpath = "//h1[contains(.,'View Account / Loan Statements')]")
	protected WebElement titleStatementsPage;

	@FindBy(xpath = "//div[@id='pageContent']/div[1]")
	protected WebElement msgAccNoStatements;

	@FindBy(xpath = "//a[contains(.,'View your transaction history')]")
	protected WebElement lnkViewTransHistory;

	@FindBy(xpath = "//a[contains(.,'View your account balances')]")
	protected WebElement lnkViewAccBalances;

	@FindBy(id = "statementCycleDate")
	protected WebElement cmbStmtDate;

	@FindBy(id = "accounts")
	protected WebElement lblAccNumber;

	@FindBy(id = "getImageTrue")
	protected WebElement optDisplayImage;

	@FindBy(css = "tr:nth-child(1) td:nth-child(1) a img")
	protected WebElement imgCheck;

	@FindBy(id = "submit")
	protected WebElement btnViewStatement;

	@FindBy(id = "pdfView")
	protected WebElement btnDownloadStatement;

	@FindBy(css = "div.page:nth-child(1) div:nth-child(2) span:nth-child(23)")
	protected WebElement lblAccNumberStmt;

	@FindBy(css = "div.page:nth-child(1) div:nth-child(2) span:nth-child(20)")
	protected WebElement lblStmtDate;

	@FindBy(css = ".accountNumber")
	protected WebElement lblAccountNumber;

	@FindBy(css = "#interestTable tbody tr span")
	protected List<WebElement> lblInterestFields;

	@FindBy(css = "#interestTable tbody tr td.alignRight")
	protected List<WebElement> lblInterestFieldsValues;

	@FindBy(css = "#detailedAccountSummary")
	protected WebElement lblAccSummary;

	@FindBy(css = "#statementCycle")
	protected WebElement lblStmtCycle;

	@FindAll({ @FindBy(xpath = "//a[contains(.,'View Your Transaction History')]"),
			@FindBy(xpath = "//a[contains(.,'View your transaction history')]"),
			@FindBy(xpath = "//a[contains(.,'View Transaction History')]") })
	protected WebElement lnkTransHistory;

	@FindBy(css = "#bodyContent div.midTopHeadingHolder p")
	protected WebElement msgStmtPeriod;

	@FindBy(css = "#customerService h2")
	protected WebElement lblCustInfo;

	@FindBy(css = "#accountSummaryTable td.left")
	protected List<WebElement> lblSummaryFields;

	@FindBy(css = "#transactionsTable  thead tr:nth-child(1) th strong")
	protected List<WebElement> lblTransHeaders;

	@FindBy(css = "#pageContent > h2")
	protected List<WebElement> lblAccTypeAndMsg;

	@FindBy(css = "#pageContent div.statement-disclaimer h3")
	protected WebElement msgFundTransDisc;

	@FindBy(css = "#pageContent div.statement-disclaimer p:nth-child(2)")
	protected WebElement msgElectronicFundTransfer;

	@FindBy(css = "#pageContent div.statement-disclaimer p")
	protected List<WebElement> msgsTransStmts;

	@FindBy(id = "dateOrder")
	protected WebElement optDateOrder;

	@FindBy(id = "getImageFalse")
	protected WebElement optImageNo;

	@FindBy(css = "#bodyContent button")
	protected WebElement btnPrint;

	@FindBy(css = "#transactionsTable tbody:nth-child(2) tr td:nth-child(1)")
	protected List<WebElement> lblTransDateOrderDates;

	@FindBy(css = "#categoricalTransactions tbody:nth-child(3) tr td h2")
	protected List<WebElement> lblTransCategories;

	@FindBy(id = "categoryOrder")
	protected WebElement optCategoryOrder;

	@FindBy(css = "#categoricalTransactions tbody:nth-child(3) tr td.date")
	protected List<WebElement> lblTransCategoriesDates;

	@FindBy(css = "#categoricalTransactions thead  tr  th div strong")
	protected List<WebElement> lblTransCategoriesHeaders;

	@FindBy(css = "#customerServiceRight")
	protected WebElement lblCustServiceRight;

	@FindBy(css = "#customerServiceLeft")
	protected WebElement lblCustServiceLeft;

	@FindBy(css = "#statementAddress")
	protected WebElement lblStmtAddress;

	@FindBy(css = "#checkList thead  tr th strong")
	protected List<WebElement> lblChecksDetails;

	@FindBy(css = "#checkList tfoot tr td:nth-child(1) strong")
	protected WebElement lblChecksCount;

	@FindBy(css = "#feesSummary tbody span")
	protected List<WebElement> lblNFSTableFields;

	@FindBy(css = "#categoricalTransactions > tbody td > strong")
	protected List<WebElement> lblTransCategorySubSections;

	@FindBy(css = "#threeColumnDailyBalance tr.borderBottom Strong")
	protected List<WebElement> lblDailyBalanceFields;

	@FindBy(css = "#threeColumnDailyBalance h2")
	protected WebElement lblDailyBalance;

	@FindBy(css = "#statementCheckMessage em")
	protected WebElement lblStmtNote;

	@FindBy(id = "show-deposit-image-page__pageTitle")
	protected WebElement titleDepositImage;

	public String statementPeriod = null;
	public String accNumber = null;
	public String statementPeriodDateRange = null;

	/**
	 * To Verify the Statements Page Title
	 */

	public boolean verifyStatementsPageTitle(String stmtsPageTitle) {
		try {
			waits.waitUntilElementIsPresent(titleStatementsPage, maxTimeOut);
			return wolWebUtil.verifyText(titleStatementsPage, stmtsPageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyStatementsPageTitle", stmtsPageTitle + " Page is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Statements Page no statements message
	 */

	public boolean verifyNoStatementsMsg(String noStatementsMsg) {
		try {
			return wolWebUtil.verifyText(msgAccNoStatements, noStatementsMsg);
		} catch (Exception e) {
			LogUtility.logException("verifyNoStatementsMsg", noStatementsMsg + " message is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the View Your Transaction History Link displayed or not
	 */
	public boolean verifyViewTransHistoryLink() {
		try {
			return webActions.isDisplayed(lnkViewTransHistory);
		} catch (Exception e) {
			LogUtility.logException("verifyViewTransHistoryLink", "Unable to display View Transaction History link", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the View Your Account Balances Link displayed or not
	 */
	public boolean verifyViewAccBalancesLink() {
		try {
			return webActions.isDisplayed(lnkViewAccBalances);
		} catch (Exception e) {
			LogUtility.logException("verifyViewAccBalancesLink", "Unable to display View Account Balances link", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Statement Period date
	 *
	 */
	public boolean verifyStmtPeriod() {
		try {
			statementPeriod = getValueFromRuntimeDataMap("dateRangeKey");
			return wolWebUtil.verifyTextContains(cmbStmtDate, statementPeriod);
		} catch (Exception e) {
			LogUtility.logException("verifyStmtPeriod", statementPeriod + " date is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Account details
	 *
	 */
	public boolean verifyAccDetails() {
		try {
			accNumber = (testDataMap.get("Loan Account Number"));
			return wolWebUtil.verifyTextContains(lblAccNumber, accNumber);
		} catch (Exception e) {
			LogUtility.logException("verifyAccDetails", accNumber + " number is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Statement Period date range
	 *
	 */
	public boolean verifyStmtPeriodDateRange() {
		boolean flag = false;
		try {
			statementPeriodDateRange = wolWebUtil.getDefaultValueForSelect(cmbStmtDate);
			if (statementPeriodDateRange.contains("-")) {
				LogUtility.logInfo("--->verifyStmtPeriodDateRange<---", " Statement Period Date Range displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyStmtPeriodDateRange", "Statement Period Date Range not displayed", e,
					LoggingLevel.ERROR, true);
		}

		return flag;
	}

	/**
	 * To select Account from dropdown list
	 */
	public boolean selectAccFromDropdownList() {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(lblAccNumber);
			if (selectAccount) {
				wolWebUtil.selectValueByPartialVisibleText(lblAccNumber, (testDataMap.get("Loan Account Number")));
				LogUtility.logInfo("---> Select Account From Dropdown <---", "Account Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectAccFromDropdown", "Unable to select the Account", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To select the Check Image Account from dropdown list
	 */
	public boolean selectChkImageAccFromDropdownList() {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(lblAccNumber);
			if (selectAccount) {
				wolWebUtil.selectValueByPartialVisibleText(lblAccNumber, (testDataMap.get("SelectCheckImageAccount")));
				LogUtility.logInfo("---> selectChkImageAccFromDropdownList <---", "Account Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectChkImageAccFromDropdownList", "Unable to select the Account", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To select the Yes option for Display Check/Deposit Images
	 */
	public boolean selectYesForDisplayImages() {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(optDisplayImage);
			if (selectAccount) {
				webActions.clickElement(optDisplayImage);
				LogUtility.logInfo("---> selectYesForDisplayImages <---", "Yes option Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectYesForDisplayImages", "Unable to select the Yes option", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on the Check/Deposit Images
	 */
	public boolean clickOnImage() {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(imgCheck);
			if (selectAccount) {
				webActions.clickElement(imgCheck);
				LogUtility.logInfo("---> clickOnImage <---", "Image Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnImage", "Unable to click on the Image", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To select the Statement Period date
	 *
	 */
	public boolean selectStmtPeriod() {
		boolean flag = false;
		try {
			boolean selectPeriodDate = webActions.isDisplayed(cmbStmtDate);
			if (selectPeriodDate) {
				wolWebUtil.selectValueByPartialVisibleText(cmbStmtDate, testDataMap.get("SelectStmtPeriodDate"));
				LogUtility.logInfo("---> selectStmtPeriod <---", "Statement Period date selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectStmtPeriod", "Unable to select the Statement Period date", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To Click on View Statement button
	 */
	public boolean clickOnViewStatement() {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(btnViewStatement);
			if (selectAccount) {
				webActions.clickElement(btnViewStatement);
				LogUtility.logInfo("---> clickOnViewStatement <---", "Clicked on View Statement button");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewStatement", "Unable to click on the ViewStatement button", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Account number in the Loan statement
	 */
	public boolean verifyAccountNumberInLoanStmt() {
		try {
			webActions.clickElement(btnDownloadStatement);
			// After clicked on Download button, page loading takes time
			waits.staticWait(2);
			waits.waitForPageReadyState();
			wolWebUtil.switchToNewWindow();
			driver.findElement(By.id("viewerContainer")).click();
			return wolWebUtil.verifyText(lblAccNumberStmt, testDataMap.get("StatementAccNumber"));
		} catch (Exception e) {
			LogUtility.logException("verifyAccountNumberInLoanStmt", lblAccNumberStmt + "  is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Statement date in the Loan statement
	 */
	public boolean verifyLoanStmtDate() {
		try {

			return wolWebUtil.verifyText(lblStmtDate, testDataMap.get("LoanStatementDate"));
		} catch (Exception e) {
			LogUtility.logException("verifyLoanStmtDate", lblStmtDate + "  is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To close the Current Browser and move to active page
	 */
	public void closeTheBrowser() {
		try {
			wolWebUtil.switchToMainWindow();
		} catch (Exception e) {
			LogUtility.logException("closeTheBrowser", "Browser is not closed", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To verify Account is not displaying in the dropdown list
	 */
	public boolean verifyAccIsNotInDropdownList() {
		try {
			return wolWebUtil.selectValueByPartialText(lblAccNumber, (testDataMap.get("Loan Account Number")));
		} catch (Exception e) {
			LogUtility.logException("selectAccFromDropdown", "Unable to select the Account", e, LoggingLevel.ERROR,
					true);
			return true;
		}
	}

	/**
	 * To verify Account number in the report
	 */
	public boolean verifyAccountNumber() {
		try {
			return wolWebUtil.verifyTextContains(lblAccountNumber, (testDataMap.get("AccountNumber")));
		} catch (Exception e) {
			LogUtility.logException("verifyAccountNumber", "Unable to display the Account", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To check the Interest fields in the Statement
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifyInterestFields(Map<String, String> interestFields) {
		try {
			return enrollmentPage.verifyListMesagses(lblInterestFields, interestFields, "InterestFields",
					"verifyInterestFields");
		} catch (Exception e) {
			LogUtility.logException("verifyMenuLinks", "Interest fields are not present", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check the Interest fields in the Statement
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifyInterestFieldsValues(Map<String, String> interestValues) {
		try {
			return wolWebUtil.verifyListOfItems(lblInterestFieldsValues, interestValues, "InterestFieldsValues",
					"verifyInterestFieldsValues");
		} catch (Exception e) {
			LogUtility.logException("verifyMenuLinks", "Interest fields values are not present", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To select APy Statement Account from dropdown list
	 */
	public boolean selectAPYStmtAccFromDropdownList() {
		boolean flag = false;
		try {
			boolean selectAccount = webActions.isDisplayed(lblAccNumber);
			if (selectAccount) {
				wolWebUtil.selectValueByPartialVisibleText(lblAccNumber, (testDataMap.get("APYStatementAccount")));
				LogUtility.logInfo("---> Select Account From Dropdown <---", "Account Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectAPYStmtAccFromDropdownList", "Unable to select the Account", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify Detailed Account Activity Content
	 */
	public boolean verifyDetailedAccActivityContent() {
		try {
			return wolWebUtil.verifyText(lblAccSummary, (testDataMap.get("DetailedContent")));
		} catch (Exception e) {
			LogUtility.logException("verifyDetailedAccActivityContent", "Unable to display the Detailed Content", e,
					LoggingLevel.ERROR, true);
			return true;
		}
	}

	/**
	 * To verify Detailed Account Activity Statement date
	 */
	public boolean verifyDetailedStmtDate() {
		try {
			return wolWebUtil.verifyText(lblStmtCycle, (testDataMap.get("DetailedStmtDate")));
		} catch (Exception e) {
			LogUtility.logException("verifyDetailedStmtDate", "Unable to display the Detailed Statement date", e,
					LoggingLevel.ERROR, true);
			return true;
		}
	}

	/**
	 * To verify the Statement is not displaying N/A in the Statement Period Date
	 * dropdown list
	 */
	public boolean verifyStmtIsNotInNADropdownList() {
		try {
			return wolWebUtil.selectValueByPartialText(cmbStmtDate, (testDataMap.get("StatementNotInNA")));
		} catch (Exception e) {
			LogUtility.logException("verifyStmtIsNotInNADropdownList", "Statement displayed as N/A", e,
					LoggingLevel.ERROR, true);
			return true;
		}
	}

	/**
	 * To Click on the View Your Transaction History Link
	 */
	public boolean clickOnViewTransHistoryLink() {
		boolean flag = false;
		try {
			boolean transHistLink = webActions.isDisplayed(lnkTransHistory);
			if (transHistLink) {
				webActions.clickElement(lnkTransHistory);
				LogUtility.logInfo("---> clickOnViewTransHistoryLink <---", "Clicked on Transaction History link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnViewTransHistoryLink", "Unable to click on the Transaction History Link", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify Select your Webster account and the statement period text message
	 */
	public boolean verifyStmtPeriodMsg() {
		try {
			return wolWebUtil.verifyText(msgStmtPeriod, (testDataMap.get("StatementMessage")));
		} catch (Exception e) {
			LogUtility.logException("verifyStmtPeriodMsg", "Unable to display the statement period text message", e,
					LoggingLevel.ERROR, true);
			return true;
		}
	}

	/**
	 * To verify the Customer Service Information label should display
	 */
	public boolean verifyCustServiceInfoLabel() {
		try {
			return wolWebUtil.verifyText(lblCustInfo, (testDataMap.get("CustomerInformation")));
		} catch (Exception e) {
			LogUtility.logException("verifyCustServiceInfoLabel",
					"Unable to display the Customer Service Information label", e, LoggingLevel.ERROR, true);
			return true;
		}
	}

	/**
	 * To check the Summary fields in the Statement
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifySummaryFields(Map<String, String> summaryFields) {
		try {
			return wolWebUtil.verifyListOfItems(lblSummaryFields, summaryFields, "SummaryFields",
					"verifySummaryFields");
		} catch (Exception e) {
			LogUtility.logException("verifyMenuLinks", "Summary fields are not present", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check the Transaction Headers in the Statement
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifyTransHeaders(Map<String, String> tranHeaders) {
		try {
			return wolWebUtil.verifyListOfItems(lblTransHeaders, tranHeaders, "TransactionFields",
					"verifyTransHeaders");
		} catch (Exception e) {
			LogUtility.logException("verifyTransHeaders", "Transaction fields are not present", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To check the messages in the Statement
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifyTransStmtsMsgs(Map<String, String> stmtMsgs) {
		try {
			return wolWebUtil.verifyListOfItems(msgsTransStmts, stmtMsgs, "TransStmtMessages", "verifyTransStmtsMsgs");
		} catch (Exception e) {
			LogUtility.logException("verifyTransStmtsMsgs", "Transaction fields are not present", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Important Information About Your Statement message should
	 * display
	 */
	public boolean verifyAccTypeAndImpStmtMsg(Map<String, String> messages) {
		try {
			return wolWebUtil.verifyListOfItems(lblAccTypeAndMsg, messages, "AccTypeAndStmtImpMessage",
					"verifyAccTypeAndImpStmtMsg");
		} catch (Exception e) {
			LogUtility.logException("verifyAccTypeAndImpStmtMsg", "Acc Type and Imp Messages are not present", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the ELECTRONIC FUND TRANSFERS text should display
	 */
	public boolean verifyElecFundTransferText() {
		try {
			return wolWebUtil.verifyTextContains(msgFundTransDisc, (testDataMap.get("ElectFundTransfer")));
		} catch (Exception e) {
			LogUtility.logException("verifyImpStmtMsg", "Unable to display the message", e, LoggingLevel.ERROR, true);
			return true;
		}
	}

	/**
	 * To verify the ELECTRONIC FUND TRANSFERS Detailed message should display
	 */
	public boolean verifyElecFundTransferMsg() {
		try {
			return wolWebUtil.verifyTextContains(msgElectronicFundTransfer, (testDataMap.get("ElectFundTransferMsg")));
		} catch (Exception e) {
			LogUtility.logException("verifyElecFundTransferMsg", "Unable to display the message", e, LoggingLevel.ERROR,
					true);
			return true;
		}
	}

	/**
	 * To select the No option for Display Check/Deposit Images
	 */
	public boolean selectNoForDisplayImages() {
		boolean flag = false;
		try {
			boolean imageNo = webActions.isDisplayed(optImageNo);
			if (imageNo) {
				webActions.clickElement(optImageNo);
				LogUtility.logInfo("---> selectNoForDisplayImages <---", "No option Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectNoForDisplayImages", "Unable to select the No option", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To select the Date order option for Statement format
	 */
	public boolean selectDateOrderOption() {
		boolean flag = false;
		try {
			boolean dateOrder = webActions.isDisplayed(optDateOrder);
			if (dateOrder) {
				webActions.clickElement(optDateOrder);
				LogUtility.logInfo("---> selectDateOrderOption <---", "No option Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectDateOrderOption", "Unable to select the Date Order option", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the given date is present or not in the date range
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Modified on:
	 */
	public boolean verifyDateRangeInStmts(String dateValue, String startDate, String endDate) throws Exception {
		String sDate[] = dateValue.split("/");
		String ModsDate = sDate[0] + "/" + sDate[1] + "/" + sDate[2];
		boolean flag = false;
		try {
			SimpleDateFormat objSDF = new SimpleDateFormat("mm/dd/yyyy");
			Date dt_1 = objSDF.parse(ModsDate);
			Date dt_2 = objSDF.parse(startDate);
			Date dt_3 = objSDF.parse(endDate);
			if ((dt_1.after(dt_2)) || (dt_1.before(dt_3)) || (dt_1.equals(dt_2)) || (dt_1.equals(dt_3))) {
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDateRangeInStmts", "Date range failed", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return flag;
	}

	/**
	 * To verify List column value date is present in range or not
	 * 
	 * @Author:Veerababu Pedireddi
	 * @Modified on:
	 */
	public void verifyDateIntheTransList(List<WebElement> element, String startDate, String endDate) {
		try {
			for (int values = 1; values < element.size(); values++) {
				String dateValue = ((WebElement) element.get(values)).getText() + "/" + testDataMap.get("Year");
				boolean resultValue = verifyDateRangeInStmts(dateValue, startDate, endDate);
				if (resultValue) {
					LogUtility.logInfo("Passed -" + dateValue + " Present in range");
				} else {
					LogUtility.logInfo("Failed -" + dateValue + " Not Present in range");
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDateIntheTransList", "Failed to return old date", e, LoggingLevel.ERROR,
					true);
		}
	}

	/**
	 * To Verify the Date Range in the list
	 */

	public boolean verifyTransDateInRange(String option) {
		boolean flag = false;
		try {
			String fromDate = testDataMap.get("FromDate");
			String toDate = testDataMap.get("ToDate");
			if (option.equals("DateOrder")) {
				verifyDateIntheTransList(lblTransDateOrderDates, fromDate, toDate);
				LogUtility.logInfo("--->verifyTransDateInRange---->",
						" Date Range verified By Date Order Successfully");
				flag = true;
			} else if (option.equals("ByCategories")) {
				verifyDateIntheTransList(lblTransCategoriesDates, fromDate, toDate);
				LogUtility.logInfo("--->verifyTransDateInRange---->",
						" Date Range verified By Categories Successfully");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyTransDateInRange", "Unable to verify date range", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To check the Transactions By Categories the Statement
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifyTransCategories(Map<String, String> categories) {
		try {
			return wolWebUtil.verifyListOfItems(lblTransCategories, categories, "TransCategories",
					"verifyTransCategories");
		} catch (Exception e) {
			LogUtility.logException("verifyTransCategories", "Transaction Categories fields are not present", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To check the Transactions By Categories Headers in the Statement
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifyTransCategoriesHeaders(Map<String, String> headers) {
		try {
			return wolWebUtil.verifyListOfItems(lblTransCategoriesHeaders, headers, "TransCategoriesHeaders",
					"verifyTransCategoriesHeaders");
		} catch (Exception e) {
			LogUtility.logException("verifyTransCategoriesHeaders", "Transaction Categories headers are not present", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To select the By Categories in the Statement format
	 */
	public boolean selectCategoryOrderOption() {
		boolean flag = false;
		try {
			boolean categoryOrder = webActions.isDisplayed(optCategoryOrder);
			if (categoryOrder) {
				webActions.clickElement(optCategoryOrder);
				LogUtility.logInfo("---> selectCategoryOrderOption <---", "Category Order option Selected");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("selectCategoryOrderOption", "Unable to select the Category Order option", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Print button is displayed or not
	 */
	public boolean verifyPrintButton() {
		try {
			return webActions.isDisplayed(btnPrint);
		} catch (Exception e) {
			LogUtility.logException("verifyPrintButton", "Unable to display the Print button", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Customer Name and Address should display
	 */
	public boolean verifyCustomerNameAddress() {
		boolean flag = false;
		try {
			String custNameAddress = webActions.getText(lblStmtAddress).replaceAll("\n", " ");
			if (custNameAddress.equals(testDataMap.get("NameAndAddress"))) {
				LogUtility.logInfo("---> verifyCustomerNameAddress <---", "Customer Name and Address displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCustomerNameAddress", "Unable to display the Name and Address", e,
					LoggingLevel.ERROR, true);
			flag = false;
		}
		return flag;
	}

	/**
	 * To verify the Customer Right Side Information should display
	 */
	public boolean verifyCustomerRightSideInfo() {
		boolean flag = false;
		try {
			String customerInfo = webActions.getText(lblCustServiceRight).replaceAll("\n", " ");
			if (customerInfo.equals(testDataMap.get("CustomerRightSideInfo"))) {
				LogUtility.logInfo("---> verifyCustomerRightSideInfo <---",
						"Customer Right side information displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCustomerRightSideInfo", "Unable to display the Customer Information", e,
					LoggingLevel.ERROR, true);
			flag = false;
		}
		return flag;
	}

	/**
	 * To verify the Customer Left Side Information should display
	 */
	public boolean verifyCustomerLeftSideInfo() {
		boolean flag = false;
		try {
			String customerInfo = webActions.getText(lblCustServiceLeft).replaceAll("\n", " ");
			if (customerInfo.equals(testDataMap.get("CustomerLeftSideInfo"))) {
				LogUtility.logInfo("---> verifyCustomerLeftSideInfo <---", "Customer Left side information displayed");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCustomerLeftSideInfo", "Unable to display the Customer Information", e,
					LoggingLevel.ERROR, true);
			return false;
		}
		return flag;
	}

	/**
	 * To verify the Checks Information should display
	 */
	public boolean verifyChecksInformation(Map<String, String> checks) {
		try {
			return wolWebUtil.verifyListOfItems(lblChecksDetails, checks, "ChecksInformation",
					"verifyChecksInformation");
		} catch (Exception e) {
			LogUtility.logException("verifyChecksInformation", "Checks Information not present", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the NFS table Information should display
	 */
	public boolean verifyNFSTableFields(Map<String, String> nfsTable) {
		try {
			return wolWebUtil.verifyListOfItems(lblNFSTableFields, nfsTable, "NFSFeeTableFields",
					"verifyNFSTableFields");
		} catch (Exception e) {
			LogUtility.logException("verifyNFSTableFields", "NFS table Information not present", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Total number of checks paid count should display
	 */
	public boolean verifyNumberOfChecks() {
		try {
			return wolWebUtil.verifyTextContains(lblChecksCount, (testDataMap.get("TotalNumberOfChecks")));
		} catch (Exception e) {
			LogUtility.logException("verifyElecFundTransferMsg", "Unable to display the message", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To Verify the Check Image is not present
	 */
	public boolean checkImagesNotPresent() {
		try {
			return wolWebUtil.elementNotDisplay(imgCheck);
		} catch (Exception e) {
			LogUtility.logException("checkImageNotPresent", " Check image is not present", e, LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Daily Balance fields should display
	 */
	public boolean verifyDailyBalanceFields(Map<String, String> balance) {
		try {
			return wolWebUtil.verifyListOfItems(lblDailyBalanceFields, balance, "DailyBalanceFields",
					"verifyDailyBalanceFields");
		} catch (Exception e) {
			LogUtility.logException("verifyDailyBalanceFields", "Daily Balance Fields not present", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Category Sub Sections should display
	 */
	public boolean verifyCategorySubSections(Map<String, String> sections) {
		try {
			return wolWebUtil.verifyListOfItems(lblTransCategorySubSections, sections, "TransCategorySubHeadings",
					"verifyCategorySubSections");
		} catch (Exception e) {
			LogUtility.logException("verifyCategorySubSections", "Category Sub Sections not present", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Daily Balance text should display
	 */
	public boolean verifyDailyBalanceText() {
		try {
			return wolWebUtil.verifyText(lblDailyBalance, (testDataMap.get("DailyBalanceText")));
		} catch (Exception e) {
			LogUtility.logException("verifyDailyBalanceText", "Unable to display the Daily Balance Text", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Daily Balance text should display
	 */
	public boolean verifyStatementNote() {
		try {
			return wolWebUtil.verifyText(lblStmtNote, (testDataMap.get("StmtNote")));
		} catch (Exception e) {
			LogUtility.logException("verifyStatementNote", "Unable to display the Statement Note", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To Verify the Deposit Image Page Title
	 */
	public boolean verifyDepositImagePage(String message) {
		try {
			return wolWebUtil.verifyText(titleDepositImage, message);
		} catch (Exception e) {
			LogUtility.logException("verifyDepositImagePage", message + " Page is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}
}
