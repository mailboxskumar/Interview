package com.wb.wol_web.pages;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

public class PaymentCenterPage extends ObjectBase {

	public PaymentCenterPage() {
		PageFactory.initElements(driver, this);
	}

	public String monthTitleBefore = null;
	List<LinkedHashMap<String, String>> enteredPayments = new ArrayList<>();
	List<LinkedHashMap<String, String>> enteredPaymentsVerify = new ArrayList<>();
	public String paymentDetail = "(//li[@data-mm-hidden='false']//span[@class=' col_Column'])[Row]";
	public String existingPaymentDetails = "//span[contains(text(),'ReplaceMe') and contains(@id,'existing_payments_table')]/..//a";
	public String existingPaymentActionMenu = "//span[contains(text(),'ReplaceMe') and contains(@id,'existing_payments_table')]/..//h1";
	public String editButton = "//span[contains(text(),'ReplaceMe')]/..//*[contains(@id,'new_payments_table_row_edit') and @href!='null']";
	public String deleteButton = "//span[contains(text(),'ReplaceMe')]/..//*[contains(@id,'new_payments_table_row_delete') and @href!='null']";
	public String billDetailLabel = "//label[contains(text(),'ReplaceMe')]";
	public String msg = "//*[contains(text(),'ReplaceMe')]";
	public String actionMenu = "//h1[contains(@id,'actionMenu__submenu-title')]";
	public String navLink = "//a[contains(@id,'paymentDetailsLink__navigationLink')]";
	public String lightBoxMsg = "//*[contains(text(),'ReplaceMe') and contains(@id,'lightbox')]";

	@FindBy(name = "new_username")
	protected WebElement txtNewUsername;

	@FindBy(xpath = "//*[contains(text(),'Next >')]")
	protected WebElement btnNext;

	@FindBy(xpath = "//*[contains(text(),'< Previous')]")
	protected WebElement btnPrevious;

	@FindBy(xpath = "//time/span[contains(@id,'month')]")
	protected WebElement lblMonthTitle;

	@FindBy(xpath = "//*[@class='lightbox' and @aria-labelledby='lightBoxTitle1']")
	protected WebElement dialogBox;

	@FindBy(name = "payFrom")
	protected WebElement selPayFrom;

	@FindBy(xpath = "//select[@name='payFrom']/optgroup[@label='Personal Accounts']")
	protected WebElement lstPersonalPayFrom;

	@FindBy(xpath = "//select[contains(@id,'payTo')]")
	protected WebElement selPayTo;

	@FindBy(name = "paymentAmount")
	protected WebElement amountTxtBox;

	@FindBy(id = "new_payment__col_5")
	protected WebElement txtDelDate;

	@FindBy(css = "#processingDate__display>span")
	protected WebElement txtDebitDate;

	@FindBy(name = "paymentMemo")
	protected WebElement memoTxtBox;

	@FindAll(@FindBy(xpath = "//span[@aria-label='Payment Type']"))
	protected List<WebElement> paymentTypeList;

	@FindBy(id = "schedulePaymentButton")
	protected WebElement btnMakePayment;

	@FindBy(id = "addPaymentButton")
	protected WebElement btnAddPayment;

	@FindBy(id = "schedulePaymentButton")
	protected WebElement btnAddToPayments;

	@FindBy(id = "submitButton__buttonText")
	protected WebElement btnReviewPayments;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle1']//*[@aria-label='Close the dialog']")

	protected WebElement btnClose;

	@FindAll(@FindBy(xpath = "//a[contains(@href,'/bank/ds?action=df_bill')]"))
	protected List<WebElement> listDates;

	@FindBy(id = "focusAction")
	protected WebElement btnDeleteInVerficationPage;

	@FindBy(id = "submitButton__actualButton")
	protected WebElement btnContinueInPayVerifyPage;

	@FindBy(id = "updateAction")
	protected WebElement btnUpdateInVerficationPage;

	@FindBy(id = "cancelButton")
	protected WebElement btnCancel;

	@FindBy(id = "duplicatePaymentChooser__option1__input")
	protected WebElement btnDuplicateBills;

	@FindBy(id = "duplicatebtn")
	protected WebElement btnDuplicateBillsInUpdate;

	@FindBy(name = "frequency")
	protected WebElement lstFrequency;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle20']//button[@id='genericLightboxCloseAndContinueButton']")
	protected WebElement ePaymentDialogClose;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle19']//button[@id='genericLightboxCloseAndContinueButton']")
	protected WebElement checkPaymentDialogClose;

	@FindBy(xpath = "//form[@name='paymentdetails']")
	protected WebElement billPaymentDetails;

	@FindBy(xpath = "//h1[contains(text(),'Payment Center')]")
	protected WebElement paymentCenterHeading;

	@FindBy(id = "new_payment__col_0")
	protected WebElement makeNewPaymentHeading;

	@FindBy(id = "deletebtn")
	protected WebElement btnDelete;

	@FindBy(id = "paymentAmount__error-message-text")
	protected WebElement amountErrorMsg;

	@FindBy(id = "payToPersonal__error-message-text")
	protected WebElement payToErrorMsg;

	@FindBy(id = "new_payments_table--with-tooltip-0")
	protected WebElement debitDateToolTip;

	@FindBy(css = "td> select")
	protected WebElement lstAlertsDaysBefore;

	@FindAll(@FindBy(xpath = "//div/b[contains(text(),'$')]/../.."))
	protected List<WebElement> listExistingPaymentDates;

	@FindAll(@FindBy(xpath = "//a[not(contains(@data-disabled,'true')) and contains(@href,'/bank') and contains(@id,'paymentCenterCalendar')]"))
	protected List<WebElement> listActiveDates;

	@FindAll(@FindBy(css = "li[data-mm-hidden='false']"))
	protected List<WebElement> listPaymentsAdded;

	@FindAll(@FindBy(xpath = "//*[@id='existing_payments_table__body']/li"))
	protected List<WebElement> listExistingPaymentsInLB;

//	@FindBy(xpath = "//h3[contains(text(),'Update Payment Details')]")
	@FindBy(css = "div.pageHeaderBlock > h3")
	protected WebElement udpTitle;

	@FindBy(xpath = "//h3[@data-wbst-message-key='eu.updatepaymentdetails.verify_title']")
	protected WebElement updateVerifyTitle;

	@FindBy(xpath = "//h3[@data-wbst-message-key='eu.updatepaymentdetails.confirm_title']")
	protected WebElement updateConfirmTitle;

	@FindBy(xpath = "//h3[@data-wbst-message-key='eu.paymentdetails.bill.title']")
	protected WebElement billPaymentTitle;

	@FindBy(xpath = "//h3[@data-wbst-message-key='eu.deletepaymentverify.title']")
	protected WebElement deletePaymentTitle;

	@FindBy(xpath = "//h3[@data-wbst-message-key='eu.deletepaymentconfirm.title']")
	protected WebElement deleteConfirmTitle;

	@FindBy(xpath = "//*[@id='quick-pay-setup-lightbox__pageErrors__quickPay__error__noPayees__body']")
	protected WebElement noPayeeErrorMsg;

	@FindBy(xpath = "//*[@id='quick-pay-setup-lightbox__pageErrors__quickPay__error__noAccounts__body']")
	protected WebElement noAccountsErrorMsg;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle5']")
	protected WebElement disclosureCheck;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle6']")
	protected WebElement disclosureElectronic;

	@FindBy(id = "quick-pay-confirmation-lightbox__pageAffirmativeNotice__body")
	protected WebElement lblSuccesPaymentMsg;

	@FindBy(xpath = "//div[@id='lightBoxContent5']//div[@id='message']")
	protected WebElement txtInCheckNotice;

	@FindBy(xpath = "//div[@id='lightBoxContent6']//div[@id='message']")
	protected WebElement txtInElectronicNotice;

	@FindBy(id = "new_payment__col_2")
	protected WebElement lblNoPayeeMsg;

	@FindBy(id = "new_payment__col_3")
	protected WebElement lblNoBusinessPayeeMsg;

	@FindBy(id = "updatePaymentButton")
	protected WebElement btnUpdatePayment;

	@FindBy(id = "new_payment__col_0")
	protected WebElement txtMakeNewPayHeading;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle6']//button[@id='genericLightboxCloseAndContinueButton']")
	protected WebElement btnDisclosureContinueForE;

	@FindBy(xpath = "//div[@aria-labelledby='lightBoxTitle5']//button[@id='genericLightboxCloseAndContinueButton']")
	protected WebElement btnDisclosureContinueForC;

	@FindAll(@FindBy(xpath = "//select[@name='payFrom']/optgroup[@label='Personal Accounts']/option"))
	protected List<WebElement> lstPersonalPayFromDropdown;

	@FindAll(@FindBy(xpath = "//select[@name='payFrom']/optgroup[@label='Business Accounts']/option"))
	protected List<WebElement> lstBusinessPayFromDropdown;

	/**
	 * To check for the error messages depending on the type of error
	 * 
	 * @param msg
	 * @param errorType
	 * @return
	 */
	public boolean checkForNoPayeeErrorMsg(String msg, String errorType) {
		WebElement eleToCheck;
		boolean flag = false;
		try {
			if (errorType.equalsIgnoreCase("NoEligibleAccounts"))
				eleToCheck = noAccountsErrorMsg;
			else
				eleToCheck = noPayeeErrorMsg;
			if (webActions.getText(eleToCheck).equalsIgnoreCase(msg)) {
				LogUtility.logInfo("---> checkForNoPayeeErrorMsg <---", "errorMessage " + msg + "is present");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("checkForNoPayeeErrorMsg", "Failed to check errorMessage", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To click on the button with text
	 * 
	 * @param text
	 */
	public boolean ClickOnButton(String text) {
		WebElement elementToClick = null;
		boolean status = false;
		switch (text) {
		case "Next":
			monthTitleBefore = lblMonthTitle.getText();
			elementToClick = btnNext;
			break;
		case "Previous":
			monthTitleBefore = lblMonthTitle.getText();
			elementToClick = btnPrevious;
			break;
		case "AddPayment":
			elementToClick = btnAddPayment;
			break;
		case "Add to Payments":
			elementToClick = btnAddToPayments;
			break;
		case "Review and Schedule Payments":
			wolWebUtil.scrollToElement(btnReviewPayments);
			elementToClick = btnReviewPayments;
			break;
		case "Close":
			elementToClick = btnClose;
			break;
		case "Delete":
			elementToClick = btnDelete;
			break;
		case "Delete in Verification Page":
			elementToClick = btnDeleteInVerficationPage;
			break;
		case "Electronic Payment dialogbox close":
			elementToClick = ePaymentDialogClose;
			break;
		case "Update":
			// id is same as delete button in Update payment details page
			elementToClick = btnDeleteInVerficationPage;
			break;
		case "Verification Page Update":
			elementToClick = btnUpdateInVerficationPage;
			break;
		case "Cancel":
			elementToClick = btnCancel;
			break;
		}
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(elementToClick, maxTimeOut);

			if (webActions.isDisplayed(elementToClick)) {
				webActions.clickElement(elementToClick);
				status = true;
			}
			waits.waitForPageToLoad(maxTimeOut);
			if (text.equals("Review and Schedule Payments")) {
				if (webActions.isDisplayed(btnDuplicateBills)) {
					LogUtility.logInfo("---> ClickonButton <---", "duplicate bills while placing the order" + text);
					webActions.clickElement(btnDuplicateBills);
					webActions.clickElement(btnReviewPayments);
				}
			}
			waits.waitForPageToLoad(maxTimeOut);
			if (text.equals("Update")) {
				if (webActions.isDisplayed(btnDuplicateBillsInUpdate)) {
					LogUtility.logInfo("---> ClickonButton <---", "Update for duplicate bills" + text);
					webActions.clickElement(btnDuplicateBillsInUpdate);
				}
			}

			LogUtility.logInfo("---> ClickonButton <---", "Clicked on the button " + text);
		} catch (Exception e) {
			LogUtility.logException("ClickonButton", "Failed to click on the button " + text, e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To click on Continue buttons
	 */
	public boolean clickOnContinueButton() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnContinueInPayVerifyPage)) {
				flag = true;
				webActions.clickElement(btnContinueInPayVerifyPage);
				LogUtility.logInfo("--->clickOnContinueButton < ---", "clicked on continue button");
			}

		} catch (Exception e) {
			LogUtility.logException("clickOnContinueButton", "Failed to click on the continue button ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To check the calendar title changes accordingly when Next/Previous button is
	 * clicked
	 * 
	 * @param addOrMinus
	 * @return
	 */
	public boolean checkCalendarTitle(String addOrMinus) {

		boolean status = false;
		Map<String, Integer> monthNum = new HashMap<String, Integer>();
		monthNum.put("JANUARY", 1);
		monthNum.put("FEBRUARY", 2);
		monthNum.put("MARCH", 3);
		monthNum.put("APRIL", 4);
		monthNum.put("MAY", 5);
		monthNum.put("JUNE", 6);
		monthNum.put("JULY", 7);
		monthNum.put("AUGUST", 8);
		monthNum.put("SEPTEMBER", 9);
		monthNum.put("OCTOBER", 10);
		monthNum.put("NOVEMBER", 11);
		monthNum.put("DECEMBER", 12);
		try {
			String presentTitle = lblMonthTitle.getText().toUpperCase();
			LocalDate now = LocalDate.now().withMonth(monthNum.get(monthTitleBefore.toUpperCase()));
			LocalDate earlier = now.minusMonths(1);
			LocalDate future = now.plusMonths(1);
			if (addOrMinus.contentEquals("Next")) {
				if (presentTitle.equalsIgnoreCase(future.getMonth().toString())) {
					status = true;
					LogUtility.logInfo("---> checkCalendarTitle <---",
							"Calendar title is displayed correctly for next month button");
				}
			} else if (addOrMinus.equalsIgnoreCase("Previous")) {
				if (presentTitle.equalsIgnoreCase(earlier.getMonth().toString())) {
					status = true;
					LogUtility.logInfo("---> checkCalendarTitle <---",
							"Calendar title is displayed correctly for previous month button");
				}
			}

		} catch (Exception e) {
			LogUtility.logException("checkCalendarTitle", "Failed to check calendar title ", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To click on the dates with existing payments
	 * 
	 * @param paymentType
	 * @return
	 * @throws Exception
	 */
	public String clickOnDatesWithPayments(String paymentType) throws Exception {
		List<WebElement> list = listExistingPaymentDates;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateClicked = "";
		try {
			Calendar cal = Calendar.getInstance();
			Calendar cal1 = Calendar.getInstance();
			for (WebElement ele : list) {
				Date date = sdf.parse(ele.getAttribute("data-date"));
				cal1.setTime(date);
				if (paymentType.equalsIgnoreCase("Future")) {
					if (cal1.after(cal) || cal1.equals(cal)) {
						webActions.clickElementJS(ele);
					}
				} else if (paymentType.equalsIgnoreCase("Past")) {
					if (cal1.before(cal)) {
						webActions.clickElementJS(ele);
					}
				} else {
					webActions.clickElementJS(list.get(list.size() - 1));
				}
				dateClicked = webActions.getText(ele);

				break;
			}
			LogUtility.logInfo("---> clickOnDatesWithPayments <---", "Clicked on the date " + dateClicked);
		} catch (Exception e) {
			LogUtility.logException("clickOnDatesWithPayments", "Failed to click on dates with payments", e,
					LoggingLevel.ERROR, true);
		}
		return dateClicked;

	}

	/**
	 * To click on the action icon for an existing payment
	 * 
	 * @param paymentType
	 * @throws Exception
	 */
	public void clickOnActionIconForExistingPayments(String paymentType) throws Exception {
		waits.waitVisibilityOfAllElements(listExistingPaymentsInLB);
		List<WebElement> list = listExistingPaymentsInLB;
		try {
			if (!paymentType.equals("LastDay")) {
				webActions.clickElementJS(driver
						.findElements(By.xpath(existingPaymentActionMenu.replace("ReplaceMe", paymentType))).get(0));
				waits.waitForDOMready();
				webActions.clickElementJS(
						driver.findElement(By.xpath(existingPaymentDetails.replace("ReplaceMe", paymentType))));
			} else {
				for (WebElement ele : list) {
					webActions.clickElement(ele.findElement(By.xpath(actionMenu)));
					webActions.clickElementJS(ele.findElement(By.xpath(navLink)));
					break;
				}
			}
			LogUtility.logInfo("---> clickOnActionIconForExistingPayments <---", "Clicked on the ActionMenu");
		} catch (Exception e) {
			LogUtility.logException("clickOnActionIconForExistingPayments", "Failed to click on ActionMenu", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * // * To check the page title for Update and Deleting pending payments // * //
	 * * @param actionType // * @return //
	 */
	public boolean checkPageTitleInUpdatePaymentDetails(String actionType) {

		String text = null;
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(udpTitle, maxTimeOut);
			text = udpTitle.getText();
			if (text.equalsIgnoreCase(actionType)) {
				LogUtility.logInfo("---> checkPageTitleInUpdatePaymentDetails <---",
						"Correct pagetitle " + actionType + " is displayed");
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkPageTitleInUpdatePaymentDetails", "Failed to check update payment title", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForActiveDates() {
		boolean status = false;
		try {
			if (listActiveDates.size() == 0 || listActiveDates.isEmpty()) {
				status = true;
				LogUtility.logInfo("---> checkForActiveDates <---", "Calendar is not active");
			}
		} catch (Exception e) {
			LogUtility.logException("checkForActiveDates", "Failed to check for active dates", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To select the active dates from the calendar
	 * 
	 * @param paymentType
	 * @return
	 * @throws Exception
	 */
	public String clickOnActiveDates(String paymentType) throws Exception {
		int previuos_list_size = 0;
		List<WebElement> allDatesList = listActiveDates;
		List<WebElement> list = new ArrayList<>();
		String dateClicked = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar today = Calendar.getInstance();
		Calendar cal1 = Calendar.getInstance();
		for (WebElement ele : allDatesList) {
			Date date = sdf.parse(ele.getAttribute("data-date"));
			cal1.setTime(date);

			if (!cal1.before(today) || cal1.get(Calendar.DAY_OF_MONTH) == today.get(Calendar.DAY_OF_MONTH)) {
				list.add(ele);
			}
		}
		previuos_list_size = list.size();
		try {
			waits.staticWait(3);
			if (paymentType.equalsIgnoreCase("Electronic")) {
				if (list.size() > 1) {
					webActions.clickElementJS(list.get(1));
					dateClicked = webActions.getText(list.get(1));
				} else {
					webActions.clickElement(btnNext);
					list.clear();
					list = listDates;
					webActions.clickElementJS(list.get(0));
					dateClicked = webActions.getText(list.get(0));
				}
			} else if (paymentType.equalsIgnoreCase("Check")) {
				if (list.size() >= 3) {
					webActions.clickElementJS(list.get(3));
					dateClicked = webActions.getText(list.get(3));
				} else {
					webActions.clickElement(btnNext);
					list.clear();
					list = listDates;
					webActions.clickElementJS(list.get(3 - previuos_list_size));
					dateClicked = webActions.getText(list.get(3 - previuos_list_size));
				}
			} else if (paymentType.equalsIgnoreCase("LastDay")) {
				if (list.size() == 0 || list.size() == 1) {
					webActions.clickElement(btnNext);
					waits.waitForPageToLoad(maxTimeOut);
					list.clear();
					list = listDates;
				}
				dateClicked = webActions.getText(list.get(list.size() - 1));
				webActions.clickElementJS(list.get(list.size() - 1));

			} else if (paymentType.equalsIgnoreCase("Today")) {
				webActions.clickElementJS(list.get(0));
				dateClicked = webActions.getText(list.get(0));
			} else {
				if (list.size() >= Integer.parseInt(paymentType)) {
					list.get(Integer.parseInt(paymentType));
				} else {
					webActions.clickElement(btnNext);
					list.clear();
					list = listDates;
					webActions.clickElementJS(list.get(Integer.parseInt(paymentType) - previuos_list_size));
				}
			}
			LogUtility.logInfo("---> clickOnActiveDates <---", "Clicked on the date " + dateClicked);
		} catch (IndexOutOfBoundsException e) {
			LogUtility.logException("clickOnActiveDates", "Failed to click on active dates", e, LoggingLevel.ERROR,
					true);
		}
		return dateClicked;
	}

	/**
	 * To select the active dates from the calendar
	 * 
	 * @param paymentType
	 * @return
	 * @throws Exception
	 */
	public String clickOnFutureDatesForAlert(int days) throws Exception {
		int previuos_list_size = 0;
		List<WebElement> allDatesList = listActiveDates;
		List<WebElement> list = new ArrayList<>();
		String dateClicked = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar today = Calendar.getInstance();
		Calendar cal1 = Calendar.getInstance();
		for (WebElement ele : allDatesList) {
			Date date = sdf.parse(ele.getAttribute("data-date"));
			cal1.setTime(date);
			if (!cal1.before(today)) {
				list.add(ele);
			}
		}
		previuos_list_size = list.size();
		try {
			waits.staticWait(3);
			if (days >= previuos_list_size) {
				webActions.clickElementJS(btnNext);
				list.clear();
				list = listDates;
				if (days - previuos_list_size == 0) {
					webActions.clickElementJS(list.get(0));
					dateClicked = list.get(0).getAttribute("data-date");
				} else {
					webActions.clickElementJS(list.get(days - previuos_list_size));
					dateClicked = list.get(days - previuos_list_size).getAttribute("data-date");
				}
			} else {
				webActions.clickElementJS(list.get(days));
				dateClicked = list.get(days).getAttribute("data-date");
			}

			LogUtility.logInfo("---> clickOnFutureDatesForAlert <---", "Clicked on the date " + dateClicked);
		} catch (IndexOutOfBoundsException e) {
			LogUtility.logException("clickOnFutureDatesForAlert", "Failed to click on active dates", e,
					LoggingLevel.ERROR, true);
		}
		return dateClicked;
	}

	/**
	 * To check if the expected message is same as the parameter
	 * 
	 * @param strMsg
	 * @return
	 */
	public boolean verifyForTheMessage(String strMsg) {
		boolean status = false;
		try {
			WebElement ele = driver.findElement(By.xpath(msg.replaceAll("ReplaceMe", strMsg)));
			if (waits.waitUntilElementIsPresent(ele, maxTimeOut)) {
				{
					LogUtility.logInfo("---> verifyForTheMessage <---", "Message " + strMsg + " is present");
					status = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyForTheMessage", "Failed to check for the message " + strMsg, e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check if the expected message is same as the parameter in lightbox
	 * 
	 * @param msg
	 * @return
	 */
	public boolean verifyForTheMessageInLightBox(String msg) {
		boolean status = false;
		waits.staticWait(4);
		try {
			WebElement ele = driver.findElement(By.xpath(lightBoxMsg.replaceAll("ReplaceMe", msg)));
			if (waits.waitUntilElementIsPresent(ele, maxTimeOut)) {
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyForTheMessageInLightBox",
					"Failed to check for the message in lightbox : " + msg, e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To enter the given payment details in the lightbox
	 * 
	 * @param paymentDetails
	 * @throws InterruptedException
	 */
	public void enterPaymentDetails(List<Map<String, String>> paymentDetails) throws Exception {
		waits.waitForPageToLoad(maxTimeOut);
		waits.waitUntilElementIsPresent(amountTxtBox, maxTimeOut);
		LinkedHashMap<String, String> eachPayment = new LinkedHashMap<String, String>();
		boolean flag = false;
		try {
			if (!paymentDetails.get(0).get("PayFrom").equalsIgnoreCase("AnyAccount"))
				webActions.selectDropDownByText(selPayFrom, paymentDetails.get(0).get("PayFrom"));

			if (!paymentDetails.get(0).get("PayTo").equalsIgnoreCase(""))

				wolWebUtil.selectValueByPartialText(selPayTo, paymentDetails.get(0).get("PayTo"));

			webActions.setValue(amountTxtBox, paymentDetails.get(0).get("Amount"));
			webActions.setValue(memoTxtBox, paymentDetails.get(0).get("Memo"));

			waits.waitForPageToLoad(maxTimeOut);

			String debitDate = webActions.getText(txtDebitDate);
			if (paymentDetails.get(0).get("PayTo").equalsIgnoreCase("")) {
				if (debitDate.equals("N/A"))
					LogUtility.logInfo("", "Debit date is N/A as payto is not slected");
			} else if (paymentDetails.get(0).get("Type").equals("Check")) {
				if (!debitDate.equals("When Cashed"))
					flag = true;
			} else if (paymentDetails.get(0).get("Type").equals("Electronic")) {
				if (!debitDate.equals(wolWebUtil.changeTheDatePattern("MMM dd, yyyy", "MMM d, yyyy", debitDate)))
					flag = true;
			}
			if (flag) {
				throw new Exception("Debit date is not displayed correct for the payee");
			}
			eachPayment.put("PayFrom", wolWebUtil.getDefaultValueForSelect(selPayFrom));
			eachPayment.put("PayTo", wolWebUtil.getDefaultValueForSelect(selPayTo));
			eachPayment.put("Delivery Date", webActions.getText(txtDelDate));
			eachPayment.put("Debit Date", debitDate);
			eachPayment.put("Amount", paymentDetails.get(0).get("Amount"));
			enteredPayments.add(eachPayment);

			waits.waitForPageToLoad(maxTimeOut);
		} catch (Exception e) {
			LogUtility.logException("enterPaymentDetails", "Error in entering payment detail", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * To check if the given payment details are displayed correct in the table
	 * 
	 * @param dataTable
	 * @return
	 * @throws InterruptedException
	 */
	public boolean checkPaymentDetails(List<Map<String, String>> dataTable) throws InterruptedException {
		boolean status = true;
		try {
			String temp = "";
			wolWebUtil.scrollToElement(listPaymentsAdded.get(0));
			for (int i = 1; i <= listPaymentsAdded.size(); i++) {
				LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
				for (int j = 0; j < 5; j++) {
					temp = paymentDetail.replaceAll("Column", String.valueOf(j)).replaceAll("Row", String.valueOf(i));
					map.put(webActions.getAttributeValue(driver.findElement(By.xpath(temp)), "aria-label"),
							webActions.getText(driver.findElement(By.xpath(temp))));
				}
				enteredPaymentsVerify.add(map);
			}
			for (int i = 0; i < dataTable.size(); i++) {
				LinkedHashMap<String, String> linkedMap = new LinkedHashMap<String, String>(dataTable.get(i));
				if (!wolWebUtil.mapValuesComaparison(linkedMap, enteredPaymentsVerify.get(i))) {
					status = false;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkPaymentDetails", "Error in checking payment detail", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To change the type of account selected from Payfrom dropdpwn
	 * 
	 * @param accountType
	 * @throws Exception
	 */
	public void selectTheAccountTypeFromPayFromDropDown(String accountType) throws Exception {

		webActions.clickElement(selPayFrom);
		try {
			List<WebElement> list = new ArrayList<>();
			if (accountType.equals("Personal Accounts"))
				list = lstPersonalPayFromDropdown;
			else
				list = lstBusinessPayFromDropdown;
			list.get(0).click();
		} catch (Exception e) {
			LogUtility.logException("selectTheAccountTypeFromPayFromDropdown",
					"Error in selecting account from payFrom dropdown", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * To enter the data given in the amount field
	 * 
	 * @param value
	 * @throws Exception
	 */
	public void enterInvalidDataInAmountField(String value) throws Exception {
		try {
			waits.waitUntilElementIsPresent(amountTxtBox, maxTimeOut);
			webActions.setValue(amountTxtBox, value);
			amountTxtBox.sendKeys(Keys.TAB);
		} catch (Exception e) {
			LogUtility.logException("enterInvalidDataInAmountField", "Error in enter invalid data", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * To check if valid error message is displayed
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean checkForErrorMessage(String errorMsg) {
		boolean flag = false;
		waits.waitForPageToLoad(maxTimeOut);
		try {
			String actualMsg = webActions.getText(amountErrorMsg);
			if (actualMsg.equalsIgnoreCase(errorMsg)) {
				LogUtility.logError("---> checkForErrorMessage <---", "Error Message " + errorMsg + " is found");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkForInvalidAmountErrorMessage", "Error in check error message " + errorMsg, e,
					LoggingLevel.ERROR, true);
		}
		return flag;

	}

	/**
	 * To check if valid error message is displayed for PayTo dropdown
	 * 
	 * @param errorMsg
	 * @return
	 */
	public boolean checkForErrorMessagePayToDropDown(String errorMsg) {
		boolean flag = false;
		waits.waitForPageToLoad(maxTimeOut);
		waits.waitUntilElementIsPresent(payToErrorMsg);
		try {
			String actualMsg = webActions.getText(payToErrorMsg);
			if (actualMsg.equalsIgnoreCase(errorMsg)) {
				LogUtility.logInfo("---> checkForErrorMessagePayToDropDown <---",
						"Error Message " + errorMsg + " is found");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("checkForErrorMessagePayToDropDown",
					"Failed to check error message for payto dropdown " + errorMsg, e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To check if add Payment dialog box is displayed
	 * 
	 * @return
	 */
	public boolean checkForAddPaymentDialogueBox() {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			if (waits.waitUntilElementIsPresent(dialogBox))
				flag = true;

		} catch (Exception e) {
			LogUtility.logException("checkForAddPaymentDialogueBox", "Failed to check for add payment dialogue box", e,
					LoggingLevel.ERROR, true);
		}
		return flag;

	}

	public void changePaymentFrequency(String arg1) {

		try {
			waits.waitUntilElementIsPresent(lstFrequency);
			webActions.selectDropDownByText(lstFrequency, arg1);
		} catch (Exception e) {
			LogUtility.logException("changePaymentFrequency", "Failed to change payment frequency", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * To check all the required filed labels are present in the Bill Payment
	 * Details page
	 * 
	 * @param list
	 * @throws Exception
	 */
	public String checkTheColumnsInBillPayeeDetailsPage(List<String> list) throws Exception {
		String col = "";
		try {
			for (String ele : list) {
				if (waits.waitUntilElementIsPresent(
						billPaymentDetails.findElement(By.xpath(billDetailLabel.replaceAll("ReplaceMe", ele))),
						maxTimeOut)) {
					col = col + ele + ",";
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheColumnsInBillPayeeDetailsPage",
					"Failed to find the details in bill payee details page", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return col;
	}

	/**
	 * To check if the dialog box opened for the disclosure agreement
	 * 
	 * @param payment
	 * @return
	 */
	public boolean checkForDisclosureDialogBoxes(String payment) {
		boolean status = false;
		waits.waitForPageToLoad(maxTimeOut);
		try {
			if (payment.equalsIgnoreCase("Check")) {
				waits.waitUntilElementIsPresent(disclosureCheck);
				status = true;
			} else {
				waits.waitUntilElementIsPresent(disclosureElectronic);
				status = true;
			}
		} catch (Exception e) {
			LogUtility.logException("checkForDisclosureDialogBoxes", "Failed to find the disclosure dialog box", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check if the dialog box opened for the disclosure agreement
	 * 
	 * @param payment
	 * @return
	 */
	public boolean checkTheMessageInPage(String msgType, String lookFor) {

		String actMsg = "";
		boolean status = false;
		try {
			switch (msgType) {
			case "SuccessfulPaymentSchedule":
				waits.waitUntilElementIsPresent(lblSuccesPaymentMsg, maxTimeOut);
				actMsg = webActions.getText(lblSuccesPaymentMsg);
				break;
			case "NoPersonalPayeeError":
				waits.waitUntilElementIsPresent(lblNoPayeeMsg, maxTimeOut);
				actMsg = webActions.getText(lblNoPayeeMsg);
				break;
			case "NoBusinessPayeeError":
				waits.waitUntilElementIsPresent(lblNoBusinessPayeeMsg, maxTimeOut);
				actMsg = webActions.getText(lblNoBusinessPayeeMsg);
				break;
			case "NoAccountsErrorMsg":
				waits.waitUntilElementIsPresent(lblNoBusinessPayeeMsg, maxTimeOut);
				actMsg = webActions.getText(lblNoBusinessPayeeMsg);
				break;
			default:
				LogUtility.logError("---> checkTheMessageInPage <---", "Message " + lookFor + " is found");
				break;
			}
			actMsg = actMsg.trim();
			if (actMsg.equals(lookFor)) {
				LogUtility.logInfo("---> checkTheMessageInPage <---", "Invalid message " + msgType);
				status = true;
			}

		} catch (Exception e) {
			LogUtility.logException("checkTheMessageInPage", "Failed to find the message", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To close the dialog box opened for the disclosure agreement
	 * 
	 * @param payment
	 */
	public void closeForDisclosureDialogBoxes(String payment) {
		try {
			if (payment.equalsIgnoreCase("Check")) {
				webActions.clickElement(btnDisclosureContinueForC);
			} else
				webActions.clickElement(btnDisclosureContinueForE);
		} catch (Exception e) {
			LogUtility.logException("closeForDisclosurDialoBoxes", "Failed to find close discloure button", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To click on Edit or delete payment button
	 * 
	 * @param actiomType
	 * @param payeeName
	 * @throws Exception
	 */
	public void clickOnEditOrDeletePayment(String actiomType, String payeeName) throws Exception {
		try {

			if (actiomType.equals("Edit"))
				webActions.clickElement(
						listPaymentsAdded.get(0).findElement(By.xpath(editButton.replaceAll("ReplaceMe", payeeName))));
			else {
				webActions.clickElement(listPaymentsAdded.get(0)
						.findElement(By.xpath(deleteButton.replaceAll("ReplaceMe", payeeName))));
				waits.staticWait(3);
				alerts.acceptAlert();
				waits.staticWait(3);
			}

			LogUtility.logInfo("---> clickOnEditOrDeletePayment <---", "Clicked on " + actiomType + " button");
		} catch (Exception e) {
			LogUtility.logException("clickOnEditOrDeletePayment", "Failed to click on delete or edit button", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * To click on the update payment button in lightbox
	 */
	public boolean clickOnUpdatePaymentLightBox() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnUpdatePayment)) {
				flag = true;
				webActions.clickElement(btnUpdatePayment);
			}
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitUntilElementIsPresent(btnReviewPayments, maxTimeOut);
		} catch (Exception e) {
			LogUtility.logException("clickOnUpdatePaymentLightbox", "Failed to click on update payment light box", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * Check for the page heading Make A New payment
	 * 
	 * @return
	 */
	public boolean checkForMakeNewPaymentPage() {
		waits.waitUntilElementIsPresent(txtMakeNewPayHeading);
		return wolWebUtil.verifyText(txtMakeNewPayHeading, "Make a New Payment");

	}

	public boolean checkTheToolTipVerifyPage(String message) {
		boolean status = false;
		try {
			if (wolWebUtil.checkTheTooltipMessage(debitDateToolTip, message)) {
				status = true;
				LogUtility.logInfo("---> checkForMakeNewPaymentPage <---", "Tooltip is correct");

			}
		} catch (Exception e) {
			LogUtility.logException("checkForMakeNewPaymentPage", "Failed to find the tooltip", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To select no of days before alert should start
	 * 
	 * @param days
	 */
	public boolean selectFromDaysBeforeAlertDropDown(String days) {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(lstAlertsDaysBefore)) {
				webActions.selectDropDownByText(lstAlertsDaysBefore, days + " Days");
				status = true;
				LogUtility.logInfo("---> selectFromDaysBeforeAlertDropdown <---",
						"Selected " + days + " Days from Alerts Page dropdown");
			}
		} catch (Exception e) {
			LogUtility.logException("selectFromDaysBeforeAlertDropDown",
					"Error in selecting days from the alert dropdown", e, LoggingLevel.ERROR, true);
		}
		return status;
	}
}