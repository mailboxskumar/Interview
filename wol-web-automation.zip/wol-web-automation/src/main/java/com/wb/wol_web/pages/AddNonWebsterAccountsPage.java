
package com.wb.wol_web.pages;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */

public class AddNonWebsterAccountsPage extends ObjectBase {

	public HashMap<String, String> details = new HashMap<>();
	public HashMap<String, String> detailsFromUI = new HashMap<>();
	public String tableInWebcomXpath = "table:nth-child(3)";
	public String dataTable = "table";
	public String accNumberAndRoutingNumber = "";
	public String delAccname = "";

	public AddNonWebsterAccountsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='errorIndicator']//p")
	protected WebElement txtErrorMsg;

	@FindBy(xpath = "//table[@class='data_grid']//following-sibling::p[2]")
	protected WebElement txtMsgInProcessInCentre;

	@FindBy(xpath = "//a[text()='View details.']")
	protected WebElement linkViewDetails;

	@FindAll(@FindBy(css = "[id*='messageSmallTalkRequired'][class=' bodyMessage']"))
	protected List<WebElement> txtSmallTalk;

	@FindBy(id = "nextId")
	protected WebElement btnNext;

	@FindBy(css = "table")
	protected WebElement tableManageTransfers;

	@FindBy(name = "rtnumber")
	protected WebElement inputRoutingNumber;

	@FindBy(name = "acctnumber")
	protected WebElement inputAcctNumber;

	@FindBy(name = "payeeaccttype")
	protected WebElement selAccType;

	@FindBy(name = "nickname")
	protected WebElement inputNickName;

	@FindBy(name = "reviewed")
	protected WebElement chkReview;

	@FindBy(id = "ContinueButton")
	protected WebElement btnContinue;

	@FindBy(id = "CancelButton")
	protected WebElement btnCancel;

//	@FindBy(xpath = "//h3[@data-wbst-message-key='payee.nwacct.title']")
	@FindBy(css = "div.pageHeaderBlock h3")
	protected WebElement txtAddNonWebAcctHeading;

	@FindBy(css = "[data-wbst-message-key='payee.nwacct.error.8009a']")
//	@FindBy(css = "div.pageHeaderBlock h3")
	protected WebElement txtExistingAccErrorMsg;

//	@FindBy(xpath = "//p[@data-wbst-message-key='payee.nwacct.transfer.inprocess.error']")
	@FindBy(css = "[data-wbst-message-key='payee.nwacct.transfer.inprocess.error']")
	protected WebElement txtInProcessErrorMsg;

//	@FindBy(xpath = "//h3[@data-wbst-message-key='payee.nwacct.title.confirmation']")
	@FindBy(css = "div.pageHeaderBlock h3")
	protected WebElement txtAddNonWebAcctConfirmHeading;

//	@FindBy(xpath = "//h3[@data-wbst-message-key='payee.nwacct.managePayees']")
	@FindBy(css = "div.pageHeaderBlock h3")
	protected WebElement manageNonWebAccTitle;

	@FindBy(css = "div.pageHeaderBlock h3")
	protected WebElement manageUpdateNonWebAccTitle;

	@FindAll(@FindBy(css = "form#externalTransfer label"))
	protected List<WebElement> lstDataLabels;

	@FindAll(@FindBy(css = "form#externalTransfer div.data"))
	protected List<WebElement> lstDataValues;

	@FindBy(id = "megaMenuSectionSidebar__SubMenuForSidebar3_Heading3_Item1__navigationLink")
	protected WebElement linkHowExtTrnsfrWork;

	@FindBy(id = "megaMenuSectionSidebar__SubMenuForSidebar3_Heading3_Item2__navigationLink")
	protected WebElement linkHowMuchCanITransfr;

	@FindBy(id = "megaMenuSectionSidebar__SubMenuForSidebar3_Heading3_Item3__navigationLink")
	protected WebElement linkWhatAccCanITrnstr;

	@FindBy(id = "megaMenuSectionSidebar__SubMenuForSidebar3_Heading3_Item4__navigationLink")
	protected WebElement linkReadFAQ;

	@FindBy(id = "page-title")
	protected WebElement linkPageHeading;

	@FindBy(css = "section#content p")
	protected WebElement txtPageContent;

	@FindBy(name = "isDelete")
	protected WebElement btnDeleteManageAccount;

	@FindBy(id = "publicLoggedInBlock")
	protected WebElement sectionLoggedIn;

	@FindBy(xpath = "//strong[text()='Your Account']")
	protected WebElement btnYourAccount;

	@FindBy(xpath = "//input[@name='acctnumber']/..//img")
	protected WebElement acctNumberTooltip;

	@FindBy(xpath = "//input[@name='nickname']/..//img")
	protected WebElement nickNameToolTip;

	@FindBy(xpath = "//input[@name='acctnumber']/..//img/..")
	protected WebElement txtAcctNumberToolTip;

	@FindBy(xpath = "//input[@name='nickname']/..//img/..")
	protected WebElement txtNickNameToolTip;

	@FindBy(xpath = "//table")
	protected WebElement tableManageAccounts;

	@FindBy(name = "nickname")
	protected WebElement inputNickNameManageAcc;

	@FindBy(id = "websterLogoColor")
	protected WebElement logoWebster;

	@FindBy(id = "NWTransDiscCon-Ok")
	protected WebElement btnOkAgreement;

	@FindBy(xpath = "//div[@class='lightbox-wrap is-visible is-top']//button[@aria-label='Close the dialog']")
	protected WebElement btnCloseAgreement;

	@FindBy(id = "agreement_link")
	protected WebElement linkAgreement;

	@FindBy(xpath = "(//table)[2]")
	protected WebElement tableInWebCom;

	@FindBy(id = "progressBarG")
	protected WebElement idProgressBar;

	@FindBy(id = "payee.nwacct.error.manage.noaccounts")
	protected WebElement txtNoAccountsMsg;

	/**
	 * Check for the page heading
	 * 
	 * @param pageHeading
	 * @return
	 */
	public boolean checkForTheHeading(String pageHeading, String checkFor) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (checkFor) {
			case "AddAccount":
				eleToGetText = txtAddNonWebAcctHeading;
				break;
			case "AddAccountConfirmation":
				eleToGetText = txtAddNonWebAcctConfirmHeading;
				break;
			case "ManageTransfer":
				eleToGetText = manageNonWebAccTitle;
				break;
			case "ManageTransferConfirmation":
				eleToGetText = manageUpdateNonWebAccTitle;
				break;
			default:
				LogUtility.logError("Invalid page type " + checkFor);
			}

			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (wolWebUtil.verifyText(eleToGetText, pageHeading)) {
				status = true;
				LogUtility.logInfo("checkForTheHeading", "Reached the page " + pageHeading);
			} else
				LogUtility.logError("checkForTheHeading", "Could not find the heading " + pageHeading);
		} catch (Exception e) {
			LogUtility.logException("checkForTheHeading", "Failed to find the heading " + pageHeading, e,
					LoggingLevel.ERROR, true);

		}
		return status;
	}

	/**
	 * To enter all the details of non webster account details
	 * 
	 * @param fileType
	 * @param accType
	 * @throws Exception
	 */
	public void enterNonWebsterAccDetails(String accType, String fileType, Map<String, String> routingNumberMap)
			throws Exception {
		try {
			String accNumber = wolWebUtil.getRandomNumber(8);
			String nickName = wolWebUtil.getRandomString(6);
			webActions.setValue(inputRoutingNumber, routingNumberMap.get(accType));
			details.put(routingNumberMap.get("First Column"), routingNumberMap.get(accType));
			webActions.setValue(inputAcctNumber, accNumber);
			details.put(routingNumberMap.get("Second Column"), accNumber);
			webActions.setValue(inputNickName, nickName);
			details.put(routingNumberMap.get("Third Column"), nickName);
			if (fileType.equals("Checking"))
				webActions.selectDropDownByValueJs(selAccType, "1");
			else
				webActions.selectDropDownByValueJs(selAccType, "3");
			details.put(routingNumberMap.get("Fourth Column"), fileType);
			webActions.clickElement(chkReview);
			webActions.clickElement(btnContinue);
			LogUtility.logInfo("enterNonWebsterAccDetails", "Entered all non webster account details");
		} catch (Exception e) {
			LogUtility.logException("enterNonWebsterAccDetails", "Failed to entered all non webster account details", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * gets the data from the confirmation page and returns it
	 * 
	 * @return
	 */
	public HashMap<String, String> validateConfirmationDetails() {

		try {
			for (int i = 0; i < lstDataLabels.size(); i++) {
				detailsFromUI.put(lstDataLabels.get(i).getText(), lstDataValues.get(i).getText());
			}
			LogUtility.logInfo("validateConfirmationDetails", " Details are " + detailsFromUI);
		} catch (Exception e) {
			LogUtility.logException("validateConfirmationDetails", "Failed to get details", e, LoggingLevel.ERROR,
					true);
			throw (e);
		}
		return detailsFromUI;

	}

	/*
	 * returns true if the required status of the account is displayed correct in
	 * the Manage Non Webster accounts page
	 * 
	 * @return
	 */
	public boolean getAccountStatusTableData(String accStatus) {
		boolean status = false;
		try {
			HashMap<Integer, String> otherColValues = new HashMap<>();
			otherColValues.put(2, "xxxxxx" + details.get("Account #").substring(4));
			otherColValues.put(4, details.get("Account Nickname"));
			otherColValues.put(3, accStatus);
			status = wolWebUtil.checkFromTableDataWithColNumbers(dataTable, otherColValues, 0);
			if (status) {
				LogUtility.logInfo("getAccountStatusTableData", "Account status is as expected " + accStatus);
			} else
				LogUtility.logInfo("getAccountStatusTableData", "Account status is not same as expected" + accStatus);

		} catch (Exception e) {
			LogUtility.logException("getAccountStatusTableData", "Failed to get Account status", e, LoggingLevel.ERROR,
					true);
		}
		return status;

	}

	/**
	 * Clicks on the links present at the right bottom part of the page
	 * 
	 * @param linkText
	 * @throws Exception
	 */
	public boolean clickOnTheLink(String linkText) throws Exception {
		boolean flag = false;
		WebElement eleToClick = null;
		try {
			if (linkText.contains("How do external transfers work?"))
				eleToClick = linkHowExtTrnsfrWork;
			else if (linkText.equals("How much can I transfer to or from a non-Webster account?"))
				eleToClick = linkHowMuchCanITransfr;
			else if (linkText.equals("What non-Webster accounts can I transfer from or to?"))
				eleToClick = linkWhatAccCanITrnstr;
			else
				eleToClick = linkReadFAQ;
			if (waits.waitUntilElementIsPresent(eleToClick, maxTimeOut)) {
				webActions.clickElement(eleToClick);
				flag = true;
				LogUtility.logInfo("--->ClickOnTheLink<---", "Clicked on the link " + linkText);
			} else
				LogUtility.logError("ClickOnTheLink", "Could not click the link");
		} catch (Exception e) {
			LogUtility.logException("ClickOnTheLink", "Error while clicking on the link" + linkText, e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		return flag;
	}

	/**
	 * Checks the heading and the page content
	 * 
	 * @param heading
	 * @param content
	 * @return
	 */
	public boolean checkForTheHeadingAndContent(String heading, String content) {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(linkPageHeading, maxTimeOut);
			if (webActions.getText(linkPageHeading).equals(heading)) {
				if (webActions.getText(txtPageContent).contains(content)) {
					status = true;
					LogUtility.logInfo("--->checkForTheHeadingAndContent<---",
							"Heading and the page content are as expected for the page " + heading);
				} else {
					LogUtility.logError("--->checkForTheHeadingAndContent<---",
							"Page content is not as expected for the page " + heading);
				}
			} else {
				LogUtility.logError("--->checkForTheHeadingAndContent<---",
						"Page heading is not as expected for the page " + heading);
			}
		} catch (Exception e) {
			LogUtility.logException("checkForTheHeadingAndContent", "Exception while checking the page heading  ", e,
					LoggingLevel.ERROR, true);

		}

		return status;
	}

	/**
	 * Opens a new tab and closes the old tab
	 * 
	 * @throws Exception
	 */
	public void openNewWindowAndCloseCurrentWindow() throws Exception {
		try {
			wolWebUtil.openANewBlankTab();
			wolWebUtil.CloseAndSwitchFocusToNewtab();
			LogUtility.logInfo("--->openNewWindowandcloseCurrentWindow<---",
					"Opened a new tab and closed the old one ");
		} catch (Exception e) {
			LogUtility.logException("openNewWindowandcloseCurrentWindow",
					"Error while closing current tab and opening a new tab ", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Checks if the user is still logged in after the browser tab is closed
	 * 
	 * @return
	 */
	public boolean checkIfUserIsStillLoggedIn() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(sectionLoggedIn, maxTimeOut)) {
				status = true;
				LogUtility.logInfo("checkIfUserIsStillLoggedIn", "user is still logged in");
			} else
				LogUtility.logError("checkIfUserIsStillLoggedIn", "Could not find the user is still logged in ");
		} catch (Exception e) {
			LogUtility.logException("checkIfUserIsStillLoggedIn", "Error while checking iof user is still logged in ",
					e, LoggingLevel.ERROR, true);

		}
		return status;
	}

	/**
	 * Clicks on the button "Return to Your Account"
	 * 
	 * @throws Exception
	 */
	public void clickOnReturnToYourAccount() throws Exception {
		try {
			waits.waitUntilElementIsPresent(btnYourAccount, maxTimeOut);
			webActions.clickElement(btnYourAccount);
			LogUtility.logInfo("--->clickOnReturntoYourAccount<---", "Clicked on your account link ");
		} catch (Exception e) {
			LogUtility.logException("clickOnReturntoYourAccount", "Error while clicking on your account link ", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Navigates back to one page
	 * 
	 * @throws Exception
	 */
	public void navigateBack() throws Exception {
		try {
			wolWebUtil.navigateBack();
			LogUtility.logInfo("--->navigateBack<---", "Navigated back");
		} catch (Exception e) {
			LogUtility.logException("navigateBack", "Error while navigating back ", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Clicks on the edit account link if the given string is present in that row
	 * 
	 * @param accName
	 * @throws Exception
	 */
	public void clickOnTheTableElementToEditAccount(String accName) throws Exception {
		try {
			wolWebUtil.clickOnTableCell(tableManageAccounts, accName);
			LogUtility.logInfo("--->clickOnTheTableELementToEditAccount<---", "Clicked on the element " + accName);
		} catch (Exception e) {
			LogUtility.logException("clickOnTheTableELementToEditAccount", "Exception while clicking element in table",
					e, LoggingLevel.ERROR, true);

			throw e;
		}
	}

	/**
	 * Updates the nick name
	 * 
	 * @throws Exception
	 */
	public void updateNickName() throws Exception {
		try {
			webActions.clearValue(inputNickNameManageAcc);
			webActions.setValue(inputNickNameManageAcc, wolWebUtil.getRandomString(5));
			webActions.clickElement(btnContinue);
			LogUtility.logInfo("--->updateNickName<---", "Updated nick name");

		} catch (Exception e) {
			LogUtility.logException("updateNickName", "Exception while updating nick name", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	/**
	 * Checks the status of the account in webcom which was added in WOL application
	 * is same as expected * @param accStatus
	 * 
	 * @return
	 */
	public boolean checkTheStatusOfTheAccountAddedInWebcom(String accStatus) {
		boolean status = false;
		try {
			HashMap<Integer, String> otherColValues = new HashMap<>();
			otherColValues.put(4, details.get("Account #"));
			otherColValues.put(5, details.get("Account Nickname"));
			otherColValues.put(6, accStatus);
			status = wolWebUtil.checkFromTableDataWithColNumbers(tableInWebcomXpath, otherColValues, 0);
			if (status)
				LogUtility.logInfo("checkTheStatusOFTheAccountAddedInWebcom",
						" Status in webcom is same as expected " + accStatus);
			else
				LogUtility.logError("checkTheStatusOFTheAccountAddedInWebcom", "Could not find the same status ");
		} catch (Exception e) {
			LogUtility.logException("checkTheStatusOFTheAccountAddedInWebcom",
					"Exception while checking the status in webcom", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Checks if the progress bar is present in Non Webster transfer Accounts page
	 * 
	 * @return
	 */
	public boolean checkForProgressBar() {
		boolean status = false;
		try {
			status = waits.waitUntilElementIsPresent(idProgressBar, maxTimeOut);
			if (status)
				LogUtility.logInfo("CheckForProgressBar", "Found the progress bar");
			else
				LogUtility.logError("CheckForProgressBar", "Could not find progress bar ");
		} catch (Exception e) {
			LogUtility.logException("CheckForProgressBar", "Exception while finding progress bar ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Checks if the message is same as the expected value
	 * 
	 * @param message
	 * @param Type
	 * @return
	 */
	public boolean checkForTheMessageInThePage(String message, String Type) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (Type) {
			case "NoAccountsAdded":
				eleToGetText = txtNoAccountsMsg;
				break;
			default:
				LogUtility.logInfo("--->checkForTheMessageInthepage<---", "Invalid message type " + Type);
				break;
			}
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			status = wolWebUtil.verifyText(eleToGetText, message);
			if (status)
				LogUtility.logInfo("--->checkForTheMessageInthepage<---", "Found the message " + message);
			else
				LogUtility.logError("checkForTheMessageInthepage", "Could not find tooltip " + message);
		} catch (Exception e) {
			LogUtility.logException("checkForTheMessageInthepage", "Exception while finding tooltip ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Checks the tooltip text contains the value retrieved from the feature file
	 * 
	 * @param labelType
	 * @param toolTipText
	 * @return
	 */
	public boolean checkTheTooltTipSampleText(String labelType, String toolTipText) {
		WebElement eleToClick = null;
		WebElement eleToGetText = null;
		boolean status = false;
		try {
			switch (labelType) {
			case "AccountNumber":
				eleToClick = acctNumberTooltip;
				eleToGetText = txtAcctNumberToolTip;
				break;
			case "Nickname":
				eleToClick = nickNameToolTip;
				eleToGetText = txtNickNameToolTip;
				break;
			default:
				LogUtility.logError("checkTheTooltTipSampleText", "Invalid label type in " + labelType);
			}
			waits.waitUntilElementIsPresent(acctNumberTooltip, maxTimeOut);
			webActions.clickElement(eleToClick);
			String text = webActions.getAttributeValue(eleToGetText, "data-title");
			if (text.contains(toolTipText)) {
				LogUtility.logInfo("checkTheTooltTipSampleText", "Tool tip is checked");
				status = true;
			} else
				LogUtility.logError("checkTheTooltTipSampleText", "Could not find tooltip " + toolTipText);
		} catch (Exception e) {
			LogUtility.logException("checkTheTooltTipSampleText", "Exception while finding tooltip text ", e,
					LoggingLevel.ERROR, true);

		}
		return status;
	}

	/**
	 * To enter all the details of non webster account details
	 * 
	 * @param fileType
	 * @param accType
	 * @throws Exception
	 */
	public void enterInvalidNonWebsterAccDetails(List<Map<String, String>> accountDetails) throws Exception {
		try {
			webActions.setValue(inputRoutingNumber, accountDetails.get(0).get("RoutingNumber"));
			webActions.setValue(inputAcctNumber, accountDetails.get(0).get("AccountNumber"));
			if (accountDetails.get(0).get("CheckDisclosure").trim().equalsIgnoreCase("Yes") && !chkReview.isSelected())
				webActions.clickElement(chkReview);
			if (accountDetails.get(0).get("AccountType").equals("Select"))
				webActions.selectDropDownByValueJs(selAccType, "-1");
			else if (accountDetails.get(0).get("AccountType").equals("Checking"))
				webActions.selectDropDownByValueJs(selAccType, "1");
			else
				webActions.selectDropDownByValueJs(selAccType, "3");
			webActions.clickElement(btnContinue);
			LogUtility.logInfo("enterInvalidNonWebsterAccDetails", "Entered invalid non webster account details");
		} catch (Exception e) {
			LogUtility.logException("enterInvalidNonWebsterAccDetails",
					"Failed to enter all non webster account details", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * To check the error message occurred on entering invalid data
	 * 
	 * @param message
	 * @throws Exception
	 */
	public boolean checkTheErrorMessage(String message) throws Exception {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(txtErrorMsg, maxTimeOut);
			status = wolWebUtil.verifyTextContains(txtErrorMsg, message);
			if (status)
				LogUtility.logInfo("checkTheErrorMessage", "Error message is displayed");
			else
				LogUtility.logError("checkTheErrorMessage", "Could not find message " + message);
		} catch (Exception e) {
			LogUtility.logException("checkTheErrorMessage", "Failed to get Error message", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check the error message occurred on entering invalid data
	 * 
	 * @param message
	 * @throws Exception
	 */
	public boolean checkTheSmallTalkMessage(String smallTalkType, String message) throws Exception {
		boolean status = false;
		try {
			for (WebElement element : txtSmallTalk) {
				waits.waitUntilElementIsPresent(element, maxTimeOut);
				status = wolWebUtil.verifyTextContains(element, message);
				if (status) {
					LogUtility.logInfo("checkTheSmallTalkMessage", "Small talk message contains:" + element.getText());
					break;
				} else {
					webActions.clickElement(btnNext);
				}
			}
		} catch (Exception e) {
			LogUtility.logException("checkTheSmallTalkMessage", "Failed to get small talk message", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		return status;
	}

	/**
	 * Gives the active state account name
	 */
	public void getActiveStatusAccount() {

		wolWebUtil.clickOnTableCell(tableManageTransfers, "Active");
		try {
			waits.waitForPageToLoad(maxTimeOut);
			accNumberAndRoutingNumber = webActions.getAttributeValue(inputRoutingNumber, "value") + ","
					+ webActions.getAttributeValue(inputAcctNumber, "value");
			LogUtility.logInfo("getActiveStatusAccount", "Clicked on the account" + accNumberAndRoutingNumber);
		} catch (Exception e) {
			LogUtility.logException("getActiveStatusAccount", "Failed to get active account number", e,
					LoggingLevel.ERROR, true);
		}

	}

	/**
	 * Checks for the error message
	 * 
	 * @param errorMsg
	 * @param msgType
	 * @return
	 */
	public boolean checkForTheErrorMessage(String errorMsg, String msgType) {
		WebElement eleToGetText = null;
		boolean status = false;
		try {
			switch (msgType) {
			case "AccountAlreadyExisting":
				eleToGetText = txtExistingAccErrorMsg;
				break;
			default:
				LogUtility.logError("Invalid Error Type " + msgType);
			}
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (wolWebUtil.verifyText(eleToGetText, errorMsg)) {
				status = true;
				LogUtility.logInfo("checkForTheErrorMessage", "Found the  error message " + errorMsg);
			} else
				LogUtility.logError("checkForTheErrorMessage", "Could not find message " + errorMsg);
		} catch (Exception e) {
			LogUtility.logException("checkForTheErrorMessage", "Failed to get error message", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * Click on the view details in small talk message
	 * 
	 * @return
	 */
	public boolean clickOnTheViewDetailsLink() {
		boolean status = false;
		try {
			if (waits.waitUntilElementIsPresent(linkViewDetails, maxTimeOut)) {
				webActions.clickElement(linkViewDetails);
				status = true;
				LogUtility.logInfo("clickOnTheViewDetailsLink", "Clicked on view details link");
			} else
				LogUtility.logError("clickOnTheViewDetailsLink", "Could not Click on view details link");
		} catch (Exception e) {
			LogUtility.logException("clickOnTheViewDetailsLink", "Failed to click on view dtails link", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Checks for the text and date in message centre and click on the link present
	 * to get the message details
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkAndClickOnTheAppropriatedDateLink(String message) {
		boolean status = false;
		HashMap<Integer, String> otherColValues = new HashMap<>();
		try {
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			waits.waitUntilElementIsPresent(tableManageTransfers, maxTimeOut);
			otherColValues.put(3, wolWebUtil.getDateInTheFormat("MM/dd/YYYY", 0));
			otherColValues.put(1, message);
			if (wolWebUtil.checkFromTableDataWithColNumbers(dataTable, otherColValues, 1)) {
				status = true;
				LogUtility.logInfo("checkAndClickOnTheAppropriatedLink", "Clicked on the link date");
			} else
				LogUtility.logError("checkAndClickOnTheAppropriatedLink", "Could not Click on the link date");
		} catch (Exception e) {
			LogUtility.logException("checkAndClickOnTheAppropriatedLink", "Failed to click on date link", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	public boolean checkForTheMessageInMessageCentre(String msg, String msgType) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (msgType) {
			case "InProcessAccount":
				eleToGetText = txtMsgInProcessInCentre;
				break;
			case "InProcessAccountTransferPage":
				eleToGetText = txtInProcessErrorMsg;
				break;
			default:
				LogUtility.logError("checkForTheMessageInMessageCentre", "Invalid msg type " + msgType);
			}
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (wolWebUtil.verifyTextContains(eleToGetText, msg)) {
				status = true;
				LogUtility.logInfo("checkForTheMessageInMessageCentre", "Message " + msg + " is present");
			} else
				LogUtility.logError("checkForTheMessageInMessageCentre", "Could not find message" + msg);
		} catch (Exception e) {
			LogUtility.logException("checkForTheMessageInMessageCentre", "Failed to find the message", e,
					LoggingLevel.ERROR, true);
		}
		return status;

	}

	/**
	 * To click on the edit button for the account name in manage transfer page
	 * 
	 * @return
	 * @throws Exception
	 */
	public void clickOnTheEditButtonForAccount() throws Exception {
		try {
			delAccname = ExternalTransfersPage.confirmDetails.get("Transfer To");
			if (delAccname.contains(" ")) {
				delAccname = delAccname.split(" ")[0];
			}
			wolWebUtil.clickOnTableCell(tableManageTransfers, delAccname);
			LogUtility.logInfo("clickOnTheEditButtonForAccount", "Clicked on the account " + delAccname);
		} catch (Exception e) {
			LogUtility.logException("clickOnTheEditButtonForAccount", "Failed to click on the delete account", e,
					LoggingLevel.ERROR, true);
			throw e;
		}

	}

	/**
	 * To click on the edit button for the account name in manage transfer page
	 * 
	 * @return
	 */
	public boolean clickOnDeleteAccount() {
		boolean status = false;
		try {
			waits.waitUntilElementIsPresent(btnDeleteManageAccount, maxTimeOut);
			if (webActions.isDisplayed(btnDeleteManageAccount)) {
				webActions.clickElement(btnDeleteManageAccount);
				webActions.clickElement(btnContinue);
				waits.waitForPageToLoad(maxTimeOut);
				LogUtility.logInfo("clickOnDeleteAccount", "Clicked on the delete account");
				status = true;
			} else {
				LogUtility.logError("clickOnDeleteAccount", "Could not delete account");
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnDeleteAccount", "Failed to click on delete account", e, LoggingLevel.ERROR,
					true);
		}
		return status;
	}

	/**
	 * To click on the edit button for the account name in manage transfer page
	 * 
	 * @return
	 */
	public boolean checkForFailedDeleteMsg(String msg) {
		boolean status = false;
		HashMap<Integer, String> otherColValues = new HashMap<>();
		try {
			otherColValues.put(2, delAccname);
			otherColValues.put(3, msg);
			if (wolWebUtil.checkFromTableDataWithColNumbers(dataTable, otherColValues, 0)) {
				status = true;
				LogUtility.logInfo("checkForFailedDeleteMsg", "Found the message " + msg);
			}
		} catch (Exception e) {
			LogUtility.logException("checkForFailedDeleteMsg", "Failed to find the delete status message", e,
					LoggingLevel.ERROR, true);
		}
		return status;

	}

}
