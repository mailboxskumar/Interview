package com.wb.wol_web.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author skarri-adm
 *
 */
public class AccountSummaryPage extends ObjectBase {

	public AccountSummaryPage() {
		PageFactory.initElements(driver, this);
	}

	EnrollmentPage enrollmentPage = new EnrollmentPage();
	public static String accName = "";
	public String emergencyMessageTitle = "";
	public String emergencyMessageBody = "";
	public String accountNickName = "//a[contains(text(),'%s')]/following::a[1]";
	String keyName;
	String linkName;

	@FindAll(@FindBy(xpath = "//input[@name='userQuicklinkIds' and @disabled='disabled']"))
	protected List<WebElement> disabledLinks;

	@FindBy(id = "depositAccountsSection__section-title")
	protected WebElement txtDepositAccountsSectionHeading;

	@FindBy(id = "loan_accounts__section-title")
	protected WebElement txtLoanAccountsSectionHeading;

	@FindBy(id = "credit_accounts__section-title")
	protected WebElement txtCreditAccountsSectionHeading;

	@FindBy(id = "investmentSection__section-title")
	protected WebElement txtInvestmentAccountsSectionHeading;

	@FindAll(@FindBy(xpath = "//li[starts-with(@id,'depositAccountsSection_row') and @data-mm-template='actionCard']"))
	protected List<WebElement> lstDepositAccounts;

	@FindAll(@FindBy(xpath = "//section[@id='depositAccountsSection']/ul/li/span[1]"))
	protected List<WebElement> lstAccountNames;

	@FindAll(@FindBy(xpath = "//section[@id='depositAccountsSection']/ul/li/span[2]"))
	protected List<WebElement> lstAvailableBal;

	@FindAll(@FindBy(xpath = "//section[@id='depositAccountsSection']/ul/li/span[3]"))
	protected List<WebElement> lstCurrentBal;

	@FindAll(@FindBy(xpath = "//section[@id='depositAccountsSection']/ul/li/span[5]"))
	protected List<WebElement> lstCol5;

	@FindAll(@FindBy(xpath = "//li[starts-with(@id,'loan_accounts_row') and @data-mm-template='actionCard']"))
	protected List<WebElement> lstLoanAccounts;

	@FindAll(@FindBy(xpath = "//ul[@id='loan_accounts__body']/li/span[1]"))
	protected List<WebElement> lstLoanAccountNames;

	@FindAll(@FindBy(xpath = "//ul[@id='loan_accounts__body']/li/span[2]"))
	protected List<WebElement> lstPrincipalBal;

	@FindAll(@FindBy(xpath = "//ul[@id='loan_accounts__body']/li/span[3]"))
	protected List<WebElement> lstDueAmt;

	@FindAll(@FindBy(xpath = "//ul[@id='loan_accounts__body']/li/span[4]"))
	protected List<WebElement> lstDueDate;

	@FindAll(@FindBy(xpath = "//ul[@id='loan_accounts__body']/li/span[7]"))
	protected List<WebElement> lstLoanWarning;

	@FindAll(@FindBy(xpath = "//ul[@id='depositAccountsSection__body']/li/span[1]/a"))
	protected List<WebElement> lstDepositAccountNamesLink;

	@FindAll(@FindBy(xpath = "//ul[@id='loan_accounts__body']/li/span[1]/a"))
	protected List<WebElement> lstLoanAccountNamesLink;

	@FindAll(@FindBy(xpath = "//li[starts-with(@id,'credit_accounts_row') and @data-mm-template='actionCard']"))
	protected List<WebElement> lstCreditAccounts;

	@FindAll(@FindBy(xpath = "//ul[@id='credit_accounts__body']/li/span[1]"))
	protected List<WebElement> lstCreditAccountNames;

	@FindAll(@FindBy(xpath = "//ul[@id='credit_accounts__body']/li/span[2]"))
	protected List<WebElement> lstCreditBal;

	@FindBy(xpath = "//li[@id='depositFooterRow']/span[contains(@aria-label,'Total Available Balance')]")
	protected WebElement txtDepositHeadingBal1;

	@FindBy(xpath = "//li[@id='depositFooterRow']/span[contains(@aria-label,'Current Balance')]")
	protected WebElement txtDepositHeadingBal2;

	@FindBy(xpath = "//li[@id='credit_accounts__columnTotals']/span[contains(@aria-label,'*Total Balance')]")
	protected WebElement txtCCHeadingBal1;

	@FindBy(xpath = "//li[@id='credit_accounts__columnTotals']/span[contains(@aria-label,'Total Credit Limit')]")
	protected WebElement txtCCHeadingBal2;

	@FindBy(xpath = "//li[@id='loan_accounts__columnTotals']/span[contains(@aria-label,'Loan Principal Balance')]")
	protected WebElement txtLoanHeadingBal1;

	@FindBy(xpath = "//li[@id='loan_accounts__columnTotals']/span[contains(@aria-label,'Due Now')]")
	protected WebElement txtLoanHeadingBal2;

	@FindAll(@FindBy(xpath = "//ul[@id='credit_accounts__body']/li/span[3]"))
	protected List<WebElement> lstCreditLimit;

	@FindAll(@FindBy(xpath = "//ul[@id='credit_accounts__body']/li/span[4]"))
	protected List<WebElement> lstCreditMinDue;

	@FindBy(id = "investmentSection.non-product-owner-content__cta")
	protected WebElement linkNoInvestAccounts;

	@FindBy(id = "credit_accounts.non-product-owner-content__cta")
	protected WebElement linkNoCreditAccounts;

	@FindBy(id = "loan_accounts.non-product-owner-content__cta")
	protected WebElement linkNoLoanAccounts;

	@FindBy(id = "credit_accounts__addAccountMenu__submenu-title")
	protected WebElement btnCreditAccountAdd;

	@FindBy(id = "loan_accounts__addAccountMenu__submenu-title")
	protected WebElement btnLoanAccountAdd;

	@FindBy(id = "depositAccountsSection__addAccountMenu__submenu-title")
	protected WebElement btnDepositAccountAdd;

	@FindBy(id = "credit_accounts__addAccountMenu__option0__navigationLink")
	protected WebElement btnCreditAccountAddLink;

	@FindBy(id = "loan_accounts__addAccountMenu__option0__navigationLink")
	protected WebElement btnLoanAccountAddLink;;

	@FindBy(id = "depositAccountsSection__addAccountMenu__option0__navigationLink")
	protected WebElement btnDepositAccountAddLink;

	@FindBy(css = "#bodyContent h1")
	protected WebElement txtAddAccountPageHeading;

	@FindBy(xpath = "//h1[@data-mm-template='pageTitle']")
	protected WebElement txtTransHisPageHeadingText;

	@FindAll(@FindBy(xpath = "//ul[@id='depositAccountsSection__body']/li/span[4]"))
	protected List<WebElement> lstLastTransaction;

	@FindBy(id = "emergency__title")
	protected WebElement msgEmergencyTitle;

	@FindBy(id = "emergency__body")
	protected WebElement msgEmergencyBody;

	@FindBy(id = "credit_accounts_row0_accountDetails")
	protected WebElement lnkCreditCardAccDetails;

	@FindBy(xpath = "//ul[@id='credit_accounts__body']/li/span[1]/a")
	protected WebElement lstCreditCardAccountNamesLink;

	@FindBy(css = "Connecting to Your Credit Card Account(s)")
	protected WebElement titlePageHeader;

	@FindBy(id = "accountType__label")
	protected WebElement lblAccountTypeField;

	@FindBy(id = "accountNumber__label")
	protected WebElement lblAccountNumberField;

	@FindBy(id = "nickname__label")
	protected WebElement lblNickNameField;

	@FindBy(id = "transaction_history_invalid_selected_account__pageErrors__transaction_history_invalid_selected_account__pageError__body")
	protected WebElement msgPageError;

	@FindBy(id = "depositAccountsSection_row_0__col_1")
	protected WebElement lblAvailBalance;

	@FindBy(id = "depositAccountsSection_row_0__col_2")
	protected WebElement lblCurrentBalance;

	@FindBy(id = "loan_accounts_row0__col_2")
	protected WebElement lblPrincipalBalance;

	@FindBy(id = "loan_accounts_row0__col_3")
	protected WebElement lblAmountDue;

	@FindBy(id = "credit_accounts_row0__col_1")
	protected WebElement lblBalance;

	@FindBy(id = "credit_accounts_row0__col_2")
	protected WebElement lblCreditLimit;

	@FindBy(css = "div#mainSiteNav__submenu1__megaMenu ul li a")
	protected List<WebElement> mnuAccounts;

	@FindBy(css = "div#mainSiteNav__submenu2__megaMenu ul li a")
	protected List<WebElement> mnuTransfers;

	@FindBy(css = "div#mainSiteNav__submenu3__megaMenu ul li a")
	protected List<WebElement> mnuPayments;

	@FindBy(css = "div#mainSiteNav__submenu4__megaMenu ul li a")
	protected List<WebElement> mnuServices;

	@FindBy(css = "div#mainSiteNav__submenu1__megaMenu ul li a")
	protected List<WebElement> mnuSupport;

	@FindBy(css = "#mainSiteNav__submenu1__menuLabel")
	protected WebElement tabAccounts;

	@FindBy(css = "#mainSiteNav__submenu2__menuLabel")
	protected WebElement tabTransfers;

	@FindBy(css = "#mainSiteNav__submenu3__menuLabel")
	protected WebElement tabPayments;

	@FindBy(css = "#mainSiteNav__submenu4__menuLabel")
	protected WebElement tabServices;

	@FindBy(css = "#mainSiteNav__submenu5__menuLabel")
	protected WebElement tabSupport;

	@FindBy(css = "#loan_accounts_row0__col_0 a")
	protected WebElement lnkFirstLoanAccount;

	@FindBy(css = "#loan_accounts_row1__col_0 a")
	protected WebElement lnkSecondLoanAccount;

	@FindBy(css = "#depositAccountsSection_row_0__col_0 a")
	protected WebElement lnkFirstDepositAccount;

	@FindBy(css = "#depositAccountsSection_row_1__col_0 a")
	protected WebElement lnkSecondDepositAccount;

	@FindBy(css = "#depositAccountsSection_row_2__col_0 a")
	protected WebElement lnkThirdDepositAccount;

	@FindBy(css = "#depositAccountsSection_row_3__col_0 a")
	protected WebElement lnkFourthDepositAccount;

	@FindBy(css = "#credit_accounts_row0__col_0  a")
	protected WebElement lnkCreditCardAccount;

	@FindBy(css = "#subHeader span")
	protected WebElement lblEsignPage;

	/**
	 * To check the heading for each section is present or not
	 * 
	 * @param heading
	 * @return
	 */
	public boolean checkForTheAccountSummaryHeading(String heading) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (heading) {
			case "Checking and Savings Accounts":
				eleToGetText = txtDepositAccountsSectionHeading;
				break;
			case "Loan Accounts":
				eleToGetText = txtLoanAccountsSectionHeading;
				break;
			case "Credit Card Accounts":
				eleToGetText = txtCreditAccountsSectionHeading;
				break;
			case "Investment Accounts":
				eleToGetText = txtInvestmentAccountsSectionHeading;
				break;
			default:
				LogUtility.logInfo("checkForTheAccountSummaryHeading", "Not a valid Section Name" + heading);
			}
			waits.waitUntilElementExistence(eleToGetText, maxTimeOut);
			status = wolWebUtil.verifyText(eleToGetText, heading);
			if (status)
				LogUtility.logInfo("checkForTheAccountSummaryHeading", heading + " Heading is present");
			else
				LogUtility.logError("checkForTheAccountSummaryHeading", heading + " Heading is not present");
		} catch (Exception e) {
			LogUtility.logException("checkForTheAccountSummaryHeading", heading + " Heading is not present", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check the heading for each section is present ot not
	 * 
	 * @param heading
	 * @return
	 * @throws Exception
	 */
	public void clickOnAddAccountButton(String sectionName) throws Exception {
		WebElement addButton = null;
		String addLink = null;
		try {
			switch (sectionName) {
			case "Checking and Savings Accounts":
				addButton = btnDepositAccountAdd;
				addLink = ("document.getElementById('depositAccountsSection__addAccountMenu__option0__navigationLink').click()");
				break;
			case "Loan Accounts":
				addButton = btnLoanAccountAdd;
				addLink = ("document.getElementById('loan_accounts__addAccountMenu__option0__navigationLink').click()");
				break;
			case "Credit Card Accounts":
				addButton = btnCreditAccountAdd;
				addLink = ("document.getElementById('credit_accounts__addAccountMenu__option0__navigationLink').click()");
				break;
			default:
				LogUtility.logInfo("clickOnAddAccountButton", "Not a valid Section Name");
			}
			waits.waitUntilElementIsPresent(addButton, maxTimeOut);
			webActions.clickElement(addButton);
			((JavascriptExecutor) driver).executeScript(addLink);
			LogUtility.logInfo("clickOnAddAccountButton", "Clicked in  Add Accounts button");
		} catch (Exception e) {
			LogUtility.logException("clickOnAddAccountButton", "Exception while cilcking on plus button", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * To click on the loan account
	 * 
	 * @throws Exception
	 */
	public void clickOnLoanAccount() throws Exception {
		try {
			waits.waitForPageToLoad(maxTimeOut);
			webActions.clickElement(lstLoanAccountNamesLink.get(0));
			LogUtility.logInfo("clickOnLoanAccount", "Clicked on the loan account");
		} catch (Exception e) {
			LogUtility.logException("clickOnLoanAccount", "Exception while cilcking on loan button", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Clicks on any deposit account based on the argument type
	 * (CD/Checkings/Savings)
	 * 
	 * @param accountType
	 * @throws Exception
	 */
	public boolean clickOnDepositAccount(String accountType) {
		boolean status = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			for (WebElement account : lstDepositAccountNamesLink) {
				String accountName = account.getText().toUpperCase();
				switch (accountType) {
				case "CD":
					if (accountName.contains("CD")) {
						if (!webActions.isDisplayed(account)) {
							wolWebUtil.scrollToElement(account);
							waits.waitForPageToLoad(maxTimeOut);
						}
						webActions.clickElement(account);
						accName = accountName;
						status = true;
					}
					break;
				case "Savings":
					if (accountName.contains("SAVINGS")) {
						webActions.clickElement(account);
						accName = accountName;
						status = true;
					}
					break;
				case "Checkings":
					if (accountName.contains("CHECKING") || accountName.contains("CKG")) {
						if (!webActions.isDisplayed(account)) {
							wolWebUtil.scrollToElement(account);
							waits.waitForPageToLoad(maxTimeOut);
						}
						webActions.clickElement(account);
						status = true;
						accName = accountName;
					}
					break;
				default:
					LogUtility.logInfo("clickOnDepositAccount", "Invalid account Type" + accountType);
				}
				if (status) {
					// After clicked on Summary tab, page loading takes time
					waits.staticWait(3);
					LogUtility.logInfo("clickOnDepositAccount", "Clicked on the account " + accName);
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnDepositAccount", "Exception while cilcking on deposit account", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * Check whether its going to correct destination page on clicking links from
	 * summary page
	 * 
	 * @param pageHeading
	 * @return
	 */
	public boolean checkForTheDestPageOnClickingLinksFromFS(String pageHeading) {
		boolean status = false;
		WebElement eleToGetText = null;
		try {
			switch (pageHeading) {
			case "Transaction History":
				eleToGetText = txtTransHisPageHeadingText;
				break;
			case "Add Webster Accounts":
				eleToGetText = txtAddAccountPageHeading;
				break;
			default:
				LogUtility.logInfo("checkForTheDestPageOnClickingLinksFromFS", "Invalid page Heading" + pageHeading);
			}
			waits.waitUntilElementIsPresent(eleToGetText, maxTimeOut);
			if (wolWebUtil.verifyText(eleToGetText, pageHeading)) {
				status = true;
				LogUtility.logInfo("checkForTheDestPageOnClickingLinksFromFS",
						"Reached the destination page " + pageHeading);
			} else
				LogUtility.logError("checkForTheDestPageOnClickingLinksFromFS",
						"Could not reach the destination page " + pageHeading);
		} catch (Exception e) {
			LogUtility.logException("checkForTheDestPageOnClickingLinksFromFS", "Could not reach the expected page", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * To check that there are no accounts present under the given section
	 * 
	 * @param section
	 * @return
	 */
	public boolean checkNoAccountsUnderEachSection(String section) {
		boolean status = false;
		WebElement eleToWait = null;

		try {
			if (section.equals("Checking and Savings Accounts")) {
				if (lstDepositAccounts == null || lstDepositAccounts.size() == 0) {
					status = true;
				}
			} else {
				switch (section) {
				case "Loan Accounts":
					eleToWait = linkNoLoanAccounts;
					break;
				case "Credit Card Accounts":
					eleToWait = linkNoCreditAccounts;
					break;
				case "Investment Accounts":
					eleToWait = linkNoInvestAccounts;
					break;
				default:
					LogUtility.logInfo("checkNoAccountsUnderEachSection", "Not a valid Section Name");
				}
				if (waits.waitUntilElementIsPresent(eleToWait, maxTimeOut)) {
					status = true;
				}
			}
			if (status)
				LogUtility.logInfo("checkNoAccountsUnderEachSection",
						"No Accounts are present under the section  " + section);
			else
				LogUtility.logError("checkNoAccountsUnderEachSection",
						"Accounts are present under the section  " + section);
		} catch (Exception e) {
			LogUtility.logException("checkNoAccountsUnderEachSection",
					"Exception while checking the accounts present under the section", e, LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * This fucntion takes the account type as input and validates the balances of
	 * all the deposit accounts accordingly
	 * 
	 * @param accountType Authored On:12-06-2019
	 * @return
	 */
	public List<HashMap<String, String>> checkTheDepsoitAccounts(String accountType) {
		List<HashMap<String, String>> allAccountDetails = new ArrayList<>();
		try {
			for (int i = 0; i < lstDepositAccounts.size(); i++) {
				HashMap<String, String> eachAccountDetail = new HashMap<>();
				eachAccountDetail.put("Account Name", lstAccountNames.get(i).getText());
				String curBal = lstCurrentBal.get(i).getText();
				if (checkBalanceValidity(accountType, curBal)) {
					eachAccountDetail.put("Current Balance", curBal);
				} else {
					eachAccountDetail.put("Current Balance", "Contains incorrect value " + curBal);
					LogUtility.logError("Current Balance contains incorrect value " + curBal);
				}

				String availBal = lstAvailableBal.get(i).getText();
				if (checkBalanceValidity(accountType, availBal)) {
					eachAccountDetail.put("Available Balance", availBal);
				} else {
					eachAccountDetail.put("Available Balance", "Contains incorrect value " + availBal);
					LogUtility.logError("Available Balance contains incorrect value " + availBal);
				}

				String lastTrasnHistory = lstLastTransaction.get(i).getText();
				if (!lastTrasnHistory.equals("")) {
					eachAccountDetail.put("Last Transaction History", lastTrasnHistory);
				} else {
					eachAccountDetail.put("Last Transaction History", "Contains incorrect value " + lastTrasnHistory);
					LogUtility.logError("Last Transaction History contains incorrect value " + lastTrasnHistory);
				}
				allAccountDetails.add(eachAccountDetail);
			}
			LogUtility.logInfo("checkTheDepsoitAccounts", "Deposit Account Details are " + allAccountDetails);
		} catch (Exception e) {
			LogUtility.logException("checkTheDepsoitAccounts", "Deposit Account Details are not displayed", e,
					LoggingLevel.ERROR, true);
		}

		return allAccountDetails;

	}

	public boolean checkTheOverAllBalancesForEachSection(String accountType, String sectionName) {
		boolean status = false;
		WebElement balance1 = null, balance2 = null;
		try {
			switch (sectionName) {
			case "Loan Accounts":
				balance1 = txtLoanHeadingBal1;
				balance2 = txtLoanHeadingBal2;
				break;
			case "Credit Card Accounts":
				balance1 = txtCCHeadingBal1;
				balance2 = txtCCHeadingBal2;
				break;
			case "Investment Accounts":
				balance1 = txtCCHeadingBal1;
				balance2 = txtLoanHeadingBal1;
				break;
			case "Checking and Savings Accounts":
				balance1 = txtDepositHeadingBal1;
				balance2 = txtDepositHeadingBal2;
				break;
			default:
				LogUtility.logInfo("checkTheOverAllBalancesforEachSection", "Invalid  accountType " + sectionName);
			}
			if (checkBalanceValidity(accountType, webActions.getText(balance1))
					&& checkBalanceValidity(accountType, webActions.getText(balance2)))
				status = true;
		} catch (Exception e) {
			LogUtility.logException("checkTheOverAllBalancesforEachSection",
					sectionName + "Exception while checking the overall balances for the section", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * checks if the balance value is valid according to the type of account
	 * 
	 * @param accountType
	 * @param balance
	 * @return
	 */
	public boolean checkBalanceValidity(String accountType, String balance) {
		boolean status = false;
		try {
			switch (accountType) {
			case "Purged":
				if (balance.contains("N/A"))
					status = true;
				break;
			case "Closed":
				if (balance.contains("Closed"))
					status = true;
				break;
			case "ClosedAll":
				if (balance.trim().equalsIgnoreCase("$0.0"))
					status = true;
				break;
			case "Normal":
				if (balance.trim().equals("Closed") || balance.trim().equals("N/A"))
					status = true;
				else {
					try {
						Double d = Double.parseDouble(balance.replace("$", "").replace(",", ""));
						status = true;
					} catch (Exception e) {
						status = false;
					}
				}
				break;
			default:
				LogUtility.logError("checkBalanceValidity", "Invalid account type" + accountType);
				break;
			}
		} catch (Exception e) {
			LogUtility.logException("checkBalanceValidity", "Exception while checkin the status validity ", e,
					LoggingLevel.ERROR, true);
		}
		return status;
	}

	/**
	 * This function takes the account type as input and validates the balances of
	 * all the loan accounts accordingly
	 * 
	 * @param accountType Authored On:13-06-2019
	 * @return
	 */
	public List<HashMap<String, String>> checkTheLoanAccounts(String accountType) {
		List<HashMap<String, String>> allAccountDetails = new ArrayList<>();
		try {
			for (int i = 0; i < lstLoanAccounts.size(); i++) {
				HashMap<String, String> eachAccountDetail = new HashMap<>();
				eachAccountDetail.put("Account Name", lstLoanAccountNames.get(i).getText());
				String principalAmt = lstPrincipalBal.get(i).getText();
				if (checkBalanceValidity(accountType, principalAmt)) {
					eachAccountDetail.put("Principal Balance", principalAmt);
				} else {
					eachAccountDetail.put("Principal Balance", "Contains incorrect value " + principalAmt);
					LogUtility.logError("Principal Balance contains incorrect value " + principalAmt);
				}
				String dueAmt = lstDueAmt.get(i).getText();
				if (checkBalanceValidity(accountType, dueAmt)) {
					eachAccountDetail.put("Due Amount", dueAmt);
				} else {
					eachAccountDetail.put("Due Amount", "Contains incorrect value " + dueAmt);
					LogUtility.logError("Due Amount contains incorrect value " + dueAmt);
				}
				eachAccountDetail.put("Due Date", lstDueDate.get(i).getText());
				allAccountDetails.add(eachAccountDetail);
			}
			LogUtility.logInfo("checkTheLoanAccounts", "Loan Account Details are " + allAccountDetails.toString());
		} catch (Exception e) {
			LogUtility.logException("checkTheLoanAccounts", "Exception while checkin the Loan Accounts ", e,
					LoggingLevel.ERROR, true);
		}
		return allAccountDetails;
	}

	/**
	 * This fucntion takes the account type as input and validates the balances of
	 * all the credit card accounts accordingly
	 * 
	 * @param accountType Authored On:13-06-2019
	 * @return
	 */
	public List<HashMap<String, String>> checkTheCreditCardAccounts(String accountType) {
		List<HashMap<String, String>> allAccountDetails = new ArrayList<>();

		try {
			for (int i = 0; i < lstCreditAccounts.size(); i++) {
				HashMap<String, String> eachAccountDetail = new HashMap<>();
				eachAccountDetail.put("Account Name", lstCreditAccountNames.get(i).getText());
				String credBalance = lstCreditBal.get(i).getText();
				if (checkBalanceValidity(accountType, credBalance)) {
					eachAccountDetail.put("Credit Balance", credBalance);
				} else {
					eachAccountDetail.put("Credit Balance", "Contains incorrect value " + credBalance);
					LogUtility.logError("Credit Balance contains incorrect value " + credBalance);
				}

				String credLimit = lstCreditLimit.get(i).getText();
				if (checkBalanceValidity(accountType, credLimit)) {
					eachAccountDetail.put("Credit Limit", credLimit);
				} else {
					eachAccountDetail.put("Credit Limit", "Contains incorrect value " + credLimit);
					LogUtility.logError("Credit Limit contains incorrect value " + credLimit);
				}
				String minDue = lstCreditMinDue.get(i).getText();
				if (checkBalanceValidity(accountType, minDue)) {
					eachAccountDetail.put("Minimum Due", minDue);
				} else {
					eachAccountDetail.put("Minimum Due", "Contains incorrect value " + minDue);
					LogUtility.logError("Minimum Due contains incorrect value " + credLimit);
				}
				allAccountDetails.add(eachAccountDetail);
			}
			LogUtility.logInfo("checkTheCreditCardAccounts",
					"Credit Card Account Details are " + allAccountDetails.toString());
		} catch (Exception e) {
			LogUtility.logException("checkTheCreditCardAccounts", "Exception while checkin the CreditCard Accounts ", e,
					LoggingLevel.ERROR, true);
		}
		return allAccountDetails;
	}

	/**
	 * To verify the Emergency Message Title
	 *
	 */
	public boolean verifyEmergencyMsgTitle() {
		try {
			emergencyMessageTitle = getValueFromRuntimeDataMap("emergencyMsgTitleKey");
			return wolWebUtil.verifyText(msgEmergencyTitle, emergencyMessageTitle);
		} catch (Exception e) {
			LogUtility.logException("verifyEmergencyMsgTitle", emergencyMessageTitle + " title is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Emergency Message Body
	 *
	 */
	public boolean verifyEmergencyMsgBody() {
		try {
			emergencyMessageBody = getValueFromRuntimeDataMap("emergencyMsgBodyKey");
			return wolWebUtil.verifyText(msgEmergencyBody, emergencyMessageBody);
		} catch (Exception e) {
			LogUtility.logException("verifyEmergencyMsgBody", emergencyMessageBody + " body is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To click on the Credit Card account
	 * 
	 * 
	 */
	public boolean clickOnCreditCardAccount() {
		boolean flag = false;
		try {
			// After login the application, page loading takes time
			waits.staticWait(2);
			boolean creditCardAcc = webActions.isDisplayed(lstCreditCardAccountNamesLink);
			if (creditCardAcc) {
				webActions.clickElement(lstCreditCardAccountNamesLink);
				LogUtility.logInfo("clickOnCreditCardAccount", "Clicked on the Credit card account");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCreditCardAccount", "Unable to click on Credit card Account", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To click on the Credit Card account details link
	 * 
	 *
	 */
	public boolean clickOnCreditCardAccountDetails() {
		boolean flag = false;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			boolean creditCardAcc = webActions.isDisplayed(lnkCreditCardAccDetails);
			if (creditCardAcc) {
				webActions.clickElement(lnkCreditCardAccDetails);
				LogUtility.logInfo("clickOnCreditCardAccountDetails",
						"Clicked on the Credit card account details link");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCreditCardAccountDetails",
					"Unable to click on Credit card Account details link", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To check the page heading for temporarily unavailable Page
	 * 
	 * @return
	 */
	public boolean verifyTemporarilyUnavailablePage(String pageTitle) {
		try {
			waits.waitUntilElementIsPresent(titlePageHeader, maxTimeOut);
			wolWebUtil.verifyPageTitleOfChildWindow(pageTitle);
			return wolWebUtil.verifyText(titlePageHeader, pageTitle);
		} catch (Exception e) {
			LogUtility.logException("checkTemporarilyUnavailablePageTitle",
					"Temporarily Unavailable Page is not displayed", e, LoggingLevel.ERROR, true);

			return false;
		}
	}

	/**
	 * To verify the Account Type field should display
	 */

	public boolean verifyAccountTypeField(String accountType) {
		try {
			waits.waitUntilElementIsPresent(lblAccountTypeField, maxTimeOut);
			return wolWebUtil.verifyText(lblAccountTypeField, accountType);
		} catch (Exception e) {
			LogUtility.logException("verifyAccountTypeField", accountType + "field is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Account Number field should display
	 */

	public boolean verifyAccountNumberField(String accountNumber) {
		try {
			waits.waitUntilElementIsPresent(lblAccountNumberField, maxTimeOut);
			return wolWebUtil.verifyText(lblAccountNumberField, accountNumber);
		} catch (Exception e) {
			LogUtility.logException("verifyAccountTypeField", accountNumber + "field is not displayed", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	/**
	 * To verify the Nick Name field should display
	 */

	public boolean verifyNickNameField(String nickName) {
		try {
			waits.waitUntilElementIsPresent(lblNickNameField, maxTimeOut);
			return wolWebUtil.verifyText(lblNickNameField, nickName);
		} catch (Exception e) {
			LogUtility.logException("verifyNickNameField", nickName + "field is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the Account details link in account based on the argument type
	 * (CD/Checkings/Savings)
	 * 
	 * @param accountType
	 * @throws Exception
	 */
	public boolean verifyAccountDetailsLink(String accountType) {
		boolean flag = false;
		try {
			WebElement account = driver.findElement(By.xpath(String.format(accountNickName, accountType)));
			if (webActions.isDisplayed(account)) {
				LogUtility.logInfo("verifyAccountDetailsLink", "Account displayed" + account);
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAccountDetailsLink", "Exception while displaying Account details", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Transaction Error Message
	 *
	 */
	public boolean verifyTransactionErrMsg(String msg) {
		try {
			return wolWebUtil.verifyText(msgPageError, msg);
		} catch (Exception e) {
			LogUtility.logException("verifyTransactionErrMsg", " Error message is not displayed", e, LoggingLevel.ERROR,
					true);
			return false;
		}
	}

	/**
	 * To verify the CD accounts Balances Amount
	 *
	 */
	public boolean verifyCDAccBalances() {
		boolean flag = false;
		try {
			String availableBalance = webActions.getText(lblAvailBalance);
			String currentBalance = webActions.getText(lblCurrentBalance);
			if (!availableBalance.equals(currentBalance)) {
				LogUtility.logInfo("verifyCDAccBalances", "Both balances were different");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCDAccBalances", " Both balances were equal", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Loan accounts Balances Amount
	 *
	 */
	public boolean verifyLoanAccBalances() {
		boolean flag = false;
		try {
			String principalBalance = webActions.getText(lblPrincipalBalance);
			String amountDue = webActions.getText(lblAmountDue);
			if (!principalBalance.equals(amountDue)) {
				LogUtility.logInfo("verifyLoanAccBalances", "Both balances were different");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyLoanAccBalances", " Both balances were equal", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Loan accounts Balances Amount
	 *
	 */
	public boolean verifyCreditCardAccBalances() {
		boolean flag = false;
		try {
			String balance = webActions.getText(lblBalance);
			String creditLimit = webActions.getText(lblCreditLimit);
			if (!balance.equals(creditLimit)) {
				LogUtility.logInfo("verifyCreditCardAccBalances", "Both balances were different");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyCreditCardAccBalances", " Both balances were equal", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * To check the heading for each section is present or not
	 * 
	 * @param heading
	 * @return
	 */
	public boolean verifyMenuLinks(String menu, Map<String, String> featureName) {
		boolean flag = false;
		try {
			switch (menu) {
			case "Accounts":
				webActions.clickElement(tabAccounts);
				enrollmentPage.verifyListMesagses(mnuAccounts, featureName, "Accounts Links", "verifyMenuLinks");
				flag = true;
				break;
			case "Transfers":
				webActions.clickElement(tabTransfers);
				enrollmentPage.verifyListMesagses(mnuTransfers, featureName, "Transfers Links", "verifyMenuLinks");
				flag = true;
				break;
			case "Payments":
				webActions.clickElement(tabPayments);
				enrollmentPage.verifyListMesagses(mnuPayments, featureName, "Payments Links", "verifyMenuLinks");
				flag = true;
				break;
			case "Services":
				webActions.clickElement(tabServices);
				enrollmentPage.verifyListMesagses(mnuServices, featureName, "Services Links", "verifyMenuLinks");
				flag = true;
				break;
			case "Support":
				webActions.clickElement(tabSupport);
				enrollmentPage.verifyListMesagses(mnuSupport, featureName, "Support Links", "verifyMenuLinks");
				flag = true;
				break;
			default:
				LogUtility.logInfo("verifyMenuLinks", "Not a valid Menu" + menu);
			}
		} catch (Exception e) {
			LogUtility.logException("verifyMenuLinks", menu + " menu is not present", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Personal/Business Loan accounts order
	 *
	 */
	public boolean verifyLoanAccountsOrder(String user) {
		boolean flag = false;
		try {
			if (user.contains("Personal User")) {
				if (webActions.getText(lnkFirstLoanAccount).contains(jsonDataParser.getTestDataMap().get("PersonalLoanAccount"))
						&& webActions.getText(lnkSecondLoanAccount).contains(jsonDataParser.getTestDataMap().get("BusinessLoanAccount"))) {
					LogUtility.logInfo("verifyLoanAccountsOrder", "Personal user Loan Accounts displayed proper order");
					flag = true;
				}
			} else if (user.contains("Business User")) {
				if (webActions.getText(lnkFirstLoanAccount).contains(jsonDataParser.getTestDataMap().get("BusinessLoanAccount"))
						&& webActions.getText(lnkSecondLoanAccount).contains(jsonDataParser.getTestDataMap().get("PersonalLoanAccount"))) {
					LogUtility.logInfo("verifyLoanAccountsOrder", "Business user Loan Accounts displayed proper order");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyPersonalLoanAccoutnsOrder", " Loan Accounts are not displayed proper order",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Personal/Business user Checking saving accounts order
	 *
	 */
	public boolean verifyDepositAccountsOrder(String user) {
		boolean flag = false;
		try {
			if (user.contains("Personal User")) {
				if (webActions.getText(lnkFirstDepositAccount).contains(jsonDataParser.getTestDataMap().get("PersonalCheckingAccount"))
						&& webActions.getText(lnkSecondDepositAccount)
								.contains(jsonDataParser.getTestDataMap().get("PersonalSavingAccount"))
						&& webActions.getText(lnkThirdDepositAccount)
								.contains(jsonDataParser.getTestDataMap().get("BusinessCheckingAccount"))
						&& webActions.getText(lnkFourthDepositAccount)
								.contains(jsonDataParser.getTestDataMap().get("BusinessSavingAccount"))) {
					LogUtility.logInfo("verifyDepositAccountsOrder",
							"Personal user Deposit Accounts displayed proper order");
					flag = true;
				}
			} else if (user.contains("Business User")) {
				if (webActions.getText(lnkFirstDepositAccount).contains(jsonDataParser.getTestDataMap().get("BusinessCheckingAccount"))
						&& webActions.getText(lnkSecondDepositAccount)
								.contains(jsonDataParser.getTestDataMap().get("BusinessSavingAccount"))
						&& webActions.getText(lnkThirdDepositAccount)
								.contains(jsonDataParser.getTestDataMap().get("PersonalCheckingAccount"))
						&& webActions.getText(lnkFourthDepositAccount)
								.contains(jsonDataParser.getTestDataMap().get("PersonalSavingAccount"))) {
					LogUtility.logInfo("verifyDepositAccountsOrder",
							"Personal user Deposit Accounts displayed proper order");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("verifyDepositAccountsOrder", " Deposit Accounts are not displayed proper order", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the Credit Card accounts Balances Amount
	 *
	 */
	public boolean clickOnCCAccountLink() {
		boolean flag = false;
		try {
			boolean creditCardLink = webActions.isDisplayed(lnkCreditCardAccount);
			if (creditCardLink) {
				webActions.clickElementJS(lnkCreditCardAccount);
				LogUtility.logInfo("clickOnLoanAccount", "Clicked on the Credit Card account");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("clickOnCCAccountLink", "Unable to click on Credit Card Account ", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * To verify the E-SIGN page should display
	 *
	 */
	public boolean verifyESIGNPage() {
		try {
			wolWebUtil.switchToNewWindow();
			waits.waitUntilElementIsPresent(lblEsignPage, maxTimeOut);
			return wolWebUtil.verifyText(lblEsignPage, (testDataMap.get("ESignLabel")));
		} catch (Exception e) {
			LogUtility.logException("verifyESIGNPage", " E SIGN page is not displayed", e, LoggingLevel.ERROR, true);
			return false;
		}
	}
}
