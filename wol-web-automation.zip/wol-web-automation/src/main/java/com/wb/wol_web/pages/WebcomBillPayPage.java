//@author: Vinodh
package com.wb.wol_web.pages;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;

/**
 * @author VSomalaraju-adm
 */
public class WebcomBillPayPage extends ObjectBase {
	public WebcomBillPayPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "h3[data-wbst-message-key*='title'],h1[data-wbst-message-key*='title'],h1[data-wbst-message-key*='payee']")
	protected WebElement txtWolPageTitle;

	@FindBy(css = "div[class='title']")
	protected WebElement ttlPassApplication;

	@FindBy(css = "div[data-wbst-message-key*='title']")
	protected WebElement txtSubPmtResrch;

	@FindBy(css = "#bodyContent  h3")
	protected WebElement ttlUnauthUserAccess;

	@FindBy(css = "#pageContent  p")
	protected WebElement txtUnauthMsg;

	@FindBy(css = "#pageContent > form > table")
	protected WebElement tblMngExtAccounts;

	@FindBy(css = "table > tbody > tr:nth-child(1)> td:nth-child(1) > a")
	protected WebElement tblPendPmtDelDate;

	@FindBy(css = " label > input[type=checkbox]")
	protected WebElement chkPmtAlert;

	@FindBy(css = "input[id='updateAction'],input[id='focusAction']")
	protected WebElement btnUpdate;
	
	@FindBy(css="#duplicatebtn")
	protected WebElement btnPayDupBills;

	/**
	 * @author VSomalaraju-adm
	 */
	public void switchToChildWindow() {
		try {
			Set<String> windows = driver.getWindowHandles();
			Iterator<String> itr = windows.iterator();
			String mainWindow = itr.next();
			String childWindow = itr.next();
			driver.switchTo().window(childWindow);
			waits.waitForPageToLoad(maxTimeOut);
			waits.waitForDOMready();
			driver.manage().window().maximize();
			LogUtility.logInfo("---> switchToChildWindow <---",
					" Application is switched to child window successfully");
		} catch (Exception e) {
			LogUtility.logException("---> switchToChildWindow <---", "Failed to verify swictch child window", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * @author VSomalaraju-adm
	 * @param pgTitle
	 * @return
	 */
	public boolean verifyWolBillPayPageTitle(String billPayTitle) {
		boolean flag = false;
		try {
			waits.staticWait(5);// Taking time to load the child window
			switchToChildWindow();
			if (waits.waitUntilElementIsPresent(txtWolPageTitle, maxTimeOut)) {
				if (txtWolPageTitle.getText().equals(billPayTitle)) {
					LogUtility.logInfo("---> verifyWolBillPayPageTitle <---",
							"CSR admin navigated to  { " + billPayTitle + " } page successfully in WOL application");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyWolBillPayPageTitle <---",
					"Failed to verify { " + billPayTitle + " } in WOL application", e, LoggingLevel.ERROR, true);

		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param pgTitle
	 * @return
	 */
	public boolean verifyPassApplicationTitle(String pgTitle) {
		boolean flag = false;
		try {
			switchToChildWindow();
			if (waits.waitUntilElementIsPresent(ttlPassApplication, maxTimeOut)) {
				if (ttlPassApplication.getText().equals(pgTitle)) {
					LogUtility.logInfo("---> verifyPassApplicationTitle <---",
							"Verified { " + pgTitle + " } page successfully");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyPassApplicationTitle <---",
					"Failed to verify { " + pgTitle + " } in Pass application", e, LoggingLevel.ERROR, true);

		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param txtSubRsrh
	 * @return
	 */
	public boolean verifySubmitResearchText(String txtSubRsrh) {
		boolean flag = false;
		try {
			switchToChildWindow();
			if (waits.waitUntilElementIsPresent(txtSubPmtResrch, maxTimeOut)) {
				if (txtSubPmtResrch.getText().equals(txtSubRsrh)) {
					LogUtility.logInfo("---> verifySubmiResearchText <---",
							"Verified { " + txtSubRsrh + " } text successfully in Payveris application");
					flag = true;
				}
			}

		} catch (Exception e) {
			LogUtility.logException("---> verifySubmiResearchText <---",
					"Failed to verify { " + txtSubRsrh + " } text in Pass application", e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean verifyUnauthUserAccessTitle(String pgTitle) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(ttlUnauthUserAccess, maxTimeOut)) {
				if (ttlUnauthUserAccess.getText().equals(pgTitle)) {
					LogUtility.logInfo("---> verifyUnauthUserAccessTitle <---",
							"CSR admin navigated to { " + pgTitle + " } page in WOL application");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyUnauthUserAccessTitle <---",
					"Failed to verify { Unauthorized User Access } text in WOL application", e, LoggingLevel.ERROR,
					true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param txtMessage
	 * @return
	 */

	public boolean verifyUnauthUserAccessMag(Map<String, String> unauthTestData) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(txtUnauthMsg, maxTimeOut)) {
				if (txtUnauthMsg.getText().equals(unauthTestData.get("UnAuthMessage"))) {
					LogUtility.logInfo("---> verifyUnauthUserAccessMsg <---",
							"Verified { " + unauthTestData.get("UnAuthMessage") + "} text in WOL Application");
					flag = true;
				}
			}

		} catch (Exception e) {
			LogUtility.logException("---> verifyUnauthUserAccessMsg <---",
					"Failed to verify { " + unauthTestData.get("UnAuthMessage") + " } text in WOL application", e,
					LoggingLevel.ERROR, true);

		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean clickOnEditIconInExtAcctPage(String editText) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(tblMngExtAccounts, maxTimeOut)) {
				wolWebUtil.clickOnTableCell(tblMngExtAccounts, editText);
				LogUtility.logInfo("---> clickOnEditIconInExtAcctPage <---",
						"Clicked on the Edit icon in manage external accounts page");
				flag = true;
			}
		} catch (Exception e) {
			LogUtility.logException("---> clickOnEditIconInExtAcctPage <---",
					"Failed to click edit icon in { Manage Non-Webster Transfer Accounts } page in WOL application", e,
					LoggingLevel.ERROR, true);

		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean clickOnDeliveryDateLinkInMngPendPmtsPage() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(tblPendPmtDelDate, maxTimeOut)) {
				webActions.clickElement(tblPendPmtDelDate);
				LogUtility.logInfo("---> clickOnDeliveryDateLinkInMngPendPmtsPage <---",
						"Clicked on the delivery date in manage pending payments page successfully");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("---> clickOnDeliveryDateLinkInMngPendPmtsPage <---",
					"Failed to click edit icon in { Manage Pending Payments Page } page in WOL application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean selectPmtAlertOptions() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(chkPmtAlert, maxTimeOut)) {
				webActions.clickElement(chkPmtAlert);
				LogUtility.logInfo("---> selectPmtAlertOptions <---",
						"Selected { When payment is delivered } check box successfully");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("---> selectPmtAlertOptions <---",
					"Failed to select { When payment is delivered } check box in WOL application", e,
					LoggingLevel.ERROR, true);

		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @return
	 */
	public boolean clickPmtUpdate() {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(btnUpdate, maxTimeOut)) {
				webActions.clickElement(btnUpdate);
				if (waits.waitUntilElementIsPresent(btnPayDupBills)) {
					webActions.clickElement(btnPayDupBills);
					LogUtility.logInfo("Clicked : Pay Duplicate Bills : successfully");
				}
				LogUtility.logInfo("---> clickPmtUpdate <---", "Clicked on { Update } button successfully");
				flag = true;
			}

		} catch (Exception e) {
			LogUtility.logException("---> clickPmtUpdate <---", "Failed to click on { Update } in WOL application", e,
					LoggingLevel.ERROR, true);

		}
		return flag;
	}
}