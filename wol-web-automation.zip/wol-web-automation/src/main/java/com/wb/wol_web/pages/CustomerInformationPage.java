package com.wb.wol_web.pages;

/**
 * @author Ramesh Pagadala
 *
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.testbases.WOLTestBase;

public class CustomerInformationPage extends ObjectBase {

	public CustomerInformationPage() {
		PageFactory.initElements(driver, this);
	}

	CommonPage commonpage = new CommonPage();

	@FindBy(css = "div#pageContent strong")
	protected WebElement txtCurrentEmail;

	@FindBy(xpath = "//span[contains(text(),'Continue') and contains(@id,'button')]")
	private WebElement btnPasswordContinue;

	@FindBy(name = "cancel")
	protected WebElement btnCancel;

	@FindBy(name = "continue")
	protected WebElement btnContinue;

	@FindBy(name = "no")
	protected WebElement btnNo;

	@FindBy(name = "yes")
	protected WebElement btnYes;

	@FindBy(id = "lightboxContent0")
	protected WebElement popUpCancelWindow;

	@FindBy(css = "div#pageContent>div p")
	protected WebElement txtErrorPageTop;

	@FindBy(name = "password")
	protected WebElement txtPassword;

	@FindBy(css = "#pageContent div:nth-child(3) > div > div")
	protected WebElement txtNewEmail;

	@FindBy(css = "#pageContent div:nth-child(4) > div > div")
	protected WebElement txtVerifyNewEmail;

	@FindBy(name = "new-email")
	protected WebElement inputNewEmail;

	@FindBy(name = "new-email-conf")
	protected WebElement inputVerifyNewEmail;

	@FindBy(css = "#update_security > div:nth-child(2) div.errorInline")
	protected WebElement txtCurrentPassword;

	@FindBy(css = "#update_security > div:nth-child(3) div.errorInline")
	protected WebElement txtNewPassword;

	@FindBy(css = "#update_security > div:nth-child(4) div.errorInline")
	protected WebElement txtReTypePassword;

	@FindBy(css = "#update_security > div:nth-child(7) div.errorInline")
	protected WebElement txtNewUsername;

	@FindBy(css = "#update_security > div:nth-child(2) label")
	protected WebElement labelCurrentPassword;

	@FindBy(css = "#update_security > div:nth-child(3) label")
	protected WebElement labelNewPassword;

	@FindBy(css = "#update_security > div:nth-child(4) label")
	protected WebElement labelReTypeNewPassword;

	@FindBy(css = "label[data-wbst-message-key='profile.update_password_username.username'] ~ strong")
	protected WebElement labelCurrentUserName;

	@FindBy(css = "#update_security > div:nth-child(7) label")
	protected WebElement labelNewUserName;

	@FindBy(css = "div#pageContent>div[class='notification ']")
	protected WebElement txtUpdatedUsernamePasswordMessage;

	@FindBy(name = "old_password")
	protected WebElement inputCurrentPassword;

	@FindBy(name = "password1")
	protected WebElement inputNewPassword;

	@FindBy(name = "password2")
	protected WebElement inputReEnterPassword;

	@FindBy(name = "username")
	protected WebElement inputNewUserName;

	@FindBy(name = "update-password")
	protected WebElement btnUpdate;

	@FindBy(id = "login-password__pageErrors_gen__generic_error_msg__body")
	protected WebElement txtPasswordErrorMessage;

	@FindBy(css = "div#pageContent div:nth-of-type(1)")
	protected WebElement txtNote;

	@FindBy(css = "input#updateprofile")
	protected WebElement btnBusinessUpdate;

	@FindBy(css = "label[data-wbst-message-key='profile.update_business_info.businessname']~strong")
	protected WebElement txtBusinessUsername;

	@FindBy(name = "address1")
	protected WebElement inputAddress;

	@FindBy(name = "city-4")
	protected WebElement inputCity;

	@FindBy(name = "state")
	protected WebElement inputState;

	@FindBy(name = "zip")
	protected WebElement inputZipCode;

	@FindBy(name = "buphone1")
	protected WebElement inputBusinessPhone;

	@FindBy(css = "#updateprofile div:nth-child(3) > div > label")
	protected WebElement labelAddress;

	@FindBy(css = "#updateprofile div:nth-child(5) > div > label")
	protected WebElement labelCity;

	@FindBy(css = "#updateprofile div:nth-child(6) > div > label")
	protected WebElement labelState;

	@FindBy(css = "#updateprofile div:nth-child(7) > div > label")
	protected WebElement labelZipCode;

	@FindBy(css = "#updateprofile div:nth-child(8) > div > label")
	protected WebElement labelBusinessPhone;

	@FindBy(css = "div#pageContent  div:nth-of-type(2)")
	protected WebElement txtUpdateConfirmBusiness;

	@FindBy(css = "ul[class='nextsteps']>li")
	protected List<WebElement> linksUpdateInfoBusiness;

	@FindBy(id = "register-9")
	protected WebElement btnNoRecognizeOnComputer;

	@FindBy(id = "register-8")
	protected WebElement btnYesRecognizeOnComputer;

	@FindBy(css = "div#pageContent>div:nth-of-type(1)")
	protected WebElement txtSecInfoUpdate;

	@FindBy(id = "answer__input")
	protected WebElement inputAnswer;

	@FindBy(id = "chooseNo__input")
	protected WebElement btnNoRegisterDevice;

	@FindBy(id = "mainSiteNav__submenu5__menuLabel")
	protected WebElement btnMenuSupport;

	@FindBy(css = "div#mainSiteNav__submenu5__megaMenu li>a")
	protected List<WebElement> linksUnderSupport;

	@FindBy(id = "submit__actualButton")
	protected WebElement btnContinueAuthentication;

	@FindBy(id = "profileWidget__profileIcon")
	protected WebElement btnProfileWidget;

	@FindBy(css = "section#profileWidget__separator  p")
	protected List<WebElement> txtUnderProfile;

	@FindBy(css = "section#profileWidget__separator a")
	protected List<WebElement> linksUnderProfile;

	@FindAll({ @FindBy(id = "address-phone-change__pageTitle"), @FindBy(id = "address-phone-change-verify__pageTitle"),
			@FindBy(id = "address-phone-change-confirm__pageTitle") })
	protected WebElement txtChangeAddressTitle;

	@FindBy(css = "div#bodyContent  select")
	protected List<WebElement> listSecurityQs;

	@FindBy(css = "div#bodyContent  input[type='text']")
	protected List<WebElement> listAnswers;

	@FindBy(css = "#updateprofile div.ProdBodyBgShadow div>div.errorInline")
	protected WebElement txtAddresError;

	@FindBy(id = "answer__input")
	protected WebElement txtAnswerBox;

	@FindBy(css = "#pageContent  tr:nth-child(2) > td.description")
	protected WebElement txtUpdatedNewMail;

	@FindBy(xpath = "//p[@data-wbst-message-key='profile.securityinfo_tooltip']")
	protected WebElement txtParentSecurityInfo;

	@FindBy(xpath = "//div[@data-wbst-message-key='login.login-challenge.section_profile']")
	protected WebElement txtSimplifyLoginInfo;

	@FindBy(css = "div[class='errorInline ']")
	protected List<WebElement> listErrorMessages;

	@FindBy(css = "#bodyContent h1")
	protected WebElement txtPageTitle1;

	@FindAll({ @FindBy(css = "#bodyContent h3"), @FindBy(id = "page-title") })
	protected WebElement txtPageHeaderH3;

	public int count = 0;
	public String txtcurrentPassword = "";
	public String txtNewPasswordValue = "";
	public String txtReTypeNewPassword = "";
	public String txtNewUserName = "";
	public String name = "";
	public String txtUpdatedEmailAddress = wolWebUtil.getRandomString(7) + "@websterbank.com";
	public String txtMailAddress = "";
	public String currentUserName = "";

	/**
	 * checkCurrentEmailAddress: To get the current email address
	 * 
	 * @return: Mail address
	 */
	public String checkCurrentEmailAddress() {
		try {
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtCurrentEmail, maxTimeOut)) {
				String currentEmailAddress = webActions.getText(txtCurrentEmail);
				if (currentEmailAddress != null) {
					LogUtility.logInfo("-->checkCurrentEmailAddress<--",
							"Current Email Address: " + currentEmailAddress + "is displayed");
					return currentEmailAddress;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("-->checkCurrentEmailAddress<--", "Unable to verify the Current Email Address", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * clickOnButton: To Click on button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean clickOnButton(String btnName) {
		waits.waitForPageReadyState();
		WebElement btnToBeClicked = null;
		waits.waitForPageReadyState(maxTimeOut);
		try {
			switch (btnName) {
			case "Cancel":
				btnToBeClicked = btnCancel;
				waits.waitUntilElementIsPresent(btnCancel);
				break;
			case "No":
				btnToBeClicked = btnNo;
				break;
			case "Yes":
				btnToBeClicked = btnYes;
				waits.waitUntilElementIsPresent(btnYes);
				break;
			case "Continue":
				btnToBeClicked = btnContinue;
				break;
			case "Continue button":
				btnToBeClicked = btnContinueAuthentication;
				break;
			case "Update":
				btnToBeClicked = btnUpdate;
				break;
			case "Business Update":
				btnToBeClicked = btnBusinessUpdate;
				break;
			case "no":
				btnToBeClicked = btnNoRecognizeOnComputer;
				break;
			case "yes":
				btnToBeClicked = btnYesRecognizeOnComputer;
				break;
			case "no radio":
				btnToBeClicked = btnNoRegisterDevice;
				break;
			case "Support":
				btnToBeClicked = btnMenuSupport;
				break;
			case "Profile":
				btnToBeClicked = btnProfileWidget;
				break;
			default:
				LogUtility.logInfo("--->clickOnButton<---", "No case match found");
				break;
			}
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(btnToBeClicked, maxTimeOut)) {
				webActions.clickElement(btnToBeClicked);
				LogUtility.logInfo("--->clickOnButton<---", "Clicked on " + btnToBeClicked + " button");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnButton<-", "Unable click on " + btnToBeClicked + " button", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkErrorMessageOnPageTop: To get Error message on top of the page
	 */
	public String checkErrorMessageOnPageTop() {
		try {
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtErrorPageTop, maxTimeOut)) {
				String txtError = webActions.getText(txtErrorPageTop);
				LogUtility.logInfo("---->checkErrorMessageOnPageTop<----", txtError + " is displayed");
				return txtError.trim();
			}
		} catch (Exception e) {
			LogUtility.logException("->checkErrorMessageOnPageTop<-", "Error Message is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkTwoMessages : To check error message on new mail and verify new mail
	 * fields
	 * 
	 * @param txtErrorMessage
	 * @param txtVerifyErrorMessage
	 * 
	 */
	public boolean checkTwoMessages(String txtErrorMessage, String txtVerifyErrorMessage) {
		try {
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtNewEmail, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtNewEmail, txtErrorMessage)) {
					LogUtility.logInfo("---->checkTwoMessages<----", txtErrorMessage + " is present");
					if (wolWebUtil.verifyTextContains(txtVerifyNewEmail, txtVerifyErrorMessage)) {
						LogUtility.logInfo("--->checkTwoMessages<---", txtVerifyErrorMessage + " is present");
						return true;
					}
				}
		} catch (Exception e) {
			LogUtility.logException("->checkTwoMessages<-", "Error Messages are not displayed", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkVerifyEmailMessage : To verify the error message at confirm new email
	 * field
	 * 
	 * @param txtErrorMessage
	 * 
	 */
	public boolean checkVerifyEmailMessage(String txtErrorMessage) {
		try {
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtVerifyNewEmail, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtVerifyNewEmail, txtErrorMessage)) {
					LogUtility.logInfo("--->checkVerifyEmailMessage<---", txtErrorMessage + " is present");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkVerifyEmailMessage<-",
					"Error Messages: " + txtErrorMessage + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkUpdatedEmail: To Check the updated email is present or not
	 * 
	 * @param txtUpdatedEmail
	 * @return
	 */
	public boolean checkUpdatedEmail() {
		try {
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtUpdatedNewMail, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtUpdatedNewMail, txtUpdatedEmailAddress)) {
					LogUtility.logInfo("--->checkUpdatedEmail<---", txtUpdatedEmailAddress + " is present");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkUpdatedEmail<-",
					"Email Address: " + txtUpdatedEmailAddress + " is not displayed", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkCurrentUserName: To get the current user name
	 *
	 */
	public String checkCurrentUserName() {
		try {
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(labelCurrentUserName, maxTimeOut)) {
				currentUserName = webActions.getText(labelCurrentUserName);
				if (currentUserName != null) {
					LogUtility.logInfo("--->checkCurrentUserName<---", "current user name is " + currentUserName);
					return currentUserName;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->checkCurrentUserName<-", "Unable to get the current user name", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkAndEnterValues : To check the fields in update user name and password
	 * and enter the values to it
	 * 
	 * @param testDataMap
	 * @return
	 */
	public List<String> checkAndEnterValues(Map<String, String> testDataMap) {
		waits.waitForPageReadyState();
		List<String> details = new ArrayList<>();
		try {
			if (waits.waitUntilElementIsPresent(labelCurrentPassword, maxTimeOut)) {
				txtcurrentPassword = webActions.getText(labelCurrentPassword);
				txtNewPasswordValue = webActions.getText(labelNewPassword);
				txtReTypeNewPassword = webActions.getText(labelReTypeNewPassword);
				txtNewUserName = webActions.getText(labelNewUserName);
				details.clear();
				name = testDataMap.get("New User Name");
				if (testDataMap.containsKey(txtcurrentPassword)) {
					webActions.setValue(inputCurrentPassword, testDataMap.get("Current Password"));
					details.add(testDataMap.get("Current Password"));
					LogUtility.logInfo("-->checkAndEnterValues<--",
							"current password: " + testDataMap.get("Current Password"));
				}
				if (testDataMap.containsKey(txtNewPasswordValue)) {
					webActions.setValue(inputNewPassword, testDataMap.get("New Password"));
					details.add(testDataMap.get("New Password"));
					LogUtility.logInfo("--->checkAndEnterValues<---",
							"new password: " + testDataMap.get("New Password"));
				}
				if (testDataMap.containsKey(txtReTypeNewPassword)) {
					webActions.setValue(inputReEnterPassword, testDataMap.get("Re-Type New Password"));
					details.add(testDataMap.get("Re-Type New Password"));
					LogUtility.logInfo("--->checkAndEnterValues<---",
							"retype new password: " + testDataMap.get("Re-Type New Password"));
				}
				if (testDataMap.containsKey(txtNewUserName.subSequence(0, 13))) {
					if ((testDataMap.get("New User Name")).contains("user"))
						name = WOLTestBase.envProps.getProperty(testDataMap.get("New User Name"));
					if (webActions.isDisplayed(inputNewUserName)) {
						webActions.setValue(inputNewUserName, name);
						details.add(name);
						LogUtility.logInfo("--->checkAndEnterValues<---", "new user name: " + name);
					}
				}
				return details;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkAndEnterValues<-", "Unable to Check and enter values", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * updateMessage : To verify update message text
	 * 
	 * @param message
	 * @return
	 */
	public boolean updateMessage(String message) {
		try {
			waits.waitForDOMready();
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtUpdatedUsernamePasswordMessage, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtUpdatedUsernamePasswordMessage, message)) {
					LogUtility.logInfo("--->updateMessage<----", "update message as: " + message + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->updateMessage<-", "update message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * forgotPasswordErrorMessage :To verify the incorrect password message
	 * 
	 * @param message
	 * @return
	 */
	public boolean forgotPasswordErrorMessage(String message) {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtPasswordErrorMessage, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtPasswordErrorMessage, message)) {
					LogUtility.logInfo("--->forgotPasswordErrorMessage---<",
							"Forgot password error message as: " + message + "  is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->forgotPasswordErrorMessage<-", "Message: " + message + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterPassword : To enter the new password and click on continue button
	 * 
	 * @param newPassword
	 * @return
	 */
	public boolean enterPassword(String newPassword) {
		try {
			waits.waitForDOMready();
			commonpage.enterInAnswerTextBoxIfExists();
			if (waits.waitUntilElementIsPresent(txtPassword, maxTimeOut)) {
				webActions.setValue(txtPassword, newPassword);
				webActions.clickElement(btnPasswordContinue);
				LogUtility.logInfo("---> enterPassword <---", "Entered password value: " + newPassword);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterPassword<-", "Unable to enter password value: " + newPassword, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkSpecificErrorMessage : To get the error text at given label
	 * 
	 * @param labelName and errorMessage
	 * @return
	 */
	public boolean checkSpecificErrorMessage(String labelName, String txtErrorMessage) {
		WebElement labelText = null;
		try {
			switch (labelName) {
			case "Current Password":
				labelText = txtCurrentPassword;
				break;
			case "New Password":
				labelText = txtNewPassword;
				break;
			case "Re-Type New Password":
				labelText = txtReTypePassword;
				break;
			case "New User Name":
				labelText = txtNewUsername;
				break;
			default:
				LogUtility.logInfo("--->checkSpecificErrorMessage<---", "No case match found");
				break;
			}
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(labelText, maxTimeOut))
				if (wolWebUtil.verifyTextContains(labelText, txtErrorMessage)) {
					LogUtility.logInfo("----->checkSpecificErrorMessage<----", txtErrorMessage + " is present");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkSpecificErrorMessage<-", "Message:" + txtErrorMessage + " is not present",
					e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkNote: To get Note Message
	 *
	 */
	public boolean checkNote(String txtNoteMessage) {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtNote, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtNote, txtNoteMessage)) {
					LogUtility.logInfo("--->checkNote<---", txtNoteMessage + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkNote<-", "Note: " + txtNoteMessage + " is not displayed", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkAndEnterValues : To check the fields in update user name and password
	 * and enter the values to it
	 * 
	 * @param map
	 * @return
	 */
	public boolean checkAndEnterValuesOfUpdateBusiness(Map<String, String> map) {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtBusinessUsername, maxTimeOut)) {
				String txtAddress = webActions.getText(labelAddress);
				String txtCity = webActions.getText(labelCity);
				String txtState = webActions.getText(labelState);
				String txtZipCode = webActions.getText(labelZipCode);
				String txtBusinessPhone = webActions.getText(labelBusinessPhone);
				if (map.containsKey(txtAddress.trim())) {
					webActions.setValue(inputAddress, map.get("Address *"));
					LogUtility.logInfo("-->checkAndEnterValuesOfUpdateBusiness<--",
							"Address : " + map.get("Address *"));
				}
				if (map.containsKey(txtCity.trim())) {
					webActions.setValue(inputCity, map.get("City *"));
					LogUtility.logInfo("-->checkAndEnterValuesOfUpdateBusiness<--", "City : " + map.get("City *"));
				}
				if (map.containsKey(txtState.trim())) {
					webActions.setValue(inputState, map.get("State *"));
					LogUtility.logInfo("-->checkAndEnterValuesOfUpdateBusiness<--", "State : " + map.get("State *"));
				}
				if (map.containsKey(txtZipCode.trim())) {
					webActions.setValue(inputZipCode, map.get("Zip Code *"));
					LogUtility.logInfo("-->checkAndEnterValuesOfUpdateBusiness<--",
							"ZipCode : " + map.get("Zip Code *"));
				}
				if (map.containsKey(txtBusinessPhone.trim())) {
					webActions.setValue(inputBusinessPhone, map.get("Business Phone *"));
					LogUtility.logInfo("-->checkAndEnterValuesOfUpdateBusiness<--",
							"BusinessPhone : " + map.get("Business Phone *"));
				}
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->checkAndEnterValuesOfUpdateBusiness<-",
					"Unable to check and enter the values of update business", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * updateMessageBusiness : To verify Business update message text
	 * 
	 * @param message
	 * @return
	 */
	public boolean updateMessageBusiness(String message) {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtUpdateConfirmBusiness, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtUpdateConfirmBusiness, message)) {
					LogUtility.logInfo("--->updateMessageBusiness<---", message + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->updateMessageBusiness<-", "Unable to verify the message: " + message, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkCurrentBusinessUserName: To get the current Business user name
	 *
	 */
	public String checkCurrentBusinessUserName() {
		try {
			String currentUserName = "";
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtBusinessUsername, maxTimeOut)) {
				currentUserName = webActions.getText(txtBusinessUsername);
				if (currentUserName != null) {
					LogUtility.logInfo("--->checkCurrentBusinessUserName<----",
							"current user name is " + currentUserName);
					return currentUserName;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->checkCurrentBusinessUserName<-", "Unable to get the current business username",
					e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * checkLinkTitles: To verify the specified links are present or not
	 * 
	 * @param listLinkValues
	 *
	 */
	public int checkLinkTitles(List<String> listLinkValues) {
		waits.waitForDOMready();
		int count = 0;
		try {
			waits.waitForPageToLoad(maxTimeOut);
			for (WebElement link : linksUpdateInfoBusiness) {
				if (wolWebUtil.verifyTextContains(link, listLinkValues.toString())) {
					LogUtility.logInfo("----->checkLinkTitles<----", link + " is present");
					count++;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->checkLinkTitles<-", "Unable to check the link titles", e, LoggingLevel.ERROR,
					true);
		}
		return count;
	}

	/**
	 * checkMessage - to verify the update message
	 * 
	 * @param message
	 * @return
	 */
	public boolean checkMessage(String message) {
		try {
			if (waits.waitUntilElementIsPresent(txtSecInfoUpdate, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtSecInfoUpdate, message)) {
					LogUtility.logInfo("--->checkMessage<---", message + " is present");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkMessage<-", "Unable to check the Message: " + message, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterAnswer - To enter the answer in authentication page
	 * 
	 * @return
	 */
	public boolean enterAnswer() {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(inputAnswer, maxTimeOut)) {
				webActions.setValue(inputAnswer, "answer");
				LogUtility.logInfo("--->enterAnswer<---", "Authentication details completed successfully");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterAnswer<-", "Unable to enter Authentication details", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * selectAndClick - select the value and click on the continue button
	 * 
	 * @param btnName
	 * @return
	 */
	public boolean selectAndClick(String btnName) {
		try {
			if (waits.waitUntilElementIsPresent(btnNoRegisterDevice, maxTimeOut)) {
				webActions.clickElement(btnNoRegisterDevice);
				webActions.clickElement(btnContinueAuthentication);
				LogUtility.logInfo("--->selectAndClick<---",
						"Selected and clicked on No register device button successfully");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->selectAndClick<-", "Unable to select and click on NO register device button", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterOnlyPassword - Enter only password without authentication page
	 * 
	 * @return
	 */
	public boolean enterOnlyPassword() {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtPassword, maxTimeOut)) {
				commonpage.enterPassword();
				LogUtility.logInfo("---> enterOnlyPassword <---", "Entered password");
				return true;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterOnlyPassword<-", "Unable to enter the password", e, LoggingLevel.ERROR,
					true);
		}
		return false;
	}

	/**
	 * checkForLinkNotPresent : To verify link is not present
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean checkForLinkNotPresent(String linkName) {
		try {
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			for (WebElement link : linksUnderSupport) {
				if (wolWebUtil.verifyTextContains(link, linkName)) {
					LogUtility.logError("---> checkForLinkNotPresent <---", linkName + " is present under support");
					return false;
				}
			}
			LogUtility.logInfo("---> checkForLinkNotPresent <---", linkName + " is not present under support");
		} catch (Exception e) {
			LogUtility.logException("->checkForLinkNotPresent<-", "Unable to check the for the link", e,
					LoggingLevel.ERROR, true);
		}
		return true;
	}

	/**
	 * checkForPresence : To check for the present of parameters
	 * 
	 * @param welcome
	 * @param lastlogin
	 * @param messages
	 * @return
	 */
	public List<String> checkForPresence(String txtWelcome, String txtLastloginDetails, String txtMessages) {
		waits.waitForDOMready();
		waits.waitForPageToLoad(maxTimeOut);
		List<String> details = new ArrayList<>();
		try {
			for (WebElement para : txtUnderProfile) {
				if (wolWebUtil.verifyTextContains(para, txtWelcome)
						|| wolWebUtil.verifyTextContains(para, txtLastloginDetails)
						|| wolWebUtil.verifyTextContains(para, txtMessages))
					details.add(webActions.getText(para));
			}
			LogUtility.logInfo("---> checkForPresence <---", "Verified for the " + details.toString());
		} catch (Exception e) {
			LogUtility.logException("->checkForPresence<-", "Unable to check the presence of labels", e,
					LoggingLevel.ERROR, true);
		}
		return details;
	}

	/**
	 * checkLinkValues: To check for the links
	 * 
	 * @param testDataMap
	 * @return
	 */
	public List<String> checkLinkValues(Map<String, String> testDataMap) {
		waits.waitForDOMready();
		waits.waitForPageToLoad(maxTimeOut);
		List<String> links = new ArrayList<>();
		try {
			for (WebElement link : linksUnderProfile) {
				if (testDataMap.containsValue(webActions.getText(link)))
					links.add(link.getText());
			}
			LogUtility.logInfo("---> listLinkValues <---", "Verified the links" + links);
		} catch (Exception e) {
			LogUtility.logException("->listLinkValues<-", "Unable to verify the link values", e, LoggingLevel.ERROR,
					true);
		}
		return links;
	}

	/**
	 * clickOnLink - Click on the links under profile widget
	 * 
	 * @param linkName
	 * @return
	 */
	public boolean clickOnLink(String linkName) {
		waits.waitForDOMready();
		waits.waitForPageToLoad(maxTimeOut);
		try {
			for (WebElement link : linksUnderProfile) {
				if (wolWebUtil.verifyTextContains(link, linkName)) {
					webActions.clickElementJS(link);
					LogUtility.logInfo("--->clickOnLink<---", "Clicked on link " + linkName);
					return true;
				}
			}
		} catch (Exception e) {
			LogUtility.logException("->clickOnLink<-", "Unable to click on link", e, LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * selectRandomQuestion: To select the random question
	 * 
	 * @return
	 */
	public boolean selectRandomQuestion(String answerType) {
		try {
			String value = "";
			waits.waitForDOMready();
			// Taking time to load questions in drop-down
			waits.staticWait(5);
			switch (answerType) {
			case "Clear":
				value = "";
				break;
			case "Lessthan 3":
				value = wolWebUtil.getRandomString(2);
				break;
			case "Morethan 19":
				value = wolWebUtil.getRandomString(19);
				break;
			case "valid":
				value = "answer";
				break;
			default:
				LogUtility.logInfo("--->selectRandomQuestion<---", "No case match found");
				break;
			}
			for (WebElement questions : listSecurityQs)
				webActions.selectDropDownByIndex(questions, Integer.parseInt(wolWebUtil.getRandomNumber(1)));
			for (WebElement answer : listAnswers)
				webActions.setValue(answer, value);
			LogUtility.logInfo("--->selectRandomQuestion<---", "Selected the questions");
			return true;
		} catch (Exception e) {
			LogUtility.logException("->selectRandomQuestion<-", "Unable to select the random question", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkAddressErrorMessage: To check the address error message
	 * 
	 * @param txtErrorMessage
	 * @return
	 */
	public boolean checkAddressErrorMessage(String txtErrorMessage) {
		try {
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtAddresError, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtAddresError, txtErrorMessage)) {
					LogUtility.logInfo("----->checkAddressErrorMessage<----", txtErrorMessage + " is present");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkAddressErrorMessage<-", "Unable to check the address error message", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkAddressPageTitle: Check Address page title
	 * 
	 * @param pageName
	 * @return
	 */
	public boolean checkAddressPageTitle(String pageName) {
		waits.waitForDOMready();
		try {
			waits.waitForPageReadyState();
			//TODO: Taking more time to load in firefox
			waits.staticWait(5);
			waits.waitForPageReadyState();
			if (waits.waitUntilElementIsPresent(txtChangeAddressTitle, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtChangeAddressTitle, pageName)) {
					LogUtility.logInfo("-->checkAddressPageTitle<---", "redirected to " + pageName + " page");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkAddressPageTitle<-", "Unable to check the address page title", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * enterNewEmailAddress : To enter the new email address in new eMail Address
	 * 
	 * @param mailType
	 * @return
	 */
	public String enterNewEmailAddress(String mailType) {
		waits.waitForDOMready();
		try {
			waits.waitForPageToLoad(maxTimeOut);
			if (mailType.equalsIgnoreCase("Random Valid Email")) {
				txtMailAddress = txtUpdatedEmailAddress;
			} else
				txtMailAddress = wolWebUtil.getRandomString(6) + "@webster";
			if (webActions.isDisplayed(inputNewEmail)) {
				webActions.setValue(inputNewEmail, txtMailAddress);
				LogUtility.logInfo("--->enterNewEmailAddress<----", "new email " + txtMailAddress + " is Entered");
				return txtMailAddress;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterNewEmailAddress<-", "Unable to enter new email address", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * enterVerifyNewEmailAddress : To enter the verify the new email address
	 * 
	 * @param mailType
	 * @return
	 */
	public String enterVerifyNewEmailAddress(String mailType) {
		try {
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			if (mailType.equalsIgnoreCase("Random Valid Email")) {
				txtMailAddress = txtUpdatedEmailAddress;
			} else
				txtMailAddress = wolWebUtil.getRandomString(6) + "@webster";
			if (webActions.isDisplayed(inputVerifyNewEmail)) {
				webActions.setValue(inputVerifyNewEmail, txtMailAddress);
				LogUtility.logInfo("--->enterVerifyNewEmailAddress<---",
						"verify new email " + txtMailAddress + " is Entered");
				return txtMailAddress;
			}
		} catch (Exception e) {
			LogUtility.logException("->enterVerifyNewEmailAddress<-", "Unable to enter verify new email address", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}

	/**
	 * verifySecurityInfo: To verify the security information
	 * 
	 * @param infoText
	 * @return
	 */
	public boolean verifySecurityInfo(String infoText) {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtParentSecurityInfo, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtParentSecurityInfo, infoText)) {
					LogUtility.logInfo("--->verifySecurityInfo<---", "Security Info " + infoText + " is displayed");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->verifySecurityInfo<-", "Unable to verify the security information", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifySimplifyLoginInfo: To verify the simplify the login text
	 * 
	 * @param text1
	 * @param text2
	 * @return
	 */
	public boolean verifySimplifyLoginInfo(String text1, String text2) {
		try {
			waits.waitForDOMready();
			if (waits.waitUntilElementIsPresent(txtSimplifyLoginInfo, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtSimplifyLoginInfo, text1)) {
					if (wolWebUtil.verifyTextContains(txtSimplifyLoginInfo, text2)) {
						LogUtility.logInfo("--->verifySimplifyLoginInfo<---",
								"Simplify login Info " + text1 + ", " + text2 + " are displayed");
						return true;
					}
				}
		} catch (Exception e) {
			LogUtility.logException("->verifySimplifyLoginInfo<-", "Unable to verify the simplify login info text", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * checkPageTitle: To get the page title
	 *
	 */
	public boolean checkPageTitle(String pageName) {
		try {
			waits.waitForDOMready();
			waits.staticWait(5);
			waits.waitForPageReadyState();
			waits.waitUntilElementIsPresent(txtPageTitle1, maxTimeOut);
			if (waits.waitUntilElementIsPresent(txtUpdatedUsernamePasswordMessage, maxTimeOut))
				if (wolWebUtil.verifyTextContains(txtPageTitle1, pageName)
						|| wolWebUtil.verifyTextContains(txtPageHeaderH3, pageName)) {
					LogUtility.logInfo("--->checkPageTitle<---", "redirected to " + pageName + " page");
					return true;
				}
		} catch (Exception e) {
			LogUtility.logException("->checkPageTitle<--", "Failed to verify the page " + pageName, e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

	/**
	 * verifyAnswerError: To verify the answer field error message
	 * 
	 * @param answerError
	 * @return
	 */
	public boolean verifyAnswerError(String answerError) {
		try {
			waits.waitForDOMready();
			waits.waitForPageToLoad(maxTimeOut);
			for (WebElement errorMessage : listErrorMessages) {
				if (wolWebUtil.verifyTextContains(errorMessage, answerError)) {
					LogUtility.logInfo("--->verifyAnswerError<---", "Answer Error:" + answerError + " is displayed");
					count++;
				}
			}
			if (count == listErrorMessages.size())
				return true;
		} catch (Exception e) {
			LogUtility.logException("->verifyAnswerError<-", "Unable to verify the answer error message", e,
					LoggingLevel.ERROR, true);
		}
		return false;
	}

}