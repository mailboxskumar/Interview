/**
 * @author VSomalaraju-adm
 */

package com.wb.wol_web.pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_web.actions.ObjectBase;
import com.wb.wol_web.utilities.WOLWebUtil;

public class AccountEligibilityWebcomPage extends ObjectBase {
	public AccountEligibilityWebcomPage() {
		PageFactory.initElements(driver, this);
	}

	public String removeAccount = "//td[contains(text(),'%s')]//following-sibling::td/input[@type='checkbox']";

	@FindBy(name = "backend_account_number")
	protected WebElement txtAcctNumber;

	@FindBy(id = "account_nickname_")
	protected WebElement txtAcctNickName;

	@FindBy(id = "accountDetailsSubmitButton")
	protected WebElement btnSubmit;

	@FindBy(xpath = "//div[@class='message']")
	protected WebElement txtConfirmationMessage;

	/**
	 * @param acctNum
	 * @param nickName
	 * @return
	 */
	public boolean addAccountInWebcom(Map<String, String> accountInfo) {
		boolean flag = false;
		try {
			waits.waitUntilElementIsPresent(txtAcctNumber, maxTimeOut);
			webActions.setValue(txtAcctNumber, accountInfo.get("AccountorCreditCardNumber"));
			waits.waitForDOMready();
			if (webActions.getAttributeValue(txtAcctNumber, "value")
					.equalsIgnoreCase(accountInfo.get("AccountorCreditCardNumber"))) {
				flag = true;
				LogUtility.logInfo("---> addAccountWebcom <---",
						"Entered { " + accountInfo.get("AccountorCreditCardNumber") + "} successfully");
			} else
				LogUtility.logInfo("---> addAccountWebcom <---",
						"Faild to Enter { " + accountInfo.get("AccountorCreditCardNumber") + "} ");
			clickSubmitButton();
		} catch (Exception e) {
			LogUtility.logException("---> addAccountWebcom <---", "Failed to enter account details in{ Update Webster Accounts} page in webcom",e,LoggingLevel.ERROR, true);
		}
		return flag;
	}

	public void clickSubmitButton() {
		try {
			waits.waitUntilElementIsPresent(btnSubmit);
			webActions.clickElementJS(btnSubmit);
			waits.waitForDOMready();
			waits.staticWait(3);// It worked only with static wait
			LogUtility.logInfo("---> clickSubmitButton <---", "Clicked on Submit button successfully");
		} catch (Exception e) {
			LogUtility.logException("---> clickSubmitButton <---",
					"Failed to click submit button in { Update Webster Accounts } page in Webcom application", e, LoggingLevel.ERROR, true);
			throw (e);
		}
	}

	public boolean verifyAddAccountMsg(Map<String, String> accountInfo) {
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(txtConfirmationMessage, maxTimeOut)) {
				return wolWebUtil.verifyText(txtConfirmationMessage, accountInfo.get("Message"));
			}

		} catch (Exception e) {
			LogUtility.logException("---> verifyAddAccountMsg <---",
					"Failed to verify { " + accountInfo.get("Message") + " } text in WEBCOM application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @author VSomalaraju-adm
	 * @param accountInfo
	 * @return
	 */
	public boolean removeAccountInWebcom(Map<String, String> accountInfo) {
		boolean flag = false;
		try {
			WebElement chkRemoveAcct = driver
					.findElement(By.xpath(removeAccount.replace("%s", accountInfo.get("AccountorCreditCardNumber"))));
			webActions.clickElementJS(chkRemoveAcct);
			clickSubmitButton();	
			waits.waitForPageToLoad(maxTimeOut);
			waits.staticWait(3);// It is required to work this function
			LogUtility.logInfo("---> removeAccountInWebcom <---" , "Account { "+accountInfo.get("AccountorCreditCardNumbe")+" } deleted successfully");
			flag = true;
		} catch (Exception e) {
			LogUtility.logException(
					"---> removeAccountInWebcom <---", " Unable to find the  { "
							+ accountInfo.get("AccountorCreditCardNumber") + " } text in WEBCOM application",
					e, LoggingLevel.ERROR, true);
		}
		return flag;
	}

	/**
	 * @param accountInfo
	 * @return
	 */
	public boolean verifyRemoveAccountConfirmMessage(Map<String, String> accountInfo){
		boolean flag = false;
		try {
			if (waits.waitUntilElementIsPresent(txtConfirmationMessage,maxTimeOut)) {
				return wolWebUtil.verifyText(txtConfirmationMessage, accountInfo.get("RemoveMessage"));
			}
		} catch (Exception e) {
			LogUtility.logException("---> verifyRemoveAccountConfirmMessage <---",
					"Failed to verify { " + accountInfo.get("RemoveMessage") + " } text in WEBCOM application", e,
					LoggingLevel.ERROR, true);
		}
		return flag;
	}
}

