package com.wb.wol_mobile.steps;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.CommonPage;
import com.wb.wol_mobile.pages.ManageAlertsPage;
import com.wb.wol_mobile.pages.SettingsPage;
import com.wb.wol_mobile.pages.ViewAccountsPage;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AlertsSteps extends ObjectBase {

	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	ManageAlertsPage manageAlertsPage = new ManageAlertsPage();
	SettingsPage settingsPage = new SettingsPage();
	CommonPage commonPage = new CommonPage();
	String thresholdAmountDisplayedBefore;
	String thresholdAmountDisplayedAfter;

	@Then("^View Accounts page is displayed$")
	public void accounts_page_is_displayed() throws Exception {
		try {
			viewAccountsPage.verifyViewAccountsPageTitle();
			reportPass("View Account Page is displayed");
		} catch (Exception e) {
			reportFail("View Accounts Page not displayed after login " + e);
			throw new Exception();
		}
	}

	@Then("I verify account current InActive Error Message as {string} and accept Ok Button")
	public void i_verify_account_current_InActive_Error_Message_as_and_accept_Ok_Button(String errorMessage)
			throws Exception {
		try {
			viewAccountsPage.verifyTemporarlyUnAvailableErrorMessage(errorMessage);
			reportPass("In Active Error message is displayed and clicked on ok Button");
		} catch (Exception e) {
			reportFail("Unable to handle In Active Error message is displayed and clicked on ok Button " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Settings icon$")
	public void i_clicked_on_Settings_icon() throws Exception {
		try {
			viewAccountsPage.clickSettingsIcon();
			reportPass("Clicked on Settings Icon");
		} catch (Exception e) {
			reportFail("Unable to click on settings icon " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Manage Alerts text$")
	public void i_clicked_on_Manage_Alerts_text() throws Exception {
		try {
			settingsPage.clickManageAlerts();
			reportPass("Clicked on Manage Alerts option");
		} catch (Exception e) {
			reportFail("Unable to click Manage Alerts Option " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Account Alerts text$")
	public void i_clicked_on_Account_Alerts_text() throws Exception {
		try {
			manageAlertsPage.clickAccountAlertsOption();
			reportPass("Clicked on Account alerts option");
		} catch (Exception e) {
			reportFail("Unable to click on Account Alerts Option " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Account Alerts text to verify error message$")
	public void i_clicked_on_Account_Alerts_text_to_verify_error_message() throws Exception {
		try {
			manageAlertsPage.clickAccountAlerts();
			reportPass("Clicked on Account alerts option");
		} catch (Exception e) {
			reportFail("Unable to click on Account Alerts Option " + e);
			throw new Exception();
		}
	}

	@Then("^All accounts should display with balances$")
	public void all_accounts_should_display_with_balances() throws Exception {
		try {
			manageAlertsPage.getListOfAccounts();
			reportPass("All the account are displayed");
		} catch (Exception e) {
			reportFail("Unable to retrieve the accounts displayed " + e);
			throw new Exception();
		}
	}

	@When("^I select any Account$")
	public void i_select_any_Account() throws Exception {
		try {
			String accountClicked = manageAlertsPage.clickOnAnyAccount();
			reportPass("Clicked on any Account " + accountClicked);
		} catch (Exception e) {
			reportFail("Unable to click on any account " + e);
			throw new Exception();
		}
	}

	@Then("^I verify selected account is displayed with last four digits of account number$")
	public void i_verify_selected_account_is_displayed_with_last_four_digits_of_account_number() throws Exception {
		try {
			manageAlertsPage.verifyLastFourDigitsDisplayed();
			reportPass("Verified last four digits displayed");
		} catch (Exception e) {
			reportFail("Unable to verify the account number displayed with last four digits " + e);
			throw new Exception();
		}
	}

	@Then("^I see \"([^\"]*)\"$")
	public void i_see(String labelName) throws Exception {
		try {
			manageAlertsPage.verifyLabelName(labelName);
			reportPass("Verified label name " + labelName);
		} catch (Exception e) {
			reportFail("Unable to verify the label name " + labelName + " due to " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Text icon in alerts page$")
	public void i_clicked_on_Text_icon_in_alerts_page() throws Exception {
		try {
			manageAlertsPage.clickOnTextIcon();
			reportPass("Clicked on Text Icon in alerts page");
		} catch (Exception e) {
			reportFail("Unable to click on Text Icon " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Text Alerts screen display \"([^\"]*)\"$")
	public void i_verify_Text_Alerts_screen_display(String textIconMessage) throws Exception {
		try {
			manageAlertsPage.verifyTextAlertsScreenMessage(textIconMessage);
			reportPass("Verified the Message of Text Icon in Alerts Screen");
		} catch (Exception e) {
			reportFail("Unable to verify the Text Alerts Screen Message " + e);
			throw new Exception();
		}
	}

	@Then("^I verify \"([^\"]*)\"$")
	public void i_verify(String dataRatesMessage) throws Exception {
		try {
			manageAlertsPage.verifyDataRatesMessage(dataRatesMessage);
			reportPass("Verified the data rates may apply message");
		} catch (Exception e) {
			reportFail("Unable to verify the message " + dataRatesMessage + " " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Primary Phone and Secondary Phone number should display$")
	public void i_verify_Primary_Phone_and_Secondary_Phone_number_should_display() throws Exception {
		try {
			manageAlertsPage.verifyNumberTextFields();
			reportPass("Verified the Primary and Secondary Phone number text fields");
		} catch (Exception e) {
			reportFail("Unable to verify the Primary phone or Secondary phone number " + e);
			throw new Exception();
		}
	}

	@Then("^Selected account displays threshold amount options$")
	public void selected_account_displays_threshold_amount_options() throws Exception {
		try {
			manageAlertsPage.verifyThresholdAmountOptions();
			reportPass("Verified the threshold amount options");
		} catch (Exception e) {
			reportFail("Unable to verify the Threashold amounts Options " + e);
			throw new Exception();
		}
	}

	@Then("I verify the balance available for {string}")
	public void i_verify_the_balance_available_for(String balanceType) {
		try {
			thresholdAmountDisplayedBefore = manageAlertsPage
					.getThresholdBalanceAvailable(jsonDataParser.getTestDataMap().get(balanceType));
			reportPass("Verified and displayed threshold amount");
		} catch (Exception e) {
			reportHardFail("Unable to get the Threashold amount " + e);
		}
	}

	@When("I verify the balance available for {string} is same")
	public void i_verify_the_balance_available_for_is_same(String balanceType) throws Exception {
		thresholdAmountDisplayedAfter = manageAlertsPage
				.getThresholdBalanceAvailable(jsonDataParser.getTestDataMap().get(balanceType));
		if (thresholdAmountDisplayedAfter.equals(thresholdAmountDisplayedBefore)) {
			reportPass("Verified the displayed threshold amount is same as before");
		} else {
			reportHardFail("Unable to verify the Threashold amount is same as before");
		}
	}

	@When("^I clicked on any threshold amount type alert$")
	public void i_clicked_on_any_threshold_amount_type_alert() throws Exception {
		try {
			manageAlertsPage.clickOnAnyThresholdAmount();
			reportPass("Clicked on Threshold amount option");
		} catch (Exception e) {
			reportFail("Unable to click on Threshold amount option " + e);
			throw new Exception();
		}
	}

	@Then("^Enter Amount Popup displays$")
	public void popup_displays() throws Exception {
		try {
			manageAlertsPage.enterAmountPopupDisplay();
			reportPass("Enter amount popup displayed and verified the elements on it");
		} catch (Exception e) {
			reportFail("Enter amountPopup is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("Enter Amount Popup displays for iOS")
	public void enter_Amount_Popup_displays_for_iOS() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equals("ios"))
				manageAlertsPage.enterAmountPopupDisplay();
			reportPass("Enter amount popup displayed and verified the elements on it");
		} catch (Exception e) {
			reportHardFail("Enter amountPopup is not displayed " + e);
		}
	}

	@When("^I enter \"([^\"]*)\" balance$")
	public void i_enter_balance(String amount) throws Exception {
		try {
			manageAlertsPage.enterAmount(amount);
			reportPass("Entered amount" + amount);
		} catch (Exception e) {
			reportFail("Unable to enter amount " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Save button$")
	public void i_clicked_on_Save_button() throws Exception {
		try {
			manageAlertsPage.clickSaveButton();
			reportPass("Clicked on Save button");
		} catch (Exception e) {
			reportFail("Unable to click on Save button " + e);
			throw new Exception();
		}
	}

	@Then("^System should display \"([^\"]*)\" with ok button$")
	public void system_should_display_with_ok_button(String error) throws Exception {
		try {
			manageAlertsPage.verifyThresholdErrorMessage(error);
			reportPass("Error message displayed when entered amount zero with ok button as " + error);
		} catch (Exception e) {
			reportFail("Error message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("^Error message displayed \"([^\"]*)\"$")
	public void error_message_displayed(String errorMessage) throws Exception {
		try {
			manageAlertsPage.verifyErrorMessageForClosedAccounts(testDataMap.get(errorMessage));
			reportPass("Error message displayed in alerts page for closed accounts " + errorMessage);
		} catch (Exception e) {
			reportFail("Error message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("^List of accounts displayed$")
	public void list_of_accounts_displayed() throws Exception {
		try {
			manageAlertsPage.getListOfAccounts();
			reportPass("List of accounts displayed");
		} catch (Exception e) {
			reportFail("List of account not displayed " + e);
			throw new Exception();
		}
	}

	@Then("^Ineligible accounts should not display like Loan and Credit Card$")
	public void ineligible_accounts_should_not_display_like_Loan_and_Credit_Card() throws Exception {
		try {
			manageAlertsPage.getListOfAccounts();
			reportPass("Verified loan and credit card accounts are not diplayes");
		} catch (Exception e) {
			reportFail("Loan and Credit Card accounts are also displayed " + e);
			throw new Exception();
		}
	}

	@Then("^Ineligible accounts should not display like Closed and NA accounts$")
	public void ineligible_accounts_should_not_display_like_Closed_and_NA_accounts() throws Exception {
		try {
			manageAlertsPage.getListOfAccounts();
			reportPass("Verified closed and NA accounts are not diplayed");
		} catch (Exception e) {
			reportFail("Not displayed closed and NA accounts " + e);
			throw new Exception();
		}
	}

	@When("^I disable all three alerts channel$")
	public void i_disable_all_three_alerts_channel_like() throws Exception {
		try {
			manageAlertsPage.disableAlerts();
			reportPass("Disabled all three alert channels");
		} catch (Exception e) {
			reportFail("Diabling alert channel is failed " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Threshold error message on Android \"([^\"]*)\" and iOS \"([^\"]*)\"$")
	public void i_verify_Threshold_error_message_on_Android_and_iOS(String android, String iOS) throws Exception {
		try {
			manageAlertsPage.verifyErrorMessageThresholdAlerts(android, iOS);
			reportPass("Verified the threshold error message when all alerts channels disabled");
		} catch (Exception e) {
			reportFail("Unable to verify the threshold error message " + e);
			throw new Exception();
		}

	}

	@When("^I entered Valid test Phone Number as \"([^\"]*)\"$")
	public void i_entered_Valid_test_Phone_Number_as(String number) throws Exception {
		try {
			manageAlertsPage.enterPhoneNumber(number);
			reportPass("Entered phone number as " + number);
		} catch (Exception e) {
			reportFail("Unable to enter the phone number " + number + " due to " + e);
			throw new Exception();
		}
	}

	@When("I entered Valid test Phone Number in Secondary as {string}")
	public void i_entered_Valid_test_Phone_Number_in_Secondary_as(String number) throws Exception {
		try {
			manageAlertsPage.enterPhoneNumberSecondary(number);
			reportPass("Entered phone number as " + number);
		} catch (Exception e) {
			reportFail("Unable to enter the phone number " + number + " due to " + e);
			throw new Exception();
		}
	}

	@When("^Enabled button$")
	public void enabled_button() throws Exception {
		try {
			manageAlertsPage.enableToggleButton();
			reportPass("Enabled toggle button");
		} catch (Exception e) {
			reportFail("Unable to toggle button " + e);
			throw new Exception();
		}
	}

	@When("^Enabled Secondary button$")
	public void enabled_secondary_button() throws Exception {
		try {
			manageAlertsPage.enableSecondaryToggleButton();
			reportPass("Enabled toggle button");
		} catch (Exception e) {
			reportFail("Unable to toggle button " + e);
			throw new Exception();
		}
	}

	@Then("^System should display Validation Code page$")
	public void system_should_display_Validation_Code_page() throws Exception {
		try {
			manageAlertsPage.verifyValidationCodePage();
			reportPass("Validation code page is verified ");
		} catch (Exception e) {
			reportFail("Unable to verify validation code page " + e);
			throw new Exception();
		}
	}

	@When("^I enter invalid data like \"([^\"]*)\"$")
	public void i_enter_invalid_data_like(String vCode) throws Exception {
		try {
			manageAlertsPage.enterValidationCode(vCode);
			reportPass("Validation code entered as " + vCode);
		} catch (Exception e) {
			reportFail("Unable to enter validation code " + e);
			throw new Exception();
		}
	}

	@When("^Click on Ok or Verify Code button$")
	public void click_on_Done_or_Verify_Code_button() throws Exception {
		try {
			manageAlertsPage.clickOkValidationCodePage();
			reportPass("Clicked on Ok/Verify Code ");
		} catch (Exception e) {
			reportFail("Unable to click on Ok/Verify Code button " + e);
			throw new Exception();
		}
	}

	@Then("^System displays error message \"([^\"]*)\"$")
	public void system_displays_error_message(String errMessage) throws Exception {
		try {
			manageAlertsPage.verifyValidationCodePageError(errMessage);
			reportPass("Verified the error message in validation code page");
		} catch (Exception e) {
			reportFail("Unable to verify the error message in validation code page " + e);
			throw new Exception();
		}
	}

	@When("^I click on Cancel button$")
	public void i_click_on_Cancel_button() throws Exception {
		try {
			manageAlertsPage.clickOnCancelButton();
			reportPass("Clicked on Cancel button");
		} catch (Exception e) {
			reportFail("Unable to click on the Cancel button " + e);
			throw new Exception();
		}
	}

	@Then("^Error displayed as \"([^\"]*)\"$")
	public void error_displayed_as(String errMessage) throws Exception {
		try {
			manageAlertsPage.validateErrorMessageValidationCode(errMessage);
			reportPass("Error message is displayed as " + errMessage);
		} catch (Exception e) {
			reportFail("Unable to verify the error message" + errMessage + " " + e);
			throw new Exception();
		}
	}

	@When("^I entered Invalid test Phone Number as \"([^\"]*)\"$")
	public void i_entered_Invalid_test_Phone_Number_as(String inValidPhNumber) throws Exception {
		try {
			manageAlertsPage.enterPhoneNumber(inValidPhNumber);
			reportPass("Invalid phone number entered as " + inValidPhNumber);
		} catch (Exception e) {
			reportFail("Unable to enter the invalid phone number " + inValidPhNumber + " due to " + e);
			throw new Exception();
		}
	}

	@When("I entered Invalid test Secondary Phone Number as {string}")
	public void i_entered_Invalid_test_Secondary_Phone_Number_as(String inValidPhNumber) throws Exception {
		try {
			manageAlertsPage.enterPhoneNumberSecondary(inValidPhNumber);
			reportPass("Invalid phone number entered as " + inValidPhNumber);
		} catch (Exception e) {
			reportFail("Unable to enter the invalid phone number " + inValidPhNumber + " due to " + e);
			throw new Exception();
		}
	}

	@Then("^Error message is displayed as \"([^\"]*)\" with Ok button$")
	public void error_message_is_displayed_as_with_Ok_button(String errMessageInValidPhNumber) throws Exception {
		try {
			manageAlertsPage.validateErrorMessageInvalidPhNumber(errMessageInValidPhNumber);
			reportPass("Error message displayed as " + errMessageInValidPhNumber);
		} catch (Exception e) {
			reportFail("Error message is not validated for invalid phone number " + e);
			throw new Exception();
		}
	}

	@When("^I navigated back$")
	public void i_navigated_back() throws Exception {
		try {
			manageAlertsPage.navigateBack();
			reportPass("Successfully navigated back");
		} catch (Exception e) {
			reportFail("Unable to navigate back " + e);
			throw new Exception();
		}
	}

	@Then("^Popup should display for iOS \"([^\"]*)\" Android \"([^\"]*)\"$")
	public void popup_should_display_for_iOS_Android(String iOS, String android) throws Exception {
		try {
			manageAlertsPage.validateErrorMessageDiscardChanges(iOS, android);
			reportPass("Error message validated when discarded the changes");
		} catch (Exception e) {
			reportFail("Popup is not displayed when changes are discarded " + e);
			throw new Exception();
		}
	}

	@When("^I leave phone number empty and switch toogle$")
	public void i_leave_phone_number_empty_and_switch_toogle() throws Exception {
		try {
			manageAlertsPage.clearPrimaryPhoneNumber();
			manageAlertsPage.enableToggleButton();
			reportPass("Left the phone number field empty");
		} catch (Exception e) {
			reportFail("Unable to switch toogle to On " + e);
			throw new Exception();
		}
	}

	@When("^I leave Secondary phone number empty and switch toogle$")
	public void i_leave_secondary_phone_number_empty_and_switch_toogle() throws Exception {
		try {
			manageAlertsPage.clearSecondaryPhoneNumber();
			manageAlertsPage.enableSecondaryToggleButton();
			reportPass("Left the Secondary phone number field empty");
		} catch (Exception e) {
			reportFail("Unable to switch Secondary phone number toogle to On " + e);
			throw new Exception();
		}
	}

	@Then("^Error message displayed as \"([^\"]*)\"$")
	public void error_message_displayed_as(String errMessageEmtpyPhNumber) throws Exception {
		try {
			manageAlertsPage.validateErrorMessageEmptyPhNumber(errMessageEmtpyPhNumber);
			reportPass("Verified the error message when phone number left empty");
		} catch (Exception e) {
			reportFail("Unable to verify the error message when ph number field left empty " + e);
			throw new Exception();
		}
	}

	@Then("^Page navigates to Manage Alerts Page$")
	public void page_navigates_to_Manage_Alerts_Page() throws Exception {
		try {
			manageAlertsPage.onMananageAlertsPage();
			reportPass("User navigated to Manage Alerts");
		} catch (Exception e) {
			reportFail("User navigated to Manage Alerts " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Email icon in alerts page$")
	public void i_clicked_on_Email_icon_in_alerts_page() throws Exception {
		try {
			manageAlertsPage.clickOnEmailIcon();
			reportPass("Clicked on Email Icon");
		} catch (Exception e) {
			reportFail("Unable to click on email icon " + e);
			throw new Exception();
		}
	}

	@Then("^I verify valid email address displayed contains \"([^\"]*)\"$")
	public void i_verify_valid_email_address_displayed_contains(String emailAddress) throws Exception {
		try {
			manageAlertsPage.validateEmailAddress(emailAddress);
			reportPass("Verified valid email present");
		} catch (Exception e) {
			reportFail("Unable to validate the valid email address " + e);
			throw new Exception();
		}
	}

	@When("I clicked on Credit transaction above alert")
	public void i_clicked_on_Credit_transaction_above_alert() throws Exception {
		try {
			manageAlertsPage.clicOnCreditTransactionAbove();
			reportPass("Clicked on Credit Transaction Above alert");
		} catch (Exception e) {
			reportFail("Unable to click on Credit Transaction Above alert " + e);
			throw new Exception();
		}
	}

	@When("I clicked on Debit transaction above alert")
	public void i_clicked_on_Debit_transaction_above_alert() throws Exception {
		try {
			manageAlertsPage.clicOnDebitTransactionAbove();
			reportPass("Clicked on Debit Transaction Above alert");
		} catch (Exception e) {
			reportFail("Unable to click on Debit Transaction Above alert " + e);
			throw new Exception();
		}
	}

	@Then("None of the non numeric characters {string} should be entered and amount should be blank")
	public void none_of_the_non_numeric_characters_should_be_entered_and_amount_should_be_blank(String value)
			throws Exception {
		try {
			manageAlertsPage.verifyAmountFieldEntered(value);
			reportPass("Verified the amount field values entered");
		} catch (Exception e) {
			reportFail("Unable to verify the values entered in amount field " + value + " " + e);
			throw new Exception();
		}
	}

	@Then("I verify the balance present for alert")
	public void i_verify_the_balance_present_for_alert() throws Exception {
		try {
			manageAlertsPage.verifyAmountBalancePresent();
			reportPass("Verified the amount field values entered");
		} catch (Exception e) {
			reportFail("Unable to verify the values entered in amount field " + e);
			throw new Exception();
		}
	}

	@Then("No changes occur for the balance alert")
	public void no_changes_occur_for_the_balance_alert() throws Exception {
		try {
			manageAlertsPage.verifyAmountBalanceNotChanged();
			reportPass("Verified the value entered is not present");
		} catch (Exception e) {
			reportFail("Unable to verify the value entered is not present " + e);
			throw new Exception();
		}
	}

	@When("I tap outside the alert box")
	public void i_tap_outside_the_alert_box() throws Exception {
		try {
			manageAlertsPage.tapOutsideAlert();
			reportPass("Tapped outside the alert box");
		} catch (Exception e) {
			reportFail("Unable to tapped outside the alert box " + e);
			throw new Exception();
		}
	}

	@Then("I verify the labels displayed on alerts screen")
	public void i_verify_the_labels_displayed_on_alerts_screen() throws Exception {
		try {
			manageAlertsPage.verifyMangaeAlertsScreen();
			reportPass("Verified the manage alerts screen options");
		} catch (Exception e) {
			reportFail("Unable to verify the value " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on Push icon in alerts page$")
	public void i_clicked_on_Push_icon_in_alerts_page() throws Exception {
		try {
			manageAlertsPage.clickOnPushIcon();
			reportPass("Clicked on Push Icon in alerts page");
		} catch (Exception e) {
			reportFail("Unable to click on Push Icon " + e);
			throw new Exception();
		}
	}

	@Then("I verify in Android {string} and {string} with enable\\/disable button")
	public void i_verify_in_Android_and_with_enable_disable_button(String message1, String message2) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				manageAlertsPage.verifyPushAlertsPageAndroid(message1, message2);
			}
		} catch (Exception e) {
			reportFail("Unable to verify the text present " + e);
			throw new Exception();
		}
	}

	@Then("I verify in iOS {string}, {string} and {string} with enable\\/disable button")
	public void i_verify_in_iOS_and_with_enable_disable_button(String message1, String message2, String message3)
			throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				manageAlertsPage.verifyPushAlertsPageIos(message1, message2, message3);
			}
		} catch (Exception e) {
			reportFail("Unable to verify the text present " + e);
			throw new Exception();
		}
	}

	@Then("I verify the email address cannot be updated")
	public void i_verify_the_email_address_cannot_be_updated() throws Exception {
		try {
			manageAlertsPage.verifyEmailAddressCanUpdate();
			reportPass("Verified valid email present");
		} catch (Exception e) {
			reportFail("Unable to validate the valid email address " + e);
			throw new Exception();
		}
	}

	@When("^I verify the content present in alerts page$")
	public void i_verify_the_content_present_in_alerts_page() throws Exception {
		try {
			manageAlertsPage.verifyContentEmailPage();
			reportPass("Verified the content present in email page");
		} catch (Exception e) {
			reportFail("Unable to verified the content present in email page " + e);
			throw new Exception();
		}
	}

	@Then("^I select the Low balance alert type$")
	public void i_select_the_low_balance_alert_type() throws Exception {
		try {
			manageAlertsPage.clickOnLowBalanceAlert();
			reportPass("Selected the low balance");
		} catch (Exception e) {
			reportFail("Unable to select the low balance " + e);
			throw new Exception();
		}
	}

	@Then("^I select the High balance alert type$")
	public void i_select_the_high_balance_alert_type() throws Exception {
		try {
			manageAlertsPage.clickOnHighBalanceAlert();
			reportPass("Selected the high balance");
		} catch (Exception e) {
			reportFail("Unable to select the high balance " + e);
			throw new Exception();
		}
	}

	@When("I enter {string} in amount text field")
	public void i_enter_in_amount_text_field(String value) throws Exception {
		try {
			manageAlertsPage.enterAmount(testDataMap.get(value));
			reportPass("Enter " + value + " in amount text field");
		} catch (Exception e) {
			reportFail("Unable to enter " + value + " in amount text field " + e);
			throw new Exception();
		}
	}

	@Then("I verify text field should not accept {string}")
	public void i_verify_text_field_should_not_accept(String value) throws Exception {
		try {
			manageAlertsPage.verifyValueNotEntered(testDataMap.get(value));
			reportPass("Provided " + value + " is not entered in text field");
		} catch (Exception e) {
			reportFail("Given " + value + " in amount text field is accepted and entered" + e);
			throw new Exception();
		}
	}

	@Then("I click on Email delivery channel")
	public void i_click_on_Email_delivery_channel() throws Exception {
		try {
			manageAlertsPage.clickOnEmailDeliveryChannel();
			reportPass("Clicked on Email delivery channel");
		} catch (Exception e) {
			reportFail("Unable to click on Email delivery channel " + e);
			throw new Exception();
		}
	}

	@Then("^View Accounts page is displayed in another device$")
	public void accounts_page_is_displayed_in_another_device() throws Exception {
		ViewAccountsPage viewAccountPageDriver = new ViewAccountsPage(RetailAppUtils.customAppiumDriver);
		try {
			viewAccountPageDriver.verifyViewAccountsPageTitle();
			reportPass("View Account Page is displayed");
		} catch (Exception e) {
			reportFail("View Accounts Page not displayed after login " + e);
			ConcurrentEngines.destroyCustomEngine();
			throw new Exception();
		}
	}

	@When("^I clicked on Settings icon in another device$")
	public void i_clicked_on_Settings_icon_in_another_device() throws Exception {
		ViewAccountsPage viewAccountPageDriver = new ViewAccountsPage(RetailAppUtils.customAppiumDriver);
		try {
			viewAccountPageDriver.clickSettingsIcon();
			reportPass("Clicked on Settings Icon");
		} catch (Exception e) {
			reportFail("Unable to click on settings icon " + e);
			throw new Exception();
		}
	}

	@Then("I {string} all three {string} alerts channel for balance more")
	public void i_all_three_alerts_channel_for_balance_more(String status, String alertType) {
		try {
			manageAlertsPage.enableAlertsChannelBalanceMore(status, alertType);
			reportPass("Enabling all three alert channels for balance more");
		} catch (Exception e) {
			reportHardFail("Enabling alert channel is failed for balance more", true);
		}
	}

	@When("I {string}, {string} alert channel")
	public void i_alert_channel(String value, String alertType) {
		try {
			if (alertType.equalsIgnoreCase("Mobile") || alertType.equalsIgnoreCase("SMS")) {
				manageAlertsPage.mobileAlertChannelStatusBalanceMore(value, alertType);
			} else if (alertType.equalsIgnoreCase("Email")) {
				manageAlertsPage.emailAlertChannelStatusBalanceMore(value, alertType);
			} else if (alertType.equalsIgnoreCase("Push")) {
				manageAlertsPage.pushAlertChannelStatusBalanceMore(value, alertType);
			}
			reportPass(alertType + " alert channel for balance more is " + value + " selected");
		} catch (Exception e) {
			reportHardFail("Enabling/Disabling " + alertType + " alert channel is failed for balance more", true);
		}
	}

	@When("I clear test Phone Number")
	public void i_clear_test_Phone_Number() throws Exception {
		try {
			manageAlertsPage.clearPhoneNumber();
			reportPass("Cleared phone number");
		} catch (Exception e) {
			reportFail("Cleared phone number " + e);
			throw new Exception();
		}
	}

	@Then("I verify text alert icon will not be displayed")
	public void i_verify_text_alert_icon_will_not_be_displayed() throws Exception {
		try {
			manageAlertsPage.verifyTextAlertChannelNotPresent();
			reportPass("Text alert channel icon is not displayed");
		} catch (Exception e) {
			reportFail("Text alert channel icon is displayed " + e);
			throw new Exception();
		}
	}

	@Then("I disabled all three alerts channel for balance more")
	public void i_disabled_all_three_alerts_channel_for_balance_more() throws Exception {
		try {
			manageAlertsPage.disableAlertsChannelBalanceMore();
			reportPass("Disabled all three alert channels for balance more");
		} catch (Exception e) {
			reportFail("Disabling alert channel is failed for balance more" + e);
			throw new Exception();
		}
	}

	@Then("I disabled all three alerts channel for balance less")
	public void i_disabled_all_three_alerts_channel_for_balance_less() throws Exception {
		try {
			manageAlertsPage.disableAlertsChannelBalanceLess();
			reportPass("Disabled all three alert channels for balance less");
		} catch (Exception e) {
			reportFail("Disabling alert channel is failed for balance less" + e);
			throw new Exception();
		}
	}

	@Then("I enabled all three alerts channel for balance less")
	public void i_enabled_all_three_alerts_channel_for_balance_less() throws Exception {
		try {
			manageAlertsPage.enableAlertsChannelBalanceLess();
			reportPass("Enabling all three alert channels for balance less");
		} catch (Exception e) {
			reportFail("Enabling alert channel is failed fior balance less" + e);
			throw new Exception();
		}
	}

	@When("^I clicked on balance more threshold alert type$")
	public void i_clicked_on_balance_more_threshold_alert_type() throws Exception {
		try {
			manageAlertsPage.clickOnBalanceMoreThresholdAmount();
			reportPass("Clicked on Balance more Threshold amount option");
		} catch (Exception e) {
			reportFail("Unable to click on Balance more Threshold amount option " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on balance less threshold alert type$")
	public void i_clicked_on_balance_less_threshold_alert_type() throws Exception {
		try {
			manageAlertsPage.clickOnBalanceLessThresholdAmount();
			reportPass("Clicked on Balance less Threshold amount option");
		} catch (Exception e) {
			reportFail("Unable to click on Balance less Threshold amount option " + e);
			throw new Exception();
		}
	}

	@When("^I verify Manage Alerts screen is displayed$")
	public void i_verify_manage_alerts_screen_is_displayed() throws Exception {
		try {
			manageAlertsPage.verifyManageAlertsPage();
			reportPass("Manage Alerts screen is verified");
		} catch (Exception e) {
			reportFail("Unable to verify Manage Alerts screen " + e);
			throw new Exception();
		}
	}

	@Then("I verify all the accounts should display in order like {string}")
	public void i_verify_all_the_accounts_should_display_in_order_like(String accountsOrder) throws Exception {
		try {
			viewAccountsPage.verifyAccountsOrder(accountsOrder);
			reportPass("Verified the accounts are displayed in order as " + accountsOrder);
		} catch (Exception e) {
			reportFail("Unable to verify the accounts displayed in order " + e);
			throw new Exception();
		}
	}

	@When("I {string}, {string} alert channel for Credit transaction above alert")
	public void i_alert_channel_for_Credit_transaction_above_alert(String value, String alertType) {
		try {
			if (alertType.equalsIgnoreCase("Mobile") || alertType.equalsIgnoreCase("SMS")) {
				manageAlertsPage.mobileAlertChannelStatusCreditAbove(value, alertType);
			} else if (alertType.equalsIgnoreCase("Email")) {
				manageAlertsPage.emailAlertChannelStatusCreditAbove(value, alertType);
			} else if (alertType.equalsIgnoreCase("Push")) {
				manageAlertsPage.pushAlertChannelStatusCreditAbove(value, alertType);
			}
			reportPass(alertType + " alert channel for Credit transaction above is " + value + " selected");
		} catch (Exception e) {
			reportHardFail("Enabling/Disabling " + alertType + " alert channel is failed for Credit transaction above",
					true);
		}
	}

	@When("I {string}, {string} alert channel for Debit transaction above alert")
	public void i_alert_channel_for_Debit_transaction_above_alert(String value, String alertType) {
		try {
			if (alertType.equalsIgnoreCase("Mobile") || alertType.equalsIgnoreCase("SMS")) {
				manageAlertsPage.mobileAlertChannelStatusDebitAbove(value, alertType);
			} else if (alertType.equalsIgnoreCase("Email")) {
				manageAlertsPage.emailAlertChannelStatusDebitAbove(value, alertType);
			} else if (alertType.equalsIgnoreCase("Push")) {
				manageAlertsPage.pushAlertChannelStatusDebitAbove(value, alertType);
			}
			reportPass(alertType + " alert channel for Debit transaction above is " + value + " selected");
		} catch (Exception e) {
			reportHardFail("Enabling/Disabling " + alertType + " alert channel is failed for Debit transaction above",
					true);
		}
	}

	@When("^I clear notifications if any$")
	public void I_clear_notifications_if_any() {
		try {
			commonPage.clearNotifications();
			reportPass("Cleared notifications");
		} catch (Exception e) {
			reportHardFail("Unable to clear notifications " + e);
		}
	}

	@When("^I verify the push notification received$")
	public void I_verify_the_push_notification_received() throws Exception {
		try {
			commonPage.openNotifications();
			reportPass("Opened notifications");
		} catch (Exception e) {
			reportHardFail("Unable to Open notifications ", true);
		}
	}
}
