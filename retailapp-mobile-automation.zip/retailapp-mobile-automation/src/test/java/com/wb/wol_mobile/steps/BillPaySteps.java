package com.wb.wol_mobile.steps;

import java.util.List;

import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.AddBillPayeePage;
import com.wb.wol_mobile.pages.BillPayPage;
import com.wb.wol_mobile.pages.TransfersPage;
import com.wb.wol_mobile.pages.ViewAccountsPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BillPaySteps extends ObjectBase {

	BillPayPage billPayPage = new BillPayPage();
	TransfersPage transfersPage = new TransfersPage();
	AddBillPayeePage addBillPayeePage = new AddBillPayeePage();
	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();

	@When("^I see PAY A BILL button$")
	public void i_see_PAY_A_BILL_button() throws Exception {
		try {
			billPayPage.verifyTextPayABills();
			viewAccountsPage.acceptInEligibleAccountPopup();
			reportPass("can see pay A Bill button");
		} catch (Exception e) {
			reportHardFail("can't see pay A Bill button after paybills " + e);
		}
	}

	@Then("I Click on Ok Button")
	public void i_Click_on_Ok_Button() throws Exception {
		try {
			billPayPage.clickOkButton();
			reportPass("user able to click on ok button", false);
		} catch (Exception e) {
			reportHardFail("user unable to click on ok button " + e);
		}

	}

	@Then("^I click PAY A BILL button$")
	public void i_click_PAY_A_BILL_button() throws Exception {
		try {
			billPayPage.clickTextPayABills();
			reportPass("Clicked on pay A Bill button");

		} catch (Exception e) {
			reportHardFail("can't able to click on pay A Bill button " + e);
		}
	}

	@Then("^I click more option from the list$")
	public void i_enter_more_option_from_the_list() throws Exception {
		try {

			billPayPage.clickMoreOptions();
			reportPass("Clicked on first moreoption from the list");
		} catch (Exception e) {
			reportHardFail("can't able to click on moreoption from the list " + e);
		}
	}

	@When("^I see Cancel Payment$")
	public void i_see_Cancel_Payment() throws Exception {
		try {

			billPayPage.verifyCancelPaymentButton();
			reportPass("can see cancelPaymentButton");
		} catch (Exception e) {
			reportHardFail("can't able to see cancelPaymentButton " + e);
		}
	}

	@Then("^I see Payment Canceled Successfully$")
	public void i_see_Payment_Canceled_Successfully() throws Exception {
		try {
			billPayPage.verifyTextPaymentCanceled();
			reportPass("can see Payment Canceled Successfully text");
		} catch (Exception e) {
			reportHardFail("can't able to see Payment Canceled Successfully text " + e);
		}
	}

	@Then("^I click Cancel Payment and click Confirm button$")
	public void i_click_Cancel_Payment_and_clcik_Confirm_button() throws Exception {
		try {
			billPayPage.clickCancelPaymentButton();
			billPayPage.clickConfirmButton();
			reportPass("Clicked on cancelpayment and confirm button");
		} catch (Exception e) {
			reportHardFail("can't able to click on cancelpayment and confirm button " + e);
		}
	}

	@Then("^I see hamburger icon and I click hamburger icon$")
	public void i_see_hamburger_and_click_icon() {
		try {
			// billPayPage.verifyHamburgerButton();
			billPayPage.clickHamburgerButton();
			reportPass("Can see hamburgerMenu icon and Clicked on the hamburgerMenu");
		} catch (Exception e) {
			reportHardFail("can't able to see and click on hamburgerMenu button ", true);
		}
	}

	@Then("^I click Pay Bills$")
	public void i_click_on_pay_bills() throws Exception {
		try {
			billPayPage.clickTextPayBills();
			reportPass("Clicked on Pay Bills");
		} catch (Exception e) {
			reportHardFail("can't able to click on Pay Bills text" + e);
		}
	}


	@Then("^I click Pay Bill$")
	public void i_click_on_pay_bill() throws Exception {
		try {
			billPayPage.clickPayBillButton();
			reportPass("Clicked on Pay Bill");

		} catch (Exception e) {
			reportHardFail("can't able to click on Pay Bill button " + e);
		}
	}

	@Then("^I click OK button$")
	public void i_click_OK_button() throws Exception {
		try {
			billPayPage.clickOkButton();
			reportPass("Clicked on OK button");

		} catch (Exception e) {
			reportHardFail("can't able to click on OK button " + e);
			throw new Exception();
		}
	}

	@Then("^I see Create a Payment$")
	public void i_see_Create_a_Payment() throws Exception {
		try {
			billPayPage.verifyTextCreatePayment();
			reportPass("can see Create a Payment");
		} catch (Exception e) {
			reportHardFail("can't able to see Create a Payment text " + e);
			throw new Exception();
		}
	}

	@Then("^I see error message \"([^\"]*)\"$")
	public void i_see_error_message(String arg1) throws Exception {
		try {
			billPayPage.verifyTextBillPayNotSetup(testDataMap.get(arg1));
			reportPass("Can see Error Message as expected");
		} catch (Exception e) {
			reportHardFail("can't able to see Error Message or Message not matched " + e);
		}
	}

	@Then("^I enter Payee and Amount \"([^\"]*)\"$")
	public void i_enter_Payee_and_Amount_200(String amount) throws Exception {
		try {
			reportInfo("In payment centre screen");
			billPayPage.clickTextPayee();
			billPayPage.clickTextSelectPayee();
			billPayPage.enterAmount(amount);
			reportPass("Successfully entered the payee, amount");
		} catch (Exception e) {
			reportHardFail("unable to enter payeeno, amount " + e);
		}
	}

	@Then("I enter PayFrom and Amount {string}")
	public void i_enter_PayFrom_and_Amount(String amount) throws Exception {
		try {
			billPayPage.clickTextPayFrom();
			billPayPage.enterAmount(amount);
			reportPass("Successfully entered the PayFrom, amount ");
		} catch (Exception e) {
			reportHardFail("unable to enter PayFrom, amount " + e);
			throw new Exception();
		}
	}

	@Then("^I give Delivery Date and Delivery option$")
	public void i_give_Delivery_Date_and_Delivery_option() throws Exception {
		try {
			billPayPage.clickDeliveryOptionButton();
			billPayPage.verifyStandardButton();
			billPayPage.clickStandardButton();
			reportPass("Successfully clicked on DeliveryOption and Standard button");
		} catch (Exception e) {
			reportHardFail("unable to clicked on DeliveryOption and Standard button" + e);
		}
	}

	@When("^I click on submit button$")
	public void i_click_on_submit_button() throws Exception {
		try {
			billPayPage.clickSubmitButton();
			reportPass("Successfully clicked on Submit button");
		} catch (Exception e) {
			reportHardFail("unable to click on Submit button " + e);
		}
	}

	@Then("I select the future date for transfer {int}")
	public void i_select_the_future_date_for_transfer(Integer date) throws Exception {
		try {
			billPayPage.selectFutureDate(date);
			reportPass("Selected the future date");
		} catch (Exception e) {
			reportHardFail("Unable to select the future date " + e);
		}
	}

	@Then("^I should see error message \"([^\"]*)\"$")
	public void i_should_see_error_message(String value) throws Exception {
		if (billPayPage.verifyChooseFromAccount(testDataMap.get(value)))
			reportPass("Choose From Account message is displayed");
		else
			reportHardFail("Not displayed Choose From Account error message ");
	}

	@Then("^I should see To error message \"([^\"]*)\"$")
	public void i_should_see_to_error_message(String value) throws Exception {
		try {
			billPayPage.verifyChooseToAccount(value);
			reportPass("Choose To Account message is displayed");
		} catch (Exception e) {
			reportHardFail("Not displayed Choose To Account error message " + e);
		}
	}

	@Then("^I should see payee error message \"([^\"]*)\"$")
	public void i_should_see_payee_error_message(String value) throws Exception {
			if (billPayPage.verifyChoosePayee(testDataMap.get(value)))
			reportPass("Choose Payee message is displayed");
			else
			reportHardFail("Not displayed Choose Payee error message ");
		}

	@When("I click on Calendar")
	public void i_click_on_Calendar() throws Exception {
		try {
			billPayPage.clickOnCalender();
			reportPass("Verified Calendar is opened by tapping");
		} catch (Exception e) {
			reportHardFail("Unable to verify that calendar is opened " + e);
		}
	}

	@Then("^I verify payment details screen$")
	public void i_verify_payment_details_Screen() throws Exception {
		try {
			billPayPage.verifyPaymentDetailsScreen();
			reportPass("Successfully verified Payment Details Screen");
		} catch (Exception e) {
			reportHardFail("can't able to verify Payment Details screen " + e);
		}
	}

	@Then("^I verify temporarily unavailable screen$")
	public void i_verify_temporarily_unavailable_Screen() throws Exception {
		try {
			billPayPage.verifyTemporaryUnavailableScreen();
			reportPass("Successfully verified Temporarily Unavailable Screen");
		} catch (Exception e) {
			reportHardFail("can't able to verify Temporarily Unavailable screen " + e);
		}
	}

	@Then("^I verify No payments screen$")
	public void i_verify_No_payments_Screen() throws Exception {
		if (billPayPage.verifyNoPaymentsScreen()) {
			reportPass("Successfully verified No Payments Screen");
		} else {
			reportHardFail("can't able to verify No Payments screen ");
		}
	}

	@Then("I verify pay bill history balances")
	public void i_veirfy_pay_bill_history_balances() throws Exception {
		try {
			billPayPage.verifyPayBillHistoryBalances();
			reportPass("Verified Paybill history balances ");
		} catch (Exception e) {
			reportHardFail("Unable to verify Paybill history balances " + e);
		}
	}

	@Then("^I should see payment cancel confirm message \"([^\"]*)\"$")
	public void payment_cancel_confirm_message_displayed(String confirmMessage) throws Exception {
		try {
			billPayPage.verifyPaymentCancelConfirmMessage(testDataMap.get(confirmMessage));
			reportPass(" message displayed in payment cancel confirm " + confirmMessage);
		} catch (Exception e) {
			reportHardFail("cancel confirm message is not displayed " + e);
		}
	}

	@Then("^I click on CLOSE button$")
	public void i_click_on_close_button() throws Exception {
		try {
			billPayPage.clickCloseButton();
			reportPass("Successfully clicked on CLOSE");
		} catch (Exception e) {
			reportHardFail("Can't click on CLOSE " + e);
		}
	}

	@Then("^I should see Payment cancelled message \"([^\"]*)\"$")
	public void i_should_see_Payment_cancelled_message(String cancelMessage) throws Exception {
		try {
			billPayPage.verifyPaymentCancelMessage(testDataMap.get(cancelMessage));
			reportPass("Snackbar or Popup message displayed " + cancelMessage);
		} catch (Exception e) {
			reportHardFail("Snackbar or PopUp message is not displayed " + e);
		}
	}

	@Then("^I Verify pending payment removed error message \"([^\"]*)\"$")
	public void i_verify_pending_Payment_removed_error_message(String cancelMessage) throws Exception {
		try {
			billPayPage.verifyPaymentCancelMessage(testDataMap.get(cancelMessage));
			reportPass("Snackbar or Popup message displayed " + cancelMessage);
		} catch (Exception e) {
			reportHardFail("Snackbar or PopUp message is not displayed " + e);
		}
	}

	@Then("I Need to verify No Payments Error Message for ios is {string} and for android is {string}")
	public void i_Need_to_verify_No_Payments_Error_Message_for_ios_is_and_for_android_is(String iosError,
			String androidError) throws Exception {
		try {
			billPayPage.verifyNoPaymentsMessage(testDataMap.get(iosError), testDataMap.get(androidError));
			reportPass("NoErrorPayments Popup message displayed as No results or No items available");
		} catch (Exception e) {
			reportHardFail("NoErrorPayments PopUp message is not displayed " + e);
		}
	}

	@Then("I Need to verify view-only message as {string}")
	public void i_Need_to_verify_view_only_message_as(String message) {
		try {
			billPayPage.verifyUnableToProcessMessage(testDataMap.get(message));
			reportPass("NoErrorPayments Popup message displayed as No results or No items available");
		} catch (Exception e) {
			reportHardFail("NoErrorPayments PopUp message is not displayed " + e);
		}

	}

	@Then("I Tap the Pay field and select account {int} from the list")
	public void i_Tap_the_Pay_field_and_select_account_from_the_list(Integer value) throws Exception {
		try {
			billPayPage.clickTextPayFrom();
			billPayPage.selectFromAccount(value);
			reportPass("User is able to select pay from and select the account successfully");
		} catch (Exception e) {
			reportHardFail("User is Unable to select pay from and select the account successfully" + e);
		}
	}

	@Then("I Tap the Payee field and select account {int} from the list")
	public void i_Tap_the_Payee_field_and_select_account_from_the_list(Integer value) throws Exception {
		try {
			billPayPage.clickTextPayee();
			billPayPage.selectToPayee(value);
			reportPass("Successfully selected the payee");
		} catch (Exception e) {
			reportHardFail("unable to select payee from the list " + e);
		}
	}

	@When("I Tap the Amount Field and clear Enter the Amount as {string}")
	public void i_Tap_the_Amount_Field_and_Enter_the_Amount_as(String amount) throws Exception {
		try {
			billPayPage.enterAmount(amount);
			reportPass("Successfully entered amount in the field");
		} catch (Exception e) {
			reportHardFail("unable to enter amount in the field " + e);
		}
	}

	@When("I Tap the Amount Field and Enter the Amount as {string}")
	public void i_Tap_the_Amount_Field_and_clear_Enter_the_Amount_as(String amount) throws Exception {
		try {
			billPayPage.enterAmount(testDataMap.get(amount));
			reportPass("Successfully entered amount in the field");
		} catch (Exception e) {
			reportHardFail("unable to enter amount in the field " + e);
		}
	}

	@Then("I select the future date for billpay {int}")
	public void i_select_the_future_date_for_billpay(Integer date) throws Exception {
		try {
			billPayPage.selectFutureDate(date);
			reportPass("user selected the future date after  " + date + " days");
		} catch (Exception e) {
			reportHardFail("Unable to select the future date " + e);
		}
	}

	@Then("I Verify Error message as {string}")
	public void i_Verify_Error_message_as(String message) throws Exception {
		try {
			billPayPage.maximumPaymentErrorMessage(testDataMap.get(message));
			reportPass("maximum payment error message displayed ");
		} catch (Exception e) {
			reportHardFail("maximum payment error message not displayed " + e);
		}
	}

	@Then("I Need to verify paymentConfirmation messsage {string}")
	public void i_Need_to_verify_paymentConfirmation_messsage(String message) throws Exception {
		try {
			billPayPage.paymentConfirmationMessage(testDataMap.get(message));
			reportPass("maximum payment error message displayed ");
		} catch (Exception e) {
			reportHardFail("maximum payment error message not displayed " + e);
		}

	}

	@Then("I Verify payment Date error message {string}")
	public void i_Verify_payment_Date_error_messsage(String message) throws Exception {
		try {
			billPayPage.verifyPaymentThreeBusinessErrorMessage(testDataMap.get(message));
			reportPass("Snackbar or Popup message displayed " + message);
		} catch (Exception e) {
			reportHardFail("Snackbar or PopUp message not displayed " + e);
		}

	}

	@Then("^Pay Bills page is displayed$")
	public void pay_bills_page_is_displayed() throws Exception {
		try {
			billPayPage.verifyPayBillsPageTitle();
			reportPass("Bill Pay Page is displayed");
		} catch (Exception e) {
			reportHardFail("Bill Pay Page not displayed after login " + e);
		}
	}

	@When("I click on Payee field to select payee")
	public void i_click_on_Payee_field_to_select_payee() throws Exception {
		try {
			billPayPage.clickTextPayFrom();
			billPayPage.clickTextPayee();
			reportPass("User is able to select pay from and select the account successfully");
		} catch (Exception e) {
			reportHardFail("User is Unable to select pay from and select the account successfully" + e);
		}
	}

	@Then("I verify Payees are displayed in alphabetical order in drop down list")
	public void i_verify_Payees_are_displayed_in_alphabetical_order_in_drop_down_list() throws Exception {
		try {
			List<String> payeeNames = billPayPage.getDropdownPayees();
			billPayPage.verifyPayeesInAlphabeticalOrder(payeeNames);
			reportPass("All payess are displayed in alphabetical order");
		} catch (Exception e) {
			reportHardFail(" payess are not displayed in alphabetical order" + e);
		}
	}

}
