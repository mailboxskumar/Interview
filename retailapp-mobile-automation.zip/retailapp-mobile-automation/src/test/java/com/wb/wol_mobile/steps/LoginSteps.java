package com.wb.wol_mobile.steps;

import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.LoginPage;
import com.wb.wol_mobile.pages.SettingsPage;
import com.wb.wol_mobile.testbases.RetailAppTestBase;
import com.wb.wol_mobile.utilities.TestDataConstants;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps extends ObjectBase {

	LoginPage login = new LoginPage();
	SettingsPage settingsPage = new SettingsPage();

	@Given("^I am in Webster Mobile login page$")
	public void i_am_in_Webster_online_login_page() throws Exception {
		try {
			login.verifyWebsterMobileLoginPage();
			reportPass("Webster Retail Mobile Bank App is launched in " + TestDataConstants.getOSPlatformName() + "..");
		} catch (Exception e) {
			reportFail("WebsterBank Mobile App not launched " + e);
			throw new Exception();
		}
	}

	@Then("^I see username and password textbox$")
	public void i_see_username_and_password_textbox() throws Exception {
		try {
			login.verifyUserNameTextField();
			login.verifyPasswordTextField();
			reportPass("Webster bank app Username and Password are displayed");
		} catch (Exception e) {
			reportFail("Username/Password fields did not verified" + e);
			throw new Exception();
		}
	}

	@Then("^I see login button$")
	public void i_see_login_button() throws Exception {
		try {
			login.verifyLogInButton();
			reportPass("LogIn button displayed");
		} catch (Exception e) {
			reportFail("Login button did not verified " + e);
			throw new Exception();
		}
	}

	@When("^I enter username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void i_enter_username_and_password(String userName, String password) throws Exception {
		String pwd = "";
		String user = "";

		if (userName == null || userName.isEmpty())
			user = "";
		else
			user = RetailAppTestBase.envProps.getProperty(userName);

		if (password == null || password.isEmpty())
			pwd = "";
		else
			pwd = RetailAppTestBase.envProps.getProperty(password);
		try {
			login.enterUserName(user);
			login.enterPassword(pwd);
			reportPass("Username " + user + " and Password entered into text field");
		} catch (Exception e) {
			reportFail("Issue while entering the Username/Password " + e);
			throw new Exception();
		}
	}

	@And("^I clicked on login button$")
	public void i_clicked_on_login_button() throws Exception {
		try {
			login.clickLogin();
			reportPass("clicked on login button successfully");
		} catch (Exception e) {
			reportFail("Unable to clicked on login button " + e);
			throw new Exception();
		}
	}

	@Then("I Need to verify Mobile Terms and Conditions")
	public void i_Need_to_verify_Mobile_Terms_and_Conditions() throws Exception {
		if (login.verifyTermsAndCondtions()) {
			reportPass("Successfully verified terms and condtions");
		} else {
			reportFail("Unable to verify terms and conditions");
		}
	}

	@And("^I clicked on login button to verify error$")
	public void i_clicked_on_login_button_to_verify_error() throws Exception {
		try {
			login.clickLoginOnly();
			reportPass("Application successfully logged in");
		} catch (Exception e) {
			reportFail("App did not logged in " + e);
			throw new Exception();
		}
	}

	@When("I verify the Save Username option is not enabled")
	public void i_verify_the_Save_Username_option_is_not_enabled() throws Exception {
		try {
			login.verifySaveUserNameOptionDisabled();
			reportPass("Verified save username option is disabled");
		} catch (Exception e) {
			reportFail("Unable to veirfy the save username option is enabled or not " + e);
			throw new Exception();
		}
	}

	@Then("I click on Save Username option")
	public void i_click_on_Save_Username_option() throws Exception {
		try {
			login.clickOnSaveUserNameOption();
			reportPass("Clicked on save username option");
		} catch (Exception e) {
			reportFail("Unable to click on save username option " + e);
			throw new Exception();
		}
	}

	@Then("I verify the username field is prefilled with Username and display first {int} characters and remaining should be masked")
	public void i_verify_the_username_field_is_prefilled_with_Username_and_display_first_characters_and_remaining_should_be_masked(
			Integer firstFourCharacters) throws Exception {
		try {
			login.verifyUserNameFieldPreFilled(firstFourCharacters);
			reportPass("Username field is prefilled with first 4 characters of username and rest are masked");
		} catch (Exception e) {
			reportFail(
					"Unable to verify Username field is prefilled with first 4 characters of username and rest are masked "
							+ e);
			throw new Exception();
		}
	}

	@Then("I clicked on Logout")
	public void i_clicked_on_Logout() throws Exception {
		try {
			settingsPage.clickOnLogout();
			reportPass("Clicked on logout button");
		} catch (Exception e) {
			reportFail("Unable to click on logout button " + e);
			throw new Exception();
		}
	}

	@Then("I verify the error message {string}")
	public void i_verify_the_error_message(String errorMessage) throws Exception {
		String errMsg = jsonDataParser.getTestDataMap().get(errorMessage);
		try {
			login.verifyErrorMessage(errMsg);
			reportPass("Verified the error message " + errMsg);
		} catch (Exception e) {
			reportFail("Unable to verify the error message " + e);
			throw new Exception("Unable to verify the error message " + e);
		}
	}
	
	@And("^I click on login$")
	public void i_click_on_login() throws Exception {
		try {
			login.clickLoginOnly();
			reportPass("Clicked on login button");
		} catch (Exception e) {
			reportFail("Unable to click on login button" + e);
			throw new Exception();
		}
	}
	
	@Then("Save Username option is enabled")
	public void save_Username_option_is_enabled() {
		try {
			login.verifySaveUserNameOptEnabled();
			reportPass("Save username option is enabled");
		} catch (Exception e) {
			reportHardFail("Unable to verify Save username option is enabled", true);
		}
	}
	
	@Then("I verify the error message for question {string}")
	public void i_verify_the_error_message_for_question (String errorMessage) throws Exception {
		try {
			login.verifyQuestionErrorMessage(errorMessage);
			reportPass("Verified the error message " + errorMessage);
		} catch (Exception e) {
			reportHardFail("Unable to verify the error message " + e);
		}
	}
}