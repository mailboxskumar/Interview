package com.wb.wol_mobile.steps;

import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.NewAccountOpeningPage;
import com.wb.wol_mobile.utilities.TestDataConstants;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class NewAccountOpeningSteps extends ObjectBase {

	NewAccountOpeningPage newAccountOpeningPage = new NewAccountOpeningPage();

	@When("I verify NAO icon is present on Home Page")
	public void i_verify_NAO_icon_is_present_on_Home_Page() {
		try {
			newAccountOpeningPage.verifyNAOIconPresent();
			reportPass("NAO icon is present on home page");
		} catch (Exception e) {
			reportHardFail("Unable to verify the NAO icon is on Home page", true);
		}
	}

	@When("I verify NAO icon is present on Menu Option")
	public void i_verify_NAO_icon_is_present_on_Menu_Option() {
		try {
			newAccountOpeningPage.verifyNAOIconPresent();
			reportPass("NAO icon is present on menu option");
		} catch (Exception e) {
			reportHardFail("Unable to verify the NAO icon is on menu option", true);
		}
	}

	@When("I tap on NAO icon")
	public void i_tap_on_NAO_icon() {
		try {
			newAccountOpeningPage.tapOnNAO();
			reportPass("Clicked on NAO icon");
		} catch (Exception e) {
			reportHardFail("Unable to click on NAO icon", true);
		}
	}

	@Then("I Verify Email Address is displayed")
	public void i_Verify_Email_Address_is_displayed() {
		try {
			newAccountOpeningPage.verifyEmailAddressDisplayed();
			reportPass("Email Address is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to verify Email Address is displayed", true);
		}
	}

	@Then("I Verify Promo Code text is displayed as Promo Code Optional")
	public void i_Verify_Promo_Code_text_is_displayed_as_Promo_Code_Optional() {
		try {
			newAccountOpeningPage.verifyPromoCodeDisplayed();
			reportPass("Promo Code (Optional) is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to verify Promo Code (Optional) is displayed", true);
		}
	}

	@Then("I verify NAO page should displayed with account types")
	public void i_verify_NAO_page_should_displayed_with_account_types() {
		try {
			newAccountOpeningPage.verifyNAOPageDisplayed();
			reportPass("Verified the NAO page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to verify the NAO page is displayed", true);
		}
	}

	@Then("I verify NAO page should displayed with account types from Menu Option")
	public void i_verify_NAO_page_should_displayed_with_account_types_from_Menu_Option() {
		try {
			newAccountOpeningPage.verifyNAOPageDisplayedMenu();
			reportPass("Verified the NAO page is displayed from menu option");
		} catch (Exception e) {
			reportHardFail("Unable to verify the NAO page is displayed from menu option", true);
		}
	}

	@When("I tap on NAO icon, NAO page should displayed with account types")
	public void i_tap_on_NAO_icon_NAO_page_should_displayed_with_account_types() {
		try {
			newAccountOpeningPage.tapOnNAO();
			newAccountOpeningPage.verifyNAOPageDisplayed();
			reportPass("Verified the NAO page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to verify the NAO page is displayed", true);
		}
	}

	@When("I tap on Savings Accounts")
	public void i_tap_on_Savings_Accounts() {
		try {
			newAccountOpeningPage.tapOnSavingsAccounts();
			reportPass("Clicked on Savings Accounts button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Savings Accounts button", true);
		}
	}

	@When("I tap on CDs")
	public void i_tap_on_CDs() {
		try {
			newAccountOpeningPage.tapOnCD();
			reportPass("Clicked on CDs button");
		} catch (Exception e) {
			reportHardFail("Unable to click on CDs button", true);
		}
	}

	@Then("I click on Back button in NAO")
	public void i_click_on_Back_button_in_NAO() {
		try {
			newAccountOpeningPage.tapOnBackButton();
			reportPass("Successfully Clicked on Back button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Back button", true);
		}
	}

	@Then("I verify Before you continue read and agree message")
	public void I_verify_Before_you_continue_read_and_agree_message() {
		try {
			newAccountOpeningPage.verifyReadAndAgreeMessage();
			reportPass("Read and agree message is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view read and agree message", true);
		}
	}

	@When("I select any of the Saving account and click Apply Now button")
	public void i_select_any_of_the_Saving_account_and_click_Apply_Now_button() {
		try {
			newAccountOpeningPage.tapOnAnySavingsAccounts();
			reportPass("Selected any one of the account from Savings Accounts");
		} catch (Exception e) {
			reportHardFail("Unable to select any one of the account from Savings Accounts", true);
		}
	}

	@When("I tap on Checkings Accounts")
	public void i_tap_on_Checkings_Accounts() {
		try {
			newAccountOpeningPage.tapOnCheckingsAccounts();
			reportPass("Clicked on Checkings Accounts button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Checkings Accounts button", true);
		}
	}

	@When("I tap on open a account for Premier Checking")
	public void i_tap_on_open_a_account_for_Premier_Checking() {
		try {
			newAccountOpeningPage.tapOnOpenPremierChecking();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for Premier Checking");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for Premier Checking", true);
		}
	}

	@When("I tap on open a account for WebsterOne Relationship Checking")
	public void i_tap_on_open_a_account_for_WebsterOne_Relationship_Checking() {
		try {
			newAccountOpeningPage.tapOnOpenWebsterOneRelationshipChecking();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for WebsterOne Relationship Checking");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for WebsterOne Relationship Checking", true);
		}
	}

	@When("I tap on open a account for Webster Value Checking")
	public void i_tap_on_open_a_account_for_Webster_Value_Checking() {
		try {
			newAccountOpeningPage.tapOnWebsterValueChecking();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for Webster Value Checking");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for Webster Value Checking", true);
		}
	}

	@When("I tap on open a account for Webster Student Checking")
	public void i_tap_on_open_a_account_for_Webster_Student_Checking() {
		try {
			newAccountOpeningPage.tapOnWebsterStudentChecking();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for Webster Student Checking");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for Webster Student Checking", true);
		}
	}

	@When("I tap on open a account for WebsterOne Savings")
	public void i_tap_on_open_a_account_for_WebsterOne_Savings() {
		try {
			newAccountOpeningPage.tapOnWebsterOneSavings();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for WebsterOne Savings");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for WebsterOne Savings", true);
		}
	}

	@When("I tap on open a account for Premium Money Market Savings")
	public void i_tap_on_open_a_account_for_Premium_Money_Market_Savings() {
		try {
			newAccountOpeningPage.tapOnPremiumMoneyMarketSavings();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for Premium Money Market Savings");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for Premium Money Market Savings", true);
		}
	}

	@When("I tap on open a account for Webster Value Savings")
	public void i_tap_on_open_a_account_for_Webster_Value_Savings() {
		try {
			newAccountOpeningPage.tapOnWebsterValueSavings();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for Webster Value Savings");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for Webster Value Savings", true);
		}
	}

	@When("I tap on open a account for Holiday Club Savings")
	public void i_tap_on_open_a_account_for_Holiday_Club_Savings() {
		try {
			newAccountOpeningPage.tapOnHolidayClubSavings();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for Holiday Club Savings");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for Holiday Club Savings", true);
		}
	}

	@When("I tap on open a account for Traditional CD")
	public void i_tap_on_open_a_account_for_Traditional_CD() {
		try {
			newAccountOpeningPage.tapOnTraditionalCD();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for Traditional CD");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for Traditional CD", true);
		}
	}

	@When("I tap on open a account for {int}-year bump up CD account")
	public void i_tap_on_open_a_account_for_year_bump_up_CD_account(Integer year) {
		try {
			newAccountOpeningPage.tapOnYearBumpUpCD();
			newAccountOpeningPage.tapOnOpenAnAccount();
			reportPass("Clicked on open account button for " + year + " year bump up CD");
		} catch (Exception e) {
			reportHardFail("Unable to click on open account button for " + year + " year bump up CD", true);
		}
	}

	@Then("I verify page displayed as {string}")
	public void i_verify_page_displayed_as(String title) {
		try {
			newAccountOpeningPage.verifyOpenAccountPage(jsonDataParser.getTestDataMap().get(title));
			reportPass(title + " NAO page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view " + title + " NAO page due to " + e, true);
		}
	}

	@Then("I click on Existing Customer Link")
	public void i_click_on_Existing_Customer_Link() {
		try {
			newAccountOpeningPage.clickOnExistingCustomer();
			reportPass("Clicked on Existing Customer link");
		} catch (Exception e) {
			reportHardFail("Unable to click on Existing Customer link", true);
		}
	}

	@Then("I Enter UserName as {string}")
	public void i_Enter_UserName_as(String userName) {
		try {
			newAccountOpeningPage.enterUserName(jsonDataParser.getTestDataMap().get(userName));
			reportPass("UserName entered as " + userName);
		} catch (Exception e) {
			reportHardFail("Unable to enter valid UserName", true);
		}
	}

	@Then("I Enter Password as {string}")
	public void I_Enter_Password_as(String password) {
		try {
			newAccountOpeningPage.enterPassword(jsonDataParser.getTestDataMap().get(password));
			reportPass("Password entered as " + password);
		} catch (Exception e) {
			reportHardFail("Unable to enter valid Password", true);
		}
	}

	@When("I Enter UserName as {string} and Password as {string} and click on Continue button")
	public void i_Enter_UserName_as_and_Password_as_and_click_on_Continue_button(String userName, String password) {
		try {
			if (newAccountOpeningPage.verifyUserNamePageDisplayed()) {
				newAccountOpeningPage.enterUserName(jsonDataParser.getTestDataMap().get(userName));
				newAccountOpeningPage.tapOnContinueButton();
				newAccountOpeningPage.enterPassword(jsonDataParser.getTestDataMap().get(password));
				newAccountOpeningPage.tapOnContinueButton();
			}
			reportPass("Entered Username and password");
		} catch (Exception e) {
			reportHardFail("Unable to enter Username and password", true);
		}
	}

	@Then("I enter valid email address {string} in NAO")
	public void i_enter_valid_email_address_in_NAO(String email) {
		try {
			newAccountOpeningPage.enterEmailAddress(jsonDataParser.getTestDataMap().get(email));
			reportPass("Email address entered as " + email);
		} catch (Exception e) {
			reportHardFail("Unable to enter valid email address", true);
		}
	}

	@Then("I enter {string} in Promo code box")
	public void i_enter_in_Promo_code_box(String promoCode) {
		try {
			newAccountOpeningPage.enterPromoCode(jsonDataParser.getTestDataMap().get(promoCode));
			reportPass("Promo Code entered as " + promoCode);
		} catch (Exception e) {
			reportHardFail("Unable to enter promo code ", true);
		}
	}

	@Then("Light box appears with message {string}")
	public void light_box_appears_with_message(String message) {
		try {
			newAccountOpeningPage.verifyLightBoxMessage(jsonDataParser.getTestDataMap().get(message));
			reportPass("Verified light box message displayed " + message);
		} catch (Exception e) {
			reportHardFail("Unable to verify the light box message ", true);
		}
	}

	@Then("I click on Continue button in NAO")
	public void i_click_on_Continue_button_in_NAO() {
		try {
			newAccountOpeningPage.tapOnContinueButton();
			reportPass("Clicked on Continue button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Continue button", true);
		}
	}

	@Then("I Clicked on Edit Button in Personal Information")
	public void i_Clicked_on_Edit_Button_in_Personal_Information() {
		try {
			newAccountOpeningPage.tapOnEditButtonInPersonalInformationPage();
			reportPass("Clicked on Edit button in personal information page");
		} catch (Exception e) {
			reportHardFail("Unable to cEdit button in Account Information page", true);
		}
	}

	@Then("I Clicked on Edit Button in Account Information")
	public void i_Clicked_on_Edit_Button_in_Account_Information() {
		try {
			newAccountOpeningPage.tapOnContinueButton();
			reportPass("Clicked on Edit button in Account Information page");
		} catch (Exception e) {
			reportHardFail("Unable to Edit button in Account Information page", true);
		}
	}

	@Then("I verify Email Error Message as {string}")
	public void i_verify_Email_Error_Message_as(String errorMessage) throws Exception {
		if (newAccountOpeningPage.verifyEmailErrorMessage(errorMessage)) {
			reportPass("Can see Error Message as expected");
		} else {
			reportFail("can't able to see Error Message or Message not matched ");
		}
	}

	@Then("I click on Back Button")
	public void i_click_on_Back_Button() {
		try {
			newAccountOpeningPage.tapOnBackButton();
			reportPass("Clicked on back button");
		} catch (Exception e) {
			reportHardFail("Unable to click on back button", true);
		}
	}

	@Then("I click on Ok button on Light Box")
	public void I_click_on_Ok_button_on_Light_Box() {
		try {
			newAccountOpeningPage.clickOkButton();
			reportPass("Clicked on Ok button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Ok button", true);
		}
	}

	@Then("Personal Information Screen should be displayed")
	public void personal_information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyPersonalInformationPage();
			reportPass("Personal information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Personal information page", true);
		}
	}

	@Then("I enter valid Personal Information like {string}, {string}, {string}, {string}, {string}, {string}, {string}, {string}")
	public void i_enter_valid_personal_information_like(String dob, String firstName, String lastName, String address1,
			String address2, String city, String state, String zipCode) {
		try {
			newAccountOpeningPage.enterPersonalInformationDetails(jsonDataParser.getTestDataMap().get(dob),
					jsonDataParser.getTestDataMap().get(firstName), jsonDataParser.getTestDataMap().get(lastName),
					jsonDataParser.getTestDataMap().get(address1), jsonDataParser.getTestDataMap().get(address2),
					jsonDataParser.getTestDataMap().get(city), jsonDataParser.getTestDataMap().get(state),
					jsonDataParser.getTestDataMap().get(zipCode));
			reportPass("Entered details in personal information page");
		} catch (Exception e) {
			reportHardFail("Unable to enter details in personal information page", true);
		}
	}

	@Then("I enter exist Personal Information like {string}, {string}")
	public void i_enter_exist_personal_information_like(String ssn, String dob) {
		try {
			newAccountOpeningPage.enterPersonalInformationDetailsExist(jsonDataParser.getTestDataMap().get(ssn),
					jsonDataParser.getTestDataMap().get(dob));
			reportPass("Entered existing details in personal information page");
		} catch (Exception e) {
			reportHardFail("Unable to enter existing details in personal information page", true);
		}
	}

	@Then("Review Personal Information Screen should be displayed")
	public void Review_Personal_Information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyReviewPersonalInformationPage();
			reportPass("Review Personal Information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Review Personal Information page", true);
		}
	}

	@Then("Identification Information Screen should be displayed")
	public void identification_information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyIdentificationInformationPage();
			reportPass("Identification information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Identification information page", true);
		}
	}

	@Then("I enter valid Identification Information like {string}, {string}, {string}")
	public void i_enter_valid_identification_information_like(String selectCountyCitizenship, String pep1,
			String pep2) {
		try {
			newAccountOpeningPage.enterIdentificationInformation(
					jsonDataParser.getTestDataMap().get(selectCountyCitizenship),
					jsonDataParser.getTestDataMap().get(pep1), jsonDataParser.getTestDataMap().get(pep2));
			reportPass("Entered details in identification information page");
		} catch (Exception e) {
			reportHardFail("Unable to enter details in identification information page", true);
		}
	}

	@Then("Are you a Non Resident or Resident alien Page should be displayed")
	public void are_you_a_Non_Resident_or_Resident_alien_Page_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyNonResidentPage();
			reportPass("Are you a Non Resident or Resident alien page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Are you a Non Resident or Resident alien page", true);
		}
	}

	@Then("I select Resident Type as {string}")
	public void i_select_Resident_Type_as(String resident) {
		try {
			newAccountOpeningPage.tapOnResidentType(jsonDataParser.getTestDataMap().get(resident));
			reportPass("Resident Type selected as " + resident);
		} catch (Exception e) {
			reportHardFail("Unable to select resident type ", true);
		}
	}

	@When("I select country {string} and unselect PEP questions")
	public void i_select_country_and_unselect_PEP_questions(String country) {
		try {
			newAccountOpeningPage.selectCountry(jsonDataParser.getTestDataMap().get(country));
			reportPass("Selected Country and unselect PEP questions");
		} catch (Exception e) {
			reportHardFail("Unable to select Country and unselect PEP questions", true);
		}
	}

	@Then("Driver's License Information Screen should be displayed")
	public void driver_s_License_Information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyDriverLicenseInformationPage();
			reportPass("Drivers License information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Drivers License information page", true);
		}
	}

	@Then("I enter valid Driver License information like {string}, {string}, {string}")
	public void i_enter_valid_Driver_License_information_like(String state, String licenseIssueDate,
			String licenseExpireDate) {
		try {
			newAccountOpeningPage.enterDriverLicenseInformation(jsonDataParser.getTestDataMap().get(state),
					jsonDataParser.getTestDataMap().get(licenseIssueDate),
					jsonDataParser.getTestDataMap().get(licenseExpireDate));
			reportPass("Entered details in Drivers License information page");
		} catch (Exception e) {
			reportHardFail("Unable to enter details in Drivers License information page", true);
		}
	}

	@Then("Employment Information Screen should be displayed")
	public void employment_information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyEmploymentInformationPage();
			reportPass("Employment information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Employment information page", true);
		}
	}

	@When("I enter valid Employment Information like {string}, {string}, {string}")
	public void i_enter_valid_Employment_Information_like(String status, String empName, String jobTitle) {
		try {
			newAccountOpeningPage.enterEmploymentInformation(jsonDataParser.getTestDataMap().get(status),
					jsonDataParser.getTestDataMap().get(empName), jsonDataParser.getTestDataMap().get(jobTitle));
			reportPass("Entered details in employment information page");
		} catch (Exception e) {
			reportHardFail("Unable to enter details in employment information page", true);
		}
	}

	@Then("Review the Account you selected Screen should be displayed with selected product {string}")
	public void review_the_Account_you_selected_Screen_should_be_displayed_with_selected_product(String product) {
		try {
			newAccountOpeningPage.verifyReviewAccountPage(jsonDataParser.getTestDataMap().get(product));
			reportPass("Review the Account you selected page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Review the Account you selected page", true);
		}
	}

	@Then("Review the Account you selected Screen for CD should be displayed with selected product {string}")
	public void review_the_Account_you_selected_Screen_for_CD_should_be_displayed_with_selected_product(
			String product) {
		try {
			newAccountOpeningPage.verifyReviewAccountPageCD(jsonDataParser.getTestDataMap().get(product));
			reportPass("Review the Account you selected page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Review the Account you selected page", true);
		}
	}

	@Then("Account Information Screen should be displayed")
	public void account_information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyAccountInformationPage();
			reportPass("Account information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Account information page", true);
		}
	}

	@When("I enter valid Account Information like {string}, {string}, {string}")
	public void i_enter_valid_Account_Information_like(String depositAmount, String withDrawAmount,
			String internationalService) {
		try {
			newAccountOpeningPage.enterAccountInformation(jsonDataParser.getTestDataMap().get(depositAmount),
					jsonDataParser.getTestDataMap().get(withDrawAmount),
					jsonDataParser.getTestDataMap().get(internationalService));
			reportPass("Entered details in Account information page");
		} catch (Exception e) {
			reportHardFail("Unable to enter details in Account information page", true);
		}
	}

	@Then("International Wire Services Screen should be displayed")
	public void International_Wire_Services_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyInternationalWireServicesPage();
			reportPass("International Wire Services page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view International Wire Services Page", true);
		}
	}

	@Then("I select related International Wire Services like {string}, {string}")
	public void i_select_related_International_Wire_Services_like(String amountIntendToWire,
			String typeOftransactions) {
		try {
			newAccountOpeningPage.selectInternationalWireServices(
					jsonDataParser.getTestDataMap().get(amountIntendToWire),
					jsonDataParser.getTestDataMap().get(typeOftransactions));
			reportPass("International Wire Services are selected");
		} catch (Exception e) {
			reportHardFail("Unable to select international wire services due to " + e, true);
		}
	}

	@Then("Choose My Debit Card Screen should be displayed")
	public void Choose_My_Debit_Card_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyChooseDebitCardPage();
			reportPass("Choose My Debit Card page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Choose My Debit Card page", true);
		}
	}

	@Then("Account Options page is displayed")
	public void Account_Options_page_is_displayed() {
		try {
			newAccountOpeningPage.verifyAccountOptionsPage();
			reportPass("Account Options page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Account Options page", true);
		}
	}

	@Then("Debit Card OverDraft Services Page should be displayed")
	public void Debit_Card_OverDraft_Services_Page_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyDebitCardOverDraftServices();
			reportPass("Debit Card OverDraft Services Page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Debit Card OverDraft Services Page", true);
		}
	}

	@Then("I select any card and select any DebitCard OverDraft Services")
	public void i_select_any_card_and_select_any_DebitCard_OverDraft_Services() {
		try {
			newAccountOpeningPage.verifyChooseDebitCardPage();
			reportPass("Select any debit card and overdraft service");
		} catch (Exception e) {
			reportHardFail("Unable to Select any debit card and overdraft service", true);
		}
	}

	@Then("I select No card in Choose my Debit card Page")
	public void i_select_No_card_in_Choose_my_Debit_card_Page() {
		try {
			newAccountOpeningPage.tapOnNoCard();
			reportPass("Select any NO card and overdraft service");
		} catch (Exception e) {
			reportHardFail("Unable to Select any No card and overdraft service", true);
		}
	}

	@Then("Verify Personal Information Screen should be displayed")
	public void verify_personal_information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyPersonalInformationScreen();
			reportPass("Verify Personal information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Verify Personal information page", true);
		}
	}

	@Then("Verify Your Identity Screen should be displayed")
	public void Verify_Your_Identity_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyYourIdentityPage();
			reportPass("Verify Your Identity page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Verify Your Identity information page", true);
		}
	}

	@Then("I select the Emulation answers as {string} and {string}")
	public void i_select_the_Emulation_answers_as_and(String emulationAnswerOne, String emulationAnswerTwo) {
		try {
			newAccountOpeningPage.selectEmulationAnswers(jsonDataParser.getTestDataMap().get(emulationAnswerOne),
					jsonDataParser.getTestDataMap().get(emulationAnswerTwo));
			reportPass("Selected the emulation answers");
		} catch (Exception e) {
			reportHardFail("Unable to select the emulation answers", true);
		}
	}

	@When("I enter valid email address {string} and valid {string} in NAO")
	public void i_enter_valid_email_address_and_valid_in_NAO(String validEmail, String validPromo) {
		try {
			newAccountOpeningPage.enterPromoCodeAndEmail(jsonDataParser.getTestDataMap().get(validEmail),
					jsonDataParser.getTestDataMap().get(validPromo));
			reportPass("Selected the valid email and promocode successfully");
		} catch (Exception e) {
			reportHardFail("Unable to valid email and promocode successfully", true);
		}
	}

	@Then("I click on Close button in NAO")
	public void i_click_on_Close_button_in_NAO() {
		try {
			newAccountOpeningPage.tapOnCloseButton();
			reportPass("Clicked on Continue button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Continue button", true);
		}
	}

	@Then("Opportunity Checking Account Information Screen should be displayed")
	public void Opportunity_Checking_Account_Information_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyOpportunityCheckingPage();
			reportPass("Opportunity Checking Account Information page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Opportunity Checking Account Information page", true);
		}
	}

	@Then("Opportunity Checking Account Information Screen should not be displayed")
	public void Opportunity_Checking_Account_Information_Screen_should_not_be_displayed() {
		try {
			newAccountOpeningPage.verifyOpportunityCheckingPageNotDisplayed();
			reportPass("Opportunity Checking Account Information page is not displayed");
		} catch (Exception e) {
			reportHardFail("Able to view Opportunity Checking Account Information page", true);
		}
	}

	@Then("Terms and Conditions Page Screen should be displayed")
	public void Terms_and_Conditions_Page_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyTermsAndConditionsPage();
			reportPass("Terms and Conditions Page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Terms and Conditions Page", true);
		}
	}

	@Then("I check all checkboxes in conditions page")
	public void i_check_all_checkboxes_in_conditions_page() {
		try {
			newAccountOpeningPage.checkAllCheckboxes();
			reportPass("Check all checkboxes in terms and conditions");
		} catch (Exception e) {
			reportHardFail("Unable to check all checkboxes in conditions page", true);
		}
	}

	@Then("Create Your Profile Screen should be displayed")
	public void Create_Your_Profile_Screen_should_be_displayed() {
		try {
			newAccountOpeningPage.verifyCreateYourProfilePage();
			reportPass("Create Your Profile page is displayed");
		} catch (Exception e) {
			reportHardFail("Unable to view Create Your Profile page", true);
		}
	}

	@Then("I Enter new Username as {string} and password {string}")
	public void i_Enter_new_Username_as_and_password(String userName, String password) {
		try {
			newAccountOpeningPage.enterNewUserNamePassword(jsonDataParser.getTestDataMap().get(userName),
					jsonDataParser.getTestDataMap().get(password));
			reportPass("Entered new username and password");
		} catch (Exception e) {
			reportHardFail("Unable to enter new username and password", true);
		}
	}

	@Then("NAO Confirmation page should displayed with Account Type, Account Number, Routing Number")
	public void nao_Confirmation_page_should_displayed_with_Account_Type_Account_Number_Routing_Number() {
		try {
			newAccountOpeningPage.verifyNAOConfirmationPage();
			reportPass("NAO Confirmation page is displayed", true);
		} catch (Exception e) {
			reportHardFail("Unable to view NAO Confirmation page", true);
		}
	}

	@When("I tap on Opportunity Checking")
	public void I_tap_on_Opportunity_Checking() {
		try {
			newAccountOpeningPage.tapOnOpportunityChecking();
			reportPass("Clicked on Opportunity Checking");
		} catch (Exception e) {
			reportHardFail("Unable to click on Opportunity Checking", true);
		}
	}

	@Then("I verify Open button should not be available for Opportunity Checking")
	public void i_verify_Open_button_should_not_be_available_for_Opportunity_Checking() {
		try {
			newAccountOpeningPage.verifyOpenAccountButtonOpportunity();
			reportPass("Verified Open Account button is not displayed");
		} catch (Exception e) {
			reportHardFail("Unable to verify Open button is not present for Opportunity Checking", true);
		}
	}

	@Then("System should stop NAO flow and display {string}")
	public void system_should_stop_NAO_flow_and_display(String errMessage) {
		try {
			newAccountOpeningPage.verifyErrorMessage(jsonDataParser.getTestDataMap().get(errMessage));
			if(TestDataConstants.getOSPlatformName().equals("android"))
				newAccountOpeningPage.closeChromeTabs();
			reportPass("Error message displayed for opening account in NAO");
		} catch (Exception e) {
			reportHardFail("Unable to view Error message for NAO flow", true);
		}
	}

	@Then("System should display PEP Error Message {string}")
	public void System_should_display_PEP_Error_Message(String errMessage) {
		try {
			newAccountOpeningPage.verifyErrorMessagePEP(jsonDataParser.getTestDataMap().get(errMessage));
			if(TestDataConstants.getOSPlatformName().equals("android"))
				newAccountOpeningPage.closeChromeTabs();
			reportPass("Error message displayed for PEP questions when unanswered");
		} catch (Exception e) {
			reportHardFail("Unable to view Error message for PEP questions when unanswered", true);
		}
	}

	@Then("I verify {string} message")
	public void i_verify_message(String message) {
		try {
			newAccountOpeningPage.verifyMessageExist(jsonDataParser.getTestDataMap().get(message));
			reportPass("Verified the message displayed as " + message);
		} catch (Exception e) {
			reportHardFail("Unable to verify the " + message + " displayed", true);
		}
	}

	@Then("I tap on Sign In link")
	public void i_tap_on_Sign_In_link() {
		try {
			newAccountOpeningPage.tapOnSignInLink();
			reportPass("Clicked on Sign In link");
		} catch (Exception e) {
			reportHardFail("Unable to click on Sign In link", true);
		}
	}

	@Then("I Verify NAO Progress Bar and email ID and Promocode fields")
	public void i_Verify_NAO_Progress_Bar_and_email_ID_and_Promocode_fields() {
		try {
			newAccountOpeningPage.verifyEmailAddressAndPromocodeDisplayed();
			reportPass("Promocode and Email Address Fileds are displayed");
		} catch (Exception e) {
			reportFail("Unable to verify Promocode and Email Address Fields is displayed", true);
		}
	}

	@Then("I verify What you will Need Details as {string},{string},{string}")
	public void i_verify_What_you_will_Need_Details_as(String employeeInfo, String driverLicense,
			String socialSecurity) {
		try {
			newAccountOpeningPage.verifyNeedDetailsOfNAO(jsonDataParser.getTestDataMap().get(employeeInfo),
					jsonDataParser.getTestDataMap().get(driverLicense),
					jsonDataParser.getTestDataMap().get(socialSecurity));
			reportPass(
					"User Able to verify details present in NAO as  Drivers License,Employee information and social Security Information");
		} catch (Exception e) {
			reportFail(
					"Unable to verify details present in NAO as  Drivers License,Employee information and social Security Information",
					true);
		}
	}

	@Then("I verify Continue Button")
	public void i_verify_Continue_Button() throws Exception {
		if (newAccountOpeningPage.verifyContinueButtonIsDisplayed()) {
			reportPass("User Able to verify Continue Button");
		} else {
			reportFail("Unable to verify Continue Button", true);
		}
	}
	
	@Then("Need to verify Opening and Account With Webster")
	public void need_to_verify_Opening_and_Account_With_Webster() {
		try {
			newAccountOpeningPage.verifyAccountInformationPage();
			reportPass("user is able to open the account successfully");
		} catch (Exception e) {
			reportFail("Unable to open the account with webster", true);
		}
	}

}
