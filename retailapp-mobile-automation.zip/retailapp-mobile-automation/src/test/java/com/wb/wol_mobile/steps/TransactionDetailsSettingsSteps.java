package com.wb.wol_mobile.steps;

import static com.wb.wol_mobile.utilities.TestDataConstants.*;

import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.AccountsPage;
import com.wb.wol_mobile.pages.FilterPage;
import com.wb.wol_mobile.pages.LoginPage;
import com.wb.wol_mobile.pages.ManageAlertsPage;
import com.wb.wol_mobile.pages.PreferencesPage;
import com.wb.wol_mobile.pages.SettingsPage;
import com.wb.wol_mobile.pages.TransactionsHistoryPage;
import com.wb.wol_mobile.pages.ViewAccountsPage;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransactionDetailsSettingsSteps extends ObjectBase {

	LoginPage loginPage = new LoginPage();
	TransactionsHistoryPage transactionHistoryPage = new TransactionsHistoryPage();
	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	FilterPage filterPage = new FilterPage();
	ManageAlertsPage manageAlertsPage = new ManageAlertsPage();
	AccountsPage accountPage = new AccountsPage();
	SettingsPage settingsPage = new SettingsPage();
	PreferencesPage preferencesPage = new PreferencesPage();
	MobileActions mobileActions = new MobileActions();

	int actualTransactions;

	@When("^I click on Aux-gear button$")
	public void i_click_on_Aux_gear_button() {
		try {
			transactionHistoryPage.clickSettingButton();
			reportPass("Successfully clicked on Aux-gear button..");
		} catch (Exception e) {
			reportFail("User is unable to clicked on Aux-gear Button" + e);
		}
	}

	@Then("^I verify Menu page is displayed$")
	public void i_verify_Menu_page_is_displayed() {
		if (transactionHistoryPage.verifyMenuHead()) {
			reportPass("User able to see the menu head text in the page");
		} else {
			reportFail("User unable to see the menu head text in the page");
		}
	}

	@When("^I click on Preferences button$")
	public void i_click_on_Preferences_button() {
		try {
			settingsPage.clickPreferences();
			reportPass("User able to click on preferences button in Menu page");
		} catch (Exception e) {
			reportFail("User is unable to click on preferences button in Menu page" + e);
		}
	}

	@When("I click on Preferences button in another device")
	public void i_click_on_Preferences_button_in_another_device() {
		TransactionsHistoryPage transactionHistoryPage = new TransactionsHistoryPage(RetailAppUtils.customAppiumDriver);
		try {
			transactionHistoryPage.clickOnPreferenceButton();
			reportPass("User able to click on preferences button in Menu page");
		} catch (Exception e) {
			reportFail("User is unable to click on preferences button in Menu page" + e);
		}
	}

	@Then("^I Verify required settings available like \"([^\"]*)\" and \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void i_Verify_required_settings_available_like_and(String preferencesText, String changeAccountText,
			String setStartPageText, String loginType, String Touchid, String passcodeLoginText) {
		try {
			transactionHistoryPage.verifyPreferencesPage(jsonDataParser.getTestDataMap().get(preferencesText),
					jsonDataParser.getTestDataMap().get(changeAccountText), jsonDataParser.getTestDataMap().get(setStartPageText), jsonDataParser.getTestDataMap().get(loginType),
					jsonDataParser.getTestDataMap().get(Touchid), jsonDataParser.getTestDataMap().get(passcodeLoginText));
			reportPass("User is able to verify preference options");
		} catch (Exception e) {
			reportFail("User is unable to verify preference options");
		}
	}

	@Then("I Verify required settings available like {string} and {string},{string},{string},{string},{string} in another device")
	public void i_Verify_required_settings_available_like_and_in_another_device(String preferencesText,
			String changeAccountText, String setStartPageText, String loginType, String TouchID,
			String passcodeLoginText) {
		TransactionsHistoryPage transactionHistoryPage = new TransactionsHistoryPage(RetailAppUtils.customAppiumDriver);
		try {
			transactionHistoryPage.verifyPreferencesPage(jsonDataParser.getTestDataMap().get(preferencesText),
					jsonDataParser.getTestDataMap().get(changeAccountText), jsonDataParser.getTestDataMap().get(setStartPageText), jsonDataParser.getTestDataMap().get(loginType),
					jsonDataParser.getTestDataMap().get(TouchID), jsonDataParser.getTestDataMap().get(passcodeLoginText));
			reportPass("User is able to verify preference options");
		} catch (Exception e) {
			reportFail("User is unable to verify preference options");
		}
	}

	@Then("^I Navigate back to preference menu screen$")
	public void i_Navigate_back_to_preference_menu_screen() {
		try {
			transactionHistoryPage.clickOnBackButton();
			reportPass("User is able to click on back button and navigate to preferences menu screen");
		} catch (Exception e) {
			reportFail("User unable to click on back button and navigate to preferences menu screen" + e);
		}
	}

	@When("^I click on Change Account Order$")
	public void i_click_on_Change_Account_Order() {
		try {
			transactionHistoryPage.clickOnChangeAccountOrder();
			reportPass("User is able to click on Change account order");
		} catch (Exception e) {
			reportFail("User unable to click change account order button" + e);
		}

	}

	@Then("I Tap and Hold drag any account change order")
	public void i_Tap_and_Hold_drag_any_account_change_order() {
		try {
			transactionHistoryPage.setToChangeAccountOrder();
			reportPass("User is able to hold and drag the account to change the priority");
		} catch (Exception e) {
			reportHardFail("User unable to hold and drag the account to change the priority" + e);
		}
	}

	@Then("I verify the number of accounts displayed")
	public void i_verify_the_number_of_accounts_displayed() {
		try {
			transactionHistoryPage.getCountOfAccountsDisplayed();
		} catch (Exception e) {
			reportFail("Unable to get the count of accounts displayed");
		}
	}

	@Then("I Tap and Hold drag {string} account to change order")
	public void i_Tap_and_Hold_drag_account_to_change_order(String account) {
		String acountName = jsonDataParser.getTestDataMap().get(account);
		try {
			transactionHistoryPage.setToChangeSpecificAccountOrder(acountName);
			reportPass("User is able to hold and drag the " + acountName + " to change the priority");
		} catch (Exception e) {
			reportHardFail("User unable to hold and drag the " + acountName + " to change the priority" + e);
		}
	}

	@When("I Tap on Close Preferences and Navigates to Accounts Page")
	public void i_Tap_on_Close_Preferences_and_Navigates_to_Accounts_Page() {
		try {
			transactionHistoryPage.clickAccountOrderCloseButton();
			reportPass("User clicked on the change account order Close button");
		} catch (Exception e) {
			reportFail("User unable to click change account order Close button" + e);
		}
	}

	@Then("I Need to Verify Account order changed in Accounts page")
	public void i_Need_to_Verify_Account_order_changed_in_Accounts_page() throws Exception {
		try {
			transactionHistoryPage.verifyChangeAccountOrder();
			reportPass("able to verify list of accounts");
		} catch (Exception e) {
			reportFail("unable to verify list of accounts");
		}
	}

	@Then("I Need to Verify Account order changed in Accounts page {string} in another device")
	public void i_Need_to_Verify_Account_order_changed_in_Accounts_page_in_another_device(String accountName) {
		AccountsPage accountPage = new AccountsPage(RetailAppUtils.customAppiumDriver);
		try {
			accountPage.verifyAccountIsPresentInViewAccounts(accountName);
			reportPass("able to verify list of accounts");
		} catch (Exception e) {
			reportFail("unable to verify list of accounts");
		}
	}

	@Then("I Need to verify InvestmentAccounts {string} shouldn't be displayed in Transaction History")
	public void i_Need_to_verify_InvestmentAccounts_shouldn_t_be_displayed_in_Transaction_History(String accountName) {
		try {
			accountPage.verifyAccountPresentInTransactionHistory(accountName);
			reportPass("able to verify list of accounts and investment account is not present in transaction history");
		} catch (Exception e) {
			reportFail("unable to verify list of accounts and investment account is  present in transaction history");
		}
	}

	@Then("^I need to verify all the accounts should display$")
	public void i_need_to_verify_all_the_accounts_should_display() throws Exception {
		if (transactionHistoryPage.listOfAccountsDisplayed()) {
			reportPass("Able to verify list of accounts");
		} else {
			reportFail("Unable to verify list of accounts");
		}
	}

	@Then("^I need to verify all the accounts should display with CLOSE and SAVE buttons$")
	public void i_need_to_verify_all_the_accounts_should_display_with_CLOSE_and_SAVE_buttons() throws Exception {
		preferencesPage.verifyAccountsUnderChangeAccountOrder();
		if (preferencesPage.verifySaveAndCloseButtons()) {
			reportPass("able to verify save and close buttons are displayed under the change account order");
		} else {
			reportFail("unable to verify save and close buttons are displayed under the change account order");
		}
	}

	@When("^I Tap on Close or Change Account Order Button$")
	public void i_Tap_on_Close_or_Change_Account_Order_Button() throws Exception {
		try {
			transactionHistoryPage.clickAccountOrderCloseButton();
			reportPass("User clicked on the change account order button");
		} catch (Exception e) {
			reportFail("User unable to click change account order button" + e);
		}

	}

	@When("^I Tap on Set Start Page$")
	public void i_Tap_on_Set_Start_Page() {
		try {
			transactionHistoryPage.clickOnSetStartPageButton();
			reportPass("Clicked on Set start Page button");
		} catch (Exception e) {
			reportFail("Unable to click on the setstart button..." + e);
		}
	}

	@Then("^List will display modules like Transfer Funds,Deposit Checks,Pay Bills,Last Visited,Most Frequently Visited links$")
	public void list_will_display_modules_like_Transfer_Funds_Deposit_Checks_Pay_Bills_Last_Visited_Most_Frequently_Visited_links()
			throws Exception {
		if (transactionHistoryPage.verifyListOfLabelsDisplayed()) {
			reportPass("List of modules are displayed like TransferFunds,Deposit checks etc");
		} else {
			reportFail("Unable to verify the Displayed modules");
		}
	}

	@Then("^I Tap on Cancel or Set Start PageButton$")
	public void i_Tap_on_Cancel_or_Set_Start_PageButton() {
		try {
			transactionHistoryPage.clickStartPageCancelButton();
			reportPass("Clicked on Set start Page button or close button");
		} catch (Exception e) {
			reportFail("Unable to click on the setstart button or close button" + e);
		}
	}

	@When("^I click on filter icon$")
	public void i_click_on_filter_icon() throws Exception {
		try {
			viewAccountsPage.clickOnFilterIcon();
			reportPass("Clicked on filter icon");
		} catch (Exception e) {
			reportFail("Unable to click on Filter Icon " + e);
			throw new Exception();
		}
	}

	@Then("I Need to verify error message displayed as {string}")
	public void i_Need_to_verify_error_message_displayed_as(String string) throws Exception {
		if (filterPage.verifyAmountErrorMessage(string)) {
			reportPass("amount error message is displayed successfully");
		} else {
			reportFail("amount error is not displayed or Unable to verify Error messsage");
		}
	}
	
	@Then("I Need to verify Invalid filter message displayed as {string}")
	public void i_Need_to_verify_invalid_filter_message_displayed_as(String errorMessage) throws Exception {
		try {
			filterPage.verifyInvalidFilterCriteria(errorMessage);
			reportPass("Amount Invalid Error message is displayed successfully");
		}catch(Exception e) {
			reportHardFail("Amount Invlaid Error is not displayed or Unable to verify Error messsage");
		}
	}

	@Then("I Enter FromAmount as ${string} and Click without enter ToAmount")
	public void i_Enter_FromAmount_as_$_and_Click_without_enter_ToAmount(String amount) {
		try {
			filterPage.enterFromAmount(amount);
			filterPage.clickOnDoneApply();
			reportPass("amount is enter successfully with out enter to amount");
		} catch (Exception e) {
			reportFail("unable to enter amount is enter successfully with out enter to amount " + e);
		}
	}

	@Then("I Enter FromAmount as $ {string} and  enter ToAmount as $ {string}")
	public void i_Enter_FromAmount_as_$_and_enter_ToAmount_as_$(String amountOne, String amountTwo) {
		try {
			filterPage.enterFromAmount(amountOne);
			filterPage.enterToAmount(amountTwo);
			reportPass("amount is enter successfully From and To amount");
		} catch (Exception e) {
			reportFail("unable to enter amount is enter successfully From and To amount " + e);
		}
	}

	@Then("I verify FromAmount Field and ToAmount Field should not allow special characters {string}")
	public void i_verify_FromAmount_Field_and_ToAmount_Field_should_not_allow_special_characters(String amount) {
		try {
			if (filterPage.verifyFromAmount(amount)) {
				reportHardFail("Special characters are allowed as input to From amount field");
			}
			if (filterPage.verifyToAmount(amount)) {
				reportHardFail("Special characters are allowed as input to To amount field");
			}
			reportPass("Special Characters are not allowed as input to From and To fields");
		} catch (Exception e) {
			reportHardFail("Unable to verify amount entered as input to From and To fields " + e);
		}
	}

	@Then("^Filter Transactions Page displayed$")
	public void filter_Transactions_Page_displayed() throws Exception {
		try {
			filterPage.verifyFilterOptions();
			reportPass("Clicked on filter icon");
		} catch (Exception e) {
			reportFail("Unable to click on Filter Icon " + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Date Range$")
	public void i_Tap_on_Date_Range() throws Exception {
		try {
			filterPage.tapOnDateRange();
			reportPass("Tapped on Date Range Filter option");
		} catch (Exception e) {
			reportFail("Unable to tap on Date Range Option " + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Last Seven Days$")
	public void i_Tap_on_Last_Seven_Days() throws Exception {
		try {
			filterPage.tapOnLastSevenDays();
			reportPass("Clicked on last seven days filter");
		} catch (Exception e) {
			reportFail("Unable to click on last seven days filter " + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Type$")
	public void i_Tap_on_Type() throws Exception {
		try {
			filterPage.tapOnType();
			reportPass("Clicked on Type option filter");
		} catch (Exception e) {
			reportFail("Unable to click on Type filter option " + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Credit$")
	public void i_Tap_on_Credit() throws Exception {
		try {
			filterPage.tapOnCredit();
			reportPass("Clicked on Credit option");
		} catch (Exception e) {
			reportFail("Unable to click on Credit option " + e);
			throw new Exception();
		}
	}

	@Then("^I click on Clear and Done in iOS, device back on Android, I verify Filters are all deselected$")
	public void i_click_on_Clear_and_Done_in_iOS_device_back_on_Android() throws Exception {
		try {
			filterPage.clearFilters();
			reportPass("Cleared selected filters");
		} catch (Exception e) {
			reportFail("Unable to clear selected filters " + e);
			throw new Exception();
		}
	}

	@When("^I click on Done in iOS, Apply in Android$")
	public void i_click_on_Done_in_iOS_Apply_in_Android() throws Exception {
		try {
			filterPage.clickOnDoneApply();
			reportPass("Clicked on Done/Apply");
		} catch (Exception e) {
			reportFail("Unable to click on Done/Apply " + e);
			throw new Exception();
		}

	}

	@Then("^I see error message as \"([^\"]*)\"$")
	public void i_see_error_message_as(String errorMessage) throws Exception {
		if (loginPage.verifyNoAccountErrorMessage(jsonDataParser.getTestDataMap().get(errorMessage))) {
			reportPass("No Accounts error message is displayed successfully");
		} else {
			reportFail("Error message is not displayed or Unable to verify Error messsage");
		}

	}

	@When("^I click on selected closed Account$")
	public void i_click_on_selected_closed_Account() {
		try {
			viewAccountsPage.clickAccount(CLOSED_ACCOUNT);
			reportPass("CLOSED Accounts error message is displayed successfully");
		} catch (Exception e) {
			reportFail("Error message is not displayed or Unable to verify Error messsage" + e);
		}
	}

	@Then("^I need to Verify closed account error message as \"([^\"]*)\"$")
	public void i_need_to_Verify_closed_error_message_as(String errorMessage) throws Exception {
		if (accountPage.verifyClosedAccountErrorMessage(jsonDataParser.getTestDataMap().get(errorMessage))) {
			reportPass("closed Accounts error message is displayed successfully");
		} else {
			reportFail("Error message is not displayed or Unable to verify Error messsage");
		}
	}

	@When("^I Click on Purged Account$")
	public void i_Click_on_Purged_Account() throws Exception {
		try {
			viewAccountsPage.clickAccount(PURGED_ACCOUNT_2);
			reportPass("PURGED  Accounts error message is displayed successfully");
		} catch (Exception e) {
			reportFail("Error message is not displayed or Unable to verify Error messsage" + e);
		}
	}

	@Then("^I need to verify purged error message as \"([^\"]*)\"$")
	public void i_need_to_verify_purged_error_message_as(String errorMessage) throws Exception {
		if (accountPage.verifyPurgedAccountErrorMessage(jsonDataParser.getTestDataMap().get(errorMessage))) {
			reportPass("purged Accounts error message is displayed successfully");
		} else {
			reportFail("Error message is not displayed or Unable to verify Error messsage");
		}
	}

	@When("^I Click on selected CreditCard Account$")
	public void i_Click_on_selected_CreditCard_Account() {
		try {
			viewAccountsPage.clickAccount(CREDITCARD_ACCOUNT);
			reportPass("Click on Credit card account successfully");
		} catch (Exception e) {
			reportFail("Unable to click on the Creditcard Account" + e);
		}
	}

	@Then("^I need to Verify CreditCard error message as \"([^\"]*)\"$")
	public void i_need_to_Verify_CreditCard_error_message_as(String message) {
		if (accountPage.verifyCreditCardAccountErrorMessage(jsonDataParser.getTestDataMap().get(message))) {
			reportPass("Credit Card error message is displayed successfully");
		} else {
			reportFail("Error message is not displayed or Unable to verify Error messsage");
		}
	}

	@Then("I need to Verify HideAccounts and NickName Options in another device")
	public void i_need_to_Verify_HideAccounts_and_NickName_Options_in_another_device() throws Exception {
		TransactionsHistoryPage transactionHistoryPage = new TransactionsHistoryPage(RetailAppUtils.customAppiumDriver);
		if (transactionHistoryPage.verifyAccountPreferences()) {
			reportPass("Hide Accounts and Nick Name options are displayed");
		} else {
			reportFail("Unable to verify the HideAccounts and Nick Names ");
		}
	}

	@Then("^I need to verify account info is displayed under hide accounts$")
	public void i_need_to_verify_account_info_is_displayed_under_hide_accounts() throws Exception {
		if (transactionHistoryPage.verifyAccountsDisplayedUnderHiddenAccounts()) {
			reportPass("Credit Card error message is displayed successfully");
		} else {
			reportFail("Error message is not displayed or Unable to verify Error messsage");
		}
	}

	@When("I Tap on the PrimaryAccount {string} Under AccountPreferences")
	public void i_Tap_on_the_PrimaryAccount_Under_AccountPreferences(String accname) {
		try {
			transactionHistoryPage.clickOnPrimaryAccount(accname);
			reportPass("Clicked on Primary Account Under Account Preferences");
		} catch (Exception e) {
			reportFail("Unable to click on the Primary Account Under Preferences" + e);
		}
	}

	@Then("^I need to Verify HideAccounts and NickName Options$")
	public void i_need_to_Verify_HideAccounts_and_NickName_Options() throws Exception {
		if (transactionHistoryPage.verifyAccountPreferences()) {
			reportPass("Hide Accounts and Nick Name options are displayed");
		} else {
			reportFail("Unable to verify the HideAccounts and Nick Names ");
		}
	}

	@Then("Tap on the Enable Hide Account Menu {string}")
	public void tap_on_the_Enable_Hide_Account_Menu(String status) {
		try {
			transactionHistoryPage.clickOnHideAccount(status);
			reportPass("Clicked On Enable Hide Account Menu Button");
		} catch (Exception e) {
			reportFail("Unable to click on Enable Hide Account Menu Preferences" + e);
		}
	}

	@Then("Tap on the Enable Hide Account Menu {string} in another device")
	public void tap_on_the_Enable_Hide_Account_Menu_in_another_device(String status) {
		TransactionsHistoryPage transactionHistoryPage = new TransactionsHistoryPage(RetailAppUtils.customAppiumDriver);
		try {
			transactionHistoryPage.clickOnHideAccount(status);
			reportPass("Clicked On Enable Hide Account Menu Button");
		} catch (Exception e) {
			reportFail("Unable to click on Enable Hide Account Menu Preferences" + e);
		}
	}

	@Then("^I need to Verify HideAccount error message as \"([^\"]*)\"$")
	public void i_need_to_Verify_HideAccount_error_message_as(String errorMessage) throws Exception {
		if (transactionHistoryPage.verifyHideAccountErrorMessage(jsonDataParser.getTestDataMap().get(errorMessage))) {
			reportPass("Hide Account error message is displayed ");
		} else {
			reportFail("HideAccount Error message is not displayed or Unable to verify Error messsage");
		}
	}

	@When("^I Tap on the Checking Account$")
	public void i_Tap_on_the_Checking_Account() {
		try {
			viewAccountsPage.clickAccount(CHECKING_ACCOUNT_2);
			reportPass("****User clicked on the checking account**** ");
		} catch (Exception e) {
			reportFail("User unable to click on the checking account" + e);
		}
	}

	@When("^I Tap on the Saving Account$")
	public void i_Tap_on_the_Saving_Account() {
		try {
			manageAlertsPage.clickOnSelectedAccount(SAVING_ACCOUNT);
			reportPass("****User clicked on the SAVING account**** ");
		} catch (Exception e) {
			reportFail("User unable to click on the saving account" + e);
		}
	}

	@When("^I Tap on the Loan Account$")
	public void i_Tap_on_the_Loan_Account() {
		try {
			manageAlertsPage.clickOnSelectedAccount(LOAN_ACCOUNT);
			reportPass("****User clicked on the loan account**** ");
		} catch (Exception e) {
			reportFail("User unable to click on the loan account" + e);
		}
	}

	@When("^I Tap on the CD Account$")
	public void i_Tap_on_the_CD_Account() {
		try {
			manageAlertsPage.clickOnSelectedAccount(CD_ACCOUNT);
			reportPass("****User clicked on the cd account**** ");
		} catch (Exception e) {
			reportFail("User unable to click on the cd account" + e);
		}
	}

	@Then("^I need to verify available balances and transactions of the account selected$")
	public void i_need_to_verify_available_balances_and_transactions_of_the_account_selected() throws Exception {
		if (accountPage.verifyBalancesAndTransactionsDetails()) {
			reportPass("User able to verify available balances and transactions of that account selected");
		} else {
			reportFail("User Unable to verify available balances and transactions of that account selected");
		}
	}

	@When("^I Tap on any one of the transaction$")
	public void i_Tap_on_any_one_of_the_transaction() {
		try {
			accountPage.clickOnFirstTransaction();
			reportPass("****User clicked any one of the account**** ");
		} catch (Exception e) {
			reportFail("User unable to click any one of the account" + e);
		}
	}

	@Then("^I need to verify the balances and transaction details displayed$")
	public void i_need_to_Verify_transaction_details_as_and() throws Exception {
		if (transactionHistoryPage.verifyTransactionsDetails()) {
			reportPass("User able to verify all the details for that transaction");
		} else {
			reportFail("User Unable to verify all the details for that transaction");
		}
	}

	@Then("^Filters should enabled succesfully$")
	public void filters_should_enabled_succesfully() throws Exception {
		try {
			filterPage.filtersEnabled();
			reportPass("Filters enabled successfully");
		} catch (Exception e) {
			reportFail("Unable to verify filters are selected " + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Amount Range$")
	public void i_Tap_on_Amount_Range() throws Exception {
		try {
			filterPage.tapOnAmountRange();
			reportPass("Tapped on amount range");
		} catch (Exception e) {
			reportFail("Unable to tap on amount range " + e);
			throw new Exception();
		}
	}

	@Then("^I enter \"([^\"]*)\" in From and \"([^\"]*)\" in To field$")
	public void i_enter_in_From_and_in_To_field(String fromAmount, String toAmount) throws Exception {
		try {
			filterPage.enterFromAmount(fromAmount);
			waits.staticWait(2);
			filterPage.enterToAmount(toAmount);
			reportPass("Amount entered successfully");
		} catch (Exception e) {
			reportFail("Amount entered have issue " + e);
			throw new Exception();
		}
	}

	@Then("I enter FromAmount in From and ToAmount in To field")
	public void i_enter_FromAmount_in_From_and_ToAmount_in_To_field() throws Exception {
		try {
			filterPage.enterGetFromAmount();
			waits.staticWait(2);
			filterPage.enterGetToAmount();
			if (TestDataConstants.getOSPlatformName().contains("android"))
				appiumDriver.navigate().back();
			reportPass("Entered amount in To and From field");
		} catch (Exception e) {
			reportFail("Unable to enter the amount in To and From field " + e);
			throw new Exception();
		}
	}

	@When("I click on Details icon on iOS and See Details in Android")
	public void i_click_on_Details_icon_on_iOS_and_See_Details_in_Android() throws Exception {
		try {
			viewAccountsPage.tapOnDetailsIcon();
			reportPass("Clicked on details icon in ios and see details in android");
		} catch (Exception e) {
			reportFail("Unable to click on Account Details icon " + e);
			throw new Exception();
		}
	}

	@When("I click on Account Settings button in Account Details Page")
	public void i_click_on_Account_Settings_button_in_Account_Details_Page() throws Exception {
		try {
			viewAccountsPage.tapOnAccountSettingsIcon();
			reportPass("Clicked on Account settings icon in details page");
		} catch (Exception e) {
			reportFail("Unable to click on Account settings icon in details page " + e);
			throw new Exception();
		}
	}

	@Then("I verify the options displayed Hide Account, Edit Nickname, Close button, Save button")
	public void i_verify_the_options_displayed_Hide_Account_Edit_Nickname_Close_button_Save_button() throws Exception {
		try {
			viewAccountsPage.verifyAccountSettingsOptions();
			reportPass("Verified the account accounts in details page");
		} catch (Exception e) {
			reportFail("Unable to verify the account accounts in details page " + e);
			throw new Exception();
		}
	}

	@When("I click on close and navigate back to view account page and verify account is not hide")
	public void i_click_on_close_and_navigate_back_to_view_account_page_and_verify_account_is_not_hide()
			throws Exception {
		try {
			viewAccountsPage.clickOnClose();
			waits.staticWait(3);
			appiumDriver.navigate().back();
			viewAccountsPage.verifyViewAccountsPageTitle();
			reportPass("Clicked on close button and navigated back to view accounts page");
		} catch (Exception e) {
			reportFail("Unable to click on close and navigate back to view accounts page " + e);
			throw new Exception();
		}
	}

	@When("I click on Hide Account option")
	public void i_click_on_Hide_Account_option() throws Exception {
		try {
			viewAccountsPage.clickOnHideAccount();
			reportPass("Clicked on Hide Account");
		} catch (Exception e) {
			reportFail("Unable to click on Hide Account " + e);
			throw new Exception();
		}
	}

	@Then("I click on Save in Android and Confirm in iOS, account will be hidden")
	public void i_click_on_Save_in_Android_and_Confirm_in_iOS() throws Exception {
		try {
			viewAccountsPage.confirmSaveHideAccount();
			reportPass("Account hidden by clicking on save and confirm");
		} catch (Exception e) {
			reportFail("Unable to save and confirm hidden account " + e);
			throw new Exception();
		}
	}

	@When("I search for any transaction {string} for account {string}")
	public void i_search_for_any_transaction_for_account(String searchText, String account) throws Exception {
		try {
			viewAccountsPage.scrollToText(jsonDataParser.getTestDataMap().get(account));
			viewAccountsPage.clickAccount(jsonDataParser.getTestDataMap().get(account));
			viewAccountsPage.enterSearchText(jsonDataParser.getTestDataMap().get(searchText), jsonDataParser.getTestDataMap().get(account));
			reportPass("Entered search text in bar " + jsonDataParser.getTestDataMap().get(searchText) + " for account "
					+ jsonDataParser.getTestDataMap().get(account));
		} catch (Exception e) {
			reportFail("Unable to enter search value in search bar");
			throw new Exception();
		}
	}

	@Then("I verify the error message for search {string}")
	public void i_verify_the_error_message_for_search(String searchErrorMessage) throws Exception {
		try {
			viewAccountsPage.verifyErrorMessageNoResults(jsonDataParser.getTestDataMap().get(searchErrorMessage));
			reportPass("No items available error message displayed");
		} catch (Exception e) {
			reportFail("Unable to verify the No items available error message displayed " + e);
			throw new Exception();
		}
	}

	@Then("Search Results will only show transactions that have word {string}")
	public void search_Results_will_only_show_transactions_that_have_word(String searchText) throws Exception {
		try {
			viewAccountsPage.verifyTransactionHistoryAmount(jsonDataParser.getTestDataMap().get(searchText));
			reportPass("Search results showed for searched keyword");
		} catch (Exception e) {
			reportFail("Unable to verify the transaction results " + e);
			throw new Exception();
		}
	}

	@When("I click on account that have transactions")
	public void i_click_on_account_that_have_transactions() throws Exception {
		try {
			viewAccountsPage.accountHavingTransactions();
			reportPass("Clicked on account and verified the transactions");
		} catch (Exception e) {
			reportFail("Unable to click on account " + e);
			throw new Exception();
		}
	}

	@Then("I scroll down through the transaction history")
	public void i_scroll_down_through_the_transaction_history() throws Exception {
		try {
			viewAccountsPage.scrollDown();
			reportPass("Scrolled down through the transactions");
		} catch (Exception e) {
			reportFail("Unable to scroll down through the transactions " + e);
			throw new Exception();
		}
	}

	@When("I tap on first  and second transaction listed under the account they should expand")
	public void i_tap_on_first_and_second_transaction_listed_under_the_account_they_should_expand() throws Exception {
		try {
			viewAccountsPage.getCountForTransactionExpandOptions();
			viewAccountsPage.expandTransactions();
			reportPass("Tapped on transactions and verified they expanded");
		} catch (Exception e) {
			reportFail("Unable to Tapped on transactions and verified they expanded " + e);
			throw new Exception();
		}
	}

	@When("Both transactions should stay open")
	public void both_transactions_should_stay_open() throws Exception {
		if (viewAccountsPage.verifyStatusTransaction()) {
			reportPass("Verified all transactions expanded stayed opened");
		} else {
			reportFail("Unable to verify all transactions expanded stayed opened ");
		}
	}

	@Then("I select a account {string} having transactions debit and credit")
	public void i_select_a_account_having_transactions_debit_and_credit(String account) throws Exception {
		try {
			viewAccountsPage.clickAccount(account);
			reportPass("Selected the account " + account + " and verified the transactions");
		} catch (Exception e) {
			reportFail("Unable to select account " + account + " and verify the transactions " + e);
			throw new Exception();
		}
	}

	@Then("Credit and Debit options should be displayed and selected by default")
	public void credit_and_Debit_options_should_be_displayed_and_selected_by_default() throws Exception {
		try {
			filterPage.verifyTypeOptions();
			reportPass("Verified the Credit and Debit options");
		} catch (Exception e) {
			reportFail("Unable to verify the Type options Debit and Credit " + e);
			throw new Exception();
		}
	}

	@When("I swipe left and off the filter")
	public void i_swipe_left_and_off_the_filter() throws Exception {
		try {
			filterPage.tapOffType();
			reportPass("Type Filter is off");
		} catch (Exception e) {
			reportFail("Unable to off the Type filter" + e);
			throw new Exception();
		}
	}

	@When("I swipe left and off the Date filter")
	public void i_swipe_left_and_off_the_Date_filter() throws Exception {
		try {
			filterPage.tapOffDate();
			reportPass("Date Filter is off");
		} catch (Exception e) {
			reportFail("Unable to off the Date filter" + e);
			throw new Exception();
		}
	}

	@When("I swipe left and off the Amount filter")
	public void i_swipe_left_and_off_the_Amount_filter() throws Exception {
		try {
			filterPage.tapOffAmount();
			reportPass("Amount Filter is off");
		} catch (Exception e) {
			reportFail("Unable to off the filter" + e);
			throw new Exception();
		}
	}

	@Then("Filter should close and display all debit and credit transactions")
	public void filter_should_close_and_display_all_debit_and_credit_transactions() throws Exception {
		try {
			waits.staticWait(4);
//			mobileActions.scrollUp();
			actualTransactions = viewAccountsPage.getCountForTransactionExpandOptions();
//			TODO: Validate the count is more than expected after the filters are removed
			reportPass("Clicked on apply/Done on filter pane");
		} catch (Exception e) {
			reportFail("Unable to click on apply/Done on filter pane " + e);
			throw new Exception();
		}
	}

	@Then("I select debit and deselect credit")
	public void i_select_debit_and_deselect_credit() throws Exception {
		try {
			filterPage.tapOnCredit();
			reportPass("Selected Debit and deselect Credit");
		} catch (Exception e) {
			reportFail("Unable to select Debit and deselect Credit " + e);
			throw new Exception();
		}
	}

	@Then("Filter should save successfully and only Debit type transactions should appear")
	public void filter_should_save_successfully_and_only_Debit_type_transactions_should_appear() throws Exception {
		try {
			waits.staticWait(4);
			viewAccountsPage.scrollDown();
			int debitTransactions = viewAccountsPage.getCountForTransactionExpandOptions();
			if (debitTransactions == actualTransactions)
				throw new Exception("Filter is not saved and hence the transactions did not filtered properly");
			reportPass("Filter Saved and only Debit type transactions displayed");
		} catch (Exception e) {
			reportFail("Unable to save filter and only Debit type transactions not displayed " + e);
			throw new Exception();
		}
	}

	@Then("I select Credit and deselect debit")
	public void i_select_Credit_and_deselect_debit() throws Exception {
		try {
			filterPage.tapOnDebit();
			reportPass("Selected Credit and deselect Debit");
		} catch (Exception e) {
			reportFail("Unable to select Credit and deselect Debit " + e);
			throw new Exception();
		}
	}

	@Then("Filter should save successfully and only Credit type transactions should appear")
	public void filter_should_save_successfully_and_only_Credit_type_transactions_should_appear() throws Exception {
		try {
			waits.staticWait(4);
			viewAccountsPage.scrollDown();
			int debitTransactions = viewAccountsPage.getCountForTransactionExpandOptions();
			if (debitTransactions == actualTransactions)
				throw new Exception("Filter is not saved and hence the transactions did not filtered properly");
			reportPass("Filter Saved and only Credit type transactions displayed");
		} catch (Exception e) {
			reportFail("Unable to save filter and only Credit type transactions not displayed " + e);
			throw new Exception();
		}
	}

	@Then("System should display the available balance and all transactions")
	public void system_should_display_the_available_balance_and_all_transactions() throws Exception {
		try {
			viewAccountsPage.verifyAmountDisplayed();
			viewAccountsPage.datesDisplayed();
			viewAccountsPage.sortDatesGetFirstLastDates();
			reportPass("Amount displayed for the account");
		} catch (Exception e) {
			reportFail("Amount not displayed due to " + e);
			throw new Exception();
		}
	}

	@Then("System should display the amounts for all transactions")
	public void system_should_display_the_amounts_for_all_transactions() throws Exception {
		try {
			viewAccountsPage.verifyAmountDisplayed();
			viewAccountsPage.amountsDisplayed();
			reportPass("Amount displayed for the account");
		} catch (Exception e) {
			reportFail("Amount not displayed due to " + e);
			throw new Exception();
		}
	}

	@When("I select the Date Range option")
	public void i_select_the_Date_Range_option() throws Exception {
		try {
			filterPage.tapOnDateRangeOption();
			reportPass("Selected the Date Range option");
		} catch (Exception e) {
			reportFail("Unable to select the Date Range option " + e);
			throw new Exception();
		}
	}

	@When("I enter the Date Range in From and To fields with no records")
	public void i_enter_the_Date_Range_in_From_and_To_fields_with_no_records() throws Exception {
		try {
			filterPage.selectDateOnCalender();
			reportPass("Entered date range in from and to fields");
		} catch (Exception e) {
			reportFail("Unable to enter date range in from and to fields " + e);
			throw new Exception();
		}

	}

	@Then("System should display the From and To Date fields and default date should be date of Transaction history")
	public void system_should_display_the_From_and_To_Date_fields_and_default_date_should_be_date_of_Transaction_history()
			throws Exception {
		try {
			filterPage.verifyDateFromToDisplayed();
			filterPage.verifyTransactionDates();
			reportPass("Verified system should displayed From and To Dates in Date Filter");
		} catch (Exception e) {
			reportFail("Unable to verified the From and To dates in Date Range " + e);
			throw new Exception();
		}
	}

	@When("I enter the Date Range in From and To fields")
	public void i_enter_the_Date_Range_in_From_and_To_fields() throws Exception {
		try {
			filterPage.selectDateOnCalender();
			reportPass("Entered date range in from and to fields");
		} catch (Exception e) {
			reportFail("Unable to enter date range in from and to fields " + e);
			throw new Exception();
		}
	}

	@Then("System should display the transaction history with filtered Date Range entered")
	public void system_should_display_the_transaction_history_with_filtered_Date_Range_entered() throws Exception {
		try {
			viewAccountsPage.compareDates();
			reportPass("Compared the default dates of filter page are displayed as per the transaction history");
		} catch (Exception e) {
			reportFail(
					"Unable to compare the default dates of filter page are displayed as per the transaction history "
							+ e);
			throw new Exception();
		}
	}

	@Then("System should display the transaction history with filtered Amount Range entered")
	public void system_should_display_the_transaction_history_with_filtered_Amount_Range_entered() throws Exception {
		try {
			viewAccountsPage.compareAmounts();
			reportPass("Compared the amounts of filter page are displayed as per the transaction history");
		} catch (Exception e) {
			reportFail(
					"Unable to compare the amounts of filter page are displayed as per the transaction history " + e);
			throw new Exception();
		}
	}

	@Then("All {int} filters should be disabled")
	public void all_filters_should_be_disabled(Integer filters) throws Exception {
		try {
			filterPage.filtersDisabled(filters);
			reportPass("Verified all filters are disabled");
		} catch (Exception e) {
			reportFail("Unable to verified all filters are disabled " + e);
			throw new Exception();
		}
	}

	@Then("System should display the transaction history for Last {int} Days")
	public void system_should_display_the_transaction_history_for_Last_Days(Integer days) throws Exception {
		try {
			viewAccountsPage.compareLastSevenFourteenDays(days);
			reportPass("Compared transaction history as per last " + days + " days");
		} catch (Exception e) {
			reportFail("Unable to compare transaction history as per last " + days + " days" + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Last Fourteen Days$")
	public void i_Tap_on_Last_Fourteen_Days() throws Exception {
		try {
			filterPage.tapOnLastFourteenDays();
			reportPass("Clicked on last fourteen days filter");
		} catch (Exception e) {
			reportFail("Unable to click on last fourteen days filter " + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Month to Date$")
	public void i_Tap_on_Month_to_Date() throws Exception {
		try {
			filterPage.tapOnMonthToDate();
			reportPass("Clicked on Month to date filter");
		} catch (Exception e) {
			reportFail("Unable to click on Month to date filter " + e);
			throw new Exception();
		}
	}

	@When("^I Tap on Specific Date$")
	public void i_Tap_on_Specific_Date() throws Exception {
		try {
			filterPage.tapOnSpecificDate();
			reportPass("Clicked on Specific Date filter");
		} catch (Exception e) {
			reportFail("Unable to click on specific Date filter " + e);
			throw new Exception();
		}
	}

	@Then("System should display the transaction history for selected specific date")
	public void system_should_display_the_transaction_history_for_selected_specific_date() throws Exception {
		try {
			viewAccountsPage.verifyTransactionSpecificDate();
			reportPass("Verified the transaction history is displayed with specific date");
		} catch (Exception e) {
			reportFail("Transaction history is not displayed with specific dates " + e);
			throw new Exception();
		}
	}

	@Then("^I Tap on the Filter Icon displayed right to the Search Bar$")
	public void i_Tap_on_the_Filter_Icon_displayed_right_to_the_Search_Bar() {
		try {
			transactionHistoryPage.clickOnFilterButton();
			reportPass("User able to Tap on the Filter Icon Displayed on the right side");
		} catch (Exception e) {
			reportFail("User is Unable to Tap on the Filter Icon Displayed on the right side" + e);
		}

	}

	@Then("^I Select the Amount Range to turn the filter on$")
	public void i_Select_the_Amount_Range_to_turn_the_filter_on() {
		try {
			transactionHistoryPage.clickOnAmountRangeButton();
			reportPass("User able to select the amount range and filter on ");
		} catch (Exception e) {
			reportFail("User Unable to select the amount range and filter on" + e);
		}

	}

	@Then("^I Select the Amount Range to turn the filter off$")
	public void i_Select_the_Amount_Range_to_turn_the_filter_off() {
		try {
			transactionHistoryPage.clickOnAmountRangeButton();
			reportPass("User able to select the amount range and filter off ");
		} catch (Exception e) {
			reportFail("User Unable to select the amount range and filter off" + e);
		}

	}

	@Then("I Need to verify filters are disabled {int}")
	public void i_Need_to_verify_filters_are_disabled(Integer filter) throws Exception {
		if (accountPage.verifyFilterStatus(filter)) {
			reportPass("all the filters are disabled successfully");
		} else {
			reportFail("all filters are enabled ");
		}

	}

	@Then("^I Enter \\$\"([^\"]*)\" in the From category$")
	public void i_Enter_$_in_the_From_category(String from) {
		try {
			transactionHistoryPage.enterFromAmount(from);
			reportPass("User able to enter the amount in the from category");
		} catch (Exception e) {
			reportFail("User Unable to enter the amount in the from category" + e);
		}
	}

	@Then("^I Enter \\$\"([^\"]*)\" in the To Category$")
	public void i_Enter_$_in_the_To_Category(String Toamount) {
		try {
			transactionHistoryPage.enterToAmount(Toamount);
			reportPass("User able to enter the amount in the To category");
		} catch (Exception e) {
			reportFail("User Unable to enter the amount in the To category" + e);
		}

	}

	@Then("^I Tap on Done or Clear$")
	public void i_Tap_on_Done_or_Clear() {
		try {
			transactionHistoryPage.clickOnDoneButton();
			reportPass("User able Click on Done Button");
		} catch (Exception e) {
			reportFail("User Unable to Click on Done or Clear Button" + e);
		}
	}

	@Then("^I Need to Verify the Amount Greater than Error Message Displayed as \"([^\"]*)\"$")
	public void i_Need_to_Verify_the_Amount_Greater_than_Error_Message_Displayed_as(String errorMessage)
			throws Exception {
		if (transactionHistoryPage.verifyGreaterErrorMessage(errorMessage)) {
			reportPass("Amount should be grater than from account error is displayed");
		} else {
			reportFail("Unable to verify the Amount should be grater than from account error message");
		}

	}

	@Then("^I Need to verify the all the accounts  displayed under account preferences$")
	public void i_Need_to_verify_the_all_the_accounts_displayed_under_account_preferences() throws Exception {
		try {
			accountPage.verifyAccountsUnderAccountPreferences();
			reportPass("all accounts are displayed under the account preferences module");
		} catch (Exception e) {
			reportFail("Unable to display all accounts  under the account preferences module");
		}
	}

	@Then("^I Need to verify Preference message as \"([^\"]*)\"$")
	public void i_Need_to_verify_Preference_message_as(String errorMessage) throws Exception {
		if (transactionHistoryPage.verifyPreferenceMessage(jsonDataParser.getTestDataMap().get(errorMessage))) {
			reportPass("accounts preferences are saved successfully");
		} else {
			reportFail("Unable to verify accounts preferences");
		}
	}

	@Then("I Need to verify Preference message as {string} in another device")
	public void i_Need_to_verify_Preference_message_as_in_another_device(String errorMessage) throws Exception {
		TransactionsHistoryPage transactionHistoryPage = new TransactionsHistoryPage(RetailAppUtils.customAppiumDriver);
		if (transactionHistoryPage.verifyPreferenceMessage(jsonDataParser.getTestDataMap().get(errorMessage))) {
			reportPass("accounts preferences are saved successfully");
		} else {
			reportFail("Unable to verify accounts preferences");
		}
	}

	@Then("^I Clicked on Logout$")
	public void i_Clicked_on_Logout() {
		try {
			settingsPage.navigateBackClickLogout();
			reportPass("User able Click on LogOut Button");
		} catch (Exception e) {
			reportFail("User Unable to Click LogOut Button" + e);
		}
	}

	@Then("I Clicked on Logout in Settings Page")
	public void i_Clicked_on_Logout_in_Settings_Page() {
		try {
			settingsPage.clickOnLogout();
			reportPass("User able Click on LogOut Button");
		} catch (Exception e) {
			reportFail("User Unable to Click LogOut Button" + e);
		}
	}

	@Then("I Clicked on Logout in another device")
	public void i_Clicked_on_Logout_in_another_device() throws Exception {
		SettingsPage settingsPage = new SettingsPage(RetailAppUtils.customAppiumDriver);
		try {
			settingsPage.clickOnLogoutCustomEngine();
			reportPass("Successfully logged out from app ");
		} catch (Exception e) {
			reportFail("Unable to logout from app " + e);
			ConcurrentEngines.destroyCustomEngine();
			throw new Exception();
		}
	}

	@Then("I see Transfer Funds page with title {string}")
	public void i_see_Transfer_Funds_page_with_title(String titlename) throws Exception {
		if (accountPage.verifyTransferFundPage(jsonDataParser.getTestDataMap().get(titlename))) {
			reportPass("User is able to see the Transfer Funds head instead of accounts summary head");
		} else {
			reportFail("User is unable to see the Transfer Funds head instead of accounts summary head");
		}
	}

	@When("I Tap on any account listed under the account preferences")
	public void i_Tap_on_any_account_listed_under_the_account_preferences() {
		try {
			accountPage.clickOnAccountUnderPreferences("Checking8970");
			reportPass("User is able to click on the account listed under preferences");
		} catch (Exception e) {
			reportFail("User is Unable to click on the account listed under preferences" + e);
		}
	}

	@When("I Tap on account under preferences {string} in another device")
	public void i_Tap_on_account_under_preferences_in_another_device(String accountName) {
		AccountsPage accountPage = new AccountsPage(RetailAppUtils.customAppiumDriver);
		try {
			accountPage.clickOnSelectedAccount(accountName);
			reportPass("User is able to click on the account" + accountName + " listed under preferences");
		} catch (Exception e) {
			reportFail("User is Unable to click on the account listed under preferences" + e);
		}
	}

	@When("I Tap on account under preferences {string}")
	public void i_Tap_on_account_under_preferences(String accountName) {
		try {
			accountPage.clickOnSelectedAccount(accountName);
			reportPass("User is able to click on the account" + accountName + " listed under preferences");
		} catch (Exception e) {
			reportFail("User is Unable to click on the account listed under preferences" + e);
		}
	}

	@Then("I Need to verify the Account is hidden on the Main Accounts Page or not")
	public void i_Need_to_verify_the_Account_is_hidden_on_the_Main_Accounts_Page_or_not() throws Exception {
		if (!accountPage.verifyHiddenAccountIsDisplayed(CHECKING_ACCOUNT_2)) {
			reportPass("account is not displayed in the list ");
		} else {
			reportFail("account is displayed in the list So unble to hide account");
		}
	}

	@Then("I Need to verify Accounts are displayed in Main acccounts page")
	public void i_Need_to_verify_Accounts_are_displayed_in_Main_acccounts_page() throws Exception {
		if (!accountPage.verifyUnHideAccountDisplayed(CHECKING_ACCOUNT_2)) {
			reportPass("account is not displayed in the list ");
		} else {
			reportFail("account is displayed in the list So unble to hide account");
		}
	}

	@Then("I Need to verfiy  confirmation popup to unhide account and Click Confirm Button")
	public void i_Need_to_verfiy_confirmation_popup_to_unhide_account_and_Click_Confirm_Button() throws Exception {
		if (accountPage.verifyAccountUnHidePopup()) {
			reportPass("User is able to verify unHidePopup");
		} else {
			reportFail("User is unable to verify unHidePopup");
		}
	}

	@When("I Scroll Down through the transaction History to end of the page")
	public void i_Scroll_Down_through_the_transaction_History_to_end_of_the_page() {
		try {
			accountPage.scrollDownToBottom();
			reportPass("able to scroll to the bottom of the page");
		} catch (Exception e) {
			reportFail("unable to scroll to the bottom of the page " + e);
		}
	}

	@Then("I Need to verify no problems in the page")
	public void i_Need_to_verify_no_problems_in_the_page() throws Exception {
		if (accountPage.verifyAccountsPage()) {
			reportPass("User is able to see the accounts text in accounts summary page");
		} else {
			reportFail("User is unable to see the accounts text in accounts summary page");
		}
	}

	@Then("I verify Close and Save buttons in Android")
	public void i_verify_Close_and_Save_buttons_in_Android() throws Exception {
		try {
			preferencesPage.verifyChangeAccountOrderButtons();
			reportPass("Verified the buttons displayed Close and Save");
		} catch (Exception e) {
			reportFail("Unable to verify the buttons close and save displayed " + e);
			throw new Exception();
		}
	}

	@Then("I verify a account {string}")
	public void i_verify_a_account(String account) throws Exception {
		try {
			viewAccountsPage.verifyAccountPresent(jsonDataParser.getTestDataMap().get(account));
			reportPass("Selected the account " + jsonDataParser.getTestDataMap().get(account) + " and verified the transactions");
		} catch (Exception e) {
			reportFail("Unable to select account " + jsonDataParser.getTestDataMap().get(account) + " and verify the transactions " + e);
			throw new Exception();
		}
	}

	@Then("I change settings to {string}")
	public void i_change_settings_to(String label) throws Exception {
		try {
			preferencesPage.tapOnSetStartPageSetting(jsonDataParser.getTestDataMap().get(label));
			reportPass("Clicked on " + label + " option");
		} catch (NoSuchElementException e) {
			reportHardFail("Unable to click on " + label + "", true);
		}
	}

	@Then("I enter text {string} in Specific Date")
	public void i_enter_text_in_Specific_date(String text) throws Exception {
		try {
			filterPage.enterTextOnSpecificDate(text);
			reportPass("Unable to enter text in specific date");
		} catch (Exception e) {
			reportHardFail("Able to enter text on specific Date filter " + e);
		}
	}

}