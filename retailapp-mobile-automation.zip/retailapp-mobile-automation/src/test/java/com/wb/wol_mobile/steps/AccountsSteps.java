package com.wb.wol_mobile.steps;

import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.AccountsPage;
import com.wb.wol_mobile.pages.CommonPage;
import com.wb.wol_mobile.pages.FilterPage;
import com.wb.wol_mobile.pages.SettingsPage;
import com.wb.wol_mobile.pages.ViewAccountsPage;
import com.wb.wol_mobile.utilities.TestDataConstants;

import cucumber.api.java.en.Then;

public class AccountsSteps extends ObjectBase {

	AccountsPage accountsPage = new AccountsPage();
	FilterPage filterPage = new FilterPage();
	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	SettingsPage settingsPage = new SettingsPage();
	CommonPage commonPage = new CommonPage();

	@Then("^I see account summary page$")
	public void i_see_account_summary_page() throws Exception {
		if (accountsPage.verifyAccountsPage()) {
			reportPass("User is able to see the accounts text in accounts summary page");
		} else {
			reportFail("User is unable to see the accounts text in accounts summary page");
		}
	}

	@Then("I Tap on iCon of the Account Box")
	public void i_Tap_on_iCon_of_the_Account_Box() {
		try {
			accountsPage.clickOptionsButton();
			reportPass("User is to click on OptionsButton ");
		} catch (Exception e) {
			reportFail("User is unable to click on OptionsButton..." + e);
		}
	}

	@Then("^I Need to verify see Account Details on the screen$")
	public void i_Need_to_verify_see_Account_Details_on_the_screen() throws Exception {
		try {
			accountsPage.verifyAccountDetailsScreen();
			reportPass("User is able to see the accounts deatils on the screen");
		} catch (Exception e) {
			reportFail("User is unable to see the accounts deatils on the screen " + e);
		}
	}

	@Then("I Tap on account {string} options icon")
	public void i_Tap_on_account_options_icon(String account) {
		try {
			accountsPage.clickAccountOptionsButton(testDataMap.get(account));
			reportPass("User clicked on OptionsButton ");
		} catch (Exception e) {
			reportFail("User is unable to click on OptionsButton..." + e);
		}
	}

	@Then("^I Need to verify see Account Details on the screen for LOC loan account$")
	public void i_Need_to_verify_see_Account_Details_on_the_screen_for_LOC_loan_account() throws Exception {
		try {
			accountsPage.verifyAccountDetailsScreenLOCAccount();
			reportPass("User is able to see the LOC loan accounts deatils on the screen");
		} catch (Exception e) {
			reportFail("User is unable to see the LOC loan accounts deatils on the screen "+e);
		}
	}

	@Then("^I Need to verify see Account Details on the screen for Other than LOC accounts$")
	public void i_Need_to_verify_see_Account_Details_on_the_screen_for_Other_than_LOC_accounts() throws Exception {
		try {
			accountsPage.verifyAccountDetailsScreenOtherLOCAccount();
			reportPass("User is able to see Other than LOC accounts deatils on the screen");
		} catch (Exception e) {
			reportFail("User is unable to see Other than LOC accounts deatils on the screen "+e);
		}
	}

	@Then("^I Need to verify see Account Details on the screen for Credit Card account$")
	public void i_Need_to_verify_see_Account_Details_on_the_screen_for_Credit_Card_account() throws Exception {
		try {
			accountsPage.verifyAccountDetailsScreenCreditCardAccount();
			reportPass("User is able to see the Credit Card accounts deatils on the screen");
		} catch (Exception e) {
			reportFail("User is unable to see the Credit Card accounts deatils on the screen "+e);
		}
	}

	@Then("^I Need to verify see Account Details on the screen for CD account$")
	public void i_Need_to_verify_see_Account_Details_on_the_screen_for_CD_account() throws Exception {
		try {
			accountsPage.verifyAccountDetailsScreenCDAccount();
			reportPass("User is able to see the CD accounts deatils on the screen");
		} catch (Exception e) {
			reportFail("User is unable to see the CD accounts deatils on the screen "+e);
		}
	}

	@Then("I Need to verify error message displayed as {string} for Android and {string} for iOS")
	public void i_Need_to_verify_error_message_displayed_as_for_Android_and_for_iOS(String android, String ios) {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				viewAccountsPage.verifyErrorMessageNoResults(android);
			} else {
				if (filterPage.verifyAmountErrorMessage(ios)) {
					filterPage.clickOnClear();
					filterPage.clickOnDone();
					waits.staticWait(5);
					reportPass("amount error message is displayed successfully");
				} else {
					reportFail("amount error is not displayed or Unable to verify Error messsage");
				}
			}
		} catch (Exception e) {
			reportHardFail("Unable to verify the amount error message", true);
		}
	}

	@Then("I click on any account to edit nickname for IM account")
	public void i_click_on_any_account_to_edit_nickname_for_IM_account() throws Exception {
		try {
			settingsPage.tapOnAnyIMAccount();
			reportPass("Tapped on IM account");
		} catch (Exception e) {
			reportFail("Unable to tap on IM account " + e);
			throw new Exception();
		}
	}

	@Then("I click on any account to edit nickname for {string} account")
	public void i_click_on_any_account_to_edit_nickname_for_account(String account) throws Exception {
		try {
			settingsPage.tapOnAnyAccount(testDataMap.get(account));
			reportPass("Tapped on IM account");
		} catch (Exception e) {
			reportFail("Unable to tap on IM account " + e);
			throw new Exception();
		}
	}

	@Then("I update the nickname with max length and tap save")
	public void i_update_the_nickname_with_max_length_and_tap_save() throws Exception {
		try {
			settingsPage.updateNickNameMaxLength();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))
				appiumDriver.navigate().back();
			reportPass("NickName updated with max length");
		} catch (Exception e) {
			reportFail("Unable to update nickname with max length " + e);
			throw new Exception();
		}
	}

	@Then("I update the nickname with max length and tap Cancel\\/Close")
	public void i_update_the_nickname_with_max_length_and_tap_cancel_close() throws Exception {
		try {
			settingsPage.updateNickNameMaxLengthCancelClose();
			reportPass("Nickname updated and clicked on close button");
		} catch (Exception e) {
			reportFail("Unable to update nickname and to click on close button " + e);
			throw new Exception();
		}
	}

	@Then("I verify the account nickname is not updated")
	public void i_verify_the_account_nickname_is_not_updated() throws Exception {
		try {
			if (settingsPage.verifyAccountNickNameNotUpdated()) {
				reportPass("NickName did not updated with max length when clicked on cancel/close");
			} else
				reportHardFail("Nickname is updated with max length after clicked on close/cancel button", true);
		} catch (Exception e) {
			throw new Exception();
		}
	}

	@Then("I navigate back to {string} Screen")
	public void i_navigate_back_to_Screen(String title) throws Exception {
		try {
			commonPage.navigateToPage(title);
			reportPass("Navigated to page screen " + title);
		} catch (Exception e) {
			reportFail("Unable to navigate to " + title + " " + e);
			throw new Exception();
		}
	}

	@Then("I verify in View Accounts Screen whether nickname is upated")
	public void i_verify_in_View_Accounts_Screen_whether_nickname_is_upated() throws Exception {
		try {
			settingsPage.verifyAccountNickNameUpdated();
			reportPass("Verified account nick name updated");
		} catch (Exception e) {
			reportHardFail("Unable to verified updated nick name", true);
		}
	}

	@Then("I update the nickname with previous updated nickname")
	public void i_update_the_nickname_with_previous_updated_nickname() {
		try {
			settingsPage.updateExistingNickNameMaxLength();
			reportPass("NickName updated with max length");
		} catch (Exception e) {
			reportHardFail("Unable to update nickname with max length ", true);
		}
	}

	@Then("I click on {string}")
	public void i_click_on(String account) {
		String accountName = testDataMap.get(account);
		try {
			commonPage.clickAccount(accountName);
			reportPass("Clicked on account " + accountName);
		} catch (Exception e) {
			reportHardFail("Unable to click on account " + accountName + "" + e);
		}
	}

	@Then("I verify account {string} is on top of accounts list")
	public void i_verify_account_is_on_top_of_accounts_list(String account) {
		String accountName = testDataMap.get(account);
		try {
			viewAccountsPage.verifyAccountIsOnTop(accountName);
			reportPass("Account is on top of accounts list " + accountName);
		} catch (Exception e) {
			reportHardFail("Account is not on top of accounts list " + accountName, true);
		}
	}
}
