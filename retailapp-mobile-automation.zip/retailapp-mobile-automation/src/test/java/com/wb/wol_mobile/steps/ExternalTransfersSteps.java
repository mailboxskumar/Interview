package com.wb.wol_mobile.steps;

import java.util.List;

import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.ExternalTransfersPage;
import com.wb.wol_mobile.pages.TransfersPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExternalTransfersSteps extends ObjectBase {
	ExternalTransfersPage externalTransfersPage = new ExternalTransfersPage();
	TransfersPage transfersPage = new TransfersPage();

	List<String> toAccountsDisplayed;
	List<String> fromAccountsDisplayed;

	@Then("I click on Non-Webster Transfers option")
	public void i_click_on_Non_Webster_Transfers_option() {
		try {
			externalTransfersPage.clickNonWebsterTransferOption();
			reportPass("Clicked on Non webster transfers option", true);
		} catch (Exception e) {
			reportHardFail("Unable to click on Non webster transfers option", true);
		}
	}

	@Then("I click on Transfer Funds")
	public void i_click_on_Transfer_Funds() {
		try {
			externalTransfersPage.clickOnTransferFunds();
			reportPass("Clicked on Transfer Funds button", true);
		} catch (Exception e) {
			reportFail("Unable to click on Transfer Funds button", true);
		}
	}

	@Then("I click on Transfer Funds to verify Error Message")
	public void i_click_on_Transfer_Funds_to_verify_error_message() {
		try {
			externalTransfersPage.verifyErrorMessageClickingTransferFunds();
			reportPass("Clicked on Transfer Funds button to verify error message", true);
		} catch (Exception e) {
			reportHardFail("Unable to click on Transfer Funds button to verify error message", true);
		}
	}

	@Then("I click on From drop down")
	public void i_click_on_From_drop_down() {
		try {
			externalTransfersPage.clickOnFromDropDown();
			fromAccountsDisplayed = externalTransfersPage.getAccountsDisplayed();
			reportPass("Clicked on From drop down", true);
		} catch (Exception e) {
			reportHardFail("Unable to click on From drop down", true);
		}
	}

	@Then("I click on To drop down")
	public void i_click_on_to_drop_down() {
		try {
			externalTransfersPage.clickOnToDropDown();
			reportPass("Clicked on To drop down", true);
		} catch (Exception e) {
			reportHardFail("Unable to click on To drop down", true);
		}
	}

	@Then("I verify format of external and internal accounts in the From drop down")
	public void i_verify_format_of_external_and_internal_accounts_in_the_From_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the external and internal accounts format in From drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the external and internal accounts format in From drop down ", true);
		}
	}

	@Then("I verify format of external and internal accounts in the To drop down")
	public void i_verify_format_of_external_and_internal_accounts_in_the_To_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the external and internal accounts format in To drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the external and internal accounts format in To drop down ", true);
		}
	}

	@Then("I verify Balances format of external accounts in the From drop down")
	public void i_verify_Balances_format_of_external_accounts_in_the_From_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the external accounts balances format in From drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the external accounts balances format in From drop down ", true);
		}
	}

	@Then("I verify External accounts in the From drop down")
	public void i_verify_External_accounts_in_the_From_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the external accounts displayed in From drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the external accounts displayed in From drop down ", true);
		}
	}

	@Then("I verify External accounts in the To drop down")
	public void i_verify_External_accounts_in_the_To_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the external accounts displayed in To drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the external accounts displayed in To drop down ", true);
		}
	}

	@Then("I verify Balances format of internal accounts in the From drop down")
	public void i_verify_Balances_format_of_internal_accounts_in_the_From_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the internal accounts balances format in From drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the internal accounts balances format in From drop down ", true);
		}
	}

	@Then("I verify Balances format of external accounts in the To drop down")
	public void i_verify_Balances_format_of_external_accounts_in_the_To_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the external accounts balances format in To drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the external accounts balances format in To drop down ", true);
		}
	}

	@Then("I verify Balances format of internal accounts in the To drop down")
	public void i_verify_Balances_format_of_internal_accounts_in_the_To_drop_down() {
		try {
			externalTransfersPage.verifyExternalInternalAccountsFormat();
			reportPass("Verified the internal accounts balances format in To drop down ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the internal accounts balances format in To drop down ", true);
		}
	}

	@Then("I select any From account")
	public void i_select_any_From_account() throws Exception {
		try {
			externalTransfersPage.clickOnAccount();
			reportPass("Clicked on account");
		} catch (Exception e) {
			reportFail("unable to click on account" + e);
		}
	}

	@Then("I select any account")
	public void i_select_any_account() throws Exception {
		try {
			externalTransfersPage.clickOnAccount();
			reportPass("Clicked on account");
		} catch (Exception e) {
			reportFail("unable to click on account" + e);
		}
	}

	@Then("I select Internal account in From drop down")
	public void i_select_Internal_account_in_From_drop_down() {
		try {
			externalTransfersPage.clickOnInternalAccount();
			reportPass("Clicked on inernal account in From drop down");
		} catch (Exception e) {
			reportFail("unable to click on internal account in From drop down " + e);
		}
	}

	@Then("I select external account in From drop down")
	public void i_select_external_account_in_From_drop_down() {
		try {
			externalTransfersPage.clickOnExternalAccount();
			reportPass("Clicked on external account in From drop down");
		} catch (Exception e) {
			reportFail("unable to click on external account in From drop down " + e);
		}
	}

	@Then("I verify Error message displayed {string}")
	public void i_verify_Error_message_displayed(String errorMessage) throws Exception {
		try {
			externalTransfersPage.verifyErrorMessage(jsonDataParser.getTestDataMap().get(errorMessage));
			reportPass("Error message displayed and verified " + errorMessage);
		} catch (Exception e) {
			reportHardFail("unable to verify the error message as " + errorMessage + " " + e);
		}
	}
	
	@Then("I verify Duplicate Error message displayed {string}")
	public void i_verify_Duplicate_Error_message_displayed(String duplicateErrorMessage) throws Exception {
			if (externalTransfersPage.verifyDuplicateErrorMessage(jsonDataParser.getTestDataMap().get(duplicateErrorMessage)))
			reportPass("Duplicate Error message displayed and verified " + duplicateErrorMessage);
			else 
			reportHardFail("unable to verify the duplicate error message as " + duplicateErrorMessage );
	}

	@Then("I click on To drop down to verify the internal accounts")
	public void i_click_on_To_drop_down_to_verify_the_internal_accounts() {
		try {
			externalTransfersPage.clickOnToDropDown();
			toAccountsDisplayed = externalTransfersPage.getAccountsDisplayed();
			reportPass("Verified and fetched the Internal accounts in To drop down", true);
		} catch (Exception e) {
			reportFail("Unable to get the Internal accounts", true);
		}
	}

	@Then("I verify the accounts order displayed with External first followed by Internal accounts")
	public void i_verify_the_accounts_order_displayed_with_External_followed_by_Internal_accounts() {
		try {
			externalTransfersPage.verifyAccountsOrderExtAndInt(fromAccountsDisplayed, toAccountsDisplayed);
			reportPass("Accounts order verified with External accounts first followed by Internal accounts ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the accounts display order", true);
		}
	}

	@Then("I verify the External Transfers History Description")
	public void i_verify_the_External_Transfers_History_Description() throws Exception {
		if (externalTransfersPage.verifyExternalTransfersHistory())
			reportPass("Verified external transfers history description like From (...1234) To (...1234)", true);
		else
			reportHardFail("Unable to verify external transfers history description like From (...1234) To (...1234)",
					true);
	}

	@Then("I click on the {string} external transfer")
	public void i_click_on_the_external_transfer(String status) {
		try {
			externalTransfersPage.clickOnTransfer(jsonDataParser.getTestDataMap().get(status));
			reportPass("Clicked on " + status + " external transfer ", true);
		} catch (Exception e) {
			reportHardFail("Unable to click on " + status + " external transfer", true);
		}
	}

	@Then("I verify the external transfer details")
	public void i_verify_the_external_transfer_details() {
		try {
			externalTransfersPage.verifyTransferDetailsPage();
			reportPass("Verified the External Transfer Details page ", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify the External Transfer Details page ", true);
		}
	}

	@Then("I verify for {string} Transfer from transfers history or schedule the transfer")
	public void i_verify_for_Transfer_from_transfers_history_or_schedule_the_transfer(String status) {
		try {
			externalTransfersPage.verifyTransferDisplayed(jsonDataParser.getTestDataMap().get(status));
			reportPass("Verifed " + status + " transfer in external transfer history", true);
		} catch (Exception e) {
			reportHardFail("Unable to verify " + status + " transfer in external transfer history", true);
		}
	}

	@Then("I schedule the transfer between External account to Internal account")
	public void i_schedule_the_transfer_between_External_account_to_Internal_account() {
		try {
			externalTransfersPage.scheduledTransferExternalInternal();
			reportPass("Scheduled transfer between External to Internal account");
		} catch (Exception e) {
			reportHardFail("Unable to schedule transfer between External to Internal account", true);
		}
	}

	@Then("I schedule the transfer between Internal account to External account")
	public void i_schedule_the_transfer_between_Internal_account_to_External_account() {
		try {
			externalTransfersPage.scheduledTransferInternalExternal();
			reportPass("Scheduled transfer between Internal to External account");
		} catch (Exception e) {
			reportHardFail("Unable to schedule transfer between Internal to External account", true);
		}
	}

	@Then("I click on Cancel button for Scheduled transfer")
	public void i_click_on_Cancel_button_for_Scheduled_transfer() {
		try {
			externalTransfersPage.clickCancelTransfer();
			reportPass("Clicked on Cancel button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Cancel button", true);
		}
	}

	@Then("I click on Confirm to Cancel transfer")
	public void i_click_on_Confirm_to_Cancel_transfer() {
		try {
			externalTransfersPage.clickOnConfirm();
			reportPass("Clicked on Confirm button");
		} catch (Exception e) {
			reportHardFail("Unable to click on confirm button", true);
		}
	}

	@Then("I click on Confirm")
	public void i_click_on_Confirm() {
		try {
			externalTransfersPage.clickConfirmTransfer();
			reportPass("Clicked on Confirm button");
		} catch (Exception e) {
			reportHardFail("Unable to click on confirm button", true);
		}
	}

	@Then("I click on {string} options menu")
	public void i_click_on_options_menu(String status) {
		try {
			externalTransfersPage.clickOnMoreOptions(jsonDataParser.getTestDataMap().get(status));
			reportPass("Clicked on " + status + " option menu");
		} catch (Exception e) {
			reportHardFail("Unable to click on " + status + " option menu", true);
		}
	}

	@Then("I click on Cancel Transfer from options menu")
	public void i_click_on_Cancel_Transfer_from_options_menu() {
		try {
			externalTransfersPage.clickOnCancelTranferMenu();
			reportPass("Clicked on Cancel Transfer option in menu");
		} catch (Exception e) {
			reportHardFail("Unable to click Cancel Transfer option in menu", true);
		}
	}

	@Then("I verify Snack bar {string}")
	public void i_verify_Snack_bar(String message) {
		if (externalTransfersPage.verifyPopUpDisplayed(jsonDataParser.getTestDataMap().get(message)))
			reportPass("Verified " + message + " is displayed");
		else
			reportHardFail("Unable to verify the " + message + " popup message", true);
	}

	@When("I select External Checking account {string}")
	public void i_select_External_Checking_account(String account) {
		try {
			externalTransfersPage.clickOnAccount(jsonDataParser.getTestDataMap().get(account));
			reportPass("Selected the external checking account as " + account);
		} catch (Exception e) {
			reportHardFail("Unable to select the external checking account ", true);
		}
	}

	@Then("I select Internal Checking account {string}")
	public void i_select_Internal_Checking_account(String account) {
		try {
			externalTransfersPage.clickOnAccount(jsonDataParser.getTestDataMap().get(account));
			reportPass("Selected the internal checking account as " + account);
		} catch (Exception e) {
			reportHardFail("Unable to select the internal checking account ", true);
		}
	}

	@Then("I enter amount {string} in amount field")
	public void i_enter_amount_in_amount_field(String amount) {
		try {
			externalTransfersPage.enterAmount(jsonDataParser.getTestDataMap().get(amount));
			reportPass("Entered the amount into amount field as " + amount);
		} catch (Exception e) {
			reportHardFail("Unable to enter the amount in the amount field", true);
		}
	}

	@Then("I select the frequency {string}")
	public void i_select_the_frequency(String frequency) {
		try {
			externalTransfersPage.selectFrequency((jsonDataParser.getTestDataMap().get(frequency)));
			reportPass("Selectd the frequency as " + frequency);
		} catch (Exception e) {
			reportHardFail("Unable to select the frequency as " + frequency + " ", true);
		}
	}

	@Then("I select the Delivery Date")
	public void i_select_the_Delivery_Date() {
		try {
			externalTransfersPage.selectFutureSubmissionDate();
			reportPass("Selected the Delivery Date");
		} catch (Exception e) {
			reportHardFail("Unable to select delivery date", true);
		}
	}

	@Then("I click on submit button to and verify the details")
	public void i_click_on_submit_button_to_and_verify_the_details() {
		try {
			externalTransfersPage.clickSubmitTransfer();
			reportPass("Submitted the transfer and verified the details");
		} catch (Exception e) {
			reportHardFail("Unable to verify the details after submitted", true);
		}
	}

	@Then("I verify the details that are submitted like Amount {string}, From {string}, To {string}, Frequency {string}, Date")
	public void i_verify_the_details_that_are_submitted_like_Amount_From_To_Frequency_Number_of_Transfers_Date(
			String amount, String from, String to, String frequency) {
		try {
			externalTransfersPage.verifySubmittedDetails(jsonDataParser.getTestDataMap().get(amount),
					jsonDataParser.getTestDataMap().get(from), jsonDataParser.getTestDataMap().get(to),
					jsonDataParser.getTestDataMap().get(frequency));
			reportPass("Verified the create transfer submitted details");
		} catch (Exception e) {
			reportFail("Unable to verify the submitted details for create transfer");
		}
	}

}
