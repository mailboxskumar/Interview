package com.wb.wol_mobile.steps;

import org.testng.Assert;

import com.wb.java_af.appium.MobileActions;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.TransfersPage;
import com.wb.wol_mobile.utilities.TestDataConstants;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransfersSteps extends ObjectBase {
	TransfersPage transfersPage = new TransfersPage();
	MobileActions mobileactions;

	@When("^I click on Transfer Funds Module$")
	public void i_click_on_Transfer_Funds_Module() throws Exception {
		try {
			transfersPage.verifyTransfersModule();
			transfersPage.clickTransfersModule();
			reportPass("Succesfully clicked on Transfers Module");
		} catch (Exception e) {
			reportFail("unable to click on Transfers Module" + e);
			throw new Exception();
		}
	}

	@Then("^I click on TRANSFER FUNDS$")
	public void i_click_on_TRANSFER_FUNDS() throws Exception {
		try {
			transfersPage.clickTransferFunds();
			reportPass("Successfully clicked on Transfer Funds");
		} catch (Exception e) {
			reportFail("unable to click on Transfer Funds" + e);
			throw new Exception();
		}
	}

	@Then("^I click on Only TRANSFER FUNDS$")
	public void i_click_on_Only_TRANSFER_FUNDS() throws Exception {
		try {
			transfersPage.clickOnlyTransferFunds();
			reportPass("Successfully clicked on Transfer Funds");
		} catch (Exception e) {
			reportFail("unable to click on Transfer Funds" + e);
			throw new Exception();
		}
	}

	@Then("^I click on Confirm button$")
	public void i_click_on_Confirm_button() throws Exception {
		try {
			transfersPage.clickConfirmButton();
			reportPass("Successfully clicked on Confirm button");
		} catch (Exception e) {
			reportFail("unable to click on Confirm button " + e);
			throw new Exception();
		}

	}

	@Then("^I click on only Confirm button$")
	public void i_click_on_only_Confirm_button() throws Exception {
		try {
			transfersPage.clickOnlyConfirmButton();
			reportPass("Successfully clicked on Confirm buton");
		} catch (Exception e) {
			reportFail("unable to click on Confirm buton " + e);
			throw new Exception();
		}

	}

	@Then("^I enter Transfer From$")
	public void i_enter_Transfer_From() throws Exception {
		try {
			transfersPage.clickTransfersFromText();
			transfersPage.clickOnFromAccount();
			reportPass("Successfully entered Transfer From");
		} catch (Exception e) {
			reportFail("unable to enter Transfer From" + e);
			throw new Exception();
		}
	}

	@Then("^I click on View Details$")
	public void i_click_on_View_Details() throws Exception {
		try {
			transfersPage.clickViewDetailsButton();
			reportPass("Succesfully clicked on View Details");
		} catch (Exception e) {
			reportFail("unable to click on View Details" + e);
			throw new Exception();
		}
	}

	@Then("I click on Cancel Transfer button")
	public void i_click_on_Cancel_Transfer_button() throws Exception {
		try {
			transfersPage.clickCancelTransfer();
			reportPass("Succesfully clicked on Cancel Transfer");
		} catch (Exception e) {
			reportFail("unable to click on Cancel Transfer" + e);
			throw new Exception();
		}
	}

	@Then("^I click on Completed transfer from transaction history displayed$")
	public void i_click_on_Completed_transfer_from_transaction_history_displayed() throws Exception {
		try {
			transfersPage.clickOnTransferHistoryCompleted();
			reportPass("Successfully clicked on Completed Transfer History");
		} catch (Exception e) {
			reportFail("unable to select completed Transfer History" + e);
			throw new Exception();
		}
	}

	@Then("^I enter Transfer to and Amount \"([^\"]*)\"$")
	public void i_enter_Transfer_to_and_Amount(String Amount) throws Exception {
		try {
			reportInfo("In Create Transfer screen");
			transfersPage.clickTextTransfersTo();
			transfersPage.clickOnToAccount();
			transfersPage.enterAmount(Amount);
			reportPass("Successfully entered the payeeno, amount and verified and clicked on done label");
		} catch (Exception e) {
			reportFail("unable to enter payeeno, amount and verify & clicked on done label " + e);
			throw new Exception();
		}
	}

	@Then("^I enter Specified Transfer to and Amount \"([^\"]*)\"$")
	public void i_enter_Specified_Transfer_to_and_Amount(String Amount) throws Exception {
		try {
			reportInfo("In Create Transfer screen");
			transfersPage.clickTextTransfersTo();
			transfersPage.clickOnSpecifiedToAccount();
			transfersPage.enterAmount(Amount);
			transfersPage.clickDoneButton();
			reportPass("Successfully entered the Specified To payeeno, amount and verified and clicked on done label");
		} catch (Exception e) {
			reportFail("unable to enter Specified To payeeno, amount and verify & clicked on done label" + e);
			throw new Exception();
		}
	}

	@Then("^I enter Transfer From and Amount \"([^\"]*)\"$")
	public void i_enter_Transfer_From_and_Amount(String Amount) throws Exception {
		try {
			reportInfo("In Create Transfer screen");
			transfersPage.clickTransfersFromText();
			transfersPage.clickTransfersFromList();
			transfersPage.enterAmount(Amount);
			reportPass("Successfully entered the payeeno, amount and verified and clicked on done label");
		} catch (Exception e) {
			reportFail("unable to enter payeeno, amount and verify & clicked on done label" + e);
			throw new Exception();
		}
	}

	@Then("^I enter Memo \"([^\"]*)\"$")
	public void i_enter_Memo(String Value) throws Exception {

		try {
			transfersPage.enterMemo(Value);
			transfersPage.clickReturnButton();
			reportPass("Successfully entered Text at Memo field");
		} catch (Exception e) {
			reportFail("unable to enter Text at Memo field" + e);
			throw new Exception();
		}
	}

	@Then("^I click on specified transfer from transaction history$")
	public void i_click_on_specified_transfer_from_transaction_history() throws Exception {
		try {
			transfersPage.clickOnTransferHistorySpecified();
			reportPass("Succesfully clicked on specified transfer");
		} catch (Exception e) {
			reportFail("unable to click on specified transfer" + e);
			throw new Exception();
		}
	}

	@Then("^I should see Transfer details page$")
	public void i_should_see_Transfer_details_page() throws Exception {
		try {
			transfersPage.verifyTextTransferDetails();
			reportPass("Successfully verified Transfer Details");
		} catch (Exception e) {
			reportHardFail("unable to verify Transfer Details" + e);
		}
	}

	@Then("I should see Transfers are not supported error message for Android {string} iOS {string}")
	public void i_should_see_Transfers_are_not_supported_error_message_for_Android_iOS(String android, String iOS)
			throws Exception {
		try {
			transfersPage.verifyNotSupportedErrorMessage(android, iOS);
			reportPass("Successfully verified Not Supported Error Message ");
		} catch (Exception e) {
			reportFail("unable to verify Not Supported Error Message " + e);
			throw new Exception();
		}
	}

	@Then("^I should see Transfer funds view only error message \"([^\"]*)\"$")
	public void error_message_displayed(String errorMessage) throws Exception {
		try {
			transfersPage.verifyErrorMessageViewOnlyAccount(errorMessage);
			reportPass("Error message displayed in Transfer fund view only account " + errorMessage);
		} catch (Exception e) {
			reportFail("Error message is not displayed at view only account" + e);
			throw new Exception();
		}
	}

	@Then("I see success message {string}")
	public void i_see_success_message(String string) {
		try {
			transfersPage.verifySuccessMessage(string);
			reportPass(" Transfer success message is displayed");
		} catch (Exception e) {
			reportFail("Not displayed Transfer success message " + e);
		}
	}

	@Then("^I should see Transfer funds equal amount error message \"([^\"]*)\"$")
	public void i_should_see_Transfer_funds_equal_amount_error_message(String errorMessage) throws Exception {
		try {
			transfersPage.verifyEqualAmountErrorMessage(errorMessage);
			reportPass("Error message displayed while providing equal amount " + errorMessage);
		} catch (Exception e) {
			reportFail("Error message is not displayed while providing equal amount " + e);
			throw new Exception();
		}
	}

	@Then("^I should see Transfer funds less amount error message \"([^\"]*)\"$")
	public void i_should_see_Transfer_funds_less_amount_error_message(String errorMessage) throws Exception {
		try {
			transfersPage.verifyLessAmountErrorMessage(errorMessage);
			reportPass("Error message displayed while providing less amount " + errorMessage);
		} catch (Exception e) {
			reportFail("Error message is not displayed while proving less amount " + e);
			throw new Exception();
		}
	}

	@Then("I should see Exceed Available error message {string}")
	public void i_should_see_Exceed_Available_error_message(String exceedMessage) throws Exception {
		try {
			transfersPage.verifyExceedErrorMessage(exceedMessage);
			reportPass("Error message displayed while providing excess amount " + exceedMessage);
		} catch (Exception e) {
			reportFail("Error message is not displayed while providing excess amount " + e);
			throw new Exception();
		}
	}

	@Then("I should see Amount zero error message {string}")
	public void i_should_see_Amount_zero_error_message(String zeroErrorMessage) throws Exception {
		try {
			transfersPage.verifyZeroErrorMessage(zeroErrorMessage);
			reportPass("Error message displayed while providing zero amount " + zeroErrorMessage);
		} catch (Exception e) {
			reportFail("Error message is not displayed while providing zero amount " + e);
			throw new Exception();
		}
	}

	@Then("^I should see Transfer canceled message \"([^\"]*)\"$")
	public void i_should_see_Transfer_canceled_message(String cancelMessage) throws Exception {
		try {
			transfersPage.verifyCancelSuccessMessage(cancelMessage);
			reportPass("PopUp cancel message displayed " + cancelMessage);
		} catch (Exception e) {
			reportFail("PopUp cancel message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("I should see To and From error message \"([^\"]*)\"$")
	public void i_should_see_To_and_From_error_message(String tonfromMessage) throws Exception {
		try {
			transfersPage.verifyToAndFromMessage(tonfromMessage);
			reportPass("ToandFrom message displayed " + tonfromMessage);
		} catch (Exception e) {
			reportFail("ToandFrom message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("I should see more than one snack bar message \"([^\"]*)\"$")
	public void i_should_see_more_than_one_snack_bar_message(String snackBarMessage) throws Exception {
		try {
			transfersPage.verifyMoreThanOneMessage(snackBarMessage);
			reportPass("MoreThanOne message displayed" + snackBarMessage);
		} catch (Exception e) {
			reportFail("MoreThanOne message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("I try to select Transfer From with CD account within Grace period \"([^\"]*)\"$")
	public void i_try_to_select_Transfer_From_with_CD_account_within_Grace_period(String inGrace) throws Exception {
		try {
			transfersPage.clickTransfersFromText();
			if (transfersPage.verifyWithinGraceCDAccount(inGrace))
				reportPass("Within Grace Period Account is selected for Transfer from and clicked" + inGrace);
			else {
				reportFail("No Account within grace period is available");
				Assert.fail();
			}
		} catch (Exception e) {
			reportFail("Unable to select Within Grace period Account at Transfer from " + e);
			throw new Exception();
		}
	}

	@Then("I try to select Transfer From with Mortagage Account greater than lakh {string}")
	public void i_try_to_select_Transfer_From_with_Mortagage_Account_greater_than_lakh(String moreThanLakh)
			throws Exception {
		try {
			transfersPage.clickTransfersFromText();
			if (transfersPage.verifyMoreThanLakhAccount(moreThanLakh))
				reportPass("More than one lakh Account is selected for Transfer from and clicked" + moreThanLakh);
			else {
				reportFail("No Account with more than one lakh is available");
				Assert.fail();
			}
		} catch (Exception e) {
			reportFail("Unable to select Account with more than one lakh at Transfer from " + e);
			throw new Exception();
		}
	}

	@Then("I try to select Transfer From with NA account \"([^\"]*)\"$")
	public void i_try_to_select_Transfer_From_with_NA_account(String naAccount) throws Exception {
		try {
			transfersPage.clickTransfersFromText();
			if (transfersPage.verifyNAAccount(naAccount))
				reportPass("NA Account is not displayed in the from list " + naAccount);
			else {
				reportFail("NA Account is displayed in from list");
				Assert.fail();
			}
		} catch (Exception e) {
			reportFail("NA Account is found in from list " + e);
			throw new Exception();
		}
	}
	
	@Then("I try to select Transfer To with NA account \"([^\"]*)\"$")
	public void i_try_to_select_Transfer_To_with_NA_account(String naAccount) throws Exception {
			transfersPage.clickTextTransfersTo();
			if (transfersPage.verifyNAAccount(naAccount))
				reportPass("NA Account is not displayed in the To list " + naAccount);
			else 
				reportHardFail("NA Account is displayed in To list");
		}


	@Then("I try to select Transfer To with CD account outside Grace period \"([^\"]*)\"$")
	public void i_try_to_select_Transfer_To_with_CD_account_outSide_Grace_period(String outGrace) throws Exception {
			transfersPage.clickTextTransfersTo();
			if (transfersPage.verifyOutsideGraceCDAccount(outGrace))
				reportPass("Outside Grace Period Account displayed in Transfer To " + outGrace);
			else {
				reportHardFail("No Account outside grace period CD account is available");
			}
	}

	@When("I click on back button")
	public void i_click_on_back_button() {
		try {
			transfersPage.clickOnBack();
			reportPass("Navigated to back ");
		} catch (Exception e) {
			reportFail("Not navigated to back " + e);
		}
	}

	@When("I click on OK buton")
	public void i_click_on_OK_buton() {
		try {
			transfersPage.clickOkButon();
			reportPass("Successfully clicked on Ok button");
		} catch (Exception e) {
			reportFail("Can't able to click OK button" + e);
		}
	}

	@Then("^I should see Missing Amount error message \"([^\"]*)\"$")
	public void i_should_see_Missing_Amount_error_message(String errorMessage) throws Exception {
		try {
			transfersPage.verifyErrorMessageMissingAmount(errorMessage);
			reportPass("Error message displayed in Transfer funds page " + errorMessage);
		} catch (Exception e) {
			reportFail("Error message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("^I verify transfer details screen$")
	public void i_verify_transfer_details_Screen() throws Exception {
		try {
			transfersPage.verifyTransferDetailsScreen();
			reportPass("Successfully verified Transfer Details Screen");
		} catch (Exception e) {
			LogUtility.logInfo("--->Invalid Transfer Details");
			reportFail("unable to verify Transfer Details screen " + e);
		}
	}

	@Then("^I verify transfer details screen for Transact$")
	public void i_verify_transfer_details_Screen_for_Transact() throws Exception {

		try {
			transfersPage.verifyTransferDetailsScreenTransact();
			reportPass("Successfully verified Transfer Details Screen for Transact User");
		} catch (Exception e) {
			LogUtility.logInfo("--->Invalid Transfer Details Transact screen");
			reportFail("unable to verify Transfer Details screen for Transact User " + e);
		}
	}

	@Then("I verify Transfers fund page is open")
	public void i_verify_Transfers_fund_page_is_open() throws Exception {
		try {
			transfersPage.verifyTransferPageDisplayed();
			reportPass("Verified the create transfer fund page is displayed");
		} catch (Exception e) {
			reportFail("Unable to verify the create transfer page is displayed " + e);
			throw new Exception();
		}
	}

	@When("I tap on Calendar")
	public void i_tap_on_Calendar() throws Exception {
		try {
			transfersPage.tapOnCalender();
			reportPass("Verified Calendar is opened by tapping");
		} catch (Exception e) {
			reportFail("Unable to verify that calendar is opened " + e);
			throw new Exception();
		}
	}

	@When("I am trying to select the past date and App should not able to select any past dates")
	public void i_am_trying_to_select_the_past_date_and_App_should_not_able_to_select_any_past_dates()
			throws Exception {
		try {
			transfersPage.selectPastDate();
			reportPass("Verified Calendar is not selecting past dates");
		} catch (Exception e) {
			reportFail("Unable to verify that calendar is not selecting past dates" + e);
			throw new Exception();
		}
	}

	@Then("I enter Transfer To")
	public void i_enter_Transfer_To() throws Exception {
		try {
			transfersPage.clickTextTransfersTo();
			transfersPage.clickOnToAccount();
			reportPass("Clicked on To amount");
		} catch (Exception e) {
			reportFail("Unable to click on To amount " + e);
			throw new Exception();
		}
	}

	@Then("I enter the amount that is greater than the amount of Pay account")
	public void i_enter_the_amount_that_is_greater_than_the_amount_of_Pay_account() throws Exception {
		try {
			transfersPage.enterAmountGreaterThanPayFrom();
			reportPass("Amount entered greater than pay account");
		} catch (Exception e) {
			reportFail("Amount is not entered " + e);
			throw new Exception();
		}
	}

	@Then("I select the future date for transfer")
	public void i_select_the_future_date_for_transfer() throws Exception {
		try {
			transfersPage.selectFutureDate();
			reportPass("Selected the future date");
		} catch (Exception e) {
			reportFail("Unable to select the future date " + e);
			throw new Exception();
		}
	}

	@Then("^I should see Transfer executed pop up message \"([^\"]*)\"$")
	public void i_should_see_Transfer_executed_pop_up_message(String popUpMessage) throws Exception {
		try {
			transfersPage.verifyTransferExecutedPopUp(popUpMessage);
			reportPass("PopUp message displayed " + popUpMessage);
		} catch (Exception e) {
			reportFail("PopUp message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("I wait for system to Timeout and error message {string}")
	public void i_wait_for_system_to_Timeout_and_error_message(String timeOutMessage) throws Exception {
		try {
			transfersPage.verifyTransferTimeOutMessage(timeOutMessage);
			reportPass("PopUp message displayed " + timeOutMessage);
		} catch (Exception e) {
			reportFail("PopUp message is not displayed " + e);
			throw new Exception();
		}

	}

	@Then("I should see Transfer more error popup message {string}")
	public void i_should_see_Transfer_more_error_popup_message(String maximumAmount) throws Exception {
		try {
			transfersPage.verifyTransferMaximumAmount(maximumAmount);
			reportPass("PopUp message displayed " + maximumAmount);
		} catch (Exception e) {
			reportFail("PopUp message is not displayed " + e);
			throw new Exception();
		}
	}

	@Then("I veirfy the Invalid accounts if any")
	public void i_veirfy_the_Invalid_accounts_if_any() throws Exception {
		try {
			transfersPage.verifyInvalidAccounts();
			reportPass("Verified Invalid accounts balances if any");
		} catch (Exception e) {
			reportFail("Unable to verify the invalid accounts balances " + e);
			throw new Exception();
		}
	}

	@Then("I veirfy the Invalid accounts like CD account")
	public void i_veirfy_the_Invalid_accounts_like_CD_account() throws Exception {
		try {
			transfersPage.verifyInvalidCDAccounts();
			reportPass("Verified Invalid accounts balances like CD");
		} catch (Exception e) {
			reportFail("Unable to verify the invalid accounts balances like CD " + e);
			throw new Exception();
		}
	}

	@Then("I verify the accounts to transfer funds From and To")
	public void i_verify_the_accounts_to_transfer_funds_From_and_To() throws Exception {
		try {
			transfersPage.getFromToAccounts();
			reportPass("Verified valid accounts balances if any");
		} catch (Exception e) {
			reportFail("Unable to verify the valid accounts balances " + e);
			throw new Exception();
		}
	}

	@Then("I Click on From Field")
	public void i_Click_on_From_Field() throws Exception {
		try {
			transfersPage.clickTransfersFromText();
			reportPass("Clicked on From field ");
		} catch (Exception e) {
			reportFail("Unable to click on From field " + e);
			throw new Exception();
		}
	}

	@Then("I select From account to transfer")
	public void i_select_From_account_to_transfer() throws Exception {
		try {
			transfersPage.clickFromAccountBalance();
			reportPass("Selected From account to transfer ");
		} catch (Exception e) {
			reportFail("Unable to select account in From account field " + e);
			throw new Exception();
		}
	}

	@Then("I Click on To Field")
	public void i_Click_on_To_Field() throws Exception {
		try {
			transfersPage.clickTextTransfersTo();
			reportPass("Clicked on To field ");
		} catch (Exception e) {
			reportFail("Unable to click on To field " + e);
			throw new Exception();
		}
	}

	@Then("I select To account to recieve")
	public void i_select_To_account_to_recieve() throws Exception {
		try {
			transfersPage.clickToAccountBalance();
			reportPass("Selected To account to transfer ");
		} catch (Exception e) {
			reportFail("Unable to select account in To account field " + e);
			throw new Exception();
		}
	}

	@Then("I enter Amount {string}")
	public void i_enter_Amount(String amount) throws Exception {
		try {
			transfersPage.enterAmount(testDataMap.get(amount));
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				transfersPage.clickDoneButton();
			}
			reportPass("Entered amount to transfer " + amount);
		} catch (Exception e) {
			reportFail("Unable to enter amount " + e);
			throw new Exception();
		}
	}

	@Then("I verify the Invalid accounts are displayed or not")
	public void i_verify_the_Invalid_accounts_are_displayed_or_not() throws Exception {
		try {
			transfersPage.verifyInvalidBalances();
			reportPass("Verified the Invalid Balances");
		} catch (Exception e) {
			reportFail("Unable to verify the invalid balances displayed or not " + e);
			throw new Exception();
		}
	}

	@Then("I click on Ok button if iOS")
	public void i_click_on_Ok_button_if_iOS() throws Exception {
		try {
			transfersPage.clickOkPopup();
			reportPass("Clicked on OK button");
		} catch (Exception e) {
			reportFail("Unable to click on OK button " + e);
			throw new Exception();
		}
	}

	@Then("I click on OK button")
	public void i_click_on_OK_button() throws Exception {
		try {
			transfersPage.clickOkButton();
			reportPass("Clicked on OK button");
		} catch (Exception e) {
			reportFail("Unable to click on OK button " + e);
			throw new Exception();
		}
	}

	@Then("I navigated back to View Accounts Page to verify the balances")
	public void i_navigated_back_to_View_Accounts_Page_to_verify_the_balances() throws Exception {
		try {
			transfersPage.navigateBack();
			reportPass("Navigated to view accounts page");
		} catch (Exception e) {
			reportFail("Unable to navigate view accounts page " + e);
			throw new Exception();
		}
	}

	@Then("I verify Transfer Funds page")
	public void i_verify_Transfer_Funds_page() {
		try {
			transfersPage.verifyTransferFundsScreen();
			reportPass("Successfully verified Transfer Funds Screen");
		} catch (Exception e) {
			reportFail("unable to verify Transfer Funds Screen" + e);
		}
	}

	@Then("I verify No results at Transfer history")
	public void i_verify_No_results_at_Transfer_history() {
		try {
			transfersPage.verifyNoItems();
			reportPass("Successfully verified No Items Found at Transfer History ");
		} catch (Exception e) {
			reportFail("unable to verify No Items Found at Transfer History " + e);
		}
	}

	@Then("I verify CREATE TRANSFER page")
	public void i_verify_CREATE_TRANSFER_page() {
		try {
			transfersPage.verifyCreateTransferScreen();
			reportPass("Successfully verified Create Transfer Screen");
		} catch (Exception e) {
			reportFail("Unable to verify Create Transfer Screen" + e);
		}
	}

	@Then("I Verify Transfer History for completed transfers")
	public void i_Verify_Transfer_History_for_completed_transfers() throws Exception {
		try {
			if (transfersPage.verifyTransfersCompleted())
				reportPass("Successfully verified Transfer History for view only user");
			else {
				reportHardFail("Unable to verify Transfer History for view only user");
			}
		} catch (Exception e) {
			reportFail("Unable to verify Transfer History for view only user" + e);
			throw new Exception();
		}
	}

	@Then("I click on Transfer History for completed transfers")
	public void i_click_on_Transfer_History_for_completed_transfers() throws Exception {
		try {
			if (transfersPage.clickTransfersCompleted())
				reportPass("Successfully clicked on Transfer History completed ");
			else {
				reportHardFail("Unable to click Transfer History completed ");
			}
		} catch (Exception e) {
			reportFail("Unable to click Transfer History completed " + e);
			throw new Exception();
		}
	}

	@Then("I click on Transfer History for pending transfers")
	public void i_click_on_Transfer_History_for_pending_transfers() throws Exception {
		try {
			if (transfersPage.clickTransfersPending())
				reportPass("Successfully clicked on Transfer History pending ");
			else {
				reportFail("Unable to click Transfer History pending  ");
				Assert.fail();
			}
		} catch (Exception e) {
			reportFail("Unable to click Transfer History pending " + e);
			throw new Exception();
		}
	}

	@Then("I verify the balances should reflect")
	public void i_verify_the_balances_should_reflect() throws Exception {
		try {
			transfersPage.verifyFromAccountBalancesReflect();
			reportPass("Verified the balances are reflected");
		} catch (Exception e) {
			reportFail("Unable to verify the balances are reflected or not " + e);
			throw new Exception();
		}
	}

	@Then("I verify the Invalid accounts like CD are displayed or not")
	public void i_verify_the_Invalid_accounts_like_CD_are_displayed_or_not() throws Exception {
		try {
			transfersPage.verifyInvalidAccountsCD();
			reportPass("Verified the Invalid accounts like CD are not displayed");
		} catch (Exception e) {
			reportFail("Unable to verify the Invalid accounts like CD displayed or not " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Submit Transfer Page will be displayed with selected amount, transfer date, From and To, Memo$")
	public void i_verify_Submit_Transfer_Page_will_be_displayed_with_selected_amount_transfer_date_From_and_To_Memo()
			throws Exception {
		try {
			transfersPage.verifyTransferPageAfterSubmit();
			reportPass("Successfully verified Submit transfer page Details Screen");
		} catch (Exception e) {
			reportFail("can't able to verify Submit transfer page Details screen " + e);
			throw new Exception();
		}
	}

	@Then("I select the present date to transfer")
	public void i_select_the_present_date_to_transfer() throws Exception {
		try {
			transfersPage.presentDateSelectedToTransfer();
			reportPass("Selected the date to transfer");
		} catch (Exception e) {
			reportFail("Unable to Select the date to transfer " + e);
			throw new Exception();
		}
	}

	@When("^I click on View Accounts Module$")
	public void i_click_on_View_Accounts_Module() throws Exception {
		try {
			transfersPage.verifyViewAccountsModule();
			transfersPage.clickViewAccountsModule();
			reportPass("Succesfully clicked on View Accounts Module");
		} catch (Exception e) {
			reportFail("unable to click on View Accounts  Module" + e);
			throw new Exception();
		}
	}

	@Then("I capture the available amounts for the accounts")
	public void i_capture_the_available_amounts_for_the_accounts() throws Exception {
		try {
			transfersPage.getFromToAccounts();
			reportPass("Verified valid accounts balances if any");
		} catch (Exception e) {
			reportHardFail("Unable to verify the valid accounts balances " + e);
		}
	}

	@Then("I Need to verify balances for the both accounts")
	public void i_Need_to_verify_balances_for_the_both_accounts() throws Exception {
		try {
			transfersPage.verifyFromAccountBalancesReflect();
			reportPass("successfully verified the balances reflected after transfer done ");
		} catch (Exception e) {
			reportHardFail("Unable to verify the balances reflected after transfer done " + e);
		}
	}

	@Then("I select From account to transfer to another account for notification")
	public void I_select_From_account_to_transfer_to_another_account_for_notification() {
		try {
			transfersPage.clickTransfersFromText();
			transfersPage.selectFromAccountForNotification();
			reportPass("Clicked on From field to select the account to transfer amount");
		} catch (Exception e) {
			reportHardFail("Unable to click on From field to select the account to transfer amount", true);
		}
	}

	@Then("I select To account to receive for notification")
	public void I_select_To_account_to_receive_for_notification() {
		try {
			transfersPage.clickTextTransfersTo();
			transfersPage.selectToAccountForNotification();
			reportPass("Clicked on To field to select account");
		} catch (Exception e) {
			reportHardFail("Unable to click on To field for selecting account", true);
		}
	}
}
