package com.wb.wol_mobile.runners;

import com.wb.java_af.testbases.CucumberTestBase;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = { "src/test/resources/features/mobile" }, glue = "com.wb.wol_mobile.steps", plugin = {
		"pretty", "json:target/cucumber-reports/CucumberTestReport.json",
		"rerun:target/cucumber-reports/rerun.txt" }, monochrome = true, strict = false, dryRun = false)
public class MobileTestRunner extends CucumberTestBase {
}
