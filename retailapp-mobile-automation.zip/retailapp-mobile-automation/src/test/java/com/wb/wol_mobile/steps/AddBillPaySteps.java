package com.wb.wol_mobile.steps;

import java.util.List;

import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.AddBillPayeePage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddBillPaySteps extends ObjectBase {
	AddBillPayeePage addBillPayeePage = new AddBillPayeePage();

	@When("I Click on AddAPayee Button")
	public void i_Click_on_AddAPayee_Button() throws Exception {
		try {
			addBillPayeePage.clickOnAddPayeeButton();
			reportPass("Successfully clicked on Add A Payee Button");
		} catch (Exception e) {
			reportHardFail("Unable to click on Add A Payee Button " + e);
		}
	}

	@Then("I Enter payeeName {string} in the Payee field")
	public void i_Enter_payeeName_in_the_Payee_field(String string) throws Exception {
		try {
			addBillPayeePage.enterPayeeName(string);
			reportPass("payee name entered in the payee field");
		} catch (Exception e) {
			reportHardFail("Unable to enter the payee name in the payee field " + e);
		}
	}

	@Then("I Need to verify Browse AvailablePayees link is available under PayeeName")
	public void i_Need_to_verify_Browse_AvailablePayees_link_is_available_under_PayeeName() throws Exception {
		if (addBillPayeePage.verifyBrowseAvailablePayeesDisplayed()) {
			reportPass("Browse payees link is available under payee name");
		} else {
			reportHardFail("Browse payees link is not available under payee name ");
		}
	}

	@Then("I Click on BrowseAvailablePayees link")
	public void i_Click_on_BrowseAvailablePayees_link() throws Exception {
		try {
			addBillPayeePage.clickOnBrowseAvailablePayeeLink();
			reportPass("Successfully clicked on browse available payees link");
		} catch (Exception e) {
			reportHardFail("Can't able to click on browse available payees link " + e);
		}
	}

	@Then("I Verify All payees are displayed in alphabtical order")
	public void i_Verify_All_payees_are_displayed_in_alphabtical_order() throws Exception {
		try {
			List<String> payeeNames = addBillPayeePage.getPayees();
			addBillPayeePage.verifyPayeesDisplayInAlphabeticalOrder(payeeNames);
			reportPass("Verified successfully that all payees are displayed in alphabetical order");
		} catch (Exception e) {
			reportHardFail("Payees are not displayed in alphabetical order" + e);

		}
	}

	@When("I Click on popular link {string} and verify popular payees Displayed related to popular link")
	public void i_Click_on_popular_link_and_verify_popular_payees_Displayed_related_to_popular_link(String payeeChar)
			throws Exception {
		if (addBillPayeePage.verifyAndTapOnSelectedAlphabet(payeeChar)) {
			reportPass("Successfully clicked on popular link and verified all the payees are displayed as expected");
		} else {
			reportHardFail("Unable to click on popular link and payees are not verified");
		}

	}

	@Then("I verify and click popular link")
	public void i_verify_and_click_popular_link() throws Exception {
		try {
			addBillPayeePage.clickPopularLink();
			reportPass("Successfully verified and clicked on popular link");
		} catch (Exception e) {
			reportHardFail("Unable to verify and click on popular link" + e);

		}
	}

	@When("I select PayeeName {string} is available in the Payee List")
	public void i_select_PayeeName_is_available_in_the_Payee_List(String payeeName) {
		try {
			addBillPayeePage.selectPayeeName(testDataMap.get(payeeName));
			reportPass("Successfully clicked on selected Payee link");
		} catch (Exception e) {
			reportHardFail("Unable to click on selected Payee link");
		}
	}

	@Then("System should navigate to AddaNewPayee Page")
	public void system_should_navigate_to_AddaNewPayee_Page() throws Exception {
		if (addBillPayeePage.verifyAddAPayeesDisplayed()) {
			reportPass("Successfully navigated to AddaNewPayee Page");
		} else {
			reportHardFail("AddaNewPayee page is not available");

		}
	}

	@Then("I verify and click check box is enabled {string}")
	public void i_verify_and_click_check_box_is_enabled(String Status) throws Exception {
		try {
			addBillPayeePage.tapOnCheckBox(Status);
			reportPass("Successfully verified check box is enabled" + Status);
		} catch (Exception e) {
			reportHardFail("Unable to verify check box is enabled or not" + Status);

		}
	}

	@Then("ReEnter the same AccountNumber in ConfirmAccountNumberField")
	public void reenter_the_same_AccountNumber_in_ConfirmAccountNumberField() throws Exception {
		try {
			addBillPayeePage.enterAndReenterAccountNumber();
			reportPass("Successfully entered the confirm account number<---");
		} catch (Exception e) {
			reportHardFail("Unable to enter confirm account number<--");

		}
	}

	@When("I click to selectPayeeAddress Button")
	public void i_click_to_selectPayeeAddress_Button() throws Exception {
		try {
			addBillPayeePage.clickOnPayeeAddress();
			reportPass("Successfully clicked on selectPayeeAddress Button<---");
		} catch (Exception e) {
			reportHardFail("Unable to click on selectPayeeAddress Button<--");

		}
	}

	@Then("Enter Payee NickName in PayeeNickNameField")
	public void enter_Payee_NickName_in_PayeeNickNameField() throws Exception {
		try {
			addBillPayeePage.enterPayeeName();
			reportPass("Successfully entered  NickName in PayeeNickNameField<---");
		} catch (Exception e) {
			reportHardFail("Failed to enter NickName in PayeeNickNameField<--");

		}
	}

	@Then("I Verify view on shortlist? enabled yes {string}")
	public void i_Verify_view_on_shortlist_enabled_yes(String Status) throws Exception {
		try {
			addBillPayeePage.selectPayeeShortList(Status);
			reportPass("Successfully verified that shortlist payee is enabled<---");
		} catch (Exception e) {
			reportHardFail("Unable to verify shortlist payee is enabled<--");

		}
	}

	@Then("I Need to select valid Address Under Payee Address {string}")
	public void i_Need_to_select_valid_Address_Under_Payee_Address(String value) throws Exception {
		try {
			addBillPayeePage.tapOnPayeeAddress(value);
			reportPass("Successfully selected valid Address" + value);
		} catch (Exception e) {
			reportHardFail("Unable to select valid address" + value);

		}
	}

	@Then("I Click on Edit Button")
	public void i_Click_on_Edit_Button() throws Exception {
		try {
			addBillPayeePage.clickOnEdit();
			reportPass("Successfully clicked on Edit Button<---");
		} catch (Exception e) {
			reportHardFail("Unable to click on Edit button<--");

		}
	}

	@Then("I Click on Cancel Button")
	public void i_Click_on_Cancel_Button() throws Exception {
		try {
			addBillPayeePage.clickOnCancel();
			reportPass("Successfully click on Cancel button<---");
		} catch (Exception e) {
			reportHardFail("Unable to click on Cancel button<--");

		}
	}

	@When("I Click on Continue Button")
	public void i_Click_on_Continue_Button() throws Exception {
		try {
			addBillPayeePage.clickOnContinue();
			reportPass("Successfully clicked on continue button in NAo page<---");
		} catch (Exception e) {
			reportHardFail("Unable to click on continue button in NAO page<--");

		}
	}

	@Then("I Verify SelectPayee Page")
	public void i_Verify_SelectPayee_Page() throws Exception {
		if (addBillPayeePage.verifySelectPayeeAddressDisplayed()) {
			reportPass("Successfully verified SelectPayee Page ");
		} else {
			reportHardFail("SelectPayee Page is not found");

		}
	}

	@Then("I Verify Add a Payee Details in verification page")
	public void i_Verify_Add_a_Payee_Details_in_verification_page() throws Exception {
		if (addBillPayeePage.verifyAddANewPayeeDisplayed()) {
			reportPass("Add a New payee verification page is displayed ");
		} else {
			reportHardFail("Unable to verify Add a New payee verification page");
		}
	}

	@Then("I verify payee related fields are displayed are not")
	public void i_verify_payee_related_fields_are_displayed_are_not() throws Exception {
		try {
			addBillPayeePage.verifyAddANewPayeeDetails();
			reportPass("Successfully verified add a payee details page");
		} catch (Exception e) {
			reportHardFail("Unable to verify add a payee details page " + e);
		}
	}

	@Then("I Verify Edit Button is Displayed")
	public void i_Verify_Edit_Button_is_Displayed() throws Exception {
		if (addBillPayeePage.verifyEditButtonDisplayed()) {
			reportPass("Successfully verified Edit Button");
		} else {
			reportHardFail("Unable to verify Edit Button");
		}
	}

	@Then("I Verify Cancel Button is Displayed")
	public void i_Verify_Cancel_Button_is_Displayed() throws Exception {
		if (addBillPayeePage.verifyCancelButtonDisplayed()) {
			reportPass("Successfully verified Cancel Button");
		} else {
			reportHardFail("Unable to verify Cancel Button");
		}
	}

	@Then("I Verify {string} in AddaNewpayee confirmation page")
	public void i_Verify_in_AddaNewpayee_confirmation_page(String errorMessage) throws Exception {
		if (addBillPayeePage.verifyPayeeAdded(testDataMap.get(errorMessage))) {
			reportPass("Successfully verified text displayed in AddaNewpayee page" + errorMessage);
		} else {
			reportHardFail("Unable to verify text at AddaNewPayee Page" + errorMessage);
		}
	}

	@Then("I Enter Valid Personal Information as {string},{string},{string},{string},{string}")
	public void i_Enter_Valid_Personal_Information_as(String address1, String address2, String city, String state,
			String zipCode) {
		try {
			addBillPayeePage.enterPayeePersonalDetails(jsonDataParser.getTestDataMap().get(address1),
					jsonDataParser.getTestDataMap().get(address2), jsonDataParser.getTestDataMap().get(city),
					jsonDataParser.getTestDataMap().get(state), jsonDataParser.getTestDataMap().get(zipCode));
			reportPass("Successfully Entered valid personal information details");
		} catch (Exception e) {
			reportHardFail("Unable to enter personal information details", true);
		}
	}

	@Then("I verify payee confirmation Details are displayed or not")
	public void i_verify_payee_confirmation_Details_are_displayed_or_not() throws Exception {
		try {
			addBillPayeePage.verifyAddANewPayeeConfirmation();
			reportPass("Successfully verified the confirmation details page");
		} catch (Exception e) {
			reportHardFail("Unable to verify the confirmation details page ", true);
		}
	}

	@Then("I verify selected payee is displayed in the dropdown list or not")
	public void i_verify_selected_payee_is_displayed_in_the_dropdown_list_or_not() throws Exception {
		if (addBillPayeePage.verifySelectToPayeeIsDisplayed()) {
			reportPass("selected payee is displayed in the dropdown list<--");
		} else {
			reportHardFail("selected payee is not displayed in the dropdown list");

		}
	}

	@Then("I Pay from selected account is {string}")
	public void i_Pay_from_selected_account_is(String account) throws Exception {
		try {
			addBillPayeePage.payFromSelectedAccount(account);
			reportPass("Successfully Selected the account to pay bill " + account);
		} catch (Exception e) {
			reportHardFail("Unable to select the account to pay bill " + account);

		}
	}

	@Then("I Need to Check the disclosure as {string}")
	public void i_Need_to_Check_the_disclosure_as(String value) throws Exception {
		try {
			addBillPayeePage.selectDisclosureCheck(value);
			reportPass("Successufully verified the disclosure<---" + value);
		} catch (Exception e) {
			reportHardFail("Unable to verify the disclosure" + value);

		}
	}

}
