package com.wb.wol_mobile.steps;

import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.AccountsPage;
import com.wb.wol_mobile.pages.DepositsPage;
import com.wb.wol_mobile.pages.TransactionsHistoryPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DepositSteps extends ObjectBase {

	DepositsPage depositsPage = new DepositsPage();
	AccountsPage accountPage = new AccountsPage();
	TransactionsHistoryPage transactionsHistoryPage = new TransactionsHistoryPage();

	@When("I click on Deposit A Check Button")
	public void i_click_on_Deposit_A_Check_Button() throws Exception {
		try {
			depositsPage.clickOnMakeADeposit();
			reportPass("User clicked on the DepositACheck button");
		} catch (Exception e) {
			reportFail("can't able to click on DepositACheck button..." + e);
			throw new Exception();
		}
	}

	@When("I click on Deposit Checks")
	public void i_click_on_Deposit_Checks() throws Exception {
		try {
			depositsPage.clickOnDepositChecks();
			reportPass("User clicked on the Deposit Checks button");
		} catch (Exception e) {
			reportFail("can't able to click on Deposit Checks button " + e);
			throw new Exception();
		}
	}

	@Then("I see Terms and conditions page with Accept and Decline Buttons")
	public void i_see_Terms_and_conditions_page_with_Accept_and_Decline_Buttons() throws Exception {
		if (depositsPage.verifyTermsAndConditionsPage()) {
			reportPass("User is able to see the terms and conditions page with accept and decline buttons");
		} else {
			reportFail("can't able to see the terms and conditions page with accept and decline buttons ");
			throw new Exception();
		}
	}

	@When("I click on Decline Button in Terms and condtions Page")
	public void i_click_on_Decline_Button_in_Terms_and_condtions_Page() throws Exception {
		try {
			depositsPage.clickOnDeclineButton();
			reportPass("User clicked on Decline button");
		} catch (Exception e) {
			reportFail("User unable to click on Decline button " + e);
			throw new Exception();
		}

	}

	@Then("I Need to Verify Error Message as {string}")
	public void i_Need_to_Verify_Error_Message_as(String errorMessage) throws Exception {
		if (depositsPage.verifyTermsAndConditionsErrorMessage(testDataMap.get(errorMessage))) {
			reportPass("User is able to see the terms and conditions error message");
		} else {
			reportFail("User is unable to see the terms and conditions error message");
		}
	}

	@When("I Clicked on OK Button")
	public void i_Clicked_on_OK_Button() throws Exception {
		try {
			depositsPage.clickOnOkButton();
			reportPass("User clicked on Ok button");
		} catch (Exception e) {
			reportFail("User unable to click on Decline button " + e);
			throw new Exception();
		}
	}

	@Then("I See the check deposits screen and popup will not occur again")
	public void i_See_the_check_deposits_screen_and_popup_will_not_occur_again() throws Exception {
		if (depositsPage.verifyDepositChecksPage()) {
			reportPass("User is able verify check deposits page");
		} else {
			reportFail("User is unable to see verify check deposits page");
		}
	}

	@Then("I Need to see the View Accounts Page")
	public void i_Need_to_see_the_View_Accounts_Page() throws Exception {
		if (accountPage.verifyAccountsPage()) {
			reportPass("User is able to see the accounts text in accounts summary page");
		} else {
			reportFail("User is unable to see the accounts text in accounts summary page");
		}
	}

	@When("I click on Accept Button in Terms and condtions Page")
	public void i_click_on_Accept_Button_in_Terms_and_condtions_Page() throws Exception {
		try {
			depositsPage.clickOnAcceptButton();
			reportPass("User clicked on Accept button");
		} catch (Exception e) {
			reportFail("User unable to click on Accept button " + e);
			throw new Exception();
		}
	}

	@Then("I Entered ${string} in the amount field and kept the To Account Field blank")
	public void i_Entered_$_in_the_amount_field_and_kept_the_To_Account_Field_blank(String toAmount) throws Exception {
		try {
			depositsPage.enterAmount(toAmount);
			reportPass("User able to enter the amount in the field");
		} catch (Exception e) {
			reportFail("User Unable to enter the amount in the field" + e);
			throw new Exception();
		}
	}

	@Then("I Need to verify the Create Deposit screen should display")
	public void i_Need_to_verify_the_Create_Deposit_screen_should_display() throws Exception {
		if (depositsPage.verifyCreateDepositChecksPage()) {
			reportPass("User is able to see Create a deposit page");
		} else {
			reportFail("User is unable to see Create a deposit page");
		}
	}

	@Then("I Take a photo of front and back check and click on Submit Button")
	public void i_Take_a_photo_of_front_and_back_check_and_click_on_Submit_Button() throws Exception {
		try {
			depositsPage.captureFrontAndBackCheckImages();
			reportPass("User is able to take a photo of front and back check click on submit button");
		} catch (Exception e) {
			reportFail("User is unable to take a photo of front and back check click on submit button" + e);
		}
	}

	@Then("I Take a photo of  front check and click on Submit Button")
	public void i_Take_a_photo_of_front_check_and_click_on_Submit_Button() {
		try {
			depositsPage.captureFrontCheck();
			reportPass("User is able to take a photo of front  click on submit button");
		} catch (Exception e) {
			reportFail("User is unable to take a photo of front and back check click on submit button" + e);
		}
	}

	@Then("I Take a photo of  back check and click on Submit Button")
	public void i_Take_a_photo_of_back_check_and_click_on_Submit_Button() {
		try {
			depositsPage.captureBackCheck();
			reportPass("User is able to take a photo of front and back check click on submit button");
		} catch (Exception e) {
			reportFail("User is unable to take a photo of front and back check click on submit button" + e);
		}
	}

	@Then("I need to see error message as {string}")
	public void i_need_to_see_error_message_as(String errorMessage) throws Exception {
		if (depositsPage.verifyDailyLimitErrorMessage(testDataMap.get(errorMessage))) {
			reportPass("Verified account error message successfully");
		} else {
			reportFail("Unable to verify account error message as " + errorMessage);
		}
	}

	@Then("I need to see Account eligible error message as {string}")
	public void i_need_to_see_Account_eligible_error_message_as(String message) throws Exception {
		if (depositsPage.verifyAccountInEligibleErrorMessage(testDataMap.get(message))) {
			reportPass("Verified account error message successfully");
		} else {
			reportFail("Unable to verify account error message as " + message);
		}
	}

	@Then("I need to see greater error message as {string}")
	public void i_need_to_see_greater_error_message_as(String errorMessage) throws Exception {
		if (depositsPage.verifyGreaterAmountErrorMessage(testDataMap.get(errorMessage))) {
			reportPass("Verified account error message successfully");
		} else {
			reportFail("Unable to verify account error message as " + errorMessage);
		}
	}

	@Then("I need to see verifyAccountInEligibleErrorMessage as {string}")
	public void i_need_to_see_verifyAccountInEligibleErrorMessage_as(String errorMessage) throws Exception {
		if (depositsPage.verifyAccountInEligibleErrorMessage(testDataMap.get(errorMessage))) {
			reportPass("Verified account error message successfully");
		} else {
			reportFail("Unable to verify account error message as " + errorMessage);
		}
	}

	@Then("I need to see Back check error  message as {string}")
	public void i_need_to_see_Back_check_error_message_as(String backError) throws Exception {
		if (depositsPage.verifyBackErrorMessage(testDataMap.get(backError))) {
			reportPass("Verified account error message successfully");
		} else {
			reportFail("Unable to verify account back error message as " + backError);
		}
	}

	@Then("I need to see Front check error message as {string}")
	public void i_need_to_see_Front_check_error_message_as(String frontError) throws Exception {
		if (depositsPage.verifyFrontErrorMessage(testDataMap.get(frontError))) {
			reportPass("Verified account error message successfully");
		} else {
			reportFail("Unable to verify account front error message as" + frontError);
		}
	}

	@Then("System should Display LastFour Digits of AccountNumber with AccountName")
	public void system_should_Display_LastFour_Digits_of_AccountNumber_with_AccountName() throws Exception {
		if (depositsPage.verifyCheckDepositHistory()) {
			reportPass("Verified account transaction successfully");
		} else {
			reportFail("Unable to verify Deposit History along with the transaction details");
		}
	}

	@Then("I Click on any check Deposit History of an account")
	public void i_Click_on_any_check_Deposit_History_of_an_account() {
		try {
			depositsPage.clickOnAnyTransation();
			reportPass("User is able to click on the deposit history account");
		} catch (Exception e) {
			reportFail("User is unable to click on deposit history account " + e);
		}
	}

	@Then("System should Display Deposit Details Screen With label name as {string}")
	public void system_should_Display_Deposit_Details_Screen_With_label_name_as(String message) throws Exception {
		if (depositsPage.verifyDepositToLabel(message)) {
			reportPass("User is able Display Deposits Deatils screen");
		} else {
			reportFail("Unable to  Display Deposits Deatils screen");
		}
	}

	@Then("I Click on BackButton")
	public void i_Click_on_BackButton() {
		try {
			transactionsHistoryPage.clickOnBackButton();
			reportPass("User is able to click on the Back Button ");
		} catch (Exception e) {
			reportFail("User is unable to click on Back Button " + e);
		}
	}

	@Then("I Need to Select To Account")
	public void i_Need_to_Select_To_Account() {
		try {
			depositsPage.clickOnAnyDepositToAccount();
			reportPass("User is able to select an Account to deposit");
		} catch (Exception e) {
			reportFail("User is unable to select Account to deposit" + e);
		}
	}

	@Then("I Entered {string} in the amount field")
	public void i_Entered_in_the_amount_field(String toAmount) throws Exception {
		try {
			depositsPage.enterAmount(toAmount);
			reportPass("User able to enter the amount in the field");
		} catch (Exception e) {
			reportFail("User Unable to enter the amount in the field" + e);
			throw new Exception();
		}
	}

	@Then("System shoud not allow you to enter special characters in the field")
	public void system_shoud_not_allow_you_to_enter_special_characters_in_the_field() throws Exception {
		if (depositsPage.verifyAmountEntered()) {
			reportPass("Field is not accepting special chracters in the field");
		} else {
			reportFail("Field is accepting the special charcters in the field");
		}
	}

	@When("I Click on the cancel Button")
	public void i_Click_on_the_cancel_Button() {
		try {
			depositsPage.clickOnCancel();
			reportPass("User is able to click on the Cancel Button ");
		} catch (Exception e) {
			reportFail("User is unable to click on Cancel Button " + e);
		}
	}

	@Then("System should Display Deposits list view page")
	public void system_should_Display_Deposits_list_view_page() throws Exception {
		if (depositsPage.verifyDepositChecksPage()) {
			reportPass("User is able verify check deposits page");
		} else {
			reportFail("User is unable to see verify check deposits page");
		}
	}

	@When("I click on the context menu for a Deposit")
	public void i_click_on_the_context_menu_for_a_Deposit() {
		try {
			depositsPage.clickOnContextmenu();
			reportPass("User is able to click on the context menu ");
		} catch (Exception e) {
			reportFail("User is unable to click on context menu " + e);
		}
	}

	@Then("Error Message in Android  Device as {string}")
	public void error_Message_in_Android_Device_as(String errorMessage) throws Exception {
		if (depositsPage.verifyLoadingCameraErrorPopup(testDataMap.get(errorMessage))) {
			reportPass("User is able to verify camera loading error popup");
		} else {
			reportFail("User is unable to verify camera loading error popup");
		}

	}

	@Then("System should Display context menu page")
	public void system_should_Display_context_menu_page() throws Exception {
		if (depositsPage.verifyContextMenuPage()) {
			reportPass("User is able verify context Menu page");
		} else {
			reportFail("User is unable to see verify context Menu page");
		}
	}

	@Then("I Verify Allow Camera PopUp is Displayed And Click On Deny Button in Android")
	public void i_Verify_Allow_Camera_PopUp_is_Displayed_And_Click_On_Deny_Button_in_Android() throws Exception {
		if (depositsPage.verifyAllowCameraPopup()) {
			reportPass("User is able to clicked on Allow camera option in popup");
		} else {
			reportFail("User is unable to clicked on Allow camera option in popup");
		}
	}

	@Then("I click on check back")
	public void i_click_on_check_back() {
		try {
			depositsPage.captureBackCheck();
			reportPass("User is able to click on the back check ");
		} catch (Exception e) {
			reportFail("User is unable to click on back check " + e);
		}
	}

	@Then("I click on check Front")
	public void i_click_on_check_Front() {
		try {
			depositsPage.captureFrontCheck();
			reportPass("User is able to click on the Front check ");
		} catch (Exception e) {
			reportFail("User is unable to click on Front check " + e);
		}
	}

	@Then("I Verify Error Message in iOS as {string}")
	public void i_Verify_Error_Message_in_iOS_as(String errorMessage) throws Exception {
		if (depositsPage.verifyLoadingCameraErrorPopup(testDataMap.get(errorMessage))) {
			reportPass("User is able to verify camera loading error popup");
		} else {
			reportFail("User is unable to verify camera loading error popup");
		}
	}

	@Then("I Need to verify {string} account should be displayed in the dropDown list")
	public void i_Need_to_verify_account_should_be_displayed_in_the_dropDown_list(String message) throws Exception {
		if (depositsPage.verifyAccountInDropDownList(message)) {
			reportPass("Successfully Verified Account is displayed in the dropDown list");
		} else {
			reportFail("Unable to Verify Account is displayed in the dropDown list");
		}
	}

	@Then("^Deposits page is displayed$")
	public void deposits_page_is_displayed() throws Exception {
		try {
			depositsPage.verifyDepositsPageTitle();
			reportPass("Deposits Page is displayed");
		} catch (Exception e) {
			reportHardFail("Deposits Page not displayed after login " + e);
		}
	}

}
