package com.wb.wol_mobile.steps;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.LoginPage;
import com.wb.wol_mobile.pages.PreferencesPage;
import com.wb.wol_mobile.pages.SettingsPage;
import com.wb.wol_mobile.pages.ViewAccountsPage;
import com.wb.wol_mobile.testbases.RetailAppTestBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LogInLogOffSteps extends ObjectBase {

	PreferencesPage preferencesPage = new PreferencesPage();
	LoginPage loginPage = new LoginPage();
	SettingsPage settingsPage = new SettingsPage();
	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	RetailAppUtils retailAppUtils = new RetailAppUtils();

	@When("^I clicked on Enable Passcode Login$")
	public void i_clicked_on_Enable_Passcode_Login() throws Exception {
		try {
			preferencesPage.clickEnablePasscodeLogin();
			reportPass("Clicked on Enable Passcode Login");
		} catch (Exception e) {
			reportFail("Unable to click on Enable Passcode Login " + e);
			throw new Exception();
		}
	}

	@Then("^Popup should be displayed with \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" for iOS \"([^\"]*)\", \"([^\"]*)\"$")
	public void popup_should_be_displayed_with_for_iOS(String createNewPasscode, String enterPasscodeDigits,
			String cnfrmPasscodeDigits, String enterPasscodeiOS, String cnfrmPasscodeiOS) throws Exception {
		try {
			preferencesPage.verifyCreatePasscodePopup(createNewPasscode, enterPasscodeDigits, cnfrmPasscodeDigits,
					enterPasscodeiOS, cnfrmPasscodeiOS);
			reportPass("Displayed " + createNewPasscode + ", " + enterPasscodeDigits + ", " + cnfrmPasscodeDigits);
		} catch (Exception e) {
			reportFail("Unable to display the popup fields " + createNewPasscode + ", " + enterPasscodeDigits + ", "
					+ cnfrmPasscodeDigits + " " + e);
			throw new Exception();
		}
	}

	@When("^I enter new pin \"([^\"]*)\" and confirm pin \"([^\"]*)\"$")
	public void i_enter_new_pin_and_confirm_pin(String newPin, String confirmPin) throws Exception {
		try {
			preferencesPage.enterPasscode(jsonDataParser.getTestDataMap().get(newPin),
					jsonDataParser.getTestDataMap().get(confirmPin));
			reportPass("Entered passcode " + newPin + ", " + confirmPin);
		} catch (Exception e) {
			reportFail("Unable to enter the " + newPin + ", " + confirmPin + " " + e);
			throw new Exception();
		}
	}

	@Then("^Error should be displayed as \"([^\"]*)\"$")
	public void error_should_be_displayed_as(String errMessage) throws Exception {
		try {
			preferencesPage.validateErrMessageCommonPin(errMessage);
			reportPass("Verified the error message " + errMessage);
		} catch (Exception e) {
			reportFail("Unable to verify the error message " + errMessage + " " + e);
			throw new Exception();
		}
	}

	@Then("^Content should be displayed as \"([^\"]*)\"$")
	public void content_should_be_displayed_as(String content) throws Exception {
		try {
			preferencesPage.verifyPasscodeContent(jsonDataParser.getTestDataMap().get(content));
			reportPass("Verified the content displayed");
		} catch (Exception e) {
			reportFail("Unable to verify the content displayed" + e);
			throw new Exception();
		}
	}

	@When("^I Click on Accept option$")
	public void i_Click_on_Accept_option() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				preferencesPage.clickOnAccept();
			} else {
				preferencesPage.clickOnConfirm();
			}
			reportPass("Clicked on Accept button ");
		} catch (Exception e) {
			reportFail("Unable to click on accept button " + e);
			throw new Exception();
		}
	}

	@When("^I Click on Decline option$")
	public void i_Click_on_Decline_option() throws Exception {
		try {
			preferencesPage.clickOnDecline();
			reportPass("Clicked on Decline button");
		} catch (Exception e) {
			reportFail("Unable to click on accept button " + e);
			throw new Exception();
		}
	}

	@When("^I clicked on forgot passcode$")
	public void i_clicked_on_forgot_passcode() throws Exception {
		try {
			loginPage.clickOnForgotPasscode();
			reportPass("Clicked on forgot passcode");
		} catch (Exception e) {
			reportFail("Unable to click on forgot passcode " + e);
			throw new Exception();
		}
	}

	@Then("^I am in preferences screen$")
	public void i_am_in_preferences_screen() throws Exception {
		try {
			preferencesPage.verifyPreferencesPage();
			reportPass("Verified preferences page");
		} catch (Exception e) {
			reportFail("Unable to verify preferences page " + e);
			throw new Exception();
		}
	}

	@Then("^Alert displayed as \"([^\"]*)\"$")
	public void alert_displayed_as(String alertMsg) throws Exception {
		try {
			preferencesPage.validatePasscodeAlert(alertMsg);
			reportPass("Verified success alerts for setting the passcode");
		} catch (Exception e) {
			reportFail("Unable to verify the success alert " + e);
			throw new Exception();
		}
	}

	@When("^I logout from app verify passcode login screen$")
	public void i_logout_from_app_verify_passcode_login_screen() throws Exception {
		try {
			settingsPage.clickOnLogoutButton();
			reportPass("Successfully logged out from app ");
		} catch (Exception e) {
			reportFail("Unable to logout from app " + e);
			throw new Exception();
		}
	}

	@When("^Home Page displayed with Passcode Enabled$")
	public void home_Page_displayed_with_Passcode_Enabled() throws Exception {
		try {
			loginPage.verifyPasscodeViewDisplayed();
			reportPass("Passcode view is displayed");
		} catch (Exception e) {
			reportFail("Passcode view not displayed " + e);
			throw new Exception();
		}
	}

	@When("^I enter incorrect Passcode \"([^\"]*)\"$")
	public void i_enter_incorrect_Passcode(String passcode) throws Exception {
		try {
			loginPage.enterPasscode(passcode);
			reportPass("Entered wrong passcode ");
		} catch (Exception e) {
			reportFail("Unable to enter the passcode " + e);
			throw new Exception();
		}
	}

	@Then("^Error message for Passcode displayed as \"([^\"]*)\"$")
	public void error_message_for_Passcode_displayed_as(String passcodeError) throws Exception {
		try {
			loginPage.validateErrorMsgPasscode(passcodeError);
			loginPage.btnAlertOk.click();
			waits.staticWait(2);
			reportPass("Verified the passcode error ");
		} catch (Exception e) {
			reportFail("Unable to verify the error message " + e);
			throw new Exception();
		}
	}

	@Then("I verify Error message {string} for {string} and {string} for {string}")
	public void i_verify_Error_message_for_and_for(String errMsg1, String OS1, String errMsg2, String OS2)
			throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				loginPage.validateErrorMsgFieldBlank(errMsg1);
			} else {
				loginPage.validateErrorMsgFieldBlank(errMsg2);
				loginPage.clickOkButton();
			}
			reportPass("Verified the error message " + errMsg1);
		} catch (Exception e) {
			reportFail("Unable to verify the error message when username left blank " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Error message for personal user as \"([^\"]*)\"$")
	public void i_verify_Error_message_for_personal_user_as(String errMsgFirstTime) throws Exception {
		try {
			loginPage.validateErrorMsgFirstTime(jsonDataParser.getTestDataMap().get(errMsgFirstTime));
			reportPass("Verified the error message for first time login");
		} catch (Exception e) {
			reportFail("Unable to verify the error message for first time login " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Error message when Email notification bounce \"([^\"]*)\"$")
	public void i_verify_Error_message_when_Email_notification_bounce(String errMsgEmailNotification) throws Exception {
		try {
			loginPage.validateErrorMsgEmailNotifyBounce(errMsgEmailNotification);
			reportPass("Verified the error message for user when email notification bounce");
		} catch (Exception e) {
			reportFail("Unable to verify the error message for user when email notification bounce " + e);
			throw new Exception();
		}
	}

	@Then("I verify Error message for weblink user as \"([^\"]*)\"$")
	public void i_verify_Error_message_for_weblink_user_as(String errMsgWeblink) throws Exception {
		try {
			loginPage.validateErrorMsgWebLink(jsonDataParser.getTestDataMap().get(errMsgWeblink));
			reportPass("Verified the error message for first time login for Weblink User");
		} catch (Exception e) {
			reportFail("Unable to verify the error message for first time login for Weblink User " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Error message for inactive user as \"([^\"]*)\"$")
	public void i_verify_Error_message_for_inactive_user_as(String errMsgInactiveUser) throws Exception {
		try {
			loginPage.validateErrorMsgInactive(jsonDataParser.getTestDataMap().get(errMsgInactiveUser));
			reportPass("Verified the error message Inactive User");
		} catch (Exception e) {
			reportFail("Unable to verify the error message Inactive User " + e);
			throw new Exception();
		}
	}

	@When("^I click on link FIRST TIME LOGIN\\? TAP HERE$")
	public void i_click_on_link_FIRST_TIME_LOGIN_TAP_HERE() throws Exception {
		try {
			loginPage.clickOnFirstTimeLogin();
			reportPass("Clicked on First time login tap here button");
		} catch (Exception e) {
			reportFail("Clicked on First time login tap here button " + e);
			throw new Exception();
		}
	}

	@Then("^User should navigate to WOL site in mobile$")
	public void user_should_navigate_to_WOL_site_in_mobile() throws Exception {
		try {
			loginPage.verifyWOLPageMobile();
			reportPass("Page navigated to WOL in mobile");
		} catch (Exception e) {
			reportFail("Unable to verify the page navigated to WOL window " + e);
			throw new Exception();
		}
	}

	@When("^I click on Locations$")
	public void i_click_on_Locations() throws Exception {
		try {
			loginPage.clickOnLocations();
			reportPass("Clicked on Locations icon");
		} catch (Exception e) {
			reportFail("Unable to clicked on Locations icon " + e);
			throw new Exception();
		}
	}

	@Then("^Locations Page should be displayed$")
	public void locations_Page_should_be_displayed() throws Exception {
		try {
			loginPage.verifyLocationsPage();
			reportPass("Locations Page screen is displayed");
		} catch (Exception e) {
			reportFail("Locations Page screen is not displayed " + e);
			throw new Exception();
		}
	}

	/**
	 * Need to implement for location search in map for both Android and
	 * iOS @When("^I search for any location, System should search for location$")
	 * public void i_search_for_any_location_System_should_search_for_location()
	 * throws Exception { try {
	 * 
	 * reportPass("Searched for entered location"); } catch (Exception e) {
	 * reportFail("Unable to search for entered location " + e); throw new
	 * Exception(); } }
	 **/

	@When("^I verified the Legal Terms and Conditions content$")
	public void i_verified_the_Legal_Terms_and_Conditions_content() throws Exception {
		try {
			loginPage.verifyTermsAndConditionsContent();
			reportPass("Verified the Terms and Conditions content");
		} catch (Exception e) {
			reportFail("Unable to verify the content of Terms and Conditions " + e);
			throw new Exception();
		}
	}

	@When("^I click on Privacy Link$")
	public void i_click_on_Privacy_Link() throws Exception {
		try {
			loginPage.clickOnPrivacy();
			reportPass("Clicked on Privacy Link");
		} catch (Exception e) {
			reportFail("Unable to click on Privacy Link " + e);
			throw new Exception();
		}
	}

	@Then("^Privacy Opt Out Notice Page displayed$")
	public void privacy_Opt_Out_Notice_Page_displayed() throws Exception {
		try {
			loginPage.verifyPrivacyOptOutNoticePage();
			reportPass("Verified Privacy Opt Out Page is opened");
		} catch (Exception e) {
			reportFail("Unable to verify Privacy Opt Out Page is opened " + e);
			throw new Exception();
		}
	}

	@When("^I click on Help$")
	public void i_click_on_Help() throws Exception {
		try {
			loginPage.clickOnHelp();
			reportPass("Clicked on Help Page");
		} catch (Exception e) {
			reportFail("Unable to click on Help Page " + e);
			throw new Exception();
		}
	}

	@Then("^Help Page should be displayed$")
	public void help_Page_should_be_displayed() throws Exception {
		try {
			loginPage.verifyHelpPageDisplayed();
			reportPass("Verified the Help Page displayed");
		} catch (Exception e) {
			reportFail("Unable to verify the Help Page " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Contact Us phone number$")
	public void i_verify_Contact_Us_phone_number() throws Exception {
		try {
			loginPage.verifyContactUSPhNumber();
			reportPass("Verified the contact us phone number");
		} catch (Exception e) {
			reportFail("Unable to verify the contact us phone number " + e);
			throw new Exception();
		}
	}

	@When("^I click on Contact Us phone number popup should display$")
	public void i_click_on_Contact_Us_phone_number() throws Exception {
		try {
			loginPage.clickOnContactUs();
			reportPass("Clicked on Contact Us phone number");
		} catch (Exception e) {
			reportFail("Unable to click on Contact Us phone number " + e);
			throw new Exception();
		}
	}

	@Then("^I verify full site link is present$")
	public void i_verify_full_site_link_is_present() throws Exception {
		try {
			loginPage.verifyFullSiteLink();
			reportPass("Verified the full site link is present");
		} catch (Exception e) {
			reportFail("Unable to Verify the full site link is present " + e);
			throw new Exception();
		}
	}

	@When("^I click on link should display WebsterOnline$")
	public void i_click_on_link_should_display_WebsterOnline() throws Exception {
		try {
			loginPage.clickOnFullSite();
			reportPass("Clicked on full site link");
		} catch (Exception e) {
			reportFail("Unable to click on full site link " + e);
			throw new Exception();
		}
	}

	@When("^I launch application Passocde Login authentication should display else enable using \"([^\"]*)\", \"([^\"]*)\" with pin \"([^\"]*)\" and confirm Pin \"([^\"]*)\"$")
	public void i_launch_application_Passocde_Login_authentication_should_display_else_enable_using_with_pin_and_confirm_Pin(
			String userName, String password, String newPin, String cnfrmPin) throws Exception {
		try {
			loginPage.veirfyLoginPagePasscodeEnabled(RetailAppTestBase.envProps.getProperty(userName),
					RetailAppTestBase.envProps.getProperty(password), newPin, cnfrmPin);
			reportPass("Application launched with passcode enabled");
		} catch (Exception e) {
			reportFail("Application not launched with passcode enabled " + e);
			throw new Exception();
		}
	}

	@Then("^I enter Incorrect Passcode \"([^\"]*)\"$")
	public void i_enter_Incorrect_Passcode(String incorrectPasscode) throws Exception {
		String invalidPasscode = jsonDataParser.getTestDataMap().get(incorrectPasscode);
		try {
			loginPage.enterPasscode(invalidPasscode);
			reportPass("Entered Incorrect Passcode " + invalidPasscode);
		} catch (Exception e) {
			reportFail("Unable to enter the Incorrect Passcode " + e);
			throw new Exception();
		}
	}

	@Then("^I verify the \"([^\"]*)\"$")
	public void i_verify_the(String errorMessage) throws Exception {
		String errMsg = jsonDataParser.getTestDataMap().get(errorMessage);
		try {
			loginPage.validateErrorMsgPasscode(errMsg);
			loginPage.btnAlertOk.click();
			waits.staticWait(2);
			reportPass("Verified the error message " + errMsg);
		} catch (Exception e) {
			reportFail("Unable to verify the error message " + e);
			throw new Exception();
		}
	}

	@Then("^I verify the error message for third time \"([^\"]*)\"$")
	public void i_verify_the_error_message_for_third_time(String errorMessage) throws Exception {
		String errMsg = jsonDataParser.getTestDataMap().get(errorMessage);
		try {
			loginPage.validateErrorMsgPasscodeIncorrect(errMsg);
			loginPage.btnAlertOk.click();
			waits.staticWait(2);
			reportPass("Verified the error message " + errMsg);
		} catch (Exception e) {
			reportFail("Unable to verify the error message " + errMsg + " " + e);
			throw new Exception();
		}
	}

	@Then("^I verify Passcode Login Displayed$")
	public void i_verify_Passcode_Login_Displayed() throws Exception {
		try {
			preferencesPage.verifyPasscodeLoginButton();
			reportPass("Verified Passcode Login");
		} catch (Exception e) {
			reportFail("Unable to verify the Passcode Login " + e);
			throw new Exception();
		}
	}

	@Then("^Verification Question popup should displayed$")
	public void verification_Question_popup_should_displayed() throws Exception {
		try {
			loginPage.verifyQuestionPopup();
			reportPass("Verification Question popup displayed");
		} catch (Exception e) {
			reportFail("Verificaiton Question popup not displayed " + e);
			throw new Exception();
		}
	}

	@Then("^I enter answer the security question as \"([^\"]*)\"$")
	public void i_enter_answer_the_security_question_as(String answer) throws Exception {
		try {
			loginPage.enterAnswer(answer);
			reportPass("Answer entered into text field");
		} catch (Exception e) {
			reportFail("Answer not entered in text field " + e);
			throw new Exception();
		}
	}

	@Then("^I click Enter/Ok button$")
	public void i_click_Enter_Ok_button() throws Exception {
		try {
			loginPage.clickEnterOrOK();
			reportPass("--->Able to click on Enter/OK button<---");
		} catch (Exception e) {
			reportFail("--->Unable to click Enter/OK button " + e);
			throw new Exception();
		}
	}

	@Then("^Terms and Conditions page displayed$")
	public void terms_and_Conditions_page_displayed() throws Exception {
		if (loginPage.verifyTermsAndCondtions())
			reportPass("Verified the Terms and Conditions page is displayed");
		else
			reportFail("--->Unable to verify the Terms and Conditions page ");
	}

	@When("^I click on Decline button$")
	public void i_click_on_Decline_button() throws Exception {
		try {
			loginPage.acceptTermsAndConditions("decline");
			reportPass("Clicked on the Decline button");
		} catch (Exception e) {
			reportFail("--->Unable to click on the decline button " + e);
			throw new Exception();
		}
	}

	@When("^I click on Ok button$")
	public void i_click_on_Ok_button() throws Exception {
		try {
			loginPage.clickOkButton();
			reportPass("Clicked on the OK button");
		} catch (Exception e) {
			reportFail("--->Unable to click on the OK button " + e);
			throw new Exception();
		}
	}

	@Then("I enter {string} in the Security Question if displayed")
	public void i_enter_in_the_Security_Question_if_displayed(String answer) throws Exception {
		try {
			if (loginPage.verifySecurityQuestionDisplayed()) {
				loginPage.verifyQuestionPopup();
				loginPage.enterAnswer(jsonDataParser.getTestDataMap().get(answer));
				loginPage.clickEnterOrOK();
				reportPass("Answered the security question and clicked on OK button");
			}
		} catch (Exception e) {
			reportFail("Failed while entering the answer " + e);
			throw new Exception();
		}
	}

	@When("I disabled the Passcode")
	public void i_disabled_the_Passcode() throws Exception {
		try {
			preferencesPage.clickDisablePasscodeLogin();
			reportPass("Clicked on disabled Passcode Login");
		} catch (Exception e) {
			reportFail("Unable to click on disabled Passcode Login " + e);
			throw new Exception();
		}
	}

	@Then("Home Page is not displayed with Passcode Enabled")
	public void home_Page_is_not_displayed_with_Passcode_Enabled() throws Exception {
		try {
			loginPage.verifyPasscodeViewNotDisplayed();
			reportPass("Passcode view is not displayed");
		} catch (Exception e) {
			reportFail("Passcode view displayed " + e);
			throw new Exception();
		}
	}

	@When("I login into {string} device using same username {string} and password {string}")
	public void i_login_into_device_using_same_username_and_password(String device, String userName, String password) {
		try {
			LoginPage loginPageDriver = new LoginPage(RetailAppUtils.customAppiumDriver);
			loginPageDriver.verifyUserNameTextField();
			loginPageDriver.verifyPasswordTextField();
			loginPageDriver.logInWithUserNamePassword(userName, password);
			loginPageDriver.clickLogin();
			reportPass("Logged in using " + userName + " in another device " + device + "");
		} catch (Exception e) {
			reportFail("Unable to logIn into another device " + device + " due to " + e);
			e.printStackTrace();
			ConcurrentEngines.destroyCustomEngine();
		}
	}

	@When("^I logout from app verify passcode login screen in another device$")
	public void i_logout_from_app_verify_passcode_login_screen_in_another_device() throws Exception {
		SettingsPage settingsPageDriver = new SettingsPage(RetailAppUtils.customAppiumDriver);
		try {
			settingsPageDriver.clickOnLogoutCustomEngine();
			reportPass("Successfully logged out from app ");
		} catch (Exception e) {
			reportFail("Unable to logout from app " + e);
			ConcurrentEngines.destroyCustomEngine();
			throw new Exception();
		}
	}

	@When("^Home Page displayed with Passcode Enabled in another device$")
	public void home_Page_displayed_with_Passcode_Enabled_in_another_device() throws Exception {
		LoginPage loginPageDriver = new LoginPage(RetailAppUtils.customAppiumDriver);
		try {
			loginPageDriver.verifyPasscodeViewDisplayed();
			reportPass("Passcode view is displayed");
		} catch (Exception e) {
			reportFail("Passcode view not displayed " + e);
			ConcurrentEngines.destroyCustomEngine();
			throw new Exception();
		}
	}

	@When("I launch device android {string} and iOS {string}")
	public void i_launch_device_android_and_iOS(String androidDevice, String iosDevice) throws Exception {
		if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))
			retailAppUtils.launchAnotherMobileDevice(androidDevice);
		else
			retailAppUtils.launchAnotherMobileDevice(iosDevice);
		/**
		 * Have to wait for the app to launch or else script will fail due to no locator
		 * available
		 */
		ConcurrentEngines.getCustomEngine().getWait().staticWait(10);
	}

	@When("I login into another device using same username {string} and password {string}")
	public void i_login_into_another_device_using_same_username_and_password(String userName, String password) {
		try {
			LoginPage loginPageDriver = new LoginPage(RetailAppUtils.customAppiumDriver);
			loginPageDriver.verifyUserNameTextField();
			loginPageDriver.verifyPasswordTextField();
			loginPageDriver.logInWithUserNamePassword(userName, password);
			loginPageDriver.clickLogin();
			reportPass("Logged in using " + userName + " in another device ");
		} catch (Exception e) {
			reportFail("Unable to logIn into another device due to " + e);
			e.printStackTrace();
			ConcurrentEngines.destroyCustomEngine();
		}
	}

	@Then("I close the second device")
	public void i_close_the_second_device() {
		ConcurrentEngines.destroyCustomEngine();
	}

	@When("I enter primary user Passcode {string}")
	public void i_enter_primary_user_Passcode(String passcode) throws Exception {
		try {
			loginPage.enterPasscode(passcode);
			reportPass("Entered primary passcode ");
		} catch (Exception e) {
			reportFail("Unable to enter primary passcode " + e);
			throw new Exception();
		}
	}

	@When("I enter secondary user Passcode {string}")
	public void i_enter_secondary_user_Passcode(String passcode) throws Exception {
		try {
			loginPage.enterPasscode(passcode);
			reportPass("Entered secondary passcode ");
		} catch (Exception e) {
			reportFail("Unable to enter secondary passcode " + e);
			throw new Exception();
		}
	}

	@When("I click on Forgot Password")
	public void i_click_on_Forgot_Password() throws Exception {
		try {
			loginPage.clickForgotPassword();
			reportPass("Clicked on Forgot Password button");
		} catch (Exception e) {
			reportFail("Unable to click on Forgot Password " + e);
			throw new Exception();
		}
	}

	@Then("I verify Reset Password page is displayed")
	public void i_verify_Reset_Password_page_is_displayed() throws Exception {
		try {
			loginPage.verifyResetPasswordPage();
			reportPass("Verified the reset password page is displayed");
		} catch (Exception e) {
			reportFail("Unable to verify the reset password page is displayed " + e);
			throw new Exception();
		}
	}

	@When("I enter UserName {string} and click on continue button")
	public void i_enter_UserName_and_click_on_continue_button(String userName) throws Exception {
		try {
			loginPage.enterUserNameResetPasswordPage(RetailAppTestBase.envProps.getProperty(userName));
			loginPage.clickContinueResetPasswordPage();
			reportPass("Entered user name in reset password page");
		} catch (Exception e) {
			reportFail("Unable to enter the username and click continue button on reset password page " + e);
			throw new Exception();
		}
	}

	@Then("System should display challenge question")
	public void system_should_display_challenge_question() throws Exception {
		try {
			loginPage.verifyChallengeQuestionPage();
			reportPass("Verified the challenge question page");
		} catch (Exception e) {
			reportFail("Unable to verify the challenge question page " + e);
			throw new Exception();
		}
	}

	@When("I enter valid answer {string} and click on continue button")
	public void i_enter_valid_answer_and_click_on_continue_button(String answer) throws Exception {
		try {
			loginPage.enterChallengeQuestionAnswer(testDataMap.get(answer));
			loginPage.clickContinueResetPasswordPage();
			reportPass("Entered the challenge question answer");
		} catch (Exception e) {
			reportFail("Unable to enter the challenge question answer " + e);
			throw new Exception();
		}
	}

	@Then("Reset password confirmation page should be displayed")
	public void reset_password_confirmation_page_should_be_displayed() throws Exception {
		try {
			loginPage.verifyResetPasswordConfirmationPage();
			reportPass("Verified the reset password confirmation page");
		} catch (Exception e) {
			reportFail("Unable to verify the reset password confirmation page " + e);
			throw new Exception();
		}
	}

	@Then("^I enter Correct Passcode \"([^\"]*)\"$")
	public void i_enter_correct_Passcode(String correctPasscode) throws Exception {
		try {
			loginPage.enterPasscode(jsonDataParser.getTestDataMap().get(correctPasscode));
			reportPass("Entered Correct Passcode " + correctPasscode);
		} catch (Exception e) {
			reportFail("Unable to enter the Correct Passcode " + e);
			throw new Exception();
		}
	}

	@Then("If Verification Question popup is displayed then {string} the question")
	public void if_Verification_Question_popup_is_displayed_then_the_question(String answer) throws Exception {
		try {
			if (loginPage.verifyQuestionPopUpDisplayed()) {
				loginPage.verifyQuestionPopup();
				loginPage.enterAnswer(answer);
				loginPage.clickEnterOrOK();
			}
			reportPass("Verified the questionarie popup");
		} catch (Exception e) {
			reportFail("Unable to verify the questionarie popup " + e);
		}
	}

}