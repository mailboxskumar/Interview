package com.wb.wol_mobile.steps;

import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.pages.CommonPage;
import com.wb.wol_mobile.pages.TransactionsHistoryPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CommonSteps extends ObjectBase {

	TransactionsHistoryPage transactionHistory = new TransactionsHistoryPage();
	CommonPage commonPage = new CommonPage();

	@Given("I load testdata from: {string}, {string}")
	public void i_load_testdata_from(String fileName, String testCaseName) throws Exception {
		jsonDataParser.parseJsonTestData(fileName, testCaseName);
	}

	@Given("I load multiple testdata from: {string}, {string}, {string}")
	public void i_load_multiple_testdata_from(String fileName, String testCaseName, String testDataName)
			throws Exception {
		jsonDataParser.parseJsonTestData(fileName, testCaseName, testDataName);
	}

	@Given("I load Environment specific testdata from: {string}, {string}, {string}")
	public void i_load_Environment_specific_testdata_from(String fileName, String testCaseName, String environmentName)
			throws Exception {

		if (environmentName.equalsIgnoreCase("pom.xml"))
			environmentName = System.getProperty("environment");

		jsonDataParser.parseJsonTestDataByEnvironment(fileName, testCaseName, environmentName);
	}

	@Given("I load Environment specific multiple testdata from: {string}, {string}, {string}, {string}")
	public void i_load_Environment_specific_multiple_testdata_from(String fileName, String testCaseName,
			String environmentName, String testDataName) throws Exception {

		if (environmentName.equalsIgnoreCase("pom.xml"))
			environmentName = System.getProperty("environment");

		jsonDataParser.parseJsonTestDataByEnvironment(fileName, testCaseName, environmentName, testDataName);
	}

	@When("I Select Set StartPage as {string}")
	public void i_Select_Set_StartPage_as(String value) {
		try {
			transactionHistory.selectCheckBox(testDataMap.get(value));
			reportPass("User able Click on" + value + "Button");
		} catch (Exception e) {
			reportFail("User Unable to Click on the" + value + " Button" + e);
		}
	}

	@Then("I Need to Hard Close the application")
	public void i_Need_to_Hard_Close_the_application() {
		try {
			MobileActions.closeApplication();
			MobileActions.startApplication();
			reportPass("User able hard close and launch the app");
		} catch (Exception e) {
			reportFail("User Unable to hard close and launch the app" + e);
		}
	}
	
	@Then("I navigate back to Hamburger and click on it")
	public void I_navigate_back_to_Hamburger_and_click_on_it() {
		try {
			commonPage.clickOnHamburger();
			reportPass("User clicked on hamburger icon");
		} catch (Exception e) {
			reportHardFail("User Unable to click on hamburger icon " + e);
		}
	}
	
	@Then("I verify error message {string} displayed")
	public void i_verify_error_message_displayed(String errorMessage) {
		try {
			commonPage.verifyErrorMessageDisplayed(jsonDataParser.getTestDataMap().get(errorMessage));
			reportPass("Error Message verified");
		} catch (Exception e) {
			reportHardFail("Unable to verify the error message ", true);
		}
	}

	
}
