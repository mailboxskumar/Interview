package com.wb.wol_mobile.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.touch.offset.PointOption;

/**
 * @author spothula-adm
 *
 */
public class ManageAlertsPage extends ObjectBase {

	int count;
	private String selectAccount;
	MobileActions mobileActions = new MobileActions();

	public ManageAlertsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	@AndroidFindBy(xpath = "//*[@resourceid='com.malauzai.websterbank:id/btn_alerts']")
	@iOSFindBy(xpath = "//*[@label='Manage Alerts']")
	protected MobileElement txtManageAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='MANAGE ALERTS']")
	@iOSFindBy(xpath = "//*[@label=\"MANAGE ALERTS\"]")
	protected MobileElement titleManageAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Account Alerts']")
	@iOSFindBy(xpath = "//*[@label='Account Alerts']")
	@CacheLookup
	protected MobileElement txtAccountAlerts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='Select Account']")
	protected MobileElement titleSelectAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_info")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected List<RemoteWebElement> accountsListedCount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_info")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected MobileElement cellAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeNavigationBar/XCUIElementTypeStaticText")
	protected MobileElement titleAccountNameNavigationBar;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy()
	@iOSFindBy(xpath = "//*[@label='Close']")
	@CacheLookup
	protected MobileElement btnCloseNavBar;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Choose an account to configure alerts']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Choose an account to configure alerts']")
	@CacheLookup
	protected MobileElement lblNameConfigureAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='TEXT']")
	@iOSFindBy(xpath = "//*[@label='Phone']")
	@CacheLookup
	protected MobileElement iconText;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='EMAIL']")
	@iOSFindBy(xpath = "//*[@label=\"Email\"]")
	protected MobileElement iconEmail;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/configure_delivery_options_config_message")
	@iOSFindBy(xpath = "//*[@label='Enter the phone number(s) where you wish to receive text alerts']")
	@CacheLookup
	protected MobileElement lblEnterPhoneNumberMessage;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/configure_delivery_options_config_message")
	@iOSFindBy(xpath = "//*[@label='*Message and data rates may apply']")
	@CacheLookup
	protected MobileElement lblDataRatesApplyMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='(224) 623-2626']")
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Primary Phone Number']")
	@AndroidFindBy(xpath = "//*[@content-desc=\"Primary Phone Number\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value='Primary Phone Number']")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@label='Primary Phone Number']/XCUIElementTypeTextField[1]")
	protected MobileElement lblPrimaryPhoneNumber;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Secondary Phone Number']")
	@AndroidFindBy(xpath = "//*[@content-desc=\"Secondary Phone Number\"]")
	@iOSFindBy(xpath = "//*[@value='Secondary Phone Number']")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@label='Secondary Phone Number']")
	@CacheLookup
	protected MobileElement lblSecondaryPhoneNumber;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Editing Your Number']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Editing Your Number']")
	protected MobileElement txtEditingYourName;

	@iOSFindBy(xpath = "//*[@label=\"Continue\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='CONTINUE']")
	protected MobileElement btnContinue;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Switch[@text='Off']")
	@AndroidFindBy(xpath = "//android.widget.Switch[@text='OFF']")
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch[@value='0']")
	protected MobileElement swtToogleOFF;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/field_two_toggle")
	@iOSFindBy(xpath = "//*[@label=\"Secondary Phone Number\" and @value=\"0\"]")
	protected MobileElement swtSecondaryToogleOFF;

	@AndroidFindBy(xpath = "//android.widget.Switch[@text='ON']")
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch[@value='1']")
	protected MobileElement swtToogleON;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Validation Code']")
	@iOSFindBy(xpath = "//*[@label='Validation Code']")
	protected MobileElement titleValidationCode;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter code to activate phone number']")
	@iOSFindBy(xpath = "//*[@label=\"Enter code to activate phone number\"]")
	protected MobileElement msgValidationCodePage;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/answer")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value='Type your response']")
	@iOSFindBy(xpath = "//*[@name=\"EFormStringQuestionCollectionViewCellAnswerTextField\"]")
	protected MobileElement txtValidationCode;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='The code entered does not match. Please try again.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='The code entered does not match. Please try again.']")
	@CacheLookup
	protected MobileElement errMsgValidationCode;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Unable to validate entered phone number']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Unable to validate entered phone number']")
	@iOSFindBy(xpath = "//*[@value=\"Unable to validate entered phone number\"]")
	protected MobileElement errMsgNoValidationCode;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='The phone number you entered is not in the correct format.  Please try again.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='The phone number you entered is not in the correct format.  Please try again.']")
	protected MobileElement errMsgInvalidPhNumber;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='The phone number you entered is not in the correct format.  Please try again.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='The phone number you entered is not in the correct format.  Please try again.']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Please provide a phone number.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Please provide a phone number.']")
	protected MobileElement errMsgEmptyPhNumber;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='You will not receive SMS alerts until you verify your phone number. Are you sure you want to continue?']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Verification of phone number is required to receive text alerts. Are you sure you want to continue?']")
	protected MobileElement errMsgDiscardChanges;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Text Alerts']")
	@iOSFindBy(xpath = "//*[@label='Text Alerts']")
	@CacheLookup
	protected MobileElement titleTextAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Email Alerts']")
	@iOSFindBy(xpath = "//*[@label='Email Alerts']")
	@CacheLookup
	protected MobileElement titleEmailAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Push Alerts']")
	@iOSFindBy(xpath = "//*[@label='Push Alerts']")
	@CacheLookup
	protected MobileElement titlePushAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[starts-with(@text, 'Available balance of') and ends-with(@text, 'or less')]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]")
	protected MobileElement availableBalanceAmountLess;

	@AndroidFindBy(xpath = "//android.widget.TextView[starts-with(@text, 'Available balance of') and ends-with(@text, 'or more')]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]")
	protected MobileElement availableBalanceAmountMore;

	@AndroidFindBy(xpath = "//android.widget.TextView[starts-with(@text, 'Credit transaction of') and ends-with(@text, 'or more')]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[starts-with(@value, 'Credit transaction of')][1]")
	@CacheLookup
	protected MobileElement creditTransactionAmountMore;

	@AndroidFindBy(xpath = "//android.widget.TextView[starts-with(@text, 'Debit transaction of') and ends-with(@text, 'or more')]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[starts-with(@value, 'Debit transaction of')][1]")
	@CacheLookup
	protected MobileElement debitTransactionAmountMore;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter the amount below:']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Enter Amount']")
	protected MobileElement enterAmountPopup;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_save")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Save']")
	@iOSFindBy(xpath = "//*[@label=\"Submit\"]")
	protected MobileElement btnSave;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_cancel")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='CLOSE']")
	@iOSFindBy(xpath = "//XCUIElementTypeAlert//*[@label=\"Close\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Close']")
	@iOSFindBy(xpath = "//*[@label='Close']")
	@iOSFindBy(xpath = "//AppiumAUT/XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeAlert[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[3]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeButton[1]")
	protected MobileElement btnClosePopup;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='CONTINUE']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Continue']")
	@CacheLookup
	protected MobileElement btnContinuePopup;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Cancel']")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='CANCEL']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Cancel']")
	@iOSFindBy(xpath = "//*[@label=\"Close\"]")
	@iOSFindBy(xpath = "//*[@value=\"Cancel\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Cancel Payment']")
	protected MobileElement btnCancel;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/currency_field")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[contains(@value,'$')]")
	@CacheLookup
	protected MobileElement txtAmountField;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount should be greater than zero']")
	@CacheLookup
	protected MobileElement lblThresholdErrorMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Button[@text='OK']")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Ok']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Ok']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='OK']")
	@iOSFindBy(xpath = "//*[@value=\"Ok\"]")
	protected MobileElement btnOk;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Done']")
	@iOSFindBy(xpath = "//*[@label=\"done\"]")
	protected MobileElement btnDone;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Sorry, none of your accounts are eligible to use this feature.']")
	@iOSFindBy(xpath = "//*[@label='Sorry, none of your accounts are eligible to use this feature.']")
	@iOSFindBy(xpath = "//*[@label=\"Sorry, none of your accounts are eligible to use this feature.  Transfers to Non-Webster Accounts is not available to Business Customers.\"]")
	@CacheLookup
	protected MobileElement errorMessageClosedAccount;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Error']")
	@iOSFindBy(xpath = "//*[@value='Error']")
	@CacheLookup
	protected MobileElement titleError;

	// added by prasanth Credit card account
	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='CreditCard8539' and @enabled = 'true']")
	protected MobileElement lblCreditCardAccount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Nlck and @enabled = 'true']")
	protected MobileElement lblPurgedAccount;

	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Email button, Enabled']")
	protected MobileElement btnEmailEnable;

	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Email button, Enabled']")
	protected List<RemoteWebElement> lstEmailEnable;

	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected MobileElement btnSMSEnable;

	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected List<RemoteWebElement> lstSMSEnable;

	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected MobileElement btnPushEnable;

	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected List<RemoteWebElement> lstPushEnable;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/alert_method1")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Email button, Disabled']")
	protected MobileElement btnEmailDisable;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/alert_method1")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Email button, Disabled']")
	protected List<RemoteWebElement> lstEmailDisable;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/alert_method2")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected MobileElement btnSMSDisable;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/alert_method2")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected List<RemoteWebElement> lstSMSDisable;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/alert_method3")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected MobileElement btnPushDisable;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/alert_method3")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected List<RemoteWebElement> lstPushDisable;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	/** Provide locator for iOS **/
	// TODO
	// @iOSFindBy()
	@CacheLookup
	protected MobileElement errorThresholdAlerts;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='MANAGE ALERTS']")
	protected MobileElement navigateBack;

	@AndroidFindBy(xpath = "//android.widget.EditText[contains(@text,'@WebsterBank.com')]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'@WebsterBank.com')]")
	protected MobileElement txtEmailAddress;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Alert Preferences']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Alert Preferences']")
	protected MobileElement txtAlertsPreferences;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Step 1: Choose Alert Channels']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Step 1: Choose Alert Channels']")
	protected MobileElement txtAlertsChannels;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='EMAIL']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Email']")
	protected MobileElement txtEmail;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='TEXT']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Phone']")
	protected MobileElement txtText;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='PUSH']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Push ']")
	protected MobileElement txtPush;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Step 2: Configure Alert Types']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Step 2: Configure Alert Types']")
	protected MobileElement txtConfigureAlertTypes;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/configure_delivery_options_config_message")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Enable or disable push alerts for this application']")
	protected MobileElement txtConfigureDelivery;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/configure_push_delivery_option_message_label")
	protected MobileElement txtConfigurePushDelivery;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/pushToggleSwitch")
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch/preceding-sibling::XCUIElementTypeStaticText[@label='Push Notifications']")
	protected MobileElement swtTogglePush;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Toggle Push Alerts']")
	protected MobileElement txtTooglePushALerts;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Push Notifications']")
	protected MobileElement txtPushNotifications;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/configure_delivery_options_config_message")
	@iOSFindBy(xpath = "//*[@label='Alerts will be delivered to the email below. To update your email, log onto websteronline.com and go to Profile.']")
	protected MobileElement txtEmailConfigureOptions;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Email Confirmation']")
	protected MobileElement txtEmailConfirmation;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected List<RemoteWebElement> lstEmailEnableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected MobileElement btnEmailEnableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected List<RemoteWebElement> lstEmailDisableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected MobileElement btnEmailDisableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected List<RemoteWebElement> lstSMSEnableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected MobileElement btnSMSEnableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected List<RemoteWebElement> lstSMSDisableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected MobileElement btnSMSDisableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected List<RemoteWebElement> lstPushEnableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected MobileElement btnPushEnableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected List<RemoteWebElement> lstPushDisableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected MobileElement btnPushDisableBalanceMore;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected List<RemoteWebElement> lstEmailEnableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected MobileElement btnEmailEnableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected List<RemoteWebElement> lstEmailDisableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected MobileElement btnEmailDisableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected List<RemoteWebElement> lstSMSDisableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected MobileElement btnSMSDisableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected List<RemoteWebElement> lstSMSEnableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected MobileElement btnSMSEnableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected List<RemoteWebElement> lstPushDisableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected MobileElement btnPushDisableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected List<RemoteWebElement> lstPushEnableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Available balance of') and contains(@text,'less')]/../../following-sibling::android.widget.LinearLayout//android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Available balance of') and contains(@value,'less')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected MobileElement btnPushEnableBalanceLess;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected List<RemoteWebElement> lstEmailEnableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected MobileElement btnEmailEnableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected List<RemoteWebElement> lstEmailDisableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected MobileElement btnEmailDisableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected List<RemoteWebElement> lstSMSEnableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected MobileElement btnSMSEnableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected List<RemoteWebElement> lstSMSDisableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected MobileElement btnSMSDisableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected List<RemoteWebElement> lstPushEnableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected MobileElement btnPushEnableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected List<RemoteWebElement> lstPushDisableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Credit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected MobileElement btnPushDisableCreditMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected List<RemoteWebElement> lstEmailEnableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Enabled']")
	protected MobileElement btnEmailEnableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected List<RemoteWebElement> lstEmailDisableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Email Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Email button, Disabled']")
	protected MobileElement btnEmailDisableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected List<RemoteWebElement> lstSMSEnableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Enabled']")
	protected MobileElement btnSMSEnableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected List<RemoteWebElement> lstSMSDisableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[3]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Text Message Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit balance of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Text Message button, Disabled']")
	protected MobileElement btnSMSDisableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected List<RemoteWebElement> lstPushEnableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Enabled. Tap to Disable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Enabled']")
	protected MobileElement btnPushEnableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected List<RemoteWebElement> lstPushDisableDebitMore;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[4]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.ImageView[@content-desc='Push Notification Delivery Option Disabled. Tap to Enable']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[contains(@value, 'Debit transaction of') and contains(@value,'more')]/preceding-sibling::XCUIElementTypeButton[@label='Push Notification button, Disabled']")
	protected MobileElement btnPushDisableDebitMore;

	public String dynamicXpathAccountName = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[2] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";
	public String balanceTextAlert = "//android.widget.TextView[@text='Credit transaction of %d or more'] | //XCUIElementTypeTextView[@value='Credit transaction of %d or more']";
	public String balanceTextAlertDebit = "//android.widget.TextView[@text='Debit transaction of %d or more'] | //XCUIElementTypeTextView[@value='Debit transaction of %d or more']";
	public String amountPresent;
	private int xLocTitleAccountName;
	private int yLocTitleAccountName;

	public String xpathAccountName = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	/**
	 * Method to click on Manage Alerts Text
	 * 
	 * @throws Exception
	 */
	public void clickManageAlerts() throws Exception {
		try {
			txtManageAlerts.click();
			LogUtility.logInfo("--->Manage Alerts Option clicked<---");
			mobileActions.isElementPresent(txtManageAlerts, 4);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Manage Alerts Text Option<---" + e.getStackTrace());
			throw new Exception("Unable to click on Manage Alerts Text Option " + e);
		}
	}

	/**
	 * Method to click on Account Alerts Text and verify the select account title
	 * 
	 * @throws Exception
	 */
	public void clickAccountAlertsOption() throws Exception {
		try {
			txtAccountAlerts.click();
			LogUtility.logInfo("--->Account Alerts Option clicked<---");
			mobileActions.isElementPresent(titleSelectAccounts, 8);
		} catch (Exception e) {
			LogUtility.logError("--->Failed while clicking on Account Alerts option<--- " + e);
			throw new Exception("Failed while clicking on Account Alerts option " + e);
		}
	}

	/**
	 * Method to click on Account Alerts Text and verify the select account title
	 * 
	 * @throws Exception
	 */
	public void clickAccountAlerts() throws Exception {
		try {
			txtAccountAlerts.click();
			LogUtility.logInfo("--->Account Alerts Option clicked<---");

			mobileActions.isElementPresent(titleError, 4);
		} catch (Exception e) {
			LogUtility.logError("--->Failed while clicking on Account Alerts option<---" + e);
			throw new Exception("Failed while clicking on Account Alerts option " + e);
		}
	}

	/**
	 * Method to return number of accounts displayed in Alerts Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfAccounts() throws Exception {
		try {
			mobileActions.isElementPresent(cellAccounts, 5);
			LogUtility.logInfo("Number of accounts  displayed " + accountsListedCount.size());
			return accountsListedCount.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of accounts listed<---" + e);
			throw new Exception("Unable to get count of accounts listed " + e);
		}
	}

	/**
	 * Method to get list of accounts after selecting Account Alerts in Manage
	 * alerts page
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<String> getListOfAccounts() throws Exception {
		try {
			String accountName = null;
			List<String> accts = new ArrayList<String>();
			int count = getCountOfAccounts();
			for (int i = 1; i <= count; i++) {
				accountName = appiumDriver.findElement(By.xpath(String.format(dynamicXpathAccountName, i, i)))
						.getText();
				accts.add(accountName);
			}
			return accts;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the accounts listed<---" + e.getStackTrace());
			throw new Exception("Unable to get the accounts listed " + e);
		}
	}

	/**
	 * Method to select any account from the list of accounts displayed in alerts
	 * page Will verify the account selected is opened
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings("unused")
	public String clickOnAnyAccount() throws Exception {
		if (accountsListedCount.size() > 0) {
			int i = 1;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathAccountName, i, i))).getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicXpathAccountName, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
		}
		mobileActions.isElementPresent(titleAccountNameNavigationBar, 10);
		setValueInRuntimeDataMap("CreditTransactionAccount", titleAccountNameNavigationBar.getText());
		xLocTitleAccountName = titleAccountNameNavigationBar.getLocation().getX();
		yLocTitleAccountName = titleAccountNameNavigationBar.getLocation().getY();
		if (getValueFromRuntimeDataMap("CreditTransactionAccount").contains(selectAccount)) {
			LogUtility.logInfo("Account selected and Navigated to " + selectAccount + " & "
					+ getValueFromRuntimeDataMap("CreditTransactionAccount"));
		}
		return getValueFromRuntimeDataMap("CreditTransactionAccount");
	}

	/**
	 * Method to click the selected account based on text passed , from the list of
	 * accounts displayed in account summary
	 * 
	 * @throws Exception
	 */
	public String clickOnSelectedAccount(String text) throws Exception {
		if (text.contains(TestDataConstants.CREDITCARD_ACCOUNT)) {
			mobileActions.scrollDownToElementPresent(lblCreditCardAccount, 2, 4);
		} else {
			for (int i = 1; i <= accountsListedCount.size();) {
				WebElement selectanAccount = appiumDriver.findElement(By.xpath(String.format(xpathAccountName, i, i)));
				String selectaccounttxt = selectanAccount.getText();
				LogUtility.logInfo("selected account text is:" + selectaccounttxt);
				if (selectaccounttxt.contains(text)) {
					selectanAccount.click();
					LogUtility.logInfo("clicked on the****" + selectaccounttxt + "****account");
					waits.staticWait(12);
					break;
				} else {
					i++;
				}
			}
		}
		return text;
	}

	/**
	 * Method to verify the account last four digits displayed
	 * 
	 * @throws Exception
	 */
	public void verifyLastFourDigitsDisplayed() throws Exception {
		String accountDisplayed = getValueFromRuntimeDataMap("CreditTransactionAccount");
		String replaceTitle = accountDisplayed.replace(selectAccount + " (...", "");
		replaceTitle = replaceTitle.replace(")", "");
		int acctLength = replaceTitle.length();
		if (acctLength == 4) {
			LogUtility.logInfo("Account displayed with last four digits " + replaceTitle);
		} else {
			throw new Exception("Account not displayed with last four digits " + replaceTitle);
		}
	}

	/**
	 * Method to verify the label name in alerts page
	 * 
	 * @param label
	 * @throws Exception
	 */
	public void verifyLabelName(String label) throws Exception {
		try {
			String labelNameDisplayed = lblNameConfigureAlerts.getText();
			Assert.assertEquals(label, labelNameDisplayed);
			LogUtility.logInfo("Label displayed as " + labelNameDisplayed + " and verified with expected label name");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the label name " + label + " due to " + e.getStackTrace());
			throw new Exception("Unable to verify the label name " + e);
		}
	}

	/**
	 * Method to click on Text Icon in Manage alerts page
	 * 
	 * @throws Exception
	 */
	public void clickOnTextIcon() throws Exception {
		try {
			iconText.click();
			LogUtility.logInfo("Clicked on text icon");
			mobileActions.isElementPresent(titleTextAlerts, 5);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Text Icon " + e.getStackTrace());
			throw new Exception("Unable to click on Text Icon " + e);
		}
	}

	/**
	 * Method to click on Email Icon in manage alerts page
	 * 
	 * @throws Exception
	 */
	public void clickOnEmailIcon() throws Exception {
		try {
			iconEmail.click();
			LogUtility.logInfo("Clicked on email icon");
			mobileActions.isElementPresent(titleEmailAlerts, 5);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on email icon " + e);
			throw new Exception("Unable to click on email icon");
		}
	}

	/**
	 * Method to click on Push Icon in Manage alerts page
	 * 
	 * @throws Exception
	 */
	public void clickOnPushIcon() throws Exception {
		try {
			txtPush.click();
			LogUtility.logInfo("Clicked on push icon");
			mobileActions.isElementPresent(titlePushAlerts, 5);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on push Icon " + e.getStackTrace());
			throw new Exception("Unable to click on push Icon " + e);
		}
	}

	/**
	 * Method to verify the message on Text Alerts screen
	 * 
	 * @param message
	 * @throws Exception
	 */
	public void verifyTextAlertsScreenMessage(String message) throws Exception {
		try {
			String messageDisplayed = lblEnterPhoneNumberMessage.getText();
			if (messageDisplayed.contains(message)) {
				LogUtility.logInfo("Message displayed as " + messageDisplayed);
			} else {
				throw new Exception("Message displayed is not matched with the expected message " + messageDisplayed);
			}
		} catch (Exception e) {
			LogUtility.logError(
					"--->Unable to verify the label Enter Phone Number/Message displayed " + e.getStackTrace());
			throw new Exception("Unable to verify the label Enter Phone Number " + e);
		}
	}

	/**
	 * Method to verify the data rates apply message on alerts page
	 * 
	 * @param message
	 */
	public void verifyDataRatesMessage(String message) {
		try {
			String ratesMessage = lblDataRatesApplyMessage.getText();
			if (ratesMessage.contains(message)) {
				LogUtility.logInfo("Message displayed as " + ratesMessage);
			} else {
				throw new Exception("Message displayed is not matched with the expected message " + ratesMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to verify Primary and Secondary phone numbers text field
	 * 
	 * @throws Exception
	 */
	public void verifyNumberTextFields() throws Exception {
		try {
			List<RemoteWebElement> numberTextFieldsElements = Arrays.asList(lblPrimaryPhoneNumber,
					lblSecondaryPhoneNumber);
			mobileActions.elementsPresent(numberTextFieldsElements);
		} catch (Exception e) {
			throw new Exception("Unable to verify the phone number text fields " + e);
		}
	}

	/**
	 * Method to verify the Threshold amount options in alerts page
	 * 
	 * @throws Exception
	 */
	public void verifyThresholdAmountOptions() throws Exception {
		try {
			List<RemoteWebElement> thresholdAmountOptionElements = Arrays.asList(availableBalanceAmountLess,
					availableBalanceAmountMore, creditTransactionAmountMore, debitTransactionAmountMore);
			mobileActions.elementsPresent(thresholdAmountOptionElements);
			LogUtility.logInfo("Displayed");
		} catch (Exception e) {
			throw new Exception("Unable to verify the Threshold amount options " + e);
		}
	}

	/**
	 * Method to click on any tHreshold amount alert option
	 * 
	 * @throws Exception
	 */
	public void clickOnAnyThresholdAmount() throws Exception {
		try {
			availableBalanceAmountLess.click();
			mobileActions.isElementPresent(enterAmountPopup, 4);
			LogUtility.logInfo("Enter amount popup displayed");
		} catch (Exception e) {
			throw new Exception("Unable to click on threshold amount option in alerts page " + e);
		}
	}

	/**
	 * Method to verify the enter amount pop up display
	 * 
	 * @throws Exception
	 */
	public void enterAmountPopupDisplay() throws Exception {
		try {
			List<RemoteWebElement> enterAmountPopUpElements = Arrays.asList(enterAmountPopup, btnSave, btnClosePopup);
			mobileActions.elementsPresent(enterAmountPopUpElements);
		} catch (Exception e) {
			throw new Exception("Unable to verify the enter amount popup " + e);
		}
	}

	/**
	 * Method to enter the amount in amount text field
	 * 
	 * @param amount
	 * @throws Exception
	 */
	public void enterAmount(String amount) throws Exception {
		try {
			txtAmountField.clear();
			waits.staticWait(1);
			txtAmountField.clear();
			waits.staticWait(1);
			txtAmountField.clear();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				for (int i = 0; i < amount.length(); i++) {
					char c = amount.charAt(i);
					String eachCharacter = new StringBuilder().append(c).toString();
					txtAmountField.sendKeys(eachCharacter);
				}
			} else {
				txtAmountField.sendKeys(amount);
			}
			LogUtility.logInfo("--->Amount entered as " + amount);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter the " + amount + "in text field  " + e.getStackTrace());
			throw new Exception("Unable to enter the amount in text field " + e);
		}
	}

	/**
	 * Method to click on Save button
	 * 
	 * @throws Exception
	 */
	public void clickSaveButton() throws Exception {
		try {
			btnSave.click();
			LogUtility.logInfo("--->Clicked on Save button<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unble click on save button " + e.getStackTrace());
			throw new Exception("Unble click on save button " + e);
		}
	}

	/**
	 * Method to verify the threshold error message when amount enter $0.00
	 * 
	 * @param error
	 * @throws Exception
	 */
	public void verifyThresholdErrorMessage(String error) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				LogUtility.logInfo("In android finding locator for error message is not happening");
				txtAmountField.click();
				btnCancel.click();
			} else {
				String errorMessage = lblThresholdErrorMessage.getText();
				Assert.assertEquals(errorMessage, error);
				btnOk.isDisplayed();
				btnOk.click();
				LogUtility.logInfo("Error message and OK button verified " + errorMessage);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + error + " " + e.getStackTrace());
			throw new Exception("Unable to verify the error message " + error + " due to " + e);
		}
	}

	/**
	 * Method to verify the error message in alerts page for closed accounts
	 * 
	 * @param errorMessage
	 * @return
	 * @throws Exception
	 */
	public String verifyErrorMessageForClosedAccounts(String errorMessage) throws Exception {
		try {
			String errorMsg = errorMessageClosedAccount.getText();
			LogUtility.logInfo(errorMsg);
			Assert.assertEquals(errorMsg, errorMessage);
			LogUtility.logInfo("--->Error message displayed as " + errorMsg);
			return errorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + errorMessage + " " + e.getStackTrace());
			throw new Exception("Unable to verify the error message " + errorMessage + " due to " + e);
		}
	}

	/**
	 * Method to disable the alerts channels of email,sms,push
	 * 
	 * @throws Exception
	 */
	public void disableAlerts() throws Exception {
		try {
			LogUtility.logInfo("--->Disabling the three alerts channel<---");
			mobileActions.isElementPresent(btnEmailEnable, 3);
			if (btnEmailEnable.isDisplayed()) {
				btnEmailEnable.click();
				mobileActions.isElementPresent(btnEmailDisable, 5);
				LogUtility.logInfo("--->Email alert channel is disabled<---");
			} else if (btnEmailDisable.isDisplayed()) {
				LogUtility.logInfo("--->Email alert is already in disabled state<---");
			}
			if (btnSMSEnable.isDisplayed()) {
				btnSMSEnable.click();
				mobileActions.isElementPresent(btnSMSDisable, 5);
				LogUtility.logInfo("--->SMS alert channel is disabled<---");
			} else if (btnSMSDisable.isDisplayed()) {
				LogUtility.logInfo("--->SMS alert is already in disabled state<---");
			}
			if (btnPushEnable.isDisplayed()) {
				btnPushEnable.click();
				mobileActions.isElementPresent(btnPushDisable, 5);
				LogUtility.logInfo("--->Push alert channel is disabled<---");
			} else if (btnPushDisable.isDisplayed()) {
				LogUtility.logInfo("--->Push alert already in disabled state<---");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on " + e);
			throw new Exception("Unable to click on" + e);
		}
	}

	/**
	 * Method to verify the Threshold amount alert error message
	 * 
	 * @param androidError
	 * @param iOSError
	 * @throws Exception
	 */
	public void verifyErrorMessageThresholdAlerts(String androidError, String iOSError) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				String error = errorThresholdAlerts.getText();
				Assert.assertEquals(error, androidError);
				LogUtility.logInfo("--->Snack bar displayed and verified " + androidError);
			} else {
				LogUtility.logInfo("--->Have to check with iOS");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message " + e);
			throw new Exception("Unable to verify the error message " + e);
		}
	}

	/**
	 * Method to enter phone number into text field
	 * 
	 * @param phoneNumber
	 * @throws Exception
	 */
	public void enterPhoneNumber(String phoneNumber) throws Exception {
		try {
			lblPrimaryPhoneNumber.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				lblPrimaryPhoneNumber.clear();
				if (mobileActions.verifyIsElementPresent(txtEditingYourName, 5)) {
					btnContinue.click();
					lblPrimaryPhoneNumber.clear();
				}
			} else {
				if (mobileActions.verifyIsElementPresent(txtEditingYourName, 5)) {
					btnContinue.click();
				}
			}
			lblPrimaryPhoneNumber.sendKeys(phoneNumber);
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				mobileActions.hideKeyBoard();
			}
			LogUtility.logInfo("--->Entered phone number into text field<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter phone number " + e);
			throw new Exception("Unable to enter phone number " + e);
		}
	}

	/**
	 * Method to enter phone number into Secondary text field
	 * 
	 * @param phoneNumber
	 * @throws Exception
	 */
	public void enterPhoneNumberSecondary(String phoneNumber) throws Exception {
		try {
			lblSecondaryPhoneNumber.click();
			lblSecondaryPhoneNumber.clear();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				if (mobileActions.verifyIsElementPresent(txtEditingYourName, 5)) {
					btnContinue.click();
					lblSecondaryPhoneNumber.clear();
				}
			} else {
				if (mobileActions.verifyIsElementPresent(txtEditingYourName, 5)) {
					btnContinue.click();
					lblSecondaryPhoneNumber.clear();
				}
			}
			lblSecondaryPhoneNumber.sendKeys(phoneNumber);
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				mobileActions.hideKeyBoard();
			}
			LogUtility.logInfo("--->Entered phone number into Secondary text field<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter Secondary phone number " + e);
			throw new Exception("Unable to enter Secondary phone number " + e);
		}
	}

	public void clearPrimaryPhoneNumber() throws Exception {
		try {
			lblPrimaryPhoneNumber.clear();
		} catch (WebDriverException e) {
			LogUtility.logError("Unable to clear text field " + e);
			throw new Exception("Unable to clear text field " + e);
		}
	}

	public void clearSecondaryPhoneNumber() throws Exception {
		try {
			lblSecondaryPhoneNumber.clear();
		} catch (WebDriverException e) {
			LogUtility.logError("Unable to clear text field " + e);
			throw new Exception("Unable to clear text field " + e);
		}
	}

	/**
	 * Method to toogle On switch
	 * 
	 * @throws Exception
	 */
	public void enableToggleButton() throws Exception {
		try {
			swtToogleOFF.click();
			LogUtility.logInfo("--->Toogle is switched<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to toggle switch " + e);
			throw new Exception("Unable to toggle switch " + e);
		}
	}

	/**
	 * Method to toogle On Secondary switch
	 * 
	 * @throws Exception
	 */
	public void enableSecondaryToggleButton() throws Exception {
		try {
			swtSecondaryToogleOFF.click();
			LogUtility.logInfo("--->Secondary Toogle is switched<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to toggle Secondary switch " + e);
			throw new Exception("Unable to toggle Secondary switch " + e);
		}
	}

	/**
	 * Method to verify the elements on Validation code page
	 * 
	 * @throws Exception
	 */
	public void verifyValidationCodePage() throws Exception {
		try {
			mobileActions.isElementPresent(titleValidationCode, 4);
			List<RemoteWebElement> validationCodePageElements = Arrays.asList(msgValidationCodePage, btnOk, btnCancel);
			mobileActions.elementsPresent(validationCodePageElements);
			LogUtility.logInfo("--->Validation Code Page displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify validation code page " + e);
			throw new Exception("Unable to verify validation code page " + e);
		}
	}

	/**
	 * Method to enter text in validation code page
	 * 
	 * @param code
	 * @throws Exception
	 */
	public void enterValidationCode(String code) throws Exception {
		try {
			txtValidationCode.sendKeys(code);
			LogUtility.logInfo("--->Entered Validation Code<--- " + code);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter Validation Code " + e);
			throw new Exception("Unable to enter validation code " + e);
		}
	}

	/**
	 * Method to click on OK button
	 * 
	 * @throws Exception
	 */
	public void clickOkValidationCodePage() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				btnDone.click();
				waits.staticWait(4);
			}
			btnOk.click();
			LogUtility.logInfo("Cliked on Ok");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on OK button or verify code " + e);
			throw new Exception("Unable to click on OK button or verify code");
		}
	}

	/**
	 * Method to verify the validation page code error
	 * 
	 * @param message
	 * @throws Exception
	 */
	public void verifyValidationCodePageError(String message) throws Exception {
		try {
			String error = errMsgValidationCode.getText();
			Assert.assertEquals(error, message);
			LogUtility.logInfo("--->Verified validation code error<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to validate error message " + e);
			throw new Exception("Unable to validate error message");
		}
	}

	/**
	 * Method to click on Cancel button
	 * 
	 * @throws Exception
	 */
	public void clickOnCancelButton() throws Exception {
		try {
			btnCancel.click();
			LogUtility.logInfo("--->Clicked on Cancel button");
			/*--waiting for popup to close after clicking on cancel button--*/
			waits.staticWait(2);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on cancel button " + e);
			throw new Exception("Unable to click on cancel button");
		}
	}

	/**
	 * Method to verify the error message when phone number is not entered and
	 * navigated back to previous page
	 * 
	 * @param errMessage
	 * @throws Exception
	 */
	public void validateErrorMessageValidationCode(String errMessage) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				mobileActions.isElementPresent(titleError, 3);
			}
			String errorMsg = errMsgNoValidationCode.getText();
			Assert.assertEquals(errorMsg, errMessage);
			LogUtility.logInfo("Validated the error message");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to validate error message after clicking on calcel button " + e);
			throw new Exception("Unable to validate error message after clicking on calcel button");
		}
	}

	/**
	 * Method to verify the error message when invalid phone number entered
	 * 
	 * @param errMessage
	 * @throws Exception
	 */
	public void validateErrorMessageInvalidPhNumber(String errMessage) throws Exception {
		try {
			String errMsg = errMsgEmptyPhNumber.getText();
			Assert.assertEquals(errMsg, errMessage);
			btnOk.isDisplayed();
			LogUtility.logInfo("--->Verified error message displayed when invalid phone number entered");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to validate error message when invalid phone number entered " + e);
			throw new Exception("Unable to validate error message when invalid phone number entered");
		}
	}

	/**
	 * Method to navigate back
	 * 
	 * @throws Exception
	 */
	public void navigateBack() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				ConcurrentEngines.getEngine().getAndroidDriver().navigate().back();
			} else {
				navigateBack.click();
			}
			LogUtility.logInfo("--->Navigated back<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to navigate back " + e);
			throw new Exception("Unable to navigate back");
		}
	}

	/**
	 * Method to validate error message when changes discarded
	 * 
	 * @param iOSErr
	 * @param androidErr
	 * @throws Exception
	 */
	public void validateErrorMessageDiscardChanges(String iOSErr, String androidErr) throws Exception {
		try {
			String errMsg = errMsgDiscardChanges.getText();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				Assert.assertEquals(errMsg, iOSErr);
			} else {
				Assert.assertEquals(errMsg, androidErr);
			}
			List<RemoteWebElement> errorMessageDiscardElements = Arrays.asList(btnContinuePopup);
			mobileActions.elementsPresent(errorMessageDiscardElements);
			LogUtility.logInfo("--->Error message validated when changes discarded<---");
		} catch (Exception e) {
			LogUtility.logError("--->Error message not validated when changes discarded " + e);
			throw new Exception("Error message not validated when changes discarded");
		}
	}

	/**
	 * Method to validate the error message for empty phone number
	 * 
	 * @param errMsgEmptyNumber
	 * @throws Exception
	 */
	public void validateErrorMessageEmptyPhNumber(String errMsgEmptyNumber) throws Exception {
		try {
			String errMsg = errMsgEmptyPhNumber.getText();
			Assert.assertEquals(errMsg, errMsgEmptyNumber);
			LogUtility
					.logInfo("--->Verified the error message when phone number field kept empty " + errMsgEmptyNumber);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message when ph number field kept empty " + e);
			throw new Exception("Unable to verify the error message when ph number field kept empty");
		}
	}

	/**
	 * Method to verify the manage alerts page
	 * 
	 * @throws Exception
	 */
	public void onMananageAlertsPage() throws Exception {
		try {
			mobileActions.isElementPresent(titleManageAlerts, 4);
			LogUtility.logInfo("-->Page displayed ==> Manage Alerts ");
		} catch (Exception e) {
			LogUtility.logError("--->Page not displayed ==> Manage alerts " + e);
			throw new Exception("Page not displayed ==> Manage alerts ");
		}
	}

	/**
	 * Method to validate the webster bank email address
	 * 
	 * @param email
	 * @throws Exception
	 */
	public void validateEmailAddress(String email) throws Exception {
		try {
			String emailAddr = txtEmailAddress.getText();
			Assert.assertTrue(emailAddr.contains(email), "Email Address present with valid email.com");
			LogUtility.logInfo("--->Validated email address<--- " + emailAddr);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to validate the eamail address " + e);
			throw new Exception("Unable to validate the eamail address");
		}
	}

	public void clicOnCreditTransactionAbove() throws Exception {
		try {
			creditTransactionAmountMore.click();
			LogUtility.logInfo("Clicked on Credit Trasaction and above");
		} catch (Exception e) {
			LogUtility.logError("-->Unable to click on credit transaction above<---" + e);
			throw new Exception("-->Unable to click on credit transaction above<---" + e);
		}
	}

	public void clicOnDebitTransactionAbove() throws Exception {
		try {
			debitTransactionAmountMore.click();
			LogUtility.logInfo("Clicked on Debit Trasaction and above");
		} catch (Exception e) {
			LogUtility.logError("-->Unable to click on Debit transaction above<---" + e);
			throw new Exception("-->Unable to click on Debit transaction above<---" + e);
		}
	}

	public void verifyAmountFieldEntered(String value) throws Exception {
		try {
			String valueEntered = txtAmountField.getText();
			Assert.assertFalse(valueEntered.contains(value),
					"Value provided to enter in the amount field is entered " + value);
			LogUtility.logInfo("Verified the amount field value entered or not");
		} catch (Exception e) {
			LogUtility.logError("-->Unable to verify the amount field values entered " + value + "<---" + e);
			throw new Exception("-->Unable to verify the amount field values entered " + value + "<---" + e);
		}
	}

	public String verifyAmountBalancePresent() throws Exception {
		try {
			amountPresent = txtAmountField.getText();
			LogUtility.logInfo("Verified the amount displayed");
			return amountPresent;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the amount balance " + e);
			throw new Exception("Unable to verify the amount balance " + e);
		}
	}

	public void verifyAmountBalanceNotChanged() throws Exception {
		try {
			if (appiumDriver.findElements(By.xpath(balanceTextAlertDebit.replace("%d", amountPresent))).size() != 0) {
				LogUtility.logInfo("Balance amount is not changed");
			} else {
				throw new Exception("Balance amount changed");
			}
			LogUtility.logInfo("Verified the amount displayed is not changed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the amount balance/amount changed " + e);
			throw new Exception("Unable to verify the amount balance/amount changed " + e);
		}
	}

	@SuppressWarnings("rawtypes")
	public void tapOutsideAlert() throws Exception {
		try {
			TouchAction touchAction = new TouchAction(appiumDriver);
			touchAction.tap(PointOption.point(xLocTitleAccountName, yLocTitleAccountName)).perform();
			if (TestDataConstants.getOSPlatformName().equals("ios")) {
				touchAction.tap(PointOption.point(xLocTitleAccountName, yLocTitleAccountName)).perform();
			}
			LogUtility.logInfo("Tapped ouside the alert box");
		} catch (Exception e) {
			LogUtility.logError("Unable to tap outside the alert box " + e);
			throw new Exception("Unable to tap outside the alert box " + e);
		}
	}

	public void verifyMangaeAlertsScreen() throws Exception {
		try {
			List<RemoteWebElement> labelsAlertsScreenElements = Arrays.asList(txtAlertsPreferences, txtAlertsChannels,
					txtEmail, txtText, txtPush, txtConfigureAlertTypes, txtAccountAlerts);
			mobileActions.elementsPresent(labelsAlertsScreenElements);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the value " + e);
			throw new Exception("Unable to verify the value " + e);
		}
	}

	public void verifyPushAlertsPageAndroid(String text1, String text2) throws Exception {
		try {
			String configureDelivery = txtConfigureDelivery.getText();
			Assert.assertEquals(configureDelivery, text1);
			LogUtility.logInfo("Verified the configure deivery text present on push page");

			String configurePushDelivery = txtConfigurePushDelivery.getText();
			Assert.assertEquals(configurePushDelivery, text2);
			LogUtility.logInfo("Verified the configure push deivery text present on push page");

			swtTogglePush.isDisplayed();
			LogUtility.logInfo("Toogle switch button is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the text present on page " + e);
			throw new Exception("Unable to verify the text present on page " + e);
		}
	}

	public void verifyPushAlertsPageIos(String text1, String text2, String text3) throws Exception {
		try {
			String tooglePushAlerts = txtTooglePushALerts.getText();
			Assert.assertEquals(tooglePushAlerts, text1);
			LogUtility.logInfo("Verified the toogle push alerts text present on push page");

			String configureDelivery = txtConfigureDelivery.getText();
			Assert.assertEquals(configureDelivery, text2);
			LogUtility.logInfo("Verified the configure deivery text present on push page");

			String pushNotifications = txtPushNotifications.getText();
			Assert.assertEquals(pushNotifications, text3);
			LogUtility.logInfo("Verified the push notifications text present on push page");

			swtTogglePush.isDisplayed();
			LogUtility.logInfo("Toogle switch button is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the text present on page " + e);
			throw new Exception("Unable to verify the text present on page " + e);
		}
	}

	public void verifyEmailAddressCanUpdate() throws Exception {
		try {
			txtEmailAddress.click();
			String verifyEditable = txtEmailAddress.getAttribute("enabled");
			boolean verifyEditableStatus = Boolean.valueOf(verifyEditable);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				if (verifyEditableStatus == false) {
					LogUtility.logInfo("Unable to edit the email address from mobile");
				} else {
					throw new Exception("Email address field is in editable mode in mobile in android");
				}
			} else {
				try {
					/** In iOS enable status is set to true by default **/
					txtEmailAddress.sendKeys("Edit email address");
					String emailAddr = txtEmailAddress.getText();
					if (emailAddr.equals("Edit email address")) {
						throw new Exception("Email address field is in editable mode in mobile in iOS");
					}
				} catch (WebDriverException e) {
					LogUtility.logInfo("Unable to edit the email address from mobile in ios");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Able to edit the email address from mobile " + e);
			throw new Exception("Able to edit the email address from mobile " + e);
		}
	}

	public void verifyContentEmailPage() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))
				txtEmailConfirmation.isDisplayed();
			String configureTextEmail = txtEmailConfigureOptions.getText();
			Assert.assertEquals(configureTextEmail, testDataMap.get("ContentConfigureDeliveryOptions"));
			LogUtility.logInfo("Configure content verified in email page");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the configure content present in email page " + e);
			throw new Exception("Unable to verify the configure content present in email page " + e);
		}
	}

	public void clickOnLowBalanceAlert() throws Exception {
		try {
			availableBalanceAmountLess.isDisplayed();
			availableBalanceAmountLess.click();
			LogUtility.logInfo("Clicked on low balance alert");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on low balance alert " + e);
			throw new Exception("Unable to click on low balance alert " + e);
		}
	}

	public void clickOnHighBalanceAlert() throws Exception {
		try {
			availableBalanceAmountMore.isDisplayed();
			availableBalanceAmountMore.click();
			LogUtility.logInfo("Clicked on high balance alert");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on high balance alert " + e);
			throw new Exception("Unable to click on high balance alert " + e);
		}
	}

	public void verifyValueNotEntered(String value) throws Exception {
		try {
			if (!mobileActions.verifyValueNotPresent(txtAmountField, value))
				LogUtility.logInfo(value + " Provided value not entered as expected");
			else
				throw new Exception(value + " Provided value entered into text field");
			LogUtility.logInfo("Provided " + value + " did not enterd in text field");
		} catch (Exception e) {
			LogUtility.logError("Provided " + value + "is entered into text field " + e);
			throw new Exception("Provided " + value + " is entered into text field " + e);
		}
	}

	public void clickOnEmailDeliveryChannel() throws Exception {
		try {
			btnEmailDisable.click();
			LogUtility.logInfo("Clicked on Email Delivery Channel");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Email Delivery Channel " + e);
			throw new Exception("Unable to click on Email Delivery Channel " + e);
		}
	}

	public void verifyAlertOptionStatus(String statusToCheck, String alertOption, List<RemoteWebElement> lstEnable,
			List<RemoteWebElement> lstDisable, MobileElement btnEnable, MobileElement btnDisable) throws Exception {
		try {
			switch (statusToCheck) {
			case "enable":
				if (lstEnable.size() > 0) {
					LogUtility.logInfo(alertOption + " delivery option is enabled");
				} else if (lstDisable.size() > 0) {
					LogUtility.logInfo(alertOption + " button is not enabled and hence enabling it");
					btnDisable.click();
					mobileActions.isElementPresent(btnEnable, 5);
					LogUtility.logInfo(alertOption + " button is enabled");
				}
				break;

			case "disable":
				if (lstDisable.size() > 0) {
					LogUtility.logInfo(alertOption + " delivery option is in disabled state");
				} else if (lstEnable.size() > 0) {
					LogUtility.logInfo(alertOption + " button is enabled and hence disabling it");
					btnEnable.click();
					mobileActions.isElementPresent(btnDisable, 5);
					LogUtility.logInfo(alertOption + " button is disbled");
				}
				break;
			}
		} catch (Exception e) {
			LogUtility.logException("verifyAlertOptionStatus",
					alertOption + " alert channel is not " + statusToCheck + "", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Enabling all the alert channels Email, SMS, Push for section available
	 * balance or more
	 * 
	 * @throws Exception
	 */
	public void enableAlertsChannelBalanceMore(String status, String alertType) throws Exception {
		LogUtility.logInfo("--->Enabling all the three alerts channel for balance more<---");
		mobileActions.isElementPresent(availableBalanceAmountMore, 5);
		String[] alerts = alertType.split(",");
		for (int i = 0; i < alerts.length; i++) {
			if (alerts[i].equalsIgnoreCase("Email")) {
				emailAlertChannelStatusBalanceMore(status, alerts[i]);
			} else if (alerts[i].equalsIgnoreCase("mobile") || alerts[i].equalsIgnoreCase("SMS")) {
				mobileAlertChannelStatusBalanceMore(status, alerts[i]);
			} else if (alerts[i].equalsIgnoreCase("Push")) {
				pushAlertChannelStatusBalanceMore(status, alerts[i]);
			}
		}
	}

	/**
	 * Method to enable/disable email alert channel
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void emailAlertChannelStatusBalanceMore(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstEmailEnableBalanceMore, lstEmailDisableBalanceMore,
				btnEmailEnableBalanceMore, btnEmailDisableBalanceMore);
	}

	/**
	 * Method to enable/disable text alert channel
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void mobileAlertChannelStatusBalanceMore(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstSMSEnableBalanceMore, lstSMSDisableBalanceMore,
				btnSMSEnableBalanceMore, btnSMSDisableBalanceMore);
	}

	/**
	 * Method to enable/disable push alert channel
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void pushAlertChannelStatusBalanceMore(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstPushEnableBalanceMore, lstPushDisableBalanceMore,
				btnPushEnableBalanceMore, btnPushDisableBalanceMore);
	}

	/**
	 * Method to clear phone number in text field
	 * 
	 * @throws Exception
	 */
	public void clearPhoneNumber() throws Exception {
		try {
			lblPrimaryPhoneNumber.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				lblPrimaryPhoneNumber.clear();
				if (mobileActions.verifyIsElementPresent(txtEditingYourName, 5)) {
					btnContinue.click();
					lblPrimaryPhoneNumber.clear();
				}
			} else {
				if (mobileActions.verifyIsElementPresent(txtEditingYourName, 5)) {
					btnContinue.click();
				}
			}
			lblPrimaryPhoneNumber.clear();
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				mobileActions.hideKeyBoard();
			}
			LogUtility.logInfo("--->Cleared phone number in text field<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to clear phone number " + e);
			throw new Exception("Unable to clear phone number " + e);
		}
	}

	/**
	 * Method to verify text alert channel icon is present or not
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void verifyTextAlertChannelNotPresent() throws Exception {
		try {
			if (lstSMSEnableBalanceMore.size() > 0 || lstSMSDisableBalanceMore.size() > 0)
				throw new Exception("Text alerts icon is still displayed");
			else
				LogUtility.logInfo("Text alert icon is not displayed");
		} catch (Exception e) {
			LogUtility.logError("Text alert channel is present " + e);
			throw new Exception("Text alert channel is present " + e);
		}
	}

	/**
	 * Disabling all the alert channels Email, SMS, Push for section available
	 * balance or more
	 * 
	 * @throws Exception
	 */
	public void disableAlertsChannelBalanceMore() throws Exception {
		LogUtility.logInfo("--->Disabling all the three alerts channel for balance more<---");
		mobileActions.isElementPresent(availableBalanceAmountMore, 5);
		if (lstEmailDisableBalanceMore.size() > 0) {
			LogUtility.logInfo("Email delivery option is disbled");
		} else if (lstEmailEnableBalanceMore.size() > 0) {
			LogUtility.logInfo("Email button is not disabled and hence disabling it");
			btnEmailEnableBalanceMore.click();
			mobileActions.isElementPresent(btnEmailDisableBalanceMore, 5);
			LogUtility.logInfo("Email button is Disabled");
		}
		if (lstSMSDisableBalanceMore.size() > 0) {
			LogUtility.logInfo("SMS delivery option is disabled");
		} else if (lstSMSEnableBalanceMore.size() > 0) {
			LogUtility.logInfo("SMS button is not disabled and hence disabling it");
			btnSMSEnableBalanceMore.click();
			mobileActions.isElementPresent(btnSMSDisableBalanceMore, 5);
			LogUtility.logInfo("SMS button is disabled");
		}
		if (lstPushDisableBalanceMore.size() > 0) {
			LogUtility.logInfo("Push delivery option is disabled");
		} else if (lstPushEnableBalanceMore.size() > 0) {
			LogUtility.logInfo("Push button is not disabled and hence disabling it");
			btnPushEnableBalanceMore.click();
			mobileActions.isElementPresent(btnPushDisableBalanceMore, 5);
			LogUtility.logInfo("Push button is disabled");
		}
	}

	/**
	 * Disabling all the alert channels Email, SMS, Push for section available
	 * balance or less
	 * 
	 * @throws Exception
	 */
	public void disableAlertsChannelBalanceLess() throws Exception {
		LogUtility.logInfo("--->Disabling all the three alerts channel for balance less<---");
		mobileActions.isElementPresent(availableBalanceAmountLess, 5);
		if (lstEmailDisableBalanceLess.size() > 0) {
			LogUtility.logInfo("Email delivery option is disbled");
		} else if (lstEmailEnableBalanceLess.size() > 0) {
			LogUtility.logInfo("Email button is not disabled and hence disabling it");
			btnEmailEnableBalanceLess.click();
			mobileActions.isElementPresent(btnEmailDisableBalanceLess, 5);
			LogUtility.logInfo("Email button is Disabled");
		}
		if (lstSMSDisableBalanceLess.size() > 0) {
			LogUtility.logInfo("SMS delivery option is disabled");
		} else if (lstSMSEnableBalanceLess.size() > 0) {
			LogUtility.logInfo("SMS button is not disabled and hence disabling it");
			btnSMSEnableBalanceLess.click();
			mobileActions.isElementPresent(btnSMSDisableBalanceLess, 5);
			LogUtility.logInfo("SMS button is disabled");
		}
		if (lstPushDisableBalanceLess.size() > 0) {
			LogUtility.logInfo("Push delivery option is disabled");
		} else if (lstPushEnableBalanceLess.size() > 0) {
			LogUtility.logInfo("Push button is not disabled and hence disabling it");
			btnPushEnableBalanceLess.click();
			mobileActions.isElementPresent(btnPushDisableBalanceLess, 5);
			LogUtility.logInfo("Push button is disabled");
		}
	}

	/**
	 * Enabling all the alert channels Email, SMS, Push for section available
	 * balance or less
	 * 
	 * @throws Exception
	 */
	public void enableAlertsChannelBalanceLess() throws Exception {
		LogUtility.logInfo("--->Enabling all the three alerts channel for balance less<---");
		mobileActions.isElementPresent(availableBalanceAmountLess, 5);
		if (lstEmailEnableBalanceLess.size() > 0) {
			LogUtility.logInfo("Email delivery option is enabled");
		} else if (lstEmailDisableBalanceLess.size() > 0) {
			LogUtility.logInfo("Email button is not enabled and hence enabling it");
			btnEmailDisableBalanceLess.click();
			mobileActions.isElementPresent(btnEmailEnableBalanceLess, 5);
			LogUtility.logInfo("Email button is enabled");
		}
		if (lstSMSEnableBalanceLess.size() > 0) {
			LogUtility.logInfo("SMS delivery option is enabled");
		} else if (lstSMSDisableBalanceLess.size() > 0) {
			LogUtility.logInfo("SMS button is not enabled and hence enabling it");
			btnSMSDisableBalanceLess.click();
			mobileActions.isElementPresent(btnSMSEnableBalanceLess, 5);
			LogUtility.logInfo("SMS button is enabled");
		}
		if (lstPushEnableBalanceLess.size() > 0) {
			LogUtility.logInfo("Push delivery option is enabled");
		} else if (lstPushDisableBalanceLess.size() > 0) {
			LogUtility.logInfo("Push button is not enabled and hence enabling it");
			btnPushDisableBalanceLess.click();
			mobileActions.isElementPresent(btnPushEnableBalanceLess, 5);
			LogUtility.logInfo("Push button is enabled");
		}
	}

	/**
	 * Method to click on balance more threshold amount alert option
	 * 
	 * @throws Exception
	 */
	public void clickOnBalanceMoreThresholdAmount() throws Exception {
		try {
			availableBalanceAmountMore.click();
			mobileActions.isElementPresent(enterAmountPopup, 4);
			LogUtility.logInfo("Enter amount popup displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on threshold amount option in alerts page " + e);
			throw new Exception("Unable to click on threshold amount option in alerts page " + e);
		}
	}

	public String getBalanceAvailable(MobileElement typeOfBalance) throws Exception {
		String amountPresent = null;
		String verifyBalance = null;
		mobileActions.isElementPresent(typeOfBalance, 5);
		verifyBalance = typeOfBalance.getText();
		LogUtility.logInfo(verifyBalance);
		amountPresent = verifyBalance.substring(verifyBalance.indexOf('$'), verifyBalance.indexOf("or")).trim();
		LogUtility.logInfo("Amount displayed " + amountPresent);
		return amountPresent;
	}

	public String getThresholdBalanceAvailable(String typeOfBalance) throws Exception {
		String amountDisplayed = null;
		if (typeOfBalance.contains("Available balance of or less")) {
			amountDisplayed = getBalanceAvailable(availableBalanceAmountLess);
		} else if (typeOfBalance.contains("Available balance of or more")) {
			amountDisplayed = getBalanceAvailable(availableBalanceAmountMore);
		} else if (typeOfBalance.contains("Credit transaction of or more")) {
			amountDisplayed = getBalanceAvailable(creditTransactionAmountMore);
		} else if (typeOfBalance.contains("Debit transaction of or more")) {
			amountDisplayed = getBalanceAvailable(debitTransactionAmountMore);
		}
		return amountDisplayed;

	}

	/**
	 * Method to click on balance less threshold amount alert option
	 * 
	 * @throws Exception
	 */
	public void clickOnBalanceLessThresholdAmount() throws Exception {
		try {
			availableBalanceAmountLess.click();
			mobileActions.isElementPresent(enterAmountPopup, 4);
			LogUtility.logInfo("Enter amount popup displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on threshold amount option in alerts page " + e);
			throw new Exception("Unable to click on threshold amount option in alerts page " + e);
		}
	}

	public void verifyManageAlertsPage() throws Exception {
		try {
			mobileActions.isElementPresent(titleManageAlerts, 5);
			LogUtility.logInfo("Verified manage alerts page screen is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the manage alerts page is displayed " + e);
			throw new Exception("Unable to verify the manage alerts page is displayed " + e);
		}
	}

	/**
	 * Method to enable/disable email alert channel for Credit More
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void emailAlertChannelStatusCreditAbove(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstEmailEnableCreditMore, lstEmailDisableCreditMore,
				btnEmailEnableCreditMore, btnEmailDisableCreditMore);
	}

	/**
	 * Method to enable/disable text alert channel for Credit More
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void mobileAlertChannelStatusCreditAbove(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstSMSEnableCreditMore, lstSMSDisableCreditMore,
				btnSMSEnableCreditMore, btnSMSDisableCreditMore);
	}

	/**
	 * Method to enable/disable push alert channel for Credit More
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void pushAlertChannelStatusCreditAbove(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstPushEnableCreditMore, lstPushDisableCreditMore,
				btnPushEnableCreditMore, btnPushDisableCreditMore);
	}

	/**
	 * Method to enable/disable email alert channel for Debit More
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void emailAlertChannelStatusDebitAbove(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstEmailEnableDebitMore, lstEmailDisableDebitMore,
				btnEmailEnableDebitMore, btnEmailDisableDebitMore);
	}

	/**
	 * Method to enable/disable text alert channel for Debit More
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void mobileAlertChannelStatusDebitAbove(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstSMSEnableDebitMore, lstSMSDisableDebitMore, btnSMSEnableDebitMore,
				btnSMSDisableDebitMore);
	}

	/**
	 * Method to enable/disable push alert channel for Debit More
	 * 
	 * @param status
	 * @throws Exception
	 */
	public void pushAlertChannelStatusDebitAbove(String status, String alertType) throws Exception {
		verifyAlertOptionStatus(status, alertType, lstPushEnableDebitMore, lstPushDisableDebitMore,
				btnPushEnableDebitMore, btnPushDisableDebitMore);
	}

}
