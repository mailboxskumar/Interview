package com.wb.wol_mobile.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author MPrasanth-adm
 *
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author MPrasanth-adm
 *
 */
public class DepositsPage extends ObjectBase {

	private static final CharSequence CAMERASETTINGS_POPUP = null;
	private String selectAccount = null;

	public DepositsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	MobileActions mobileActions = new MobileActions();
	ManageAlertsPage manageAlertsPage = new ManageAlertsPage();

	@AndroidFindBy(xpath = "//android.support.v7.widget.RecyclerView/child::android.widget.FrameLayout")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView/child::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstCheckDepositTranscation;

	@AndroidFindBy(xpath = "//*[@text=\"Deposit Checks\"]")
	@iOSFindBy(xpath = "//*[@label=\"Deposit Checks\"]")
	protected MobileElement btnCheckDeposits;
	
	@AndroidFindBy(xpath = "//*[@resourceid=\"com.android.packageinstaller:id/permission_allow_button\"]")
	protected MobileElement allowPopUp;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'accept']")
	@iOSFindBy(xpath = "//*[@label=\"accept\"]")
	protected MobileElement btnAccept;

	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'accept']")
	@iOSFindBy(xpath = "//*[@label=\"accept\"]")
	protected List<RemoteWebElement> lstAcceptButton;

	@AndroidFindBy(xpath = "//android.widget.ImageButton[@resource-id = 'com.malauzai.websterbank:id/parallax_button_1']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@name = 'Make a Deposit']")
	protected MobileElement btnDepositACheck;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'MAKE DEPOSIT']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label = 'CREATE DEPOSIT']")
	protected MobileElement lblMakeADeposit;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label='DEPOSIT CHECKS']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='DEPOSIT CHECKS']")
	protected MobileElement txtDepositCheck;

	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'OK']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Try Again']")
	protected MobileElement btnOk;

	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'decline']")
	@iOSFindBy(xpath = "//*[@label='decline']")
	protected MobileElement btnDecline;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Unable to continue without accepting terms and conditions.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Unable to continue without accepting terms and conditions.']")
	protected MobileElement lblTermAndConditionsErrorHead;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name='RemoteDepositsPayToAccountCell']")
	protected MobileElement lblDepositToField;

	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id = 'com.malauzai.websterbank:id/currency']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name='RemoteDepositsAmountCell']")
	protected MobileElement lblAmountField;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/currency")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Please choose an account']")
	protected MobileElement lblChooseAccountError;

	@iOSFindBy(xpath = "//*[@label=\"Check Front\"]//*[@label=\"More Info\"]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Check Front (Click to Capture Image)']")
	protected MobileElement lblCheckFrontField;

	@iOSFindBy(xpath = "//XCUIElementTypeTable/child::XCUIElementTypeCell")
	public List<RemoteWebElement> lblCheckFrontList;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeTable[1]/child::XCUIElementTypeCell")
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/options_button\"][1]")
	@AndroidFindBy(xpath = "//android.widget.ListView/child::android.widget.FrameLayout")
	public List<RemoteWebElement> lblToAccountList;

	@iOSFindBy(xpath = "//XCUIElementTypeTable[1]/child::XCUIElementTypeCell[1]")
	protected MobileElement depositToAccount;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resourceid=\"com.malauzai.websterbank:id/account_name\"]")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/value")
	@iOSFindBy(className = "XCUIElementTypeTable")
	protected MobileElement depositToField;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'View Details']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'View Details']")
	protected MobileElement btnViewDetails;

	@iOSFindBy(xpath = "//XCUIElementTypeCell[4]/XCUIElementTypeButton[1]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Check Back (Click to Capture Image)']")
	protected MobileElement lblCheckBackField;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/detailed_failover_continue_btn")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Capture Manually']")
	protected MobileElement btnCaptureManually;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Capture image']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/misnap_overlay_capture_button")
	protected MobileElement btnCameraCapture;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Submit']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/nextbtn")
	protected MobileElement btnSubmit;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Please choose an account']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='You do not have an eligible account for Mobile Deposit']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Your daily deposit limit is $10,000.00']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/error_txt")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/info_text")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='You do not have an eligible account for Mobile Deposit']")
	protected MobileElement txtAccountError;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/info_text")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[starts-with(@name,'Your daily deposit limit is')]")
	protected MobileElement dailyDepositSix;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='You do not have an eligible account for Mobile Deposit']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='You do not have an eligible account for Mobile Deposit']")
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, 'Sorry, none of your accounts are eligible to use this feature.')]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label, 'Sorry, none of your accounts are eligible to use this feature.  Transfers to Non-Webster Accounts is not available to Business Customers.')]")
	protected MobileElement accountInEligibleErrorMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='You cannot schedule a payment for a weekend or bank holiday.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='You cannot schedule a payment for a weekend or bank holiday.']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Amount must be greater than $0.00']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount must be greater than $0.00']")
	protected MobileElement greaterAmountError;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Please take a back check image']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@text = 'Please take a back check image']")
	protected MobileElement txtBackCheckError;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'To deposit a check, please grant permission for your camera to capture a check image.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Error loading camera. Please check the camera settings for this application and try again.']")
	protected MobileElement txtBackCheckCameraError;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Please take a front check image']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@text = 'Please take a front check image']")
	protected MobileElement txtFrontCheckError;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'To deposit a check, please grant permission for your camera to capture a check image.']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Allow Webster to take pictures and record video?']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Error loading camera. Please check the camera settings for this application and try again.']")
	protected MobileElement txtFrontCheckCameraError;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Continue']")
	protected MobileElement btnContinue;

	@iOSFindBy(xpath = "//XCUIElementTypeTable[1]/XCUIElementTypeCell[1]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Check Back (Click to Capture Image)']")
	protected MobileElement lblSelectAccount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/transfer_information")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected List<RemoteWebElement> transactionDetailsList;

	@AndroidFindBy(xpath = "//*[text()=\"Deposit To\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView")
	protected MobileElement txtDepositTo;

	public String dynamicXpathTitle = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/title'])[%d]";

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Cancel']")
	protected MobileElement btnCancel;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'DEPOSIT DETAILS']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label = 'DEPOSIT DETAILS']")
	protected MobileElement lblContextMenuHead;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='OK']")
	@AndroidFindBy(id = "com.android.packageinstaller:id/permission_allow_button")
	protected MobileElement btnAllow;

	@AndroidFindBy(id = "com.android.packageinstaller:id/permission_deny_button")
	protected MobileElement btnDeny;

	public String toAccountName = "//XCUIElementTypeStaticText[%d] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	public String dynamicXpathAccount = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	public String dropButton = "RemoteDepositsPayToAccountCell";

	boolean status = false;

	/**
	 * Method to EnterAmount in the field
	 * 
	 * @param fromamount
	 * @throws Exception
	 */
	public void enterAmount(String fromAmount) throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				if (mobileActions.verifyIsElementPresent(lblAmountField, 4))
					lblAmountField.click();
				for (int i = 0; i < fromAmount.length(); i++) {
					char c = fromAmount.charAt(i);
					String eachCharacter = new StringBuilder().append(c).toString();
					lblAmountField.sendKeys(eachCharacter);
				}
				LogUtility.logInfo("--->Amount entered as " + fromAmount);
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				lblAmountField.click();
				lblAmountField.sendKeys(fromAmount);
				LogUtility.logInfo("--->Amount entered as " + fromAmount);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter amount in the  Text field<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify terms and conditions page
	 * 
	 * @throws Exception
	 */
	public boolean verifyTermsAndConditionsPage() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnAccept, 4)) {
				LogUtility.logInfo("--->Verified the Terms and Conditions details page");
				return true;
			} else {
				LogUtility.logInfo("--->Unable to Verify the Terms and Conditions details page");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to Verify the Terms and Conditions details page" + e);
			throw e;
		}
	}

	/**
	 * Method To click Deposit Checks
	 */
	public void clickOnDepositChecks() throws Exception {
		try {
			btnCheckDeposits.click();
			LogUtility.logInfo("Succsessfully clicked on Deposit checks button");
			if(mobileActions.verifyIsElementPresent(allowPopUp, 5)) {
				allowPopUp.click();
				LogUtility.logInfo("Succsessfully clicked on allow popup button");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Deposit checks<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Decline Button
	 * 
	 * @throws Exception
	 */
	public void clickOnDeclineButton() throws Exception {
		try {
			btnDecline.click();
			LogUtility.logInfo("Succsessfully clicked on Decline Button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Decline Button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Accept Button
	 * 
	 * @throws Exception
	 */
	public void clickOnAcceptButton() throws Exception {
		try {
			btnAccept.click();
			LogUtility.logInfo("Succsessfully clicked on accept button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Accept Button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to select account error
	 * 
	 * @param message
	 * @return
	 * @throws Exception
	 */
	public boolean verifyTermsAndConditionsErrorMessage(String message) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblTermAndConditionsErrorHead, 4)) {
				return message.equalsIgnoreCase(lblTermAndConditionsErrorHead.getText());
			} else {
				LogUtility.logInfo("Unable to verify Terms and conditions Error Message");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Terms and conditions Error Message: " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify account error message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAccountErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(errorMessage, dailyDepositSix, 10)) {
				LogUtility.logInfo("-->Able to verify Error Message:<--");
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Accounts Error Message: " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify account InEligible Error Message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAccountInEligibleErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(accountInEligibleErrorMessage, 10)) {
				LogUtility.logInfo("available text from app is:" + accountInEligibleErrorMessage.getText());
				return errorMessage.contains(accountInEligibleErrorMessage.getText());
			} else {
				LogUtility.logInfo("Unable to verify account InEligible ErrorMessage ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify account InEligible ErrorMessage" + e.getStackTrace());
			throw e;
		}
	}
	
	/**
	 * Method to verify account error message amount should be enter grater than
	 * zero
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyGreaterAmountErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(errorMessage, greaterAmountError, 10)) {
				LogUtility.logInfo("-->Able to verify Error Message:<--");
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Accounts Error Message:" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify account error message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyDailyLimitErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(errorMessage, dailyDepositSix, 10)) {
				LogUtility.logInfo("-->Able to verify Error Message:<--");
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Accounts Error Message:" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify accounts in a drop down list
	 * 
	 * @param message
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAccountInDropDownList(String message) throws Exception {
		try {
			if(mobileActions.verifyIsElementPresent(btnSubmit, 8)) 
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				// while selecting Account from the list accounts are displaying from index one
				lblToAccountList.get(0).findElement(By.name(dropButton)).click();
				LogUtility.logInfo("-->clicked on account field in ios and size" + lblToAccountList.size());
				int j = 1;
				for (int i = 5; i <= lblToAccountList.size(); i++) {
					String accountName = lblToAccountList.get(i)
							.findElement(By.xpath(String.format(toAccountName, j, j))).getText();
					LogUtility.logInfo("-->Account is displyed in the list of drop down " + accountName + "<--");
					if (message.contains(accountName)) {
						status = true;
						try {
							WebElement dropDownAccount = lblToAccountList.get(i)
									.findElement(By.xpath(String.format(toAccountName, j, j)));
							waits.staticWait(5);
							dropDownAccount.click();
							LogUtility.logInfo("-->drop down clicked<--");
						} catch (Exception e) {
							manageAlertsPage.tapOutsideAlert();
						}
						break;
					}
				}
			} else if (TestDataConstants.getOSPlatformName().contains("android")) {
				depositToField.click();
				LogUtility.logInfo("-->clicked on account field in android");
				// while selecting Account from the list accounts are displaying from index
				for (int i = 0; i <= lblToAccountList.size(); i++) {
					String accountName = lblToAccountList.get(i)
							.findElement(By.xpath(String.format(toAccountName, i + 1, i + 1))).getText();
					LogUtility.logInfo("-->Account is displyed in the list of drop down " + accountName + "<--");
					if (message.contains(accountName)) {
						status = true;
						try {
							WebElement dropDownAccount = lblToAccountList.get(i)
									.findElement(By.xpath(String.format(toAccountName, i + 1, i + 1)));
							dropDownAccount.click();
							LogUtility.logInfo("-->drop down clicked<--");
						} catch (Exception e) {
							manageAlertsPage.tapOutsideAlert();
						}
						break;
					}
				}
			}
			return status;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Accounts in DropDown list" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Back error message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyBackErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(errorMessage, txtBackCheckError, 10)) {
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Accounts in DropDown list" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Front Error Message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyFrontErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(errorMessage, txtFrontCheckError, 4)) {
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Accounts in DropDown list" + e.getStackTrace());
			throw e;
		}

	}

	/**
	 * Method to verify choose account page
	 * 
	 * @param message
	 * @return
	 * @throws Exception
	 */
	public boolean verifyChooseAccountErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(errorMessage, lblChooseAccountError, 4)) {
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Accounts in DropDown list" + e.getStackTrace());
			throw e;
		}

	}

	/**
	 * Method to click on Ok button
	 * 
	 * @throws Exception
	 */
	public void clickOnOkButton() throws Exception {
		try {
			btnOk.click();
			LogUtility.logInfo("Succsessfully clicked on Ok button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Ok Button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Deposit Checks page
	 * 
	 * @throws Exception
	 */
	public boolean verifyDepositChecksPage() throws Exception {
		try {
			if (lstAcceptButton.size() != 0) {
				btnAccept.click();
			}
			if (mobileActions.verifyIsElementPresent(btnDepositACheck, 4)) {
				btnDepositACheck.isEnabled();
				txtDepositCheck.isEnabled();
				LogUtility.logInfo("--->Verified the Details of Deposit checks page");
				return true;
			} else {
				LogUtility.logInfo("--->Unable to verify the Details of Deposit checks page ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the Details of Deposit checks page " + e);
			throw e;
		}
	}

	/**
	 * Method to verify create Deposit Checks page
	 * 
	 * @throws Exception
	 */
	public boolean verifyCreateDepositChecksPage() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblMakeADeposit, 4)) {
				LogUtility.logInfo("--->Verified the Create DepositCheck  page");
				return true;
			} else {
				LogUtility.logInfo("--->Unable to verify the Create Deposit Check page ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the Create Deposit Check page " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Deposit check
	 * 
	 * @throws Exception
	 */
	public void clickOnMakeADeposit() throws Exception {
		try {
			mobileActions.isElementPresent(btnDepositACheck, 10);
			btnDepositACheck.click();
			LogUtility.logInfo("Succsessfully clicked on Make A Deposit button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Make A deposit button");
			throw e;
		}
	}

	/**
	 * Method to EnterAmount in the field
	 * 
	 * @param fromamount
	 * @throws Exception
	 */
	public void captureFrontAndBackCheckImages() throws Exception {
		try {
			lblCheckFrontField.click();
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				btnContinue.click();
			} else if (mobileActions.verifyIsElementPresent(btnCaptureManually, 25)) {
				btnCaptureManually.click();
				btnCameraCapture.click();
			} else if (mobileActions.verifyIsElementPresent(lblAmountField, 25)) {
				lblCheckBackField.click();
			} else if (mobileActions.verifyIsElementPresent(btnCaptureManually, 25)) {
				btnCaptureManually.click();
				btnCameraCapture.click();
			} else if (mobileActions.verifyIsElementPresent(lblAmountField, 25)) {
				btnSubmit.click();
				LogUtility.logInfo("--->succesfully clicked on front and back check images");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to check front field<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on capture front check
	 * 
	 */
	public void captureFrontCheck() throws Exception {
		try {
			lblCheckFrontField.click();
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				if (btnContinue.isEnabled()) {
					btnContinue.click();
					LogUtility.logInfo("User is able to find and click on continue button");
				} else {
					LogUtility.logInfo("User is Unable to find and click on continue button");
				}
			}
			if (mobileActions.verifyIsElementPresent(btnCaptureManually, 25)) {
				btnCaptureManually.click();
				btnCameraCapture.click();
			} else if (mobileActions.verifyIsElementPresent(lblAmountField, 25)) {
				btnSubmit.click();
				LogUtility.logInfo("User is able to take the front check");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to check front field<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * 
	 * Method to click on capture Back check
	 */
	public void captureBackCheck() throws Exception {
		try {
			lblCheckBackField.click();
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				if (mobileActions.verifyIsElementPresent(btnContinue, 6)) {
					btnContinue.click();
					LogUtility.logInfo("User is able to find and click on continue button");
				} else {
					LogUtility.logInfo("User is Unable to find and click on continue button");
				}
			}
			if (mobileActions.verifyIsElementPresent(btnCaptureManually, 25)) {
				btnCaptureManually.click();
				btnCameraCapture.click();
			} else if (mobileActions.verifyIsElementPresent(lblAmountField, 25)) {
				btnSubmit.click();
				LogUtility.logInfo("User is able to take the back check");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to check back field<--- " + e.getStackTrace());
			throw e;
		}

	}

	/**
	 * Method to verify loading camera error page
	 * 
	 * @param errorMessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyLoadingCameraErrorPopup(String errorMessage) throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				if (mobileActions.verificationOfMessage(errorMessage, txtFrontCheckCameraError, 6)) {
					btnAllow.click();
					status = true;
				} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
					if (txtFrontCheckCameraError.getText().contains(CAMERASETTINGS_POPUP)) {
						btnDeny.click();
						clickOnDepositChecks();
						clickOnMakeADeposit();
					}
					if (mobileActions.verificationOfMessage(errorMessage, txtFrontCheckCameraError, 6)) {
						btnAllow.click();
						status = true;
					}
				}
			}
			return status;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Method to return number of transactions displayed in Deposits Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfTransactions() throws Exception {
		try {
			mobileActions.isElementPresent(btnDepositACheck, 10);
			LogUtility.logInfo("Number of accounts  displayed " + lstCheckDepositTranscation.size());
			return lstCheckDepositTranscation.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of transactions listed<---" + e);
			throw e;
		}
	}

	/**
	 * Method to verify check deposit history
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyCheckDepositHistory() throws Exception {
		try {
			List<String> listDeposit = new ArrayList<String>();
			LogUtility.logInfo("Number of Transactions  displayed " + lstCheckDepositTranscation.size());
			for (int i = 1; i <= transactionDetailsList.size(); i++) {
				selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathTitle, i, i))).getText();
				LogUtility.logInfo("Account selected " + selectAccount);
				listDeposit.add(selectAccount);
			}
			LogUtility.logInfo("size of the list is" + listDeposit);
			String replaceTitle = selectAccount.replace("...", "");
			replaceTitle = replaceTitle.replace(")", "");
			int acctLength = replaceTitle.length();
			if (acctLength == 4) {
				LogUtility.logInfo("Account displayed with last four digits " + replaceTitle);
				return true;
			} else {
				LogUtility.logInfo("Account not displayed with last four digits " + replaceTitle);
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Account not displayed with last four digits<---" + e);
			throw e;
		}

	}

	/**
	 * Method to select any transaction that is displayed
	 * 
	 * 
	 * @throws Exception
	 */
	public void clickOnAnyTransation() throws Exception {
		try {
			// while selecting Account from the list accounts are displaying from index one
			for (int i = 1; i <= transactionDetailsList.size(); i++) {
				WebElement clickOnAccount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathTitle, i, i)));
				selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathTitle, i, i))).getText();
				LogUtility.logInfo("transaction selected " + selectAccount);
				if (clickOnAccount.isDisplayed()) {
					clickOnAccount.click();
					break;
				}
			}
			LogUtility.logInfo("clicked on any one of the transaction ");
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Method to verify Front Error Message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyDepositToLabel(String message) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(message, txtDepositTo, 4)) {
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Error Message:" + e);
			throw  e;
		}
	}

	/**
	 * Method to click on any of the Deposit to account
	 * 
	 */
	public void clickOnAnyDepositToAccount() {
		try {
			if (mobileActions.verifyIsElementPresent(btnSubmit, 8))
				if (TestDataConstants.getOSPlatformName().contains("ios")) {
					lblToAccountList.get(0).findElement(By.name(dropButton)).click();
					// After clicking the deposit to field we need to static wait to get loaded the
					// accounts.Here static wait is mandatory because based on the list of accounts
					// it will take time to load accounts.there is no particular element to wait
					// based on the element.So here we used static wait.
					waits.staticWait(3);
					int size = lblToAccountList.size();
					LogUtility.logInfo("size of the accounts list is" + size);
					if (size > 0) {
						// while selecting Account from the list accounts are displaying from index 5th
						// element
						lblToAccountList.get(0).click();
					} else {
						depositToAccount.click();
					}
				} else if (TestDataConstants.getOSPlatformName().contains("android")) {
					depositToField.click();
					lblToAccountList.get(0).click();
				}
			LogUtility.logInfo("clicked on Deposit account ");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on any deposit account" + e);
			throw e;
		}
	}

	/**
	 * Method to click on the context menu
	 * 
	 */
	public void clickOnContextmenu() {
		try {
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				lblToAccountList.get(0).findElement(By.className(dropButton)).click();
				if (mobileActions.verifyIsElementPresent(btnViewDetails, 5)) {
					btnViewDetails.click();
					LogUtility.logInfo("clicked on context menu");
				} else {
					LogUtility.logInfo("Unable to click on context menu");
				}
			} else if (TestDataConstants.getOSPlatformName().contains("android")) {
				lblToAccountList.get(0).click();
				if (mobileActions.verifyIsElementPresent(btnViewDetails, 5)) {
					btnViewDetails.click();
					LogUtility.logInfo("clicked on context menu");
				} else {
					LogUtility.logInfo("Unable to click on context menu");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to click contextt menu" + e);
			throw e;
		}
	}

	/**
	 * Method to click on cancel in ipad device
	 * 
	 */
	public void clickOnCancel() {
		try {
			btnCancel.click();
			LogUtility.logInfo("clicked on Cancel Button ");
		} catch (Exception e) {
			LogUtility.logError("Unable clicked on Cancel Button" + e);
			throw e;
		}
	}

	/**
	 * 
	 * Method to verify weather it is accepting special characters or not
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAmountEntered() throws Exception {
		try {
			if (lblAmountField.getText().contains("0.00")) {
				LogUtility.logInfo("Amount not entered in the field");
				return true;
			} else {
				LogUtility.logInfo("Amount is entered in the field");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify amount entered<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify context menu page
	 * 
	 * @throws Exception
	 */
	public boolean verifyContextMenuPage() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblContextMenuHead, 5)) {
				return true;
			} else {
				LogUtility.logInfo("--->Unable to verify the context Menu page ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to Verify the Details context Menu page" + e.getStackTrace());
			throw e;
		}
	}

	public boolean verifyAllowCameraPopup() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				if (mobileActions.verifyIsElementPresent(btnAllow, 3)) {
					List<MobileElement> passCodeViewElements = new ArrayList<MobileElement>();
					passCodeViewElements.addAll(Arrays.asList(btnAllow, btnDeny));
					btnDeny.click();
					if (mobileActions.verifyIsElementPresent(btnDepositACheck, 4))
						btnDepositACheck.click();
				}
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify allow camera options in the device" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verifying the deposits page title after logged in
	 * 
	 * @throws Exception
	 */
	public void verifyDepositsPageTitle() throws Exception {
		try {
			if (mobileActions.isAlertPresent()) {
				appiumDriver.switchTo().alert().dismiss();
			}
			mobileActions.isElementPresent(txtDepositCheck, 5);
			LogUtility.logInfo("Deposits Title page displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the deposits Title " + e.getStackTrace());
			throw e;
		}
	}

}
