package com.wb.wol_mobile.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.testbases.RetailAppTestBase;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author spothula-adm
 *
 */
public class LoginPage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	SettingsPage settingsPage = new SettingsPage();
	PreferencesPage preferencesPage = new PreferencesPage();

	public LoginPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	public LoginPage(AppiumDriver<RemoteWebElement> customDriver) {
		PageFactory.initElements(new AppiumFieldDecorator(customDriver), this);
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@text='FORGOT PASSCODE']")
	@iOSFindBy(xpath = "//*[@label='Forgot Pin? ']")
	public List<RemoteWebElement> btnLstForgotPasscode;


	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Button[@text='FORGOT PASSCODE']")
	@iOSFindBy(xpath = "//*[@label=\"FORGOT PASSCODE\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@label='Pin Number One of Four']")
	public MobileElement btnPasscodeFieldOne;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/b_revert")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='FORGOT PASSCODE']")
	@iOSFindBy(xpath = "//*[@label='Forgot Pin? ']")
	public MobileElement btnForgotPasscode;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/passcode_view\"]/android.view.View")
	@iOSFindBy(xpath = "//*[@label=\"Pin Number One of Four\"]")
	protected MobileElement radioBtnPasscodeView;

	@AndroidFindBy(xpath = "//*[@resourceid='com.malauzai.websterbank:id/passcode_view']/view")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeTextField")
	protected List<RemoteWebElement> rbtnPasscodeFields;

	/** Provide locator for Android if required **/
	// TODO
	// @AndroidFindBy()
	@iOSFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeTextField")
	protected MobileElement rbtnPasscodeField;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label=\"MENU\"]")
	protected MobileElement menuHead;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeStaticText")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeStaticText[1]")
	protected MobileElement txtInvalidPasscode;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='The maximum allowed Passcode retries have been exceeded. Please create a new one in Passcode Settings.']")
	@iOSFindBy(xpath = "//*[@value=\"The maximum allowed Passcode retries have been exceeded. Please create a new one in Passcode Settings.\"]")
	protected MobileElement txtIncorrectPasscode;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Username and/or password fields cannot be blank']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/textinput_error")
	@iOSFindBy(xpath = "//*[@value=\"Username and/or password fields cannot be blank\"]")
	protected MobileElement txtFieldsCannotBlank;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"We're sorry, but you must first log in to WebsterOnline.com before using Webster Mobile Banking.\"]")
	@iOSFindBy(xpath = "//*[@value=\"We're sorry, but you must first log in to WebsterOnline.com before using Webster Mobile Banking.\"]")
	protected MobileElement txtFirstLogWOL;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"We're sorry, but you do not currently have access to Webster Mobile Banking. Go to WebsterOnline.com.\"]")
	@iOSFindBy(xpath = "//*[@value=\"We're sorry, but you do not currently have access to Webster Mobile Banking. Go to WebsterOnline.com.\"]")
	protected MobileElement txtErrMsgWebLink;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"We are unable to process your request at this time. Please contact us at 800.325.2424, 24 hours a day, 7 days a week.\"]")
	@iOSFindBy(xpath = "//*[@value=\"We are unable to process your request at this time. Please contact us at 800.325.2424, 24 hours a day, 7 days a week.\"]")
	protected MobileElement txtErrMsgInactiveUser;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/iv_logo")
	@iOSFindBy(xpath = "//*[@label='About Us']")
	protected MobileElement logoWebsterBank;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/register_button")
	@iOSFindBy(xpath = "//*[@label=\"Register\"]")
	protected MobileElement btnFirstTimeLogin;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Locations']")
	@iOSFindBy(xpath = "//*[@label=\"Locations\"]")
	protected MobileElement iconLocations;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Webster Bank, N.A. Member FDIC | Equal Housing Lender']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Webster Bank, N.A. Member FDIC | Equal Housing Lender']")
	protected MobileElement txtLegalTermsConditionsContent;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.view.View[@text='Webster Mobile Terms of Service']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Webster Mobile Terms of Service']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Webster Mobile Terms of Service']")
	protected MobileElement txtTermsOfService;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/privacy_text")
	@iOSFindBy(xpath = "//*[@label=\"Privacy Notice\"]")
	protected MobileElement txtPrivacy;

	@AndroidFindBy(xpath = "//android.view.View[@text='Privacy and Opt-Out Notice']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Privacy and Opt-Out Notice']")
	protected MobileElement txtPrivacyOptOutNotice;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='FIND A BANKING CENTER']")
	@iOSFindBy(xpath = "//*[@label=\"FIND A BANKING CENTER\"]")
	protected MobileElement txtFindBankCenter;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.android.packageinstaller:id/permission_allow_button\"]")
	protected MobileElement btnAllow;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/action_search")
	@iOSFindBy(xpath = "//*[@label=\"Search Locations\"]")
	protected MobileElement iconSearchLocations;

	@AndroidFindBy(xpath = "//android.widget.Image[@text='Webster Bank. Living up to you.']")
	@iOSFindBy(xpath = "//XCUIElementTypeImage[@name='Webster Bank. Living up to you.']")
	protected MobileElement imgWebsterWOLMobile;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id=\"login-user__pageTitle_gen\"]")
	@AndroidFindBy(xpath = "//*[@id=\"login-user__pageTitle_gen\"]")
	@AndroidFindBy(xpath = "//*[@value=\"Enter User Name\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Enter User Name']")
	protected MobileElement txtEnterUserNameWOLMobile;

	@AndroidFindBy(xpath = "//android.view.View[@text='User Name']")
	@iOSFindBy(xpath = "//*[@value='User Name']")
	protected MobileElement txtUserNameWOLMobile;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Continue']")
	@iOSFindBy(xpath = "//*[@label=\"Continue\"]")
	protected MobileElement btnContinueWOLMobile;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/username_entry")
	@iOSFindBy(xpath = "//*[@label=\"Username\"]")
	protected MobileElement txtUserName;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/password_entry")
	@iOSFindBy(xpath = "//*[@label='Password']")
	protected MobileElement txtPassword;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/b_submit")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='LOG IN']")
	protected MobileElement btnLogIn;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='VIEW ACCOUNTS']")
	protected MobileElement titleViewAccounts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Verification Question']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Verification Question']")
	protected MobileElement titleAlertQuestion;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='CLOSE']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Close']")
	protected MobileElement btnCloseQuestionAlert;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='OK']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Enter']")
	protected MobileElement btnEnterOKQuestionAlert;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/answer")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView//XCUIElementTypeSecureTextField")
	protected MobileElement txtQAnswerField;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/question")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@value,'?')]")
	protected MobileElement txtQuestion;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//*[@label='OK']")
	@iOSFindBy(xpath = "//*[@label='Ok']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Enter' and @enabled = 'true']")
	public MobileElement btnAlertOk;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Help']")
	@iOSFindBy(xpath = "//*[@label=\"Help\"]")
	protected MobileElement iconHelp;

	@AndroidFindBy(xpath = "//*[text()='800.325.2424']")
	@iOSFindBy(xpath = "//XCUIElementTypeLink[@label=\"800.325.2424\"]")
	protected MobileElement lnkContact;

	@AndroidFindBy(xpath = "//android.widget.EditText[@text='(800) 325-2424']")
	@iOSFindBy(xpath = "//*[@label=\"Call ‭(800) 325-2424‬\"]")
	protected MobileElement optCall;

	@AndroidFindBy(xpath = "//h1[text()='Help']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Help\"]")
	protected MobileElement txtHelp;

	@AndroidFindBy(xpath = "//*[text()='full site']")
	@iOSFindBy(xpath = "//*[@value=\"full site\"]")
	protected MobileElement lnkFullSite;

	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'You have been signed out as you don't have any active accounts. Call 800.325.2424, 24 hours a day, 7 days a week, for more info.']")
	protected MobileElement accountErrorHead;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_auxmenu")
	@iOSFindBy(xpath = "//*[@label=\"Auxiliary Menu\"]")
	protected MobileElement iconAux;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/save_username_toggle")
	@iOSFindBy(xpath = "//*[@label=\"Save Username?\"]")
	protected MobileElement txtSaveUsername;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeStaticText[1]")
	@iOSFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeStaticText")
	protected MobileElement errMessage;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther//XCUIElementTypeStaticText[2]")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeStaticText[2]")
	protected MobileElement errMessageQuestion;

	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'accept']")
	@iOSFindBy(xpath = "//*[@label=\"accept\"]")
	protected List<RemoteWebElement> lstAcceptButton;

	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'decline']")
	@iOSFindBy(xpath = "//*[@label=\"decline\"]")
	protected MobileElement btnDecline;

	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'accept']")
	@iOSFindBy(xpath = "//*[@label=\"accept\"]")
	protected MobileElement btnAccept;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/passcode_view")
	@iOSFindBy(xpath = "//XCUIElementTypeCell/XCUIElementTypeTextField[1]")
	protected MobileElement chkTxtEnterPasscode;

	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.malauzai.websterbank:id/reset_password_button']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Forgot Password']")
	protected MobileElement btnForgotPassword;

	@AndroidFindBy(xpath = "//android.view.View[@text='Reset Password']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Reset Password']")
	protected MobileElement txtResetPassword;

	@AndroidFindBy(xpath = "//android.view.View[@text='Enter your user name']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Enter your user name']")
	protected MobileElement txtEnterYourUserNameResetPassword;

	@AndroidFindBy(xpath = "//android.view.View[@text='Forgot User Name?']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Forgot User Name?']")
	protected MobileElement lnkForgotUserName;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Continue']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Continue']")
	protected MobileElement btnContinueResetPasswordPage;

	@AndroidFindBy(xpath = "//*[@resource-id=\"fieldUsername__input\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField")
	protected MobileElement txtUserNameResetPasswordPage;

	@AndroidFindBy(xpath = "//*[@resource-id=\"answer__input\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField")
	protected MobileElement txtCQAnswerResetPasswordPage;

	@AndroidFindBy(xpath = "//android.view.View[@text='Challenge Question']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Challenge Question']")
	protected MobileElement txtChallengeQuestionResetPasswordPage;

	@AndroidFindBy(xpath = "//android.view.View[@text='Answer your challenge question']")
	@iOSFindBy(xpath = "//*[@label='Answer your challenge question']")
	protected MobileElement txtAnswerChallengeResetPasswordPage;

	@AndroidFindBy(xpath = "//android.view.View[@text='Reset Password Confirmation']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Reset Password Confirmation']")
	protected MobileElement txtResetPasswordConfirmation;

	@AndroidFindBy(xpath = "//android.view.View[@text='Your password has been reset']")
	@iOSFindBy(xpath = "//*[@label='Your password has been reset']")
	protected MobileElement txtPasswordHasReset;

	@AndroidFindBy(xpath = "//android.view.View[@text='Sign in with your temporary password']")
	@iOSFindBy(xpath = "//*[@value='Sign in with your temporary password']")
	protected MobileElement txtSignInTempPassword;

	@iOSFindBy(xpath = "//*[@label='Webster Bank']/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeButton[2]")
	protected MobileElement iconSettings;

	/**
	 * Method to verify the Webster Mobile Login Page
	 * 
	 * @throws Exception
	 */
	public void verifyWebsterMobileLoginPage() throws Exception {
		try {
			mobileActions.isElementPresent(logoWebsterBank, 6);
			LogUtility.logInfo("--->WebsterBank Logo displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Webster Logo is not verified<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify the mobile login username field
	 * 
	 * @throws Exception
	 */
	public void verifyUserNameTextField() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnPasscodeFieldOne, 5)) {
				btnForgotPasscode.click();
				LogUtility.logInfo("--->Forgot Passcode button is displayed<---");
			} else {
				txtUserName.isDisplayed();
				LogUtility.logInfo("--->UserName field is displayed<---");
			}
		} catch (Exception e) {
			LogUtility.logError(
					"--->Unable to verify the Username Text Field or forgotpasscode button<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify the mobile login password
	 * 
	 * @throws Exception
	 */
	public void verifyPasswordTextField() throws Exception {
		try {
			txtPassword.isDisplayed();
			LogUtility.logInfo("--->Password field is displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the Password field<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method verify the mobile login button
	 * 
	 * @throws Exception
	 */
	public void verifyLogInButton() throws Exception {
		try {
			btnLogIn.isDisplayed();
			LogUtility.logInfo("--->LogIn button is displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the logIn Button<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to enter userName in the text field
	 * 
	 * @param userName
	 * @throws Exception
	 */
	public void enterUserName(String userName) throws Exception {
		try {
			txtUserName.clear();
			txtUserName.sendKeys(userName);
			LogUtility.logInfo("--->UserName entered as " + userName);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter Username in Username Text field<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to enter password in the text field
	 * 
	 * @param password
	 * @throws Exception
	 */
	public void enterPassword(String password) throws Exception {
		try {
			txtPassword.clear();
			txtPassword.sendKeys(password);
			LogUtility.logInfo("Password entered");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter Password in password Text field<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to enter answer in the text field
	 * 
	 * @param password
	 * @throws Exception
	 */
	public void enterAnswer(String answer) throws Exception {
		try {
			txtQAnswerField.sendKeys(answer);
			LogUtility.logInfo("--->Answer entered<---" + answer);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter " + answer + " in answer Text field<--- " + e);
			throw e;
		}
	}

	/**
	 * Method to click on log in button and verify logged In or not
	 * 
	 * @throws Exception
	 */
	public void clickLogin() throws Exception {
		try {
			btnLogIn.click();
			if (acceptSecurityAnswer()) {
				if (lstAcceptButton.size() != 0) {
					btnAccept.click();
				}
				if ((mobileActions.verifyIsElementPresent(iconAux, 65))) {
					LogUtility.logInfo("**** Aux button is displayed *****");
				}
			} else {
				try {
					if (lstAcceptButton.size() != 0) {
						btnAccept.click();
					}
					mobileActions.isElementPresent(iconAux, 15);
					LogUtility.logInfo("---> It is navigated to next page<--- ");
				} catch (Exception e) {
					LogUtility.logError("--->Unable verify the Aux button<--- " + e.getStackTrace());
					mobileActions.isElementPresent(iconSettings, 10);
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on LogIn button<--- ");
			throw e;
		}
	}

	/**
	 * Method to clickTerms and conditons
	 * 
	 * @param Status
	 * @throws Exception
	 */
	public void acceptTermsAndConditions(String status) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtTermsOfService, 4)) {
				if (status.equals("accept")) {
					btnAccept.click();
					LogUtility.logInfo("---> Clicked on accept button<--- ");
				} else {
					btnDecline.click();
					LogUtility.logInfo("---> Clicked on Decline button<--- ");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on " + status + " button<--- ");
			throw e;
		}

	}

	/**
	 * Method to verify terms and conditions page
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyTermsAndCondtions() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtTermsOfService, 4)) {
				btnAccept.isEnabled();
				btnDecline.isEnabled();
				LogUtility.logInfo("terms and condtitons are verified successfully");
				return true;
			} else {
				LogUtility.logInfo("Unable to verify terms and condtitons");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify terms and conditons <--- ");
			throw e;
		}

	}

	/**
	 * Method to accept security answer
	 * 
	 * 
	 */
	public boolean acceptSecurityAnswer() {
		boolean flag = false;
		waits.staticWait(12);
		if ((appiumDriver.getPlatformName().equalsIgnoreCase("android"))) {
			try {
				if (mobileActions.verifyIsElementPresent(btnAccept, 4)) {
					btnAccept.click();
					LogUtility.logInfo("**** Acccepted terms and conditions is displayed *****");
				}
				if (titleAlertQuestion.isDisplayed()) {
					LogUtility.logInfo("security question is displayed");
					txtQAnswerField.sendKeys(TestDataConstants.SECURITY_ANSWER);
					btnAlertOk.click();
					mobileActions.isElementPresent(menuHead, 9);
					flag = true;
					return flag;
				} else {
					LogUtility.logInfo("alert question is not displayed");
					return flag;
				}
			} catch (Exception e) {
				LogUtility.logError("--->Unable to handle alert Because Alert is not displayed<--- ");
				return flag;
			}
		} else if ((appiumDriver.getPlatformName().equalsIgnoreCase("ios"))) {
			try {
				if (titleAlertQuestion.isDisplayed()) {
					LogUtility.logInfo("security question is displayed");
					txtQAnswerField.sendKeys(TestDataConstants.SECURITY_ANSWER);
					btnAlertOk.click();
					mobileActions.isElementPresent(logoWebsterBank, 14);
					flag = true;
					return flag;
				} else {
					LogUtility.logInfo("alert question is not displayed");
					return flag;
				}
			} catch (Exception e) {
				LogUtility.logError("--->Unable to get the text since alert is not displayed<--- ");
				return flag;
			}

		}
		LogUtility.logInfo("out of the if else and try catch");
		return flag;
	}

	public boolean verifyNoAccountErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(accountErrorHead, 10)) {
				LogUtility.logInfo("available text from app is:" + accountErrorHead.getText());
				return errorMessage.contains(accountErrorHead.getText());
			} else {
				LogUtility.logInfo("Unable to verify account InEligible ErrorMessage ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("-->Unable to verify list of labels displayed:<--" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on log in button
	 * 
	 * @throws Exception
	 */
	public void clickLoginOnly() throws Exception {
		try {
			btnLogIn.click();
			LogUtility.logInfo("--->Clicked on Login button<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on LogIn button<--- " + e.getStackTrace());
			throw new Exception("Unable to click on LogIn button " + e);
		}
	}

	/**
	 * Method to click on Enter/OK button question popup
	 * 
	 * @throws Exception
	 */
	public void clickEnterOrOK() throws Exception {
		try {
			btnEnterOKQuestionAlert.click();
			LogUtility.logInfo("--->Clicked on Enter/Ok button<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Enter/OK button<--- " + e);
			throw new Exception("Unable to click on Enter/Ok button " + e);
		}
	}

	/**
	 * Method to click on Forgot Passcode button
	 * 
	 * @throws Exception
	 */
	public void clickOnForgotPasscode() throws Exception {
		try {
			if (btnForgotPasscode.isDisplayed()) {
				LogUtility.logInfo("--->Forgot Passcode button is displayed<---");
				btnForgotPasscode.click();
				mobileActions.isElementPresent(txtUserName, 3);
			}
			LogUtility.logInfo("--->Clicked on Forgot Passcode<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Forgot Passcode " + e);
			throw new Exception("Unable to click on Forgot Passcode");
		}
	}

	/**
	 * Methos to verify the passcode view fields displayed
	 * 
	 * @throws Exception
	 */
	public void verifyPasscodeViewDisplayed() throws Exception {
		try {
			List<RemoteWebElement> passCodeViewElements = new ArrayList<RemoteWebElement>();
			passCodeViewElements.addAll(Arrays.asList(btnForgotPasscode));
			mobileActions.elementsPresent(passCodeViewElements);
			LogUtility.logInfo("--->Passcode View is displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to view Passcode grid " + e);
			try {
				LogUtility.logInfo("--->Trying again for Passcode View is displayed<---");
				mobileActions.isElementDisplayed(btnForgotPasscode, 5);
			} catch (Exception ex) {
				throw ex;
			}
		}
	}

	/**
	 * Method to enter the passcode
	 * 
	 * @param passcode
	 * @throws Exception
	 */
	public void enterPasscode(String passcode) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				LogUtility.logInfo("View buttons " + rbtnPasscodeFields.size());
				rbtnPasscodeField.sendKeys(passcode);
			} else {
				mobileActions.isElementPresent(chkTxtEnterPasscode, 5);
				List<MobileElement> enterPasscode = chkTxtEnterPasscode
						.findElements(By.xpath("//*[@class='android.view.View']"));

				for (int i = 0; i < passcode.length(); i++) {
					char passcodeValue = passcode.charAt(i);
					String conVpasscode = Character.toString(passcodeValue);
					enterPasscode.get(i).sendKeys(conVpasscode);
					LogUtility.logInfo("Passcode entered successfully");
				}
			}
			LogUtility.logInfo("--->Entered Passcode successfully");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter the passcode " + e);
			throw new Exception("Unable to enter the passcode " + e);
		}
	}

	/**
	 * Method to verify the passcode error when invalid passcode entered
	 * 
	 * @param passcodeErr
	 * @throws Exception
	 */
	public void validateErrorMsgPasscode(String passcodeErr) throws Exception {
		String errMsg;
		mobileActions.isElementPresent(txtInvalidPasscode, 10);
		try {
			errMsg = txtInvalidPasscode.getText();
			LogUtility.logInfo("Error message " + errMsg);
			if (errMsg == null) {
				for (int i = 1; i <= 5; i++) {
					waits.staticWait(1);
					errMsg = txtInvalidPasscode.getText();
					if (errMsg != null)
						break;
				}
			}
			LogUtility.logInfo("Verified the passcode error when incorrect entered");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the passcode error " + e);
			LogUtility.logInfo("Trying again to get text");
			errMsg = txtInvalidPasscode.getText();
		}
		Assert.assertEquals(errMsg, passcodeErr);
	}

	/**
	 * Method to verify the invalid passcode error message when eneterd third time
	 * 
	 * @param passcodeErr
	 * @throws Exception
	 */
	public void validateErrorMsgPasscodeIncorrect(String passcodeErr) throws Exception {
		try {
			waits.staticWait(3);
			mobileActions.isElementPresent(txtInvalidPasscode, 3);
			String errMsg = txtInvalidPasscode.getText();
			Assert.assertEquals(errMsg, passcodeErr);
			LogUtility.logInfo("Verified the passcode error when incorrect entered for third time " + passcodeErr);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the passcode error when incorrect entered for third time " + e);
			throw new Exception("Unable to verify the passcode error when incorrect entered for third time");
		}
	}

	/**
	 * Method to verify the error message when any login field(Username or password)
	 * left blank
	 * 
	 * @param errMsgBlankField
	 * @throws Exception
	 */
	public void validateErrorMsgFieldBlank(String errMsgBlankField) throws Exception {
		String errMsg;
		mobileActions.isElementPresent(txtFieldsCannotBlank, 5);
		try {
			errMsg = txtFieldsCannotBlank.getText();
			if (errMsg == null) {
				for (int i = 1; i <= 5; i++) {
					waits.staticWait(1);
					errMsg = txtFieldsCannotBlank.getText();
					if (errMsg != null)
						break;
				}
			}
			LogUtility.logInfo("--->Verified the error message when field left blank " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message when field left blank " + e);
			LogUtility.logInfo("Trying again to get text");
			errMsg = txtInvalidPasscode.getText();
		}
		Assert.assertEquals(errMsg, errMsgBlankField);
	}

	/**
	 * Method to verify the error message when user logged in for the first time
	 * 
	 * @param errMsgFirstTime
	 * @throws Exception
	 */
	public void validateErrorMsgFirstTime(String errMsgFirstTime) throws Exception {
		try {
			String errMsg = txtFirstLogWOL.getText();
			Assert.assertEquals(errMsg, errMsgFirstTime);
			LogUtility.logInfo("--->Verified the error message when logged for the first time " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message when logged for the first time " + e);
			throw new Exception("Unable to verify the error message when logged for the first time");
		}
	}

	/**
	 * Method to verify the error message when user logged in with email
	 * notification bounce
	 * 
	 * @param errMsgEmailNotifyBounce
	 * @throws Exception
	 */
	public void validateErrorMsgEmailNotifyBounce(String errMsgEmailNotifyBounce) throws Exception {
		try {
			String errMsg = txtFirstLogWOL.getText();
			Assert.assertEquals(errMsg, errMsgEmailNotifyBounce);
			LogUtility.logInfo("--->Verified the error message when email notification bounce " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message when email notification bounce " + e);
			throw new Exception("Unable to verify the error message when email notification bounce");
		}
	}

	/**
	 * Method to verify the error message when user logged with weblink account
	 * 
	 * @param errMsgWebLink
	 * @throws Exception
	 */
	public void validateErrorMsgWebLink(String errMsgWebLink) throws Exception {
		try {
			String errMsg = txtErrMsgWebLink.getText();
			Assert.assertEquals(errMsg, errMsgWebLink);
			LogUtility.logInfo("--->Verified the error message when logged for the first time " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message when logged for the first time " + e);
			throw new Exception("Unable to verify the error message when logged for the first time");
		}
	}

	/**
	 * Method to verify the error message for inactive user
	 * 
	 * @param errMsgInactive
	 * @throws Exception
	 */
	public void validateErrorMsgInactive(String errMsgInactive) throws Exception {
		try {
			String errMsg = txtErrMsgInactiveUser.getText();
			Assert.assertEquals(errMsg, errMsgInactive);
			LogUtility.logInfo("--->Verified the error message for inactive user " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message for inactive user " + e);
			throw new Exception("Unable to verify the error message for inactive user");
		}
	}

	/**
	 * Method to click on First Time Login?Tap Here button on login page
	 * 
	 * @throws Exception
	 */
	public void clickOnFirstTimeLogin() throws Exception {
		try {
			btnFirstTimeLogin.click();
			LogUtility.logInfo("--->Clicked on First time login? Tap here button<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on First time login? Tap here button " + e);
			throw new Exception("Unable to click on First time login? Tap here button");
		}
	}

	/**
	 * Method to verify the WOL page elements in mobile
	 * 
	 * @throws Exception
	 */
	public void verifyWOLPageMobile() throws Exception {
		try {
			waits.staticWait(5);
			List<RemoteWebElement> wolPageMobileElements = Arrays.asList(imgWebsterWOLMobile, txtEnterUserNameWOLMobile,
					txtUserNameWOLMobile, btnContinueWOLMobile);
			mobileActions.elementsPresent(wolPageMobileElements);
			LogUtility.logInfo("Verified WOL page in mobile");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the WOL page in mobile " + e);
			throw new Exception("Unable to verify the WOL page in mobile");
		}
	}

	/**
	 * Method to click on Locations icon
	 * 
	 * @throws Exception
	 */
	public void clickOnLocations() throws Exception {
		try {
			iconLocations.click();
			LogUtility.logInfo("--->Clicked on locations icon<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on locations icon<--- " + e);
			throw new Exception("Unable to click on locations icon ");
		}
	}

	/**
	 * Method to click on Help option
	 * 
	 * @throws Exception
	 */
	public void clickOnHelp() throws Exception {
		try {
			iconHelp.click();
			LogUtility.logInfo("--->Clicked on Help icon<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Help icon " + e);
			throw new Exception("Unable to click on Help icon");
		}
	}

	/**
	 * Method to click on Locations icon
	 * 
	 * @throws Exception
	 */
	public void verifyLocationsPage() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnAllow, 5))
				btnAllow.click();
			mobileActions.isElementPresent(txtFindBankCenter, 30);
			LogUtility.logInfo("--->Verified Locations Search page<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the locations page " + e);
			throw e;
		}
	}

	/**
	 * Method to verify on Terms and Conditions Content
	 * 
	 * @throws Exception
	 */
	public void verifyTermsAndConditionsContent() throws Exception {
		try {
			txtLegalTermsConditionsContent.isDisplayed();
			txtPrivacy.isDisplayed();
			LogUtility.logInfo("--->Verified T&C content displayed on home page<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Privacy Link " + e);
			throw new Exception("Unable to click on Privacy Link ");
		}
	}

	/**
	 * Method to click on Privacy link
	 * 
	 * @throws Exception
	 */
	public void clickOnPrivacy() throws Exception {
		try {
			txtPrivacy.click();
			LogUtility.logInfo("--->CLicked on Privacy Link<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Privacy Link " + e);
			throw new Exception("Unable to click on Privacy Link ");
		}
	}

	/**
	 * Method to verify on Privacy Opt Out and Notice page text
	 * 
	 * @throws Exception
	 */
	public void verifyPrivacyOptOutNoticePage() throws Exception {
		try {
			mobileActions.isElementPresent(txtPrivacyOptOutNotice, 8);
			LogUtility.logInfo("Verified the Privacy Opt out Notice Page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the page " + e);
			throw new Exception("Unable to verify the page");
		}
	}

	/**
	 * Method to verify the Help Page title
	 * 
	 * @throws Exception
	 */
	public void verifyHelpPageDisplayed() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				mobileActions.switchToWebView();
			}
			mobileActions.isElementPresent(txtHelp, 5);
			LogUtility.logInfo("Verified the Help Page displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the help page " + e);
			throw new Exception("Unable to verify the help page");
		}
	}

	/**
	 * Method to verify the Customer Care number in help page
	 * 
	 * @throws Exception
	 */
	public void verifyContactUSPhNumber() throws Exception {
		try {
			lnkContact.isDisplayed();
			LogUtility.logInfo("Verified the Contact us phone number");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the contact us phone number " + e);
			throw new Exception("Unable to verify the contact us phone number");
		}
	}

	/**
	 * Method to verify Full site link in Help page
	 * 
	 * @throws Exception
	 */
	public void verifyFullSiteLink() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				mobileActions.switchToWebView();
			}
			lnkFullSite.isDisplayed();
			LogUtility.logInfo("Verified the full site link");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the full site link " + e);
			throw new Exception("Unable to verify the full site link");
		}
	}

	/**
	 * Method to click on Contact us in help page
	 * 
	 * @throws Exception
	 */
	public void clickOnContactUs() throws Exception {
		try {
			lnkContact.click();
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				mobileActions.switchToNativeView();
			}
			mobileActions.isElementPresent(optCall, 3);
			LogUtility.logInfo("--->Clicked on Contact us phone number and popup displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click the contact us phone number and popup display " + e);
			throw new Exception("Unable to click the contact us phone number and popup display");
		}
	}

	/**
	 * Method to click on Full site link text
	 * 
	 * @throws Exception
	 */
	public void clickOnFullSite() throws Exception {
		try {
			lnkFullSite.click();
			LogUtility.logInfo("Clicked on full site<---");
			mobileActions.isElementPresent(txtEnterUserNameWOLMobile, 5);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on full site " + e);
			throw new Exception("Unable to click on full site");
		}
	}

	/**
	 * 
	 * Method to verify the Passcode Login enabled
	 * 
	 * @param userName
	 * @param password
	 * @param newPin
	 * @param cnfrmPin
	 * @throws Exception
	 */
	public void veirfyLoginPagePasscodeEnabled(String userName, String password, String newPin, String cnfrmPin)
			throws Exception {
		try {
			if (btnLstForgotPasscode.size() == 0) {
				LogUtility.logInfo("Passcode not enabled");
				enterUserName(userName);
				enterPassword(password);
				clickLogin();
				viewAccountsPage.clickSettingsIcon();
				settingsPage.clickPreferences();
				preferencesPage.setEnablePasscodeLogin();
				preferencesPage.enterPasscode(newPin, cnfrmPin);
				if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
					preferencesPage.btnOK.click();
					mobileActions.isElementPresent(viewAccountsPage.iconSettings, 4);
					viewAccountsPage.clickSettingsIcon();
				} else {
					appiumDriver.navigate().back();
				}
				settingsPage.clickOnLogout();
			}
			LogUtility.logInfo("--->Passcode set<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to set Passcode Pin " + e);
			throw new Exception("Unable to set Passcode Pin " + e);
		}
	}

	public boolean verifySecurityQuestionDisplayed() {
		try {
			if (titleAlertQuestion.isDisplayed())
				return true;
		} catch (WebDriverException e) {
			return false;
		}
		return false;
	}

	/**
	 * Method to verify the Question alert popup
	 * 
	 * @throws Exception
	 */
	public void verifyQuestionPopup() throws Exception {
		try {
			List<RemoteWebElement> questionPopUpElements = new ArrayList<RemoteWebElement>();
			questionPopUpElements.addAll(Arrays.asList(titleAlertQuestion, btnCloseQuestionAlert,
					btnEnterOKQuestionAlert, txtQAnswerField, txtQuestion));
			mobileActions.elementsPresent(questionPopUpElements);
			LogUtility.logInfo("--->Verification question popup is displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Verification question popup is not displayed " + e);
			throw new Exception("Verification question popup is not displayed " + e);
		}
	}

	public void verifySaveUserNameOptionDisabled() throws Exception {
		String saveUserNameValue;
		try {
			txtSaveUsername.isDisplayed();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				saveUserNameValue = txtSaveUsername.getAttribute("checked");
				boolean convSaveUserNameValue = Boolean.valueOf(saveUserNameValue);
				if (convSaveUserNameValue == true) {
					txtSaveUsername.click();
					LogUtility.logInfo("Save Username option is enabled and disabled it now");
				}
			} else {
				saveUserNameValue = txtSaveUsername.getAttribute("value");
				if (saveUserNameValue.equals("selected")) {
					txtSaveUsername.click();
					LogUtility.logInfo("Save Username option is enabled and disabled it now");
				}
			}
			LogUtility.logInfo("Save username option is disbaled");
		} catch (Exception e) {
			LogUtility.logError("Save username option is not disabled " + e);
			throw new Exception("Save username option is not disabled " + e);
		}
	}

	public void clickOnSaveUserNameOption() throws Exception {
		try {
			txtSaveUsername.click();
			LogUtility.logInfo("Clicked on save username option");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on save username option " + e);
			throw new Exception("Unable to click on save username option " + e);
		}
	}

	public void verifyUserNameFieldPreFilled(int firstFourCharacters) throws Exception {
		try {
			txtUserName.isDisplayed();
			String userNamePreFilled = txtUserName.getText();
			LogUtility.logInfo("Username prefilled with " + userNamePreFilled);
			for (int i = 0; i < userNamePreFilled.length(); i++) {
				if (userNamePreFilled.charAt(i) == '*') {
					if (i == firstFourCharacters) {
						break;
					} else {
						throw new Exception("After First Four characters, username is not masked");
					}
				}
			}
			LogUtility.logInfo("Verifed the first four are characters and rest is masked");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the first four are characters and rest is masked " + e);
			throw new Exception("Unable to verify the first four are characters and rest is masked " + e);
		}
	}

	/**
	 * Method Verify ErrorMessage
	 * 
	 * @param errorMessage
	 * @throws Exception
	 */
	public void verifyErrorMessage(String errorMessage) throws Exception {
		mobileActions.isElementPresent(errMessage, 10);
		try {
			waits.staticWait(3);
			String errMsg = errMessage.getText();
			LogUtility.logInfo("Displayed message " + errMsg);
			Assert.assertEquals(errMsg, errorMessage);
			LogUtility.logInfo("Verified the error message " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the error message " + e);
			throw new Exception("Unable to verify the error message " + e);
		}
	}

	public void clickOkButton() throws Exception {
		try {
			btnAlertOk.click();
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Ok button " + e);
			throw new Exception("Unable to click on Ok button " + e);
		}
	}

	/**
	 * Method to verify the passcode view fields are not displayed
	 * 
	 * @throws Exception
	 */
	public void verifyPasscodeViewNotDisplayed() throws Exception {
		try {

			if (mobileActions.verifyIsElementPresent(btnForgotPasscode, 5) == false)
				LogUtility.logInfo("Passcode login is not displayed in Home Screen");
			else
				throw new Exception("Passcode Login is displayed in home screen after disabling the passcode login");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify view Passcode grid is not displayed " + e);
			throw new Exception("Unable to verify view Passcode grid is not displayed " + e);
		}
	}

	public void logInWithUserNamePassword(String userName, String password) throws Exception {
		try {
			String pwd = "";
			String user = "";

			if (userName == null || userName.isEmpty())
				user = "";
			else
				user = RetailAppTestBase.envProps.getProperty(userName);

			if (password == null || password.isEmpty())
				pwd = "";
			else
				pwd = RetailAppTestBase.envProps.getProperty(password);
			try {
				enterUserName(user);
				enterPassword(pwd);
			} catch (Exception e) {
				throw new Exception("Unable to enter the username and password ");
			}
			LogUtility.logInfo("--->UserName and password entered as " + userName);
		} catch (Exception e) {
			LogUtility
					.logError("--->Unable to enter Username in Username Text field/password<--- " + e.getStackTrace());
			throw new Exception("Unable to enter Username in Username Text field/password " + e);
		}
	}

	/**
	 * Method to click on Forgot Password button
	 * 
	 * @throws Exception
	 */
	public void clickForgotPassword() throws Exception {
		try {
			mobileActions.isElementPresent(btnForgotPassword, 5);
			btnForgotPassword.click();
			mobileActions.isElementPresent(lnkForgotUserName, 10);
			LogUtility.logInfo("Clicked on Forgot Password ");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Forgot Password " + e);
			throw new Exception("Unable to click on Forgot Password button " + e);
		}
	}

	public void verifyResetPasswordPage() throws Exception {
		try {
			List<RemoteWebElement> resetPasswordPageElements = Arrays.asList(txtResetPassword,
					txtEnterYourUserNameResetPassword, lnkForgotUserName, btnContinueResetPasswordPage);
			mobileActions.elementsPresent(resetPasswordPageElements);
			LogUtility.logInfo("Verified the reset password page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the reset Password page " + e);
			throw new Exception("Unable to verify the reset password page " + e);
		}
	}

	public void enterUserNameResetPasswordPage(String userName) throws Exception {
		try {
			txtUserNameResetPasswordPage.sendKeys(userName);
			LogUtility.logInfo("Entered Username in reset password page");
		} catch (Exception e) {
			LogUtility.logError("Unable to enter the username in reset password page " + e);
			throw new Exception("Unable to enter the username in reset password page " + e);
		}
	}

	public void verifyChallengeQuestionPage() throws Exception {
		try {
			mobileActions.isElementPresent(txtAnswerChallengeResetPasswordPage, 10);
			List<RemoteWebElement> challengeQuestionPageElements = new ArrayList<RemoteWebElement>();
			challengeQuestionPageElements
					.addAll(Arrays.asList(txtChallengeQuestionResetPasswordPage, txtAnswerChallengeResetPasswordPage));
			mobileActions.elementsPresent(challengeQuestionPageElements);
			LogUtility.logInfo("Verified the challenge question page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the challenge question page " + e);
			throw new Exception("Unable to verify the challenge question page " + e);
		}
	}

	public void enterChallengeQuestionAnswer(String answer) throws Exception {
		try {
			txtCQAnswerResetPasswordPage.sendKeys(answer);
			LogUtility.logInfo("Entered challenge question answer in reset password page");
		} catch (Exception e) {
			LogUtility.logError("Unable to enter the answer for challenge question in reset password page " + e);
			throw new Exception("Unable to enter the answer for challenge question in reset password page " + e);
		}
	}

	public void clickContinueResetPasswordPage() throws Exception {
		try {
			btnContinueResetPasswordPage.click();
			LogUtility.logInfo("Clicked on continue button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on continue button " + e);
			throw new Exception("Unable to click on continue button " + e);
		}
	}

	public void verifyResetPasswordConfirmationPage() throws Exception {
		try {
			mobileActions.isElementPresent(txtSignInTempPassword, 10);
			List<RemoteWebElement> resetPasswordConfirmPageElements = new ArrayList<RemoteWebElement>();
			resetPasswordConfirmPageElements
					.addAll(Arrays.asList(txtResetPasswordConfirmation, txtPasswordHasReset, txtSignInTempPassword));
			mobileActions.elementsPresent(resetPasswordConfirmPageElements);
			LogUtility.logInfo("Verified the reset password confirmation page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the reset password confirmation page " + e);
			throw new Exception("Unable to verify the reset password confirmation page " + e);
		}
	}

	public boolean verifyQuestionPopUpDisplayed() {
		if (mobileActions.verifyIsElementPresent(titleAlertQuestion, 10))
			return true;
		else
			return false;
	}

	public void verifySaveUserNameOptEnabled() throws Exception {
		mobileActions.isElementPresent(txtSaveUsername, 5);
		String saveUserNameStatus;
		if (TestDataConstants.getOSPlatformName().equals("android")) {
			saveUserNameStatus = txtSaveUsername.getAttribute("checked");
			if (!Boolean.parseBoolean(saveUserNameStatus))
				throw new Exception("Save Username option is not enabled in android");
		} else {
			saveUserNameStatus = txtSaveUsername.getAttribute("value");
			if (!saveUserNameStatus.equalsIgnoreCase("selected"))
				throw new Exception("Save username is not enabled in iOS");
		}

	}

	public void verifyQuestionErrorMessage(String errorMessage) throws Exception {
		mobileActions.isElementPresent(errMessageQuestion, 10);
		try {
			waits.staticWait(3);
			String errMsg = errMessageQuestion.getText();
			LogUtility.logInfo("Displayed message " + errMsg);
			Assert.assertEquals(errMsg, errorMessage);
			LogUtility.logInfo("Verified the error message " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the error message " + e);
			throw new Exception("Unable to verify the error message " + e);
		}
	}

}
