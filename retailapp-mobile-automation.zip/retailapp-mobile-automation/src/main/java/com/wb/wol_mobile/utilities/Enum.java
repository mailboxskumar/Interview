package com.wb.wol_mobile.utilities;

public class Enum {
	
	public  enum DIRECTION {
	    DOWN, UP, LEFT, RIGHT;
	}

}
