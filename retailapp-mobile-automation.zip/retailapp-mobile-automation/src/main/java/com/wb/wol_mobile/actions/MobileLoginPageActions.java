package com.wb.wol_mobile.actions;

import com.wb.wol_mobile.pages.LoginPage;
import com.wb.wol_mobile.utilities.ActionsHolder;

public class MobileLoginPageActions {

	ActionsHolder actions;
	LoginPage page;

	public MobileLoginPageActions(ActionsHolder actions) {
		this.actions = actions;
		page = new LoginPage();
	}
}

