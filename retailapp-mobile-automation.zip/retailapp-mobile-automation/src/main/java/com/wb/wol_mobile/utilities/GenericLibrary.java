package com.wb.wol_mobile.utilities;

import java.util.HashMap;
import java.util.Map;

import com.aventstack.extentreports.Status;

import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

public class GenericLibrary {

	public static void reportInfo(String message) {
		ExtentTestManager.getTest().log(Status.INFO, message);
		LogUtility.logInfo(message);
		reportComment(message);
	}

	public static void reportPass(String message) {
		ExtentTestManager.getTest().log(Status.PASS, message);
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message, true);
	}

	public static void reportFail(String message) {
		ExtentTestManager.getTest().log(Status.FAIL, message);
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message, false);
	}

	public static void reportComment(String message) {
		Map<String, Object> params = new HashMap<>();
		params.put("text", message);
		ConcurrentEngines.getEngine().getAppiumDriver().executeScript("mobile:comment", params);
	}

}
