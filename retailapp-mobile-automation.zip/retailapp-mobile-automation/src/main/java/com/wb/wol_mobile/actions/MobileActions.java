package com.wb.wol_mobile.actions;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.utilities.Enum.DIRECTION;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

/**
 * @author MPrasanth-adm..
 *
 */
public class MobileActions extends ObjectBase {

	static SoftAssert softAssert = new SoftAssert();
	MobileElement element;
	@SuppressWarnings("rawtypes")
	TouchAction touchAction;
	private long defaultWaitSeconds = 20;
	RetailAppUtils retailAppUtils = new RetailAppUtils();

	/**
	 * 
	 * Method to scroll based on the values
	 * 
	 * @param startx
	 * @param starty
	 * @param endx
	 * @param endy
	 */
	@SuppressWarnings("rawtypes")
	public void scroll(int startXcoordinate, int startYcoordinate, int endXcoordinate, int endYcoordinate) {
		try {
			TouchAction touchAction = new TouchAction(appiumDriver);
			touchAction.longPress(PointOption.point(startXcoordinate, startYcoordinate))
					.moveTo(PointOption.point(endXcoordinate, endYcoordinate)).release().perform();
		} catch (Exception e) {
			LogUtility.logInfo("Unable to scroll the element :" + e);
		}
	}

	/**
	 * Method to scroll down
	 * 
	 * 
	 */
	public void scrollDown() {
		try {
			// The viewing size of the device
			Dimension size = appiumDriver.manage().window().getSize();
			int startYcoordinate = (int) (size.height * 0.80);// Starting y location set to 80% of the height (near
			int endYcoordinate = (int) (size.height * 0.20);// Ending y location set to 20% of the height (near top)
			int startXcoordinate = (int) size.width / 2;// x position set to mid-screen horizontally
			scroll(startXcoordinate, startYcoordinate, startXcoordinate, endYcoordinate);
			LogUtility.logInfo("It is scroll down to the screen");
		} catch (Exception e) {
			LogUtility.logInfo("Unable to scroll down the element :" + e);
		}
	}

	// waiting for Clicking on a Mobile element
	/**
	 * Method to wait and click element
	 * 
	 * @param elementToClick
	 */
	public void waitAndClickElement(RemoteWebElement elementToClick) {
		String elementName = "";
		try {
			new WebDriverWait(appiumDriver, defaultWaitSeconds).until(ExpectedConditions.visibilityOf(elementToClick));
			elementName = elementToClick.getText();
			elementToClick.click();
			LogUtility.logInfo("Successfully Clicked on element :" + elementName);
		} catch (Exception e) {
			LogUtility.logInfo("Unable to Clicked on element :" + elementName);
		}
	}

	/**
	 * Method to scroll based on the element
	 * 
	 * @param elementName
	 * @param timeout
	 * @param count
	 */
	public void scrollDownToElementPresent(WebElement elementName, int timeout, int count) {
		LogUtility.logInfo("Intiated method for finding Text presence....");
		try {
			for (int i = 0; i < count; i++) {
				if (verifyIsElementPresent(elementName, timeout)) {
					break;
				} else {
					scrollDown();
					if (verifyIsElementPresent(elementName, timeout)) {
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logInfo("Element not present on page " + elementName + e);
		}
	}

	/**
	 * Method to scroll based on the element
	 * 
	 * @param elementName
	 * @param timeout
	 * @param count       Modified as per the latest comments
	 */
	public void scrollUpToElementPresent(WebElement elementName, int timeout, int count) {
		LogUtility.logInfo("Intiated method for finding Text presence....");
		try {
			for (int i = 0; i < count; i++) {
				if (verifyIsElementPresent(elementName, timeout)) {
					break;
				} else {
					scrollDown();
					if (verifyIsElementPresent(elementName, timeout)) {
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logInfo("Element not present on page for scroll up method " + elementName + e);
		}
	}

	/**
	 * Method to verify is Element Present
	 * 
	 * @param elementName
	 * @param timeout
	 * @throws Exception
	 */
	public void isElementPresent(WebElement elementName, int timeout) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(appiumDriver, timeout);
			wait.until(ExpectedConditions.visibilityOf(elementName));
			LogUtility.logInfo("--->Element is found<--- " + elementName);
		} catch (Exception e) {
			LogUtility.logError("--->Element not present on page " + e.getStackTrace());
			throw new Exception("Element not present on page " + elementName + " " + e);
		}
	}

	/**
	 * Method to verify is Element Present String parameter
	 * 
	 * 
	 * @param elementName
	 * @param timeout
	 * @throws Exception
	 */
	public void isElementPresentReplaceText(String elementName, int timeout) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(appiumDriver, timeout);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(elementName)));
			LogUtility.logInfo("--->Element is found<--- " + elementName);
		} catch (Exception e) {
			LogUtility.logError("--->Element not present on page " + e.getStackTrace());
			throw new Exception("Element not present on page " + elementName + " " + e);
		}
	}

	/**
	 * Method to verify is Element Not Present
	 * 
	 * @param lblOpportunityChecking
	 * @param timeout
	 * @throws Exception
	 */
	public void isElementNotPresent(By by, int timeout) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(appiumDriver, 15);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
		} catch (Exception e) {
			LogUtility.logError("--->Element not present on page " + e.getStackTrace());
			throw new Exception("Element not present on page " + by + " " + e);
		}
	}

	/**
	 * Method to verify is element present
	 * 
	 * @param elementName
	 * @param timeout
	 * @return
	 * @throws Exception Modified return statement true based on the comments
	 */
	public boolean verifyIsElementPresent(WebElement elementName, long timeout) {
		try {
			if (timeout > defaultWaitSeconds) {
				timeout = defaultWaitSeconds;
				WebDriverWait wait = new WebDriverWait(appiumDriver, timeout);
				wait.until(ExpectedConditions.visibilityOf(elementName));
				return true;
			} else {
				WebDriverWait wait = new WebDriverWait(appiumDriver, timeout);
				wait.until(ExpectedConditions.visibilityOf(elementName));
				LogUtility.logInfo("--->Element is found<--- " + elementName);
				return true;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Element not present on page " + e.getStackTrace());
			return false;
		}
	}

	/**
	 * Method to swipe based on the direction
	 * 
	 * @param mobiledriver
	 * @param direction
	 * @param time
	 */
	@SuppressWarnings("rawtypes")
	public static void swipe(DIRECTION direction, int time) {
		try {
			Dimension size = ConcurrentEngines.getEngine().getAppiumDriver().manage().window().getSize();
			int startXcoordinate = 0;
			int endXcoordinate = 0;
			int startYcoordinate = 0;
			int endYcoordinate = 0;
			switch (direction) {
			case RIGHT:
				startYcoordinate = (int) (size.height / 2);
				startXcoordinate = (int) (size.width * 0.90);
				endXcoordinate = (int) (size.width * 0.05);
				new TouchAction(ConcurrentEngines.getEngine().getAppiumDriver())
						.press(PointOption.point(startXcoordinate, startYcoordinate))
						.waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
						.moveTo(PointOption.point(startXcoordinate, startYcoordinate)).release().perform();
				LogUtility.logInfo("Swipe action is successfully done to RIGHT direction");
				break;
			case LEFT:
				startYcoordinate = (int) (size.height / 2);
				startXcoordinate = (int) (size.width * 0.05);
				endXcoordinate = (int) (size.width * 0.90);
				new TouchAction(ConcurrentEngines.getEngine().getAppiumDriver())
						.press(PointOption.point(startXcoordinate, startYcoordinate))
						.waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
						.moveTo(PointOption.point(endXcoordinate, startYcoordinate)).release().perform();
				LogUtility.logInfo("Swipe action is successfully done to LEFT direction");
				break;
			case UP:
				endYcoordinate = (int) (size.height * 0.70);
				startYcoordinate = (int) (size.height * 0.30);
				startXcoordinate = (size.width / 2);
				new TouchAction(ConcurrentEngines.getEngine().getAppiumDriver())
						.press(PointOption.point(startXcoordinate, startYcoordinate))
						.waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
						.moveTo(PointOption.point(endXcoordinate, startYcoordinate)).release().perform();
				LogUtility.logInfo("Swipe action is successfully done to UP direction");
				break;
			case DOWN:
				startYcoordinate = (int) (size.height * 0.70);
				endYcoordinate = (int) (size.height * 0.30);
				startXcoordinate = (size.width / 2);
				new TouchAction(ConcurrentEngines.getEngine().getAppiumDriver())
						.press(PointOption.point(startXcoordinate, startYcoordinate))
						.waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
						.moveTo(PointOption.point(startXcoordinate, endYcoordinate)).release().perform();
				LogUtility.logInfo("Swipe action is successfully done to DOWN direction");
				break;
			}
		} catch (Exception e) {
			LogUtility.logInfo("Unable to swipe the element :" + e);
		}
	}

	// Performing Drag and Drop operation
	/**
	 * Method to drag and drop the element from one to another location
	 * 
	 * @param startPosition
	 * @param endPostion
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public void dragAndDrop(WebElement startPosition, WebElement endPosition) {
		try {
			int startXcoordinate = startPosition.getLocation().getX();
			int startYcoordinate = startPosition.getLocation().getY();

			int endXcoordinate = endPosition.getLocation().getX();
			int endYcoordinate = endPosition.getLocation().getY();

			TouchAction action = new TouchAction(appiumDriver);
			LogUtility.logInfo("It Is dragging element.");
			action.longPress(PointOption.point(startXcoordinate, startYcoordinate))
					.moveTo(PointOption.point(endXcoordinate, endYcoordinate)).release().perform();
			LogUtility.logInfo("Element has been dropped at destination successfully.");
		} catch (Exception e) {
			LogUtility.logInfo("Unable to drag and drop the element :" + e);
		}
	}

	/**
	 * Method to get the screen resolution
	 * 
	 * @return
	 */
	private Dimension getScreenResolution() {
		Dimension resolution = appiumDriver.manage().window().getSize();
		return resolution;
	}

	/**
	 * Method to swipe horizontal
	 * 
	 * @param direction
	 * @throws Throwable
	 */
	public void swipeHorizontal(String direction) throws Throwable {
		if (element == null) {
			throw new Throwable(": Mobile Actions : Element is null");
		} else {
			try {
				Dimension size = getScreenResolution();
				int rightDimension = (int) (size.width * 0.20);// point which is at right side of screen
				int leftDimension = (int) (size.width * 0.80);// point which is at left side of screen.
				switch (direction.toUpperCase()) {
				case "RIGHT":
					touchAction
							.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(element)))
							.moveTo(PointOption.point(rightDimension, 580)).release().perform();
					break;
				case "LEFT":
					touchAction
							.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(element)))
							.moveTo(PointOption.point(leftDimension, 580)).release().perform();
					break;
				}
			} catch (Throwable t) {
				LogUtility.logError("Exception in swipeHorizontal method " + t.getLocalizedMessage());
				throw t;
			}
		}
	}

	/**
	 * Method to verify message based on the element and text
	 * 
	 * @param errormsg
	 * @param elementName
	 * @param timeout
	 * @return
	 */
	public boolean verificationOfMessage(String errorMsg, MobileElement elementName, int timeout) {
		try {
			if (verifyIsElementPresent(elementName, timeout))
				LogUtility.logInfo(
						"expected error text is:" + errorMsg + ":text from the application" + elementName.getText());
			elementName.isEnabled();
			return errorMsg.equalsIgnoreCase(elementName.getText());
		} catch (Exception e) {
			LogUtility.logError("-->Unable to verify  Error Message:<--" + e.getStackTrace());
		}
		return false;
	}

	/**
	 * @param element
	 * @param timeout Verify Element to enabled or not
	 */
	public void waitForElementEnabled(RemoteWebElement element, final long timeout) {
		try {
			new WebDriverWait(appiumDriver, timeout).until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception e) {
			LogUtility.logError("popup element not found in thread" + e.getStackTrace());
		}
	}

	/**
	 * 
	 * Method to scrollUp
	 * 
	 */
	public void scrollUp() {
		try {
			// The viewing size of the device
			Dimension size = appiumDriver.manage().window().getSize();
			int startXcoordinate = size.width / 2;
			int startYcoordinate = (int) (size.height * 0.70);
			int endYcoordinate = (int) (size.height * 0.40);
			scroll(startXcoordinate, endYcoordinate, startXcoordinate, startYcoordinate);
			LogUtility.logInfo("It is scroll up to the screen");
		} catch (Exception e) {
			LogUtility.logInfo("Unable to scroll up the element :" + e);
		}
	}

	/**
	 * Method to select clickAndEnterText based on the element and string text
	 * 
	 * @param element
	 * @param Text
	 * @throws Throwable
	 */
	public void clickAndEnterText(MobileElement element, String Text) throws Throwable {
		try {
			if (element == null) {
				throw new Throwable(": Mobile Actions : Element is null");
			} else {
				element.click();
				element.clear();
				element.sendKeys(Text);
				LogUtility.logInfo("Successfully entered text :" + Text);
			}
		} catch (Exception e) {
			LogUtility.logError("Failed to enter text for ");
			throw new Throwable(": Mobile Actions : unable to find the element");
		}
	}

	/**
	 * Method to select dropdownvalue based on the element and string text
	 * 
	 * @param dropdown
	 * @param Text
	 * @throws Throwable
	 */
	public void selectDropdownValue(MobileElement dropDown, String Text) throws Throwable {
		try {
			if (dropDown == null) {
				throw new Throwable(": Mobile Actions : Element is null");
			} else {
				dropDown.click();
				Select selectValue = new Select(dropDown);
				selectValue.selectByVisibleText(Text);
				LogUtility.logInfo("Succesfully selected a value from dropDown value: " + Text);
			}
		} catch (Exception e) {
			LogUtility.logInfo("Unable to select the Dropdown value..");
			throw new Throwable(": Mobile Actions : unable to find the element in dropdown");
		}
	}

	/**
	 * Method to verify element isDisplayed or not
	 * 
	 * @param element
	 * @param withinMilliseconds
	 * @return
	 */
	public boolean isElementDisplayed(RemoteWebElement element, int withinMilliSeconds) {
		try {
			return element.isDisplayed();
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * Method to verify list of elements
	 * 
	 * @param data
	 * @throws Exception
	 */
	public void elementsPresent(List<RemoteWebElement> data) throws Exception {
		try {
			for (RemoteWebElement elementPresent : data) {
				Boolean elementStatus = isElementDisplayed(elementPresent, 2);
				softAssert.assertTrue(elementStatus, " Element " + elementPresent);
			}
			softAssert.assertAll();
		} catch (AssertionError x) {
			throw new Exception("Few of the elements on page are not found  " + x);
		}
	}

	/**
	 * Method to closed the app
	 */
	public static void closeApplication() {
		try {
			ConcurrentEngines.getEngine().getAppiumDriver().closeApp();
			LogUtility.logInfo("Mobile app is closed d successfully");
		} catch (Exception e) {
			LogUtility.logInfo("Unable to closed the Mobile app ");
		}
	}

	/**
	 * Method to start the app
	 */
	public static void startApplication() {
		try {
			ConcurrentEngines.getEngine().getAppiumDriver().launchApp();
			LogUtility.logInfo("Mobile app is start successfully");
		} catch (Exception e) {
			LogUtility.logInfo("Unable to start the Mobile app ");
		}
	}

	/**
	 * Method to Hide the keyboard
	 * 
	 * @throws Exception
	 */
	public void hideKeyBoard() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				appiumDriver.navigate().back();
				LogUtility.logInfo("Keyboard hidden");
			} else {
				ConcurrentEngines.getEngine().getAndroidDriver().hideKeyboard();
				LogUtility.logInfo("Keyboard hidden android");
			}
		} catch (Exception e) {
			throw new Exception("Keyboard is not hidden " + e);
		}
	}

	/**
	 * Method to verify is alert present
	 * 
	 * @return
	 * @throws InterruptedException
	 */
	public boolean isAlertPresent() throws InterruptedException {
		boolean foundAlert = false;
		WebDriverWait wait = new WebDriverWait(appiumDriver, 5);
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			foundAlert = true;
		} catch (WebDriverException e) {
			foundAlert = false;
		}
		return foundAlert;
	}

	/**
	 * Method to verify valuenotpresent
	 * 
	 * @param element
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public boolean verifyValueNotPresent(MobileElement element, String value) throws Exception {
		try {
			String textPresent = element.getText();
			if (textPresent.equals(value)) {
				LogUtility.logInfo(value + " entered in text field");
				return true;
			} else {
				LogUtility.logInfo(value + " did not entered in the text field");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Element provided is not available " + e);
			throw new Exception("Element provided is not available " + e);
		}
	}

	/**
	 * Method to verify text present
	 * 
	 * @param data
	 * @throws Exception
	 */
	public boolean verifyTextValuePresent(MobileElement element, String value) throws Exception {
		boolean textStatus = false;
		try {
			String textPresent = element.getText();
			if (textPresent.equals(value)) {
				LogUtility.logInfo(value + " entered in text field");
				textStatus = true;
			} else {
				textStatus = false;
			}
			return textStatus;
		} catch (Exception x) {
			throw new Exception("Few of the elements on page are not found  " + x);
		}
	}

	public void switchToWebView() {
		waits.staticWait(3);
		Set<String> contextNames = appiumDriver.getContextHandles();
		for (String contextName : contextNames) {
			LogUtility.logInfo("contextNames " + contextName);
			if (contextName.equals("WEBVIEW_1")) {
				appiumDriver.context(contextName);
				break;
			}
			appiumDriver.context("NATIVE_APP");
		}
	}
	
	public void switchToNativeView() {
		waits.staticWait(3);
		Set<String> contextNames = appiumDriver.getContextHandles();
		for (String contextName : contextNames) {
			LogUtility.logInfo("contextNames " + contextName);
			if (contextName.equals("NATIVE_APP")) {
				appiumDriver.context(contextName);
				break;
			}
			appiumDriver.context("WEBVIEW_1");
		}
	}

	public void swipeUpUntilTextExists(RemoteWebElement expected, int times) {
		int i = 0;
		do {
			swipeUp();
			i++;
			if (i == times)
				break;
		} while (!isElementDisplayed(expected, 100));
	}

	@SuppressWarnings("rawtypes")
	public void swipeUp() {
		Dimension size = appiumDriver.manage().window().getSize();
		int starty = (int) (size.height * 0.8);
		int endy = (int) (size.height * 0.2);
		int startx = (int) (size.width / 2.2);
		try {
			LogUtility.logInfo(
					"Trying to swipe up from x:" + startx + " y:" + starty + ", to x:" + startx + " y:" + endy);
			new TouchAction(appiumDriver).press(PointOption.point(startx, starty))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1300)))
					.moveTo(PointOption.point(startx, endy)).release().perform();
		} catch (Exception e) {
			LogUtility.logInfo("Swipe did not complete succesfully.");
		}
	}

	@SuppressWarnings("rawtypes")
	public void swipeDown() {
		Dimension size = appiumDriver.manage().window().getSize();
		int starty = (int) (size.height * 0.8);
		int endy = (int) (size.height * 0.2);
		int startx = (int) (size.width / 2.2);
		try {
			LogUtility.logInfo(
					"Trying to swipe down from x:" + startx + " y:" + endy + ", to x:" + startx + " y:" + starty);
			new TouchAction(appiumDriver).press(PointOption.point(startx, endy))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1300)))
					.moveTo(PointOption.point(startx, starty)).release().perform();
		} catch (Exception e) {
			LogUtility.logInfo("Swipe did not complete succesfully.");
		}
	}
}
