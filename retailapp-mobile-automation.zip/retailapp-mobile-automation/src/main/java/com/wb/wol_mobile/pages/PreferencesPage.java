package com.wb.wol_mobile.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

public class PreferencesPage extends ObjectBase {
	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	SettingsPage settingsPage = new SettingsPage();
	CommonPage commonPage = new CommonPage();

	public PreferencesPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_personalize")
	@iOSFindBy(xpath = "//*[@label=\"Preferences\"]")
	protected MobileElement txtPreferences;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='PREFERENCES']")
	@iOSFindBy(xpath = "//*[@label=\"PREFERENCES\"]")
	protected MobileElement titlePreferences;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Enable Passcode Login']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Passcode Login']")
	protected MobileElement btnEnablePasscodeLogin;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Disable Passcode Login']")
	protected MobileElement btnDisablePasscodeLogin;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Disable Passcode Login']")
	protected List<RemoteWebElement> lstDisablePasscodeLogin;

	@AndroidFindBy(xpath = "//android.widget.Switch[@text='OFF']")
	@iOSFindBy(xpath = "//*[@label=\"Passcode Login\" and @value=\"0\"]")
	protected MobileElement swtPasscodeToogleOn;

	@AndroidFindBy(xpath = "//android.widget.Switch[@text='OFF']")
	@iOSFindBy(xpath = "//*[@label=\"Passcode Login\" and @value=\"0\"]")
	protected List<RemoteWebElement> lstPasscodeToogleOn;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Switch[@text='ON']")
	@iOSFindBy(xpath = "//*[@label=\"Passcode Login\" and @value=\"1\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch[@value='1']")
	protected MobileElement swtPasscodeToogleOff;

	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'Instead of logging on with your username and password')]")
	protected MobileElement contentPasscode;

	@iOSFindBy(xpath = "//*[@label=\"Confirm\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='ACCEPT']")
	protected MobileElement btnConfirm;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='ACCEPT']")
	protected MobileElement btnAccept;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='DECLINE']")
	@iOSFindBy(xpath = "//XCUIElementTypeAlert//*[@label='Close']")
	protected MobileElement btnDecline;

	@iOSFindBy(xpath = "//*[@label=\"OK\"]")
	protected MobileElement btnOK;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Create New Passcode']")
	protected MobileElement titleCreatePasscode;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter Passcode Digits']")
	@iOSFindBy(xpath = "//*[@label=\"Please enter your Passcode below.\"]")
	protected MobileElement txtEnterPasscode;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Confirm Passcode Digits']")
	@iOSFindBy(xpath = "//*[@label=\"Confirm your Passcode below.\"]")
	protected MobileElement txtConfirmPasscode;

	@iOSFindBy(xpath = "//XCUIElementTypeCell/XCUIElementTypeTextField")
	protected MobileElement txtPasscodeFields;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/passcode_view")
	@iOSFindBy(xpath = "//XCUIElementTypeCell/XCUIElementTypeTextField[1]")
	protected MobileElement chkTxtEnterPasscode;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/passcode_view")
	protected List<RemoteWebElement> btnEnterPasscode;

	@AndroidFindBy(xpath = "//*[@class='android.view.View']")
	protected List<MobileElement> btnViewPasscode;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/confirm_passcode_view")
	@iOSFindBy(xpath = "//XCUIElementTypeCell/XCUIElementTypeTextField")
	protected MobileElement chkTxtConfirmPasscode;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='The Passcode you chose is too common, please choose another.']")
	@iOSFindBy(xpath = "//*[@value=\"The Passcode you chose is too common, please choose another.\"]")
	protected MobileElement errMessageCommonPin;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Passcode Enabled']")
	@iOSFindBy(xpath = "//*[@value=\"Passcode Enabled\"]")
	protected MobileElement txtPasscodeEnabled;

	@iOSFindBy(xpath = "//*[@value='Passcode Login']")
	protected MobileElement txtPasscodeLogin;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Close']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_cancel")
	protected MobileElement btnAccountClose;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_accept")
	protected MobileElement btnSave;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/preceding-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstAccountsName;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/preceding-sibling::XCUIElementTypeCell")
	protected MobileElement accountNames;

	public String xpathAccountName = "//XCUIElementTypeCollectionView/child::XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Last Visited' and @enabled='true']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Last Visited' and @enabled ='true']")
	protected MobileElement lblLastVisited;

	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/passcode_view']/android.view.View[1]")
	protected List<RemoteWebElement> lstEnterPasscode;

	MobileActions mobileActions = new MobileActions();

	List<RemoteWebElement> listOfButtons = new ArrayList<RemoteWebElement>();

	/**
	 * Enable Passcode Login. If Passcode toogle is on disable and enable the
	 * passcode again
	 * 
	 * @throws Exception
	 */
	public void clickEnablePasscodeLogin() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				if (lstDisablePasscodeLogin.size() != 0) {
					btnDisablePasscodeLogin.click();
					mobileActions.isElementPresent(btnEnablePasscodeLogin, 4);
					btnEnablePasscodeLogin.click();
				} else {
					btnEnablePasscodeLogin.click();
				}
			} else {
				mobileActions.isElementPresent(txtPasscodeLogin, 5);
				if (lstPasscodeToogleOn.size() != 0) {
					(swtPasscodeToogleOn).click();
				} else {
					swtPasscodeToogleOff.click();
					btnOK.click();
					settingsPage.clickSettingsIcon();
					settingsPage.clickPreferences();
					swtPasscodeToogleOn.click();
				}
			}
			LogUtility.logInfo("--->Clicked on Enable Passcode Login");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on " + e);
			throw e;
		}
	}

	/**
	 * Method to validate the Passcode content
	 * 
	 * @param content
	 * @throws Exception
	 */
	public void verifyPasscodeContent(String content) throws Exception {
		try {
			String passcodecontent = contentPasscode.getText();
			Assert.assertEquals(passcodecontent, content);
			LogUtility.logInfo("Verified the passcode content " + passcodecontent);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the passcode content " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Confirm button
	 * 
	 * @throws Exception
	 */
	public void clickOnConfirm() throws Exception {
		try {
			btnConfirm.click();
			LogUtility.logInfo("--->Clicked on confirm<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click " + e);
			throw e;
		}
	}

	/**
	 * Method to set passcode login
	 * 
	 * @throws Exception
	 */
	public void setEnablePasscodeLogin() throws Exception {
		try {
			clickEnablePasscodeLogin();
			mobileActions.isElementPresent(contentPasscode, 4);
			clickOnConfirm();
		} catch (Exception e) {
			LogUtility.logError("Unable toset Passcode Login " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Accept button
	 * 
	 * @throws Exception
	 */
	public void clickOnAccept() throws Exception {
		try {
			btnAccept.click();
			LogUtility.logInfo("--->Clicked on accept<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Decline button
	 * 
	 * @throws Exception
	 */
	public void clickOnDecline() throws Exception {
		try {
			btnDecline.click();
			LogUtility.logInfo("--->Clicked on decline<---");
		} catch (NoSuchElementException e) {
			LogUtility.logError("--->Unable to click " + e);
			throw e;
		}
	}

	/**
	 * Method to verify the passcode popup elements
	 * 
	 * @param createPasscodeTitle
	 * @param enterPasscode
	 * @param confirmPasscode
	 * @param enterPasscodeiOS
	 * @param cnfrmPasscodeiOS
	 * @throws Exception
	 */
	public void verifyCreatePasscodePopup(String createPasscodeTitle, String enterPasscode, String confirmPasscode,
			String enterPasscodeiOS, String cnfrmPasscodeiOS) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				String createPasscode = titleCreatePasscode.getText();
				Assert.assertEquals(createPasscode, createPasscodeTitle);

				String enterPasscodeTxt = txtEnterPasscode.getText();
				Assert.assertEquals(enterPasscodeTxt, enterPasscode);

				String cnfrmPasscodeTxt = txtConfirmPasscode.getText();
				Assert.assertEquals(cnfrmPasscodeTxt, confirmPasscode);
			} else {
				String enterPasscodeios = txtEnterPasscode.getText();
				Assert.assertEquals(enterPasscodeios, enterPasscodeiOS);

				String cnfrmPasscodeios = txtConfirmPasscode.getText();
				Assert.assertEquals(cnfrmPasscodeios, cnfrmPasscodeiOS);
			}
			LogUtility.logInfo("--->Verified the passcode popup elements<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the passcode popup elements " + e);
			throw e;
		}
	}

	/**
	 * Method to enter passcode
	 * 
	 * @param newPin
	 * @param cnfrmPin
	 * @throws Exception
	 */
	public void enterPasscode(String newPin, String cnfrmPin) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				/**
				 * Commented this below code, getting cast exception when implemented this way
				 * List<MobileElement> enterPasscode = chkTxtEnterPasscode.findElements((By)
				 * rbtnViewPasscode); List<MobileElement> confirmPasscode =
				 * chkTxtConfirmPasscode.findElements((By) rbtnViewPasscode);
				 **/
				List<MobileElement> enterPasscode = chkTxtEnterPasscode
						.findElements(By.xpath("//*[@class='android.view.View']"));

				List<MobileElement> confirmPasscode = chkTxtConfirmPasscode
						.findElements(By.xpath("//*[@class='android.view.View']"));
				int enterPinLength = newPin.length();
				int confirmPinLength = cnfrmPin.length();
				for (int i = 0; i < enterPinLength; i++) {
					char passcodeValue = newPin.charAt(i);
					String passcode = Character.toString(passcodeValue);
					enterPasscode.get(i).sendKeys(passcode);
					LogUtility.logInfo("Passcode entered successfully");
				}
				for (int j = 0; j < confirmPinLength; j++) {
					// confirmPasscode.get(j).click();
					char cnfrmPasscodeValue = cnfrmPin.charAt(j);
					String cPasscode = Character.toString(cnfrmPasscodeValue);
					confirmPasscode.get(j).sendKeys(cPasscode);
					LogUtility.logInfo("Confirm Passcode entered successfully");
				}
			} else {
				chkTxtEnterPasscode.sendKeys(newPin);
				chkTxtConfirmPasscode.sendKeys(cnfrmPin);
			}
			waits.staticWait(2);
			LogUtility.logInfo("Entered pin successfully");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter " + newPin + ", " + cnfrmPin + ", " + e);
			throw e;
		}
	}

	/**
	 * 
	 * Method to validate the error message when common pin entered
	 * 
	 * @param errMsgCommonPin
	 * @throws Exception
	 */
	public void validateErrMessageCommonPin(String errMsgCommonPin) throws Exception {
		try {
			String errMsg = errMessageCommonPin.getText();
			Assert.assertEquals(errMsg, errMsgCommonPin);
			LogUtility.logInfo("Verified the error message for common pin " + errMsgCommonPin);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message " + e);
			throw e;
		}
	}

	/**
	 * Method to verify the passcode login button
	 * 
	 * @throws Exception
	 */
	public void verifyPasscodeLoginButton() throws Exception {
		try {
			btnEnablePasscodeLogin.isDisplayed();
			LogUtility.logInfo("Passcode Login button displayed");
		} catch (NoSuchElementException e) {
			LogUtility.logError("--->Unable to verify the Passcode Login Button and trying again<---");
			if (lstDisablePasscodeLogin.size() != 0) {
				btnDisablePasscodeLogin.click();
				btnEnablePasscodeLogin.isDisplayed();
			}
			throw e;
		}
	}

	/**
	 * Method to validate the Passcode alert
	 * 
	 * @param alertMsg
	 * @throws Exception
	 */
	public void validatePasscodeAlert(String alertMsg) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				String alert = txtPasscodeEnabled.getText();
				Assert.assertEquals(alert, alertMsg);
				LogUtility.logInfo("-->Validated the passcode has set succesfully<---");
				btnOK.click();
			} else {
				txtPasscodeEnabled.isDisplayed();
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to validate the passcode has set succesfully " + e);
			throw e;
		}
	}

	public void verifyPreferencesPage() throws Exception {
		try {
			mobileActions.isElementPresent(titlePreferences, 5);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Preferences page is displayed " + e);
			throw e;
		}
	}

	public void clickDisablePasscodeLogin() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				btnDisablePasscodeLogin.isDisplayed();
				btnDisablePasscodeLogin.click();
				btnEnablePasscodeLogin.isDisplayed();
			} else {
				if (mobileActions.verifyIsElementPresent(viewAccountsPage.iconSettings, 10)) {
					viewAccountsPage.iconSettings.click();
					LogUtility.logInfo("Settings Icon clicked");
					mobileActions.isElementPresent(txtPreferences, 4);
					txtPreferences.click();
					mobileActions.isElementPresent(txtPasscodeLogin, 5);
					swtPasscodeToogleOff.click();
					btnOK.click();
				}
			}
			LogUtility.logInfo("--->Clicked on Disable Passcode Login");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on " + e);
			throw e;
		}
	}

	public void verifyChangeAccountOrderButtons() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				List<RemoteWebElement> changeAccountOrderButtons = new ArrayList<RemoteWebElement>();
				changeAccountOrderButtons.addAll(Arrays.asList(btnAccountClose, btnSave));
				mobileActions.elementsPresent(changeAccountOrderButtons);
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the change account order buttons " + e);
			throw e;
		}
	}

	/**
	 * Method to return number of accounts displayed in Alerts Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfAccountsInChangeAccountOrder() throws Exception {
		try {
			mobileActions.isElementPresent(accountNames, 10);
			LogUtility.logInfo("Number of accounts  displayed " + lstAccountsName.size());
			return lstAccountsName.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of accounts listed in change account order<---" + e);
			throw e;
		}
	}

	/**
	 * Method to get list of accounts displayed in Under change accountOrder
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<String> verifyAccountsUnderChangeAccountOrder() throws Exception {
		try {
			List<String> accts = new ArrayList<String>();
			for (RemoteWebElement liElement : lstAccountsName) {
				LogUtility.logInfo("account name is" + liElement.getText());
				accts.add(liElement.getText());
			}
			return accts;
		} catch (Exception e) {
			LogUtility
					.logError("--->Unable to get the accounts listed in change account order<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify CLOSE and SAVE buttons are displayed or not
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifySaveAndCloseButtons() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnSave, 5)) {
				listOfButtons.addAll(Arrays.asList(btnSave, btnAccountClose));
				mobileActions.elementsPresent(listOfButtons);
				LogUtility.logInfo(" verified all the Buttons are displayed ");
				return true;
			} else {
				LogUtility.logInfo("Unable to verify buttons are displayed on the change account order page");
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void tapOnSetStartPageSetting(String label) throws Exception {
		commonPage.clickAccount(label);
	}
}
