package com.wb.wol_mobile.actions;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebElement;

import com.wb.java_af.engine.Navigator;
import com.wb.java_af.engine.Waits;
import com.wb.java_af.engine.WebActions;
import com.wb.java_af.parameters.JsonDataParser;
import com.wb.java_af.reporting.ReportLibrary;
import com.wb.java_af.setup.ConcurrentEngines;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class ObjectBase {
	
	protected static ConcurrentMap<String, String> runtimeDataMap = new ConcurrentHashMap<>();

	public AppiumDriver<RemoteWebElement> appiumDriver = ConcurrentEngines.getEngine().getAppiumDriver();
	public AndroidDriver<RemoteWebElement> androidDriver = ConcurrentEngines.getEngine().getAndroidDriver();
	public IOSDriver<RemoteWebElement> iosDriver = ConcurrentEngines.getEngine().getIosDriver();
	public WebDriver webDriver = ConcurrentEngines.getEngine().getWebDriver();

	public WebActions webActions = ConcurrentEngines.getEngine().getWebActions();
	public Waits waits = ConcurrentEngines.getEngine().getWait();
	public Navigator navigator = ConcurrentEngines.getEngine().getNavigator();

	public JsonDataParser jsonDataParser = ConcurrentEngines.getEngine().getJsonDataParser();
	public Map<String, String> testDataMap = ConcurrentEngines.getEngine().getJsonDataParser().getTestDataMap();

	public ReportLibrary reportLibrary = ConcurrentEngines.getEngine().getReportLibrary();
	
	public void reportInfo(String message) {
		reportLibrary.reportInfo(message);
	}

	public void reportPass(String message) {
		reportLibrary.reportPass(message);
	}

	public void reportPass(String message, boolean flag) {
		reportLibrary.reportPass(message, flag);
	}

	public void reportFail(String message) {
		reportLibrary.reportFail(message);
	}

	public void reportFail(String message, boolean flag) {
		reportLibrary.reportFail(message, flag);
	}

	public void reportHardFail(String message) {
		reportLibrary.reportHardFail(message);
	}

	public void reportHardFail(String message, boolean flag) {
		reportLibrary.reportHardFail(message);
	}
	
	public String getValueFromRuntimeDataMap(String key) {
		return runtimeDataMap.get(key);
	}

	public void setValueInRuntimeDataMap(String key, String value) {
		runtimeDataMap.put(key, value);
	}
	
}
