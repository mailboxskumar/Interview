package com.wb.wol_mobile.pages;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

public class FilterPage extends ObjectBase {

	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	ManageAlertsPage manageAlertsPage = new ManageAlertsPage();
	MobileActions mobileActions = new MobileActions();
	RetailAppUtils retailAppUtils = new RetailAppUtils();

	public FilterPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']")
	protected MobileElement optFilterAmount;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']")
	protected List<RemoteWebElement> lstOptFilterAmount;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Date Range']")
	protected MobileElement optFilterDate;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Type']")
	protected MobileElement optFilterType;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='OFF']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='Off']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']/following-sibling::XCUIElementTypeSwitch[@value='0']")
	protected MobileElement swtToogleAmountOff;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='OFF']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='Off']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']/following-sibling::XCUIElementTypeSwitch[@value='0']")
	protected List<RemoteWebElement> lstSwitchToogleAmountOff;

	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.malauzai.websterbank:id/txt_value']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name = 'filterAmountFieldFromAccessibilityIdentifier' and @enabled ='true']")
	protected MobileElement lblAmountFromField;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id='com.malauzai.websterbank:id/grp_amount_hi']/android.widget.EditText")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name = 'filterAmountFieldToAccessibilityIdentifier' and @enabled ='true']")
	protected MobileElement lblAmountToField;

	@iOSFindBy(xpath = "//*[@name=\"Done\"]")
	protected MobileElement btnDoneKeyboard;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='OFF']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='Off']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Date Range']/following-sibling::XCUIElementTypeSwitch[@value='0']")
	protected MobileElement swtToogleDateOff;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='OFF']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='Off']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Date Range']/following-sibling::XCUIElementTypeSwitch[@value='0']")
	protected List<RemoteWebElement> lstSwitchToogleDateOff;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Date Range']")
	@iOSFindBy(xpath = "//*[@name=\"filterTableViewAccessibilityIdentifier\"]/XCUIElementTypeCell[5]/XCUIElementTypeStaticText[1]")
	protected MobileElement optDateRange;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Starts']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Starts']")
	protected MobileElement txtDateStarts;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Ends')]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Ends']")
	protected MobileElement txtDateEnds;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Starts']/following-sibling::android.widget.TextView")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Starts']/following-sibling::XCUIElementTypeStaticText")
	protected MobileElement txtDateStartsField;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Ends')]/following-sibling::android.widget.TextView")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Ends']/following-sibling::XCUIElementTypeStaticText")
	protected MobileElement txtDateEndsField;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Switch[@text='OFF']")
	@AndroidFindBy(xpath = "//android.widget.Switch[@text='Off']")
	@iOSFindBy(xpath = "//*[@label=\"Empty list\"]/XCUIElementTypeOther/XCUIElementTypeSwitch", priority = 1)
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch[@value='0']")
	protected List<RemoteWebElement> swtToogleOff;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='OFF']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='Off']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Type']/following-sibling::XCUIElementTypeSwitch[@value='0']")
	protected MobileElement swtToogleTypeOff;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='OFF']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='Off']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Type']/following-sibling::XCUIElementTypeSwitch[@value='0']")
	protected List<RemoteWebElement> lstSwitchToogleTypeOff;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='ON']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected MobileElement swtToogleAmountOn;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='ON']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Date Range']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected MobileElement swtToogleDateOn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='ON']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='On']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Type']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected List<RemoteWebElement> lstSwitchToogleTypeOn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='ON']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Type']/following-sibling::android.widget.Switch[@text='On']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Type']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected MobileElement swtToogleTypeOn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='ON']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='On']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Date']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected List<RemoteWebElement> lstSwitchToogleDateOn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='ON']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Date']/following-sibling::android.widget.Switch[@text='On']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Date']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected MobileElement switchToogleDateOn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='ON']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='On']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected List<RemoteWebElement> lstSwitchToogleAmountOn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='ON']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']/following-sibling::android.widget.Switch[@text='On']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected MobileElement switchToogleAmountOn;

	@iOSFindBy(xpath = "//*[@label='Clear']")
	protected MobileElement btnClearFilter;

	@iOSFindBy(xpath = "//*[@label='Done']")
	protected MobileElement btnDoneFilter;

	@iOSFindBy(xpath = "//*[@label='OK']")
	protected MobileElement btnOk;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Apply']")
	protected MobileElement btnApply;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Last Seven Days']")
	@iOSFindBy(xpath = "//*[@label='Last Seven Days']")
	protected MobileElement optLastSevenDays;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Last Seven Days']/following-sibling::android.widget.CheckBox")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Last Seven Days']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='checkmark']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Last Seven Days']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='More Info']")
	protected MobileElement optLastSevenDaysSelected;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Credit']/following-sibling::android.widget.CheckBox")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Credit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='More Info']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Credit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='checkmark']")
	protected MobileElement optCreditDeSelected;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Debit']/following-sibling::android.widget.CheckBox")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Debit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='More Info']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Debit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='checkmark']")
	protected MobileElement optDebitDeSelected;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Credit']/following-sibling::android.widget.CheckBox")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Credit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='More Info']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Credit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='checkmark']")
	protected List<RemoteWebElement> lstOptCreditDeSelected;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Debit']/following-sibling::android.widget.CheckBox")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Debit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='More Info']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Debit']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='checkmark']")
	protected List<RemoteWebElement> lstOptDebitDeSelected;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Credit']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Credit']")
	protected MobileElement optCredit;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Debit']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Debit']")
	protected MobileElement optDebit;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/calendar_date_display")
	protected MobileElement txtCalenderMonth;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Last Fourteen Days']")
	@iOSFindBy(xpath = "//*[@label='Last Fourteen Days']")
	protected MobileElement optLastFourteenDays;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Month to Date']")
	@iOSFindBy(xpath = "//*[@label='Month to Date']")
	protected MobileElement optMonthToDate;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Last Fourteen Days']/following-sibling::android.widget.CheckBox")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Last Fourteen Days']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='More Info']")
	protected MobileElement optLastFourteenDaysSelected;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Month to Date']/following-sibling::android.widget.CheckBox")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Month to Date']/following-sibling::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton[@label='More Info']")
	protected MobileElement optMonthToDateSelected;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Specific Date']")
	@iOSFindBy(xpath = "//*[@label='Specific Date']")
	protected MobileElement optSpecificDate;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='No Items Available']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Invalid Filter Criteria: Please, select a higher 'To' amount.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='No Items Available']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Invalid filter criteria: Please, select a higher ‘To’ amount']")
	protected MobileElement txtAmountError;
	
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/snackbar_text\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Invalid filter criteria: Please, select a higher ‘To’ amount']")
	protected MobileElement errInvalidFilter;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/selected_day_of_month_date")
	protected MobileElement dateCalendar;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/button_ok")
	protected MobileElement btnOkCalendar;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/txt_value")
	protected MobileElement txtSpecificDateValue;

	public String startDate;
	public String endDate;
	SimpleDateFormat formatiOS = new SimpleDateFormat("MM-dd-yyyy");
	public static Date dateStart;
	public static Date dateEnd;
	public static String toAmount;
	public static Date specifcDateSelected;
	DecimalFormat decimalFormat = new DecimalFormat(".00");

	/**
	 * Method to click on Clear button for IOS
	 * 
	 * @throws Exception
	 */
	public void clickOnClear() throws Exception {
		try {
			btnClearFilter.click();
			LogUtility.logInfo("Clicked on clear button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Clear " + e);
			throw new Exception("Unable to click on clear " + e);
		}
	}

	/**
	 * Method to click on Done button for IOS
	 * 
	 * @throws Exception
	 */
	public void clickOnDone() throws Exception {
		try {
			btnDoneFilter.click();
			LogUtility.logInfo("Clicked on done button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Done " + e);
			throw new Exception("Unable to click on Done " + e);
		}
	}

	/**
	 * Method to click on Apply button in Android
	 * 
	 * @throws Exception
	 */
	public void clickOnApply() throws Exception {
		try {
			btnApply.click();
			LogUtility.logInfo("Clicked on Apply button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Apply " + e);
			throw new Exception("Unable to click on Apply " + e);
		}
	}

	/**
	 * Method to verify the all Filter options available
	 * 
	 * @throws Exception
	 */
	public void verifyFilterOptions() throws Exception {
		try {
			List<RemoteWebElement> filterOptionsElements = Arrays.asList(optFilterAmount, optFilterDate, optFilterType);
			mobileActions.elementsPresent(filterOptionsElements);
			LogUtility.logInfo("Filter options verified that are displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the filter options " + e);
			throw new Exception("Unable to verify the filter options " + e);
		}
	}

	/**
	 * Method to click on Amount Range in filter pane
	 * 
	 * @throws Exception
	 */
	public void tapOnAmountRange() throws Exception {
		try {
			mobileActions.isElementPresent(optFilterAmount, 3);
			if (lstSwitchToogleAmountOff.size() != 0) {
				swtToogleAmountOff.click();
			} else {
				swtToogleAmountOn.click();
				swtToogleAmountOff.click();
			}
			mobileActions.isElementPresent(lblAmountFromField, 4);
			LogUtility.logInfo("Clicked on Type filter");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Type filter " + e);
			throw new Exception("Unable to click on Type filter " + e);
		}
	}

	/**
	 * Method to Enter From Amount in amount range filter option
	 * 
	 * @param fromAmount
	 * @throws Exception
	 */
	public void enterFromAmount(String fromAmount) throws Exception {
		try {
			lblAmountFromField.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				for (int i = 0; i < fromAmount.length(); i++) {
					char c = fromAmount.charAt(i);
					String eachCharacter = new StringBuilder().append(c).toString();
					lblAmountFromField.sendKeys(eachCharacter);
				}
				mobileActions.hideKeyBoard();
			} else {
				lblAmountFromField.sendKeys(fromAmount);
			}
			LogUtility.logInfo("--->Amount entered as " + fromAmount);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter amount in the From Text field<--- " + e.getStackTrace());
			throw new Exception("Unable to enter Amount in the From Text field " + e);
		}
	}

	/**
	 * Method to enter the amount To field in amount range option
	 * 
	 * @param toAmount
	 * @throws Exception
	 */
	public void enterToAmount(String toAmount) throws Exception {
		try {
			mobileActions.verifyIsElementPresent(lblAmountToField, 6);
			lblAmountToField.click();
			lblAmountToField.sendKeys(toAmount);
			LogUtility.logInfo("--->Amount entered as " + toAmount);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				btnDoneKeyboard.click();
			} else {
				appiumDriver.navigate().back();
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter amount in the To Text field<--- " + e.getStackTrace());
			throw new Exception("Unable to enter Amount in the To Text field " + e);
		}
	}

	/**
	 * Method to click on Date Range filter option
	 * 
	 * @throws Exception
	 */
	public void tapOnDateRange() throws Exception {
		try {
			mobileActions.isElementPresent(optFilterDate, 3);
			if (lstSwitchToogleDateOff.size() != 0) {
				swtToogleDateOff.click();
			} else {
				swtToogleDateOn.click();
				swtToogleDateOff.click();
			}
			mobileActions.isElementPresent(optLastSevenDays, 4);
			LogUtility.logInfo("Clicked on Date Range filter");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Date Range filter " + e);
			throw new Exception("Unable to click on Date Range filter " + e);
		}
	}

	/**
	 * 
	 * Method to click on Last seven days option in date range filter option
	 * 
	 * @throws Exception
	 */
	public void tapOnLastSevenDays() throws Exception {
		try {
			mobileActions.isElementPresent(optLastSevenDays, 3);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				optLastSevenDays.click();
				/** Commenting for no due to locator issue and raised defect #6933 **/
				mobileActions.isElementPresent(optLastSevenDaysSelected, 3);
			} else {
				String selected = optLastSevenDaysSelected.getAttribute("checked");
				boolean b = Boolean.parseBoolean(selected);
				if (b == false) {
					optLastSevenDaysSelected.click();
				}
			}
			LogUtility.logInfo("Clicked on Last seven days option");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Last seven days filter " + e);
			throw new Exception("Unable to click on Last seven days filter " + e);
		}
	}

	/**
	 * Method to click on Type filter option in filter pane
	 * 
	 * @throws Exception
	 */
	public void tapOnType() throws Exception {
		try {
			mobileActions.isElementPresent(optFilterType, 3);
			if (lstSwitchToogleTypeOff.size() != 0) {
				swtToogleTypeOff.click();
			} else {
				swtToogleTypeOn.click();
				swtToogleTypeOff.click();
			}
			mobileActions.isElementPresent(optCredit, 4);
			LogUtility.logInfo("Clicked on Type filter");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Type filter " + e);
			throw new Exception("Unable to click on Type filter " + e);
		}
	}

	/**
	 * Method to set OFF the Type option in filter pane
	 * 
	 * @throws Exception
	 */
	public void tapOffType() throws Exception {
		try {
			mobileActions.isElementPresent(optFilterType, 3);
			if (lstSwitchToogleTypeOn.size() != 0) {
				swtToogleTypeOn.click();
			}
			LogUtility.logInfo("Clicked on Type filter to Off");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Type filter " + e);
			throw new Exception("Unable to click on Type filter " + e);
		}
	}

	/**
	 * Method to set OFF the Date option in filter pane
	 * 
	 * @throws Exception
	 */
	public void tapOffDate() throws Exception {
		try {
			mobileActions.isElementPresent(optFilterType, 3);
			if (lstSwitchToogleDateOn.size() != 0) {
				switchToogleDateOn.click();
			}
			LogUtility.logInfo("Clicked on Date filter to Off");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Date filter " + e);
			throw new Exception("Unable to click on Date filter " + e);
		}
	}

	/**
	 * Method to set OFF the Amount option in filter pane
	 * 
	 * @throws Exception
	 */
	public void tapOffAmount() throws Exception {
		try {
			mobileActions.isElementPresent(optFilterType, 3);
			if (lstSwitchToogleAmountOn.size() != 0) {
				switchToogleAmountOn.click();
			}
			LogUtility.logInfo("Clicked on Amount filter to Off");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Amount filter " + e);
			throw new Exception("Unable to click on Amount filter " + e);
		}
	}

	/**
	 * Method to verify the Type options like Debit and Credit
	 * 
	 * @throws Exception
	 */
	public void verifyTypeOptions() throws Exception {
		try {
			List<RemoteWebElement> typeOptionsElements = new ArrayList<RemoteWebElement>();
			typeOptionsElements.addAll(Arrays.asList(optCredit, optCreditDeSelected, optDebitDeSelected, optDebit));
			mobileActions.elementsPresent(typeOptionsElements);
			LogUtility.logInfo("Verified the type options");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the options " + e);
			throw new Exception("Unable to verify the options " + e);
		}
	}

	/**
	 * Method to set Credit to OFF
	 * 
	 * @throws Exception
	 */
	public void tapOnCredit() throws Exception {
		try {
			mobileActions.isElementPresent(optCredit, 3);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				optCredit.click();
				/** Commenting this code due to locator issue and raised defect #6933 **/
				 if (lstOptCreditDeSelected.size() != 0) { throw new
				 Exception("Credit option is still On"); }
			} else {
				String selected = optCreditDeSelected.getAttribute("checked");
				boolean b = Boolean.parseBoolean(selected);
				if (b == true) {
					optCreditDeSelected.click();
				}
			}
			LogUtility.logInfo("--->Clicked on Credit option to off<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Credit option to off " + e);
			throw new Exception("Unable to click on Credit option to off " + e);
		}
	}

	/**
	 * Method to set Debit to OFF
	 * 
	 * @throws Exception
	 */
	public void tapOnDebit() throws Exception {
		try {
			mobileActions.isElementPresent(optDebit, 3);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				optDebit.click();
				if (lstOptDebitDeSelected.size() != 0) {
					throw new Exception("Debit option is still On");
				}
			} else {
				String selected = optDebitDeSelected.getAttribute("checked");
				boolean b = Boolean.parseBoolean(selected);
				if (b == true) {
					optDebitDeSelected.click();
				}
			}
			LogUtility.logInfo("--->Clicked on Debit option to off<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Debit option to off " + e);
			throw new Exception("Unable to click on Debit option to off " + e);
		}
	}

	/**
	 * Method to clear the filters by clicking Clear in iOS and navigate back in
	 * Android
	 * 
	 * @throws Exception
	 */
	public void clearFilters() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				btnClearFilter.click();
				waits.staticWait(2);
				if (!(swtToogleOff.size() >= 3))
					throw new Exception("Filters not deselected");
				btnDoneFilter.click();
			} else {
				appiumDriver.navigate().back();
				viewAccountsPage.clickOnFilterIcon();
				if (swtToogleOff.size() != 3)
					throw new Exception("Filters not deselected");
				appiumDriver.navigate().back();
			}
			waits.staticWait(1);
			if (lstOptFilterAmount.size() != 0) {
				throw new Exception("Filter Option page is still displayed");
			}
			LogUtility.logInfo("--->Cleared all filters<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to clear filter due to " + e);
			throw new Exception("Unabele to clear filter due to " + e);
		}
	}

	/**
	 * Method to verify all filters Enabled
	 * 
	 * @throws Exception
	 */
	public void filtersEnabled() throws Exception {
		try {
			viewAccountsPage.clickOnFilterIcon();
			if (swtToogleOff.size() == 3)
				throw new Exception("All filters deselcted");
			LogUtility.logInfo("--->Filters enabled<---");
		} catch (Exception e) {
			LogUtility.logError("--->Filters not enabled " + e);
			throw new Exception("Filters not enabled " + e);
		}
	}

	/**
	 * Method to click on Done/Apply button
	 * 
	 * @throws Exception
	 */
	public void clickOnDoneApply() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				btnApply.click();
			} else {
				btnDoneFilter.click();
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to click on done/ apply button " + e);
			throw new Exception("Unable to click on done/ apply button " + e);
		}
	}

	/**
	 * Method to verify amount error message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAmountErrorMessage(String errormessage) throws Exception {
		try {
			if (mobileActions.verificationOfMessage(errormessage, txtAmountError, 5)) {
				btnOk.click();
				return true;
			} else {
				LogUtility.logInfo("-->Unable to verify Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			throw new Exception("Unable to verify Accounts Error Message: " + e);
		}

	}
	

	public void verifyInvalidFilterCriteria(String errorFilter) throws Exception {
		retailAppUtils.fluentWaitElement(errInvalidFilter, 6, 1);
		String txtInvalidFilter = errInvalidFilter.getText();
		if(!errorFilter.equals(txtInvalidFilter))
			throw new Exception();
		btnOk.click();
	}

	public void tapOnDateRangeOption() throws Exception {
		try {
			optDateRange.click();
			mobileActions.isElementPresent(txtDateStarts, 5);
			LogUtility.logInfo("Clicked on Date Range option");
		} catch (Exception e) {
			LogUtility.logError("Unable to clickd on Date Range option " + e);
			throw new Exception("Unable to clickd on Date Range option " + e);
		}
	}

	public void verifyDateFromToDisplayed() throws Exception {
		try {
			List<RemoteWebElement> dateFromToFieldElements = Arrays.asList(txtDateStarts, txtDateEnds);
			mobileActions.elementsPresent(dateFromToFieldElements);
			LogUtility.logInfo("Verified the Date From and To fields");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the Date From, To fields " + e);
			throw new Exception("Unable to verify the Date From, To fields " + e);
		}
	}

	public void verifyTransactionDates() throws Exception {
		try {
			int isStartDatExists, isEndDatExists;
			startDate = txtDateStartsField.getText();
			endDate = txtDateEndsField.getText();
			dateStart = retailAppUtils.parse(startDate, retailAppUtils.simpleDateFormat);
			dateEnd = retailAppUtils.parse(endDate, retailAppUtils.simpleDateFormat);

			LogUtility.logInfo("Size" + viewAccountsPage.sortDatesGetFirstLastDates().size());
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {

				isStartDatExists = retailAppUtils.parse(startDate, retailAppUtils.simpleDateFormat)
						.compareTo(retailAppUtils.parse(viewAccountsPage.sortDatesGetFirstLastDates().get(0),
								retailAppUtils.simpleDateFormat));
				if (isStartDatExists == 0) {
					LogUtility.logInfo("Starts Date is defualt date as transaction history");
				} else {
					throw new Exception("Start date is not default date as transaction history");
				}
			} else {
				Date start = formatiOS.parse(viewAccountsPage.sortDatesGetFirstLastDates().get(0));
				if (dateStart.compareTo(start) == 0) {
					LogUtility.logInfo("Start date is default date as transaction history");
					isStartDatExists = 0;
				} else {
					throw new Exception("Start date is not default date as transaction history");
				}
			}
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {

				isEndDatExists = retailAppUtils.parse(endDate, retailAppUtils.simpleDateFormat)
						.compareTo(retailAppUtils.parse(
								viewAccountsPage.sortDatesGetFirstLastDates()
										.get(viewAccountsPage.sortDatesGetFirstLastDates().size() - 1),
								retailAppUtils.simpleDateFormat));
				if (isEndDatExists == 0) {
					LogUtility.logInfo("End Date is defualt date as transaction history");
				} else {
					throw new Exception("End date is not default date as transaction history");
				}
			} else {
				Date end = formatiOS.parse(viewAccountsPage.sortDatesGetFirstLastDates()
						.get(viewAccountsPage.sortDatesGetFirstLastDates().size() - 1));
				if (dateEnd.compareTo(end) == 0) {
					LogUtility.logInfo("End date is default date as transaction history");
					isEndDatExists = 0;
				} else {
					throw new Exception("End Date is not defualt date as transaction history");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the default date " + e);
			throw new Exception("Unable to verify the default date " + e);
		}
	}

	/**
	 * Method to verify all filters Disabled
	 * 
	 * @throws Exception
	 */
	public void filtersDisabled(int filtersCount) throws Exception {
		try {
			if (!(swtToogleOff.size() >= filtersCount))
				throw new Exception("All filters are not disabled");
			LogUtility.logInfo("--->All three Filters Disabled<---");
		} catch (Exception e) {
			LogUtility.logError("--->Filters not disabled " + e);
			throw new Exception("Filters not disabled " + e);
		}
	}

	public void selectDateOnCalender() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				appiumDriver.navigate().back();
				mobileActions.isElementPresent(btnClearFilter, 5);
			} else {
				mobileActions.isElementPresent(txtDateStartsField, 5);
				txtDateStartsField.click();
				mobileActions.isElementPresent(txtCalenderMonth, 5);
				appiumDriver.navigate().back();
			}
//			TODO: Need to select the date range
			LogUtility.logInfo("Date selected as ");
		} catch (Exception e) {
			LogUtility.logError("Date not selected on calender " + e);
			throw new Exception("Date not selected on calender " + e);
		}
	}

	public void enterGetFromAmount() throws Exception {
		try {
			lblAmountFromField.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				for (int i = 0; i < ViewAccountsPage.amounts.get(0).length(); i++) {
					char c = ViewAccountsPage.amounts.get(0).charAt(i);
					String eachCharacter = new StringBuilder().append(c).toString();
					lblAmountFromField.sendKeys(eachCharacter);
				}
			} else {
				lblAmountFromField.sendKeys(ViewAccountsPage.amounts.get(0).replace(".", ""));
			}
			LogUtility.logInfo("Entered amount in From field");
		} catch (Exception e) {
			LogUtility.logError("Unable to enter the amount in from field " + e);
			throw new Exception("Unable to enter the amount in from field " + e);
		}
	}

	public void enterGetToAmount() throws Exception {
		try {
			double addAmount = 1.00;
			lblAmountToField.click();
			String amount = ViewAccountsPage.amounts.get(0).replace("$", "").replace("-", "").replace(",", "");
			double convAmount = Double.parseDouble(amount) + addAmount;
			toAmount = decimalFormat.format(convAmount);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				for (int i = 0; i < toAmount.length(); i++) {
					char c = toAmount.charAt(i);
					String eachCharacter = new StringBuilder().append(c).toString();
					lblAmountToField.sendKeys(eachCharacter);
				}
			} else {
				lblAmountToField.sendKeys(toAmount.replace(".", ""));
			}
			LogUtility.logInfo("Entered amount in From field as " + toAmount);
		} catch (Exception e) {
			LogUtility.logError("Unable to enter the amount in from field " + e);
			throw new Exception("Unable to enter the amount in from field " + e);
		}
	}

	/**
	 * Method to click on Last fourteen days option in date range filter option
	 * 
	 * @throws Exception
	 */
	public void tapOnLastFourteenDays() throws Exception {
		try {
			mobileActions.isElementPresent(optLastFourteenDays, 3);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				optLastFourteenDays.click();
				/** Commenting for no due to locator issue and raised defect #6933 **/
				// mobileActions.isElementPresent(optLastFourteenDaysSelected, 3);
			} else {
				String selected = optLastFourteenDaysSelected.getAttribute("checked");
				boolean b = Boolean.parseBoolean(selected);
				if (b == false) {
					optLastFourteenDaysSelected.click();
				}
			}
			LogUtility.logInfo("Clicked on Last fourteen days option");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Last fourteen days filter " + e);
			throw new Exception("Unable to click on Last fourteen days filter " + e);
		}
	}

	/**
	 * Method to click on Month to date option in date range filter option
	 * 
	 * @throws Exception
	 */
	public void tapOnMonthToDate() throws Exception {
		try {
			mobileActions.isElementPresent(optMonthToDate, 3);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				optMonthToDate.click();
				mobileActions.isElementPresent(optMonthToDateSelected, 3);
			} else {
				String selected = optMonthToDateSelected.getAttribute("checked");
				boolean b = Boolean.parseBoolean(selected);
				if (b == false) {
					optMonthToDateSelected.click();
				}
			}
			LogUtility.logInfo("Clicked on month to date option");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on month to date filter " + e);
			throw new Exception("Unable to click on month to date filter " + e);
		}
	}

	/**
	 * Method to click on specific date option in date range filter option
	 * 
	 * @throws Exception
	 */
	public void tapOnSpecificDate() throws Exception {
		String dateSelected = null;
		try {
			mobileActions.isElementPresent(optSpecificDate, 3);
			optSpecificDate.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				// In iOS specific date page locators are not inspecting. Mobile app window
				// closes automatically.
			} else {
				mobileActions.isElementPresent(dateCalendar, 5);
				btnOkCalendar.click();
				dateSelected = txtSpecificDateValue.getText();
				specifcDateSelected = retailAppUtils.parse(dateSelected, retailAppUtils.simpleDateFormat);
				LogUtility.logInfo("Date Selected " + dateSelected);
			}
			LogUtility.logInfo("Clicked on Specific Date option and selected " + dateSelected);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Specific Date filter " + e);
			throw new Exception("Unable to click on Specific Date filter " + e);
		}
	}

	public boolean verifyFromAmount(String fromAmount) throws Exception {
		String fromAmountField = lblAmountFromField.getText();
		if (fromAmountField.equals(fromAmount)) {
			LogUtility.logInfo("Amount entered as provided");
			return true;
		} else {
			return false;
		}
	}

	public boolean verifyToAmount(String toAmount) throws Exception {
		String toAmountField = lblAmountToField.getText();
		if (toAmountField.equals(toAmount)) {
			LogUtility.logInfo("Amount entered as provided");
			return true;
		} else {
			return false;
		}
	}

	public void enterTextOnSpecificDate(String text) throws Exception {
		try {
			mobileActions.isElementPresent(optSpecificDate, 3);
			optSpecificDate.click();
			mobileActions.isElementPresent(dateCalendar, 5);
			dateCalendar.sendKeys(text);
			if (dateCalendar.getText().equals(text))
				throw new Exception("Incorrect date is entered into specific date");
			else
				LogUtility.logInfo("Incorrect date is not entered");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Specific Date filter " + e);
			throw e;
		}
	}
}
