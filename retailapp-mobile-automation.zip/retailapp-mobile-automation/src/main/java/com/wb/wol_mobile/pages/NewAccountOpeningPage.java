package com.wb.wol_mobile.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

public class NewAccountOpeningPage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	RetailAppUtils retailAppUtils = new RetailAppUtils();

	public NewAccountOpeningPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label='New Account']")
	@iOSFindBy(xpath = "//*[@label='Open New Accounts']")
	@AndroidFindBy(xpath = "//*[@text='New Account']")
	@AndroidFindBy(xpath = "//*[@text='Open New Accounts']")
	protected MobileElement txtNewAccount;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.android.chrome:id/username\"]")
	// @iOSFindBy()
	protected MobileElement txtUserNameAuthentication;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.android.chrome:id/password\"]")
	// @iOSFindBy()
	protected MobileElement txtPasswordAuthentication;

	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/button1\"]")
	// @iOSFindBy()
	protected MobileElement btnSignInAuthentication;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value='CHECKING ACCOUNTS']")
	@AndroidFindBy(xpath = "//a[@href='/personal/checking-accounts-mobile']")
	@AndroidFindBy(xpath = "//*[text()='CHECKING ACCOUNTS']")
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"CHECKING ACCOUNTS\")")
	protected MobileElement btnCheckingsAccounts;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value='SAVINGS ACCOUNTS']")
	@AndroidFindBy(xpath = "//a[@href='/personal/savings-accounts-mobile' and text()='Savings Accounts']")
	@AndroidFindBy(xpath = "//*[text()='SAVINGS ACCOUNTS']")
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"SAVINGS ACCOUNTS\")")
	protected MobileElement btnSavingsAccounts;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value='CDs']")
	@AndroidFindBy(xpath = "//a[@href='/personal/certificates-deposit-mobile' and text()='CDs']")
	@AndroidFindBy(xpath = "//*[text()='CDs']")
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"CDs\")")
	protected MobileElement btnCDsAccounts;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='OPEN AN ACCOUNT']")
	@AndroidFindBy(xpath = "//a[text()='Open An Account']")
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"OPEN AN ACCOUNT\")")
	@AndroidFindBy(xpath = "//a[id = 'hero_module_cta']")
	protected MobileElement btnOpenAnAccount;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Checking Accounts\"]")
	@AndroidFindBy(xpath = "//*[@text=\"Checking Accounts\"]")
	protected MobileElement txtCheckingAccounts;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Savings Accounts\"]")
	@AndroidFindBy(xpath = "//h1[text()='Savings Accounts']")
	@AndroidFindBy(xpath = "//*[@text=\"Savings Accounts\"]")
	protected MobileElement txtSavingsAccounts;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Certificates of Deposits\"]")
	@AndroidFindBy(xpath = "//*[@text=\"Certificates of Deposits\"]")
	protected MobileElement txtCDs;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label='Premier Checking ']")
	@AndroidFindBy(xpath = "//a[@id='premier_checking_title_mobile']")
	@AndroidFindBy(xpath = "//android.view.View[@text='Premier Checking 1']")
	protected MobileElement lnkPremierChecking;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\" Relationship Checking \"]")
	@AndroidFindBy(id = "websterone_relationship_checking_title")
	@AndroidFindBy(xpath = "//*[@resource-id=\"websterone_relationship_checking_title\"]")
	protected MobileElement lnkWebsterOneRelationshipChecking;

	@iOSFindBy(xpath = "//*[@label=\"Webster Value Checking \"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"webster_value_checking_title_mobile\"]")
	protected MobileElement lnkWebsterValueChecking;

	@iOSFindBy(xpath = "//*[@label=\"Webster Student Checking \"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"webster_student_checking_title_mobile\"]")
	protected MobileElement lnkWebsterStudentChecking;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"WebsterOne® Savings \"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"websterone_savings_title_mobile\"]")
	@AndroidFindBy(id = "websterone_savings_title_mobile")
	protected MobileElement lnkWebsterOneSavings;

	@iOSFindBy(xpath = "//*[@label=\"Premium Money Market Savings \"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"premium_money_market_savings_title\"]")
	protected MobileElement lnkPremiumMoneyMarketSavings;

	@iOSFindBy(xpath = "//*[@label=\"Webster Value Savings \"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"webster_value_savings_title_mobile\"]")
	protected MobileElement lnkWebsterValueSavings;

	@iOSFindBy(xpath = "//*[@label=\"Holiday Club Savings \"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"holiday_club_savings_title_mobile\"]")
	protected MobileElement lnkHolidayClubSavings;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Traditional CDs\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"traditional_cd_title_mobile\"]")
	protected MobileElement lnkTraditionalCDs;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"3-year Bump-up CDs\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"3_year_bump_cd_title_mobile\"]")
	protected MobileElement lnk3YearBumpUpCDs;

	@iOSFindBy(xpath = "//*[@label=\"Opportunity Checking \"]")
	@AndroidFindBy(id = "opportunity_checking_title_mobile")
	protected MobileElement lnkOpportunityChecking;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Existing Customer?\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"existingCustomerLink\"]")
	@AndroidFindBy(id = "existingCustomerLink")
	protected MobileElement lnkExistingCustomer;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Enter User Name\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"login-user__pageTitle_gen\"]")
	@AndroidFindBy(id = "login-user__pageTitle_gen")
	protected MobileElement titleUserName;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Enter Password\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"login-password__pageTitle_gen\"]")
	@AndroidFindBy(id = "login-password__pageTitle_gen")
	protected MobileElement titlePassword;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Register Your Device\"]")
	@iOSFindBy(xpath = "//*[@value=\"Register Your Device\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"login-challenge__pageTitle_gen\"]")
	@AndroidFindBy(id = "login-challenge__pageTitle_gen")
	protected MobileElement titleRegisterYourDevice;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"answer__input\"]")
	@AndroidFindBy(id = "answer__input")
	protected MobileElement txtAnswerInput;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Back\"]")
	@AndroidFindBy(xpath = "//button[@id='Back']")
	@AndroidFindBy(id = "Back")
	protected MobileElement btnBack;

	@iOSFindBy(xpath = "//*[@value='Register this device?']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"recognizeMeChooser__label\"]")
	protected MobileElement lblRegisterYourDeviceOption;

	@iOSFindBy(xpath = "//*[@label=\"Yes\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"chooseYes__input\"]")
	protected MobileElement rbtnRegisterDeviceYes;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label='No']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"chooseNo__input\"]")
	@AndroidFindBy(id = "answer__input")
	protected MobileElement rbtnRegisterDeviceNo;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label='Email Address']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"custemail__label\"]")
	@AndroidFindBy(xpath = "//label[@id='custemail__label']")
	protected MobileElement lblEmailAddress;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Email Address *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"custemail__input\"]")
	@AndroidFindBy(id = "custemail__input")
	protected MobileElement txtEmailAddress;

	@AndroidFindBy(id = "promo_code__label")
	@iOSFindBy(xpath = "//*[@value=\"Promo Code (Optional)\"]")
	protected MobileElement lblPromoCode;

	@AndroidFindBy(id = "promo_code__input")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Promo Code (Optional)\"]/following-sibling::XCUIElementTypeTextField")
	protected MobileElement txtPromoCode;

	@AndroidFindBy(id = "open_account_form__formSectionVerifyPromoInvalid__section-note")
	@iOSFindBy(xpath = "//*[@label=\"We apologize, but the promotion code you entered is not valid. Please make sure you typed in the promotional code correctly.\"]")
	protected MobileElement txtInValidPromo;

	@AndroidFindBy(id = "open_account_form__formSectionVerifyPromoInvalid__section-note")
	@iOSFindBy(xpath = "//*[@label='We apologize but the promotion you requested has expired.']")
	protected MobileElement txtExpiredPromo;

	@AndroidFindBy(id = "open_account_form__formSectionVerifyPromoValid__section-note")
	@iOSFindBy(xpath = "//*[@label=\"Based on promotional code you entered, you are applying for:\"]")
	protected MobileElement txtValidPromo;

	@AndroidFindBy(id = "ok")
	@iOSFindBy(xpath = "//*[@label=\"OK\"]")
	protected MobileElement btnOk;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Continue\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Continue']")
	@AndroidFindBy(id = "continueButton__actualButton")
	@AndroidFindBy(xpath = "//span[text()='Continue']")
	@AndroidFindBy(id = "buttonSubmit_formLoginUser__buttonText")
	protected MobileElement btnContinue;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Continue\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"custemail__error-message-text\"]")
	@AndroidFindBy(xpath = "//error-message-text[@text='A valid email address is required. Example: myname@webster.com']")
	@AndroidFindBy(id = "buttonSubmit_formLoginUser__buttonText")
	protected MobileElement emailErrorMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Close']")
	@iOSFindBy(xpath = "//*[@id=\"Close\"]")
	@AndroidFindBy(xpath = "//component button_cancel_std_noConfirm wbst_fnc__close[@text='Close']")
	@AndroidFindBy(id = "Close")
	@AndroidFindBy(xpath = "//span[text()='Close']")
	protected MobileElement btnClose;

	@iOSFindBy(xpath = "//*[@label=\"Done\"]")
	protected MobileElement btnDone;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Tell us about yourself\"]")
	@AndroidFindBy(xpath = "//android.view.View[@text='Tell us about yourself']")
	@AndroidFindBy(xpath = "//*[@id='progressBar__masterlabeltextarea']")
	protected MobileElement lblTellUsAboutYourself;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Social Security Number\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"ssn__label\"]", priority = 1)
	@AndroidFindBy(id = "ssn__label")
	protected MobileElement lblSocialSecurityNumber;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Social Security Number *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id='ssn__input']", priority = 1)
	@AndroidFindBy(id = "//*[@id=\"ssn__input\"]")
	@AndroidFindBy(id = "ssn__input")
	protected MobileElement txtSocialSecurityNumber;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Date of Birth *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"date__input\"]", priority = 1)
	@AndroidFindBy(id = "date__input")
	protected MobileElement txtDOB;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value=\"First Name\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"fullNameTextInputField__inputFirstName\"]", priority = 1)
	@AndroidFindBy(id = "fullNameTextInputField__inputFirstName")
	protected MobileElement txtFirstName;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value=\"Last Name\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"fullNameTextInputField__inputLastName\"]", priority = 1)
	@AndroidFindBy(id = "fullNameTextInputField__inputLastName")
	protected MobileElement txtLastName;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Best Phone Number *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"homephone__input\"]", priority = 1)
	@AndroidFindBy(id = "homephone__input")
	protected MobileElement txtPhoneNumber;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Address1 *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"address1__input\"]", priority = 1)
	@AndroidFindBy(id = "address1__input")
	protected MobileElement txtAddress1;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Address2\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"address2__input\"]", priority = 1)
	@AndroidFindBy(id = "address2__input")
	protected MobileElement txtAddress2;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"City *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"city__input\"]", priority = 1)
	@AndroidFindBy(id = "city__input")
	protected MobileElement txtCity;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label=\"Select\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Select']")
	@AndroidFindBy(id = "states__select-button")
	protected MobileElement btnSelect;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"State\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"states__radio__label\"]")
	@AndroidFindBy(xpath = "//legend[text()='State']")
	protected MobileElement lblState;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Before you continue to open your new account, you must read and agree to each individual disclosure\"]")
	@AndroidFindBy(id = "nao-disclosures__pageErrors_gen__DISCLOSURES__ERROR__body")
	protected MobileElement txtReadAndAgreeMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Zip Code *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"zipCode__input\"]")
	@AndroidFindBy(id = "zipCode__input")
	protected MobileElement txtZipCode;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Identification Information\"]")
	@AndroidFindBy(xpath = "//android.view.View[@text='Identification Information']")
	@AndroidFindBy(id = "open_account_form__formSectionIdentification__section-title")
	protected MobileElement lblIdentificationInformation;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Personal Information\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Review Personal Information\"]")
	@AndroidFindBy(id = "open_account_form__formSectionPersonal__section-title")
	@AndroidFindBy(xpath = "//*[@resource-id=\"open_account_form__formSectionPersonal__section-title\"]", priority = 1)
	protected MobileElement lblReviewPersonalInformation;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign political figure or foreign government official? Why do we ask this?\"]/XCUIElementTypeOther[2]")
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign political figure or foreign government official? Why do we ask this? *\"]//*[@label=\"Yes\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cdd_pep_question1_yes__input\"]")
	@AndroidFindBy(id = "cdd_pep_question1_yes__labelCaption")
	protected MobileElement rbtnPep1Yes;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign political figure or foreign government official? Why do we ask this?\"]/XCUIElementTypeOther[3]")
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign political figure or foreign government official? Why do we ask this? *\"]//*[@label=\"No\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cdd_pep_question1_no__input\"]")
	@AndroidFindBy(id = "cdd_pep_question1_no__labelCaption")
	protected MobileElement rbtnPep1No;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign official of a major political party or a senior executive of a foreign government-owned business including charitable organizations? Why do we ask this?\"]/XCUIElementTypeOther[2]")
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign official of a major political party or a senior executive of a foreign government-owned business including charitable organizations? Why do we ask this? *\"]//*[@label=\"Yes\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cdd_pep_question2_yes__input\"]")
	@AndroidFindBy(id = "cdd_pep_question2_yes__labelCaption")
	protected MobileElement rbtnPep2Yes;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign official of a major political party or a senior executive of a foreign government-owned business including charitable organizations? Why do we ask this?\"]/XCUIElementTypeOther[3]")
	@iOSFindBy(xpath = "//*[@label=\"Have you or an immediate family member or close associate ever held a position as a senior foreign official of a major political party or a senior executive of a foreign government-owned business including charitable organizations? Why do we ask this? *\"]//*[@label=\"No\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cdd_pep_question2_no__input\"]")
	@AndroidFindBy(id = "cdd_pep_question2_no__labelCaption")
	protected MobileElement rbtnPep2No;

	@iOSFindBy(xpath = "//*[@label='An answer is required.']")
	@AndroidFindBy(xpath = "//p[text()='An answer is required.']")
	protected MobileElement txtErrorMessagePEP;

	@iOSFindBy(xpath = "//*[@label=\"It looks like you are already enrolled in Online Banking. Please\"]")
	@AndroidFindBy(xpath = "//div[contains(text(),'It looks like you are already enrolled in Online Banking. Please ')]")
	protected MobileElement txtMessageExist;

	@AndroidFindBy(xpath = "//*[text()='Are you a Non Resident or Resident alien?']")
	@iOSFindBy(xpath = "//*[@label=\"Are you a Non Resident or Resident alien?\"]")
	protected MobileElement lblNonResident;

	@AndroidFindBy(xpath = "//*[text()='Resident Alien']")
	@iOSFindBy(xpath = "//*[@label=\"Resident Alien\"]")
	protected MobileElement rbtnResidentAlien;

	@AndroidFindBy(xpath = "//*[text()='Non Resident Alien']")
	@iOSFindBy(xpath = "//*[@label=\"Non Resident Alien\"]")
	protected MobileElement rbtnNonResidentAlien;

	@iOSFindBy(xpath = "//XCUIElementTypeLink[@label=\"Sign In\"]")
	@AndroidFindBy(xpath = "//a[text()='Sign In']")
	protected MobileElement lnkSignIn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@label,'What is Your Country of Citizenship?')]/following-sibling::XCUIElementTypeOther/XCUIElementTypeButton")
	@AndroidFindBy(xpath = "//*[@resource-id=\"citizenship__select-button\"]")
	@AndroidFindBy(id = "citizenship__select-button")
	protected MobileElement btnCountrySelect;

	@iOSFindBy(xpath = "//*[@value=\"What is Your Country of Citizenship?\"]")
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"What is Your Country of Citizenship?\")")
	protected MobileElement lblCountry;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Driver's License Information\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"open_account_form__formSectionDriverLicense__section-title\"]")
	@AndroidFindBy(id = "open_account_form__formSectionDriverLicense__section-title")
	protected MobileElement lblDriverLicenseInformation;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label=\"Select\"]")
	@iOSFindBy(xpath = "//*[@label=\"main\"]/XCUIElementTypeOther[6]/XCUIElementTypeOther[2]/XCUIElementTypeOther[3]/XCUIElementTypeButton[1]")
	@iOSFindBy(xpath = "//*[@label=\"main\"]/XCUIElementTypeOther[9]/XCUIElementTypeOther[2]/XCUIElementTypeOther[3]/XCUIElementTypeButton[1]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"dlstate__select-button\"]")
	@AndroidFindBy(id = "dlstate__select-button")
	protected MobileElement btnLicenseState;
		
	@iOSFindBy(xpath = "//*[@label=\"Employment Information\"]")
	@AndroidFindBy(xpath = "//*[text()=\"Employment Information\"]")
	protected MobileElement lblEmploymentInfo;
	
	@iOSFindBy(xpath = "//*[@label=\"Driver's License Number\"]")
	@AndroidFindBy(xpath = "//*[text()=\"Driver's License Number\"]")
	protected MobileElement lblDriverLicense;
	
	@iOSFindBy(xpath = "//*[@label=\"Social Security Number\"]")
	@AndroidFindBy(xpath = "//*[text()=\"Social Security Number\"]")
	protected MobileElement lblSocialSecurity;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label='main']/XCUIElementTypeOther[6]/XCUIElementTypeOther[2]/XCUIElementTypeOther[3]/XCUIElementTypeButton[1]")
	@iOSFindBy(xpath = "//*[@label=\"main\"]/XCUIElementTypeOther[9]/XCUIElementTypeOther[2]/XCUIElementTypeOther[3]/XCUIElementTypeButton[1]")
	protected MobileElement btnLicenseStateIos;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"License Number *\"]/following-sibling::XCUIElementTypeTextField")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"License Number\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"dlnumber__input\"]")
	@AndroidFindBy(id = "dlnumber__input")
	protected MobileElement txtLicenseNumber;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Issue Date *\"]/following-sibling::XCUIElementTypeTextField")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Issue Date\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"dlissuedate__input\"]")
	@AndroidFindBy(id = "dlissuedate__input")
	protected MobileElement txtLicenseIssueDate;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Expiration Date *\"]/following-sibling::XCUIElementTypeTextField")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Expiration Date\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"dlexpirydate__input\"]")
	@AndroidFindBy(id = "dlexpirydate__input")
	protected MobileElement txtLicenseExpirationDate;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Employment Information\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"open_account_form__formSectionEmployment__section-title\"]")
	@AndroidFindBy(id = "open_account_form__formSectionEmployment__section-title")
	protected MobileElement lblEmploymentInformation;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label='main']/XCUIElementTypeOther[7]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeButton[1]")
	@iOSFindBy(xpath = "//*[@label=\"main\"]/XCUIElementTypeOther[10]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeButton[1]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"empstatus__select-button\"]")
	@AndroidFindBy(id = "empstatus__select-button")
	protected MobileElement btnEmploymentSelect;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"What is the name of your employer? *\"]/following-sibling::XCUIElementTypeTextField")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"What is the name of your employer?\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"empname__input\"]")
	protected MobileElement txtEmployerName;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"What is your job title? *\"]/following-sibling::XCUIElementTypeTextField")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"What is your job title?\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"jobTitle__input\"]")
	protected MobileElement txtJobTitle;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Setup account features\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"progressBar__masterlabel\"]")
	@AndroidFindBy(id = "progressBar__masterlabeltextarea")
	protected MobileElement lblSetupAccountFeatures;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Review the account you selected\"]")
	@iOSFindBy(xpath = "//*[@value=\"Review the account you selected\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"open_account_form__formSectionSelectAccount__section-title\"]")
	@AndroidFindBy(id = "open_account_form__formSectionSelectAccount__section-title")
	protected MobileElement lblReviewAccountSelected;

	@iOSFindBy(xpath = "//*[@value=\"You have selected\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"selectAccountCheckingRatesTableWidget__selectedAccount__label\"]")
	protected MobileElement lblYouHaveSelected;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label='You have selected']/following-sibling::XCUIElementTypeOther/XCUIElementTypeStaticText")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"You have selected:\"]/following-sibling::XCUIElementTypeOther/XCUIElementTypeStaticText")
	@AndroidFindBy(xpath = "//*[@resource-id=\"selectAccountCheckingRatesTableWidget__selectedAccount__display\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"selectAccountCdRatesTableWidget__selectedAccount__label\"]")
	@AndroidFindBy(id = "selectAccountCheckingRatesTableWidget__selectedAccount__display")
	@AndroidFindBy(id = "selectAccountSavingsRatesTableWidget__selectedAccount__display")
	protected MobileElement txtSelectedAccount;

	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"You have selected\"]/following-sibling::XCUIElementTypeOther/XCUIElementTypeStaticText")
	@AndroidFindBy(xpath = "//*[@resource-id=\"selectAccountCdRatesTableWidget__selectedAccount__display\"]")
	protected MobileElement txtSelectedAccountCD;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Rate Tiers']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"selectAccountCheckingRatesTableWidget__tableHeaders__headerItem-selectAccountCheckingRatesTableWidget__tableHeaders__bucketHeader-label\"]")
	@AndroidFindBy(id = "selectAccountCheckingRatesTableWidget__tableHeaders__headerItem-selectAccountCheckingRatesTableWidget__tableHeaders__bucketHeader-label")
	protected MobileElement lblRateTiers;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Rate Tiers']")
	@AndroidFindBy(xpath = "//android.view.View[@text='Rate Tiers']")
	protected MobileElement lblRateTiersCD;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"General Notes\"]")
	@AndroidFindBy(xpath = "//*[@text=\"General Notes\"]")
	@AndroidFindBy(xpath = "//header[text()='General Notes']")
	protected MobileElement lblGeneralNotes;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Account Information\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"open_account_form__formSectionAccountInformation__section-title\"]")
	@AndroidFindBy(id = "open_account_form__formSectionAccountInformation__section-title")
	protected MobileElement lblAccountInformation;

	@iOSFindBy(xpath = "//*[@value=\"International Wire Services\"]")
	@AndroidFindBy(id = "open_account_form__formSectionInternationalWireServices__section-title")
	protected MobileElement lblInternationalWireServices;

	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"What is the average monthly dollar amount you intend to wire?\"]//*[@label=\"$5,001 to $10,000\"]")
	@AndroidFindBy(id = "intendtoWire__radio__Range5Kto10K__labelCaption")
	protected MobileElement rbtnIntendToWire5KTo10K;

	@iOSFindBy(xpath = "//*[@label=\"Send Domestic Wires\" and @value=\"0\"]")
	@AndroidFindBy(id = "domestic__label")
	protected MobileElement chkSendDomesticWires;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to deposit to your account in a month? Why do we ask this?\"]//*[@label=\"0\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashin_transact__radio__Zero__input\"]")
	@AndroidFindBy(id = "cashin_transact__radio__Zero__labelCaption")
	protected MobileElement rbtnDepositZero;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to deposit to your account in a month? Why do we ask this?\"]//*[@label=\"Less than $5,000\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashin_transact__radio__LessThan5K__input\"]")
	@AndroidFindBy(id = "cashin_transact__radio__LessThan5K__labelCaption")
	protected MobileElement rbtnDepositLess5K;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to deposit to your account in a month? Why do we ask this?\"]//*[@label=\"$5,001 to $10,000\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashin_transact__radio__Range5Kto10K__input\"]")
	@AndroidFindBy(id = "cashin_transact__radio__Range5Kto10K__labelCaption")
	protected MobileElement rbtnDepositBetween5K10K;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to deposit to your account in a month? Why do we ask this?\"]//*[@label=\"$10,001 or MORE\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashin_transact__radio__MoreThan10K__input\"]")
	@AndroidFindBy(id = "cashin_transact__radio__MoreThan10K__labelCaption")
	protected MobileElement rbtnDepositMore10K;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to withdraw from your account in a month? Why do we ask this?\"]//*[@label=\"0\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashout_transact__radio__Zero__input\"]")
	@AndroidFindBy(id = "cashout_transact__radio__Zero__labelCaption")
	protected MobileElement rbtnWithDrawZero;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to withdraw from your account in a month? Why do we ask this?\"]//*[@label=\"Less than $5,000\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashout_transact__radio__LessThan5K__input\"]")
	@AndroidFindBy(id = "cashout_transact__radio__LessThan5K__labelCaption")
	protected MobileElement rbtnWithDrawLess5K;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to withdraw from your account in a month? Why do we ask this?\"]//*[@label=\"$5,001 to $10,000\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashout_transact__radio__Range5Kto10K__input\"]")
	@AndroidFindBy(id = "cashout_transact__radio__Range5Kto10K__labelCaption")
	protected MobileElement rbtnWithDrawBetween5K10K;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"How much cash do you expect to withdraw from your account in a month? Why do we ask this?\"]//*[@label=\"$10,001 or MORE\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cashout_transact__radio__MoreThan10K__input\"]")
	@AndroidFindBy(id = "cashout_transact__radio__MoreThan10K__labelCaption")
	protected MobileElement rbtnWithDrawMore10K;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Do you intend to use international wire services? Why do we ask this?\"]/XCUIElementTypeOther[2]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"wire_service_y__input\"]")
	@AndroidFindBy(id = "wire_service_y__labelCaption")
	protected MobileElement rbtnInternalWireServicesYes;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Do you intend to use international wire services? Why do we ask this?\"]/XCUIElementTypeOther[3]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"wire_service_n__input\"]")
	@AndroidFindBy(id = "wire_service_n__labelCaption")
	protected MobileElement rbtnInternalWireServicesNo;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Choose my Debit Card\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cardStockTypeCode__label\"]")
	@AndroidFindBy(id = "cardStockTypeCode__label")
	protected MobileElement lblChooseMyDebitCard;

	@iOSFindBy(xpath = "//*[@value=\"Choose No Card\"]")
	@AndroidFindBy(id = "cardStockTypeCode__defaultChoice__choiceLabel")
	protected MobileElement lblNoCard;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"No Card\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cardStockTypeCode__defaultChoice__input\"]")
	@AndroidFindBy(id = "cardStockTypeCode__defaultChoice__labelCaption")
	@AndroidFindBy(xpath = "//*[@id=\"cardStockTypeCode__defaultChoice__labelCaption\"]")
	protected MobileElement rbtnNoCard;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Choose my Debit Card\"]")
	@AndroidFindBy(xpath = "//*[@id=\"cardStockTypeCode__DFLTPREM__input\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cardStockTypeCode__DFLTVISA__input\"]")
	@AndroidFindBy(id = "cardStockTypeCode__DFLTVISA__labelCaption")
	protected MobileElement rbtnVisaDebitCard;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Debit Card Overdraft Services\"]")
	@AndroidFindBy(xpath = "//*[@text=\"Debit Card Overdraft Services\"]")
	@AndroidFindBy(xpath = "//*[text()='Debit Card Overdraft Services']")
	protected MobileElement txtDebitCardOverdraftServices;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Yes, I do want Webster Bank to authorize and pay overdrafts on my ATM and everyday debit card transactions.\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"odp-12__input\"]")
	@AndroidFindBy(id = "odp-12__choiceLabel")
	protected MobileElement rbtnPayOverDraftYes;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"No, I do not want Webster Bank to authorize and pay overdrafts on my ATM and everyday Debit card transactions.\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"odp-13__input\"]")
	@AndroidFindBy(id = "odp-13__choiceLabel")
	protected MobileElement rbtnPayOverDraftNo;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Enroll this account in Statement eDelivery\"]")
	@AndroidFindBy(xpath = "//*[@text='Enroll this account in Statement eDelivery']")
	@AndroidFindBy(id = "visa_check_card__label")
	protected MobileElement txtEnrollStatementeDelivery;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Verify Personal Information\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"personalInfoFormSection__section-title\"]")
	@AndroidFindBy(id = "personalInfoFormSection__section-title")
	protected MobileElement lblVerifyPersonalInformation;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Verify Account Information\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"accountInfoFormSection__section-title\"]")
	@AndroidFindBy(id = "accountInfoFormSection__section-title")
	protected MobileElement lblVerifyAccountInformation;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"main\"]/XCUIElementTypeLink[1]/XCUIElementTypeStaticText[@label='Edit Personal Information']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"personalInfoEditTopButton\"]")
	@AndroidFindBy(id = "personalInfoEditTopButton")
	protected MobileElement btnEditPersonalInformation;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"main\"]/XCUIElementTypeLink[3]/XCUIElementTypeStaticText[@text='Edit Account Information']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"accountInfoEditTopButton\"]")
	@AndroidFindBy(id = "accountInfoEditTopButton")
	protected MobileElement btnEditAccountInformation;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Equifax logo\"]")
	@AndroidFindBy(xpath = "//*[@text=\"Equifax logo\"]")
	@AndroidFindBy(xpath = "//img[@alt='Equifax logo']")
	protected MobileElement imgEquifax;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Verify your identity\"]")
	@AndroidFindBy(xpath = "//android.view.View[@text='Verify your identity']")
	@AndroidFindBy(xpath = "//p[@id='progressBar__masterlabeltextarea']")
	protected MobileElement lblVerifyYourIdentity;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Emulation Question #1 [Pass]\"]")
	@AndroidFindBy(xpath = "//android.view.View[@text='Emulation Question #1 [Pass]']")
	@AndroidFindBy(id = "question1__label")
	protected MobileElement lblEmulationQuestion1;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Emulation Question #2 [Pass]\"]")
	@AndroidFindBy(xpath = "//android.view.View[@text='Emulation Question #2 [Pass]']")
	@AndroidFindBy(id = "question2__label")
	protected MobileElement lblEmulationQuestion2;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"I Don't Know The Answers\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"cancelButton\"]")
	@AndroidFindBy(id = "cancelButton")
	protected MobileElement btnIDontKnowTheAnswers;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Opportunity Checking Account Information\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"accountInformationSection__section-title\"]")
	@AndroidFindBy(id = "accountInformationSection__section-title")
	protected MobileElement lblOpportunityChecking;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//a[text()='product details page']")
	protected MobileElement txtProductDetailsPage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Condition to avoid Monthly Service Charge\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"opportunityTermsAndRates__avoidCharge__label\"]")
	@AndroidFindBy(id = "opportunityTermsAndRates__avoidCharge__label")
	protected MobileElement lblConditionAvoidMonthlySerCharge;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Monthly Service Charge\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"opportunityTermsAndRates__charge__label\"]")
	@AndroidFindBy(id = "opportunityTermsAndRates__charge__label")
	protected MobileElement lblMonthlyServiceChargeTransFee;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Rate Tiers']")
	@AndroidFindBy(id = "opportunityTermsAndRates__tableHeaders__headerItem-opportunityTermsAndRates__tableHeaders__bucketHeader-label")
	@AndroidFindBy(xpath = "//*[@resource-id=\"opportunityTermsAndRates__tableHeaders__headerItem-opportunityTermsAndRates__tableHeaders__bucketHeader-label\"]")
	protected MobileElement lblRateTiersOpportunity;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Send me my free Webster Visa Debit Card\"]")
	@AndroidFindBy(id = "visa_check_card__label")
	@AndroidFindBy(xpath = "//*[@resource-id=\"visa_check_card__input\"]")
	protected MobileElement chkSendMeMyFreeVisaDebitCard;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Enroll this account in\"]")
	@AndroidFindBy(id = "enroll_edelivery__label")
	@AndroidFindBy(xpath = "//*[@resource-id=\"enroll_edelivery__input\"]")
	protected MobileElement chkEnrollThisAccount;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Decline\"]")
	@AndroidFindBy(xpath = "//a[text()='Decline']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"opportunityDeclineButton\"]")
	protected MobileElement btnDecline;

	@iOSFindBy(xpath = "//*[@label=\"We were unable to open your account online.\"]")
	@AndroidFindBy(xpath = "//div[text()='We were unable to open your account online.']")
	protected MobileElement txtErrorMessageUnable;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"I have read these Disclosures and I Agree\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"formSectionDisclosuresMain__section-title\"]")
	@AndroidFindBy(xpath = "//h1[@id='formSectionDisclosuresMain__section-title']")
	protected MobileElement lblDisclosuresIAgree;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"I Agree to WebsterOnline Services Agreement\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"disclosureList2160__input\"]")
	@AndroidFindBy(id = "disclosureList2160__input")
	protected MobileElement chkWebsterOnlineServicesAgreement;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"I Agree to eDelivery Agreement\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"disclosureList2156__input\"]")
	@AndroidFindBy(id = "disclosureList2156__input")
	protected MobileElement chkEDeliveryAgreement;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"I Agree to Privacy and Opt-Out Notice\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"disclosureList2137__input\"]")
	@AndroidFindBy(id = "disclosureList2137__input")
	protected MobileElement chkPrivacyOptOutNotice;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"I Agree to Fee Schedule for Consumer Accounts\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"disclosureList2139__input\"]")
	@AndroidFindBy(id = "disclosureList2139__input")
	protected MobileElement chkFeeScheduleConsumerAccounts;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"I Agree to Interest Rate Disclosure\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"disclosureList2023__input\"]")
	@AndroidFindBy(id = "disclosureList2023__input")
	protected MobileElement chkInterestRateDisclosure;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"I Agree to Deposit Account Disclosure for Consumer Accounts\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"disclosureList2145__input\"]")
	@AndroidFindBy(id = "disclosureList2145__input")
	protected MobileElement chkDepositAccountDisclosure;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Create your profile\"]")
	@AndroidFindBy(xpath = "//android.view.View[@text='Create your profile']")
	@AndroidFindBy(xpath = "//*[@id='progressBar__masterlabeltextarea']")
	protected MobileElement lblCreateYourProfile;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"User Name\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"username__input\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"fieldUsername__input\"]")
	@AndroidFindBy(id = "username__input")
	@AndroidFindBy(id = "fieldUsername__input")
	protected MobileElement txtUserName;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Password\"]/following-sibling::XCUIElementTypeTextField")
	@iOSFindBy(xpath = "//XCUIElementTypeSecureTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"password__input\"]")
	@AndroidFindBy(id = "password__input")
	protected MobileElement txtPassword;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Reenter Password\"]/following-sibling::XCUIElementTypeSecureTextField")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label=\"Reenter Password\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//*[@resource-id=\"reenterPassword__input\"]")
	@AndroidFindBy(id = "reenterPassword__input")
	protected MobileElement txtReEnterPassword;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id=\"mobileapp-nao-confirmation-auth__pageAffirmativeNotice_gen__body\"]")
	@AndroidFindBy(xpath = "//*[text()=\"Congratulations!\"]")
	protected MobileElement lblCongratulations;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@id=\"accountTypeField__label\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"accountTypeField__display\"]")
	protected MobileElement txtAccountType;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@id=\"accountNumberField__label\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"accountNumberField__display\"]")
	protected MobileElement txtAccountNumber;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@id=\"routingNumberField__label\"]")
	@AndroidFindBy(xpath = "//*[@resource-id=\"routingNumberField__display\"]")
	protected MobileElement txtRoutingNumber;
	
	@AndroidFindBy(id = "com.android.chrome:id/tab_switcher_button")
	protected MobileElement iconChromeTab;
	
	@AndroidFindBy(id = "com.android.chrome:id/menu_button")
	protected MobileElement btnMenuChrome;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[text() = 'Close all tabs']")
	protected MobileElement txtCloseTabs;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label='Other']")
	@AndroidFindBy(xpath = "//span[text()='Other']")
	@AndroidFindBy(xpath = "//android.widget.RadioButton[@text='Other']")
	protected MobileElement btnEmploymentStatus;

	public String pageTitle = "//h1[text()='Open a New %s Account'] | //XCUIElementTypeStaticText[@label='Open a New %s Account'] | //android.view.View[@text='Open a New %s Account']";
	public String stateSelect = "//android.widget.RadioButton[@text='%s'] | //*[@label='%s'] | //span[text()='%s' and contains(@id,'states')]";
	public String licenseState = "//android.widget.RadioButton[@text='%s'] | //*[@label='%s'] | //span[text()='%s' and contains(@id,'dlstate')]";
	public String employmentStatus = "//android.widget.RadioButton[@text='%s'] | //*[@label='%s'] | //span[text()='%s']";
	public String countrySelect = "//android.widget.RadioButton[@text='%s'] | //span[text()='%s' and contains(@id,'citizenship')]";
	public String countrySelectiOS = "//*[@label='%s']";
	public String emulationQAOneSelect = "//*[@resource-id=\"question1__%s__input\"] | //XCUIElementTypeOther[@label=\"Emulation Question #1 [Pass]\"]//*[@label='%s'] | //span[@id='question1__%s__labelCaption']";
	public String emulationQATwoSelect = "//*[@resource-id=\"question2__%s__input\"] | //XCUIElementTypeOther[@label=\"Emulation Question #2 [Pass]\"]//*[@label='%s'] | //span[@id='question2__%s__labelCaption']";
	public String labelOpportunityChecking = "//XCUIElementTypeStaticText[@label='Opportunity Checking Account Information'] | //*[@resource-id='accountInformationSection__section-title'] | //*[@id='accountInformationSection__section-title']";
	public String lightBoxMessage = "//*[contains(text(),'%s')] | //*[contains(@label,'%s')]";

	public void verifyNAOIconPresent() throws Exception {
		try {
			mobileActions.isElementPresent(txtNewAccount, 5);
			LogUtility.logInfo("Verified NAO icon is present in Home screen");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the NAO icon is present in Home screen");
			throw e;
		}
	}

	public void tapOnNAO() throws Exception {
		try {
			verifyNAOIconPresent();
			txtNewAccount.click();
			LogUtility.logInfo("Clicked on NAO icon");
		} catch (Exception e) {
			LogUtility.logError("Unable click on NAO account " + e);
			throw e;
		}
	}

	public void verifyNAOPageDisplayed() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				waits.staticWait(2);
				mobileActions.switchToWebView();
			}
			if (TestDataConstants.getOSPlatformName().equals("ios")) {
				/**
				 * Have to wait for sometime to load the page complete and few times page
				 * loading but scrolling is not happening
				 **/
				waits.staticWait(2);
				mobileActions.scrollDown();
			}
			waits.staticWait(2);
			List<RemoteWebElement> accountsButtons = new ArrayList<RemoteWebElement>();
			accountsButtons.addAll(Arrays.asList(btnCheckingsAccounts, btnSavingsAccounts, btnCDsAccounts));
			mobileActions.elementsPresent(accountsButtons);
			LogUtility.logInfo("Verified the NAO page is displayed..");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the NAO page is displayed " + e);
			throw e;
		}
	}

	public void verifyNAOPageDisplayedMenu() throws Exception {
		if (mobileActions.verifyIsElementPresent(txtUserNameAuthentication, 5)) {
			txtUserNameAuthentication.sendKeys(TestDataConstants.USERNAMEAUTHENTICATION);
			txtPasswordAuthentication.sendKeys(TestDataConstants.PASSWORDAUTHENTICATION);
			btnSignInAuthentication.click();
		}

		try {
			mobileActions.isElementPresent(btnCheckingsAccounts, 10);
			mobileActions.scrollDown();
			List<RemoteWebElement> accountsButtons = new ArrayList<RemoteWebElement>();
			accountsButtons.addAll(Arrays.asList(btnCheckingsAccounts, btnSavingsAccounts, btnCDsAccounts));
			mobileActions.elementsPresent(accountsButtons);
			LogUtility.logInfo("Verified the NAO page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the NAO page is displayed " + e);
			throw e;
		}
	}

	public void verifyEmailAddressDisplayed() throws Exception {
		try {
			mobileActions.isElementPresent(txtEmailAddress, 5);
			LogUtility.logInfo("Email Address text is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Email Address text is displayed " + e);
			throw e;
		}
	}

	public void verifyPromoCodeDisplayed() throws Exception {
		try {
			mobileActions.isElementPresent(txtPromoCode, 5);
			LogUtility.logInfo("Promo Code text is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Promo Code text is displayed " + e);
			throw e;
		}
	}
	
	public void verifyEmailAddressAndPromocodeDisplayed() throws Exception {
		try {
			mobileActions.isElementPresent(txtEmailAddress, 5);
			mobileActions.isElementPresent(txtPromoCode, 5);
			LogUtility.logInfo("Promo Code text AND Email Address text is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Promo Code text and Email Address text is displayed " + e);
			throw e;
		}
	}

	public void tapOnSavingsAccounts() throws Exception {
		try {
			btnSavingsAccounts.click();
			waits.staticWait(5);
			LogUtility.logInfo("Clicked on Savings Accounts");
		} catch (Exception e) {
			LogUtility.logError("Unable click on Savings Accounts " + e);
			throw e;
		}
	}

	public void tapOnCheckingsAccounts() throws Exception {
		try {
			btnCheckingsAccounts.click();
			LogUtility.logInfo("Clicked on Checkings Accounts");
		} catch (Exception e) {
			LogUtility.logError("Unable click on Checkings Accounts " + e);
			throw e;
		}
	}

	public void tapOnCD() throws Exception {
		try {
			btnCDsAccounts.click();
			mobileActions.isElementPresent(txtCDs, 5);
			LogUtility.logInfo("Clicked on CDs");
		} catch (Exception e) {
			LogUtility.logError("Unable click on CDs " + e);
			throw e;
		}
	}

	public void tapOnOpenAnAccount() throws Exception {
		if (mobileActions.verifyIsElementPresent(btnOpenAnAccount, 10)) {
			LogUtility.logInfo("Open a account button is displayed");
		} else {
			mobileActions.swipeUpUntilTextExists(btnOpenAnAccount, 2);
		}
		try {
			btnOpenAnAccount.click();
			LogUtility.logInfo("Clicked on Open an account");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on any one of the Savings Accounts " + e);
			throw e;
		}
	}

	public void tapOnAnySavingsAccounts() throws Exception {
		mobileActions.isElementPresent(btnOpenAnAccount, 5);
		try {
			btnOpenAnAccount.click();
			LogUtility.logInfo("Clicked on any one of the Savings Accounts");
		} catch (Exception e) {
			LogUtility.logError("Unable click on any one of the Savings Accounts " + e);
			throw e;
		}
	}

	public void tapOnOpenPremierChecking() throws Exception {
		if (mobileActions.isElementDisplayed(lnkPremierChecking, 4)) {
			LogUtility.logInfo("Checked Premier Checking is present");
		} else {
			mobileActions.swipeUpUntilTextExists(lnkPremierChecking, 3);
		}
		try {
			lnkPremierChecking.click();
			LogUtility.logInfo("Clicked on Premier Checking Open a account");
		} catch (Exception e) {
			LogUtility.logError("Unable click on Premier Checking Open a Account " + e);
			throw e;
		}
	}

	public void tapOnOpenWebsterOneRelationshipChecking() throws Exception {
		if (mobileActions.isElementDisplayed(lnkWebsterOneRelationshipChecking, 3)) {
			LogUtility.logInfo("WebsterOne Relationship Checking is displayed");
		} else {
			mobileActions.swipeUpUntilTextExists(lnkWebsterOneRelationshipChecking, 3);
		}
		try {
			lnkWebsterOneRelationshipChecking.click();
			waits.staticWait(5);
			LogUtility.logInfo("Clicked on WebsterOne Relationship Checking Open a account");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on WebsterOne Relationship Checking Open a Account " + e);
			throw e;
		}
	}

	public void tapOnWebsterValueChecking() throws Exception {
		mobileActions.isElementPresent(txtCheckingAccounts, 5);
		try {
			mobileActions.swipeUpUntilTextExists(lnkWebsterValueChecking, 3);
			lnkWebsterValueChecking.click();
			LogUtility.logInfo("Clicked on Webster Value Checking Open a account");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Webster Value Checking Open a Account " + e);
			throw e;
		}
	}

	public void tapOnWebsterStudentChecking() throws Exception {
		mobileActions.isElementPresent(txtCheckingAccounts, 5);
		try {
			mobileActions.swipeUpUntilTextExists(lnkWebsterStudentChecking, 3);
			lnkWebsterStudentChecking.click();
			LogUtility.logInfo("Clicked on Webster Student Open a account");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Webster Student Open a Account " + e);
			throw e;
		}
	}

	public void tapOnWebsterOneSavings() throws Exception {
		try {
			mobileActions.swipeUpUntilTextExists(lnkWebsterOneSavings, 3);
			lnkWebsterOneSavings.click();
			LogUtility.logInfo("Clicked on WebsterOne Savings account");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on WebsterOne Savings account " + e);
			throw e;
		}
	}

	public void tapOnPremiumMoneyMarketSavings() throws Exception {
		mobileActions.isElementPresent(txtSavingsAccounts, 5);
		try {
			mobileActions.swipeUpUntilTextExists(lnkPremiumMoneyMarketSavings, 3);
			lnkPremiumMoneyMarketSavings.click();
			LogUtility.logInfo("Clicked on Premium Money Market Savings account");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Premium Money Market Savings account " + e);
			throw e;
		}
	}

	public void tapOnWebsterValueSavings() throws Exception {
		mobileActions.isElementPresent(txtSavingsAccounts, 5);
		try {
			mobileActions.swipeUpUntilTextExists(lnkWebsterValueSavings, 3);
			lnkWebsterValueSavings.click();
			LogUtility.logInfo("Clicked on Webster Value Savings account");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Webster Value Savings account " + e);
			throw e;
		}
	}

	public void tapOnHolidayClubSavings() throws Exception {
		mobileActions.isElementPresent(txtSavingsAccounts, 5);
		try {
			mobileActions.swipeUpUntilTextExists(lnkHolidayClubSavings, 3);
			lnkHolidayClubSavings.click();
			LogUtility.logInfo("Clicked on Webster Value Savings account");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Webster Value Savings account " + e);
			throw e;
		}
	}

	public void tapOnTraditionalCD() throws Exception {
		mobileActions.isElementPresent(txtCDs, 5);
		try {
			mobileActions.isElementPresent(lnkTraditionalCDs, 2);
			lnkTraditionalCDs.click();
			LogUtility.logInfo("Clicked on Traditional CD");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Traditional CD " + e);
			throw e;
		}
	}

	public void tapOnYearBumpUpCD() throws Exception {
		mobileActions.isElementPresent(txtCDs, 5);
		try {
			mobileActions.swipeUpUntilTextExists(lnk3YearBumpUpCDs, 2);
			lnk3YearBumpUpCDs.click();
			LogUtility.logInfo("Clicked on 3 year bump up CD");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on year bump up CD " + e);
			throw e;
		}
	}

	public void verifyOpenAccountPage(String title) throws Exception {
		try {
			waits.staticWait(5);
			mobileActions.isElementDisplayed(
					appiumDriver.findElement(By.xpath(String.format(pageTitle, title, title, title))), 5);
			LogUtility.logInfo("Open a new account page is displayed as " + title);
		} catch (Exception e) {
			LogUtility.logError("Unable to view open a new account page " + e);
			mobileActions.isElementDisplayed(
					appiumDriver.findElement(By.xpath(String.format(pageTitle, title, title, title))), 5);
			throw e;
		}
	}

	public void enterEmailAddress(String email) throws Exception {
		retailAppUtils.fluentWaitElement(lblEmailAddress, 5, 1);
		try {
			txtEmailAddress.click();
			txtEmailAddress.clear();
			txtEmailAddress.sendKeys(email);
			if (TestDataConstants.getOSPlatformName().equals("ios"))
				btnDone.click();
			LogUtility.logInfo("Email address entered as " + email);
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable to enter email address " + e);
			throw e;
		}
	}

	public void enterPromoCode(String promoCode) throws Exception {
		try {
			mobileActions.isElementPresent(lblPromoCode, 3);
			txtPromoCode.clear();
			txtPromoCode.sendKeys(promoCode);
			LogUtility.logError("Entered promo code " + promoCode);
		} catch (Exception e) {
			LogUtility.logInfo("Unable to enter promo code due to " + e);
			throw e;
		}
	}

	public void verifyLightBoxMessage(String message) throws Exception {
		try {
			mobileActions.isElementPresentReplaceText(lightBoxMessage.replace("%s", message), 3);
			LogUtility.logError("Verified light box message displayed as " + message);
		} catch (Exception e) {
			LogUtility.logInfo("Unable to verify light box message displayed due to " + e);
			throw e;
		}
	}

	public boolean verifyUserNamePageDisplayed() {
		if (mobileActions.verifyIsElementPresent(titleUserName, 4))
			return true;
		else
			return false;
	}

	public void enterUserName(String userName) throws Exception {
		mobileActions.isElementPresent(titleUserName, 5);
		try {
			txtUserName.click();
			txtUserName.sendKeys(userName);
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable to enter UserName " + e);
			throw e;
		}
	}

	public void enterPassword(String password) throws Exception {
		if (mobileActions.verifyIsElementPresent(titleRegisterYourDevice, 5)) {
			mobileActions.swipeUp();
			txtAnswerInput.sendKeys(TestDataConstants.ANSWER);
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				appiumDriver.hideKeyboard();
			} else {
				btnDone.click();
			}
			rbtnRegisterDeviceNo.click();
			waits.staticWait(2);
			btnContinue.click();
		}
		try {
			retailAppUtils.fluentWaitElement(titlePassword, 5, 1);
			txtPassword.click();
			txtPassword.sendKeys(password);
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable to enter password " + e);
			throw e;
		}
	}

	public void tapOnContinueButton() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(btnContinue, 10, 2).click();
			LogUtility.logInfo("Clicked on continue button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on continue button " + e);
			LogUtility.logInfo("Trying to click again");
			mobileActions.scrollDown();
			try {
				btnContinue.click();
				LogUtility.logInfo("Clicked on continue button");
			} catch (NoSuchElementException ex) {
				LogUtility.logError("Unable to click on continue button " + ex);
				throw ex;
			}
		}
	}
	
	public boolean verifyContinueButtonIsDisplayed() throws Exception {
		if (mobileActions.verifyIsElementPresent(btnContinue, 4)) {
			LogUtility.logInfo("User is able to verify the Continue button");
			return true;
		}
		else {
			LogUtility.logInfo("User is Un able to verify the Continue button");
			return false;
	}
	}

	public void tapOnNoCard() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(lblNoCard, 10, 2).click();
			LogUtility.logInfo("Clicked on NOcard button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on NO card button " + e);
			LogUtility.logInfo("Trying to click again");
			mobileActions.scrollDown();
			try {
				lblNoCard.click();
				LogUtility.logInfo("Clicked on no card button");
			} catch (NoSuchElementException ex) {
				LogUtility.logError("Unable to click on no card button " + ex);
				throw ex;
			}
		}
	}

	public void tapOnBackButton() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(btnBack, 10, 2).click();
			LogUtility.logInfo("Clicked on back button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on back button " + e);
			LogUtility.logInfo("Trying to click again");
			mobileActions.scrollDown();
			try {
				btnBack.click();
				LogUtility.logInfo("Clicked on back button");
			} catch (NoSuchElementException ex) {
				LogUtility.logError("Unable to click on back button " + ex);
				throw ex;
			}
		}
	}

	public void tapOnCloseButton() throws Exception {
		mobileActions.isElementPresent(btnClose, 5);
		try {
			btnClose.click();
			LogUtility.logInfo("Clicked on Close button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on close button " + e);
			LogUtility.logInfo("Trying to click again");
			mobileActions.scrollDown();
			try {
				btnClose.click();
				LogUtility.logInfo("Clicked on close button");
			} catch (NoSuchElementException ex) {
				LogUtility.logError("Unable to click on close button " + ex);
				throw ex;
			}
		}
	}

	public void clickOkButton() {
		try {
			btnOk.click();
			LogUtility.logInfo("Clicked on Ok button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable to click on Ok button");
			throw e;
		}
	}

	public void verifyPersonalInformationPage() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(lblReviewPersonalInformation, 20, 2);
			mobileActions.isElementPresent(lblSocialSecurityNumber, 5);
			LogUtility.logInfo("Personal Information page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view personal information page " + e);
			throw e;
		}
	}

	public boolean verifyEmailErrorMessage(String error) throws Exception {
		mobileActions.isElementPresent(emailErrorMessage, 10);
		try {
			if (emailErrorMessage.getText().contains(error)) {
				LogUtility.logInfo("Error message displayed ");
				return true;
			} else {
				LogUtility.logInfo("Unable to view Error message ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to view Error message " + e);
			throw e;
		}
	}

	public void makeElementVisible() {
		if (TestDataConstants.getOSPlatformName().equals("ios"))
			btnDone.click();
		else
			appiumDriver.hideKeyboard();
	}

	public void enterPersonalInformationDetails(String dob, String firstName, String lastName, String address1,
			String address2, String city, String state, String zipCode) throws Exception {
		try {
			// Social Security Number
			if (mobileActions.isElementDisplayed(txtSocialSecurityNumber, 5)) {
				txtSocialSecurityNumber.sendKeys(retailAppUtils.getRandomNumber(9));
			}
			// Date of Birth
			if (mobileActions.isElementDisplayed(txtDOB, 3)) {
				txtDOB.sendKeys(dob);
			}
			// FirstName
			if (mobileActions.isElementDisplayed(txtFirstName, 3)) {
				txtFirstName.sendKeys(firstName + retailAppUtils.getRandomString(3));
			}
			// LastName
			if (mobileActions.isElementDisplayed(txtLastName, 3)) {
				txtLastName.sendKeys(lastName + retailAppUtils.getRandomString(3));
			} else {
				mobileActions.swipeUpUntilTextExists(txtLastName, 2);
				txtLastName.sendKeys(lastName + retailAppUtils.getRandomString(3));
			}
			// Phone number
			if (mobileActions.isElementDisplayed(txtPhoneNumber, 3)) {
				txtPhoneNumber.sendKeys(retailAppUtils.getRandomNumber(10));
				if(TestDataConstants.getOSPlatformName().equals("ios")) {
					btnDone.click();
				}
			} else {
				mobileActions.swipeUpUntilTextExists(txtPhoneNumber, 2);
				txtPhoneNumber.sendKeys(retailAppUtils.getRandomNumber(10));
			}
			// Address1
			if (mobileActions.isElementDisplayed(txtAddress1, 3)) {
				txtAddress1.sendKeys(address1);
			} else {
				mobileActions.swipeUpUntilTextExists(txtAddress1, 2);
				txtAddress1.sendKeys(address1);
			}
			// Address2
			if (mobileActions.isElementDisplayed(txtAddress2, 3)) {
				txtAddress2.sendKeys(address2);
			} else {
				mobileActions.swipeUpUntilTextExists(txtAddress2, 2);
				txtAddress2.sendKeys(address2);
			}
			// City
			if (mobileActions.isElementDisplayed(txtCity, 3)) {
				txtCity.sendKeys(city);
			} else {
				mobileActions.swipeUpUntilTextExists(txtCity, 2);
				txtCity.sendKeys(city);
			}
			// State
			if (mobileActions.isElementDisplayed(btnSelect, 5)) {
				btnSelect.click();
				mobileActions.isElementPresent(lblState, 5);
				retailAppUtils.fluentWait(By.xpath(String.format(stateSelect, state, state, state)), 10, 1).click();
			} else {
				mobileActions.swipeUpUntilTextExists(btnSelect, 2);
				btnSelect.click();
				appiumDriver.findElement(By.xpath(String.format(stateSelect, state, state, state))).click();
			}
			// ZipCode
			if (mobileActions.isElementDisplayed(txtZipCode, 3)) {
				txtZipCode.sendKeys(zipCode);
			} else {
				mobileActions.swipeUpUntilTextExists(txtZipCode, 2);
				txtZipCode.sendKeys(zipCode);
			}
			LogUtility.logInfo("Personal Information page is displayed");
			if (TestDataConstants.getOSPlatformName().equals("ios"))
				btnDone.click();
		} catch (Exception e) {
			LogUtility.logError("Unable to enter personal information page " + e);
			throw e;
		}
	}

	public void enterPersonalInformationDetailsExist(String ssn, String dob) throws Exception {
		try {
			// Social Security Number
			if (mobileActions.isElementDisplayed(txtSocialSecurityNumber, 5)) {
				txtSocialSecurityNumber.sendKeys(ssn);
			}
			// Date of Birth
			if (mobileActions.isElementDisplayed(txtDOB, 3)) {
				txtDOB.sendKeys(dob);
			}
			LogUtility.logInfo("Entered SSN and DOB exist data");
		} catch (Exception e) {
			LogUtility.logError("Unable to enter SSN and DOB exist data " + e);
			throw e;
		}
	}

	public void verifyIdentificationInformationPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblIdentificationInformation, 15);
			LogUtility.logInfo("Identification Information page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Identification information page " + e);
			throw e;
		}
	}

	public void verifyReviewPersonalInformationPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblReviewPersonalInformation, 15);
			mobileActions.swipeUp();
			mobileActions.swipeUp();
			LogUtility.logInfo("Review Personal Information page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Review Personal Information page " + e);
			throw e;
		}
	}

	public void selectCountry(String country) throws InterruptedException {
		if (mobileActions.verifyIsElementPresent(btnCountrySelect, 3)) {
			btnCountrySelect.click();
			try {
				if (TestDataConstants.getOSPlatformName().equals("ios"))
					appiumDriver.findElement(By.xpath(String.format(countrySelectiOS, country))).click();
				else
					retailAppUtils.fluentWait(By.xpath(String.format(countrySelect, country, country)), 30, 5).click();
			} catch (NoSuchElementException e) {
				try {
					LogUtility.logInfo("Trying to click again");
					if (TestDataConstants.getOSPlatformName().equals("ios"))
						appiumDriver.findElement(By.xpath(String.format(countrySelectiOS, country))).click();
					else
						retailAppUtils.fluentWait(By.xpath(String.format(countrySelect, country, country)), 30, 5)
								.click();
				} catch (NoSuchElementException ex) {
					LogUtility.logInfo("Trying to click again");
					if (TestDataConstants.getOSPlatformName().equals("ios"))
						appiumDriver.findElement(By.xpath(String.format(countrySelectiOS, country))).click();
					else
						retailAppUtils.fluentWait(By.xpath(String.format(countrySelect, country, country)), 30, 5)
								.click();
				}
			}
			mobileActions.swipeUp();
			LogUtility.logInfo("Clicked on country");
		}
	}

	public void enterIdentificationInformation(String country, String pep1, String pep2) throws Exception {
		try {
			// Country
			if (mobileActions.verifyIsElementPresent(btnCountrySelect, 3)) {
				btnCountrySelect.click();
				try {
					if (TestDataConstants.getOSPlatformName().equals("ios"))
						appiumDriver.findElement(By.xpath(String.format(countrySelectiOS, country))).click();
					else
						retailAppUtils.fluentWait(By.xpath(String.format(countrySelect, country, country)), 30, 5)
								.click();
				} catch (NoSuchElementException e) {
					try {
						LogUtility.logInfo("Trying to click again");
						if (TestDataConstants.getOSPlatformName().equals("ios"))
							appiumDriver.findElement(By.xpath(String.format(countrySelectiOS, country))).click();
						else
							retailAppUtils.fluentWait(By.xpath(String.format(countrySelect, country, country)), 30, 5)
									.click();
					} catch (NoSuchElementException ex) {
						LogUtility.logInfo("Trying to click again");
						if (TestDataConstants.getOSPlatformName().equals("ios"))
							appiumDriver.findElement(By.xpath(String.format(countrySelectiOS, country))).click();
						else
							retailAppUtils.fluentWait(By.xpath(String.format(countrySelect, country, country)), 30, 5)
									.click();
					}
				}
				LogUtility.logInfo("Clicked on country");
			}

			// PEP1
			if (pep1.equalsIgnoreCase("Yes")) {
				rbtnPep1Yes.click();
			} else if (pep1.equalsIgnoreCase("No")) {
				rbtnPep1No.click();
			}
			mobileActions.swipeUp();
			// PEP2
			if (pep2.equalsIgnoreCase("Yes")) {
				rbtnPep2Yes.click();
			} else if (pep2.equalsIgnoreCase("No")) {
				rbtnPep2No.click();
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to enter identification information details " + e);
			throw e;
		}
	}

	public void verifyNonResidentPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblNonResident, 10);
			LogUtility.logInfo("Are you a non resident page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Are you a non resident page " + e);
			throw e;
		}
	}

	public void tapOnResidentType(String residentType) {
		try {
			if (residentType.equalsIgnoreCase("Resident Alien"))
				rbtnResidentAlien.click();
			else
				rbtnNonResidentAlien.click();
			LogUtility.logInfo("Selected on Resident Type " + residentType);
		} catch (Exception e) {
			LogUtility.logError("Unable to select on Resident Type due to " + e);
			throw e;
		}
	}

	public void verifyDriverLicenseInformationPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblDriverLicenseInformation, 15);
			LogUtility.logInfo("Driver License Information page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Driver License information page " + e);
			throw e;
		}
	}

	public void enterDriverLicenseInformation(String state, String issueDate, String expireDate) throws Exception {
		try {
			// License State
			if (mobileActions.verifyIsElementPresent(btnLicenseState, 3)) {
				btnLicenseState.click();
				try {
					appiumDriver.findElement(By.xpath(String.format(licenseState, state, state, state))).click();
				} catch (NoSuchElementException e) {
					retailAppUtils.fluentWait(By.xpath(String.format(licenseState, state, state, state)), 30, 5)
							.click();
				}
			} else {
				if (TestDataConstants.getOSPlatformName().equals("ios")) {
					btnLicenseStateIos.click();
				} else {
					mobileActions.swipeUpUntilTextExists(btnLicenseStateIos, 2);
					btnLicenseStateIos.click();
				}
				appiumDriver.findElement(By.xpath(String.format(licenseState, state, state, state))).click();
			}
			// License number
			if (mobileActions.isElementDisplayed(txtLicenseNumber, 3)) {
				txtLicenseNumber.sendKeys(retailAppUtils.getRandomNumber(9));
			}
			// Issue Date
			if (mobileActions.isElementDisplayed(txtLicenseIssueDate, 3)) {
				txtLicenseIssueDate.sendKeys(issueDate);
			} else {
				mobileActions.swipeUpUntilTextExists(txtLicenseIssueDate, 2);
				txtLicenseIssueDate.sendKeys(issueDate);
			}
			// Expiration Date
			if (mobileActions.isElementDisplayed(txtLicenseExpirationDate, 3)) {
				txtLicenseExpirationDate.sendKeys(expireDate);
			} else {
				mobileActions.swipeUpUntilTextExists(txtLicenseExpirationDate, 2);
				txtLicenseExpirationDate.sendKeys(expireDate);
			}
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				appiumDriver.hideKeyboard();
			} else {
				btnDone.click();
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to enter drivers license information details " + e);
			throw e;
		}
	}
	
	
	public void verifyNeedDetailsOfNAO(String employeeInfo, String DrivingLicense, String SocialSecurity) throws Exception {
		try {
				String employeeText = lblEmploymentInfo.getText();
				Assert.assertEquals(employeeInfo, employeeText);

				String drivingLiceseText = lblDriverLicense.getText();
				Assert.assertEquals(DrivingLicense, drivingLiceseText);

				String socialSecurityText = lblSocialSecurity.getText();
				Assert.assertEquals(SocialSecurity, socialSecurityText);
			LogUtility.logInfo("--->Verified All Need Information in NAO Page<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify All Need Information in NAO Page" + e);
			throw e;
		}
	}

	public void verifyEmploymentInformationPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblEmploymentInformation, 15);
			LogUtility.logInfo("Employment Information page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Employment information page " + e);
			throw e;
		}
	}

	public void enterEmploymentInformation(String status, String empName, String jobTitle) throws Exception {
		try {
			// Employment Status
			if (mobileActions.verifyIsElementPresent(btnEmploymentSelect, 3)) {
				btnEmploymentSelect.click();
				mobileActions.isElementPresent(btnEmploymentStatus, 10);
				appiumDriver.findElement(By.xpath(String.format(employmentStatus, status, status, status))).click();
			} else {
				mobileActions.swipeUpUntilTextExists(btnEmploymentSelect, 2);
				btnEmploymentSelect.click();
				appiumDriver.findElement(By.xpath(String.format(employmentStatus, status, status, status))).click();
			}
			btnContinue.click();
			if (!status.equals("Other")) {
				if (mobileActions.verifyIsElementPresent(txtEmployerName, 5)) {
					txtEmployerName.sendKeys(empName);
					txtJobTitle.sendKeys(jobTitle);
					mobileActions.swipeUpUntilTextExists(btnContinue, 5);
					btnContinue.click();
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to enter employment information " + e);
			throw e;
		}
	}

	public void verifyReviewAccountPage(String product) throws Exception {
		String productDisplayed = null;
		try {
			mobileActions.isElementPresent(lblReviewAccountSelected, 10);
			mobileActions.isElementPresent(lblSetupAccountFeatures, 3);
			if (TestDataConstants.getOSPlatformName().equals("ios")) {
				productDisplayed = txtSelectedAccount.getAttribute("name");
			} else {
				productDisplayed = txtSelectedAccount.getText();
			}
			Assert.assertEquals(productDisplayed, product);
			LogUtility.logInfo("Selected Product is displayed");
			mobileActions.swipeUpUntilTextExists(lblRateTiers, 2);
			mobileActions.swipeUpUntilTextExists(lblGeneralNotes, 2);
			mobileActions.swipeUp();
			LogUtility.logInfo("Review the Account you selected page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Review the Account you selected page " + e);
			throw e;
		}
	}

	public void verifyReviewAccountPageCD(String product) throws Exception {
		try {
			mobileActions.isElementPresent(lblReviewAccountSelected, 15);
			mobileActions.isElementPresent(lblSetupAccountFeatures, 2);
			mobileActions.isElementPresent(lblRateTiersCD, 2);
			mobileActions.swipeUpUntilTextExists(txtSelectedAccountCD, 2);
			String productDisplayed = txtSelectedAccountCD.getText();
			Assert.assertEquals(productDisplayed, product);
			LogUtility.logInfo("Selected Product is displayed");
			mobileActions.swipeUpUntilTextExists(lblGeneralNotes, 2);
			mobileActions.swipeUp();
			LogUtility.logInfo("Review the Account you selected page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Review the Account you selected page " + e);
			throw e;
		}
	}

	public void verifyAccountInformationPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblAccountInformation, 15);
			LogUtility.logInfo("Account Information page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Account information page " + e);
			throw e;
		}
	}

	public void verifyInternationalWireServicesPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblInternationalWireServices, 10);
			LogUtility.logInfo("International Wire Services page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view International Wire Services page " + e);
			throw e;
		}
	}

	public void selectInternationalWireServices(String amount, String transaction) {
		try {
			// Intend to Wire Amount (Passing Static Value)
			rbtnIntendToWire5KTo10K.click();
			// Check Type of Transaction
			chkSendDomesticWires.click();
			mobileActions.swipeUp();
			LogUtility.logInfo("International Wire Services are selected");
		} catch (Exception e) {
			LogUtility.logError("Unable to select International Wire Services " + e);
		}
	}

	public void enterAccountInformation(String depositAmount, String withDrawAmount, String wireService)
			throws Exception {
		try {
			mobileActions.swipeDown();
			// Deposit Amount(Passing static values as there is no compulsion to pass
			// specific values)
			if (depositAmount != null)
				rbtnDepositLess5K.click();
			// WithDraw Amount(Passing static values)
			mobileActions.swipeUpUntilTextExists(rbtnWithDrawLess5K, 1);
			if (withDrawAmount != null)
				rbtnWithDrawLess5K.click();
			if (wireService.equalsIgnoreCase("Yes")) {
				mobileActions.swipeUpUntilTextExists(rbtnInternalWireServicesYes, 1);
				rbtnInternalWireServicesYes.click();
			} else {
				mobileActions.swipeUpUntilTextExists(rbtnInternalWireServicesNo, 1);
				rbtnInternalWireServicesNo.click();
			}
			LogUtility.logInfo("Account information details updated ");
		} catch (Exception e) {
			LogUtility.logError("Unable to fill account information details " + e);
			throw e;
		}
	}

	public void verifyChooseDebitCardPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblChooseMyDebitCard, 15);
			List<RemoteWebElement> debitCard = new ArrayList<RemoteWebElement>();
			debitCard.addAll(Arrays.asList(rbtnNoCard, rbtnVisaDebitCard, txtDebitCardOverdraftServices,
					rbtnPayOverDraftYes, rbtnPayOverDraftNo, txtEnrollStatementeDelivery));
			mobileActions.elementsPresent(debitCard);
			LogUtility.logInfo("Choose My Debit Card page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Choose My Debit Card page " + e);
			throw e;
		}
	}

	public void verifyAccountOptionsPage() throws Exception {
		try {
			mobileActions.isElementPresent(txtEnrollStatementeDelivery, 10);
			LogUtility.logInfo("Account Options page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Account Options page " + e);
			throw e;
		}
	}

	public void selectAnyCardAndODService() throws Exception {
		try {
			rbtnVisaDebitCard.click();
			rbtnPayOverDraftYes.click();
			LogUtility.logInfo("Selected any debit card and OD Service");
		} catch (Exception e) {
			LogUtility.logError("Unable to Select any debit card and OD Service " + e);
			throw e;
		}
	}

	public void verifyDebitCardOverDraftServices() throws Exception {
		try {
			mobileActions.isElementPresent(txtDebitCardOverdraftServices, 10);
			mobileActions.isElementPresent(txtEnrollStatementeDelivery, 2);
			LogUtility.logInfo("Choose My Debit Card page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Choose My Debit Card page " + e);
			throw e;
		}
	}

	public void verifyPersonalInformationScreen() throws Exception {
		try {
			mobileActions.isElementPresent(lblVerifyPersonalInformation, 15);
			mobileActions.swipeUpUntilTextExists(lblVerifyAccountInformation, 3);
			mobileActions.swipeUpUntilTextExists(btnEditPersonalInformation, 3);
			mobileActions.swipeUpUntilTextExists(btnEditAccountInformation, 3);
			LogUtility.logInfo("Verify Personal Information page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Verify Personal information page " + e);
			throw e;
		}
	}

	public void tapOnEditButtonInPersonalInformationPage() throws Exception {
		try {
			mobileActions.swipeUpUntilTextExists(btnEditPersonalInformation, 5);
			LogUtility.logInfo("Successfully clicked on Edit Button in Personal Information page");
		} catch (Exception e) {
			LogUtility.logError("Unable to clicked on Edit Button in  Personal information page " + e);
			throw e;
		}
	}

	public void tapOnEditButtonInAccountInformationPage() throws Exception {
		try {
			mobileActions.swipeUpUntilTextExists(btnEditAccountInformation, 5);
			LogUtility.logInfo("Successfully clicked on Edit Button in Account Information page");
		} catch (Exception e) {
			LogUtility.logError("Unable to clicked on Edit Button in  Account information page " + e);
			throw e;
		}
	}

	public void verifyYourIdentityPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblVerifyYourIdentity, 10);
			mobileActions.swipeDown();
			mobileActions.isElementPresent(imgEquifax, 3);
			mobileActions.swipeUpUntilTextExists(lblEmulationQuestion1, 2);
			mobileActions.swipeUpUntilTextExists(lblEmulationQuestion2, 2);
			mobileActions.swipeUpUntilTextExists(btnIDontKnowTheAnswers, 3);
			LogUtility.logInfo("Verify Your Identity page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Verify Your Identity information page " + e);
			throw e;
		}
	}

	public void enterPromoCodeAndEmail(String emailAddress, String promoCode) throws Exception {
		mobileActions.isElementPresent(lblEmailAddress, 5);
		try {
			txtEmailAddress.click();
			txtEmailAddress.clear();
			txtEmailAddress.sendKeys(emailAddress);
			txtPromoCode.click();
			txtPromoCode.clear();
			txtPromoCode.sendKeys(promoCode);
			if (TestDataConstants.getOSPlatformName().equals("ios"))
				btnDone.click();
			LogUtility.logInfo("Email address entered as " + emailAddress);
			LogUtility.logInfo("promocode  entered as " + promoCode);
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable to enter promocode and email address " + e);
			throw e;
		}
	}

	public void selectEmulationAnswers(String emulationAns1, String emulationAns2) {
		try {
			mobileActions.swipeDown();
			appiumDriver
					.findElement(
							By.xpath(String.format(emulationQAOneSelect, emulationAns1, emulationAns1, emulationAns1)))
					.click();
			mobileActions.swipeUp();
			appiumDriver
					.findElement(
							By.xpath(String.format(emulationQATwoSelect, emulationAns2, emulationAns2, emulationAns2)))
					.click();
			LogUtility.logInfo("Selected the emulaion answers");
		} catch (Exception e) {
			LogUtility.logError("Unable to select the emulation answers " + e);
			throw e;
		}
	}

	public void verifyOpportunityCheckingPage() throws Exception {
		try {
			mobileActions.isElementPresent(lblOpportunityChecking, 10);
			/**
			 * Commented below line to verify Product Details page link displayed on page
			 * for now
			 **/
			// mobileActions.isElementPresent(txtProductDetailsPage, 3);
			mobileActions.isElementPresent(lblConditionAvoidMonthlySerCharge, 1);
			mobileActions.swipeUpUntilTextExists(lblMonthlyServiceChargeTransFee, 1);
			mobileActions.swipeUpUntilTextExists(lblRateTiersOpportunity, 1);
			mobileActions.swipeUpUntilTextExists(chkSendMeMyFreeVisaDebitCard, 1);
			mobileActions.swipeUpUntilTextExists(chkEnrollThisAccount, 1);
			mobileActions.isElementPresent(btnDecline, 2);
			LogUtility.logInfo("Opportunity Checking Account Informaion page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Opportunity Checking Account Information page " + e);
			throw e;
		}
	}

	public void verifyOpportunityCheckingPageNotDisplayed() throws Exception {
		try {
			mobileActions.isElementNotPresent(By.xpath("lblOpportunityChecking"), 10);
			LogUtility.logInfo("Opportunity Checking Account Informaion page is not displayed");
		} catch (Exception e) {
			LogUtility.logError("Able to view Opportunity Checking Account Information page " + e);
			throw e;
		}
	}

	public void verifyTermsAndConditionsPage() throws Exception {
		mobileActions.isElementPresent(lblDisclosuresIAgree, 10);
		List<RemoteWebElement> termsAndConditionsElements = new ArrayList<RemoteWebElement>();

		try {
			if (TestDataConstants.getOSPlatformName().equals("ios")) {
				termsAndConditionsElements.addAll(Arrays.asList(chkEDeliveryAgreement, chkFeeScheduleConsumerAccounts,
						chkPrivacyOptOutNotice, chkWebsterOnlineServicesAgreement));
				mobileActions.elementsPresent(termsAndConditionsElements);
				mobileActions.swipeUpUntilTextExists(chkInterestRateDisclosure, 2);
				mobileActions.swipeUpUntilTextExists(chkDepositAccountDisclosure, 1);
			} else {
				termsAndConditionsElements.addAll(Arrays.asList(chkDepositAccountDisclosure, chkEDeliveryAgreement,
						chkFeeScheduleConsumerAccounts, chkInterestRateDisclosure, chkPrivacyOptOutNotice,
						chkWebsterOnlineServicesAgreement));
				mobileActions.elementsPresent(termsAndConditionsElements);
			}
			LogUtility.logInfo("Terms and Conditions Page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Terms and Conditions Page " + e);
			throw e;
		}
	}

	public void checkAllCheckboxes() {
		try {
			chkWebsterOnlineServicesAgreement.click();
			chkEDeliveryAgreement.click();
			chkPrivacyOptOutNotice.click();
			mobileActions.swipeUp();
			chkFeeScheduleConsumerAccounts.click();
			chkInterestRateDisclosure.click();
			chkDepositAccountDisclosure.click();
			LogUtility.logInfo("Checked all checkboxes in conditions page");
		} catch (Exception e) {
			LogUtility.logError("Unable to check all checkboxes " + e);
			throw e;
		}
	}

	public void verifyCreateYourProfilePage() throws Exception {
		mobileActions.isElementPresent(lblCreateYourProfile, 10);
		try {
			List<RemoteWebElement> createYourProfile = Arrays.asList(txtUserName, txtPassword, txtReEnterPassword);
			mobileActions.elementsPresent(createYourProfile);
			LogUtility.logInfo("Create Your Profile page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Create Your Profile page " + e);
			throw e;
		}
	}

	public void enterNewUserNamePassword(String userName, String password) throws Exception {
		try {
			txtUserName.sendKeys(userName + retailAppUtils.getRandomString(5));
			txtPassword.sendKeys(password);
			txtReEnterPassword.sendKeys(password);
			LogUtility.logInfo("Entered new username and password");
		} catch (Exception e) {
			LogUtility.logError("Unable to enter new username and password " + e);
			throw e;
		}
	}

	public void verifyNAOConfirmationPage() throws Exception {
		mobileActions.isElementPresent(lblCongratulations, 10);
		try {
			List<RemoteWebElement> confirmationPage = new ArrayList<RemoteWebElement>();
			confirmationPage.addAll(Arrays.asList(txtAccountType, txtAccountNumber, txtRoutingNumber));
			mobileActions.elementsPresent(confirmationPage);
			LogUtility.logInfo("Nao cconfirmation page is displayed with account number, routing number, account type");
		} catch (Exception e) {
			LogUtility.logError(
					"Unable to view Nao cconfirmation page is displayed with account number, routing number, account ype "
							+ e);
			throw e;
		}
	}

	public void clickOnExistingCustomer() {
		try {
			if (mobileActions.isElementDisplayed(lnkExistingCustomer, 3)) {
				lnkExistingCustomer.click();
				if (!mobileActions.isElementDisplayed(titleUserName, 5)) {
					mobileActions.swipeUp();
					lnkExistingCustomer.click();
				}
				LogUtility.logInfo("Clicked on existing customer link");
			}
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable to click on Existing Customer link " + e);
			throw e;
		}
	}

	public void tapOnCheckingsAccountsWeb() throws Exception {
		try {
			btnCheckingsAccounts.click();
			LogUtility.logInfo("Clicked on Checkings Accounts");
		} catch (Exception e) {
			LogUtility.logError("Unable click on Checkings Accounts " + e);
			throw e;
		}
	}

	public void tapOnOpportunityChecking() {
		if (mobileActions.isElementDisplayed(lnkOpportunityChecking, 3)) {
			LogUtility.logInfo("Opportunity Checking is displayed");
		} else {
			mobileActions.swipeUpUntilTextExists(lnkOpportunityChecking, 3);
		}
		try {
			lnkOpportunityChecking.click();
			LogUtility.logInfo("Tapped on Opportunity Checking");
		} catch (Exception e) {
			LogUtility.logError("Unable to tap on Opportunity Checking due to " + e);
			throw e;
		}
	}

	public void verifyOpenAccountButtonOpportunity() {
		if (!mobileActions.verifyIsElementPresent(btnContinue, 5))
			LogUtility.logInfo("Verified Opportunity Checking has no Open Account button");
		else
			LogUtility.logError("verifyOpenAccountButtonOpportunity",
					"Open Account button is available for Opportunity Checking");
	}

	public boolean verifyErrorMessage(String error) throws Exception {
		mobileActions.isElementPresent(txtErrorMessageUnable, 10);
		if (!txtErrorMessageUnable.getText().contains(error)) {
			LogUtility.logInfo("Error message displayed ");
			return false;
		} else {
			LogUtility.logError("Unable to view Error message ");
			return true;
		}
	}

	public boolean verifyErrorMessagePEP(String error) throws Exception {
		mobileActions.isElementPresent(txtErrorMessagePEP, 10);
		if (!txtErrorMessagePEP.getText().contains(error)) {
			LogUtility.logInfo("Error message displayed ");
			return false;
		} else {
			LogUtility.logError("Unable to view Error message ");
			return true;
		}
	}


	public boolean verifyMessageExist(String message) throws Exception {
		mobileActions.isElementPresent(txtMessageExist, 10);
		if (!txtMessageExist.getText().contains(message)) {
			LogUtility.logInfo("Message displayed ");
			return false;
		} else {
			LogUtility.logError("Unable to view Message ");
			return true;
		}
	}

	public void verifyReadAndAgreeMessage() throws Exception {
		try {
			mobileActions.isElementPresent(txtReadAndAgreeMessage, 10);
			LogUtility.logInfo("Before you Continue, read and agree message is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to view Before you Continue, read and agree message " + e);
			throw e;
		}
	}

	public void tapOnSignInLink() {
		try {
			lnkSignIn.click();
			LogUtility.logInfo("Clicked on Sign In link");
		} catch (Exception e) {
			LogUtility.logInfo("Unable to click on Sign In link " + e);
			throw e;
		}
	}
	
	public void closeChromeTabs() throws Exception {
		try {
			mobileActions.switchToNativeView();
			iconChromeTab.click();
			mobileActions.isElementPresent(btnMenuChrome, 5);
			btnMenuChrome.click();
			mobileActions.isElementPresent(txtCloseTabs, 5);
			txtCloseTabs.click();
			LogUtility.logInfo("Closed chrome tabs");
		}catch(Exception e) {
			LogUtility.logError("Unable to Close Chrome tabs");
			throw e;
		}
	}

}
