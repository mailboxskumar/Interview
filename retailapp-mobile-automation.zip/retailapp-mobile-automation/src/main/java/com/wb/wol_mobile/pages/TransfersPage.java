package com.wb.wol_mobile.pages;

import static com.wb.wol_mobile.utilities.TestDataConstants.TRANSFERHISTORY_POSTED;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.touch.offset.PointOption;

public class TransfersPage extends ObjectBase {

	private String selectAccount;
	private String accountFromBalance;

	String iosDeliveryDate;

	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	ManageAlertsPage manageAlertsPage = new ManageAlertsPage();
	MobileActions mobileActions = new MobileActions();
	CommonPage commonPage = new CommonPage();

	RetailAppUtils retailAppUtils = new RetailAppUtils();

	public TransfersPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	@AndroidFindBy(xpath = "//*[@text=\"Transfer Funds\"]")
	@iOSFindBy(xpath = "//*[@label=\"Transfer Funds\"]")
	protected MobileElement lblTransfersModule;

	/** Need to provide the locator for iOS **/
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/parallax_button_1\"]")
	// @iOSFindBy(xpath = "")
	protected MobileElement btnTransferFunds;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/empty_view_text\"]")
	@iOSFindBy(xpath = "//*[@label=\"No results\"]")
	protected MobileElement txtNoItems;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/title\"]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='CREATE TRANSFER']")
	@iOSFindBy(xpath = "//*[@label=\"CREATE TRANSFER\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Submit']")
	protected MobileElement lblCreateTransfer;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/account_name\"]")
	@iOSFindBy(xpath = "//*[@name=\"TransfersFromAccountCell\" and @value=\"From\"]")
	protected MobileElement lblTransferFrom;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/currency\")")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value = 'Amount' and @enabled = 'true']")
	@CacheLookup
	protected MobileElement lblAmount;

	/** Need to provide the locator for iOS **/
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'From' and @enabled = 'true']")
	protected MobileElement lblFrom;

	/** Need to provide the locator for iOS **/
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'To' and @enabled = 'true']")
	// @iOSFindBy(xpath = "")
	protected MobileElement lblTo;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/button\"]")
	@AndroidFindBy(xpath = "//*[@text='Delivery Date']")
	@AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name=\"TransfersSendDatePropertyCell\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@label = 'Delivery Date' and @enabled = 'true']")
	protected MobileElement lblDeliveryDate;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.Button[1]")
	protected MobileElement txtDeliveryDate;

	/** Need to provide the locator for iOS **/
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Transfer Type' and @enabled = 'true']")
	// @iOSFindBy(xpath = "")
	protected MobileElement lblTransferType;

	/** Need to provide the locator for iOS **/
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Reference Number' and @enabled = 'true']")
	// @iOSFindBy(xpath = "")
	protected MobileElement lblReferenceNumber;

	/** Need to provide the locator for iOS **/
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Memo' and @enabled = 'true']")
	// @iOSFindBy(xpath = "")
	protected MobileElement lblMemo;

	/** Need to provide the locator for iOS **/
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Status' and @enabled = 'true']")
	// @iOSFindBy(xpath = "")
	protected MobileElement lblStatus;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/recycler_view\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeCell[1]")
	protected MobileElement lblSpecifiedTransfer;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Cancel Transfer']")
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/action_main\"]")
	@AndroidFindBy(xpath = "//*[@text='Cancel']")
	@iOSFindBy(xpath = "//*[@label=\"Cancel Transfer\"]")
	@iOSFindBy(xpath = "//*[@label=\"Cancel\"]")
	@iOSFindBy(xpath = "//*[@label=\"Delete\"]")
	protected MobileElement lblCancelTransfer;

	@iOSFindBy(xpath = "//*[@label=\"return\"]")
	protected MobileElement btnReturn;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/button_ok")
	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/button1\"]")
	@iOSFindBy(xpath = "//*[@label=\"OK\"]")
	@iOSFindBy(xpath = "//*[@label=\"Done\"]")
	protected MobileElement btnOk;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeNavigationBar/XCUIElementTypeOther")
	protected MobileElement titleTransferNameNavigationBar;

	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/message\"]")
	@iOSFindBy(xpath = "//*[@value=\"You do not currently have access to perform this function based on your assigned role. Please speak with your business account administrator for more information.\"]")
	protected MobileElement lblErrorMessageViewOnly;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@iOSFindBy(xpath = "//*[@label=\"Sorry, none of your accounts are eligible to use this feature.\"]")
	@CacheLookup
	protected MobileElement txtErrorNotSupported;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@CacheLookup
	protected MobileElement lblSuccessMessage;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Amount entered is less than the minimum amount due for payment. Please enter at least the minimum amount due.']")
	@CacheLookup
	protected MobileElement txtLessAmountErrorMessage;

	@AndroidFindBy(xpath = "//*[@resourceid=\"com.malauzai.websterbank:id/textinput_error\"]")
	@iOSFindBy(xpath = "//*[@label=\"Amount exceeds Available Balance\"]")
	protected MobileElement txtExceedErrorMessage;

	@AndroidFindBy(xpath = "//*[@resourceid=\"com.malauzai.websterbank:id/textinput_error\"]")
	@iOSFindBy(xpath = "//*[@label=\"Amount must be greater than $0.00\"]")
	protected MobileElement txtZeroErrorMessage;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='The transfer amount requested is equal to or greater than your loan balance. Please select a lesser amount; or if you would like to payoff your loan, please contact us at 800-995-9995.']")
	protected MobileElement txtEqualAmountErrorMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='android:id/message']")
	@AndroidFindBy(xpath = "//*[@resourceid=\"android:id/message\"]")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(className = "XCUIElementTypeStaticText")
	protected MobileElement txtTransferExecutedPopUpMessage;

	/** Need to provide the locator for Android **/
	@iOSFindBy(xpath = "//*[@label=\"Your session will expire in 1 minute\"]")
	protected MobileElement txtTimeOutPopUpMessage;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@iOSFindBy(className = "XCUIElementTypeStaticText")
	protected MobileElement txtTransferMaximumAmount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@iOSFindBy(xpath = "//*[@label=\"Transfer Canceled Successfully\"]")
	protected MobileElement txtCancelSuccessMessage;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	// TODO
	// @iOSFindBy(xpath = "//*[@label=\"The TO and FROM accounts cannot be the
	// same\"]")
	protected MobileElement txtSnackBarMessage;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@iOSFindBy(xpath = "//*[@label=\"The TO and FROM accounts cannot be the same\"]")
	protected MobileElement txtToAndFromMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@AndroidFindBy(id = "android:id/message")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id = 'android:id/message']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'Transfer Executed Successfully. Confirmation number:')]")
	protected MobileElement transferOkPopUpMessage;

	/** Need to provide the locator for Android **/
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/textinput_error\"]")
	@iOSFindBy(xpath = "//*[@label=\"Amount must be greater than $0.00\"]")
	@CacheLookup
	protected MobileElement errorMessageMissingAmount;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/recycler_view\"]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.ImageButton[1]")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeCell[1]/XCUIElementTypeButton[1]")
	@CacheLookup
	protected MobileElement btnMoreOptions;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/parallax_button_1\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Transfer Funds' and @enabled = 'true']")
	protected MobileElement lblTransferFunds;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/editable_rows']/android.widget.RelativeLayout[2]")
	@iOSFindBy(xpath = "//*[@name=\"TransfersToAccountCell\" and @value=\"To\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name='TransfersToAccountCell']")
	@iOSFindBy(xpath = "//*[@label=\"To\" and @name=\"TransfersToAccountCell\"]")
	protected MobileElement txtTransfersTo;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/editable_rows']/android.widget.RelativeLayout[1]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name='TransfersFromAccountCell']")
	@iOSFindBy(xpath = "//*[@name=\"TransfersFromAccountCell\" and @value=\"From\"]")
	@iOSFindBy(xpath = "//*[@label=\"From\" and @name=\"TransfersFromAccountCell\"]")
	protected MobileElement txtTransfersFrom;

	@AndroidFindBy(xpath = "//*[@class=\"android.widget.ListView\"]/group[2]")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[2]")
	protected MobileElement lstTransfersTo;

	@AndroidFindBy(xpath = "//*[@class=\"android.widget.ListView\"]/group[1]")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[1]")
	protected MobileElement lstTransfersFrom;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/currency")
	@iOSFindBy(xpath = "//*[@label=\"Amount\"]/XCUIElementTypeTextField[2]")
	protected MobileElement txtAmount;

	@AndroidFindBy(xpath = "//*[@text=\"Memo\"]")
	@iOSFindBy(xpath = "//*[@value=\"Memo\"]")
	@CacheLookup
	protected MobileElement txtMemo;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//*[@label=\"Done\"]")
	@CacheLookup
	protected MobileElement btnDone;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='View Details']")
	@iOSFindBy(xpath = "//*[@label=\"View Details\"]")
	@CacheLookup
	protected MobileElement btnViewDetails;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='TRANSFER DETAILS']")
	@iOSFindBy(xpath = "//*[@label=\"TRANSFER DETAILS\"]")
	@CacheLookup
	protected MobileElement txtTransferDetails;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/action_more")
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/button1']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Confirm']")
	@iOSFindBy(xpath = "//*[@label=\"Cancel Transfer\"]")
	@iOSFindBy(xpath = "//*[@label=\"Cancel\"]")
	@CacheLookup
	protected MobileElement btnConfirm;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@name='IOFSelectionListTableViewCellIdentifier']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell")
	protected List<RemoteWebElement> transferFromListedCount;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@name='IOFSelectionListTableViewCellIdentifier']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell")
	protected List<RemoteWebElement> transferToListedCount;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	// @AndroidFindBy(id = "com.malauzai.websterbank:id/transfer_information")
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/memo']")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeCell")
	protected List<RemoteWebElement> transferHistoryCount;

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/memo']")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeCell")
	protected MobileElement txtTransactionStatus;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected List<RemoteWebElement> transferFromCount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected List<RemoteWebElement> transferToCount;

	/** Added by Phani **/

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='CREATE TRANSFER']")
	@iOSFindBy(xpath = "//*[@label=\"CREATE TRANSFER\"]")
	protected MobileElement titleCreateTransfer;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/selected_day_of_month_date")
	@iOSFindBy(xpath = "//*[@label=\"Clear Date\"]")
	protected MobileElement paneCalendar;

	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc='%Day, %Month %Date %Year is not available, please select a different date.']")
	protected MobileElement lblPreviousDate;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/button_ok")
	@iOSFindBy(xpath = "//*[@label=\"Done\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Done' and @enabled = 'true']")
	protected MobileElement btnCalendarOkDone;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "android:id/message")
	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/snackbar_text']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText")
	protected MobileElement txtAlertMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/button1\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='OK']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='OK' and @enabled ='true']")
	protected MobileElement btnAlertOK;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='OK' and @enabled ='true']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='OK']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@text='OK']")
	@iOSFindBy(xpath = "//*[@label=\"OK\"]")
	protected MobileElement btnOkPopup;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='TRANSFER FUNDS']")
	@iOSFindBy(xpath = "//*[@label='TRANSFER FUNDS']")
	protected MobileElement titleTransferFunds;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Tap to edit this transfer. Menu']")
	protected MobileElement btnTapMenu;

	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name='TransfersFromAccountCell']")
	protected MobileElement txtFromField;

	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name='TransfersToAccountCell']")
	protected MobileElement txtToField;

	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/button_done']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Submit']")
	protected MobileElement lblSubmitTransfer;

	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView[@label=', Amount, amountEntered, From, fromAccount, To, toAccount, Delivery Date, dateSelected']")
	protected MobileElement txtValuesSubmitPage;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='View Accounts']")
	@iOSFindBy(xpath = "//*[@label=\"View Accounts\"]")
	protected MobileElement lblViewAccountsModule;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='VIEW ACCOUNTS']")
	@iOSFindBy(xpath = "//*[@label='VIEW ACCOUNTS']")
	protected MobileElement lblViewAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText")
	protected List<RemoteWebElement> titleAcctName;

	public String xpathSelectedFromAccountBalance = "//XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[3] |"
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/balance_display'])[%d]";

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name']")
	protected MobileElement accountNameFromAndTo;

	public String xpathSelectedToAccountBalance = "//XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[3] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/balance_display'])[%d]";

	private String dynamicFromAndToAccountValue = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	private String dynamicTransferHistoryCount = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[4] | "
			+ "(//*[@resource-id=\"com.malauzai.websterbank:id/recycler_view\"]/android.widget.FrameLayout)[%d]";
	public String dynamicXpathAccountName = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | (//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";
	public String dynamicXpathToAccountName = "//XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | (//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	public String dynamicXpathBalances = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[3] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/primary_balance_value'])[%d]";

	public String dynamicXpathFromBalances = "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/balance_display'])[%d] | "
			+ "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[3]";

	public String dynamicXpathNaAccount = "//XCUIElementTypeStaticText[1]";
	public String dynamicXpathAndroidPosted = "com.malauzai.websterbank:id/memo";
	public String dynamicXpathPosted = "//XCUIElementTypeStaticText[4]";
	public String dynamicXpathPendingTransfer = "//*[@text='%s'] | //*[@value='%s']";

	public String dynamicXpathAccountBalance = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1]/following::XCUIElementTypeStaticText[3]";
	public String dynamicXpathSubmitTransferPage = "//XCUIElementTypeCollectionView[@label=', Amount, %s, From, %s, To, %s, Delivery Date, %s']";
	public String dynamicXpathFromToAccount = "//android.widget.Spinner[2]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.TextView[%d]";

	private List<String> validBalances = new ArrayList<String>();
	private List<String> inValidBalances = new ArrayList<String>();
	private List<String> validAccounts = new ArrayList<String>();
	private List<String> inValidAccounts = new ArrayList<String>();
	private String amountEnter;
	private String fromBalance;
	private String toBalance;
	private String selectedFromAccountBalance;
	private String selectedToAccountBalance;
	private int countBalances;
	public String fromAccountSelected;
	public String toAccountSelected;
	public String defaultDate;
	public String getFromAccountAndroid;
	public String getToAccountAndroid;

	/**
	 * Method to Verify TransfersModule label
	 * 
	 */
	public void verifyTransfersModule() throws Exception {
		try {
			lblTransfersModule.isDisplayed();
			LogUtility.logInfo("Verification of Transfer Module at Menu Page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Transfers Module<---" + e.getStackTrace());
			throw new Exception("Unable to verify Transfers Module " + e);
		}
	}

	/**
	 * Method to Verify From label
	 * 
	 */
	public void verifyFrom() throws Exception {
		try {
			lblFrom.isDisplayed();
			LogUtility.logInfo("Verification of From lable at Transfer details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify From label<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify To label
	 * 
	 */
	public void verifyTo() throws Exception {
		try {
			lblTo.isDisplayed();
			LogUtility.logInfo("Verification of To lable at Transfer details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify To label<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify Delivery Date label
	 * 
	 */

	public void verifyDeliveryDate() throws Exception {
		try {
			lblDeliveryDate.isDisplayed();
			LogUtility.logInfo("Verification of Delivery date lable at Transfer details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Delivery Date<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify TransferType label
	 * 
	 */

	public void verifyTransferType() throws Exception {
		try {
			lblTransferType.isDisplayed();
			LogUtility.logInfo("Verification of Transfer Type lable at Transfer details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Transfer Type<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify ReferenceNumber label
	 * 
	 */

	public void verifyReferenceNumber() throws Exception {
		try {
			lblReferenceNumber.isDisplayed();
			LogUtility.logInfo("Verification of Reference Number lable at Transfer details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Reference Number<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify Memo Label
	 * 
	 */

	public void verifyMemo() throws Exception {
		try {
			lblMemo.isDisplayed();
			LogUtility.logInfo("Verification of Memo lable at Transfer details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Memo<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify Status label
	 * 
	 */

	public void verifyStatus() throws Exception {
		try {
			lblStatus.isDisplayed();
			LogUtility.logInfo("Verification of Status lable at Transfer details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Status<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify Transfer Details
	 * 
	 */

	public void verifyTextTransferDetails() throws Exception {
		try {
			// After loading of the waiting for element to get identify
			waits.staticWait(4);
			txtTransferDetails.isDisplayed();
			LogUtility.logInfo("Verification of Transfer Deatils at Transfers page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify TransferDetails<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Transfers from the list of Hamburger Menu
	 * 
	 */

	public void clickTransfersModule() throws Exception {
		try {
			lblTransfersModule.click();
			LogUtility.logInfo("Succsessfully clicked on Transfers Module");
			mobileActions.isElementPresent(titleTransferFunds, 100);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Transfers Module<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on first Item from the list of Transfer history list
	 * 
	 */
	public void clickSpecifiedTransfer() throws Exception {
		try {
			lblSpecifiedTransfer.click();
			LogUtility.logInfo("Succsessfully clicked on Specified transfer");

		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Specified transfer<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click TransferFunds Label
	 * 
	 */

	public void clickTransferFunds() throws Exception {
		mobileActions.isElementPresent(lblTransferFunds, 10);
		try {
			mobileActions.isElementPresent(btnMoreOptions, 10);
			lblTransferFunds.click();
			mobileActions.isElementPresent(lblCreateTransfer, 10);
			LogUtility.logInfo("Succsessfully clicked on Transfer Funds");
		} catch (Exception e) {
			try {
				lblTransferFunds.click();
				mobileActions.isElementPresent(lblCreateTransfer, 10);
			} catch (NoSuchElementException ex) {
				LogUtility.logError("Unable to click on transfer funds button " + e);
				throw e;
			}
		}
	}

	public void clickOnlyTransferFunds() throws Exception {
		mobileActions.isElementPresent(lblTransferFunds, 10);
		try {
			lblTransferFunds.click();
			LogUtility.logInfo("Succsessfully clicked on Transfer Funds");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on transfer funds button " + e);
			throw e;
		}
	}

	/**
	 * Method to click Return Button from Keyboard
	 * 
	 */

	public void clickReturnButton() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				btnReturn.click();
				LogUtility.logInfo("Succsessfully clicked on return button");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Return button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Confirm Button
	 * 
	 */

	public void clickConfirmButton() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				if (mobileActions.verifyIsElementPresent(btnConfirm, 5))
					btnConfirm.click();
				LogUtility.logInfo("Succsessfully clicked on Confirm button");
			} else if (TestDataConstants.getOSPlatformName().contains("ios")) {
				btnConfirm.click();
				LogUtility.logInfo("Succsessfully clicked on Confirm button and ready to click OK button");
				mobileActions.isElementPresent(btnAlertOK, 10);
				btnAlertOK.click();
				LogUtility.logInfo("Succsessfully clicked on OK button after confirm button");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Confirm button<---" + e.getStackTrace());
			throw e;
		}
	}

	public void clickOnlyConfirmButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnConfirm, 10);
			btnConfirm.click();
			LogUtility.logInfo("Succsessfully clicked on Confirm button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Confirm button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click View-Details Button
	 * 
	 */

	public void clickViewDetailsButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnViewDetails, 30);
			btnViewDetails.click();
			LogUtility.logInfo("Succsessfully clicked on View Details Button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on View Details<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click View-Details Button
	 * 
	 */

	public void clickCancelTransfer() throws Exception {
		try {
			mobileActions.isElementPresent(lblCancelTransfer, 30);
			lblCancelTransfer.click();
			LogUtility.logInfo("Succsessfully clicked on Cancel Transfer");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Cancel Transfer<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to enter Amount in text field
	 * 
	 * @param
	 */
	public void clickTextTransfersTo() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				txtTransfersTo.findElement(By.id("com.malauzai.websterbank:id/value")).click();
				LogUtility.logInfo("clicked successfully Transfers To");
			} else {
				txtTransfersTo.click();
				LogUtility.logInfo("clicked successfully Transfers To");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Transfers To<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Click Transfer From
	 * 
	 * @param
	 */
	public void clickTransfersFromText() throws Exception {
		try {
			mobileActions.isElementPresent(txtTransfersFrom, 10);
			txtTransfersFrom.click();
			LogUtility.logInfo("clicked successfully Transfers From");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Transfers From<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to enter Amount in text field
	 * 
	 * @param
	 * @throws Exception
	 */
	public void enterAmount(String amount) throws Exception {
		amountEnter = amount;
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				for (int i = 0; i < amountEnter.length(); i++) {
					char c = amountEnter.charAt(i);
					String eachCharacter = new StringBuilder().append(c).toString();
					txtAmount.sendKeys(eachCharacter);
				}
			} else {
				txtAmount.clear();
				txtAmount.sendKeys(amount);
				btnDone.click();
			}
			LogUtility.logInfo("Amount is Succsessfully entered in the amount field");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on done button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * @param Method to enter Text in Memo field
	 */
	public void enterMemo(String value) {
		txtMemo.sendKeys(value);
		LogUtility.logInfo("value is Succsessfully entered in the Memo field");
	}

	/**
	 * Method to Verify Done Button
	 * 
	 * @return
	 */
	public boolean verifyDoneButton() {

		if (btnDone.isDisplayed()) {
			LogUtility.logInfo("Successfully verified done button");
			return true;
		} else
			LogUtility.logInfo("unable to verified done button");
		return false;
	}

	/**
	 * Method to click done button
	 */
	public void clickDoneButton() throws Exception {
		try {
			btnDone.click();
			LogUtility.logInfo("Succsessfully clicked on done button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on done button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Transfer To List
	 */
	public void clickTransfersToList() throws Exception {
		try {
			lstTransfersTo.click();
			LogUtility.logInfo("Succsessfully clicked on Transfers To list");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Transfers To list<---" + e.getStackTrace());
			throw e;

		}
	}

	/**
	 * Method to click Transfer From List
	 */
	public void clickTransfersFromList() throws Exception {
		try {
			lstTransfersFrom.click();
			LogUtility.logInfo("Succsessfully clicked on Transfers From list");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Transfers From list<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Verify TransferDetailsScreenTransact
	 */
	public void verifyTransferDetailsScreenTransact() {
		try {

			List<RemoteWebElement> transferDetailsScreenTransactElements = new ArrayList<RemoteWebElement>();
			transferDetailsScreenTransactElements.addAll(
					Arrays.asList(lblAmount, lblFrom, lblTo, lblDeliveryDate, lblReferenceNumber, lblMemo, lblStatus));
			mobileActions.elementsPresent(transferDetailsScreenTransactElements);
			LogUtility.logInfo("Transfer details screen transact is Displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to display details<---" + e.getStackTrace());
		}

	}

	/**
	 * Method to Verify TransferDetailsScreen
	 * 
	 * @throws Exception
	 */
	public void verifyTransferDetailsScreen() {
		LogUtility.logInfo("Verification of TransferDetails Screen ");
		try {
			List<RemoteWebElement> transferDetailsScreenElements = new ArrayList<RemoteWebElement>();
			transferDetailsScreenElements.addAll(
					Arrays.asList(lblAmount, lblFrom, lblTo, lblDeliveryDate, lblReferenceNumber, lblMemo, lblStatus));
			mobileActions.elementsPresent(transferDetailsScreenElements);
			LogUtility.logInfo("Transfer Details screen is Displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to display details<---" + e.getStackTrace());
		}

	}

	/**
	 * Method to Verify TransferFundsScreen
	 */
	public boolean verifyTransferFundsScreen() {
		try {
			mobileActions.isElementPresent(btnTransferFunds, 30);
			LogUtility.logInfo("Verification of TransferFunds Screen ");
			btnTransferFunds.isDisplayed();
			LogUtility.logInfo(" Transfer Funds screen is Displayed ");
			return true;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to find TransferFunds screen<---" + e.getStackTrace());

		}
		return false;
	}

	public boolean verifyNoItems() {
		try {
			txtNoItems.isDisplayed();
			LogUtility.logInfo("No Items Text is Displayed ");
			return true;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to find No Items text <---" + e.getStackTrace());

		}
		return false;
	}

	/**
	 * Method to Verify CreateTransferScreen
	 */
	public void verifyCreateTransferScreen() throws Exception {
		try {

			mobileActions.isElementPresent(lblCreateTransfer, 10);
			List<RemoteWebElement> createTransferDetailsScreen = Arrays.asList(lblCreateTransfer, lblSubmitTransfer);
			mobileActions.elementsPresent(createTransferDetailsScreen);
			LogUtility.logInfo(" Create Transfer Details screen is Displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Not displayed Create Transfer details on screen <---");
			throw e;
		}
	}

	/**
	 * Method to return number of accounts displayed in Alerts Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfTransferFrom() throws Exception {
		try {
			// Waiting to load the size of Transfer From
			waits.staticWait(4);
			return transferFromListedCount.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to the count of accounts listed<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on back button
	 * 
	 */
	public void clickOnBack() throws Exception {
		try {
			appiumDriver.navigate().back();
			LogUtility.logInfo("Successfully navigate to back ");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to navigate back<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on OK button
	 * 
	 */
	public void clickOkButon() throws Exception {
		try {
			btnOk.click();
			LogUtility.logInfo("Successfully clicked on Ok button ");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click Ok<---" + e.getStackTrace());
			throw e;
		}
	}

	public int getCountOfTransferTo() throws Exception {
		try {
			// Waiting to load the size of Transfer To
			waits.staticWait(4);
			return transferToListedCount.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to the count of accounts listed<---" + e.getStackTrace());
			throw e;
		}
	}

	public int getCountOfTransferHistory() throws Exception {
		try {
			// Waiting to load the size of Transfer History
			waits.staticWait(4);
			return transferHistoryCount.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to the count of accounts listed<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to select any account from the list of accounts displayed in Transfer
	 * from page Will verify the account selected is opened
	 * 
	 * @throws Exception
	 */
	public String clickOnFromAccount() throws Exception {
		if (transferFromListedCount.size() > 0) {
			int i = 1;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)))
					.getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			waits.staticWait(6);
			clickOnAccount.click();
		}
		return selectAccount;
	}

	public String clickOnToAccount() throws Exception {
		if (transferToListedCount.size() > 0) {
			// Initialized with no 2 because to select an account which is not default in
			// the Transfer to list
			int i = 2;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)))
					.getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
		}
		return selectAccount;
	}

	public String clickOnSpecifiedToAccount() throws Exception {
		if (transferToListedCount.size() > 0) {
			int i = 1;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)))
					.getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
		}
		return selectAccount;
	}

	public String clickOnTransferHistoryCompleted() throws Exception {
		if (transferHistoryCount.size() > 0) {
			int i = 2;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicTransferHistoryCount, i, i)))
					.getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicTransferHistoryCount, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
		}
		return selectAccount;
	}

	public String clickOnTransferHistorySpecified() throws Exception {
		waits.staticWait(4);
		if (transferHistoryCount.size() > 0) {
			int i = 1;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicTransferHistoryCount, i, i)))
					.getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicTransferHistoryCount, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
		}
		return selectAccount;
	}

	/**
	 * Method to verify the error message in Transfer fund page for view only
	 * account
	 * 
	 * @param errorMessage
	 * @return
	 * @throws Exception
	 */
	public String verifyErrorMessageViewOnlyAccount(String errorMessage) throws Exception {
		try {
			mobileActions.isElementPresent(lblErrorMessageViewOnly, 4);
			// Waiting to load the size of Transfer History
			waits.staticWait(4);
			String errorMsg = lblErrorMessageViewOnly.getText();
			LogUtility.logInfo(errorMsg);
			Assert.assertEquals(errorMsg, errorMessage);
			LogUtility.logInfo("--->Error message displayed as " + errorMsg);
			return errorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + errorMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify the Threshold amount alert error message
	 * 
	 * @param androidError
	 * @param iOSError
	 * @throws Exception
	 */
	public void verifyNotSupportedErrorMessage(String androidError, String iOSError) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				String error = txtErrorNotSupported.getText();
				Assert.assertEquals(error, androidError);
				LogUtility.logInfo("--->Android Error Message is displayed and verified " + androidError);
			} else {
				String error = txtErrorNotSupported.getText();
				Assert.assertEquals(error, iOSError);
				LogUtility.logInfo("--->iOS Error Message is displayed and verified " + iOSError);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the error message " + e);
			throw e;
		}
	}

	public String verifySuccessMessage(String string) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				mobileActions.isElementPresent(txtCancelSuccessMessage, 30);
				String successMsg = txtCancelSuccessMessage.getText();
				LogUtility.logInfo(successMsg);
				Assert.assertEquals(successMsg, string);
				LogUtility.logInfo("--->Success message displayed as " + successMsg);
				btnOkPopup.click();
				return successMsg;
			} else {
				String successMsg = txtCancelSuccessMessage.getText();
				LogUtility.logInfo(successMsg);
				Assert.assertEquals(successMsg, string);
				LogUtility.logInfo("--->Success message displayed as " + successMsg);
				return successMsg;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + string);
			throw e;
		}
	}

	/**
	 * Added by Phani
	 * 
	 * @throws Exception
	 **/

	public void verifyTransferPageDisplayed() throws Exception {
		try {
			titleCreateTransfer.isDisplayed();
			LogUtility.logInfo("Verified the transfer fund page is displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the transfer fund page is displayed " + e);
			throw e;
		}
	}

	public void tapOnCalender() throws Exception {
		try {
			mobileActions.isElementPresent(lblDeliveryDate, 10);
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				iosDeliveryDate = lblDeliveryDate.getAttribute("value");
			}
			lblDeliveryDate.click();
			mobileActions.isElementPresent(paneCalendar, 10);
			btnDone.click();
			LogUtility.logInfo("Clicked on Calendar");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Calendar " + e);
			throw e;
		}
	}

	/**
	 * Method to select past date in calendar
	 * 
	 * @throws Exception
	 */
	public void selectPastDate() throws Exception {
		String selectedDateCalendar;
		try {
			String dom = LocalDate.now().toString().split("-")[2];

			LocalDate prevDate = LocalDate.now().minusDays(1);
			DayOfWeek dow = prevDate.getDayOfWeek();
			String convDow = dow.name().substring(0, 1).toUpperCase() + dow.name().substring(1).toLowerCase();
			String pdom = prevDate.toString().split("-")[2];
			int convPrevDom = prevDate.getDayOfMonth();
			Month m = prevDate.getMonth();
			String convM = m.name().substring(0, 1).toUpperCase() + m.name().substring(1).toLowerCase();
			int y = prevDate.getYear();

			if (TestDataConstants.getOSPlatformName().contains("android")) {
				selectedDateCalendar = paneCalendar.getText();
				if (selectedDateCalendar.equals(dom)) {
					LogUtility.logInfo("Current date is selected by default " + dom);
				} else {
					throw new Exception("Current date is not selected in calendar ");
				}
				String dynamicDateAndroid = "//android.widget.TextView[@content-desc='%s, %s %s %d is not available, please select a different date.']";

				WebElement prevDateSelect = appiumDriver
						.findElement(By.xpath(String.format(dynamicDateAndroid, convDow, convM, pdom, y)));
				prevDateSelect.click();
				LogUtility.logInfo("Clicked on previous date in calendar");
				selectedDateCalendar = paneCalendar.getText();
				if (selectedDateCalendar.equals(pdom)) {
					throw new Exception("Previous date selected");
				}
				btnCalendarOkDone.click();
			} else {
				String dynamicDateiOS = "//*[@label='%s %d, %dis not available']";
				WebElement prevDateSelectiOS = appiumDriver
						.findElement(By.xpath(String.format(dynamicDateiOS, convM, convPrevDom, y)));
				prevDateSelectiOS.click();
				btnCalendarOkDone.click();
				int convDate = Integer.parseInt(iosDeliveryDate.split("-")[1]);
				if (convDate == convPrevDom) {
					throw new Exception("Previuos date got selected");
				}
			}
			appiumDriver.navigate().back();
		} catch (Exception e) {
			throw new Exception("Unable to find " + e);
		}
	}

	public void enterAmountGreaterThanPayFrom() throws Exception {
		try {
			txtAmount.clear();
			mobileActions.isElementPresent(txtAmount, 5);
			double addAmount = 100.00;
			String amount = accountFromBalance.replace("$", "").replaceAll("[, ;]", "");
			double fromPayAmount = Double.parseDouble(amount) + addAmount;
			String payFromAmount = Double.toString(fromPayAmount);
			txtAmount.sendKeys(payFromAmount);
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				btnDone.click();
				Thread.sleep(1500);
			}

		} catch (Exception e) {
			throw new Exception("Unable to enter the amount " + e);
		}
	}

	/**
	 * Method to select future date in calendar
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings({ "unused", "rawtypes" })
	public void selectFutureDate() throws Exception {
		String selectedDateCalendar;
		String dom = null;
		LocalDate futureDate = null;
		DayOfWeek dow;
		String convDow = null;
		String pdom = null;
		int convPrevDom = 0;
		Month m;
		String convM = null;
		int y = 0;
		try {
				dom = LocalDate.now().toString().split("-")[2];
				futureDate = LocalDate.now().plusDays(1);
				for(int i =1; i<=2; i++) {
					if (futureDate.getDayOfWeek() == DayOfWeek.SATURDAY || futureDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
						LogUtility.logInfo("Selected future date " + futureDate + " is on weekends");
						futureDate = futureDate.plusDays(1);
						if (futureDate.getDayOfWeek() != DayOfWeek.SATURDAY || futureDate.getDayOfWeek() != DayOfWeek.SUNDAY) {
							LogUtility.logInfo("Selected future date " + futureDate + " is on weekends");
							futureDate = futureDate.plusDays(1);
						}else {
							break;
						}
					}else {
						LogUtility.logInfo("Selected future date " + futureDate + " is not on weekends");
						break;
					}
				}
				
				dow = futureDate.getDayOfWeek();
				convDow = dow.name().substring(0, 1).toUpperCase() + dow.name().substring(1).toLowerCase();
				pdom = futureDate.toString().split("-")[2];
				convPrevDom = futureDate.getDayOfMonth();
				m = futureDate.getMonth();
				convM = m.name().substring(0, 1).toUpperCase() + m.name().substring(1).toLowerCase();
				y = futureDate.getYear();
				
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				selectedDateCalendar = paneCalendar.getText();
				if (selectedDateCalendar.equals(dom)) {
					LogUtility.logInfo("Current date is selected by default " + dom);
				} else {
					throw new Exception("Current date is not selected in calendar ");
				}
				String dynamicDateAndroid = "//android.widget.TextView[@content-desc='%s, %s %s %d']";
				/** Date format for Android //*[@contentDesc="Tuesday, June 11 2019"] **/
				WebElement futureDateSelect = appiumDriver
						.findElement(By.xpath(String.format(dynamicDateAndroid, convDow, convM, pdom, y)));
				futureDateSelect.click();
				LogUtility.logInfo("Clicked on future date in calendar");
				selectedDateCalendar = paneCalendar.getText();
				if (!selectedDateCalendar.equals(pdom)) {
					throw new Exception("Future date not selected");
				}
				btnCalendarOkDone.click();
			} else {
				String dynamicDateiOS = "//*[@label='%s %d, %d']";
				/** Date format for iOS //*[@label="June 11, 2019"] **/
				WebElement futureDateSelectiOS = appiumDriver
						.findElement(By.xpath(String.format(dynamicDateiOS, convM, convPrevDom, y)));
				// futureDateSelectiOS.click();
				Point point = appiumDriver.findElement(By.xpath(String.format(dynamicDateiOS, convM, convPrevDom, y)))
						.getLocation();
				new TouchAction(appiumDriver).tap(new PointOption().withCoordinates(321, 1848)).perform();
				int convDate = Integer.parseInt(iosDeliveryDate.split("-")[1]);
				if (convDate != convPrevDom) {
					throw new Exception("Future date not selected");
				}
			}
				} catch (Exception e) {
			throw new Exception("Unable to find " + e);
		}
	}

	public String verifyErrorMessageMissingAmount(String errorMessage) throws Exception {
		try {
			String errorMsg = errorMessageMissingAmount.getText();
			LogUtility.logInfo(errorMsg);
			Assert.assertEquals(errorMsg, errorMessage);
			LogUtility.logInfo("--->Error message displayed as " + errorMsg);
			return errorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + errorMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public List<String> verifyInvalidAccounts() throws Exception {
		try {
			int countBalances = viewAccountsPage.getCountOfAccountsDisplayed();
			String balanceAmount = null;
			for (int i = 1; i <= countBalances; i++) {
				balanceAmount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathBalances, i, i))).getText();
				if (balanceAmount.equals("N/A") || balanceAmount.equals("$0.00")) {
					inValidBalances.add(balanceAmount);
				} else {
					validBalances.add(balanceAmount);
				}
			}
			LogUtility.logInfo("Invalid accounts are verified and only valid balances are listed " + validBalances);
			LogUtility.logInfo("Balance with N/A is not added to list " + inValidBalances);
			return validBalances;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the invalid accounts " + e);
			throw e;
		}
	}

	public List<String> verifyInvalidCDAccounts() throws Exception {
		try {
			int countAccounts = viewAccountsPage.getCountOfAccountsDisplayed();
			String accountName = null;
			for (int i = 1; i <= countAccounts; i++) {
				accountName = appiumDriver.findElement(By.xpath(String.format(dynamicXpathAccountName, i, i)))
						.getText();
				if (accountName.startsWith("CD") || accountName.equals("CD")) {
					inValidAccounts.add(accountName);
				} else {
					validAccounts.add(accountName);
				}
			}
			LogUtility.logInfo("Invalid accounts are verified and only valid accounts are listed " + validAccounts);
			LogUtility.logInfo("Accounts that are like CD not added to list " + validAccounts);
			return validBalances;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the invalid accounts " + e);
			throw e;
		}
	}

	public List<String> verifyInvalidAccountsCD() throws Exception {
		try {
			int countAccounts = transferToListedCount.size();
			String accountDisplayed = null;
			List<String> validToAccounts = new ArrayList<String>();
			for (int i = 1; i <= countAccounts; i++) {
				accountDisplayed = appiumDriver.findElement(By.xpath(String.format(dynamicXpathToAccountName, i, i)))
						.getText();
				validToAccounts.add(accountDisplayed);
			}
			boolean isEqual = validAccounts.equals(validToAccounts);
			if (isEqual == false) {
				throw new Exception("Invalid accounts like CD are displayed");
			}
			LogUtility.logInfo(
					"Invalid accounts like CD are verified and only valid accounts are listed " + validToAccounts);
			return validToAccounts;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the invalid accounts " + e);
			throw e;
		}
	}

	public List<String> verifyInvalidBalances() throws Exception {
		try {
			int countBalances = transferFromListedCount.size();
			String balanceFromAmount = null;
			List<String> validFromBalances = new ArrayList<String>();
			for (int i = 1; i <= countBalances; i++) {
				waits.staticWait(3);
				balanceFromAmount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathFromBalances, i, i)))
						.getText();
				validFromBalances.add(balanceFromAmount);
			}
			boolean isEqual = validBalances.equals(validFromBalances);
			if (isEqual == false) {
				throw new Exception("Invalid Balances are displayed");
			}
			LogUtility.logInfo("Invalid accounts are verified and only valid balances are listed " + validFromBalances);
			return validFromBalances;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the invalid accounts " + e);
			throw e;
		}
	}

	public void clickOkPopup() throws Exception {
		try {
			waits.staticWait(5);
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				mobileActions.isElementPresent(btnOkPopup, 5);
				btnOkPopup.click();
			}
			LogUtility.logInfo("Clicked on Ok button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on OK popup " + e);
			throw e;
		}
	}

	public void clickOkButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnAlertOK, 5);
			btnAlertOK.click();
			LogUtility.logInfo("Clicked on Ok button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on OK popup " + e);
			throw new Exception("Unable to click on OK popup " + e);
		}
	}

	public void navigateBack() throws Exception {
		try {
			appiumDriver.navigate().back();
			LogUtility.logInfo("Naviagted back");
		} catch (Exception e) {
			LogUtility.logError("Unable to navigate back " + e);
			throw e;
		}
	}

	public void getFromToAccounts() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				mobileActions.scrollUp();
			}
			countBalances = viewAccountsPage.getCountOfAccountsDisplayed();
			String balanceAmount = null;
			for (int i = 1; i <= countBalances; i++) {
				balanceAmount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathBalances, i, i))).getText();
				if (balanceAmount.equals("N/A") || balanceAmount.equals("$0.00")) {
					inValidBalances.add(balanceAmount);
				} else {
					validBalances.add(balanceAmount);
				}
				if (validBalances.size() == 2)
					break;
			}
			fromBalance = validBalances.get(0);
			toBalance = validBalances.get(1);
			LogUtility.logInfo("Fetched From and To balances for funds transfer");
		} catch (Exception e) {
			LogUtility.logError("Unable to get From and To balances " + e);
			throw e;
		}
	}

	public void clickFromAccountBalance() throws Exception {
		try {
			for (int i = 1; i <= transferFromListedCount.size(); i++) {
				selectedFromAccountBalance = appiumDriver
						.findElement(By.xpath(String.format(xpathSelectedFromAccountBalance, i, i))).getText();
				if (selectedFromAccountBalance.equalsIgnoreCase(fromBalance)) {
					WebElement clickOnAccountBalance = appiumDriver
							.findElement(By.xpath(String.format(xpathSelectedFromAccountBalance, i, i)));
					LogUtility.logInfo("From Balance selected " + selectedFromAccountBalance);
					clickOnAccountBalance.click();
					break;
				}
			}
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				fromAccountSelected = txtFromField.getAttribute("value");
			} else {
				getFromAccountAndroid = accountNameFromAndTo.getText();
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to select From account balance " + e);
			throw e;
		}
	}

	public void clickToAccountBalance() throws Exception {
		try {
			for (int i = 1; i <= transferToListedCount.size(); i++) {

				selectedToAccountBalance = appiumDriver
						.findElement(By.xpath(String.format(xpathSelectedToAccountBalance, i, i))).getText();
				if (selectedToAccountBalance.equalsIgnoreCase(toBalance)) {
					WebElement clickOnAccountBalance = appiumDriver
							.findElement(By.xpath(String.format(xpathSelectedToAccountBalance, i, i)));
					LogUtility.logInfo("From Balance selected " + selectedToAccountBalance);
					clickOnAccountBalance.click();
					break;
				}
			}
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				toAccountSelected = txtToField.getAttribute("value");
			} else {
				getToAccountAndroid = accountNameFromAndTo.getText();
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to select From account balance " + e);
			throw e;
		}
	}

	public void verifyFromAccountBalancesReflect() throws Exception {
		try {
			mobileActions.scrollUp();
			validBalances.clear();
			waits.staticWait(5);
			double convSelectedFromAccountBalance = Double
					.parseDouble(selectedFromAccountBalance.replace("$", "").replaceAll("[, ;]", ""));
			double balanceReflect = convSelectedFromAccountBalance - Double.parseDouble(amountEnter);
			String convBalanceReflect = Double.toString(balanceReflect);
			String balanceAmount = null;
			for (int i = 1; i <= countBalances; i++) {
				balanceAmount = appiumDriver.findElement(By.xpath(String.format(dynamicXpathBalances, i, i))).getText();
				if (balanceAmount.equals("N/A") || balanceAmount.equals("$0.00")) {
					inValidBalances.add(balanceAmount);
				} else {
					validBalances.add(balanceAmount);
				}
				if (validBalances.size() == 1)
					break;
			}
			fromBalance = validBalances.get(0).replace("$", "").replaceAll("[, ;]", "");
			if (fromBalance.equals(convBalanceReflect)) {
				LogUtility.logInfo("Verified that the balances are reflected");
			} else {
				throw new Exception("Balance amount is not reflected");
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the balances are reflected or not " + e);
			throw e;
		}
	}

	public String verifyLessAmountErrorMessage(String errorMessage) throws Exception {
		try {
			String errorMsg = txtLessAmountErrorMessage.getText();
			LogUtility.logInfo(errorMsg);
			Assert.assertEquals(errorMsg, errorMessage);
			LogUtility.logInfo("--->Error message displayed as " + errorMsg);
			return errorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + errorMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyEqualAmountErrorMessage(String errorMessage) throws Exception {
		try {
			String errorMsg = txtEqualAmountErrorMessage.getText();
			LogUtility.logInfo(errorMsg);
			Assert.assertEquals(errorMsg, errorMessage);
			LogUtility.logInfo("--->Error message displayed as " + errorMsg);
			return errorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + errorMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyTransferExecutedPopUp(String popUpMessage) throws Exception {
		try {
			mobileActions.isElementPresent(transferOkPopUpMessage, 20);
			String popUpMsg = txtTransferExecutedPopUpMessage.getText();
			LogUtility.logInfo("message text is" + popUpMsg);
			if (popUpMsg.contains(popUpMessage))
				LogUtility.logInfo("---> Popup message displayed as " + popUpMsg);
			try {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					mobileActions.isElementPresent(btnOk, 5);
					btnOk.click();
					LogUtility.logInfo("click on ok button");
				}
			} catch (Exception e) {
				LogUtility.logError("Unable to click on ok button");
				throw e;
			}
			return popUpMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + popUpMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyExceedErrorMessage(String exceedMessage) throws Exception {
		try {
			String exceedMsg = txtExceedErrorMessage.getText();
			LogUtility.logInfo(exceedMsg);
			if (exceedMsg.contains(exceedMessage))
				LogUtility.logInfo("--->Error message displayed as " + exceedMsg);
			return exceedMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + exceedMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyZeroErrorMessage(String zeroErrorMessage) throws Exception {
		try {
			String zeroMsg = txtZeroErrorMessage.getText();
			LogUtility.logInfo(zeroMsg);
			if (zeroMsg.contains(zeroErrorMessage))
				LogUtility.logInfo("--->Error message displayed as " + zeroMsg);
			return zeroMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + zeroErrorMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyTransferTimeOutMessage(String timeOutMessage) throws Exception {
		try {
			// want to wait for 15 long minutes for timeout message, so given long wait of
			// 960 seconds
			retailAppUtils.fluentWaitElement(txtTimeOutPopUpMessage, 960, 1);
			String timeOutMsg = txtTimeOutPopUpMessage.getText();
			LogUtility.logInfo(timeOutMsg);
			if (timeOutMsg.contains(timeOutMessage))
				LogUtility.logInfo("---> Popup message displayed as " + timeOutMsg);
			return timeOutMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + timeOutMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyTransferMaximumAmount(String maximumAmount) throws Exception {
		try {
			String maxAmount = txtTransferMaximumAmount.getText();
			LogUtility.logInfo(maxAmount);
			if (maxAmount.contains(maximumAmount))
				LogUtility.logInfo("---> Popup message displayed as " + maxAmount);
			return maxAmount;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + maximumAmount + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyCancelSuccessMessage(String cancelMessage) throws Exception {
		try {
			mobileActions.isElementPresent(transferOkPopUpMessage, 3);
			String cancelMsg = txtCancelSuccessMessage.getText();
			LogUtility.logInfo(cancelMsg);
			Assert.assertEquals(cancelMsg, cancelMessage);
			LogUtility.logInfo("--->Cancel message displayed as " + cancelMsg);
			return cancelMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + cancelMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyToAndFromMessage(String tonfromMessage) throws Exception {
		try {
			String tonfromMsg = txtToAndFromMessage.getText();
			LogUtility.logInfo(tonfromMsg);
			Assert.assertEquals(tonfromMsg, tonfromMessage);
			LogUtility.logInfo("--->ToAndFrom message displayed as " + tonfromMsg);
			return tonfromMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + tonfromMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyMoreThanOneMessage(String snackBarMessage) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				String snackMsg = txtSnackBarMessage.getText();
				LogUtility.logInfo(snackMsg);
				Assert.assertEquals(snackMsg, snackBarMessage);
				LogUtility.logInfo("--->ToAndFrom message displayed as " + snackMsg);
				return snackMsg;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + snackBarMessage + " " + e.getStackTrace());
			throw e;
		}
		return snackBarMessage;
	}

	public boolean verifyTransfersCompleted() throws Exception {
		mobileActions.isElementPresent(btnMoreOptions, 100);
		String transactionName;
		boolean flag = false;
		try {
			for (WebElement ele : transferHistoryCount) {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					transactionName = ele.getText();
				} else {
					transactionName = ele.findElement(By.xpath("//XCUIElementTypeStaticText[4]")).getText();
				}

				if (transactionName.contains(TRANSFERHISTORY_POSTED)) {
					LogUtility.logInfo("--->Transaction History is verified");
					flag = true;
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the transactions details completed" + e.getStackTrace());
			throw e;
		}
		return flag;
	}

	public boolean clickTransfersCompleted() throws Exception {
		String transactionName;
		boolean flag = false;
		try {
			mobileActions.isElementPresent(btnMoreOptions, 100);
			waits.staticWait(4);
			for (WebElement ele : transferHistoryCount) {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					transactionName = ele.findElement(By.id("com.malauzai.websterbank:id/memo")).getText();
					LogUtility.logInfo("--->Transaction Name " + transactionName);
				} else {
					transactionName = ele.findElement(By.xpath("//XCUIElementTypeStaticText[4]")).getText();
					LogUtility.logInfo("--->Transaction Name " + transactionName);
				}

				if (transactionName.contains(TRANSFERHISTORY_POSTED)) {
					ele.click();
					flag = true;
					LogUtility.logInfo("--->Transaction Posted is clicked from History");
					break;
				} else {
					LogUtility.logInfo("--->Unable to find Posted Transactions in Transaction history");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to click the transactions details completed" + e.getStackTrace());
			throw e;
		}
		return flag;
	}

	public boolean clickTransfersPending() throws Exception {
		String transactionName;
		boolean flag = false;
		try {
			mobileActions.isElementPresent(btnMoreOptions, 100);
			// Wait required for after loading to identify the element
			waits.staticWait(4);
			for (WebElement ele : transferHistoryCount) {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					transactionName = ele.getText();
					LogUtility.logInfo("--->Transaction Name " + transactionName);
				} else {
					transactionName = ele.findElement(By.xpath("//XCUIElementTypeStaticText[4]")).getText();
					LogUtility.logInfo("--->Transaction Name " + transactionName);
				}
				if (transactionName.contains(TestDataConstants.TRANSFERHISTORY_PENDING)) {
					appiumDriver.findElement(By.xpath(String.format(dynamicXpathPendingTransfer, transactionName, transactionName))).click();
					flag = true;
					LogUtility.logInfo("--->Transaction PENDING is clicked from History");
					break;
				} else {
					LogUtility.logInfo("--->Unable to find PENDING Transactions in Transaction history");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to click the transactions history with pending status " + e.getStackTrace());
			throw e;
		}
		return flag;
	}

	public boolean verifyWithinGraceCDAccount(String inGrace) throws Exception {
		String withInGrace;
		boolean flag = false;
		try {
			for (WebElement ele : transferFromCount) {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					withInGrace = ele.getText();
				} else {
					withInGrace = ele.findElement(By.xpath(String.format(dynamicXpathNaAccount))).getText();
				}
				if (withInGrace.contains(inGrace)) {
					ele.click();
					flag = true;
					LogUtility.logInfo("--->Transfer From is verified and clicked Sucessfully");
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the transfer From" + e.getStackTrace());
			throw e;
		}
		return flag;

	}

	public boolean verifyMoreThanLakhAccount(String moreThanLakh) throws Exception {
		String bigAccount;
		boolean flag = false;
		try {
			for (WebElement ele : transferFromCount) {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					bigAccount = ele.getText();
				} else {
					bigAccount = ele.findElement(By.xpath(String.format(dynamicXpathNaAccount))).getText();
				}
				if (bigAccount.contains(moreThanLakh)) {
					ele.click();
					flag = true;
					LogUtility.logInfo("--->Transfer From is verified and clicked Sucessfully");
					break;
				} else {
					LogUtility.logInfo("---> Unable to verify Transfer From ");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the transfer From" + e.getStackTrace());
			throw e;
		}
		return flag;
	}

	public boolean verifyOutsideGraceCDAccount(String outGrace) throws Exception {
		String outSideGrace;
		boolean flag = false;
		try {
			for (WebElement ele : transferToCount) {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					outSideGrace = ele.getText();

				} else {
					outSideGrace = ele.findElement(By.xpath(String.format(dynamicXpathNaAccount))).getText();
				}
				if (outSideGrace.contains(outGrace)) {
					ele.click();
					flag = true;
					LogUtility.logInfo("--->Transfer To is verified Sucessfully");
					break;
				} else {
					LogUtility.logInfo("---> Unable to verify Transfer To");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the transfer To" + e.getStackTrace());
			throw e;
		}
		return flag;
	}

	public boolean verifyNAAccount(String naAccount) throws Exception {
		String naAcc;
		boolean flag = false;
		try {
			for (WebElement ele : transferFromCount) {
				if (TestDataConstants.getOSPlatformName().contains("android")) {
					naAcc = ele.getText();
				} else {
					naAcc = ele.findElement(By.xpath(String.format(dynamicXpathNaAccount))).getText();
				}
				if (!naAcc.contains(naAccount)) {
					flag = true;
					LogUtility.logInfo("--->Valid Transfer From is verified Sucessfully");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the transfer From" + e.getStackTrace());
			throw e;
		}
		return flag;
	}

	public void presentDateSelectedToTransfer() throws Exception {
		try {
			// Current Date
			DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
			lblDeliveryDate.isDisplayed();
			Date today = new Date();
			String convToday = formatter.format(today);

			Date todayWithZeroTime = retailAppUtils.parse(convToday, retailAppUtils.simpleDateFormat);
			System.out.println("Current Date=" + todayWithZeroTime);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				defaultDate = lblDeliveryDate.getText();
				Date date = retailAppUtils.parse(defaultDate, retailAppUtils.simpleDateFormat);
				if (date.compareTo(todayWithZeroTime) == 0) {
					LogUtility.logInfo("Current date selected as delivery date in iOS");
				} else {
					throw new Exception("Default date for delivery is not selected in iOS");
				}
			} else {
				defaultDate = txtDeliveryDate.getText();

				Date date = retailAppUtils.parse(defaultDate, retailAppUtils.simpleDateFormat);
				if (date.compareTo(todayWithZeroTime) == 0) {
					LogUtility.logInfo("Current date selected as delivery date in Android");
				} else {
					throw new Exception("Default date for delivery is not selected in Android");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to select the present date " + e);
			throw e;
		}
	}

	public void verifyTransferPageAfterSubmit() throws Exception {
		mobileActions.isElementPresent(lblSubmitTransfer, 6);
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				RemoteWebElement submitPage = appiumDriver
						.findElement(By.xpath(String.format(dynamicXpathSubmitTransferPage, "$" + amountEnter,
								fromAccountSelected, toAccountSelected, defaultDate)));
				submitPage.isDisplayed();
				LogUtility.logInfo("Submit Transfer page is verified in iOS");
			} else {
				commonPage.verifyElementTextPresent("$" + amountEnter);
				commonPage.verifyElementTextPresent(getFromAccountAndroid);
				commonPage.verifyElementTextPresent(getToAccountAndroid);
				commonPage.verifyElementTextPresent(defaultDate);
				LogUtility.logInfo("Submit Transfer page is verified in Android");
			}
		} catch (Exception e) {
			throw new Exception("Unable to find the values in submit transfer page " + e);
		}
	}

	/**
	 * Method to Verify View Accounts label
	 * 
	 */
	public void verifyViewAccountsModule() throws Exception {
		try {
			lblViewAccountsModule.isDisplayed();
			LogUtility.logInfo("Verification of View Accounts text on Menu Page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify View Accounts text on Menu Page<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click View Accounts from the list of Hamburger Menu
	 * 
	 */

	public void clickViewAccountsModule() throws Exception {
		try {
			lblViewAccountsModule.click();
			LogUtility.logInfo("Succsessfully clicked on View Accounts Module");
			mobileActions.isElementPresent(lblViewAccounts, 10);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on View Accounts Module<---" + e.getStackTrace());
			throw e;
		}
	}

	public void selectFromAccountForNotification() throws Exception {
		String fromAccountSelect = manageAlertsPage.getValueFromRuntimeDataMap("CreditTransactionAccount");
		for (Iterator<RemoteWebElement> itr = titleAcctName.iterator(); itr.hasNext();) {
			String accountName = itr.next().getText();
			if (!fromAccountSelect.contains(accountName)) {
				commonPage.clickAccount(accountName);
				LogUtility.logInfo("From Account selected " + accountName);
				break;
			}
		}
	}

	public void selectToAccountForNotification() throws Exception {
		String toAccountSelect = manageAlertsPage.getValueFromRuntimeDataMap("CreditTransactionAccount");
		LogUtility.logInfo(toAccountSelect);
		for (Iterator<RemoteWebElement> itr = titleAcctName.iterator(); itr.hasNext();) {
			String accountName = itr.next().getText();
			if (toAccountSelect.contains(accountName)) {
				commonPage.clickAccount(accountName);
				break;
			}
		}
	}

}
