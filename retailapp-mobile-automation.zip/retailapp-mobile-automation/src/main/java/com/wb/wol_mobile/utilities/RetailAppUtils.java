package com.wb.wol_mobile.utilities;

import static com.wb.wol_mobile.utilities.TestDataConstants.DYNAMICINTEGERS;
import static com.wb.wol_mobile.utilities.TestDataConstants.DYNAMIC_APLHACHARACTERS;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;
import com.wb.java_af.capabilities.CapabilityParser;
import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.wol_mobile.actions.ObjectBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class RetailAppUtils extends ObjectBase {

	public DesiredCapabilities caps;
	public Engine customEngine = null;
	public static AppiumDriver<RemoteWebElement> customAppiumDriver;

	public SimpleDateFormat simpleDateFormat[] = new SimpleDateFormat[] { new SimpleDateFormat("MM/dd/yy"),
			new SimpleDateFormat("MM-dd-yyyy"), new SimpleDateFormat("MMM dd, yyyy"),
			new SimpleDateFormat("MMM dd,yyyy") };

	public void launchAnotherMobileDevice(String device) throws Exception {
		try {
			caps = CapabilityParser.parseMobileCapabilities("capabilities/deviceCapabilities.json", "perfectoMobile",
					device);
			ConcurrentEngines.createCustomEngine(caps, "ie", true, true, true);
			customEngine = ConcurrentEngines.getCustomEngine();
			customAppiumDriver = customEngine.getAppiumDriver();
		} catch (WebDriverException e) {
			e.printStackTrace();
		}
	}

	public Date parse(String value, DateFormat... formatters) {
		Date date = null;
		for (DateFormat formatter : formatters) {
			try {
				date = formatter.parse(value);
				break;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return date;
	}

	public String getRandomString(int size) {
		String alphaChars = DYNAMIC_APLHACHARACTERS;
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < size; i++) {
			sb.append(alphaChars.charAt(random.nextInt(alphaChars.length())));
		}
		return sb.toString();
	}

	public String getRandomNumber(int size) {
		String numberChars = DYNAMICINTEGERS;
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < size; i++) {
			sb.append(numberChars.charAt(random.nextInt(numberChars.length())));
		}
		return sb.toString();
	}

	public LocalDate randomBirthday() {
		return LocalDate.now().minus(Period.ofDays((new Random().nextInt(365 * 70))));
	}

	public RemoteWebElement fluentWait(final By locator, long timeOut, long pollTime) {
		Wait<AppiumDriver<RemoteWebElement>> fluentWait = new FluentWait<AppiumDriver<RemoteWebElement>>(appiumDriver)
				.withTimeout(Duration.ofSeconds(timeOut)).pollingEvery(Duration.ofSeconds(pollTime))
				.ignoring(NoSuchElementException.class).ignoring(TimeoutException.class);
		RemoteWebElement element = (RemoteWebElement) fluentWait
				.until(new Function<AppiumDriver<RemoteWebElement>, MobileElement>() {
					public MobileElement apply(AppiumDriver<RemoteWebElement> appiumDriver) {
						return (MobileElement) appiumDriver.findElement(locator);
					}
				});
		return element;
	};
	
	public RemoteWebElement fluentWaitElement(final MobileElement locator, long timeOut, long pollTime) {
		Wait<AppiumDriver<RemoteWebElement>> fluentWait = new FluentWait<AppiumDriver<RemoteWebElement>>(appiumDriver)
				.withTimeout(Duration.ofSeconds(timeOut))   
				.pollingEvery(Duration.ofSeconds(pollTime))
		        .ignoring(NoSuchElementException.class)
		        .ignoring(TimeoutException.class);
		RemoteWebElement element = (RemoteWebElement) fluentWait.until(new Function<AppiumDriver<RemoteWebElement>, MobileElement>() {
			public MobileElement apply(AppiumDriver<RemoteWebElement> appiumDriver) {
				return (MobileElement) locator;
			}
		});
		return element;
	};
}
