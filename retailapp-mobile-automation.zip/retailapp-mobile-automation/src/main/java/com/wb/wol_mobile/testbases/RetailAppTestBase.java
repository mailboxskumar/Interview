package com.wb.wol_mobile.testbases;

import java.lang.reflect.Method;

import org.testng.ITestContext;

import com.wb.java_af.testbases.CucumberTestBase;

/**
 * This class is supplied to override some of the default behaviour of java-af CucumberTestBase if desired.
 * @author Bharat Pandey
 *
 */
public class RetailAppTestBase extends CucumberTestBase{
	
	@Override
	public void beforeMethod(ITestContext context, Method method) throws Exception {
		super.beforeMethod(context, method);
	}

}
