package com.wb.wol_mobile.pages;

import static com.wb.wol_mobile.utilities.TestDataConstants.CHECKBOX_YES;
import static com.wb.wol_mobile.utilities.TestDataConstants.PERSONAL_ACCOUNT;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

public class AddBillPayeePage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	CommonPage commonPage = new CommonPage();
	RetailAppUtils retailAppUtils = new RetailAppUtils();

	public AddBillPayeePage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	/** Add a Bill payee locators **/
	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/parallax_button_2")
	@iOSFindBy(xpath = "//*[@label=\"Create a Payee\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Create a Payee']")
	protected MobileElement btnAddABillPayee;

	@iOSFindBy(xpath = "//*[@resourceid=\"payeeName__input\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Browse Available Payees']")
	protected MobileElement payeeNameField;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id=\"browsePayees\"]")
	@iOSFindBy(xpath = "//*[@value=\"Browse Available Payees\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Browse Available Payees']")
	protected MobileElement lnkBrowsePayees;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Continue\")")
	@AndroidFindBy(xpath = "//*[@resourceid=\"electronicSetupContinue__actualButton\"]")
	@AndroidFindBy(id = "submit_button")
	@AndroidFindBy(id = "submit_button__actualButton")
	@AndroidFindBy(id = "submit__actualButton")
	@AndroidFindBy(id = "electronicSetupContinue__actualButton")
	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'Continue']")
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id = 'submit_button__actualButton']")
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id = 'electronicSetupContinue__actualButton']")
	@AndroidFindBy(xpath = "//*[@resourceid=\"mobileapp-warp-add-payee-verification-submit__actualButton\"]")
	@iOSFindBy(xpath = "//*[@label=\"submit_button__actualButton\"]")
	protected MobileElement btnContinue;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Popular']")
	@iOSFindBy(xpath = "//*[@label=\"Popular\"]")
	protected MobileElement btnPopular;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Your payee has been added']")
	@iOSFindBy(xpath = "//*[@label=\"Your payee has been added\"]")
	protected MobileElement txtPayeeAddedMessage;

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Cancel\")")
	@iOSFindBy(xpath = "//*[@label=\"Cancel\"]")
	protected MobileElement btnCancel;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"billpay makepaymentbutton img\"]")
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Edit\")")
	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Cancel\")")
	protected MobileElement btnMakePaymentFooter;

	@AndroidFindBy(uiAutomator = "new UiSelector().text(\"Edit\")")
	@iOSFindBy(xpath = "//*[@label=\"Edit\"]")
	protected MobileElement btnEdit;

	// add a payee verification head
	@AndroidFindBy(xpath = "//android.view.View[@text = 'Add a New Payee Verification']")
	@iOSFindBy(xpath = "//*[@label=\"Add a New Payee Verification\"]")
	protected MobileElement lblAddAPayee;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Add a New Payee']")
	@iOSFindBy(xpath = "//*[@label=\"Add a New Payee\"]")
	protected MobileElement addAPayeeHead;

	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id = 'paymentAccountNumber__input']")
	@iOSFindBy(xpath = "//*[@label=\"paymentAccountNumber__input\"]")
	protected MobileElement accountNumberField;

	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id = 'payeeNickname__input']")
	@iOSFindBy(xpath = "//*[@label=\"payeeNickname__input\"]")
	protected MobileElement payeeField;

	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id = 'paymentAccountNumberConfirm__input']")
	@iOSFindBy(xpath = "//*[@label=\"paymentAccountNumberConfirm__input\"]")
	protected MobileElement confirmAccountNumberField;

	@AndroidFindBy(xpath = "//android.view.View[@resource-id = 'noAccountNumber']")
	@iOSFindBy(xpath = "//*[@label=\"noAccountNumber\"]")
	protected MobileElement accountNumberCheckBox;

	@AndroidFindBy(id = "disclosure__input")
	@iOSFindBy(xpath = "//*[@label=\"disclosure__input\"]")
	protected MobileElement disclosureCheckBox;

	@AndroidFindBy(xpath = "//android.view.View[@resource-id = 'browsePayeesSection__contentSection']/child::android.view.View")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label = 'Popular, tab panel']/child::XCUIElementTypeLink")
	protected List<RemoteWebElement> lstBrowsePayeeSection;

	@AndroidFindBy(xpath = "//android.view.View[@resource-id = 'browsePayeesSection__contentSection']/child::android.view.View")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label = 'Popular, tab panel']/child::XCUIElementTypeLink")
	protected MobileElement lstBrowsePayee;

	@AndroidFindBy(xpath = "//android.widget.TabWidget[@resource-id = 'browsePayeesSection__tabSection']/child::android.view.View")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label= 'First Letter of Payee Name']/child::XCUIElementTypeLink")
	protected List<RemoteWebElement> lstAlphaSection;

	@AndroidFindBy(xpath = "//android.widget.RadioButton[@resource-id = 'shortList__option--Y__input']")
	// @iOSFindBy(xpath = "")
	protected MobileElement shortListYes;

	@AndroidFindBy(id = "//android.view.View[@resource-id = 'shortList']")
	// @iOSFindBy(xpath = "")
	protected MobileElement lblShortList;

	@AndroidFindBy(xpath = "//android.widget.RadioButton[@resource-id = 'shortList__option--N__input']")
	// @iOSFindBy(xpath = "")
	protected MobileElement shortListNo;

	@AndroidFindBy(id = "payeeDesignationType__option--P__input")
	// @iOSFindBy(xpath = "")
	protected MobileElement btnPersonalRadioBtn;

	@AndroidFindBy(id = "payeeDesignationType__option--B__input")
	// @iOSFindBy(xpath = "")
	protected MobileElement btnBusinessRadioBtn;

	// payee submit button need to write verification method also
	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'Select Payee Address']")
	// @iOSFindBy(xpath = "")
	protected MobileElement payeeAddressSubmit;

	// locator for payee address one
	@AndroidFindBy(xpath = "//android.widget.RadioButton[@text = 'Connecticut Natural Gas PO Box 1085 Augusta, ME 04332-1085']")
	// @iOSFindBy(xpath = "")
	protected MobileElement payeeAddressOne;

	// locator for payee address two
	@AndroidFindBy(xpath = "//android.widget.RadioButton[@text = 'Connecticut Natural Gas PO Box 2411 Hartford, CT 06146-2411']")
	// @iOSFindBy(xpath = "")
	protected MobileElement payeeAddressTwo;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Payee Name']")
	@iOSFindBy(xpath = "//*[@label=\"Payee Name\"]")
	protected MobileElement payeeName;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Payee Account Number']")
	@iOSFindBy(xpath = "//*[@label=\"Payee Account Number\"]")
	protected MobileElement payeeAccountNumber;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Payment Type']")
	@iOSFindBy(xpath = "//*[@label=\"Payment Type\"]")
	protected MobileElement paymentType;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Payee Address']")
	@iOSFindBy(xpath = "//*[@label=\"Payee Address\"]")
	protected MobileElement payeeAddress;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'Payee Nick Name']")
	@iOSFindBy(xpath = "//*[@label=\"Payee Nick Name\"]")
	protected MobileElement payeeNickName;

	@AndroidFindBy(xpath = "//android.view.View[@text = 'View on Shortlist?']")
	@iOSFindBy(xpath = "//*[@label=\"View on Shortlist?\"]")
	protected MobileElement viewOnShortList;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell")
	protected List<RemoteWebElement> payeeToListedCount;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"payeeAddressLine1__input *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='payeeAddressLine1__input']")
	@AndroidFindBy(id = "payeeAddressLine1__input")
	protected MobileElement txtAddress1;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"payeeAddressLine2__input\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='payeeAddressLine2__input']")
	@AndroidFindBy(id = "payeeAddressLine2__input")
	protected MobileElement txtAddress2;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"payeeCity__input *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='payeeCity__input']")
	@AndroidFindBy(id = "payeeCity__input")
	protected MobileElement txtCity;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label=\"payeeState__select-button\"]")
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='payeeState__select-button']")
	@AndroidFindBy(id = "payeeState__select-button")
	protected MobileElement btnSelect;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@value=\"Payee State\"]")
	@AndroidFindBy(xpath = "//android.view.View[@resource-id='payeeState__radio__label']")
	@AndroidFindBy(xpath = "//android.view.View[@text='Payee State']")
	protected MobileElement lblState;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Zip Code *\"]/following-sibling::XCUIElementTypeTextField")
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='payeeZipCode__input']")
	@AndroidFindBy(id = "payeeZipCode__input")
	protected MobileElement txtZipCode;

	@iOSFindBy(xpath = "//*[@label=\"Done\"]")
	protected MobileElement btnDone;

	@AndroidFindBy(xpath = "//android.view.View[@resource-id = 'payeeState__radio']/child::android.widget.RadioButton")
	@iOSFindBy(xpath = "//*[@label=\"payeeState__radio\"]")
	protected List<RemoteWebElement> listState;

	public String stateSelect = "//android.widget.RadioButton[@text='%s'] | //android.widget.RadioButton[text()='%s' and contains(@id, 'payeeState')]";

	public String payeeXpathIos = "//XCUIElementTypeOther[@label = '%s, tab panel']/child::XCUIElementTypeLink";

	private String dynamicPayeeValue = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	public String payeesXpath = "//android.view.View[@resource-id = 'payeeLink%d']";
	public String payeesPopularXpath = "//*[resource-id\"payeeCharctersLink[%d]\"]";
	public String firstAddressText = null;
	public String secondAddressText = null;
	public String payeeText = null;
	public String accNum = null;
	public String selectedOne = "One";
	public String selectedTwo = "Two";
	public String editText = "Edit";
	public String cancelText = "Cancel";
	public String buttonText = null;
	public String dynamicAlpha = null;

	List<String> charList;
	List<String> alphaList;
	List<String> alphaRelatedList;

	boolean flag = false;
	public String alphaText = null;
	public String selectAccount = null;

	List<String> payeeDropdownList;

	/**
	 * Method to click on Add a payee *
	 */

	public void clickOnAddPayeeButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnAddABillPayee, 10);
			btnAddABillPayee.click();
			LogUtility.logInfo("Succsessfully clicked on AddaBillpayee button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on AddaBillpayee button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to enter payee name in the field *
	 */

	public void enterPayeeName(String payeeName) throws Exception {
		try {
			mobileActions.isElementPresent(payeeNameField, 5);
			payeeNameField.sendKeys(payeeName);
			LogUtility.logInfo("Succsessfully Entered payee name in the field");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to Enter payee name in the field<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on payee address *
	 */

	public void clickOnPayeeAddress() throws Exception {
		try {
			mobileActions.isElementPresent(payeeAddressSubmit, 10);
			payeeAddressSubmit.click();
			LogUtility.logInfo("Succsessfully clicked on payeeAddressSubmit button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on payeeAddressSubmit button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify payee address is displayed*
	 */
	public boolean verifySelectPayeeAddressDisplayed() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(payeeAddressSubmit, 10, 2);
			if (mobileActions.verifyIsElementPresent(payeeAddressSubmit, 5)) {
				LogUtility.logInfo("payeeAddressSubmit is displayed under the payee Name");
				return true;
			} else {
				LogUtility.logInfo("payeeAddressSubmit is not displayed under the payee Name");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable verify payeeAddressSubmit displayed<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify add a new payee is displayed*
	 */
	public boolean verifyAddANewPayeeDisplayed() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(lblAddAPayee, 10, 2);
			if (mobileActions.verifyIsElementPresent(lblAddAPayee, 5)) {
				LogUtility.logInfo("add a new payee page is displayed under the payee Name");
				return true;
			} else {
				LogUtility.logInfo("add a new payee page is not displayed under the payee Name");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable verify add a new payee page displayed<---" + e.getStackTrace());
			throw e;
		}
	}

	/*
	 * Method to verifyEditSelectedButtonDisplayed*
	 */
	public boolean verifyEditButtonDisplayed() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnContinue, 5)) {
				lblAddAPayee.click();
				buttonText = btnEdit.getText();
				mobileActions.swipeUp();
			} else {
				mobileActions.swipeUpUntilTextExists(btnContinue, 3);
			}
			if (buttonText.contains(editText)) {
				LogUtility.logInfo("selected Edit button is displayed");
				return true;
			} else {
				LogUtility.logInfo("selected Edit button is not displayed");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable verify add a new payee page displayed<---" + e.getStackTrace());
			throw e;
		}
	}

	/*
	 * Method to verifyCancelSelectedButtonDisplayed*
	 */
	public boolean verifyCancelButtonDisplayed() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnContinue, 5)) {
				lblAddAPayee.click();
				buttonText = btnCancel.getText();
				mobileActions.swipeUp();
			} else {
				mobileActions.swipeUpUntilTextExists(btnContinue, 3);
			}
			if (buttonText.contains(cancelText)) {
				LogUtility.logInfo("selected cancel button is displayed");
				return true;
			} else {
				LogUtility.logInfo("selected Cancel button is not displayed");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable verify add a new payee page displayed<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify the account settings options
	 * 
	 * @throws Exception
	 */
	public void verifyAddANewPayeeDetails() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnContinue, 5)) {
				buttonText = btnContinue.getText();
				mobileActions.swipeUpUntilTextExists(btnContinue, 3);
			}
			List<RemoteWebElement> addAPayeeDetails = new ArrayList<RemoteWebElement>();
			addAPayeeDetails.addAll(Arrays.asList(payeeName, payeeAccountNumber, paymentType, viewOnShortList,
					btnContinue, btnEdit, btnCancel));
			mobileActions.elementsPresent(addAPayeeDetails);
			mobileActions.scrollUp();
			LogUtility.logInfo("--->Verified the addAPayeeDetails options in details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify addAPayeeDetails options in details page " + e);
			throw e;
		}
	}

	/**
	 * Method to verify the account settings options
	 * 
	 * @throws Exception
	 */
	public void verifyAddANewPayeeConfirmation() throws Exception {
		try {
			mobileActions.scrollUp();
			List<RemoteWebElement> addAPayeeDetails = new ArrayList<RemoteWebElement>();
			addAPayeeDetails
					.addAll(Arrays.asList(payeeName, payeeAccountNumber, paymentType, payeeNickName, viewOnShortList));
			mobileActions.elementsPresent(addAPayeeDetails);
			mobileActions.scrollUp();
			LogUtility.logInfo("--->Verified the addAPayee confirmation in details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify addAPayee confirmation in details page " + e);
			throw e;
		}
	}

	/**
	 * Method to verify browseAvailable payess are displayed or not*
	 */
	public boolean verifyBrowseAvailablePayeesDisplayed() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(lnkBrowsePayees, 10, 2);
			if (mobileActions.verifyIsElementPresent(lnkBrowsePayees, 5)) {
				LogUtility.logInfo("browseAvailable payee is displayed under the payee Name");
				return true;
			} else {
				LogUtility.logInfo("browseAvailable payee is not displayed under the payee Name");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable verify browseavailable payees displayed<---" + e.getStackTrace());
			throw e;
		}
	}

	public void enterAndReenterAccountNumber() throws Exception {
		try {
			accNum = retailAppUtils.getRandomNumber(10);
			LogUtility.logInfo("enter account number is" + accNum);
			mobileActions.isElementPresent(accountNumberField, 5);
			accountNumberField.sendKeys(accNum);
			mobileActions.isElementPresent(confirmAccountNumberField, 5);
			confirmAccountNumberField.sendKeys(accNum);
			LogUtility.logInfo("successfully entered and re entered the account account numbers in the fields");
		} catch (Exception e) {
			LogUtility.logError("--->Able to Enter the account number<---" + e.getMessage());
			throw e;
		}
	}

	public void enterPayeeName() throws Exception {
		try {
			mobileActions.isElementPresent(payeeField, 10);
			payeeText = commonPage.getRandomString();
			payeeField.sendKeys(payeeText);
			LogUtility.logInfo("successfully entered payee name in the field");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to Enter the payee Name<---" + e.getMessage());
			throw e;
		}
	}

	/**
	 * To select shortList yes/No to add a new payee
	 * 
	 * @param shortList
	 * @throws Exception
	 */
	public void selectPayeeShortList(String shortList) throws Exception {
		try {
			retailAppUtils.fluentWaitElement(shortListYes, 10, 2);
			mobileActions.swipeUpUntilTextExists(shortListYes, 2);
			if (shortList.contains(CHECKBOX_YES)) {
				shortListYes.click();
			} else {
				mobileActions.isElementPresent(shortListNo, 5);
				shortListNo.click();
				LogUtility.logInfo("selectPayeeshortList", "Selected short list value");
			}
		} catch (Exception e) {
			LogUtility.logError("--->selectPayeeshortList<---", e.getMessage());
			throw e;
		}
	}

	/**
	 * To select Shortlist yes/No to add a new payee
	 * 
	 * @param Shortlist
	 * @throws Exception
	 */
	public void selectDisclosureCheck(String value) throws Exception {
		try {
			mobileActions.isElementPresent(disclosureCheckBox, 5);
			String selected = disclosureCheckBox.getAttribute("checked");
			if (selected != value)
				disclosureCheckBox.click();
			LogUtility.logInfo("--->Selected the check box" + value + "<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to Select the check box" + value + "<--" + e);
			throw e;
		}
	}

	/**
	 * To select personal or business account
	 * 
	 * @param accountType
	 * @throws Exception
	 */
	public void payFromSelectedAccount(String accountType) throws Exception {
		try {
			mobileActions.isElementPresent(btnPersonalRadioBtn, 5);
			if (accountType.contains(PERSONAL_ACCOUNT))
				btnPersonalRadioBtn.click();
			else
				mobileActions.isElementPresent(btnPersonalRadioBtn, 5);
			btnPersonalRadioBtn.click();
			LogUtility.logInfo("account selected is" + accountType);
		} catch (Exception e) {
			LogUtility.logError("--->selectPayeeshortlist<---", e.getMessage());
			throw e;
		}
	}

	/**
	 * Method to verify AddaNewPayees are displayed or not*
	 */
	public boolean verifyAddAPayeesDisplayed() throws Exception {
		try {
			mobileActions.isElementPresent(addAPayeeHead, 10);
			if (mobileActions.verifyIsElementPresent(addAPayeeHead, 5)) {
				LogUtility.logInfo("addAPayeeHead payee is displayed under the payee Name");
				return true;
			} else {
				LogUtility.logInfo("addAPayeeHead payee is not displayed under the payee Name");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable verify addAPayeeHead payees displayed<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to check the check box
	 * 
	 * @throws Exception
	 */
	public void tapOnCheckBox(String value) throws Exception {
		try {
			mobileActions.isElementPresent(addAPayeeHead, 5);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				String selected = accountNumberCheckBox.getAttribute("checked");
				if (selected.equals(value)) {
					accountNumberCheckBox.click();
				} else if (value.equals("false")) {
					accountNumberCheckBox.click();
				}
			}
			LogUtility.logInfo("--->Selected the check box" + value + "<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to Select the check box" + value + "<--" + e);
			throw e;
		}
	}

	public void tapOnPayeeAddress(String value) throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				if (selectedOne.equals(value)) {
					payeeAddressOne.click();
					LogUtility.logInfo(
							"--->first address is selected and selected address is" + firstAddressText + "<-----");
				} else if (selectedTwo.equals(value)) {
					payeeAddressTwo.click();
					LogUtility.logInfo(
							"--->second address is selected and selected address is" + secondAddressText + "<-----");
				}
			}
			LogUtility.logInfo("--->Selected the check box" + value + "<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to Select the check box" + value + "<--" + e);
			throw e;
		}
	}

	public void clickOnContinue() {
		try {
			if (mobileActions.verifyIsElementPresent(btnContinue, 5))
				btnContinue.click();
			LogUtility.logInfo("Clicked on continue button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on continue button " + e);
			LogUtility.logInfo("Trying to click again");
			mobileActions.scrollDown();
			try {
				btnContinue.click();
				LogUtility.logInfo("Clicked on continue button");
			} catch (NoSuchElementException ex) {
				LogUtility.logError("--->Unable to click on continue button" + e);
				throw e;
			}
		}
	}

	public void clickOnEdit() {
		try {
			if (mobileActions.verifyIsElementPresent(btnEdit, 5))
				btnEdit.click();
			LogUtility.logInfo("Clicked on Edit button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on Edit button " + e);
			LogUtility.logInfo("Trying to click again");
			mobileActions.scrollDown();
			try {
				btnEdit.click();
				LogUtility.logInfo("Clicked on Edit button");
			} catch (NoSuchElementException ex) {
				LogUtility.logError("--->Unable to click on Edit button" + e);
				throw e;
			}
		}
	}

	public void clickOnCancel() {
		try {
			if (mobileActions.verifyIsElementPresent(btnCancel, 5))
				btnCancel.click();
			LogUtility.logInfo("Clicked on Cancel button");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable click on Cancel button " + e);
			LogUtility.logInfo("Trying to click again");
			mobileActions.scrollDown();
			try {
				btnCancel.click();
				LogUtility.logInfo("Clicked on Cancel button");
			} catch (NoSuchElementException ex) {
				LogUtility.logError("--->Unable to click on Cancel button" + e);
				throw e;
			}
		}
	}

	public void clickOnBrowseAvailablePayeeLink() throws Exception {
		try {
			mobileActions.isElementPresent(lnkBrowsePayees, 5);
			lnkBrowsePayees.click();
			LogUtility.logInfo("successfully clicked on lnkBrowsePayees button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on lnkBrowsePayees button<---" + e.getStackTrace());
			throw e;
		}
	}

	public boolean verifyPayeesDisplayInAlphabeticalOrder(List<String> listName) {
		if (!listName.isEmpty()) {
			Iterator<String> it = listName.iterator();
			String previous = it.next();
			while (it.hasNext()) {
				String next = it.next();
				if (previous.compareTo(next) > 0) {
					LogUtility.logInfo("list of payees are not displayed in alphabetical order");
					return false;
				}
				previous = next;
			}
		}
		LogUtility.logInfo("list of payees are  displayed in alphabetical order");
		return true;
	}

	public List<String> getDropdownPayees() {
		payeeDropdownList = new ArrayList<String>();
		try {
			for (int i = 1; i < payeeToListedCount.size(); i++) {
				String popularList = payeeToListedCount.get(i).getText();
				LogUtility.logInfo("Account selected is :" + popularList);
				payeeDropdownList.add(popularList);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the payee Name <---" + e.getStackTrace());
		}
		return payeeDropdownList;
	}

	public void verifyAndSelectPopularLink() throws Exception {
		try {
			charList = new ArrayList<String>();
			mobileActions.isElementPresent(btnPopular, 5);
			btnPopular.click();
			LogUtility.logInfo("successfully clicked on popular button and verify popularlink");
			for (int i = 0; i <= lstBrowsePayeeSection.size(); i++) {
				String popularList = lstBrowsePayeeSection.get(i).findElement(By.xpath(String.format(payeesXpath, i)))
						.getText();
				charList.add(popularList);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify and selectpopular button<---" + e.getStackTrace());
			throw e;
		}
	}

	public String[] payeesDisplayed() {
		charList = new ArrayList<String>();
		try {
			for (int i = 0; i <= lstBrowsePayeeSection.size(); i++) {
				String popularList = lstBrowsePayeeSection.get(i).findElement(By.xpath(String.format(payeesXpath, i)))
						.getText();
				charList.add(popularList);
				LogUtility.logInfo("payee name is :" + popularList);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the payee Name <---" + e.getStackTrace());
		}
		return (String[]) charList.toArray();

	}

	public List<String> getPayees() {
		charList = new ArrayList<String>();
		try {
			LogUtility.logInfo("size" + lstBrowsePayeeSection.size());
			Iterator<RemoteWebElement> i = lstBrowsePayeeSection.iterator();
			while (i.hasNext()) {
				WebElement element = i.next();
				String popularList = element.getText();
				charList.add(popularList);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the payee Name <---" + e.getStackTrace());
		}
		return charList;
	}

	/**
	 * Method to get count of billpayee displayed for user when logged in
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfPayeesDisplayed() throws Exception {
		try {
			mobileActions.isElementPresent(lstBrowsePayee, 10);
			LogUtility.logInfo("Number of billpayee  displayed " + lstBrowsePayeeSection.size());
			return lstBrowsePayeeSection.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of billpayee listed<---" + e);
			throw e;
		}
	}

	public void clickPopularLink() throws Exception {
		try {
			mobileActions.isElementPresent(btnPopular, 10);
			btnPopular.click();
			LogUtility.logInfo("successfully clicked on popular button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to selectpopular button<---" + e.getStackTrace());
			throw e;
		}
	}

	public void selectPayeeName(String payeeNameActual) {
		try {
			for (int i = 0; i <= lstBrowsePayeeSection.size(); i++) {
				WebElement payeeClick = lstBrowsePayeeSection.get(i)
						.findElement(By.xpath(String.format(payeesXpath, i)));
				String payeeExpected = lstBrowsePayeeSection.get(i).findElement(By.xpath(String.format(payeesXpath, i)))
						.getText();
				if (payeeNameActual.contains(payeeExpected)) {
					payeeClick.click();
					break;
				}
			}
			LogUtility.logInfo("clickPayeename", "Clicked on Payee Name: " + payeeNameActual + " link");
		} catch (Exception e) {
			LogUtility.logError("--->clickPayeename<---", e.getMessage());
			throw (e);
		}
	}

	public boolean verifyAndTapOnSelectedAlphabet(String alpha) {
		try {
			char actualChar = alpha.charAt(0);
			if (!lstAlphaSection.isEmpty()) {
				Iterator<RemoteWebElement> it = lstAlphaSection.iterator();
				while (it.hasNext()) {
					RemoteWebElement next = it.next();
					char expectedChar = next.getText().charAt(0);
					dynamicAlpha = String.valueOf(expectedChar);
					if (actualChar == expectedChar) {
						next.click();
						alphaText = alpha;
						break;
					}
				}
			}

			if (TestDataConstants.getOSPlatformName().contains("android")) {
				LogUtility.logInfo("size of the browsersection is" + lstBrowsePayeeSection.size());
				for (int j = 0; j <= lstBrowsePayeeSection.size(); j++) {
					String popularBrowseList = lstBrowsePayeeSection.get(j)
							.findElement(By.xpath(String.format(payeesXpath, j))).getText();
					char second = popularBrowseList.charAt(0);
					if (actualChar == second) {
						flag = true;
						return flag;
					}

				}
			}

		} catch (Exception e) {
			LogUtility.logError("--->Unable to click and verify the payees displayed in alphabatical order<---",
					e.getMessage());
			throw (e);
		}
		return flag;

	}

	/**
	 * To Click on required Payee name link to add a new payee
	 * 
	 * @param payeeName
	 * @throws InterruptedException
	 */
	@SuppressWarnings("unused")
	public boolean verifyPayeesDisplayedInAlphabeticalOrder() throws Exception {
		try {
			for (int i = 1; i <= lstAlphaSection.size(); i++) {
				WebElement popularClicks = lstAlphaSection.get(i).findElement(By.xpath(String.format(payeesXpath, i)));
				popularClicks.click();
				String popularList = lstAlphaSection.get(i).findElement(By.xpath(String.format(payeesXpath, i)))
						.getText();
				char first = popularList.charAt(0);
				for (int j = 0; j <= lstBrowsePayeeSection.size(); j++) {
					String popularBrowseList = lstBrowsePayeeSection.get(j)
							.findElement(By.xpath(String.format(payeesXpath, j))).getText();
					char second = popularBrowseList.charAt(0);
					if (first == second) {
						flag = true;
						return flag;
					} else {
						return flag;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->clickPayeename<---", e.getMessage());
			throw e;
		}
		return flag;
	}

	public List<String> getListOfPayees() {
		charList = new ArrayList<String>();
		try {
			LogUtility.logInfo("size" + lstBrowsePayeeSection.size());
			Iterator<RemoteWebElement> i = lstBrowsePayeeSection.iterator();
			while (i.hasNext()) {
				WebElement element = i.next();
				String popularList = element.getText();
				charList.add(popularList);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the payee Name <---" + e.getStackTrace());
			throw e;
		}
		return charList;
	}

	/**
	 * Method to verify payee added message
	 * 
	 * @param errormsg
	 * @return
	 * @throws Exception
	 */
	public boolean verifyPayeeAdded(String errorMessage) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtPayeeAddedMessage, 5)) {
				LogUtility.logInfo("available text from app is:" + txtPayeeAddedMessage.getText());
				return errorMessage.equalsIgnoreCase(txtPayeeAddedMessage.getText());
			} else {
				LogUtility.logInfo("Unable to verify text payee added successfully ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify text payee added successfully " + e);
			throw e;
		}
	}

	/**
	 * Method to verify and select payee from the list
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifySelectToPayeeIsDisplayed() throws Exception {
		try {
			for (int i = 1; i < payeeToListedCount.size(); i++) {
				selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicPayeeValue, i, i))).getText();
				WebElement clickOnAccount = appiumDriver.findElement(By.xpath(String.format(dynamicPayeeValue, i, i)));
				LogUtility.logInfo("Account selected is :" + selectAccount);
				if (selectAccount.contains(payeeText)) {
					clickOnAccount.click();
					flag = true;
					return flag;
				}
			}
			return flag;
		} catch (Exception e) {
			LogUtility.logError("--->Unable Select ToPayee<---" + e.getStackTrace());
			throw e;
		}
	}

	public void enterPayeePersonalDetails(String address1, String address2, String city, String state, String zipCode)
			throws Exception {
		try {
			// Address1
			if (mobileActions.isElementDisplayed(txtAddress1, 3)) {
				txtAddress1.sendKeys(address1);
			} else {
				mobileActions.swipeUpUntilTextExists(txtAddress1, 2);
				txtAddress1.sendKeys(address1);
			}
			// Address2
			if (mobileActions.isElementDisplayed(txtAddress2, 3)) {
				txtAddress2.sendKeys(address2);
			} else {
				mobileActions.swipeUpUntilTextExists(txtAddress2, 2);
				txtAddress2.sendKeys(address2);
			}
			// City
			if (mobileActions.isElementDisplayed(txtCity, 3)) {
				txtCity.sendKeys(city);
			} else {
				mobileActions.swipeUpUntilTextExists(txtCity, 2);
				txtCity.sendKeys(city);
			}
			// State
			if (mobileActions.isElementDisplayed(btnSelect, 5)) {
				btnSelect.click();
				mobileActions.isElementPresent(lblState, 5);
				btnSelect.click();
				try {
					LogUtility.logInfo("Size of state list is " + listState.size() + " link");
					Iterator<RemoteWebElement> i = listState.iterator();
					while (i.hasNext()) {
						WebElement element = i.next();
						String popularList = element.getText();
						if (popularList.contains(state)) {
							element.click();
							break;
						}
					}
					LogUtility.logInfo("clickPayeename", "Clicked on Payee Name: " + state + " link");
				} catch (Exception e) {
					LogUtility.logError("--->clickPayeename<---", e.getMessage());
					throw (e);
				}
			} else {
				mobileActions.swipeUpUntilTextExists(btnSelect, 2);
				btnSelect.click();
				try {
					Iterator<RemoteWebElement> i = listState.iterator();
					while (i.hasNext()) {
						WebElement element = i.next();
						String popularList = element.getText();
						if (popularList.contains(state)) {
							element.click();
							break;
						}
					}
					LogUtility.logInfo("clickPayeename", "Clicked on Payee Name: " + state + " link");
				} catch (Exception e) {
					LogUtility.logError("--->clickPayeename<---", e.getMessage());
					throw (e);
				}
			}
			// ZipCode
			if (mobileActions.isElementDisplayed(txtZipCode, 3)) {
				txtZipCode.sendKeys(zipCode);
			} else {
				mobileActions.swipeUpUntilTextExists(txtZipCode, 2);
				txtZipCode.sendKeys(zipCode);
			}
			LogUtility.logInfo("Personal Information page is displayed in payee deatils page");
			if (TestDataConstants.getOSPlatformName().equals("ios"))
				btnDone.click();
		} catch (Exception e) {
			LogUtility.logError("Unable to enter personal information in bill payee page" + e);
			throw e;
		}
	}

}
