package com.wb.wol_mobile.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.Enum.DIRECTION;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author MPrasanth-adm
 *
 */
public class AccountsPage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	TransactionsHistoryPage transactionHistory = new TransactionsHistoryPage();
	ManageAlertsPage manageAlertsPage = new ManageAlertsPage();
	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();

	String amountTxt = null;
	boolean status = false;

	public AccountsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	public AccountsPage(AppiumDriver<RemoteWebElement> customDriver) {
		PageFactory.initElements(new AppiumFieldDecorator(customDriver), this);
	}

	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView/child::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstAccountName;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Are you sure you want to unhide this account?']")
	protected MobileElement txtUnHideAccountPopUp;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Close']")
	protected MobileElement btnCloseButton;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Confirm']")
	protected MobileElement btnConfirmButton;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label=\"VIEW ACCOUNTS\"]")
	protected MobileElement lblAccountPageText;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'No Items Available']")
	@iOSFindBy(xpath = "//*[@label=\"No Items Available\"]")
	protected MobileElement closedErrorHead;

	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Your account is currently inactive and not eligible for this action. We apologize for any inconvenience']")
	protected MobileElement txtPurgedErrorHead;

	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'For Credit Card transaction details please go to myaccountaccess.com.']")
	protected MobileElement txtCreditCardErrorHead;

	// locators for : buttons and verification texts
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Account Details']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Account Details']")
	protected MobileElement lblAccountHeadDetails;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/options_button")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'More Info' and @enabled = 'true']")
	protected MobileElement btnOptions;

	@AndroidFindBy(id = "android:id/title")
	protected MobileElement btnSeeDetails;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Current Balance']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Current Balance']")
	protected MobileElement txtCurrentBalance;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Available Balance']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Available Balance']")
	protected MobileElement txtAvailableBalance;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Last Deposit']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Last Deposit']")
	protected MobileElement lblLastDeposit;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Last Deposit Date']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Last Deposit Date']")
	protected MobileElement lblLastDepositDate;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Last Interest Paid Amount']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Last Interest Paid Amount']")
	protected MobileElement lblInterestPaidAmount;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'YTD Interest']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'YTD Interest']")
	protected MobileElement lblYTDInterest;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Current APY']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Current APY']")
	protected MobileElement lblCurrentAPY;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Credit Limit']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Credit Limit']")
	protected MobileElement lblCreditLimit;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Last Payment']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Last Payment']")
	protected MobileElement lblLastPayment;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Amt Due Now']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Amt Due Now']")
	protected MobileElement lblAmountDueNow;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Next Payment Due']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Next Payment Due']")
	protected MobileElement lblNextPaymentDue;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Maturity Date']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Maturity Date']")
	protected MobileElement lblMaturityDate;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'TRANSFER FUNDS']")
	protected MobileElement lblFundTransferText;

	// locators for click for different accounts
	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id = 'com.malauzai.websterbank:id/transaction_info']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]//following-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstFirstTransaction;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id = 'com.malauzai.websterbank:id/grp_details_body']//following-sibling::android.widget.RelativeLayout")
	protected List<RemoteWebElement> lstActiveAccount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_info")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected List<RemoteWebElement> listedCount;

	// locators for click for different accounts
	@AndroidFindBy(xpath = "//android.widget.LinearLayout")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[5]//following-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstPreferenceAccounts;

	@AndroidFindBy(xpath = "//android.widget.FrameLayout[2]//following-sibling::android.widget.LinearLayout")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[5]//following-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstAccountsUnderPreferences;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/preceding-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> accountsListedCount;

	@AndroidFindBy(xpath = "//android.widget.Switch[@text='OFF']")
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch[@value='0']")
	protected List<RemoteWebElement> swtToogleOff;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id = 'com.malauzai.websterbank:id/transaction_info']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]//following-sibling::XCUIElementTypeCell")
	protected MobileElement transactionsListed;

	public String accountTitleXpath = "//XCUIElementTypeStaticText[%d] |"
			+ "(//android.widget.TextView[@resource-id = 'android:id/title'])";

	public String accountsText = "//android.widget.TextView[@resource-id = 'android:id/title']";

	// locators for click for different accounts
	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id = 'com.malauzai.websterbank:id/transaction_info']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]//following-sibling::XCUIElementTypeCell[1]")
	protected MobileElement firstTransaction;

	public String btnAccountOptions = "//android.widget.LinearLayout/android.widget.TextView[@text='AccountReplace']/following::android.widget.LinearLayout/android.widget.TextView/following::android.widget.ImageButton | "
			+ "//XCUIElementTypeCell/XCUIElementTypeStaticText[@label='AccountReplace']/following::XCUIElementTypeButton[@label='More Info']";

	public String transactionsXpathiOS = "//XCUIElementTypeOther[2]//following-sibling::XCUIElementTypeCell[%d]";
	public String selectAccountDynamicXpath = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	public String preferenceText1 = "//XCUIElementTypeStaticText[1]";
	public String preferenceText2 = "//XCUIElementTypeStaticText[2]";
	public String preferenceText3 = "//XCUIElementTypeStaticText[3]";
	public String transactionGroup = "//android.widget.RelativeLayout[@resource-id = 'com.malauzai.websterbank:id/transaction_info']";
	public String transactionSubGroup = "com.malauzai.websterbank:id/title";
	public String transactionAmount = "com.malauzai.websterbank:id/amount";
	private String verifyAccountExists = "//android.widget.TextView[@text='%d'] | //*[@label='%d']";

	public String xpathAccountName = "//XCUIElementTypeCollectionView/child::XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	/**
	 * Method to verify accounts page
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAccountsPage() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblAccountPageText, 12)) {
				LogUtility.logInfo("Accounts head text is displayed");
				return true;
			} else {
				LogUtility.logInfo("unable to get the account head text");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the Accounts page " + e);
			throw new Exception("Unable to verify the Accounts page " + e);
		}
	}

	/**
	 * Method to verify Closed Account Error Message
	 * 
	 * @param errormsg
	 * @return
	 * @throws Exception
	 */
	public boolean verifyClosedAccountErrorMessage(String errorMessage) throws Exception {
		try {
			mobileActions.scrollDown();
			if (mobileActions.verifyIsElementPresent(closedErrorHead, 5)) {
				LogUtility.logInfo("available text from app is:" + closedErrorHead.getText());
				return errorMessage.equalsIgnoreCase(closedErrorHead.getText());
			} else {
				LogUtility.logInfo("Unable to verify the closed account error message ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the closed Accounts page " + e);
			throw new Exception("Unable to verify the closed Accounts page " + e);
		}
	}

	/**
	 * Method to verify Purged Account Error message
	 * 
	 * @param errormsg
	 * @return
	 * @throws Exception
	 */
	public boolean verifyPurgedAccountErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtPurgedErrorHead, 10)) {
				LogUtility.logInfo("available text from app is:" + txtPurgedErrorHead.getText());
				return errorMessage.equalsIgnoreCase(txtPurgedErrorHead.getText());
			} else {
				LogUtility.logInfo("Unable to verify the Purged account error message ");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the Purged Accounts page " + e);
			throw new Exception("Unable to verify the Purged Accounts page " + e);
		}
	}

	/**
	 * Method to verify account details
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyAccountDetailsScreen() throws Exception {
		try {
			mobileActions.isElementPresent(lblAccountHeadDetails, 6);
			List<RemoteWebElement> numberTextFieldsElements = new ArrayList<RemoteWebElement>();
			numberTextFieldsElements.addAll(Arrays.asList(txtCurrentBalance, txtAvailableBalance, lblLastDeposit,
					lblLastDepositDate, lblInterestPaidAmount, lblYTDInterest, lblCurrentAPY));
			mobileActions.elementsPresent(numberTextFieldsElements);
			LogUtility.logInfo("Verified all the elements on Account details page");
		} catch (Exception e) {
			LogUtility.logException("verifyAccountDetailsScreen",
					"Unable to verify the elements on Account details page", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Method to click on the options button
	 * 
	 * @throws Exception
	 */
	public void clickOptionsButton() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				mobileActions.isElementPresent(btnOptions, 4);
				btnOptions.click();
				btnSeeDetails.click();
				LogUtility.logInfo("User clicked on options button in android device");
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				btnOptions.click();
				LogUtility.logInfo("User clicked on options button in ios device");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on options button " + e);
			throw new Exception("Unable to click on options button " + e);
		}
	}

	/**
	 * 
	 * Method to verify balance and transaction details
	 * 
	 * @return
	 * @throws Exception
	 */

	@SuppressWarnings("unused")
	public boolean verifyBalancesAndTransactionsDetails() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				mobileActions.scrollDown();
				for (RemoteWebElement liElement : lstFirstTransaction) {
					List<WebElement> child = liElement.findElements(By.xpath(transactionGroup));
					for (WebElement liElements : child) {
						LogUtility.logInfo("Transaction displayed is : "
								+ liElements.findElement(By.id(transactionSubGroup)).getText()
								+ "Balance displayed is : "
								+ liElements.findElement(By.id(transactionAmount)).getText());
						amountTxt = liElements.findElement(By.id(transactionAmount)).getText();
						if (amountTxt.contains("$")) {
							status = true;
							break;
						}
						break;
					}
					return status;
				}
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				mobileActions.scrollDown();
				for (RemoteWebElement liElement : lstFirstTransaction) {
					for (int i = 2; i <= lstFirstTransaction.size(); i++) {
						String accName = liElement.findElement(By.xpath(String.format(accountTitleXpath, i))).getText();
						LogUtility.logInfo("account details1:" + accName);
						amountTxt = liElement.findElement(By.xpath(preferenceText3)).getText();
						if (accName.contains("$")) {
							status = true;
							break;
						}
					}
					break;
				}
			}
			return status;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the balances and transaction  Details page " + e);
			throw new Exception("Unable to verify the balances and transaction  Details page " + e);
		}
	}

	/**
	 * Method to return number of Transactions means accounts displayed in
	 * Transaction page
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfTransactions() throws Exception {
		try {
			LogUtility.logInfo("Number of transactions  displayed " + lstFirstTransaction.size());
			return lstFirstTransaction.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of transactions listed<---" + e);
			throw new Exception("Unable to get count of transactions listed " + e);
		}
	}

	/**
	 * Method to verify Credit card Account Error message
	 * 
	 * @param errormsg
	 * @return
	 */
	public boolean verifyCreditCardAccountErrorMessage(String errorMessage) {
		try {
			mobileActions.isElementPresent(txtCreditCardErrorHead, 8);
			String expectedText = txtCreditCardErrorHead.getText();
			Assert.assertEquals(errorMessage, expectedText);
			return true;
		} catch (Exception e) {
			LogUtility.logError("-->Unable to verify list of labels displayed:<--" + e.getStackTrace());
			return false;
		}
	}

	/**
	 * Method to click on First Transaction displayed when you clicked on the any
	 * account
	 * 
	 * @throws Exception
	 * 
	 */
	public void clickOnFirstTransaction() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				// while selecting the first transaction from the list from the dropdown
				// Selected first account.
				lstFirstTransaction.get(1).click();
				LogUtility.logInfo("User Clicked on any one Transaction");
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				mobileActions.scrollUp();
				// while selecting the first transaction from the list dropdown in ios first
				// transaction index will start from 6th that why I selected the 6th element to
				// get the first transaction.
				lstFirstTransaction.get(6).click();
				LogUtility.logInfo("User Clicked on any one Transaction");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on first transaction<---" + e);
			throw new Exception("Unable to click on first transaction " + e);
		}
	}

	/**
	 * Method to scroll to the bottom of the page
	 * 
	 */
	public void scrollDownToBottom() {
		try {
			mobileActions.scrollDown();
			// Static wait is Mandatory wait until to the bottom of the page.Once all
			// transactions are load it should wait with some static wait.
			waits.staticWait(6);
			LogUtility.logInfo("Scroll down to the bottom of the page");
		} catch (Exception e) {
			LogUtility.logError("Unable  to Scroll down to the bottom of the page" + e.getMessage());
		}
	}

	/**
	 * Method to verify accountUnHidePopup
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAccountUnHidePopup() throws Exception {
		try {
			LogUtility.logInfo("Popup head text is:" + txtUnHideAccountPopUp.getText());
			if (btnConfirmButton.isEnabled()) {
				btnConfirmButton.click();
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify popup details for Unhide account");
			throw new Exception("Unable to verify popup details for Unhide account " + e);
		}
	}

	/**
	 * Method to get list of accounts displayed in view accounts page
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<String> listOfAccountsDisplayed() throws Exception {
		try {
			String accountName = null;
			List<String> accts = new ArrayList<String>();
			int count = manageAlertsPage.getCountOfAccounts();
			for (int i = 1; i <= count; i++) {
				accountName = appiumDriver.findElement(By.xpath(String.format(xpathAccountName, i, i))).getText();
				accts.add(accountName);
			}
			return accts;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the accounts listed<---" + e.getStackTrace());
			throw new Exception("Unable to get the accounts listed " + e);
		}
	}

	/**
	 * Method to verify unHideAccountDisplayed based on the string provide
	 * 
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public boolean verifyUnHideAccountDisplayed(String value) throws Exception {
		List<String> accountName = listOfAccountsDisplayed();
		for (String liElement : accountName) {
			if (liElement.contains(value)) {
				status = true;
				LogUtility.logInfo(
						"--->account is displayed in the list So unable to hide account or Unhide the account<---");
				break;
			} else {
				return status;
			}
		}
		return status;
	}

	/**
	 * 
	 * Method to verify Hidden accounts displayed
	 * 
	 * @param value
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("static-access")
	public boolean verifyHiddenAccountIsDisplayed(String value) throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				int count = getCountOfAccountsDisplayed();
				for (RemoteWebElement liElement : accountsListedCount) {
					for (int i = 0; i < count; i++) {
						LogUtility.logInfo("--->account name is<---" + liElement.getText());
						if (liElement.getText().contains(value)) {
							LogUtility.logInfo("--->account is displayed in the list So unable to hide account<---");
							break;
						} else {
							status = true;
						}
					}
				}
				return status;
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				mobileActions.swipe(DIRECTION.UP, 2000);
				for (RemoteWebElement liElement : accountsListedCount) {
					WebElement accountName = liElement.findElement(By.xpath(preferenceText1));
					LogUtility.logInfo("--->account name is<---" + accountName.getText());
					if (accountName.getText().contains(value)) {
						LogUtility.logInfo("--->account is displayed in the list So unable to hide account<---");
						break;
					} else {
						status = true;
					}
				}
			}
			return status;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of accounts listed<---" + e);
			throw new Exception("Unable to get count of accounts listed " + e);
		}
	}

	/**
	 * Method to get Count of the accounts displayed
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfAccountsDisplayed() throws Exception {
		try {
			// Static wait is required for loading accounts and to display it takes
			// time.Once all
			// transactions are load it should wait with some static wait.
			waits.staticWait(10);
			LogUtility.logInfo("Number of accounts  displayed " + accountsListedCount.size());
			return accountsListedCount.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of accounts listed<---" + e);
			throw new Exception("Unable to get count of accounts listed " + e);
		}
	}

	/**
	 * 
	 * Method to verify filter status
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyFilterStatus(int count) throws Exception {
		try {
			if (swtToogleOff.size() == count) {
				LogUtility.logInfo("--->All filters deselcted && Filters enabled<---");
				return true;
			} else {
				LogUtility.logInfo("--->Filters disabled<---");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Filters not enabled " + e);
			throw new Exception("Filters not enabled " + e);
		}
	}

	/**
	 * 
	 * Method to click on second Account
	 * 
	 * @throws Exception
	 */
	public void clickOnAccountUnderPreferences(String value) throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				LogUtility.logInfo("preference list size is:" + lstAccountsUnderPreferences.size());
				for (RemoteWebElement liElement : lstAccountsUnderPreferences) {
					WebElement txtValue = liElement.findElement(By.xpath(accountsText));
					amountTxt = liElement.findElement(By.xpath(accountsText)).getText();
					LogUtility.logInfo("account name is:" + amountTxt);
					if (value.contains(amountTxt)) {
						txtValue.click();
						LogUtility.logInfo("User is able to click on the account::" + value);
						break;
					} else {
						LogUtility.logInfo("User is unable to click on the account" + value);
					}
				}
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				for (RemoteWebElement liElement : lstPreferenceAccounts) {
					WebElement txtValue = liElement.findElement(By.xpath(preferenceText2));
					amountTxt = liElement.findElement(By.xpath(preferenceText2)).getText();
					LogUtility.logInfo("account name is:" + amountTxt);
					if (amountTxt.contains(value)) {
						txtValue.click();
						break;
					} else {
						LogUtility.logInfo("User is unable to click on the account" + value);
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on account under preferences" + e);
			throw new Exception(" Unable to click on account under preferences " + e);
		}
	}

	/**
	 * Method to clickonSelectedAccount based on accountName
	 * 
	 * @throws Exception
	 * 
	 * 
	 */
	public void clickOnSelectedAccount(String accountName) throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				// i value started from 6 because we are getting the account names from that
				// point.
				for (int i = 6; i < lstPreferenceAccounts.size(); i++) {
					WebElement txtValue = lstPreferenceAccounts.get(i).findElement(By.id("android:id/title"));
					String accountText = txtValue.getText();
					if (accountText.contains(accountName)) {
						txtValue.click();
						LogUtility.logInfo("User is able to click on the account::" + accountText);
						break;
					} else {
						continue;
					}
				}
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				for (RemoteWebElement liElement : lstPreferenceAccounts) {
					WebElement txtValue = liElement.findElement(By.xpath(preferenceText2));
					amountTxt = liElement.findElement(By.xpath(preferenceText2)).getText();
					LogUtility.logInfo("account name is:" + amountTxt);
					if (amountTxt.contains(accountName)) {
						txtValue.click();
						LogUtility.logInfo("User is able to click on the account::" + accountName);
						break;
					} else {
						continue;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->unable to click the account " + e);
			throw new Exception("Unable to click the account " + e);
		}
	}

	/**
	 * Method to verify account is present in view accounts page
	 * 
	 * @throws Exception
	 * 
	 * 
	 */
	public void verifyAccountIsPresentInViewAccounts(String accountName) throws Exception {
		try {
			ConcurrentEngines.getCustomEngine().getAppiumDriver().navigate().back();
			ConcurrentEngines.getCustomEngine().getAppiumDriver().navigate().back();
			if (mobileActions.verifyIsElementPresent(lblAccountPageText, 8)) {
				LogUtility.logInfo("accounts size" + accountsListedCount.size());
				for (int i = 0; i < accountsListedCount.size(); i++) {
					String txtValue = accountsListedCount.get(i).getText();
					if (txtValue.contains(accountName)) {
						LogUtility.logInfo("User is able to verify that account is present" + txtValue);
						break;
					} else {
						continue;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify the account " + e);
			throw new Exception("Unable to verify the account " + e);
		}
	}

	/**
	 * Method to verify account is present in TransactionHistory page
	 * 
	 * @throws Exception
	 * 
	 * 
	 */
	public void verifyAccountPresentInTransactionHistory(String accountName) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblAccountPageText, 8)) {
				LogUtility.logInfo("accounts size" + accountsListedCount.size());
				for (int i = 0; i < accountsListedCount.size(); i++) {
					String txtValue = accountsListedCount.get(i).getText();
					if (txtValue.contains(accountName)) {
						LogUtility.logInfo("User is able to verify that account is present" + txtValue);
						break;
					} else {
						continue;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify the account " + e);
			throw new Exception("Unable to verify the account " + e);
		}
	}

	/**
	 * Method to verify Fund Transfer Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyTransferFundPage(String title) throws Exception {
		try {
			mobileActions.isElementPresent(lblFundTransferText, 10);
			if (lblFundTransferText.getText().contains(title)) {
				LogUtility.logInfo("Transfer head text displayed as : " + lblFundTransferText.getText());
				return true;
			} else {
				LogUtility.logInfo("Transfer head text head is not displayed");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify Transfer fund page" + e);
			throw new Exception("Unable to verify Transfer fund page " + e);
		}

	}

	public void verifyAccountsUnderAccountPreferences() throws Exception {
		try {
			String accountName = null;
			List<String> accts = new ArrayList<String>();
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				LogUtility.logInfo("preference list size is:" + lstAccountsUnderPreferences.size());
				for (RemoteWebElement liElement : lstAccountsUnderPreferences) {
					accountName = liElement.findElement(By.xpath(accountsText)).getText();
					accts.add(accountName);
				}
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				for (RemoteWebElement liElement : lstAccountsUnderPreferences) {
					accountName = liElement.findElement(By.xpath(preferenceText2)).getText();
					LogUtility.logInfo("account name is:" + accountName);
					accts.add(accountName);
				}
			}
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify Accounts Under Preferences" + e);
			throw new Exception("Unable to verify Accounts Under Preferences " + e);
		}
	}

	/**
	 * Method to click on the options button
	 * 
	 * @throws Exception
	 */
	public void clickAccountOptionsButton(String account) throws Exception {
		String xpathReplace = btnAccountOptions.replace("AccountReplace", account);
		MobileElement optionIcon = (MobileElement) appiumDriver.findElement(By.xpath(xpathReplace));
		mobileActions.isElementPresent(optionIcon, 4);
		if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
			optionIcon.click();
			btnSeeDetails.click();
			LogUtility.logInfo("User clicked on options button in android device");
		} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
			optionIcon.click();
			LogUtility.logInfo("User clicked on options button in ios device");
		}
	}

	/**
	 * Method to verify account details for LOC accounts
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyAccountDetailsScreenLOCAccount() throws Exception {
		try {
			mobileActions.isElementPresent(lblAccountHeadDetails, 6);
			List<RemoteWebElement> numberTextFieldsElements = Arrays.asList(txtCurrentBalance, lblCreditLimit,
					lblLastPayment, lblYTDInterest, lblAmountDueNow, lblNextPaymentDue);
			mobileActions.elementsPresent(numberTextFieldsElements);
			LogUtility.logInfo("Verified all the elements on Account details page");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the elements on Account details page " + e);
			throw new Exception("Unable to verify the elements on Account details page " + e);
		}
	}

	/**
	 * Method to verify account details for Other LOC accounts
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyAccountDetailsScreenOtherLOCAccount() throws Exception {
		try {
			mobileActions.isElementPresent(lblAccountHeadDetails, 6);
			List<RemoteWebElement> numberTextFieldsElements = Arrays.asList(txtCurrentBalance, lblLastPayment,
					lblYTDInterest, lblAmountDueNow, lblNextPaymentDue);
			mobileActions.elementsPresent(numberTextFieldsElements);
			LogUtility.logInfo("Verified all the elements on Account details page");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the elements on Account details page " + e);
			throw new Exception("Unable to verify the elements on Account details page " + e);
		}
	}

	/**
	 * Method to verify account details for Credit Card accounts
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyAccountDetailsScreenCreditCardAccount() throws Exception {
		try {
			mobileActions.isElementPresent(lblAccountHeadDetails, 6);
			List<RemoteWebElement> numberTextFieldsElements = Arrays.asList(lblCreditLimit);
			mobileActions.elementsPresent(numberTextFieldsElements);
			LogUtility.logInfo("Verified all the elements on Account details page");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the elements on Account details page " + e);
			throw new Exception("Unable to verify the elements on Account details page " + e);
		}
	}

	/**
	 * Method to verify account details for Credit Card accounts
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyAccountDetailsScreenCDAccount() throws Exception {
		try {
			mobileActions.isElementPresent(lblAccountHeadDetails, 6);
			List<RemoteWebElement> numberTextFieldsElements = Arrays.asList(txtCurrentBalance, txtAvailableBalance,
					lblInterestPaidAmount, lblYTDInterest, lblCurrentAPY, lblMaturityDate);
			mobileActions.elementsPresent(numberTextFieldsElements);
			LogUtility.logInfo("Verified all the elements on Account details page");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the elements on Account details page " + e);
			throw new Exception("Unable to verify the elements on Account details page " + e);
		}
	}
}
