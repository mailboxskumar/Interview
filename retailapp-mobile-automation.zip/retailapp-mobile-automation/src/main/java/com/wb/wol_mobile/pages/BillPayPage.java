package com.wb.wol_mobile.pages;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.touch.offset.PointOption;

public class BillPayPage extends ObjectBase {

	ViewAccountsPage viewAccountsPage = new ViewAccountsPage();
	MobileActions mobileActions = new MobileActions();

	public BillPayPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	@AndroidFindBy(id = "com.malauzai.websterbank:id/username_entry")
	@iOSFindBy(className = "XCUIElementTypeTextField")
	@CacheLookup
	protected MobileElement txtUserName;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/password_entry")
	@iOSFindBy(className = "XCUIElementTypeSecureTextField")
	@CacheLookup
	protected MobileElement txtPassword;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/account_name\"][1]")
	@iOSFindBy(xpath = "//*[@name=\"Pay From\"]//XCUIElementTypeTextField")
	protected MobileElement txtPayFrom;

	@iOSFindBy(xpath = "//*[@value=\"Payment Canceled Successfully\"]")
	protected MobileElement txtPaymentCancelled;

	@AndroidFindBy(xpath = "//*[@text=\"Cancel Payment\"]")
	@iOSFindBy(xpath = "//*[@label=\"Cancel Payment\"]")
	protected MobileElement btnCancelPayment;

	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/editable_rows']/android.widget.RelativeLayout[2]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value=\"Payee\"]")
	protected MobileElement txtPayee;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeTable[1]/XCUIElementTypeCell[1]/XCUIElementTypeStaticText[1]")
	protected MobileElement lstPayee;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@label=\"Amount\"]/XCUIElementTypeTextField[2]")
	protected MobileElement txtAmount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/b_submit")
	@iOSFindBy(xpath = "//*[@label=\"LOG IN\"]")
	@CacheLookup
	protected MobileElement btnLogin;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//*[@label=\"Confirm\"]")
	@CacheLookup
	protected MobileElement btnConfirm;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@label=\"Auxiliary Menu\"]")
	@CacheLookup
	protected MobileElement btnAux;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	@CacheLookup
	protected MobileElement txtAccountPage;

	@AndroidFindBy(id = "electronicSetupContinue__actualButton")
	@iOSFindBy(xpath = "//*[@label=\"Continue\"]")
	@CacheLookup
	protected MobileElement btnContinue;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@label=\"Set Start Page\"]")
	@CacheLookup
	protected MobileElement btnSetStartPage;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@label=\"Change Account Order\"]")
	@CacheLookup
	protected MobileElement btnChangeAccountOrder;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@label=\"PREFERENCES\"]")
	@CacheLookup
	protected MobileElement txtPreferences;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'The selected payee requires a check payment. The payment date must be at least 3 business days from today.']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'The selected payee requires a check payment. The payment date must be at least 3 business days from today.']")
	protected MobileElement paymentThreeBusinessErrorMessage;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@value=\"Touch ID\"]")
	@CacheLookup
	protected MobileElement btnTouchId;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "")
	@iOSFindBy(xpath = "//*[@value=\"Passcode Login\"]")
	@CacheLookup
	protected MobileElement btnPassCodeLogin;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@content-desc=\"Open navigation drawer\"]")
	@AndroidFindBy(xpath = "//*[@content-desc='Menu']")
	@iOSFindBy(xpath = "//*[@label='menu']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='menu']")
	@iOSFindBy(xpath = "//*[@label=\"Webster Bank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeButton[1]")
	protected MobileElement btnHamburger;

	@iOSFindBy(xpath = "//*[@label=\"Webster Bank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeButton[1]")
	protected MobileElement btnHamburgerImg;

	@AndroidFindBy(xpath = "//*[@text=\"Pay Bills\"]")
	@iOSFindBy(xpath = "//*[@label=\"Pay Bills\"]")
	protected MobileElement txtPayBills;

	@AndroidFindBy(id = "android:id/progress")
	@iOSFindBy(xpath = "//XCUIElementTypeActivityIndicator[@label = 'In progress']")
	protected MobileElement loadSpinner;

	@AndroidFindBy(xpath = "//*[@text=\"Pay Bills\"]")
	@iOSFindBy(xpath = "//*[@label=\"PAY BILLS\"]")
	protected MobileElement btnPayBill;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/parallax_button_1")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label='PAY BILLS']")
	@iOSFindBy(xpath = "//*[@label=\"billpay makepaymentbutton img\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label ='billpay makepaymentbutton img']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@name ='billpay makepaymentbutton img']")
	protected MobileElement txtPayABills;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/parallax_button_1")
	@iOSFindBy(xpath = "//*[@label=\"billpay makepaymentbutton img\"]")
	protected MobileElement btnPayABills;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/options_button")
	@iOSFindBy(xpath = "//AppiumAUT/XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[2]/XCUIElementTypeCollectionView[1]/XCUIElementTypeButton[1]")
	protected MobileElement moreOptionsButton;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/options_button\"][1]")
	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeCell[1]/XCUIElementTypeButton[1]")
	protected MobileElement btnMoreOptions;

	@AndroidFindBy(xpath = "//*[@text=\"Cancel Payment\"]")
	@iOSFindBy(xpath = "//*[@label=\"Cancel Payment\"]")
	@CacheLookup
	protected MobileElement txtCancelPayment;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//*[@label=\"Confirm\"]")
	@CacheLookup
	protected MobileElement btnConfirmButton;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//*[@label=\"OK\"]")
	protected MobileElement btnOk;

	@AndroidFindBy(id = "//*[@resource-id=\"android:id/message\"]")
	@iOSFindBy(xpath = "//*[@label=\"Billpay is not setup for this user\"]")
	protected MobileElement txtBillPayNotSetup;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label=\"Create a Payment\"]")
	protected MobileElement txtCreateAPayment;

	@AndroidFindBy(xpath = "//android.widget.Button[@resourceid='com.malauzai.websterbank:id/button']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value=\"Delivery Date\"]")
	protected MobileElement btnDeliveryDate;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/button_ok")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Done' and @enabled = 'true']")
	@iOSFindBy(xpath = "//*[@label=\"Done\"]")
	protected MobileElement btnDone;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value=\"Delivery Option\"]")
	protected MobileElement btnDeliveryOption;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/option_name\"]")
	@iOSFindBy(xpath = "//*[@label=\"Empty list\"]")
	@iOSFindBy(xpath = "//*[@label=\"Standard ($0.00) \"]")
	protected MobileElement btnStandard;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/button_done")
	@iOSFindBy(xpath = "//*[@label=\"Submit\"]")
	protected MobileElement btnSubmit;

	/** Need to provide the locator for Android **/
	@iOSFindBy(xpath = "//*[@label=\"Please choose a from account\"]")
	protected MobileElement btnChooseFromAccount;

	@iOSFindBy(xpath = "//*[@label=\"Please choose a to account\"]")
	@CacheLookup
	protected MobileElement lblChooseToAccount;

	@iOSFindBy(xpath = "//*[@label=\"Please choose a payee\"]")
	@CacheLookup
	protected MobileElement lblChoosePayee;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Payment maximum is $1,000,000. Please select a lower amount.']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Payment maximum is $1,000,000. Please select a lower amount.']")
	protected MobileElement pendingPaymentRemoved;

	@iOSFindBy(xpath = "//*[@label=\"Clear text\"]")
	protected MobileElement btnClear;

	@AndroidFindBy(xpath = "//*[@text=\"Transfer Funds\"]")
	@iOSFindBy(xpath = "//*[@label=\"Transfer Funds\"]")
	protected MobileElement lblTransferModule;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/editable_rows']/android.widget.RelativeLayout[2]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value=\"Payee\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value='Payee']")
	@iOSFindBy(xpath = "//*[@name=\"Payee\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@name= 'Payee']")
	protected MobileElement txtSelectPayee;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/account_name\"][1]")
	@iOSFindBy(xpath = "//*[@name=\"Pay From\"]//XCUIElementTypeTextField")
	protected MobileElement txtSelectPayFrom;

	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value = 'Amount']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/currency")
	protected MobileElement lblAmount;

	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value = 'From']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'From']")
	protected MobileElement lblFrom;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@value = 'Temporarily Unavailable']")
	@AndroidFindBy(xpath = "//*[@text=\"Temporarily Unavailable\"]")
	protected MobileElement txtTempUnavailable;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@value = 'for 24/7 assistance.']")
	@AndroidFindBy(xpath = "//*[@text=\"Please try again later, or call 1-800-325-2424 for 24/7 assistance.\"]")
	protected MobileElement txtTryAgain;

	@iOSFindBy(xpath = "//*[@value='Delivery Date']")
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id = 'com.malauzai.websterbank:id/value']")
	protected MobileElement lblDeliveryDate;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id= 'com.malauzai.websterbank:id/value']")
	@AndroidFindBy(xpath = "//android.widget.EditText[@text= 'Send Date']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value=\"Delivery Date\"]")
	@AndroidFindBy(xpath = "//*[text()=\"Send Date\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name=\"TransfersSendDatePropertyCell\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@label = 'Delivery Date' and @enabled = 'true']")
	protected MobileElement lblSendDate;

	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value = 'Reference Number']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Reference Number']")
	protected MobileElement lblReferenceNumber;

	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@value = 'Status']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Status']")
	protected MobileElement lblStatus;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Close']")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='CLOSE']")
	protected MobileElement btnClose;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Are you sure you want to cancel this scheduled payment?']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Are you sure you want to cancel this scheduled payment?']")
	protected MobileElement lblPaymentCancelConfirmMessage;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/empty_view_text")
	@iOSFindBy(xpath = "//*[@label=\"No results\"]")
	protected MobileElement txtNoPayments;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Payment Canceled Successfully']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@AndroidFindBy(xpath = "//android.widget.TextView[@label = 'Payment Canceled Successfully']")
	@AndroidFindBy(id = "android:id/message")
	protected MobileElement txtPaymentCancelMessage;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@label = 'We are unable to process your request at this time. Please try again later.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'We are unable to process your request at this time. Please try again later.']")
	@AndroidFindBy(id = "android:id/message")
	protected MobileElement unableToProcessError;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Payment maximum is $1,000,000. Please select a lower amount.']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Payment maximum is $1,000,000. Please select a lower amount.']")
	protected MobileElement maximumPaymentsErrorMessage;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@text(),'Payment submitted sucessfully.')]")
	protected MobileElement paymentsConfirmationMessage;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'You do not currently have any accounts eligible to make a payment.']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Sorry, none of your account are eligible to use this feature.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'No results']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='No Items Available']")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='You do not currently have any accounts eligible to make a payment.']")
	protected MobileElement txtNoPaymentsErrorMessage;

	@iOSFindBy(xpath = "//*[@label=\"PAY BILLS\"]")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='PAY BILLS']")
	protected MobileElement titlePayBills;

	@iOSFindBy(xpath = "//*[@label=\"PAY BILLS\"]")
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='$0.00']")
	protected MobileElement zeroAmountValue;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell")
	protected List<RemoteWebElement> payeeListedCount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/selected_day_of_month_date")
	@iOSFindBy(xpath = "//*[@label=\"Clear Date\"]")
	protected MobileElement paneCalendar;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/calendar_next_button")
	protected MobileElement calenderNext;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/button_ok")
	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'OK']")
	@iOSFindBy(xpath = "//*[@label=\"Done\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Done']")
	protected MobileElement btnCalendarOkDone;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	// @iOSFindBy(xpath =
	// "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell")
	protected List<RemoteWebElement> payeeToListedCount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/amount")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell")
	protected List<RemoteWebElement> payBillHistoryCount;

	public String dynamicXpathHistoryAmount = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[4] |"
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/amount'])[%d]";

	private String dynamicPayeeValue = "//XCUIElementTypeOther[1]/XCUIElementTypeTable[1]/XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	public String iosDeliveryDate;
	public String amountEnter = null;
	public String noErrorMsg = null;
	public String pendingErrorMsg = null;
	private String selectAccount;

	List<String> payeeDropdownList;

	RetailAppUtils retailAppUtils = new RetailAppUtils();

	/**
	 * Method to verify Create Payment text is displayed or not
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyTextCreatePayment() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtCreateAPayment, 5)) {
				LogUtility.logInfo("Successfully verified create a payment page");
				return true;
			} else
				LogUtility.logError("Unable to Verify create a payment page");
			return false;
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify text create payment" + e);
			throw e;
		}
	}

	/**
	 * Method to verify Bill pay not setup text
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyTextBillPayNotSetup(String arg1) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtBillPayNotSetup, 5)) {
				LogUtility.logInfo("Successfully verified Error Message, Billpay not setup");
				return true;
			} else
				LogUtility.logError("Unable to Verify Error Message, Billpay not setup");
			return false;
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify text bill payment notsetup" + e);
			throw e;
		}
	}

	/**
	 * Method to verify Choose From Account Button
	 * 
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public boolean verifyChooseToAccount(String value) {
		if (lblChooseToAccount.getText().contains(value)) {
			LogUtility.logInfo("To Account Value dispalyed as : " + value);
			return true;
		} else {
			LogUtility.logError("Incorrect Choose To Account Value dispalyed : " + lblChooseToAccount.getText());
			return false;
		}

	}

	public boolean verifyChoosePayee(String value) throws Exception {
		if (TestDataConstants.getOSPlatformName().contains("ios")) {
			if (lblChoosePayee.getText().contains(value)) {
				LogUtility.logInfo("Payee Account Value displayed as : " + value);
			} else {
				LogUtility.logInfo("Payee field is not selected as expected");
				return false;
			}
		}
		return true;
	}

	public void clickOnCalender() throws Exception {
		try {
			mobileActions.isElementPresent(lblDeliveryDate, 10);
			lblDeliveryDate.click();
			LogUtility.logInfo("Clicked on Calendar");
			waits.staticWait(5);
			retailAppUtils.fluentWaitElement(btnDone, 10, 1).click();
			LogUtility.logInfo("Clicked on Calendar with present date ");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Calendar " + e);
			throw e;
		}
	}

	public boolean verifyChooseFromAccount(String value) throws Exception {
		if (TestDataConstants.getOSPlatformName().contains("ios")) {
			if (btnChooseFromAccount.getText().contains(value)) {
				LogUtility.logInfo("From Account Value dispalyed as : " + value);
			} else {
				LogUtility.logInfo("Pay From not selected as expected");
				return false;
			}
		}
		return true;
	}

	/**
	 * Method to verify Payment Canceled text
	 * 
	 * @return
	 * @throws Exception
	 */

	public boolean verifyTextPaymentCanceled() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtPaymentCancelled, 5)) {
				LogUtility.logInfo("Successfully verified Payment Canceled Successfully text");
				return true;
			} else {
				LogUtility.logError("Unable to Verify Payment Canceled Successfully text");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify text payment cancelled" + e);
			throw e;
		}

	}

	/**
	 * Method to verify Hamburger button
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyHamburgerButton() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(btnHamburger, 10)) {
				LogUtility.logInfo("Successfully verified hamburgerbutton at View Account page");
				return true;
			} else {
				LogUtility.logError("Unable to Verify hamburgerbutton at View Account page");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->unable to verify Hamburgerbutton" + e);
			throw e;
		}
	}

	/**
	 * Method to verify Pay A Bills text
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyTextPayABills() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(txtPayABills, 5)) {
				LogUtility.logInfo("Successfully verified payabill label text at billpay page");
				return true;
			} else {
				LogUtility.logError("Unable to verify payabill label text at billpay page");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Text Pay A Bills Button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Done button
	 * 
	 */

	public void verifyDoneButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnDone, 5);
			LogUtility.logInfo("Successfully verified done button at billpay callender page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Done button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Submit button
	 */
	public void clickSubmitButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnSubmit, 5);
			btnSubmit.click();
			LogUtility.logInfo("successfully clicked on submit button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Submit button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on OK button
	 */
	public void clickOkButton() throws Exception {
		try {
			btnOk.click();
			LogUtility.logInfo("successfully clicked on OK button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on OK button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Select Payee from
	 */
	public void clickTextSelectPayee() throws Exception {
		try {
			mobileActions.isElementPresent(txtSelectPayee, 5);
			txtSelectPayee.click();
			LogUtility.logInfo("successfully clicked on payee from the list");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to select the payee <---" + e.getStackTrace());
			throw e;
		}
	}

	public void clickTextSelectPayFrom() throws Exception {
		try {
			txtSelectPayFrom.click();
			// After selecting Payfrom page itself is taking few seconds to get stable tried
			// with list of element not working.So here static wait is mandatory.
			waits.staticWait(6);
			LogUtility.logInfo("successfully clicked on payFrom from list");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to select the PayFrom <---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Delivery Option button
	 */
	public void clickDeliveryOptionButton() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				btnDeliveryOption.click();
				LogUtility.logInfo("successfully clicked on delivery Option button");
			} else {
				LogUtility.logInfo("It is running on Android Delivery Option not required");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on delivery Option button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click standard button
	 */
	public void clickStandardButton() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				mobileActions.isElementPresent(btnStandard, 10);
				btnStandard.click();
				LogUtility.logInfo("successfully clicked on standard button");
			} else {
				LogUtility.logInfo("Running on android click on standard button not applicable");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Standard button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Standard Button
	 * 
	 */
	public void verifyStandardButton() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				btnStandard.isDisplayed();
				LogUtility.logInfo("Successfully verified standard button ");
			} else {
				LogUtility.logInfo("Running on android verification of standard button not applicable");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Not able to verify Standard button <---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Done Button
	 */
	public void clickDoneButton() throws Exception {
		try {
			btnDone.click();
			LogUtility.logInfo("successfully clicked on done button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on done button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Pay A Bills Text
	 */
	public void clickTextPayABills() throws Exception {
		try {
			mobileActions.isElementPresent(btnPayABills, 20);
			waits.staticWait(2);
			btnPayABills.click();
			LogUtility.logInfo("successfully clicked and verifying on payabill text");
			try {
				mobileActions.isElementPresent(txtCreateAPayment, 5);
			} catch (TimeoutException e) {
				btnPayABills.click();
				mobileActions.isElementPresent(txtCreateAPayment, 5);
			}
			LogUtility.logInfo("successfully clicked on payabill text");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click payabill text<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Delivery Date button
	 */
	public void clickDeliveryDateButton() throws Exception {
		try {
			btnDeliveryDate.click();
			LogUtility.logInfo("successfully clicked on delivery date button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on delivery date button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click context button
	 */
	public void clickMoreOptions() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(btnMoreOptions, 100, 1).click();
			LogUtility.logInfo("successfully clicked on first moreoptions in the list");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on moreoptions<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Cancel Payment button
	 * 
	 * @return
	 */
	public void verifyCancelPaymentButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnCancelPayment, 10);
			LogUtility.logInfo("Successfully verified cancelpayment button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify cancel payment button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click cancelpayment button
	 */
	public void clickCancelPaymentButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnCancelPayment, 10);
			btnCancelPayment.click();
			LogUtility.logInfo("successfully clicked on cancelPayment button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on cancelpayment button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method To click PayBills and wait the list to load
	 */
	public void clickTextPayBills() throws Exception {
		try {
			mobileActions.isElementPresent(txtPayBills, 5);
			txtPayBills.click();
			LogUtility.logInfo("successfully clicked on pay bills button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on paybills<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method To click PayBills button
	 */
	public void clickPayBillButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnPayBill, 10);
			btnPayBill.click();
			LogUtility.logInfo("successfully clicked on pay bill button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on paybill<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click confirm button
	 */
	public void clickConfirmButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnConfirm, 10);
			btnConfirm.click();
			LogUtility.logInfo("successfully clicked on confirm button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on confirm button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Hamburger button
	 */
	public void clickHamburgerButton() throws Exception {
		try {
			if (mobileActions.isElementDisplayed(btnHamburger, 30)) {
				btnHamburger.click();
				LogUtility.logInfo("successfully clicked on hamburgermenu button");
			} else {
				try {
					mobileActions.isElementPresent(btnHamburgerImg, 30);
					btnHamburgerImg.click();
				} catch (NoSuchElementException e) {
					LogUtility.logError("--->Unable to click on HamburgerButton<---" + e.getStackTrace());
					throw e;
				}
			}
			mobileActions.isElementPresent(lblTransferModule, 10);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on HamburgerButton<---" + e.getStackTrace());
			try {
				mobileActions.verifyIsElementPresent(btnHamburger, 5);
				btnHamburger.click();
				LogUtility.logInfo("successfully clicked on hamburgermenu button");
			} catch (Exception ex) {
				LogUtility.logException("clickHamburgerButton", ex, LoggingLevel.ERROR, true);
				throw ex;
			}
		}
	}

	/**
	 * Method to click Payee to text
	 */
	public void clickTextPayee() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(txtSelectPayee, 5, 5);
			mobileActions.isElementPresent(txtSelectPayee, 10);
			txtSelectPayee.click();
			LogUtility.logInfo("payee field clicked successfully");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Payee field<---" + e.getStackTrace());
			throw e;
		}
	}

	public void clickTextPayFrom() throws Exception {
		try {
			mobileActions.isElementPresent(txtPayFrom, 10);
			txtPayFrom.click();
			LogUtility.logInfo("payFrom field clicked successfully");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on PayFrom field<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to enter amount in amount field
	 * 
	 * @param Amount
	 */

	public void enterAmount(String amount) throws Exception {
		try {
			amountEnter = amount;
			lblAmount.click();
			if (TestDataConstants.getOSPlatformName().contains("android")) {
				for (int i = 0; i <= 8; i++) {
					lblAmount.clear();
				}
				for (int i = 0; i < amountEnter.length(); i++) {
					char c = amountEnter.charAt(i);
					String eachCharacter = new StringBuilder().append(c).toString();
					lblAmount.sendKeys(eachCharacter);
				}
			} else if (TestDataConstants.getOSPlatformName().contains("ios")) {
				try {
					waits.staticWait(5);
					txtAmount.clear();
					waits.staticWait(2);
					txtAmount.sendKeys(amount);
					waits.staticWait(2);
					btnDone.click();
					LogUtility.logInfo("successfully clicked on done button");
				} catch (Exception e) {
					LogUtility.logError("--->Unable to click on done button<---" + e.getStackTrace());
					throw e;
				}
			}
			LogUtility.logInfo("amount is successfully entered in the amount field");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to Enter Amount<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click Login Button
	 */
	public void clickLoginButton() throws Exception {
		try {
			btnLogin.click();
			LogUtility.logInfo("successfully clicked on login button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Login button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Account title in Accounts summary page
	 * 
	 */
	public void verifyAccountsPage() throws Exception {
		try {
			txtAccountPage.isDisplayed();
			LogUtility.logInfo("Successfully verified Account title in accounts page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Account Page<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify pre-login page
	 * 
	 * @return
	 */
	public void verifyPreLoginPage() throws Exception {
		try {
			mobileActions.isElementPresent(btnLogin, 5);
			LogUtility.logInfo("Successfully verified login page in pre-login page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Login button<---" + e.getStackTrace());
			throw e;
		}
	}

	public boolean verifyNoPaymentsScreen() throws Exception {
		try {
			mobileActions.isElementPresent(txtNoPayments, 5);
			LogUtility.logInfo("Successfully verified No Payments page");
			return true;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify No Payments page<---" + e.getStackTrace());
			return false;
		}
	}

	public boolean verifyPayBillHistoryBalances() throws Exception {
		try {
			String historyAmount = null;
			if (payBillHistoryCount.size() != 0) {

				int counter = 1;
				do {
					historyAmount = appiumDriver
							.findElement(By.xpath(String.format(dynamicXpathHistoryAmount, counter, counter)))
							.getText();
					counter += counter;
				} while (counter <= 2);
				if (historyAmount.equals("$0.02")) {
					LogUtility.logInfo("Duplicate transactions has been performed successfully");
				} else {
					LogUtility.logInfo("Duplicate transactions has not been performed");
				}
			}
			return true;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the history amounts from Duplicate transactions " + e);
			throw e;
		}
	}

	public void verifyPaymentDetailsScreen() throws Exception {
		try {
			List<RemoteWebElement> paymentDetailsScreenElements = new ArrayList<RemoteWebElement>();
			paymentDetailsScreenElements
					.addAll(Arrays.asList(lblAmount, lblFrom, lblDeliveryDate, lblReferenceNumber, lblStatus));
			mobileActions.elementsPresent(paymentDetailsScreenElements);
			LogUtility.logInfo("Payment Detail Screen is Displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to display Transfer screen details<---" + e.getStackTrace());
			throw e;
		}

	}

	public void verifyTemporaryUnavailableScreen() throws Exception {
		try {
			List<RemoteWebElement> temporaryScreenElements = Arrays.asList(txtTempUnavailable, txtTryAgain);
			mobileActions.elementsPresent(temporaryScreenElements);
			LogUtility.logInfo("Temporarily Unable Screen is Displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to display Temporarily Unable screen details<---" + e.getStackTrace());
			throw e;
		}

	}

	/**
	 * Method to verify the cancel confirm message in payment cancel page
	 * 
	 * @param errorMessage
	 * @return
	 * @throws Exception
	 */
	public String verifyPaymentCancelConfirmMessage(String confirmMessage) throws Exception {
		try {
			String confirmMsg = lblPaymentCancelConfirmMessage.getText();
			LogUtility.logInfo("cancel confirm message:" + confirmMsg);
			Assert.assertEquals(confirmMsg, confirmMessage);
			LogUtility.logInfo("--->Confirm message displayed as " + confirmMsg);
			return confirmMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + confirmMessage + " " + e.getStackTrace());
			throw e;
		}

	}

	/**
	 * Method to click Close Button
	 * 
	 */

	public void clickCloseButton() throws Exception {
		try {
			btnClose.click();
			LogUtility.logInfo("successfully clicked on CLOSE button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on CLOSE button<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify o payments cancel message
	 * 
	 * @param errorMessageIos
	 * @param errorMessageAndroid
	 * @return
	 * @throws Exception
	 */
	public String verifyPaymentCancelMessage(String cancelMessage) throws Exception {
		try {
			mobileActions.isElementPresent(txtPaymentCancelMessage, 10);
			String cancelMsg = txtPaymentCancelMessage.getText();
			LogUtility.logInfo("Error Message is displayed as:" + cancelMsg);
			Assert.assertEquals(cancelMsg, cancelMessage);
			LogUtility.logInfo("--->Error message displayed as " + cancelMsg);
			return cancelMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + cancelMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	public String verifyPaymentThreeBusinessErrorMessage(String errorMessage) throws Exception {
		try {
			mobileActions.isElementPresent(paymentThreeBusinessErrorMessage, 10);
			noErrorMsg = paymentThreeBusinessErrorMessage.getText();
			LogUtility.logInfo("*** No Error Message ***" + noErrorMsg);
			Assert.assertEquals(noErrorMsg, errorMessage);
			LogUtility.logInfo("--->NoPayments Error message displayed as " + noErrorMsg);
			clickOkButton();
			return noErrorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify unable to process error message
	 * 
	 * @param errorMessageIos
	 * @param errorMessageAndroid
	 * @return
	 * @throws Exception
	 */
	public String verifyUnableToProcessMessage(String cancelMessage) throws Exception {
		try {
			mobileActions.isElementPresent(unableToProcessError, 10);
			String cancelMsg = unableToProcessError.getText();
			LogUtility.logInfo("Error Message is displayed as:" + cancelMsg);
			Assert.assertEquals(cancelMsg, cancelMessage);
			LogUtility.logInfo("--->Error message displayed as " + cancelMsg);
			return cancelMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + cancelMessage + " " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify no payments error message
	 * 
	 * @param errorMessageIos
	 * @param errorMessageAndroid
	 * @return
	 * @throws Exception
	 */
	public String verifyNoPaymentsMessage(String errorMessageIos, String errorMessageAndroid) throws Exception {
		try {
			waits.staticWait(2);
			mobileActions.isElementPresent(txtNoPaymentsErrorMessage, 10);
			noErrorMsg = txtNoPaymentsErrorMessage.getText();
			LogUtility.logInfo("***No error message***** " + noErrorMsg);
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				Assert.assertEquals(noErrorMsg, errorMessageAndroid);
				LogUtility.logInfo("--->Payments error message android displayed as " + noErrorMsg);
				return noErrorMsg;
			} else {
				Assert.assertEquals(noErrorMsg, errorMessageIos);
				LogUtility.logInfo("--->Payments error message for ios displayed as " + noErrorMsg);
				return noErrorMsg;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Maximum payment error message
	 * 
	 * @param errorMessage
	 * @return
	 * @throws Exception
	 */
	public String maximumPaymentErrorMessage(String errorMessage) throws Exception {
		try {
			mobileActions.isElementPresent(maximumPaymentsErrorMessage, 10);
			noErrorMsg = maximumPaymentsErrorMessage.getText();
			LogUtility.logInfo("***No error message***** " + noErrorMsg);
			Assert.assertEquals(noErrorMsg, errorMessage);
			LogUtility.logInfo("--->NoPayments error message  displayed as " + noErrorMsg);
			clickOkButton();
			return noErrorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify confirmation message for payments
	 * 
	 * @param errorMessageIos
	 * @param errorMessageAndroid
	 * @return
	 * @throws Exception
	 */
	public String paymentConfirmationMessage(String errorMessage) throws Exception {
		try {
			mobileActions.isElementPresent(paymentsConfirmationMessage, 10);
			noErrorMsg = paymentsConfirmationMessage.getText();
			LogUtility.logInfo("***payment confirmation message***** " + noErrorMsg);
			Assert.assertEquals(noErrorMsg, errorMessage);
			LogUtility.logInfo("--->*payment confirmation message  displayed as " + noErrorMsg);
			clickOkButton();
			return noErrorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to select payee from the list
	 * 
	 * @param count
	 * @return
	 * @throws Exception
	 */
	public String selectToPayee(int count) throws Exception {

		try {
			if (payeeToListedCount.size() > 0) {
				int i = count;
				selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicPayeeValue, i, i))).getText();
				WebElement clickOnAccount = appiumDriver.findElement(By.xpath(String.format(dynamicPayeeValue, i, i)));
				LogUtility.logInfo("Account selected is :" + selectAccount);
				clickOnAccount.click();
				return selectAccount;
			} else {
				LogUtility.logInfo("There are no accounts to select To Payee");
				return null;
			}

		} catch (Exception e) {
			LogUtility.logError("--->Unable Select ToPayee<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to select account base on name
	 * 
	 * @param name
	 * @return
	 * @throws Exception
	 */
	public String selectPayeeByName(String name) throws Exception {
		try {
			int accountSize = payeeToListedCount.size();
			LogUtility.logInfo("list of payee size is:" + accountSize);
			for (int i = 0; i <= accountSize; i++) {
				selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicPayeeValue, i, i))).getText();
				if (selectAccount.contains(name)) {
					WebElement clickOnAccount = appiumDriver
							.findElement(By.xpath(String.format(dynamicPayeeValue, i, i)));
					LogUtility.logInfo("Account selected is :" + selectAccount);
					clickOnAccount.click();
					break;
				}
			}
			return selectAccount;
		} catch (Exception e) {
			LogUtility.logError("--->Unable Select Payee By Name<---" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to select any account from the list of accounts displayed in payments
	 * page page Will verify the account selected is opened
	 * 
	 * @throws Exception
	 */
	public String selectFromAccount(int count) throws Exception {
		try {
			if (payeeToListedCount.size() > 0) {
				int i = count;
				selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicPayeeValue, i, i))).getText();
				WebElement clickOnAccount = appiumDriver.findElement(By.xpath(String.format(dynamicPayeeValue, i, i)));
				LogUtility.logInfo("Account selected " + selectAccount);
				mobileActions.isElementPresent(clickOnAccount, 8);
				clickOnAccount.click();
				return selectAccount;
			} else {
				LogUtility.logInfo("There are no accounts to select From Account");
				return null;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable Select From Payee<---" + e.getStackTrace());
			throw e;
		}
	}

	public void tapOnSendDate() throws Exception {
		try {
			mobileActions.isElementPresent(lblSendDate, 10);
			if (TestDataConstants.getOSPlatformName().contains("ios")) {
				iosDeliveryDate = lblSendDate.getAttribute("value");
			}
			lblSendDate.click();
			mobileActions.isElementPresent(paneCalendar, 10);
			LogUtility.logInfo("Clicked on Calendar");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Calendar " + e);
			throw e;
		}
	}

	public List<String> getDropdownPayees() {
		payeeDropdownList = new ArrayList<String>();
		try {
			for (int i = 1; i < payeeToListedCount.size(); i++) {
				String popularList = payeeToListedCount.get(i).getText();
				LogUtility.logInfo("Account selected is :" + popularList);
				payeeDropdownList.add(popularList);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the payee Name <---" + e.getStackTrace());
			throw e;
		}
		return payeeDropdownList;
	}

	/**
	 * Method to select future date in calendar
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings({ "unused", "rawtypes" })
	public void selectFutureDate(int date) throws Exception {
		String selectedDateCalendar;
		String dom = null;
		LocalDate futureDate = null;
		DayOfWeek dow;
		String convDow = null;
		String pdom = null;
		int convPrevDom = 0;
		Month m;
		String convM = null;
		int y = 0;
		try {

			for (int i = 1; i <= 2; i++) {
				dom = LocalDate.now().toString().split("-")[2];
				futureDate = LocalDate.now().plusDays(date);
				dow = futureDate.getDayOfWeek();
				convDow = dow.name().substring(0, 1).toUpperCase() + dow.name().substring(1).toLowerCase();
				pdom = futureDate.toString().split("-")[2];
				convPrevDom = futureDate.getDayOfMonth();
				m = futureDate.getMonth();
				convM = m.name().substring(0, 1).toUpperCase() + m.name().substring(1).toLowerCase();
				y = futureDate.getYear();
				if (futureDate.getDayOfWeek() != DayOfWeek.SATURDAY && futureDate.getDayOfWeek() != DayOfWeek.SUNDAY) {
					date = date + 1;
					LogUtility.logInfo("Selected future date is on weekends");
					break;
				}
			}
			LogUtility.logInfo("Selected future date " + futureDate + " is not on weekends");

			if (TestDataConstants.getOSPlatformName().contains("android")) {
				selectedDateCalendar = paneCalendar.getText();
				if (selectedDateCalendar.equals(dom)) {
					LogUtility.logInfo("Current date is selected by default " + dom);
				} else {
					throw new Exception("Current date is not selected in calendar ");
				}
				String dynamicDateAndroid = "//android.widget.TextView[@content-desc='%s, %s %s %d']";
				/** Date format for Android //*[@contentDesc="Tuesday, June 11 2019"] **/
				LogUtility.logInfo("Next date selected is" + dynamicDateAndroid);
				WebElement prevDateSelect = appiumDriver
						.findElement(By.xpath(String.format(dynamicDateAndroid, convDow, convM, pdom, y)));
				if (mobileActions.verifyIsElementPresent(prevDateSelect, 5)) {
					prevDateSelect.click();
					LogUtility.logInfo("Clicked on selected date" + dynamicDateAndroid + " in calendar");
				} else {
					calenderNext.click();
					prevDateSelect.click();
				}
				selectedDateCalendar = paneCalendar.getText();
				if (!selectedDateCalendar.equals(pdom)) {
					throw new Exception("Future date not selected");
				}
				btnCalendarOkDone.click();
			} else {
				String dynamicDateiOS = "//*[@label='%s %d, %d']";
				/** Date format for iOS //*[@label="June 11, 2019"] **/
				WebElement futureDateSelectiOS = appiumDriver
						.findElement(By.xpath(String.format(dynamicDateiOS, convM, convPrevDom, y)));
				// futureDateSelectiOS.click();
				Point point = appiumDriver.findElement(By.xpath(String.format(dynamicDateiOS, convM, convPrevDom, y)))
						.getLocation();
				new TouchAction(appiumDriver).tap(new PointOption().withCoordinates(321, 1848)).perform();
				int convDate = Integer.parseInt(iosDeliveryDate.split("-")[1]);
				if (convDate != convPrevDom) {
					throw new Exception("Future date not selected");
				}
			}
		} catch (Exception e) {
			throw new Exception("Unable to find " + e);
		}
	}

	/**
	 * Method to verifying the pay bills title after logged in
	 * 
	 * @throws Exception
	 */
	public void verifyPayBillsPageTitle() throws Exception {
		try {
			if (mobileActions.isAlertPresent()) {
				appiumDriver.switchTo().alert().dismiss();
			}
			mobileActions.isElementPresent(titlePayBills, 5);
			LogUtility.logInfo("Pay bills Title page displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the pay bills Title " + e.getStackTrace());
			throw e;
		}
	}

	public boolean verifyPayeesInAlphabeticalOrder(List<String> listName) {
		if (!listName.isEmpty()) {
			Iterator<String> it = listName.iterator();
			String previous = it.next();
			while (it.hasNext()) {
				String next = it.next();
				if (previous.compareTo(next) > 0) {
					LogUtility.logInfo("list of payees are not displayed in alphabetical order");
					return false;
				}
				previous = next;
			}
		}
		LogUtility.logInfo("list of payees are  displayed in alphabetical order");
		return true;
	}

}
