package com.wb.wol_mobile.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import edu.emory.mathcs.backport.java.util.Collections;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

public class ExternalTransfersPage extends ObjectBase {

	public ExternalTransfersPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	MobileActions mobileActions = new MobileActions();
	RetailAppUtils retailAppUtils = new RetailAppUtils();
	TransfersPage transferPage = new TransfersPage();
	Random rd = new Random();

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Non-Webster Transfer']")
	@iOSFindBy(xpath = "//*[@label='Non-Webster Transfer']")
	protected MobileElement lblNonWebsterTransfer;

	@AndroidFindBy(xpath = "//*[@text='NON-WEBSTER TRANSFER']")
	@iOSFindBy(xpath = "//*[@label=\"NON-WEBSTER TRANSFER\"]")
	protected MobileElement txtNonWebsterTransfer;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/parallax_button_1")
	@iOSFindBy(xpath = "//*[@label=\"Account Transfer\"]")
	protected MobileElement btnTransferFunds;

	@AndroidFindBy(xpath = "//*[@text='CREATE TRANSFER']")
	@iOSFindBy(xpath = "//*[@label='CREATE TRANSFER']")
	protected MobileElement txtCreateTransfer;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/editable_rows']/android.widget.RelativeLayout[1]")
	@iOSFindBy(xpath = "//*[@name=\"A2APayFromAccountCell\" and @value=\"Transfer From\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name=\"A2APayFromAccountCell\"]")
	protected MobileElement btnFrom;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/editable_rows']/android.widget.RelativeLayout[2]")
	@iOSFindBy(xpath = "//*[@name=\"Transfer To\"]")
	@iOSFindBy(xpath = "//*[@label=\"Transfer To\" and @name=\"A2APayToAccountCell\"]")
	protected MobileElement btnTo;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/currency\"]")
	protected MobileElement txtAmount;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/frequencyEntry\"]")
	protected MobileElement txtFrequencyEntry;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/number_value\"]")
	protected MobileElement txtNoOfTransfers;

	@AndroidFindBy(xpath = "//*[@text=\"Submission Date\"]")
	protected MobileElement txtSubmissionDate;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/button_done\"]")
	protected MobileElement btnSubmit;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='CONFIRM TRANSFER']")
	protected MobileElement txtConfirmTransfer;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@class=\"android.widget.ListView\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTable", priority = 3)
	@iOSFindBy(xpath = "//*[@label='Webster Bank']/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]", priority = 2)
	@iOSFindBy(xpath = "//*[@label='Webster Bank']/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]", priority = 1)
	protected MobileElement lstViewDropDown;

	@iOSFindBy(xpath = "//*[@label='Webster Bank']/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTable[1]")
	protected MobileElement lstDropDown;

	@AndroidFindBy(xpath = "//*[@class=\"android.widget.ListView\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected List<MobileElement> lstAccountsDropDown;

	// @HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/txt_account_nickname']")
	// @iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell", priority =
	// 2)
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@name = 'IOFSelectionListTableViewCellIdentifier']", priority = 1)
	protected List<MobileElement> lstAccountsDisplayed;

	// @HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/txt_account_nickname']")
	// @iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell", priority =
	// 2)
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@name = 'IOFSelectionListTableViewCellIdentifier']", priority = 1)
	protected MobileElement lstViewAccountsDisplayed;

	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/message\"]")
	@iOSFindBy(xpath = "//*[@value=\"Error\"]")
	protected MobileElement lblErrorAlertBox;

	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/message\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Error']/following::XCUIElementTypeStaticText")
	protected MobileElement txtErrorMessage;
	
	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/message\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Error']/following::XCUIElementTypeStaticText")
	protected MobileElement txtDuplicateErrorMessage;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/options_button")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Options']")
	protected MobileElement btnOptionsMore;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/options_button")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Options']")
	protected List<MobileElement> btnOptionsMoreCount;

	@AndroidFindBy(xpath = "//*[@text=\"Cancel Transfer\"]")
	protected MobileElement btnCancelTransfer;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	protected MobileElement txtPopUpMessage;

	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/recycler_view']/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'From')]")
	protected List<MobileElement> txtTransferTitle;

	@AndroidFindBy(xpath = "//*[@resource-id=\"com.malauzai.websterbank:id/recycler_view\"]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'From')]")
	protected MobileElement txtTransferTitleDisplayed;

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/description']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'From')]")
	protected MobileElement txtDescription;

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/description']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'From')]")
	protected List<MobileElement> txtDescriptionDisplayed;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='TRANSFER DETAILS']")
	@iOSFindBy(xpath = "//*[@label=\"TRANSFER DETAILS\"]")
	protected MobileElement titleTransferDetails;

	@AndroidFindBy(xpath = "//*[@text=\"Amount\"]")
	protected MobileElement lblAmount;

	@AndroidFindBy(xpath = "//*[@text='Amount']/following-sibling::android.widget.TextView")
	protected MobileElement txtAmountValue;

	@AndroidFindBy(xpath = "//*[@text=\"From\"]")
	protected MobileElement lblFrom;

	@AndroidFindBy(xpath = "//*[@text='From']/following-sibling::android.widget.TextView")
	protected MobileElement txtFromValue;

	@AndroidFindBy(xpath = "//*[@text=\"To\"]")
	protected MobileElement lblTo;

	@AndroidFindBy(xpath = "//*[@text='To']/following-sibling::android.widget.TextView")
	protected MobileElement txtToValue;

	@AndroidFindBy(xpath = "//*[@text=\"Date\"]")
	protected MobileElement lblDate;

	@AndroidFindBy(xpath = "//*[@text='Date']/following-sibling::android.widget.TextView")
	protected MobileElement txtDateValue;

	@AndroidFindBy(xpath = "//*[@text=\"Frequency\"]")
	protected MobileElement lblFrequency;

	@AndroidFindBy(xpath = "//*[@text='Frequency']/following-sibling::android.widget.TextView")
	protected MobileElement txtFrequencyValue;

	@AndroidFindBy(xpath = "//*[@text=\"Reference Number\"]")
	protected MobileElement lblReferenceNumber;

	@AndroidFindBy(xpath = "//*[@text=\"Status\"]")
	protected MobileElement lblStatus;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Cancel']")
	protected MobileElement btnCancel;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Are you sure you want to cancel this scheduled payment?']")
	protected MobileElement txtCancelScheduledPayment;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Are you sure you want to cancel this scheduled transfer?']")
	protected MobileElement txtCancelScheduledTransfer;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Transfer scheduled successfully, transfer will occur on the selected date. Confirmation number:')]")
	protected MobileElement txtTransferSubmitted;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Button[@text='CONFIRM']")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Confirm']")
	protected MobileElement btnConfirm;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='OK']")
	protected MobileElement btnOk;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='CLOSE']")
	protected MobileElement btnClose;

	@iOSFindBy(xpath = "//XCUIElementTypeCollectionView[contains(@label,'Amount') and contains(@label,'From') and contains(@label,'To') and contains(@label,'Date') and contains(@label,'Reference Number') and contains(@label,'Status')]")
	protected MobileElement txtTransferDetailsPageElements;

	public String lstClassName = "android.widget.LinearLayout/android.widget.TextView[2]";
	public String lstClassNameIos = "//XCUIElementTypeCell/XCUIElementTypeStaticText[1]";
	public String selectAccount;
	public String accountSelected = "//*[@text='%s'] | //*[contains(@label,'%s')]";
	public String dynamicFromAndToAccountValue = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/txt_account_nickname'])[%d]";
	public String selectFrequency = "//*[@text='%s']";
	public String transfersCount;
	public String regexForAccountNumberDisplayed = "\\.{3}\\d{4}";
	public String regexForTransferDescriptionDisplayed = "From \\(\\.{3}\\d{4}\\) To \\(\\.{3}\\d{4}\\)";
	public String regexForTransactionDisplayedIos = "From \\(\\.{3}\\d{4}\\) To \\(\\.{3}\\d{4}\\), (POSTED|Scheduled), Date: ([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])), Amount:(\\$)(\\\\+|-)?([0-9]+(\\.[0-9]+))|^\\$(([1-9]\\d{0,2}(,\\d{3})*)|(([1-9]\\d*)?\\d))(\\.\\d\\d)?$";

	public void verifyNonWebsterTransferOption() throws Exception {
		try {
			mobileActions.isElementPresent(lblNonWebsterTransfer, 10);
			LogUtility.logInfo("Verified Non webster transfer option is present");
		} catch (NoSuchElementException e) {
			LogUtility.logException("verifyNonWebsterTransferOption", e, LoggingLevel.ERROR, true);
		}
	}

	public void clickNonWebsterTransferOption() throws Exception {
		verifyNonWebsterTransferOption();
		try {
			lblNonWebsterTransfer.click();
			retailAppUtils.fluentWaitElement(txtNonWebsterTransfer, 60, 2);
			LogUtility.logInfo("Clicked Non webster transfer option");
		} catch (NoSuchElementException e) {
			LogUtility.logException("clickNonWebsterTransferOption", e, LoggingLevel.ERROR, true);
		}
	}

	public void clickOnTransferFunds() throws Exception {
		mobileActions.isElementPresent(btnTransferFunds, 10);
		try {
			btnTransferFunds.click();
			mobileActions.isElementPresent(txtCreateTransfer, 20);
			LogUtility.logInfo("Clicked on Transfer Funds button");
		} catch (Exception e) {
			try {
				btnTransferFunds.click();
				mobileActions.isElementPresent(txtCreateTransfer, 20);
				LogUtility.logInfo("Clicked on Transfer Funds button");
			} catch (NoSuchElementException ex) {
				LogUtility.logException("clickOnTransferFunds", ex, LoggingLevel.ERROR, true);
			}
		}
	}

	public void verifyErrorMessageClickingTransferFunds() throws Exception {
		try {
			btnTransferFunds.click();
			LogUtility.logInfo("Clicked on Transfer Funds button");
			mobileActions.isElementPresent(lblErrorAlertBox, 6);
		} catch (Exception e) {
			try {
				btnTransferFunds.click();
				LogUtility.logInfo("Clicked on Transfer Funds button");
				mobileActions.isElementPresent(lblErrorAlertBox, 6);
			} catch (NoSuchElementException ex) {
				LogUtility.logException("clickOnTransferFunds", ex, LoggingLevel.ERROR, true);
			}
		}
	}

	public void clickOnFromDropDown() throws Exception {
		try {
			mobileActions.isElementPresent(btnFrom, 30);
			btnFrom.click();
			mobileActions.isElementPresent(lstViewDropDown, 30);
			LogUtility.logInfo("Clicked on From drop down");
		} catch (Exception e) {
			LogUtility.logException("clickOnFromDropDown", e, LoggingLevel.ERROR, true);
		}
	}

	public String clickOnAccount() throws Exception {
		waits.staticWait(2);
		if (lstAccountsDropDown.size() > 0) {
			int i = 1;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)))
					.getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
		} else {
			LogUtility.logInfo("Accounts not displayed to select");
			throw new Exception("Accounts not displayed to select");
		}
		return selectAccount;
	}

	public void clickOnAccount(String account) throws Exception {
		waits.staticWait(2);
		LogUtility.logInfo("Account to select " + account);
		appiumDriver.findElement(By.xpath(String.format(accountSelected, account, account))).click();
		LogUtility.logInfo("Account selected " + account);
	}

	public String clickOnExternalAccount() throws Exception {
		waits.staticWait(3);
		if (lstAccountsDropDown.size() > 0) {
			// External Account by default is displayed in first position
			int i = 1;
			selectAccount = appiumDriver.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)))
					.getText();
			WebElement clickOnAccount = appiumDriver
					.findElement(By.xpath(String.format(dynamicFromAndToAccountValue, i, i)));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
		} else {
			LogUtility.logInfo("External Accounts not displayed to select");
			throw new Exception("External Accounts not displayed to select");
		}
		return selectAccount;
	}

	public String clickOnInternalAccount() throws Exception {
		mobileActions.isElementPresent(lstViewAccountsDisplayed, 3);
		int numberOfAccounts = lstAccountsDisplayed.size();
		if (numberOfAccounts > 0) {
			selectAccount = appiumDriver
					.findElement(
							By.xpath(String.format(dynamicFromAndToAccountValue, numberOfAccounts, numberOfAccounts)))
					.getText();
			try {
				WebElement clickOnAccount = appiumDriver.findElement(
						By.xpath(String.format(dynamicFromAndToAccountValue, numberOfAccounts, numberOfAccounts)));
				LogUtility.logInfo("Account selected " + selectAccount);
				clickOnAccount.click();
			} catch (Exception e) {
				LogUtility.logError("Unable to click on account " + e);
				throw e;
			}
		}
		return selectAccount;
	}

	public void clickOnToDropDown() throws Exception {
		try {
			retailAppUtils.fluentWaitElement(btnTo, 60, 2);
			btnTo.click();
			mobileActions.isElementPresent(lstViewDropDown, 5);
			LogUtility.logInfo("Clicked on To drop down");
		} catch (NoSuchElementException e) {
			LogUtility.logException("clickOnToDropDown", e, LoggingLevel.ERROR, true);
		}
	}

	public void enterAmount(String amount) throws Exception {
		try {
			txtAmount.clear();
			for (int i = 0; i < amount.length(); i++) {
				char c = amount.charAt(i);
				String eachCharacter = new StringBuilder().append(c).toString();
				txtAmount.sendKeys(eachCharacter);
			}
			LogUtility.logInfo("Entered amount into amount text field");
		} catch (NoSuchElementException e) {
			LogUtility.logError("Unable to enter amount " + e);
			throw e;
		}
	}

	public void selectFrequency(String frequency) throws Exception {
		txtFrequencyEntry.click();
		mobileActions.isElementPresent(lstViewDropDown, 10);
		try {
			appiumDriver.findElement(By.xpath(String.format(selectFrequency, frequency))).click();
			LogUtility.logInfo("Clicked on frequency " + frequency);
			if (!frequency.equalsIgnoreCase("One-time")) {
				mobileActions.isElementPresent(txtNoOfTransfers, 5);
				txtNoOfTransfers.sendKeys(retailAppUtils.getRandomNumber(1));
				transfersCount = txtNoOfTransfers.getText();
				LogUtility.logInfo("Entered " + transfersCount + " number of transfers for " + frequency);
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to select frequency " + frequency + " ");
			throw e;
		}
	}

	public void selectFutureSubmissionDate() throws Exception {
		try {
			txtSubmissionDate.click();
			transferPage.selectFutureDate();
			LogUtility.logInfo("Entered Submission Date");
		} catch (Exception e) {
			LogUtility.logError("Unable to select submission date " + e);
			throw e;
		}
	}

	public void clickSubmitTransfer() throws Exception {
		try {
			btnSubmit.click();
			mobileActions.isElementPresent(txtConfirmTransfer, 10);
			LogUtility.logInfo("Clicked on submit button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on submit button " + e);
			throw e;
		}
	}

	public void clickConfirmTransfer() throws Exception {
		try {
			btnConfirm.click();
			mobileActions.isElementPresent(txtTransferSubmitted, 15);
			LogUtility.logInfo("Clicked on confirm button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on confirm button " + e);
			throw e;
		}
	}

	public void verifyExternalInternalAccountsFormat() throws Exception {
		ArrayList<MobileElement> fromAccounts;
		String getAccountNumberDisplayed;
		try {
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				fromAccounts = (ArrayList<MobileElement>) lstViewDropDown.findElementsByClassName(lstClassName);
			} else {
				fromAccounts = (ArrayList<MobileElement>) lstViewDropDown.findElementsByXPath(lstClassNameIos);
			}
			for (int i = 0; i < fromAccounts.size(); i++) {
				String accountName = fromAccounts.get(i).getText();
				LogUtility.logInfo("Accounts displayed " + accountName);
				/**
				 * Code is implemented as per the current functionality of application and not
				 * as per test case, balances are not getting displayed now and test
				 * case/functionality has to reverify
				 **/
				getAccountNumberDisplayed = accountName.substring(accountName.indexOf("(") + 1,
						accountName.indexOf(")"));
				LogUtility.logInfo(getAccountNumberDisplayed);
				boolean patternMatches = getAccountNumberDisplayed.matches(regexForAccountNumberDisplayed);
				if (patternMatches)
					LogUtility.logInfo("External and Internal accounts matches the pattern");
				else
					throw new Exception("External and Internal accounts does not match the pattern");
			}
		} catch (NoSuchElementException e) {
			LogUtility.logException("verifyExternalInternalAccountsFormat", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public ArrayList<String> getAccountsDisplayed() throws Exception {
		ArrayList<String> accounts = new ArrayList<String>();
		accounts.clear();
		ArrayList<MobileElement> fromAccounts;
		String getAccountNumberDisplayed;
		if (TestDataConstants.getOSPlatformName().equals("android")) {
			fromAccounts = (ArrayList<MobileElement>) lstViewDropDown.findElementsByClassName(lstClassName);
		} else {
			fromAccounts = (ArrayList<MobileElement>) lstViewDropDown.findElementsByXPath(lstClassNameIos);
		}
		for (int i = 0; i < fromAccounts.size(); i++) {
			String accountName = fromAccounts.get(i).getText();
			LogUtility.logInfo("Accounts displayed " + accountName);
			/**
			 * Code is implemented as per the current functionality of application and not
			 * as per test case, balances are not getting displayed now and test
			 * case/functionality has to reverify
			 **/
			getAccountNumberDisplayed = accountName.substring(accountName.indexOf("(") + 1, accountName.indexOf(")"));
			LogUtility.logInfo(getAccountNumberDisplayed);
			accounts.add(getAccountNumberDisplayed);
			boolean patternMatches = getAccountNumberDisplayed.matches(regexForAccountNumberDisplayed);
			if (patternMatches)
				LogUtility.logInfo("Account verified");
			else
				throw new Exception("Accounts displayed are not matched with the pattern");
		}
		return accounts;
	}

	public void verifyErrorMessage(String errorMessage) throws Exception {
		try {
			waits.staticWait(3);
			String errorMessageDisplayed = txtErrorMessage.getText();
			if (!errorMessageDisplayed.equals(errorMessage))
				throw new Exception();
			LogUtility.logInfo("Verified the error message as " + errorMessage);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the error message " + e);
			throw e;
		}
	}
	
	public boolean verifyDuplicateErrorMessage(String errorMessage) throws Exception {
			/* Need time to load error message */
			waits.staticWait(3);
			String errorMessageDisplayed = txtDuplicateErrorMessage.getText();
			if (!errorMessageDisplayed.equals(errorMessage))
				return false;
			else 
				LogUtility.logInfo("Verified the error message as " + errorMessage);
				return true;
	}


	public void verifyAccountsOrderExtAndInt(List<String> from, List<String> to) throws Exception {
		LogUtility.logInfo("From Accounts " + from + " To Accounts " + to);

		Collections.reverse(from);
		Collections.reverse(to);

		int getSizeOfToAccounts = to.size();
		LogUtility.logInfo("After reverse From Accounts " + from + " To Accounts " + to);

		try {
			for (int i = 0; i < getSizeOfToAccounts; i++) {
				if (!to.get(i).equals(from.get(i))) {
					LogUtility.logInfo("Account Order verified");
				}
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean verifyExternalTransfersHistory() throws Exception {
		Boolean value = true;
		try {
			mobileActions.isElementPresent(btnOptionsMore, 30);
			int titles = txtTransferTitle.size();
			for (int i = 0; i < titles; i++) {
				String titleDisplayed = txtTransferTitle.get(i).getText();
				LogUtility.logInfo(titleDisplayed);
				if (TestDataConstants.getOSPlatformName().equals("android")) {
					if (!titleDisplayed.matches(regexForTransferDescriptionDisplayed)) {
						LogUtility.logInfo("Title description did not matched with the history displayed in android");
						value = false;
						break;
					}
				} else {
					if (!titleDisplayed.matches(regexForTransactionDisplayedIos)) {
						LogUtility.logInfo("Title description did not matched with the history displayed in iOS");
						value = false;
						break;
					}
				}
			}
			LogUtility.logInfo(
					"Transfer title descriptions matched with the given format like From (...1234) To (...1234)");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the external transfers history " + e);
			throw e;
		}
		return value;
	}

	public void clickOnTransfer(String status) throws Exception {
		mobileActions.isElementPresent(btnOptionsMore, 30);
		int titles = txtTransferTitle.size();
		try {
			for (int i = 0; i < titles; i++) {
				String statusDisplayed = txtDescriptionDisplayed.get(i).getText();
				LogUtility.logInfo(statusDisplayed);
				if (TestDataConstants.getOSPlatformName().equals("android")) {
					if (statusDisplayed.equals(status)) {
						waits.staticWait(3);
						txtDescriptionDisplayed.get(i).click();
						LogUtility.logInfo("Clicked on " + status + " transfer in android");
						break;
					}
				} else {
					if (statusDisplayed.matches("From \\(\\.{3}\\d{4}\\) To \\(\\.{3}\\d{4}\\), " + status
							+ ", Date: ([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])), "
							+ "Amount:(\\$)(\\\\+|-)?([0-9]+(\\.[0-9]+))|^\\$(([1-9]\\d{0,2}(,\\d{3})*)|(([1-9]\\d*)?\\d))(\\.\\d\\d)?$")) {
						txtDescriptionDisplayed.get(i).click();
						LogUtility.logInfo("Clicked on " + status + " transfer in iOS");
						break;
					}
				}
			}
			mobileActions.isElementPresent(titleTransferDetails, 10);
			LogUtility.logInfo("Clicked on " + status + " and navigated to transfer details page");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on " + status + " transfer " + e);
			throw e;
		}
	}

	public void verifyTransferDetailsPage() throws Exception {
		try {
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				List<RemoteWebElement> transferDetailsPage = Arrays.asList(lblAmount, lblFrom, lblTo, lblDate,
						lblReferenceNumber, lblStatus);
				mobileActions.elementsPresent(transferDetailsPage);
			} else {
				mobileActions.isElementPresent(txtTransferDetailsPageElements, 10);
			}
			LogUtility.logInfo("Verified the Transfer Details Page");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the details of transfer page");
			throw e;
		}
	}

	public void verifyScheduledTransferDetailsPage() throws Exception {
		try {
			List<RemoteWebElement> transferDetailsPage = Arrays.asList(lblAmount, lblFrom, lblTo, lblDate,
					lblReferenceNumber);
			mobileActions.elementsPresent(transferDetailsPage);
			LogUtility.logInfo("Verified the Transfer Details Page");
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the details of transfer page");
			throw e;
		}
	}

	public void verifyTransferDisplayed(String status) throws Exception {
		mobileActions.isElementPresent(btnOptionsMore, 30);
		int statusCount = txtDescriptionDisplayed.size();

		for (int i = 0; i < statusCount; i++) {
			String statusDisplayed = txtDescriptionDisplayed.get(i).getText();
			LogUtility.logInfo(statusDisplayed);
			if (TestDataConstants.getOSPlatformName().equals("android")) {
				if (statusDisplayed.equals(status)) {
					LogUtility.logInfo("Verified " + status + " transfer in android");
					break;
				} else if (i == statusCount - 1) {
					LogUtility.logInfo("Scheduled transfer is not found hence creating it ");
					btnTransferFunds.click();
					mobileActions.isElementPresent(txtCreateTransfer, 5);
					clickOnFromDropDown();
					clickOnExternalAccount();
					clickOnToDropDown();
					clickOnInternalAccount();
					enterAmount(retailAppUtils.getRandomNumber(2));
					selectFutureSubmissionDate();
					clickSubmitTransfer();
					clickConfirmTransfer();
					LogUtility.logInfo("Scheduled a new transfer");
				}
			} else {
				if (statusDisplayed.matches("From \\(\\.{3}\\d{4}\\) To \\(\\.{3}\\d{4}\\), " + status
						+ ", Date: ([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])), "
						+ "Amount:(\\$)(\\\\+|-)?([0-9]+(\\.[0-9]+))|^\\$(([1-9]\\d{0,2}(,\\d{3})*)|(([1-9]\\d*)?\\d))(\\.\\d\\d)?$")) {
					LogUtility.logInfo("Verified " + status + " transfer in iOS");
					break;
				}
			}
		}
	}

	public void scheduledTransferExternalInternal() throws Exception {
		LogUtility.logInfo("Scheduling transfer between External to Internal account ");
		clickOnFromDropDown();
		clickOnExternalAccount();
		clickOnToDropDown();
		clickOnInternalAccount();
		enterAmount(retailAppUtils.getRandomNumber(2));
		selectFutureSubmissionDate();
		clickSubmitTransfer();
		clickConfirmTransfer();
		LogUtility.logInfo("Scheduled transfer between External to Internal account");
	}

	public void scheduledTransferInternalExternal() throws Exception {
		LogUtility.logInfo("Scheduling transfer between Internal to External account ");
		clickOnFromDropDown();
		clickOnInternalAccount();
		clickOnToDropDown();
		clickOnExternalAccount();
		enterAmount(retailAppUtils.getRandomNumber(2));
		selectFutureSubmissionDate();
		clickSubmitTransfer();
		clickConfirmTransfer();
		LogUtility.logInfo("Scheduled transfer between Internal to External account");
	}

	public void clickCancelTransfer() throws Exception {
		try {
			btnCancel.click();
			mobileActions.isElementPresent(txtCancelScheduledPayment, 10);
			LogUtility.logInfo("Clicked on Cancel button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on cancel button " + e);
			throw e;
		}
	}

	public void clickOnConfirm() throws Exception {
		try {
			btnConfirm.click();
			LogUtility.logInfo("Clicked on confirm button");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on confirm button " + e);
			throw e;
		}
	}

	public void clickOnMoreOptions(String status) throws Exception {
		mobileActions.isElementPresent(btnOptionsMore, 30);
		int statusCount = txtDescriptionDisplayed.size();
		try {
			for (int i = 0; i < statusCount; i++) {
				String statusDisplayed = txtDescriptionDisplayed.get(i).getText();
				LogUtility.logInfo("Transaction status displayed " + statusDisplayed);
				if (TestDataConstants.getOSPlatformName().equals("android")) {
					if (statusDisplayed.equals(status)) {
						btnOptionsMoreCount.get(i).click();
						LogUtility.logInfo("Clicked on " + status + " options menu in android");
						break;
					}
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to click on " + status + " option menu " + e);
			throw e;
		}
	}

	public void clickOnCancelTranferMenu() throws Exception {
		try {
			btnCancelTransfer.click();
			mobileActions.isElementPresent(txtCancelScheduledTransfer, 10);
			LogUtility.logInfo("Clicked on Cancel Transfer option in Menu");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Cancel Transfer option in menu options " + e);
			throw e;
		}
	}

	public boolean verifyPopUpDisplayed(String message) {
		try {
			retailAppUtils.fluentWaitElement(txtPopUpMessage, 10, 1);
			String popUpMessage = txtPopUpMessage.getText();
			if (popUpMessage.equals(message)) {
				LogUtility.logInfo("Verified the popup message displayed " + message + " ");
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the pop up message displayed as " + message + " " + e);
			throw e;
		}
	}

	public boolean verifySubmittedDetails(String amount, String from, String to, String frequency) throws Exception {
		try {
			mobileActions.verifyTextValuePresent(txtAmountValue, amount);
			mobileActions.verifyTextValuePresent(txtFromValue, from);
			mobileActions.verifyTextValuePresent(txtToValue, to);
			mobileActions.verifyTextValuePresent(txtFrequencyValue, frequency);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the create transfer submitted data " + e);
			throw e;
		}
		return true;
	}

}
