package com.wb.wol_mobile.pages;

import java.util.Random;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.openqa.selenium.WebElement;
import static com.wb.wol_mobile.utilities.TestDataConstants.*;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

@SuppressWarnings("deprecation")
public class CommonPage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	public String pageTitle = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/title'] | //XCUIElementTypeNavigationBar/XCUIElementTypeStaticText[1]";

	public CommonPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	@AndroidFindBy(id = "com.android.systemui:id/notification_panel")
	private List<RemoteWebElement> notificationPanel;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='CLEAR']")
	private MobileElement clearAllBtn;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[@content-desc=\"Open navigation drawer\"]")
	@AndroidFindBy(xpath = "//*[@content-desc='Menu']")
	@iOSFindBy(xpath = "//*[@label=\"menu\"]")
	protected MobileElement btnHamburger;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
	@iOSFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeStaticText")
	protected MobileElement txtErrorMessage;

	private String verifyAccountExists = "//android.widget.TextView[contains(@text,'%d')] | //*[contains(@label,'%d')] | //android.widget.CheckedTextView[contains(@text,'%d')]";
	public String dynamicXpathText = "//android.widget.TextView[contains(@text,'%s')]";

	public void navigateToPage(String title) throws Exception {
		try {
			for (int i = 1; i <= 5; i++) {
				String pagePresent = appiumDriver.findElement(By.xpath(pageTitle)).getText();
				LogUtility.logInfo(pagePresent);
				if (!pagePresent.equalsIgnoreCase(title))
					appiumDriver.navigate().back();
				else
					break;
			}
		} catch (NoSuchElementException e) {
			throw e;
		}
	}

	public void navigateToHamburger() throws Exception {
		try {
			for (int i = 1; i <= 6; i++) {
				if (mobileActions.verifyIsElementPresent(btnHamburger, 5))
					break;
				else
					appiumDriver.navigate().back();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void clickOnHamburger() throws Exception {
		navigateToHamburger();
		try {
			btnHamburger.click();
		} catch (NoSuchElementException e) {
			throw new Exception("Unable to find the hamburger " + e);
		}
	}

	public boolean isNativeNotificationPage() {
		return !notificationPanel.isEmpty();
	}

	public boolean isClearAllBtnLoaded() {
		return !mobileActions.verifyIsElementPresent(clearAllBtn, 5);
	}

	public void tapClearAllBtn() {
		clearAllBtn.click();
	}

	public boolean openNotifications() {
		androidDriver.openNotifications();
		return isNativeNotificationPage();
	}

	public void clearNotifications() {
		androidDriver.openNotifications();
		Assert.assertTrue(isNativeNotificationPage(), "Native notification page is NOT loaded");
		if (mobileActions.isElementDisplayed(clearAllBtn, 5)) {
			if (clearAllBtn.isEnabled()) {
				tapClearAllBtn();
			} else {
				((androidDriver)).pressKeyCode(AndroidKeyCode.BACK);
				waits.staticWait(5);
			}
		}
	}

	/**
	 * Method to clickOnAccount
	 * 
	 * @param accountName
	 * @throws Exception
	 */
	public void clickAccount(String accountName) throws Exception {
		try {
			appiumDriver.findElement(By.xpath(verifyAccountExists.replace("%d", accountName))).click();
			LogUtility.logInfo("Clicked on account "+accountName );
		} catch (Exception e) {
			LogUtility.logError("Unable to click on account " + accountName);
			throw e;
		}
	}
	
	public void verifyErrorMessageDisplayed(String errorMessage) throws Exception {
		mobileActions.isElementPresent(txtErrorMessage, 5);
		try {
			String errorDisplayed = txtErrorMessage.getText();
			Assert.assertEquals(errorDisplayed, errorMessage);
			LogUtility.logInfo("Error message displayed as " + errorDisplayed);
		} catch (NoSuchElementException e) {
			LogUtility.logException("verifyErrorMessageDisplayed", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public WebElement verifyElementTextPresent(String value) {
		WebElement elementPresent = appiumDriver.findElement(By.xpath(String.format(dynamicXpathText, value)));
		return elementPresent;
	}

	public String getRandomString() throws Exception {
		try {
			String alphaChar = DYNAMIC_APLHACHARACTERS;
			StringBuilder build = new StringBuilder();
			Random random = new Random();
			while (build.length() < 8) { // length of the random string.
				int index = (int) (random.nextFloat() * alphaChar.length());
				build.append(alphaChar.charAt(index));
			}
			String randomString = build.toString();
			LogUtility.logInfo("Generated string is" + randomString);
			return randomString;
		} catch (Exception e) {
			LogUtility.logError("--->unable to generate randomstring <---", e.getMessage());
			throw e;
		}
	}

}
