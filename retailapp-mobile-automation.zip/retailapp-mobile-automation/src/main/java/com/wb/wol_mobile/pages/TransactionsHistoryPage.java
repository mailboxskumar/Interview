package com.wb.wol_mobile.pages;

import static com.wb.wol_mobile.utilities.TestDataConstants.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author MPrasanth-adm
 *
 */
public class TransactionsHistoryPage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	ManageAlertsPage manageAlertsPage = new ManageAlertsPage();

	public TransactionsHistoryPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	public TransactionsHistoryPage(AppiumDriver<RemoteWebElement> customDriver) {
		PageFactory.initElements(new AppiumFieldDecorator(customDriver), this);
	}

	@iOSFindBy(xpath = "//XCUIElementTypeOther[2]//following-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstPreferences;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/filter_button")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Filter']")
	protected MobileElement btnFilter;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_auxmenu")
	@iOSFindBy(xpath = "//*[@label='Auxiliary Menu']")
	protected MobileElement btnAux;

	// preferences Menu locators
	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[text()=\"Preferences\"]")
	@iOSFindBy(xpath = "//*[@label=\"MENU\"]")
	@iOSFindBy(xpath = "//*[@label=\"Create a Payment\"]")
	protected MobileElement btnBack;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Set Start Page']")
	@iOSFindBy(xpath = "//*[@label=\"Set Start Page\"]")
	protected MobileElement btnSetStartPage;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Change Account Order']")
	@iOSFindBy(xpath = "//*[@label=\"Change Account Order\"]")
	protected MobileElement btnChangeAccountOrder;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Login Type']")
	protected MobileElement btnLoginType;

	@iOSFindBy(xpath = "//*[@value=\"Touch ID\"]")
	protected MobileElement btnTouchID;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'PREFERENCES']")
	protected MobileElement txtPreferences;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Enable Passcode Login']")
	@AndroidFindBy(xpath = "//*[text()=\"Enable Passcode Login\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Passcode Login']")
	protected MobileElement btnPassCodeLogin;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label=\"MENU\"]")
	protected MobileElement titleMenu;

	@AndroidFindBy(xpath = "//*[@text='Preferences']")
	@iOSFindBy(xpath = "//*[@label=\"Preferences\"]")
	protected MobileElement btnPreference;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Account Preferences']")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	protected MobileElement txtAccountPreferences;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_number_label")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Acct#']")
	protected MobileElement lblAccount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/transaction_date_label")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Date']")
	protected MobileElement lblDate;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/transaction_description_label")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Desc']")
	protected MobileElement lblDescription;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/transaction_type_label")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Type']")
	protected MobileElement lblType;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Reference#']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Reference#']")
	protected MobileElement lblReference;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Status']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Status']")
	protected MobileElement lblStatus;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/transaction_amount_label")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Amount']")
	protected MobileElement lblAmount;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Preference Saved Successfully']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Preference Removed Successfully']")
	protected MobileElement txtPreferenceMsg;

	// change account order mobile elements
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Change Account Order']")
	@iOSFindBy(xpath = "//*[@label='Change Account Order']")
	protected MobileElement btnChangeAccountOrderButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Change Account Order']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Change Account Order']")
	protected MobileElement txtChangeAccountOrderHead;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_accept")
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'SAVE' and @clickable='true']")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	protected MobileElement btnSave;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id, 'com.malauzai.websterbank')]")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	protected List<RemoteWebElement> lblListOfAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/accounts")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	protected MobileElement lblDisplayedAccounts;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Close']")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_cancel")
	@AndroidFindBy(xpath = "//android.widget.Button[@text = 'CLOSE']")
	protected MobileElement btnAccountClose;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_accept")
	protected MobileElement btnSetStartSave;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_drag_item")
	@iOSFindBy(xpath = "//*[@label=\"Change Account Order\"]")
	protected MobileElement btnDrag;

	@AndroidFindBy(xpath = "//android.widget.CheckBox[@text = 'Hide Account']")
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch[@name = 'Hide Account']")
	protected MobileElement lblHiddenAccount;

	@AndroidFindBy(id = "android:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Account Preferences (...2602)']")
	protected MobileElement lblAccountPreferencePopup;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/value")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField")
	protected MobileElement lblNameField;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/save")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Submit']")
	protected MobileElement btnSaveButton;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/save")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Close']")
	protected MobileElement btnCloseButton;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/hide_account")
	@iOSFindBy(xpath = "//XCUIElementTypeSwitch[@label = 'Hide Account']")
	protected MobileElement btnCheckHideAccount;

	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Unable to hide primary account']")
	protected MobileElement lblPopUpPrimaryError;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'OK']")
	protected MobileElement btnPopupOk;

	@iOSFindBy(xpath = "//XCUIElementTypeCell[2]/XCUIElementTypeStaticText[2]")
	protected MobileElement txtVerification;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Nickname']")
	protected MobileElement btnNickName;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'CANCEL']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Set Start Page']")
	protected List<RemoteWebElement> btnSetStartPageCancelButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Set Start Page']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Set Start Page']")
	protected MobileElement lblSetStartPageButton;

	@AndroidFindBy(xpath = "//android.widget.CheckedTextView[@text = 'Pay Bills']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Pay Bills']")
	protected MobileElement lblPayBills;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Most Frequently Visited']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Most Frequently Visited']")
	protected MobileElement lblMostFrequentlyVisited;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Last Visited']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Last Visited']")
	protected MobileElement lblLastVisited;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'View Accounts']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'View Accounts']")
	protected MobileElement lblViewAccounts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Deposit Checks']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Deposit Checks']")
	protected MobileElement lblDepositChecks;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Transfer Funds']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Transfer Funds']")
	protected MobileElement lblTransferFunds;

	// HideAccount
	@AndroidFindBy(id = "android:id/message")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Unable to hide primary account']")
	protected MobileElement lblHideAccountErrorHead;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Done']")
	protected MobileElement btnDone;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='Apply']")
	protected MobileElement btnApply;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/snackbar_text")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Invalid filter criteria: Please, select a higher ‘To’ amount']")
	protected MobileElement lblAmountErrorMsg;

	@iOSFindBy(xpath = "//*[@label = 'OK']")
	protected MobileElement btnOk;

	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.malauzai.websterbank:id/txt_value']")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name = 'filterAmountFieldFromAccessibilityIdentifier']")
	protected MobileElement lblAmountFromField;

	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id='com.malauzai.websterbank:id/grp_amount_hi']/android.widget.EditText")
	@iOSFindBy(xpath = "//XCUIElementTypeTextField[@name = 'filterAmountFieldToAccessibilityIdentifier']")
	protected MobileElement lblAmountToField;

	@AndroidFindBy(id = "//com.malauzai.websterbank:id/btn_checkbox_or_switch")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']/following-sibling::XCUIElementTypeSwitch[@value='1']")
	protected MobileElement btnAmountRangeOn;

	@AndroidFindBy(id = "//com.malauzai.websterbank:id/btn_checkbox_or_switch")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount Range']/following-sibling::XCUIElementTypeSwitch[@value='0']")
	protected MobileElement btnAmountRangeOff;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/preceding-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstAccountOrder;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/preceding-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> accountsListedCount;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE, androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name']")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[5]/XCUIElementTypeStaticText[4]")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[2]/XCUIElementTypeStaticText[2]")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/contentPanel")
	protected MobileElement primaryAccount;

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name']")
	protected List<RemoteWebElement> lstAccountName;

	ArrayList<String> listOfAccounts;
	boolean verified = false;

	public String accountTitle = "com.malauzai.websterbank:id/grp_content";
	public String accountSubTitle = "com.malauzai.websterbank:id/grp_title";
	public String amountRangeButton = "com.malauzai.websterbank:id/btn_checkbox_or_switch";

	public String dynamicXpathAccount = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";

	public String dynamicXpathAccountButton = "//XCUIElementTypeCell[%d]/XCUIElementTypeButton[1]";

	public String accountNameId = "com.malauzai.websterbank:id/account_name";
	public String accountNameXpath = "//XCUIElementTypeStaticText[1]";
	public String dragElementId = "com.malauzai.websterbank:id/btn_drag_item";
	public String dragElementXpath = "//XCUIElementTypeButton[1]";
	public String dynamicXpathiOS = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[%d]";
	public String checkBoxText = "android.widget.CheckedTextView |" + "//XCUIElementTypeStaticText[1]";
	public String setStartText = "//XCUIElementTypeStaticText[2]";
	public String dragToTopXpath = "//*[@resource-id='com.malauzai.websterbank:id/accounts']/android.widget.RelativeLayout[1]/android.widget.ImageView[1]";
	public String dragAccountDynamicXpath = "//*[@resource-id='com.malauzai.websterbank:id/accounts']/android.widget.RelativeLayout[%d]/android.widget.ImageView[1]";
	public String accountName = "//XCUIElementTypeCell[1]/XCUIElementTypeStaticText[2]";
	public String getAccountName = "//XCUIElementTypeTable/XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1]";
	public String dragButtonFirst = "//XCUIElementTypeCell[1]/XCUIElementTypeButton[1]";
	public String dragButtonLast = "//XCUIElementTypeCell[%d]/XCUIElementTypeButton[1]";
	int count;
	List<RemoteWebElement> numberTextFieldsElements = new ArrayList<RemoteWebElement>();
	SoftAssert softAssert = new SoftAssert();

	public String startPageText = null;

	/**
	 * Method to click on Change Account Order
	 * 
	 * @throws Exception
	 * 
	 */
	public void clickOnChangeAccountOrder() throws Exception {
		try {
			mobileActions.isElementPresent(btnChangeAccountOrderButton, 5);
			btnChangeAccountOrderButton.click();
			LogUtility.logInfo("user clicked on change account order button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click changeAccountOrderButton<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify Menu head
	 * 
	 * @return
	 */
	public boolean verifyMenuHead() {
		try {
			if (mobileActions.verifyIsElementPresent(titleMenu, 5)) {
				LogUtility.logInfo("Menu head text is" + titleMenu.getText());
				return true;
			} else {
				LogUtility.logInfo("--->Unable verify the text<---");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable verify the text<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on settings button
	 * 
	 * @throws Exception
	 * 
	 */
	public void clickSettingButton() throws Exception {
		try {
			/**
			 * Provided below line of code in times of alert handle when service is down
			 **/
			// btnPopUpOk.click();
			mobileActions.isElementPresent(btnAux, 5);
			btnAux.click();
			LogUtility.logInfo("user tried to click on aux button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to clickon aux button<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Preference button
	 * 
	 */
	public void clickOnPreferenceButton() {
		try {
			btnPreference.click();
			LogUtility.logInfo("user tried to click on the preference button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to clickon preference button<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Back button
	 * 
	 */
	public void clickOnBackButton() {
		try {
			appiumDriver.navigate().back();
			LogUtility.logInfo("user  clicked on BACK button in android device");
		} catch (Exception e) {
			if (mobileActions.verifyIsElementPresent(btnBack, 5))
				btnBack.click();
			LogUtility.logInfo("user clicked on BACK button in ios device");
		}
	}

	/**
	 * Method to verify text present
	 * 
	 * @param data
	 * @throws Exception
	 */
	public boolean verifyTextValuePresent(MobileElement element, String value) throws Exception {
		boolean textStatus = false;
		try {
			String textPresent = element.getText();
			if (textPresent.contains(value)) {
				LogUtility.logInfo(value + " is present on the screen");
				textStatus = true;
			} else {
				LogUtility.logInfo(value + " is not present on the screen");
				textStatus = false;
			}
			return textStatus;
		} catch (Exception e) {
			LogUtility.logError("--->Few of the elements on page are not found<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify on Preference page
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyPreferencesPage(String preferencesText, String changeAccountText, String setStartPageText,
			String loginType, String touchIDText, String passcodeLoginText) throws Exception {
		try {
			softAssert.assertTrue(verifyTextValuePresent(txtPreferences, preferencesText),
					"expected text is preference text is not displayed");
			softAssert.assertTrue(verifyTextValuePresent(btnSetStartPage, setStartPageText),
					"expected text is set startpage text is not displayed");
			softAssert.assertTrue(verifyTextValuePresent(btnChangeAccountOrder, changeAccountText),
					"expected text is change account text is not displayed");
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				softAssert.assertTrue(verifyTextValuePresent(btnLoginType, loginType),
						"expected text is loginType text is not displayed");
			}
			softAssert.assertTrue(verifyTextValuePresent(btnPassCodeLogin, passcodeLoginText),
					"expected text is passcodeLogin Text  is not displayed");
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				softAssert.assertTrue(verifyTextValuePresent(btnTouchID, touchIDText),
						"expected text is TouchID text is not displayed");
			}
			softAssert.assertAll();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify preferences page<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify list of accounts displayed in change account order
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean listOfAccountsDisplayed() throws Exception {
		try {
			LogUtility.logInfo("Account order text is :" + txtChangeAccountOrderHead.getText());
			mobileActions.isElementPresent(txtChangeAccountOrderHead, 5);
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				// while getting the list of accounts accounts are displaying from 1 so here i
				// was using 1th element
				for (int i = 1; i <= lblListOfAccounts.size(); i++) {
					String list = appiumDriver.findElement(By.xpath(String.format(dynamicXpathAccount, i, i)))
							.getText();
					LogUtility.logInfo("name of the accounts displayed is :" + list);
				}
				LogUtility.logInfo("Verified all accouns displayed");
				btnAccountClose.isEnabled();
				verified = true;
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				// while getting the list of accounts accounts are displaying from 1 so here i
				// was using 1th element
				for (int i = 1; i > lblListOfAccounts.size(); i++) {
					String ele = appiumDriver.findElement(By.xpath(String.format(dynamicXpathAccount, i, i))).getText();
					LogUtility.logInfo("name of the accounts displayed is :" + ele);
					RemoteWebElement button = appiumDriver
							.findElement(By.xpath(String.format(dynamicXpathAccountButton, i)));
					if (button.isEnabled()) {
						continue;
					} else {
						break;
					}
				}
				verified = true;
			}
			return verified;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify list of accounts displayed " + e);
			throw e;
		}
	}

	/**
	 * Method to drag and drop the account to change the priority order
	 * 
	 * @throws Exception
	 * 
	 */
	@SuppressWarnings("unused")
	public void setToChangeAccountOrder() throws Exception {
		try {
			listOfAccounts = new ArrayList<String>();
			WebElement startX = null;
			WebElement endX = null;
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				for (RemoteWebElement liElement : lstAccountOrder) {
					WebElement accountName = liElement.findElement(By.id(accountNameId));
					LogUtility.logInfo("account name is" + accountName.getText());
					listOfAccounts.add(accountName.getText());
				}
				endX = lstAccountOrder.get(0).findElement(By.id(dragElementId));
				startX = lstAccountOrder.get(lstAccountOrder.size() - 1).findElement(By.id(dragElementId));
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				// To get the accounts displayed need static wait here mandatory
				waits.staticWait(3);
				for (RemoteWebElement liElement : lstAccountOrder) {
					WebElement accountName = liElement.findElement(By.xpath(accountNameXpath));
					LogUtility.logInfo("account name is" + accountName.getText());
					listOfAccounts.add(accountName.getText());
					endX = lstAccountOrder.get(0).findElement(By.xpath(dragElementXpath));
					startX = lstAccountOrder.get(lstAccountOrder.size() - 1).findElement(By.xpath(dragElementXpath));
				}
			}
			mobileActions.dragAndDrop(startX, endX);
			LogUtility.logInfo("user able to hold the account and dropped");
			btnSave.click();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to set the change order<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify changeAccountOrder is changed
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyChangeAccountOrder() throws Exception {
		try {
			mobileActions.scrollDown();
			String firstAccount = lstAccountOrder.get(0).findElement(By.id(accountNameXpath)).getText();
			LogUtility.logInfo("First Account Name is :" + firstAccount);
			String lastAccount = lstAccountOrder.get(lstAccountOrder.size() - 1).findElement(By.id(accountNameXpath))
					.getText();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				if (accountsListedCount.get(0).getText().contains(lastAccount)) {
					LogUtility.logInfo("account order is successsfully changed");
					return verified;
				} else {
					LogUtility.logInfo("Unable to change account order");
					verified = true;
				}
			} else if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("iOS")) {
				if (accountsListedCount.get(0).findElement(By.xpath(accountNameXpath)).getText()
						.contains(lastAccount)) {
					LogUtility.logInfo("account order is successsfully changed");
					return verified;
				} else {
					LogUtility.logInfo("Unable to change account order");
					verified = true;
				}
			}
			return verified;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify Change account order  " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Account order close button
	 * 
	 * @throws Exception
	 * 
	 * @void
	 */
	public void clickAccountOrderCloseButton() throws Exception {
		try {
			mobileActions.isElementPresent(btnAccountClose, 10);
			btnAccountClose.click();
			LogUtility.logInfo("user  clicked on Account Close button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click AccountOrder CloseButton<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Click on Startpage cancel button
	 * 
	 * @throws Exception
	 * 
	 * @void
	 */
	public void clickStartPageCancelButton() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				btnAccountClose.click();
				LogUtility.logInfo("user clicked on Account Cancel button in android device");
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				mobileActions.isElementPresent(lblSetStartPageButton, 4);
				lblSetStartPageButton.click();
				LogUtility.logInfo("user clicked on Accounts Close button in ios Device");
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click cancel button<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to Click on SetStartpage button
	 * 
	 * @void
	 */
	public void clickOnSetStartPageButton() {
		try {
			lblSetStartPageButton.click();
			LogUtility.logInfo("---->Clicked on Set start Page Button<----");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on SetStartPageButton:" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify the list of label displayed on set start page
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyListOfLabelsDisplayed() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblPayBills, 11)) {
				numberTextFieldsElements.addAll(Arrays.asList(lblMostFrequentlyVisited, lblLastVisited, lblViewAccounts,
						lblDepositChecks, lblTransferFunds));
				mobileActions.elementsPresent(numberTextFieldsElements);
				LogUtility.logInfo(" verified all the labels are displayed when click on set start page");
				return true;
			} else {
				LogUtility.logInfo("Unable to verify all are displayed when click on set start page");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify list of labels displayed " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify AccountsDisplayed Under Hidden Accounts
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAccountsDisplayedUnderHiddenAccounts() throws Exception {
		try {
			listOfAccounts = new ArrayList<String>();
			if (mobileActions.verifyIsElementPresent(lblHiddenAccount, 6)) {
				LogUtility.logInfo("Hidden accounts head text displayed as : " + lblHiddenAccount.getText());
				/** Expected accounts are displayed from 5th index value **/
				for (int i = 5; i <= 6; i++) {
					for (int j = 1; j <= 3; j++) {
						String accountName = appiumDriver.findElement(By.xpath(String.format(dynamicXpathiOS, i, j)))
								.getText();
						LogUtility.logInfo(" Account info : " + accountName);
						listOfAccounts.add(accountName);
					}
				}
				int value = listOfAccounts.size();
				if (manageAlertsPage.getCountOfAccounts() != value) {
					LogUtility.logInfo("Verification of accounts under HiddenAccounts");
					verified = true;
				} else {
					return verified;
				}
			}
			return verified;
		} catch (Exception e) {
			throw new Exception("Unable to verify Accounts Displayed under Hidden Accounts " + e);
		}
	}

	/**
	 * 
	 * Method to click on Primary Account
	 */
	public void clickOnPrimaryAccount(String value) {
		try {
			mobileActions.isElementPresent(primaryAccount, 10);
			String accountNametxt = primaryAccount.getText();
			if (accountNametxt.equals(value)) {
				primaryAccount.click();
				LogUtility.logInfo("Clicked on PrimaryAccount" + accountNametxt);
			} else {
				LogUtility.logInfo("Unabled to Clicked on PrimaryAccount" + accountNametxt);
			}
		} catch (Exception e) {
			LogUtility.logError("-->Unable to Clicked on Primary Account:<--" + e);
		}
	}

	/**
	 * Method to click on Hide Account
	 * 
	 */
	public void clickOnHideAccount(String status) {
		try {
			String hideAccount = null;
			hideAccount = lblHiddenAccount.getAttribute("checked");
			if (status.equals(hideAccount)) {
				lblHiddenAccount.click();
				btnSaveButton.click();
				LogUtility.logInfo("Successfully enabled/clicked to Hide the account");
			} else if (!status.equals(hideAccount)) {
				lblHiddenAccount.click();
				btnSaveButton.click();
				LogUtility.logInfo("Successfully clicked to UnHide the account");
			}
		} catch (Exception e) {
			LogUtility.logError("-->Unable to Clicked on Hidden Account:<--" + e.getStackTrace());
		}
	}

	/**
	 * Method to verify Account Preferences
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyAccountPreferences() throws Exception {
		try {
			LogUtility.logInfo("Verification of accounts preferences page with hideaccounts");
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				numberTextFieldsElements.addAll(
						Arrays.asList(lblAccountPreferencePopup, lblNameField, btnSaveButton, btnCheckHideAccount));
				mobileActions.elementsPresent(numberTextFieldsElements);
				verified = true;
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				mobileActions.isElementPresent(btnCheckHideAccount, 5);
				LogUtility.logInfo("Clicked on NickName tab");
				btnNickName.click();
				if (mobileActions.verifyIsElementPresent(btnSaveButton, 5)) {
					numberTextFieldsElements.addAll(Arrays.asList(lblNameField, btnSaveButton));
					mobileActions.elementsPresent(numberTextFieldsElements);
					btnCloseButton.click();
					verified = true;
				}
			}
			return verified;
		} catch (Exception e) {
			LogUtility.logError("Unable to verify AccountPreferences " + e);
			throw e;
		}
	}

	/**
	 * Method to verify the transaction details
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyTransactionsDetails() throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblReference, 15)) {
				numberTextFieldsElements
						.addAll(Arrays.asList(lblDescription, lblType, lblReference, lblDate, lblAmount));
				mobileActions.elementsPresent(numberTextFieldsElements);
				LogUtility.logInfo("all transactions details are displayed");
				return true;
			} else {
				LogUtility.logInfo("Unable to verify all transactions details are displayed");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify transaction details :" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click On Filter Button
	 * 
	 */
	public void clickOnFilterButton() {
		try {
			btnFilter.click();
			LogUtility.logInfo("---->Clicked on Filter Button<----");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on Filter Button:" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify HideAccount Error Message
	 * 
	 * @param errormsg
	 * @return
	 * @throws Exception
	 */
	public boolean verifyHideAccountErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblHideAccountErrorHead, 11)) {
				LogUtility.logInfo("---->HideAccountError Text is<----" + lblHideAccountErrorHead.getText());
				return errorMessage.equalsIgnoreCase(lblHideAccountErrorHead.getText());
			} else {
				LogUtility.logError("Unable to verify account errror head");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Accounts Error Message" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * 
	 * Method to click on the Transfer Funds Check box
	 */
	public void clickOnCheckBox(String selectValue) {
		try {
			List<String> accts = new ArrayList<String>();
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				List<MobileElement> checkList = primaryAccount.findElements(By.className(checkBoxText));
				for (WebElement list : checkList) {
					if (list.getText().contains(selectValue)) {
						list.click();
						LogUtility.logInfo("---->Clicked on " + selectValue + " Button<----");
						break;
					}
				}
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				LogUtility.logInfo("---->Displayed module is<----" + primaryAccount.getText());
				LogUtility.logInfo("---->size of preferences module is <----" + lstPreferences.size());
				for (int i = 0; i <= 6; i++) {
					startPageText = lstPreferences.get(0).findElement(By.xpath(setStartText)).getText();
					accts.add(startPageText);
					if (startPageText.contains(selectValue)) {
						lstPreferences.get(0).click();
						LogUtility.logInfo("---->Clicked on " + selectValue + " Button<----");
						break;
					}
					if (i > 0) {
						startPageText = lstPreferences.get(i).findElement(By.xpath(setStartText)).getText();
						accts.add(startPageText);
						if (startPageText.contains(selectValue)) {
							lstPreferences.get(i).click();
							LogUtility.logInfo("---->Clicked on " + selectValue + " Button<----");
							break;
						}
					}
				}
			}
			LogUtility.logInfo("----> " + selectValue + " Button is not displayed in the list<----");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on " + selectValue + " Button");
			throw e;
		}
	}

	public void selectCheckBox(String selectValue) throws Exception {
		try {
			LogUtility.logInfo("---->" + "User try to select the set start  page" + "<----");
			// Here total six features dispalyed so i value is up to
			// 6...Ex:billpay,transfers,checkdeposits etc..
			for (int i = 0; i <= 6; i++) {
				if (i == 0) {
					startPageText = lstPreferences.get(i).findElement(By.xpath(setStartText)).getText();
				} else {
					startPageText = lstPreferences.get(i).findElement(By.xpath(checkBoxText)).getText();
				}
				if (startPageText.contains(selectValue)) {
					lstPreferences.get(i).click();
					LogUtility.logInfo("---->Clicked on " + selectValue + " Button<----");
					break;
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Greater error message");
			throw e;
		}
	}

	/**
	 * Method to verify Amount Greater Error Message
	 * 
	 * @param errorMessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyGreaterErrorMessage(String errorMessage) throws Exception {
		try {
			if (mobileActions.verifyIsElementPresent(lblAmountErrorMsg, 5)) {
				String amountErrorMsg = lblAmountErrorMsg.getText();
				LogUtility.logInfo(
						"expected HideAccount text is:" + errorMessage + ":text from the application" + amountErrorMsg);
				if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
					btnOk.isEnabled();
				}
				return errorMessage.contains(amountErrorMsg);
			} else {
				LogUtility.logError("-->Unable to verify Amount Greater Error Message:<--");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify Greater error message");
			throw e;
		}
	}

	/**
	 * Method to verify the Preference saved message
	 * 
	 * @param errormessage
	 * @return
	 * @throws Exception
	 */
	public boolean verifyPreferenceMessage(String errorMessage) throws Exception {
		if (mobileActions.verificationOfMessage(errorMessage, txtPreferenceMsg, 4)) {
			try {
				if (mobileActions.verifyIsElementPresent(btnPopupOk, 5)) {
					btnPopupOk.click();
					btnAux.click();
				} else {
					LogUtility.logInfo("---->popup is not displayed so only verified preference message<----");
				}
			} catch (Exception e) {
				LogUtility.logError("---->popup is not displayed so only verified preference message<----");
				throw e;
			}
			verified = true;
		}
		// For transfer Funds and set preferences for the checking account text
		// verification is changed so we added here
		else if (mobileActions.verifyIsElementPresent(txtVerification, 5)) {
			if (txtVerification.getText().contains(TRANSFER_FUNDS)
					|| txtVerification.getText().contains(CHECKING_ACCOUNT_2)) {
				try {
					if (mobileActions.verifyIsElementPresent(btnCloseButton, 5)) {
						btnCloseButton.click();
						LogUtility.logInfo("---->preference is successfully changed for checking8970<----");
					} else {
						LogUtility.logInfo("---->set start page  preference is successfully changed<----");
					}
					verified = true;
				} catch (Exception e) {
					LogUtility.logError("--->Unable to verify Error Message:" + e);
					throw e;
				}
			}
		}
		return verified;
	}

	/**
	 * 
	 * Method to click on the Done Button
	 * 
	 * @throws Exception
	 */
	public void clickOnDoneButton() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				LogUtility.logInfo("user tried to click on Apply button android device");
				if (mobileActions.verifyIsElementPresent(btnApply, 6))
					btnApply.click();

			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				LogUtility.logInfo("user tried to click on Done button in ios Device");
				mobileActions.isElementPresent(btnDone, 5);
				btnDone.click();
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to clickonDone Button");
			throw e;
		}
	}

	/**
	 * Method to EnterfromAmount in the from field
	 * 
	 * @param fromamount
	 * @throws Exception
	 */
	public void enterFromAmount(String fromAmount) throws Exception {
		try {
			lblAmountFromField.click();
			lblAmountFromField.sendKeys(fromAmount);
			// To enter amount it is loading to get reflected static wait here mandatory
			waits.staticWait(2);
			LogUtility.logInfo("--->Amount entered as " + fromAmount);
		} catch (Exception e) {
			LogUtility.logError("Unable to enter Amount in the From Text field " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * 
	 * Method to enter Amount in the To field
	 * 
	 * @param Toamount
	 * @throws Exception
	 */
	public void enterToAmount(String toAmount) throws Exception {
		try {
			lblAmountToField.click();
			lblAmountToField.sendKeys(toAmount);
			// To get the accounts displayed need static wait here mandatory
			waits.staticWait(2);
			LogUtility.logInfo("--->Amount entered as " + toAmount);
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")))
				appiumDriver.navigate().back();
		} catch (Exception e) {
			LogUtility.logError("Unable to enter Amount in the To Text field " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * 
	 * Method to Click on AmountRangeButton
	 * 
	 */
	public void clickOnAmountRangeButton() {
		if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
			try {
				RemoteWebElement group = appiumDriver.findElement(By.id(accountTitle));
				List<WebElement> subgroup = group.findElements(By.id(accountSubTitle));
				subgroup.get(0).findElement(By.id(amountRangeButton)).click();
				LogUtility.logInfo("---->Clicked on Amount Range Button in android <----");
			} catch (Exception e) {
				LogUtility.logError("Unable to click on Amount Range Button:" + e.getStackTrace());
			}
		} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
			try {
				btnAmountRangeOn.click();
				LogUtility.logInfo("---->Clicked on ON Amount Range Button in ios<----");
			} catch (Exception e) {
				btnAmountRangeOff.click();
				LogUtility.logInfo("---->Clicked on OFF Amount Range Button in ios<----");
			}
		}
	}

	/**
	 * @param account
	 * @throws Exception
	 * @Author Phaneendra
	 */
	public void setToChangeSpecificAccountOrder(String account) throws Exception {
		try {
			listOfAccounts = new ArrayList<String>();
			WebElement startX = null;
			WebElement endX = null;
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {

				Iterator<RemoteWebElement> itr = lstAccountName.iterator();
				while (itr.hasNext()) {
					MobileElement acctName = (MobileElement) itr.next();
					LogUtility.logInfo(acctName.getText());
					listOfAccounts.add(acctName.getText());
				}
				endX = appiumDriver.findElement(By.xpath(dragToTopXpath));
				int i = (listOfAccounts.indexOf(account)) + 1;
				LogUtility.logInfo("Account position " + i);
				startX = appiumDriver.findElement(By.xpath(String.format(dragAccountDynamicXpath, i)));
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				// To get the accounts displayed need static wait here mandatory
				waits.staticWait(3);
				String accountToAdd = null;
				listOfAccounts.add(appiumDriver.findElement(By.xpath(accountName)).getText());
				for (int i = 2; i <= count; i++) {
					String changeOrderAccount = appiumDriver.findElement(By.xpath(String.format(getAccountName, i)))
							.getText();
					LogUtility.logInfo(changeOrderAccount);
					int spacePos = changeOrderAccount.indexOf(" ");
					if (spacePos > 0) {
						accountToAdd = changeOrderAccount.substring(0, spacePos);
					}
					listOfAccounts.add(accountToAdd);
				}

				int i = (listOfAccounts.indexOf(account)) + 1;
				endX = appiumDriver.findElement(By.xpath(dragButtonFirst));
				startX = appiumDriver.findElement(By.xpath(String.format(dragButtonLast, i)));
			}
			mobileActions.dragAndDrop(startX, endX);
			LogUtility.logInfo("user able to hold the account and dropped");
			btnSave.click();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to set the change order<--- " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to get count of accounts displayed for user when logged in
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfAccountsDisplayed() throws Exception {
		try {
			count = accountsListedCount.size();
			for (int i = 1; i <= 10; i++) {
				waits.staticWait(1);
				count = accountsListedCount.size();
				if (!(count == 0)) {
					break;
				}
			}
			LogUtility.logInfo("Number of accounts  displayed " + accountsListedCount.size());
			return count;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of accounts listed<---" + e);
			throw e;
		}
	}

}