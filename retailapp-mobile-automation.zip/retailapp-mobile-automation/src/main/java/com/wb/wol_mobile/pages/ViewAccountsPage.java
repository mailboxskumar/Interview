package com.wb.wol_mobile.pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author spothula-adm
 *
 */
public class ViewAccountsPage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	RetailAppUtils retailAppUtils = new RetailAppUtils();

	public ViewAccountsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	public ViewAccountsPage(AppiumDriver<RemoteWebElement> customDriver) {
		PageFactory.initElements(new AppiumFieldDecorator(customDriver), this);
	}

	public String accountNavigated;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='VIEW ACCOUNTS']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"VIEW ACCOUNTS\"]")
	protected MobileElement titleViewAccounts;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Webster Bank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeStaticText[1]")
	@iOSFindBy(xpath = "//*[@label=\"Webster Bank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[4]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeStaticText[1]")
	@iOSFindBy(xpath = "//*[@label=\"Webster Bank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeStaticText[1]")
	protected MobileElement iosViewAccountsTitle;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_auxmenu")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Auxiliary Menu']")
	@iOSFindBy(xpath = "//*[@label=\"Webster Bank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeButton[2]")
	@iOSFindBy(xpath = "//*[@label='Webster Bank']/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeButton[2]")
	@iOSFindBy(xpath = "//*[@label='Auxiliary Menu']")
	public MobileElement iconSettings;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@iOSFindBy(xpath = "//*[@label=\"Webster Bank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeButton[2]")
	@iOSFindBy(xpath = "//*[@label='Webster Bank']/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeNavigationBar[1]/XCUIElementTypeButton[2]")
	public MobileElement btnSettings;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Nlck and @enabled = 'true']")
	protected MobileElement lblPurgedAccount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='MENU']")
	protected MobileElement titleMenu;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/card_view")
	@iOSFindBy(xpath = "//*[@label='MENU']")
	@CacheLookup
	protected List<RemoteWebElement> listViewAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/filter_button")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Filter']")
	protected MobileElement iconFilter;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Filter by Amount']")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@label='Filter Transactions']")
	@iOSFindBy(xpath = "//*[@label=\"Filter Transactions\"]")
	protected MobileElement titleFilter;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/options_button")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='More Info']")
	protected MobileElement iconDetails;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='See Details']")
	protected MobileElement txtSeeDetails;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Account Details']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Account Details']")
	protected MobileElement txtAccountDetails;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/img_account_settings")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Account Settings.']")
	protected MobileElement btnAccountSettingsIcon;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/value")
	@iOSFindBy(xpath = "//*[@label=\"Edit Nickname\"]")
	protected MobileElement optEditNickName;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/hide_account")
	@iOSFindBy(xpath = "//*[@label='Hide Account']")
	protected MobileElement optHideAccount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/cancel")
	@iOSFindBy(xpath = "//*[@label=\"Close\"]")
	protected MobileElement btnClose;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/XCUIElementTypeStaticText")
	protected MobileElement titleAcctName;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/save")
	protected MobileElement btnSave;

	@iOSFindBy(xpath = "//*[@label=\"Confirm\"]")
	protected MobileElement btnConfirm;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Account']")
	@iOSFindBy(xpath = "//*[@label='Account']")
	protected MobileElement acctVerify;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Your account is currently inactive and not eligible for this action.We apologize for any inconvenience.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Your account is currently inactive and not eligible for this action.We apologize for any inconvenience.']")
	protected MobileElement lblInActiveErrorMessage;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Your account information is temporarily unavailable due to system maintenance. We apologize for any inconvenience.']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Your account information is temporarily unavailable due to system maintenance. We apologize for any inconvenience.']")
	protected MobileElement lblTemporaryUnAvailableErrorMessage;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "android:id/search_src_text")
	@iOSFindBy(xpath = "//XCUIElementTypeSearchField[@label='Search Transactions']")
	@iOSFindBy(xpath = "//XCUIElementTypeSearchField[@label='Search transactions']")
	protected MobileElement txtSearchTransactions;

	@AndroidFindBy(xpath = "//android.widget.LinearLayout/android.widget.TextView[contains(@text,'Transactions for')]")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'Transactions for')]")
	protected MobileElement titleTransactionFor;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/transaction_info")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Transactions for')]/following::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstTransactions;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/transaction_info")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Transactions for')]/following::XCUIElementTypeCell")
	protected MobileElement cellTransactions;

	@AndroidFindBy(xpath = "//android.widget.ListView[@resource-id='com.malauzai.websterbank:id/transactions']/android.widget.RelativeLayout/following-sibling::android.widget.LinearLayout")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Transactions for')]/following::XCUIElementTypeCell")
	protected MobileElement txtTransactions;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_name")
	@iOSFindBy(xpath = "//XCUIElementTypeOther/preceding-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> accountsListedCount;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//*[@label=\"OK\"]")
	protected List<RemoteWebElement> lstButtonOkAlert;

	@AndroidFindBy(id = "android:id/button1")
	@iOSFindBy(xpath = "//*[@label=\"OK\"]")
	protected MobileElement btnOkAlert;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/caret")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Transactions for')]/following-sibling::XCUIElementTypeCell")
	protected List<RemoteWebElement> lstBtnDropArrowSeeDetails;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/caret")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Transactions for')]/following-sibling::XCUIElementTypeCell")
	protected MobileElement btnDropArrowSeeDetails;

	@iOSFindBy(xpath = "//*[@label=\"Show Details\"]")
	protected MobileElement btnShowDetails;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Status']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Status']")
	protected List<RemoteWebElement> lstTxtTransactionStatus;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/primary_balance_value")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[contains(@label,'$')]")
	protected MobileElement txtAmountDisplay;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/date")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[contains(@label,'Transaction Cell')]/child::XCUIElementTypeStaticText[1]")
	protected List<RemoteWebElement> lstDates;

	@iOSFindBy(xpath = "//XCUIElementTypeCell[contains(@label,'Transaction Cell')]/child::XCUIElementTypeStaticText[3]")
	protected List<RemoteWebElement> lstMoreDates;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/date")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Transactions for')]/following::XCUIElementTypeCell/XCUIElementTypeStaticText[1]")
	protected MobileElement txtTransactionDate;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE, iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.Button[@text='OK']")
	@AndroidFindBy(xpath = "//android.widget.Button[@text='Ok']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Ok']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='OK']")
	protected MobileElement btnOk;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/amount")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[contains(@label,'Transaction Cell')]/child::XCUIElementTypeStaticText[3]")
	protected List<RemoteWebElement> lstAmounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/amount")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Transactions for')]/following::XCUIElementTypeCell/XCUIElementTypeStaticText[3]")
	protected MobileElement txtTransactionAmount;

	@HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='No Items Available']")
	@AndroidFindBy(xpath = "//*[@resource-id='com.malauzai.websterbank:id/snackbar_text']")
	@iOSFindBy(xpath = "//*[@label=\"No Items Available\"]")
	protected MobileElement txtNoItemsAvailable;

	@AndroidFindBy(xpath = "//*[@resource-id=\"android:id/progress\"]")
	protected MobileElement iconLoadingProgress;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/amount")
	@iOSFindBy(xpath = "//XCUIElementTypeCell[@name='transactionCellAccessibilityIdentifier']/XCUIElementTypeStaticText[3]")
	protected List<RemoteWebElement> txtTransactionsListAmount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/alertTitle")
	protected List<RemoteWebElement> lblErrorAlert;

	public static ArrayList<Date> dates = new ArrayList<>();
	ArrayList<String> lstSelectedDays = new ArrayList<String>();
	public static ArrayList<String> amounts = new ArrayList<String>();
	public static List<String> dateList = new ArrayList<String>();
	SimpleDateFormat format = new SimpleDateFormat("MMM dd,yyyy");
	SimpleDateFormat formatiOS = new SimpleDateFormat("MM-dd-yyyy");
	public static String currentDate;
	public static String lastNthDate;

	private String account = "//XCUIElementTypeOther/preceding-sibling::XCUIElementTypeCell[%d] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";
	private String getAccounts = "//XCUIElementTypeCell[%d]/XCUIElementTypeStaticText[1] | "
			+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])[%d]";
	private String verifyAccountExists = "//android.widget.TextView[@text='%d'] | //*[@label='%d']";

	private String amountText = "com.malauzai.websterbank:id/amount";
	public String accountDisplayed = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name']";
	public String moreDatesDisplayed = "//XCUIElementTypeCell[contains(@label,'Transaction Cell')][%d]/child::XCUIElementTypeStaticText[3]";
	public String moreAmountsDisplayed = "//XCUIElementTypeCell[@name='transactionCellAccessibilityIdentifier'][%d]/XCUIElementTypeStaticText[2]";
	public String amountDisplayed = "//XCUIElementTypeStaticText[3]";
	
	public WebElement verifyAccount(String accountName) {
		return appiumDriver.findElement(By.xpath(verifyAccountExists.replace("%d", accountName)));
	}

	public boolean verifyAccountExist(String accountName) {
		if (appiumDriver.findElements(By.xpath(verifyAccountExists.replace("%d", accountName))).size() != 0) {
			LogUtility.logInfo(accountName+" exists");
			return true;
		} else {
			LogUtility.logInfo(accountName+"not exists");
			return false;
		}
	}

	/**
	 * Method to clickOnAccount
	 * 
	 * @param accountName
	 * @throws Exception
	 */
	public void clickAccount(String accountName) throws Exception {
		WebElement element = null;
		try {
			mobileActions.scrollUp();
			appiumDriver.findElement(By.xpath(verifyAccountExists.replace("%d", accountName))).click();
			LogUtility.logInfo("Clicked on account " + accountName);
		} catch (Exception e) {
			try {
				mobileActions.scrollDownToElementPresent(element, 5, 2);
			}catch(NoSuchElementException ex) {
				LogUtility.logError("Unable to click on account " + accountName);
				throw e;
			}
		}
	}

	/**
	 * Method to verifying the view Accounts title after logged in
	 * 
	 * @throws Exception
	 */
	public void verifyViewAccountsPageTitle() throws Exception {
		try {
			if (mobileActions.isAlertPresent()) {
				appiumDriver.switchTo().alert().dismiss();
			} else if (lblErrorAlert.size() != 0) {
				btnOkAlert.click();
			}
			try {
				mobileActions.isElementPresent(titleViewAccounts, 5);
				LogUtility.logInfo("View Accounts Title page displayed");
			} catch (Exception e) {
				mobileActions.isElementPresent(iosViewAccountsTitle, 5);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the View Account Title " + e.getStackTrace());
			throw e;
		}
	}
	
	
	public void acceptInEligibleAccountPopup() throws Exception {
		try {
			if (mobileActions.isAlertPresent() == true) {
				appiumDriver.switchTo().alert().dismiss();
			} else if (lblErrorAlert.size() != 0) {
				btnOkAlert.click();
				LogUtility.logInfo("accept the inEligiblePopup");
			}
			else {
			LogUtility.logInfo("inEligiblePopup is not displayed");
			}
		}
		catch(Exception e) {
			LogUtility.logError(" Unable to handle the inEligiblePopup error popup " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Settings Icon
	 * 
	 * @throws Exception
	 */
	public void clickSettingsIcon() throws Exception {
		try {
			if (iconSettings.isDisplayed()) {
				iconSettings.click();
				LogUtility.logInfo("Settings Icon clicked");
			}
			try {
				mobileActions.isElementPresent(titleMenu, 4);
			} catch (Exception e) {
				btnSettings.isDisplayed();
				btnSettings.click();
				mobileActions.isElementPresent(titleMenu, 4);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Failed while/after clicking on settings icon " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to get count of elements
	 * 
	 * @return
	 * @throws Exception
	 */
	public int listOfAccountsInViewPage() throws Exception {
		try {
			LogUtility.logInfo("Accounts displayed " + listViewAccounts.size());
			return listViewAccounts.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the list of acounts" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to click on Filter icon
	 * 
	 * @throws Exception
	 */
	public void clickOnFilterIcon() throws Exception {
		try {
			mobileActions.isElementPresent(iconFilter, 10);
			iconFilter.click();
			LogUtility.logInfo("Clicked on filter icon");
			mobileActions.isElementPresent(titleFilter, 5);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on filter icon " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Details Icon in view Accounts Page
	 * 
	 * @throws Exception
	 */
	public void tapOnDetailsIcon() throws Exception {
		try {
			mobileActions.isElementPresent(iconDetails, 8);
			iconDetails.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				mobileActions.isElementPresent(txtSeeDetails, 3);
				txtSeeDetails.click();
			}
			mobileActions.isElementPresent(txtAccountDetails, 8);
			accountNavigated = titleAcctName.getText();
			LogUtility.logInfo("Clicked on Details icon and navigated to Account Details Page " + accountNavigated);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Details icon " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Account Settings Icon
	 * 
	 * @throws Exception
	 */
	public void tapOnAccountSettingsIcon() throws Exception {
		try {
			btnAccountSettingsIcon.click();
			LogUtility.logInfo("Clicked on Account Settings button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on account settings button " + e);
			throw e;
		}
	}

	/**
	 * Method to verify the account settings options
	 * 
	 * @throws Exception
	 */
	public void verifyAccountSettingsOptions() throws Exception {
		try {
			List<RemoteWebElement> accountSettingsOptionElements = new ArrayList<RemoteWebElement>();
			accountSettingsOptionElements.addAll(Arrays.asList(optEditNickName, optHideAccount, btnClose));
			mobileActions.elementsPresent(accountSettingsOptionElements);
			LogUtility.logInfo("--->Verified the Account settings options in details page");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the Account settings options in details page " + e);
			throw e;
		}
	}

	/**
	 * 
	 * Method to click on Close button
	 * 
	 * @throws Exception
	 */
	public void clickOnClose() throws Exception {
		try {
			btnClose.click();
			LogUtility.logInfo("Clicked on close button");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on CLose button " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Hide account option
	 * 
	 * @throws Exception
	 */
	public void clickOnHideAccount() throws Exception {
		try {
			optHideAccount.click();
			LogUtility.logInfo("--->Clicked on Hide Account<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Hide Account " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Confirm/Save button in iOS and Android
	 * 
	 * @throws Exception
	 */
	public void confirmSaveHideAccount() throws Exception {
		try {
			LogUtility.logInfo("Account hiding " + accountNavigated);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				mobileActions.isElementPresent(btnConfirm, 5);
				btnConfirm.click();
				mobileActions.isElementPresent(btnOk, 5);
				btnOk.click();
			} else {
				btnSave.click();
			}
			mobileActions.isElementPresent(titleViewAccounts, 10);
			if (verifyAccountExist(accountNavigated) == true) {
				throw new Exception("Account not hidden");
			}
			LogUtility.logInfo("Clicked and saved Hide account ");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to save and confirm hide account " + e);
			throw e;
		}
	}

	/**
	 * Method to click on account
	 * 
	 * @param account
	 * @throws Exception
	 */
	public void clickOnAccount(String account) throws Exception {
		try {
			verifyAccount(account);
			clickAccount(account);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on account " + account);
			throw e;
		}
	}

	/**
	 * Method to scroll upto text is visible for both iOS and Android
	 * 
	 * @param visibleText
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void scrollToText(String visibleText) {
		try {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				/**
				 * This is temporary implementation as per the webster app design. Below
				 * commented code UiScrollable is not scrolling. Below actual implementation for scrolling
				 **/
				/*
				 * ConcurrentEngines.getEngine().getAndroidDriver().
				 * findElementByAndroidUIAutomator(
				 * "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
				 * + visibleText + "\").instance(0))");
				 */
				try {
					appiumDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector())"
							+ ".scrollIntoView(new UiSelector().text(\"" + visibleText + "\"));"));
				} catch (NoSuchElementException e) {
					mobileActions.scrollUp();
					appiumDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector())"
							+ ".scrollIntoView(new UiSelector().text(\"" + visibleText + "\"));"));
				}
			} else {
				JavascriptExecutor js = (JavascriptExecutor) ConcurrentEngines.getEngine().getIosDriver();
				HashMap scrollObject = new HashMap<>();
				scrollObject.put("predicateString", "value == '" + visibleText + "'");
				/** Commented this below line, if scrolling is not happening uncomment it **/
				// scrollObject.put("direction", "down");
				js.executeScript("mobile: scroll", scrollObject);
			}
		} catch (NoSuchElementException e) {
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				/** Scrolling two times again **/
				mobileActions.scrollUp();
				mobileActions.scrollUp();
				appiumDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector())"
						+ ".scrollIntoView(new UiSelector().text(\"" + visibleText + "\"));"));
			}
		}
	}

	/**
	 * Method to scroll down for both iOS and Android
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void scrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) appiumDriver;
		HashMap scrollObject = new HashMap<>();
		scrollObject.put("direction", "down");
		js.executeScript("mobile: scroll", scrollObject);
	}

	/**
	 * Method to enter search keyword in search transactions bar
	 * 
	 * @param searchText
	 * @param account
	 * @throws Exception
	 */
	public void enterSearchText(String searchText, String account) throws Exception {
		try {
			txtSearchTransactions.click();
			txtSearchTransactions.sendKeys(searchText);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				appiumDriver.navigate().back();
			} else {
				ConcurrentEngines.getEngine().getIosDriver().getKeyboard().sendKeys(Keys.RETURN);
			}
			LogUtility.logInfo("Enter search value " + searchText + " for account " + account);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter text in search " + searchText + " for account " + account);
			throw e;
		}
	}

	/**
	 * Method to verify the transaction history available for account
	 * 
	 * @param searchText
	 * @throws Exception
	 */
	public void verifyTransactionHistory(String searchText) throws Exception {
		try {
			scrollDown();
			mobileActions.isElementPresent(titleTransactionFor, 5);
			LogUtility.logInfo("Verifying the trasactions available");
			LogUtility.logInfo("Number of Transactions " + lstTransactions.size());
			verifyAccount(searchText);
		} catch (Exception e) {
			LogUtility.logError("Unable verify the transaction history");
			throw new Exception();
		}
	}

	public void verifyTransactionHistoryAmount(String searchText) {
		if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
			for (WebElement accounts : lstTransactions) {
				String amount = accounts.findElement(By.id(amountText)).getText();
				if (amount.contains(searchText)) {
					break;
				} else {
					continue;
				}
			}

		} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
			for (WebElement accounts : lstTransactions) {
				String amount = accounts.findElement(By.xpath(amountDisplayed)).getText();
				if (amount.contains(searchText)) {
					break;
				} else {
					continue;
				}
			}

		}
	}

	/**
	 * Method to return count for expand icons on Android and see details options on
	 * ios for Transaction History
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountForTransactionExpandOptions() throws Exception {
		try {
			LogUtility.logInfo("Number of icons displayed to expand transactions " + lstBtnDropArrowSeeDetails.size());
			return lstBtnDropArrowSeeDetails.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of icons displayed to expand transactions<---" + e);
			throw e;
		}
	}

	/**
	 * Method to expand transactions that are displayed
	 * 
	 * @throws Exception
	 */
	public void expandTransactions() throws Exception {
		try {
			Iterator<RemoteWebElement> i = lstBtnDropArrowSeeDetails.iterator();
			int j = 1;
			while (i.hasNext()) {
				WebElement element = i.next();
				element.click();
				if (j == 2)
					break;
				scrollDown();
				j++;
			}
			LogUtility.logInfo("Expanded Transactions displayed");
		} catch (Exception e) {
			LogUtility.logError("Unable to expand the transactions " + e);
			throw e;
		}
	}

	/**
	 * Method to return the boolean value if Status field is present
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean verifyStatusTransaction() throws Exception {
		try {
			if (lstTxtTransactionStatus.size() > 1) {
				LogUtility.logInfo("Verified status element present for transactions");
				return true;
			} else {
				LogUtility.logError("Unable to verify the status for transactions");
				return false;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the status for transactions" + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to get count of accounts displayed for user when logged in
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfAccountsDisplayed() throws Exception {
		try {
			//Loading of accounts take time
			waits.staticWait(10);
			LogUtility.logInfo("Number of accounts  displayed " + accountsListedCount.size());
			return accountsListedCount.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get count of accounts listed<---" + e);
			throw e;
		}
	}

	/**
	 * Method to iterate each account displayed in view accounts page and verify the
	 * transactions available
	 * 
	 * @throws Exception
	 */
	public void accountHavingTransactions() throws Exception {
		int count = getCountOfAccountsDisplayed();
		try {
			for (int i = count; i <= count; --i) {
				appiumDriver.findElement(By.xpath(String.format(account, i, i))).click();
				if (lstTransactions.size() != 0)
					break;
				if (lstButtonOkAlert.size() != 0)
					btnOkAlert.click();
				count--;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to click on account " + e);
			throw e;
		}
	}

	public void verifyAmountDisplayed() throws Exception {
		try {
			mobileActions.isElementPresent(txtAmountDisplay, 5);
			String amount = txtAmountDisplay.getText().replaceAll("[\\$|,|;|']", "");
			float finAmount = Float.parseFloat(amount);
			if (finAmount > 0) {
				LogUtility.logInfo("Verified amount displayed " + amount);
			} else {
				throw new Exception();
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the amount " + e);
			throw e;
		}
	}

	/**
	 * Method to get dates of Transaction History
	 * 
	 * @return
	 * @throws Exception
	 */
	public ArrayList<Date> datesDisplayed() throws Exception {
		WebElement element;
		String dateText;
		try {
			Date dateFormat = null;
			dates.clear();
			mobileActions.isElementPresent(txtTransactionDate, 8);
			if (TestDataConstants.getOSPlatformName().equals("android"))
				mobileActions.swipeUp();
			Iterator<RemoteWebElement> date = lstDates.iterator();
			int counter = 0;
			while (date.hasNext() && counter < 25) {
				element = date.next();
				dateText = element.getText();
				/**
				 * Added code to fix the date fetch issue, getting transaction name instead date
				 **/
				if (TestDataConstants.getOSPlatformName().equals("ios")) {
					boolean atleastOneAlpha = dateText.matches(".*[a-zA-Z]+.*");
					if (atleastOneAlpha) {
						dateText = appiumDriver.findElement(By.xpath(String.format(moreDatesDisplayed, counter + 1)))
								.getText();
					}
				}
				LogUtility.logInfo(dateText);
				if (!dateText.equalsIgnoreCase("pending")) {
					if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
						dateFormat = format.parse(dateText);
					} else {
						dateFormat = formatiOS.parse(dateText);
					}
					dates.add(dateFormat);
					counter++;
				}
			}
			return dates;
		} catch (Exception e) {
			LogUtility.logError("Dates not displayed " + e);
			throw e;
		}
	}

	public List<String> sortDatesGetFirstLastDates() throws Exception {
		try {
			dateList.clear();
			String getDate = null;
			Collections.sort(dates);
			/** Below line for sample to write for each loop **/
			// dates.forEach(action -> LogUtility.logInfo("Dates sorted
			// "+format.format(action)));
			for (Date action : dates) {
				if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
					getDate = format.format(action);
					LogUtility.logInfo(format.format(action));
				} else {
					getDate = formatiOS.format(action);
					LogUtility.logInfo(formatiOS.format(action));
				}
				dateList.add(getDate);
			}
			return dateList;
		} catch (Exception e) {
			LogUtility.logError("Dates sorting is not happened " + e);
			throw e;
		}
	}

	public void compareDates() throws Exception {
		WebElement element;
		String dateTextEle;
		try {
			mobileActions.isElementPresent(txtTransactionDate, 8);
			Iterator<RemoteWebElement> date = lstDates.iterator();
			int counter = 0;
			while (date.hasNext()) {
				element = date.next();
				dateTextEle = element.getText();
				LogUtility.logInfo(dateTextEle);
				/**
				 * Added code to fix the date fetch issue, getting transaction name instead date
				 **/
				if (TestDataConstants.getOSPlatformName().equals("ios")) {
					boolean atleastOneAlpha = dateTextEle.matches(".*[a-zA-Z]+.*");
					if (atleastOneAlpha) {
						dateTextEle = appiumDriver.findElement(By.xpath(String.format(moreDatesDisplayed, counter + 1)))
								.getText();
					}
				}
				Date dateTransaction = retailAppUtils.parse(dateTextEle, retailAppUtils.simpleDateFormat);
				Date startsDate = (FilterPage.dateStart);
				Date endsDate = (FilterPage.dateEnd);
				if ((dateTransaction.after(startsDate) || dateTransaction.equals(startsDate))
						&& dateTransaction.before(endsDate) || dateTransaction.equals(endsDate)) {
					LogUtility.logInfo(dateTransaction + " Falls in or between filter Start & End default date "
							+ startsDate + " " + endsDate);
				} else {
					throw new Exception(dateTransaction + " does not fall between default start " + startsDate
							+ " and end " + endsDate + " dates");
				}
				counter++;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the filtered transactions based on date " + e.getStackTrace());
			throw e;
		}
	}

	public void compareLastSevenFourteenDays(int days) throws Exception {
		try {
			String getdate = null;
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_YEAR, -days);

			for (int i = 0; i < days; i++) {
				cal.add(Calendar.DAY_OF_YEAR, 1);
				getdate = format.format(cal.getTime());
				lstSelectedDays.add(getdate);
			}
			LogUtility.logInfo("Last " + days + " days dates to compare transaction history " + lstSelectedDays);
			currentDate = lstSelectedDays.get(lstSelectedDays.size() - 1);
			lastNthDate = lstSelectedDays.get(0);
			Date currentDay = retailAppUtils.parse(currentDate, retailAppUtils.simpleDateFormat);
			Date seventhDay = retailAppUtils.parse(lastNthDate, retailAppUtils.simpleDateFormat);

			Iterator<RemoteWebElement> date = lstDates.iterator();
			try {
				while (date.hasNext()) {
					WebElement element = date.next();
					LogUtility.logInfo(element.getText());
					Date dateTransaction = retailAppUtils.parse(element.getText(), retailAppUtils.simpleDateFormat);
					if ((dateTransaction.after(seventhDay) || dateTransaction.equals(seventhDay))
							&& dateTransaction.before(currentDay) || dateTransaction.equals(currentDay)) {
						LogUtility.logInfo(dateTransaction + " Falls in or between filter Start & End default date "
								+ seventhDay + " " + currentDay);
					} else {
						throw new Exception(dateTransaction + " does not fall between default start " + seventhDay
								+ " and end " + currentDay + " dates");
					}
				}
			} catch (NullPointerException e) {
				LogUtility.logInfo("No Items available");
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to compare the dates " + e.getStackTrace());
			throw e;
		}
	}

	public void compareAmounts() throws Exception {
		try {
			String amountTrans = null;
			waits.staticWait(5);
			Iterator<RemoteWebElement> amount = (txtTransactionsListAmount).iterator();
			int counter = 0;
			//Verifying first 6 amounts that are displayed due to UI automator limitation
			while (amount.hasNext() && counter < 6) {
				WebElement element = amount.next();
				String amountToCompare = element.getText();
				LogUtility.logInfo(amountToCompare);
				if (amountToCompare.matches(
						"(\\+|-)?\\s?(\\$)([0-9]+(\\.[0-9]+))|^\\$(([1-9]\\d{0,2}(,\\d{3})*)|(([1-9]\\d*)?\\d))(\\.\\d\\d)?$")) {
					amountTrans = amountToCompare.replaceFirst("(\\+|-)?\\s?(\\$)", "").replace(",", "");
				} else {
					/**
					 * Added code to fix the date fetch issue, getting transaction date and name
					 * instead amount
					 **/
					if (TestDataConstants.getOSPlatformName().equals("ios")) {
						amountTrans = appiumDriver
								.findElement(By.xpath(String.format(moreAmountsDisplayed, counter + 1))).getText()
								.replaceFirst("(\\+|-)?\\s?(\\$)", "").replace(",", "");
						LogUtility.logInfo(amountTrans);
					}
				}
				double convDouble = Double.parseDouble(amountTrans);
				int compareFrom = Double.compare(
						Double.parseDouble(amounts.get(0).replaceAll("(\\+|-)?\\s?(\\$)", "").replace(",", "")),
						convDouble);
				int compareTo = Double.compare(Double.parseDouble(FilterPage.toAmount), convDouble);
				if ((compareFrom == 0 || compareFrom < 0) && (compareTo == 0 || compareTo > 0)) {
					LogUtility.logInfo(convDouble + " Falls in or between filter From & To Amount Range "
							+ amounts.get(0) + " and " + FilterPage.toAmount);
				} else {
					throw new Exception("Amount is not filtered properly " + convDouble + " is not between "
							+ compareFrom + " " + compareTo);
				}
				counter++;
			}
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the filtered transactions based on date " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to get amounts of Transaction History
	 * 
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> amountsDisplayed() throws Exception {
		WebElement amount;
		String amountDisplayed;
		try {
			amounts.clear();
			mobileActions.isElementPresent(txtTransactionAmount, 10);
			Iterator<RemoteWebElement> iosAmounts = txtTransactionsListAmount.iterator();
			int counter = 0;
			while (iosAmounts.hasNext()) {
				amount = iosAmounts.next();
				amountDisplayed = amount.getText();
				boolean str = amount.getText().matches(
						"(\\+|-)?\\s?(\\$)([0-9]+(\\.[0-9]+))|^\\$(([1-9]\\d{0,2}(,\\d{3})*)|(([1-9]\\d*)?\\d))(\\.\\d\\d)?$");
				if (!str) {
					if (TestDataConstants.getOSPlatformName().equals("ios"))
						amountDisplayed = appiumDriver
								.findElement(By.xpath(String.format(moreAmountsDisplayed, counter + 1))).getText();
				}
				LogUtility.logInfo(amountDisplayed);
				amounts.add(amountDisplayed);
				// Checking size upto 5, means getting amount data upto 5 times
				if (amounts.size() == 5)
					break;
				counter++;
			}
			return amounts;
		} catch (Exception e) {
			LogUtility.logError("Amounts not displayed " + e);
			throw e;
		}
	}

	public void verifyTransactionSpecificDate() throws Exception {
		try {
			LogUtility.logInfo("Comparing the transactions listed based on specific date");
			for (Date transactionHistoryDate : datesDisplayed()) {
				if (transactionHistoryDate.compareTo(FilterPage.specifcDateSelected) == 0) {
					LogUtility.logInfo("Transaction history is filtered with selected specific dates");
				} else {
					throw new Exception("Transaction History is not displayed with selected specific date");
				}
			}
		} catch (Exception e) {
			LogUtility.logError("Verification is failed due to " + e);
			throw e;
		}
	}

	public void verifyErrorMessageNoResults(String errMsg) throws Exception {
		try {
			mobileActions.isElementPresent(txtNoItemsAvailable, 10);
			String noSearch = txtNoItemsAvailable.getText();
			Assert.assertEquals(noSearch, errMsg);
			LogUtility.logInfo("Error message displayed as " + errMsg);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the error message when no results are displayed " + e);
			throw e;
		}
	}

	/**
	 * Method to clickOnAccount
	 * 
	 * @param accountName
	 * @throws Exception
	 */
	public void verifyAccountPresent(String accountName) throws Exception {
		try {
			scrollToText(accountName);
			LogUtility.logInfo("Verified account is present " + accountName);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify account is present" + accountName);
			throw e;
		}
	}

	/**
	 * Method to verify the accounts displayed in order
	 * 
	 * @param accountsOrder
	 * @throws Exception
	 */
	public void verifyAccountsOrder(String accountsOrder) throws Exception {
		try {
			LinkedList<String> accounts = new LinkedList<String>();
			List<String> accountsApp = new ArrayList<String>();
			for (String eachAccount : accountsOrder.split(",")) {
				accounts.add(testDataMap.get(eachAccount));
			}
			/**
			 * After scrolling waiting 5 seconds for scroll to stop and if any loading icon
			 * to disappear
			 **/
			waits.staticWait(2);
			mobileActions.scrollUp();
			waits.staticWait(5);
			try {
				btnOk.isDisplayed();
				btnOk.click();
			} catch (Exception e) {
				LogUtility.logInfo("Alert is not displyed so unable to click on button");
			}
			int count = getCountOfAccountsDisplayed();
			for (int i = 1; i <= count; i++) {
				String accountAdding = appiumDriver.findElement(By.xpath(String.format(getAccounts, i, i))).getText();
				accountsApp.add(accountAdding);
			}
			for (int j = 0; j < accounts.size(); j++) {
				if (!accounts.get(j).equals(accountsApp.get(j))) {
					throw new Exception("Accounts are not listed in order");
				}
			}
			LogUtility.logInfo("Accounts from the application displayed " + accountsApp);
			LogUtility.logInfo("Verifed accounts are displayed in order like " + accounts);
		} catch (Exception e) {
			LogUtility.logError("Unable to verify the accounts order " + e);
			throw e;
		}
	}

	/**
	 * Method to verify the your account is currently inacative
	 * 
	 * @param error
	 * @throws Exception
	 */
	public void verifyAccountInActiveErrorMessage(String error) throws Exception {
		try {
			String errorMessage = lblInActiveErrorMessage.getText();
			Assert.assertEquals(errorMessage, error);
			mobileActions.isElementPresent(btnOk, 5);
			btnOk.click();
			LogUtility.logInfo("Error message and OK button verified " + errorMessage);
			LogUtility.logInfo("account is currently inactive message is displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + error + " " + e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Method to verify the your account is Temporarily UnAvailable
	 * 
	 * @param error
	 * @throws Exception
	 */
	public void verifyTemporarlyUnAvailableErrorMessage(String error) throws Exception {
		try {
			String errorMessage = lblTemporaryUnAvailableErrorMessage.getText();
			Assert.assertEquals(errorMessage, error);
			mobileActions.isElementPresent(btnOk, 5);
			btnOk.click();
			LogUtility.logInfo("Error message and OK button verified " + errorMessage);
			LogUtility.logInfo("account is currently inactive message is displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message " + error + " " + e.getStackTrace());
			throw e;
		}
	}

	public void verifyAccountIsOnTop(String account) throws Exception {
		ArrayList<String> listOfAccountPresent = new ArrayList<String>();
		List<RemoteWebElement> accountName = appiumDriver.findElements(By.xpath(accountDisplayed));
		Iterator<RemoteWebElement> itr = accountName.iterator();
		while (itr.hasNext()) {
			MobileElement acctName = (MobileElement) itr.next();
			LogUtility.logInfo(acctName.getText());
			listOfAccountPresent.add(acctName.getText());
			if (listOfAccountPresent.get(0).equals(account)) {
				LogUtility.logInfo("Account displayed on top");
				break;
			} else {
				throw new Exception("Account is not in top of accounts displayed");
			}
		}
	}
}
