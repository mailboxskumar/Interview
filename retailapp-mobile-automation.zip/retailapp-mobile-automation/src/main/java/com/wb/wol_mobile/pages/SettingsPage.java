package com.wb.wol_mobile.pages;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.utilities.LogUtility;
import com.wb.wol_mobile.actions.MobileActions;
import com.wb.wol_mobile.actions.ObjectBase;
import com.wb.wol_mobile.utilities.RetailAppUtils;
import com.wb.wol_mobile.utilities.TestDataConstants;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author MPrasanth-adm
 *
 */
public class SettingsPage extends ObjectBase {

	MobileActions mobileActions = new MobileActions();
	ViewAccountsPage viewAccountPage = new ViewAccountsPage();
	RetailAppUtils retailAppUtils = new RetailAppUtils();
	
	public SettingsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);
	}

	public SettingsPage(AppiumDriver<RemoteWebElement> customDriver) {
		PageFactory.initElements(new AppiumFieldDecorator(customDriver), this);
	}

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_auxmenu")
	@iOSFindBy(xpath = "//*[@label='Auxiliary Menu']")
	@CacheLookup
	protected MobileElement imgSettingsIcon;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(xpath = "//*[text()='MENU']")
	@iOSFindBy(xpath = "//*[@label=\"MENU\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='MENU']")
	protected MobileElement titleMenu;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='PREFERENCES']")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='PREFERENCES']")
	protected MobileElement titlePreferences;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='FORGOT PASSCODE']")
	@iOSFindBy(xpath = "//*[@label='Forgot Pin']")
	public MobileElement btnForgotPasscode;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_alerts")
	@iOSFindBy(xpath = "//*[@label='Manage Alerts']")
	protected MobileElement optManageAlerts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_personalize")
	@iOSFindBy(accessibility = "Preferences")
	protected MobileElement optPreferences;

	@iOSFindBy(xpath = "//*[@label=\"Log Out\"]")
	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_logout")
	protected MobileElement btnLogout;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@name = 'PREFERENCES']")
	protected MobileElement txtPreferences;

	@AndroidFindBy(xpath = "//*[@resourceid=\"android:id/buttonPanel\"]")
	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label = 'Log out']")
	protected MobileElement btnlogoutButton;

	@AndroidFindBy(xpath = "android.widget.TextView[@text = 'Confirm Logout']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Would you like to log out of your session?']")
	protected MobileElement popupConfirmMessage;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='OK']")
	protected MobileElement btnOkPopup;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label = 'Your session has ended. Please log in again.']")
	protected MobileElement lblSessionEndpopup;

	@AndroidFindBy(xpath = "//android.widget.Button[@text='LOG OUT']")
	protected MobileElement btnLogoutAlert;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Account Preferences']/following::android.widget.LinearLayout/android.widget.RelativeLayout[1]/android.widget.TextView[1]")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@name=\"Account Preferences\"]/following-sibling::XCUIElementTypeCell/XCUIElementTypeStaticText[2]")
	protected MobileElement txtAccountsDisplayed;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Account Preferences']/following::android.widget.LinearLayout/android.widget.RelativeLayout[1]/android.widget.TextView[1]")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@name=\"Account Preferences\"]/following-sibling::XCUIElementTypeCell/XCUIElementTypeStaticText[2]")
	protected List<RemoteWebElement> lstAccountsDisplayed;

	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
	@AndroidFindBy(id = "com.malauzai.websterbank:id/value")
	@iOSFindBy(xpath = "//*[@label=\"Edit Nickname\"]")
	@iOSFindBy(xpath = "//*[@label=\"Nickname\"]")
	protected MobileElement optEditNickName;

	@iOSFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Account Preferences')]/following-sibling::XCUIElementTypeCell[2]/XCUIElementTypeStaticText[2]")
	protected MobileElement txtIosNickNameExists;

	@iOSFindBy(className = "XCUIElementTypeTextField")
	protected MobileElement txtAccountNickNameField;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/save")
	@iOSFindBy(xpath = "//*[@label=\"Submit\"]")
	protected MobileElement btnSave;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/cancel")
	@iOSFindBy(xpath = "//XCUIElementTypeAlert//*[@label='Close']")
	protected MobileElement btnClose;

	@AndroidFindBy(xpath = "//*[@text=\"Account Preferences\"]")
	protected MobileElement lblAccountPreferences;

	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/textinput_counter']")
	protected MobileElement txtMaxCharacters;

	public String logoutText = "android:id/parentPanel";
	public String logoutButtonText = "android:id/button1";
	public String accountDisplayed = "//android.widget.TextView[@text='Account Preferences']/following::android.widget.LinearLayout/android.widget.RelativeLayout[1]/android.widget.TextView[@text='%s'] |"
			+ "//XCUIElementTypeOther[@name='Account Preferences']/following-sibling::XCUIElementTypeCell/XCUIElementTypeStaticText[@label='%s']";
	public String accountNickName = "//android.widget.TextView[@text='Account Preferences']/following::android.widget.LinearLayout/android.widget.RelativeLayout[1]/android.widget.TextView[contains(@text,'%s')] | "
			+ "//XCUIElementTypeOther[contains(@name,'Account Preferences')]/following-sibling::XCUIElementTypeCell[2]/XCUIElementTypeStaticText[@label='%s']";
	private String verifyAccountExists = "//android.widget.TextView[@text='%d'] | //*[@label='%d']";
	public String getAccountName;
	public String generateStringIos;
	public String generatedStringAndroid;
	public String accountNickNameUpdated;

	/**
	 * Method to click on Settings Icon
	 * 
	 * @throws Exception
	 */
	public void clickSettingsIcon() throws Exception {
		try {
			imgSettingsIcon.click();
			try {
				mobileActions.isElementPresent(titleMenu, 3);
				LogUtility.logInfo("Settings Icon clicked");
			} catch (Exception e) {
				viewAccountPage.btnSettings.isDisplayed();
				viewAccountPage.btnSettings.click();
				mobileActions.isElementPresent(titleMenu, 4);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Settings icon " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Manage Alerts Text
	 * 
	 * @throws Exception
	 */
	public void clickManageAlerts() throws Exception {
		try {
			optManageAlerts.click();
			LogUtility.logInfo("Manage Alerts Option clicked");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Manage Alerts Option " + e);
			throw e;
		}
	}

	/**
	 * Method to click on Preferences option
	 * 
	 * @throws Exception
	 */
	public void clickPreferences() throws Exception {
		try {
			optPreferences.click();
			mobileActions.isElementPresent(titleMenu, 3);
			LogUtility.logInfo("Preferences option clicked");
		} catch (Exception e) {
			try {
				mobileActions.isElementPresent(titlePreferences, 3);
			} catch (NoSuchElementException ex) {
				LogUtility.logError("--->Unable to click on Preferences Option " + ex);
				throw ex;
			}
		}
	}

	/**
	 * Method to logout from the app
	 * 
	 * @throws Exception
	 */
	public void clickLogout() throws Exception {
		try {
			btnLogout.click();
			mobileActions.isElementPresent(btnForgotPasscode, 5);
			LogUtility.logInfo("Logged out from the application");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on logout button " + e);
			throw e;
		}
	}

	/**
	 * 
	 * Method to Click onLogoutButton
	 * 
	 * @throws Exception
	 */
	public void clickOnLogoutButton() throws Exception {
		try {
			if ((appiumDriver.getPlatformName().equalsIgnoreCase("android"))) {
				appiumDriver.navigate().back();
				btnLogout.click();
				btnLogoutAlert.click();
				LogUtility.logInfo("User is able to click on the logout button in android ");
			} else if ((appiumDriver.getPlatformName().equalsIgnoreCase("ios"))) {
				LogUtility.logInfo("User is in ios ");
				if (mobileActions.verifyIsElementPresent(viewAccountPage.iconSettings, 8)
						|| mobileActions.verifyIsElementPresent(viewAccountPage.btnSettings, 8)) {
					viewAccountPage.iconSettings.click();
					try {
						btnLogout.isDisplayed();
					} catch (Exception e) {
						viewAccountPage.btnSettings.click();
					}
				}
				btnLogout.click();
				btnlogoutButton.click();
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on logout button " + e);
			throw e;
		}
	}

	public void clickOnLogout() throws Exception {
		try {
			if ((appiumDriver.getPlatformName().equalsIgnoreCase("android"))) {
				btnLogout.click();
				LogUtility.logInfo("User is able to click on the logout button in android ");
				btnLogoutAlert.click();
				LogUtility.logInfo("Clicked on logout button in android");
			} else if ((appiumDriver.getPlatformName().equalsIgnoreCase("ios"))) {
				if (mobileActions.verifyIsElementPresent(txtPreferences, 10)) {
					LogUtility.logInfo("User is in ios ");
					btnLogout.click();
					btnlogoutButton.click();
					LogUtility.logInfo("Clicked on logout button in iOS");
				} else {
					btnLogout.click();
					btnlogoutButton.click();
					LogUtility.logInfo("Clicked on logout button in iOS");
				}

			}
		} catch (NoSuchElementException e) {
			try {
				if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
					btnLogoutAlert.click();
					LogUtility.logInfo("Logged out from the application");
				}
			} catch (Exception ex) {
				LogUtility.logError("--->Unable to click on logout button " + e);
				throw e;
			}
		}
	}

	public void navigateBackClickLogout() throws Exception {
		try {
			if ((appiumDriver.getPlatformName().equalsIgnoreCase("android"))) {
				if (mobileActions.verifyIsElementPresent(txtPreferences, 15)) {
					appiumDriver.navigate().back();
					btnLogout.click();
					RemoteWebElement value = appiumDriver.findElement(By.id(logoutText));
					WebElement checklist = value.findElement(By.id(logoutText));
					checklist.findElement(By.id(logoutButtonText)).click();
					LogUtility.logInfo("Clicked on logout button in android");
				}
			} else if ((appiumDriver.getPlatformName().equalsIgnoreCase("ios"))) {
				if (mobileActions.verifyIsElementPresent(txtPreferences, 10))
					LogUtility.logInfo("User is in ios ");
				titleMenu.click();
				btnLogout.click();
				btnlogoutButton.click();
				LogUtility.logInfo("Clicked on logout button in iOS");
			}
		} catch (NoSuchElementException e) {
			try {
				if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
					btnLogoutAlert.click();
					LogUtility.logInfo("Logged out from the application");
				}
			} catch (Exception ex) {
				LogUtility.logError("--->Unable to click on logout button " + ex);
				throw e;
			}
		}
	}

	public void clickOnLogoutCustomEngine() throws Exception {
		try {
			if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("android"))) {
				btnLogout.click();
				btnLogoutAlert.click();
				LogUtility.logInfo("Clicked on logout button in android");
			} else if ((TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios"))) {
				LogUtility.logInfo("User is in ios ");
				if (mobileActions.verifyIsElementPresent(viewAccountPage.iconSettings, 5)) {
					viewAccountPage.iconSettings.click();
					btnLogout.isDisplayed();
				}
				btnLogout.click();
				btnlogoutButton.click();
			}
		} catch (NoSuchElementException e) {
			LogUtility.logError("--->Unable to click on logout button " + e);
			throw e;
		}
	}

	public void tapOnAnyIMAccount() throws Exception {
		try {
			Iterator<RemoteWebElement> itr = lstAccountsDisplayed.iterator();
			while (itr.hasNext()) {
				String acctName = itr.next().getText();
				LogUtility.logInfo(acctName);
				if (acctName.contains("Checking")) {
					appiumDriver.findElement(By.xpath(String.format(accountDisplayed, acctName, acctName))).click();
					LogUtility.logInfo("Account Nickname popup is displayed");
					break;
				}
			}
			if (!mobileActions.verifyIsElementPresent(optEditNickName, 10))
				throw new Exception("NickName popup is not displayed/No IM account found in the list");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on IM account " + e);
			throw e;
		}
	}

	@SuppressWarnings("unused")
	public void updateNickNameMaxLength() throws Exception {
		try {
			mobileActions.isElementPresent(optEditNickName, 5);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				getAccountName = txtIosNickNameExists.getText();
				int getNickName = getAccountName.length();
				LogUtility.logInfo("Nickname length " + getNickName);
				generateStringIos = RandomStringUtils.randomAlphabetic(30 - getNickName);
				LogUtility.logInfo(generateStringIos);
				optEditNickName.click();
				mobileActions.isElementPresent(txtAccountNickNameField, 5);
				accountNickNameUpdated = getAccountName + generateStringIos;
				txtAccountNickNameField.sendKeys(accountNickNameUpdated);
			} else {
				getAccountName = optEditNickName.getText();
				LogUtility.logInfo("NickName already present " + getAccountName);
				String inputCounter = txtMaxCharacters.getText();
				String maxLength = inputCounter.split("/")[0].trim();
				generatedStringAndroid = RandomStringUtils.randomAlphabetic(30 - Integer.parseInt(maxLength));
				LogUtility.logInfo(generatedStringAndroid);
				accountNickNameUpdated = getAccountName + generatedStringAndroid;
				optEditNickName.clear();
				optEditNickName.sendKeys(accountNickNameUpdated);
			}
			btnSave.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				mobileActions.isElementPresent(btnOkPopup, 5);
				btnOkPopup.click();
				mobileActions.isElementPresent(optEditNickName, 5);
			} else {
				mobileActions.isElementPresent(lblAccountPreferences, 5);
			}
			MobileElement acctNickNameUpdated = (MobileElement) appiumDriver
					.findElement(By.xpath(String.format(accountNickName, getAccountName + generatedStringAndroid,
							getAccountName + generateStringIos)));
			LogUtility.logInfo("NickName upated");
		} catch (Exception e) {
			LogUtility.logError("Unable to update nickname with max length " + e);
			throw e;
		}
	}

	public void updateExistingNickNameMaxLength() throws Exception {
		try {
			mobileActions.isElementPresent(optEditNickName, 5);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("android")) {
				optEditNickName.clear();
				optEditNickName.sendKeys(accountNickNameUpdated);
			} else {
				optEditNickName.click();
				mobileActions.isElementPresent(txtAccountNickNameField, 5);
				txtAccountNickNameField.sendKeys(accountNickNameUpdated);
			}
			btnSave.click();
		} catch (Exception e) {
			LogUtility.logError("Unable to update nickname with max length " + e);
			throw e;
		}
	}

	public WebElement verifyAccountNickNameUpdated() {
		return retailAppUtils.fluentWait(By.xpath(verifyAccountExists.replace("%d", accountNickNameUpdated)), 30, 2);
	}

	public boolean verifyAccountNickNameNotUpdated() {
		if (appiumDriver.findElements(By.xpath(verifyAccountExists.replace("%d", accountNickNameUpdated)))
				.size() == 0) {
			return true;
		} else {
			return false;
		}
	}

	public void tapOnAnyAccount(String account) throws Exception {
		mobileActions.isElementPresent(txtAccountsDisplayed, 5);
		try {
			Iterator<RemoteWebElement> itr = lstAccountsDisplayed.iterator();
			while (itr.hasNext()) {
				String acctName = itr.next().getText();
				LogUtility.logInfo(acctName);
				if (acctName.contains(account)) {
					appiumDriver.findElement(By.xpath(String.format(accountDisplayed, acctName, acctName))).click();
					LogUtility.logInfo("Account Nickname popup is displayed");
					break;
				}
			}
			if (!mobileActions.verifyIsElementPresent(optEditNickName, 10))
				throw new Exception("NickName popup is not displayed/No IM account found in the list");
		} catch (Exception e) {
			LogUtility.logError("Unable to click on IM account " + e);
			throw e;
		}
	}

	public void updateNickNameMaxLengthCancelClose() throws Exception {
		try {
			mobileActions.isElementPresent(optEditNickName, 5);
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				getAccountName = txtIosNickNameExists.getText();
				int getNickName = getAccountName.length();
				LogUtility.logInfo("Nickname length " + getNickName);
				generateStringIos = RandomStringUtils.randomAlphabetic(30 - getNickName);
				LogUtility.logInfo(generateStringIos);
				optEditNickName.click();
				mobileActions.isElementPresent(txtAccountNickNameField, 5);
				accountNickNameUpdated = getAccountName + generateStringIos;
				txtAccountNickNameField.sendKeys(accountNickNameUpdated);
			} else {
				getAccountName = optEditNickName.getText();
				LogUtility.logInfo("NickName already present " + getAccountName);
				String inputCounter = txtMaxCharacters.getText();
				String maxLength = inputCounter.split("/")[0].trim();
				generatedStringAndroid = RandomStringUtils.randomAlphabetic(30 - Integer.parseInt(maxLength));
				LogUtility.logInfo(generatedStringAndroid);
				accountNickNameUpdated = getAccountName + generatedStringAndroid;
				optEditNickName.clear();
				optEditNickName.sendKeys(accountNickNameUpdated);
			}
			btnClose.click();
			if (TestDataConstants.getOSPlatformName().equalsIgnoreCase("ios")) {
				mobileActions.isElementPresent(optEditNickName, 5);
			} else {
				mobileActions.isElementPresent(lblAccountPreferences, 5);
			}
			LogUtility.logInfo("NickName popup closed");
		} catch (Exception e) {
			LogUtility.logError("Unable to update nickname with max length and click on close button " + e);
			throw e;
		}
	}
}
