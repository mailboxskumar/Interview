package com.wb.wol_mobile.utilities;

import com.wb.wol_mobile.actions.MobileLoginPageActions;

public class ActionsHolder {

	private GenericLibrary genericLibrary;
	private MobileLoginPageActions mobileLoginPageActions;

	public ActionsHolder() {
		genericLibrary = null;
		mobileLoginPageActions = null;
	}

	public void initialize() {
		//genericLibrary = new GenericLibrary(this);
		mobileLoginPageActions = new MobileLoginPageActions(this);
	}

	public GenericLibrary getGenericLibrary() {
		return genericLibrary;
	}

	public void setGenericLibrary(GenericLibrary genericLibrary) {
		this.genericLibrary = genericLibrary;
	}

	public MobileLoginPageActions getMobileLoginPageActions() {
		return mobileLoginPageActions;
	}

	public void setMobileLoginPageActions(MobileLoginPageActions mobileLoginPageActions) {
		this.mobileLoginPageActions = mobileLoginPageActions;
	}

}
