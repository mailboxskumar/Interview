package com.wb.wol_mobile.utilities;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.wol_mobile.testbases.RetailAppTestBase;

public class TestDataConstants {

	public static String getOSPlatformName() {
		return ConcurrentEngines.getEngine().getAppiumDriver().getPlatformName();
	}

	public static final String SECURITY_ANSWER = RetailAppTestBase.envProps.getProperty("user.rsa.answer");
	public static final String NOACCOUNTS_ERRORMESSAGE = "You have been signed out as you don't have any active accounts. Call 800.325.2424, 24 hours a day, 7 days a week, for more info.";
	public static final String CLOSED_ACCOUNT = "AnthonyCheckingClosedAcc";
	public static final String PURGED_ACCOUNT = "Nick";
	public static final String PURGED_ACCOUNT_2 = "AnthonyPurgedAcc";
	public static final String CREDITCARD_ACCOUNT = "CreditCard8539";
	public static final String CHECKING_ACCOUNT = "webster Business Value Checking";
	public static final String SAVING_ACCOUNT = "Premier Savings";
	public static final String LOAN_ACCOUNT = "HRPHHPMoneyM";
	public static final String CD_ACCOUNT = "5 Year CD";
	public static final String CHECKING_ACCOUNT_2 = "Checking9162";
	public static final String INVESTMENT_ACCOUNT = "Outin-RET";
	public static final String TRANSFERHISTORY_POSTED = "POSTED";
	public static final String TRANSFERHISTORY_PENDING = "Scheduled Transfer";
	public static final String CAMERASETTINGS_POPUP = "Allow Webster to take pictures and record video?";
	public static final String TRANSFER_FUNDS = "Transfer Funds";
	public static final String SCHEDULED_TRANSFER = "Scheduled Transfer";
	public static final String ANSWER = "answer";
	public static final String USERNAMEAUTHENTICATION = "webster";
	public static final String PASSWORDAUTHENTICATION = "WOLtest1935";
	public static final String PERSONAL_ACCOUNT = "Personal";
	public static final String BUSINESS_ACCOUNT = "Business";
	public static final String CHECKBOX_YES = "Yes";
	public static final String CHECKBOX_NO = "No";
	public static final String DYNAMIC_APLHACHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final String DYNAMICINTEGERS = "123456789";

}
