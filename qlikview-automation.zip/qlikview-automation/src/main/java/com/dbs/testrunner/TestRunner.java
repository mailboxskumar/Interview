package com.dbs.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions
(
	features= {"src/test/resoruces/features/CustomerAndAccounts.feature"},
	glue="src/test/java/com/dbs/stepDefinition",
	plugin = { "pretty" , "html:target/cucumber-reports"},
	monochrome = true,
	tags = "@firstTestcase"
)
public class TestRunner{}

