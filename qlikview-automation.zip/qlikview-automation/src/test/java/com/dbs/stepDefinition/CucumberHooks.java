package com.dbs.stepDefinition;

import com.dbs.utilities.Reusable_Components;

import cucumber.api.Scenario;
import cucumber.api.java.Before;

public class CucumberHooks{
	
	public static String featureFileName;
	public static String testcaseName;

	@Before
	public void printScenarioName(Scenario scenario) {
		testcaseName = scenario.getName();
		featureFileName = new Reusable_Components().getFeatureFileNameFromScenarioId(scenario);

	}
}
