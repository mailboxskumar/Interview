package com.dbs.stepDefinition;

import java.io.IOException;
import java.sql.SQLException;

import com.dbs.utilities.Reusable_Components;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TabularReports extends Reusable_Components {
	
	@Given("^Browser is opened and report url is navigated$")
	public void Browser_is_opened_and_report_url_is_navigated() throws IOException {

		// INVOKING BROWSER
		invokeBrowser(getConfig("BrowserName"));

		// MAXIMIZING
		driver.manage().window().maximize();

		// LOADING URL
		driver.get(getConfig("URL"));

		// Pre-req
		initializeReport();

		// Reading Repository
		readRepo();

		// Reading Mapping Sheet
		// readMappingSheet(featureFileName,testcaseName);

	}

	@When("^user enters username and password and clicked on login button$")
	public void user_enters_username_and_password_and_clicked_on_login_button()
			throws IOException, InterruptedException {
		reportLogin();
	}

	@Then("^login should be successful$")
	public void login_should_be_successful() throws IOException {
		checkLoginSuccessful();
	}

	@Given("^Report is opened$")
	public void Report_is_opened() throws InterruptedException, IOException {
		reportSelection();
	}

	@When("^filters are applied for cusotmer and accounts report$")
	public void filters_are_applied_for_customer_and_accounts_report() throws InterruptedException, IOException {
		clearFilters();
		applyFiltersCustomerAccounts();
	}

	@When("^filters are applied for self service report$")
	public void filters_are_applied_for_self_service_report() throws InterruptedException, IOException, SQLException {
		clearFilters();
		applyFiltersSelfService();
	}

	@Then("^results should match exactly with the values in database$")
	public void results_should_match_exactly_with_the_values_in_database()
			throws InterruptedException, IOException, SQLException {
		reportComparison();
		compareResults();
	}

	@And("^close the browser$")
	public void close_the_browser() {
		reports.flush();
		reports.endTest(logger);
		driver.quit();
	}

	@When("^filters are applied for BBPS report$")
	public void filters_are_applied_for_BBPS_report() {

	}
}
