package com.dbs.utilities;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.dbs.stepDefinition.CucumberHooks;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentFactory {
	public static ExtentReports getInstance() {
		ExtentReports extent;
		String[] featureFileArray = CucumberHooks.featureFileName.split(" ");
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String path = ".\\Reports\\" + featureFileArray[1] + timeStamp.trim() + ".html";
		extent = new ExtentReports(path, false);
		return extent;
	}
}
