package com.dbs.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TDConnection extends Reusable_Components {
	public static ArrayList<String> dbList;
	public ExtentReports reports;
	public ExtentTest logger;
	public HSSFWorkbook wb;
	public HSSFSheet ws;
	public HSSFRow row;
	public int rowcount;
	public String rowValue;
	public String colNames = "";
	public List<String> cif_child = new ArrayList<String>();
	public List<String> investment_ID_child = new ArrayList<String>();
	public List<String> date_of_Investment_Id_Creation_child = new ArrayList<String>();
	public List<String> dateTime_of_riskScore_child = new ArrayList<String>();
	public List<String> risk_score_child = new ArrayList<String>();
	public List<String> expiry_riskScore_child = new ArrayList<String>();
	public List<String> dint_one_child = new ArrayList<String>();
	public List<String> dint_three_child = new ArrayList<String>();
	public List<String> dint_six_child = new ArrayList<String>();
	public List<String> dint_twelve_child = new ArrayList<String>();
	public ResultSet rs;
	//public Reusable_Components obj = new Reusable_Components();

	public Connection getTeradataConnection(String ConnectionURL, String username, String password) {
		Connection conStd = null;

		try {
			Class.forName("com.teradata.jdbc.TeraDriver");
			String TeradataURL = "jdbc:teradata://" + ConnectionURL.trim() + "/TMODE=ANSI,CHARSET=UTF8";
			System.out.println("Getting the connection to " + TeradataURL);
			conStd = DriverManager.getConnection(TeradataURL, username, password);
			reporting("Pass","Connection to Database is Successfull");
		} catch (ClassNotFoundException e) {
			// System.out.println("Teradata Drfivers are missing.");
			e.printStackTrace();
			e.getMessage();
			reporting("Fail","Connection to Database is Failure :- "+e.getMessage());
		} catch (SQLException e) {
			
			e.printStackTrace();
			reporting("Fail","Connection to Database is Failure :- "+e.getMessage());
		}
		return conStd;
	}

	public void closeConnection(Connection conn) throws SQLException {
		conn.close();
		System.out.println("Connection Closed Properly.");
	}

	public String getColumnNamesForDB(String tableName) throws IOException {
		File f = new File(".\\Mapping\\mapping.xlsx");
		FileInputStream fin = new FileInputStream(f);
		wb = new HSSFWorkbook(fin);
		ws = wb.getSheet("Sheet1");
		rowcount = ws.getLastRowNum();
		for (int rownum = 0; rownum < rowcount; rownum++) {
			row = ws.getRow(rownum);
			rowValue = row.getCell(0).getStringCellValue();
			if (rowValue.trim().equalsIgnoreCase(tableName)) {
				colNames = row.getCell(1).getStringCellValue().trim();
				break;
			}
		}

		return colNames;
	}

	public void process(String QUERY, ArrayList<String> excelList) throws SQLException, IOException {
		String readQuery;
		System.out.println("Processing of DB is in Progress.................");
		int recordCount = 0;
		String connectionString = getConfig("tdAddress");
		System.out.println(connectionString);
		String user = getConfig("tdUsername");
		String password = getConfig("tdPassword");

		System.out.println("Connection String :- " + connectionString);
		System.out.println("Username :- " + user);
		System.out.println("Password :- " + password);

		Connection conObj = getTeradataConnection(connectionString, user.trim(), password.trim());
		System.out.println("Connection object formed");

		Statement stmt = conObj.createStatement();
		readQuery = fetchConfig("");

		String query = QUERY;
		System.out.println("QUERY :- " + query);
		
	
			rs = stmt.executeQuery(query);
		
		dbList = new ArrayList<String>();

		int i = 0;
		int rowcount = 0;
		while (rs.next()) {
			recordCount++;

			dbList.add(rs.getString("Cif"));
			dbList.add(rs.getString("Investment_ID"));
			dbList.add(rs.getString("Date_of_investment_ID_creation"));
			dbList.add(rs.getString("Date_time_of_riskscoregeneration"));
			dbList.add(rs.getString("risk_score"));
			dbList.add(rs.getString("expiry_dateofriskscore"));
			dbList.add(rs.getString("Dint_1_month"));
			dbList.add(rs.getString("Dint_3_month"));
			dbList.add(rs.getString("Dint_6_month"));
			dbList.add(rs.getString("Dint_12_month"));

			cif_child.add(rs.getString("Cif"));
			investment_ID_child.add(rs.getString("Investment_ID"));
			date_of_Investment_Id_Creation_child.add(rs.getString("Date_of_investment_ID_creation"));
			dateTime_of_riskScore_child.add(rs.getString("Date_time_of_riskscoregeneration"));
			risk_score_child.add(rs.getString("risk_score"));
			expiry_riskScore_child.add(rs.getString("expiry_dateofriskscore"));
			dint_one_child.add(rs.getString("Dint_1_month"));
			dint_three_child.add(rs.getString("Dint_3_month"));
			dint_six_child.add(rs.getString("Dint_6_month"));
			dint_twelve_child.add(rs.getString("Dint_12_month"));
			rowcount++;
		}

		System.out.println("COMPARISON STARTING BETWEEN EXCEL AND DB ");
		// compareResults(dbList,excelList);

		if (rowcount > 0) {
			//obj.reporting("Pass", "Rowcount from Database : " + rowcount);
			reporting("Pass", "Rowcount from Database : " + rowcount);
		} else {
			//obj.reporting("Fail", "Rowcount from Database : " + rowcount);
			reporting("Fail", "Rowcount from Database : " + rowcount);
		}

		if (rowcountExcelParent != rowcount) {
			reporting("Fail", "Rowcounts between Report and Database are not matching ");
		}

		compareResults(cif_child, cif, "CIF");
		compareResults(dint_one_child, dint_one, "No One Month");

	}

	public void compareResults(List<String> source, List<String> destination, String colName) {

		source.removeAll(destination);
		// destination.removeAll(source);
		if (source.isEmpty()) {
			reporting("Pass", "Everything Matched for " + colName);
		} else {
			reporting("Fail", "Mismatches found for " + colName + " As Follows " + source);
		}

		// SAMPLE

		for (int i = 0; i < source.size(); i++) {
			String str1 = (String) source.get(i);
			for (int j = 0; j < destination.size(); j++) {
				String str2 = (String) destination.get(j);
				if (str2.equalsIgnoreCase(str1)) {
					// System.out.println(str1);
				} else {
					System.out.println("Not Matching :- DB :  " + str1 + " Report : " + str2);
				}
			}
		}

	}

}
