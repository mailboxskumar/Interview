package com.dbs.utilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dbs.stepDefinition.CucumberHooks;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.Scenario;

public class Reusable_Components {

	// VARIABLES
	public static String excelPath = null;
	public static int rowcount = 0;
	public FileOutputStream fout = null;
	public static XSSFWorkbook wb;
	public static FileInputStream fin = null;
	public WebDriver driver;
	public static XSSFSheet ws;
	public static FileWriter fw;
	public static BufferedWriter bw;
	public static ArrayList<String> excelList;
	public static ArrayList<String> excelHeaderList;
	public static ExtentReports reports;
	public static ExtentTest logger;
	public String headerColNames = "";
	public static String mappingPath;
	public static String query;
	public static HSSFRow row;
	public static String data;
	public static List<String> cif = new ArrayList<String>();
	public static List<String> accountType = new ArrayList<String>();
	public static List<String> account_open_Date = new ArrayList<String>();
	public static List<String> investment_ID = new ArrayList<String>();
	// public static List<String> date_of_Investment_Id_Creation = new
	// ArrayList<String>();
	public static List<String> dateTime_of_riskScore = new ArrayList<String>();
	public static List<String> risk_score = new ArrayList<String>();
	public static List<String> expiry_riskScore = new ArrayList<String>();
	public static List<String> dint_one = new ArrayList<String>();
	public static List<String> dint_three = new ArrayList<String>();
	public static List<String> dint_six = new ArrayList<String>();
	public static List<String> dint_twelve = new ArrayList<String>();
	public static int rowcountExcelParent;
	public static String config_key;
	public static String config_value;
	public static String key, value;
	public HashMap<String, String> repo = new HashMap<String, String>();

	// METHODS

	/**
	 * Function Name :- performClickOperation Function Desc :- It retrieves the
	 * value from Config file based on the key Created ON :- 20-07-2018 Created By
	 * :- BADRI
	 */

	public void performClickOperation(WebElement element) {
		try {
			element.click();
		} catch (Exception ex) {
			reporting("fail", ex.getMessage());
		}
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- enterText Function Desc :- It enters the text into
	 * textbox Created ON :- 20-07-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void enterText(WebElement element, String value) {
		try {
			element.click();
			wait(1);
			element.sendKeys(value.trim());
		} catch (Exception ex) {
			reporting("fail", ex.getMessage());
		}
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- enterText Function Desc :- It enters the text into
	 * textbox Created ON :- 20-07-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void wait(int num_of_seconds) throws InterruptedException {
		Thread.sleep(num_of_seconds * 1000);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- identifyElement Function Desc :- It identifies the
	 * element using xpath Created ON :- 18-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public WebElement identifyElement(String xpath) {
		WebElement element = null;
		if (driver.findElement(By.xpath(xpath.trim())).isDisplayed()) {
			return driver.findElement(By.xpath(xpath.trim()));
		}
		return element;
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- identifyElementDropDown Function Desc :- It
	 * identifies the element using xpath Created ON :- 18-09-2018 Created By :-
	 * BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public Select identifyElementDropDown(String xpath) {
		Select element = null;
		if (driver.findElement(By.xpath(xpath.trim())).isDisplayed()) {
			element = new Select(driver.findElement(By.xpath(xpath)));
		}
		return element;
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- getConfig Function Desc :- It retrives the value from
	 * config file based on the key Created ON :- 20-07-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */
	public String getConfig(String keyName) throws IOException {
		config_key = keyName.trim();
		File f = new File(".\\Config\\config.xlsx");
		FileInputStream fin = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fin);
		XSSFSheet ws = wb.getSheet("Sheet1");
		int rowcount = ws.getLastRowNum();
		HashMap<String, String> hm = new HashMap<String, String>();
		for (int rownum = 0; rownum < rowcount; rownum++) {
			XSSFRow row = ws.getRow(rownum);
			for (int colnum = 0; colnum <= 1; colnum++) {
				if (colnum == 0) {
					key = row.getCell(colnum).getStringCellValue();
				} else {
					value = row.getCell(colnum).getStringCellValue();
				}
			}
			hm.put(key.trim(), value.trim());
		}
		return hm.get(keyName);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- getTheNewestFile Function Desc :- It retrives the
	 * latest file from a given directory Created ON :- 28-06-2018 Created By :-
	 * BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public File getTheNewestFile(String filePath, String ext) {
		File theNewestFile = null;
		File dir = new File(filePath);
		FileFilter fileFilter = new WildcardFileFilter("*." + ext);
		File[] files = dir.listFiles(fileFilter);

		if (files.length > 0) {
			/** The newest file comes first **/
			Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
			theNewestFile = files[0];
		}

		return theNewestFile;
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- getFileExtension Function Desc :- It retrives the
	 * extension of the input file Created ON :- 28-06-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public String getFileExtension(String f) {
		String ext = "";
		int i = f.lastIndexOf('.');
		if (i > 0 && i < f.length() - 1) {
			ext = f.substring(i + 1).toLowerCase();
		}
		return ext;
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- reporting Function Desc :- It creates a reporting
	 * statement based on the input values Created ON :- 28-06-2018 Created By :-
	 * BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public static void reporting(String status, String desc) {
		if (status.equalsIgnoreCase("pass")) {
			logger.log(LogStatus.PASS, desc);
			reports.flush();
		} else {
			logger.log(LogStatus.FAIL, desc);
			reports.flush();
		}
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- initializeReport Function Desc :- It creates a
	 * reporting statement based on the input values Created ON :- 28-06-2018
	 * Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void initializeReport() throws IOException {
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String title = driver.getTitle() + "-" + fetchConfig("BookMark");
		reports = ExtentFactory.getInstance();
		// reports = new
		// ExtentReports(".\\Reports\\"+getConfig("reportName")+timeStamp.trim()+".html",true);
		// logger=reports.startTest(title);
		logger = reports.startTest(CucumberHooks.testcaseName.trim());
		// reports.flush();

	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- fetchConfig Function Desc :- It will fetch the
	 * respective value from config file for the given input Created ON :-
	 * 28-06-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public String fetchConfig(String key) throws IOException {
		File f = new File(".\\config.property");
		FileInputStream fconfig = new FileInputStream(f);
		Properties prop = new Properties();
		prop.load(fconfig);
		return prop.getProperty(key);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- fetchConfig Function Desc :- It will fetch the
	 * respective value from config file for the given input Created ON :-
	 * 28-06-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public String fetchRepo(String key) throws IOException {
		File f = new File(".\\ObjectRepo.property");
		FileInputStream fconfig = new FileInputStream(f);
		Properties prop = new Properties();
		prop.load(fconfig);
		return prop.getProperty(key);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- invokeBrowser Function Desc :- It will Invoke the
	 * Browser as per users choice Created ON :- 20-07-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void invokeBrowser(String browserName) throws IOException {
		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			// reporting("pass","Chrome browser launched");
			System.out.println("Crossed the function");
		} else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", ".\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
			// reporting("pass","Firefox browser launched");
		} else {
			System.setProperty("webdriver.ie.driver", ".\\drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			// reporting("pass","Internet Explorer Browser Launched");
		}
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- navigateURL Function Desc :- It will Invoke the
	 * Browser as per users choice Created ON :- 20-07-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void navigateURL(String URL) throws IOException {
		driver.get(URL);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- implicitWait Function Desc :- It performs implicit
	 * wait Created ON :- 25-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void implicitWait(int num_of_seconds) {
		driver.manage().timeouts().implicitlyWait(num_of_seconds, TimeUnit.SECONDS);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- reportLogin Function Desc :- It logins to the report
	 * portal Created ON :- 10-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void reportLogin() throws IOException, InterruptedException {
		implicitWait(50);

		// USERNAME
		WebElement usernameTextbox = identifyElement(fetchRepoValue("QV_Login_Username_Textbox"));
		if (isElementExists(usernameTextbox)) {
			performClickOperation(usernameTextbox);
			enterText(usernameTextbox, getConfig("QVUsername"));
			reporting("pass", "Entered Username as " + getConfig("QVUsername").toUpperCase());
		} else {
			reporting("fail", "Login Username Textbox not found in the Login Page");
			System.exit(0);
		}

		// PASSWORD
		WebElement passwordTextbox = identifyElement(fetchRepoValue("QV_Login_Password_Textbox"));
		if (isElementExists(passwordTextbox)) {
			performClickOperation(passwordTextbox);
			enterText(passwordTextbox, getConfig("QVPassword"));
			reporting("pass", "Entered Password");
		} else {
			reporting("fail", "Login Password Textbox not found in the Login Page");
			System.exit(0);
		}

		// LOGIN BUTTON
		WebElement loginButton = identifyElement(fetchRepoValue("QV_Login_Login_Button"));
		if (isElementExists(loginButton)) {
			performClickOperation(loginButton);
		} else {
			reporting("fail", "Login Button not found");
			System.exit(0);
		}
		wait(5);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- checkLoginSuccessful Function Desc :- It cross check
	 * the login whether it is success or failure Created ON :- 10-09-2018 Created
	 * By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void checkLoginSuccessful() throws IOException {
		WebElement homePage = identifyElement(fetchRepo("loginCheck"));
		if (homePage.getText().trim().toLowerCase().equals("accesspoint")) {
			reporting("Pass", "Login Successful");
		} else {
			reporting("Fail", "Login UnSuccessful");
			System.exit(0);
		}
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- reportSelection Function Desc :- It searches for a
	 * particular report and selects it Created ON :- 10-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void reportSelection() throws InterruptedException, IOException {
		// REPORT SELECTING
		WebElement reportSearch = identifyElement(fetchRepo("reportSearch_textbox"));
		performClickOperation(reportSearch);
		enterText(reportSearch, getConfig("reportName"));
		wait(5);

		WebElement goButton = identifyElement(fetchRepo("goButton"));
		performClickOperation(goButton);
		wait(5);

		// Checking Number of Results

		WebElement resultObj = driver.findElement(By.xpath("//div[@id='searchArea']/strong"));
		String resultObjData = resultObj.getText();

		// INVOKING THE REPORT
		WebElement reportToInvoke = identifyElement(fetchRepo("reportToInvoke"));
		performClickOperation(reportToInvoke);
		wait(5);
		reporting("Pass", "Invoked the report :- " + getConfig("reportName"));

	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- clearFilters Function Desc :- It clears all the
	 * filters applied Created ON :- 10-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void clearFilters() throws InterruptedException, IOException {
		WebElement clearFilter = identifyElement(fetchRepo("clearFilter"));
		performClickOperation(clearFilter);
		wait(3);
		reporting("Pass", "Report Cleared");
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- applyFiltersCustomerAccounts Function Desc :- It
	 * searches for a particular report and selects it Created ON :- 10-09-2018
	 * Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void applyFiltersCustomerAccounts() throws InterruptedException, IOException {
		// Bookmark Filter
		Select bookmark = identifyElementDropDown(fetchRepo("bookmarkFilter"));
		bookmark.selectByVisibleText("MF Risk Profile and Activity");
		reporting("pass", "Applied filters as per criteria");
		wait(3);
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- readRepo Function Desc :- It reads the object
	 * repository Created ON :- 24-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void readRepo() throws IOException {
		String objName;
		String objValue;

		File f = new File(".\\repository\\ObjectRepository.xlsx");
		FileInputStream fin = new FileInputStream(f);
		XSSFWorkbook repoWB = new XSSFWorkbook(fin);
		XSSFSheet repoWS = repoWB.getSheet("repo");
		int rowcount = repoWS.getLastRowNum();
		for (int rownum = 0; rownum < rowcount; rownum++) {
			XSSFRow row = repoWS.getRow(rownum);
			objName = row.getCell(0).getStringCellValue();
			objValue = row.getCell(1).getStringCellValue();
			repo.put(objName, objValue);
		}
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- fetchRepovalue Function Desc :- It returns the XPATH
	 * value for respective object Created ON :- 26-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public String fetchRepoValue(String objName) throws IOException {
		return repo.get(objName.trim());
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- reportComparison Function Desc :- Testing of report
	 * Created ON :- 10-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void reportComparison() throws InterruptedException, IOException {

		// DOWNLOADING TO EXCEL
		WebElement exportExcel = identifyElement(fetchRepo("sendToExcel"));
		performClickOperation(exportExcel);
		wait(2);
		reporting("Pass", "Clicked on Download to Excel");

		// WAITING FOR DOWNLOAD TO COMPLETE
		WebDriverWait wait = new WebDriverWait(driver, 100);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(fetchRepo("exportToExcelModelDialog"))));
		wait(8);
		reporting("Pass", "Report got successfully exported to Excel");

		// GET THE LATEST FILE NAME
		File newFile = getTheNewestFile("c:\\users\\" + System.getProperty("user.name").trim() + "\\downloads", "xls");
		System.out.println(newFile.getName());
		String fileName = newFile.getName().toString();

		if (!fileName.isEmpty()) {
			reporting("Pass", "Report got downloaded to " + fetchConfig("downloadsPath"));
			reporting("Pass", "Downloaded File Name is " + fileName);
		} else {
			reporting("Fail", "Problem Occured during report downloading");
			System.exit(0);
		}

		File f = new File(fetchConfig("downloadsPath") + newFile.getName());
		FileInputStream fin = new FileInputStream(f);
		HSSFWorkbook wb = new HSSFWorkbook(fin);
		HSSFSheet ws = wb.getSheet("Sheet1");

		rowcountExcelParent = ws.getLastRowNum();
		System.out.println("RowCount :- " + rowcount);
		reporting("Pass", "Total Number of Rows in the report : " + rowcountExcelParent);

		int dataRowCount = ws.getLastRowNum();

		// READING ALL THE HEADERS
		excelHeaderList = new ArrayList<String>();
		HSSFRow rowHeader = ws.getRow(0);
		int colcount = rowHeader.getPhysicalNumberOfCells();
		System.out.println("Column Count in Excel header :- " + colcount);
		for (int colnum = 0; colnum < colcount; colnum++) {
			String data = rowHeader.getCell(colnum).getStringCellValue();
			excelHeaderList.add(data);
		}

		System.out.println("Total Count of Headers in Excel :- " + excelHeaderList.size());
		for (int index = 0; index < excelHeaderList.size() - 2; index++) {
			headerColNames = headerColNames + excelHeaderList.get(index) + ",";
		}

		headerColNames = headerColNames + excelHeaderList.get(excelHeaderList.size() - 1);

		System.out.println(headerColNames);

		// READIUNG ALL THE VALUES

		HSSFRow excelRow;
		excelList = new ArrayList<String>();
		System.out.println("EXCEL ROWCOUNT FROM DOWNLOADS FOLDER :- " + rowcount);
		for (int rownum = 1; rownum < dataRowCount; rownum++) {
			excelRow = ws.getRow(rownum);
			System.out.println("EXCEL ROW NUMBER IN ITERATION :- " + rownum);
			int colCount = excelRow.getPhysicalNumberOfCells();
			for (int colnum = 0; colnum < colCount; colnum++) {
				System.out.println("COLUMN NUMBER IN ITERATION :- " + colnum);
				if (excelRow.getCell(colnum).getCellType() == 0) {
					data = Double.toString(excelRow.getCell(colnum).getNumericCellValue());
					System.out.println("DATA in ITERATION INTEGER :- " + data);
				} else {

					data = excelRow.getCell(colnum).getStringCellValue();
					System.out.println("DATA in ITERATION STRING :- " + data);
				}
				excelList.add(data);
			}
		}

	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- readQuery Function Desc :- Compare the results
	 * between Report and Database Created ON :- 10-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public String readQuery() throws IOException {
		// READING MAPPING EXCEL
		mappingPath = ".\\Mapping\\mapping.xlsx";
		String report = getConfig("report");
		String tab1 = getConfig("tab");
		System.out.println(report);
		System.out.println(tab1);
		System.out.println("MAPPING PATH :- " + mappingPath);

		File f = new File(mappingPath);
		fin = new FileInputStream(f);

		XSSFWorkbook book = new XSSFWorkbook(fin);
		XSSFSheet sheet = book.getSheet("Sheet1");
		XSSFRow row;

		rowcount = sheet.getLastRowNum();
		System.out.println("RowCount :- " + rowcount);

		String final_check = report.trim() + "-" + tab1.trim();
		System.out.println(final_check);
		for (int rownum = 0; rownum <= rowcount; rownum++) {
			row = sheet.getRow(rownum);
			if (row.getCell(0).getStringCellValue().equalsIgnoreCase(final_check)) {
				System.out.println(row.getCell(0).getStringCellValue());
				query = row.getCell(1).getStringCellValue();
				break;
			}
		}
		System.out.println(query);
		return query;
	}

	public static String readMappingSheet(String featureFileName, String testcaseName) throws IOException {
		// READING MAPPING EXCEL
		mappingPath = ".\\Mapping\\testcase_mapping.xlsx";

		String[] arr = featureFileName.split(" ");

		System.out.println("Feature File Name from readMappingSheet:- " + arr[1]);
		System.out.println("Scenario Name from readMappingSheet :- " + testcaseName);
		File f = new File(mappingPath);
		fin = new FileInputStream(f);

		XSSFWorkbook book = new XSSFWorkbook(fin);
		XSSFSheet sheet = book.getSheet(arr[1].trim());
		XSSFRow row;

		rowcount = sheet.getLastRowNum();
		System.out.println("RowCount From New modified Excel :- " + rowcount);

		for (int rownum = 1; rownum <= rowcount; rownum++) {
			row = sheet.getRow(rownum);
			if (row.getCell(0).getStringCellValue().equalsIgnoreCase(testcaseName.trim())) {
				query = row.getCell(1).getStringCellValue();
			}
		}
		System.out.println(query);
		return query;
	}

	public String getFeatureFileNameFromScenarioId(Scenario scenario) {
		String featureName = "Feature ";
		String rawFeatureName = scenario.getId().split(";")[0].replace("-", " ");
		featureName = featureName + rawFeatureName.substring(0, 1).toUpperCase() + rawFeatureName.substring(1);

		return featureName;
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- compareResults Function Desc :- Compare the results
	 * between Report and Database Created ON :- 10-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void compareResults() throws InterruptedException, IOException, SQLException {
		TDConnection obj = new TDConnection();
		// obj.process(readQuery(), excelList);
		// readMappingSheet

		/*
		 * obj.process(readMappingSheet(TabularReports.featureFileName.trim(),
		 * TabularReports.testcaseName.trim()), excelList); Sanjay
		 */

	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- compareResults Function Desc :- Compare the results
	 * between Report and Database Created ON :- 17-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public boolean isElementExists(WebElement element) {
		if (element.isDisplayed())
			return true;
		else
			return false;
	}

	/*
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@ Function Name :- compareResults Function Desc :- Compare the results
	 * between Report and Database Created ON :- 17-09-2018 Created By :- BADRI
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	 * 
	 * @@@@@@@@
	 */

	public void applyFiltersSelfService() throws InterruptedException, IOException, SQLException {

		Thread.sleep(5000);
		// YEAR
		String year_value = getConfig("Year");
		driver.findElement(By.xpath("//div[@title='" + year_value + "']")).click();
		Thread.sleep(2000);

		// MONTH
		String month_value = getConfig("Month");
		driver.findElement(By.xpath("//div[@title='" + month_value + "']")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"16\"]/div[2]/div/div[1]/div[1]/div[2]/div[3]/div")).click();
		Thread.sleep(3000);

		String dimentionsMain = getConfig("Dimentions");
		if (!(dimentionsMain.equalsIgnoreCase("nil"))) {
			String[] dimentionsMainArray = dimentionsMain.split(";");
			for (String element : dimentionsMainArray) {
				driver.findElement(By.xpath("//div[@title='" + element + "']")).click();
				Thread.sleep(2000);
			}
		}

		// Customer
		String dimentionsCustomer = getConfig("Dimentions-Customer");
		if (!(dimentionsCustomer.equalsIgnoreCase("nil"))) {
			driver.findElement(By.xpath("//div[@title='Customer']/div[3]/div/div")).click();
			Thread.sleep(2000);
			String[] dimentionsCustomerArray = dimentionsCustomer.split(";");
			for (String element : dimentionsCustomerArray) {
				driver.findElement(By.xpath("//div[@title='" + element + "']")).click();
				Thread.sleep(2000);
			}
		}

		// Account
		String dimentionsAccount = getConfig("Dimentions-Account");
		if (!(dimentionsAccount.equalsIgnoreCase("nil"))) {
			driver.findElement(By.xpath("//div[@title='Account']/div[3]/div/div")).click();
			Thread.sleep(2000);
			String[] dimentionsAccountArray = dimentionsAccount.split(";");
			for (String element : dimentionsAccountArray) {
				driver.findElement(By.xpath("//div[@title='" + element + "']")).click();
				Thread.sleep(2000);
			}
		}

		// Transaction
		String dimentionsTransaction = getConfig("Dimentions-Transaction");
		if (!(dimentionsTransaction.equalsIgnoreCase("nil"))) {
			driver.findElement(By.xpath("//div[@title='Transaction']/div[3]/div")).click();
			Thread.sleep(2000);
			String[] dimentionsTransactionArray = dimentionsTransaction.split(";");
			for (String element : dimentionsTransactionArray) {
				driver.findElement(By.xpath("//div[@title='" + element + "']")).click();
				Thread.sleep(2000);
			}
		}

		driver.findElement(By.xpath("//*[@id=\"15\"]/div[2]/div/div[1]/div[1]/div[1]")).click();

		/*
		 * // METRICS
		 * 
		 * 
		 * String metricsMain = getConfig("Metrics");
		 * if(!(metricsMain.equalsIgnoreCase("nil"))) { String[] metricsMainArray =
		 * metricsMain.split(";"); for(String element : metricsMainArray) {
		 * driver.findElement(By.xpath("//div[@title='"+element+"']")).click();
		 * Thread.sleep(2000); } }
		 * 
		 * //Customer String metricsCustomer = getConfig("Dimentions-Customer");
		 * if(!(metricsCustomer.equalsIgnoreCase("nil"))) {
		 * driver.findElement(By.xpath("//div[@title='Customer']/div[3]/div/div")).click
		 * (); Thread.sleep(2000); String[] metricsCustomerArray =
		 * metricsCustomer.split(";"); for(String element : metricsCustomerArray) {
		 * driver.findElement(By.xpath("//div[@title='"+element+"']")).click();
		 * Thread.sleep(2000); } }
		 * 
		 * 
		 * //Account String metricsAccount = getConfig("Dimentions-Account");
		 * if(!(dimentionsAccount.equalsIgnoreCase("nil"))) {
		 * driver.findElement(By.xpath("//div[@title='Account']/div[3]/div/div")).click(
		 * ); Thread.sleep(2000); String[] metricsAccountArray =
		 * metricsAccount.split(";"); for(String element : metricsAccountArray) {
		 * driver.findElement(By.xpath("//div[@title='"+element+"']")).click();
		 * Thread.sleep(2000); } }
		 * 
		 * 
		 * //Transaction String metricsTransaction =
		 * getConfig("Dimentions-Transaction");
		 * if(!(metricsTransaction.equalsIgnoreCase("nil"))) {
		 * driver.findElement(By.xpath("//div[@title='Transaction']/div[3]/div")).click(
		 * ); Thread.sleep(2000); String[] metricsTransactionArray =
		 * metricsTransaction.split(";"); for(String element : metricsTransactionArray)
		 * { driver.findElement(By.xpath("//div[@title='"+element+"']")).click();
		 * Thread.sleep(2000); } }
		 * 
		 */

	}

}
