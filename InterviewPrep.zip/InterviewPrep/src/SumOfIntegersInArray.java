
public class SumOfIntegersInArray {

	public static void main(String[] args) {
		
		String st = "1";
	
	}

}
