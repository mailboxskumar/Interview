package javaprograming;

public class SwapObjectsInJava {

	public static void main(String[] args) {
		
	}

}
