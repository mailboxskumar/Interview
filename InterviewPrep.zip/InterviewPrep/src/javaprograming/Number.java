package javaprograming;

public class Number {

	private static Object obj; 
	Integer itr =  null;
	
	public static void main(String[] args) {
		System.out.println("Magic");
		System.out.println("Value of object obj is : " + obj);
	}

}
