package javaprograming;

public class LinkedListWithoutUsingLinkedList {

	int a;
	int b;

	public static void main(String[] args) {

	}

	public class ChildClass {

	}

}
