package selenium.db.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConnector {

	public static void main(String[] args) throws Exception {
		Connection conn = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		String query = "select CASE_NUM, ALERT_ID from ifadb.ifa_alert_detail_txn where ALERT_ID like '77c8e80e-bac0-4a9a-8d2c-f4cddc959f5317%'";
		// String query = "select count(*) from ifadb.ifa_alert_detail_txn where
		// ALERT_ID like '77c8e80e-bac0-4a9a-8d2c-f4cddc959f5317%'";

		// Class.forName("com.mysql.jdbc.Driver");
		Class.forName("org.mariadb.jdbc.Driver");
		// conn = DriverManager.getConnection("jdbs:mysql://localhost:3306/testdb",
		// "username", "password");
		// conn = DriverManager.getConnection("jdbs:mariadb://localhost:3306/testdb",
		// "username", "password");
		conn = DriverManager.getConnection("jdbc:mariadb://10.91.134.133:6603/iwfdb", "iwfdb", "Password_1");

		stmt = conn.createStatement();
		resultSet = stmt.executeQuery(query);
		int colCnt = resultSet.getMetaData().getColumnCount();
		resultSet.getFetchSize();
		// int rowCnt = resultSet.getInt(1);

		// System.out.println(rowCnt);
		System.out.println(colCnt);

		int rouCounter = 0;
		while (resultSet.next()) {
			rouCounter++;

			System.out.println(resultSet.getString(1) + "� " + resultSet.getString(2));
			System.out.println(resultSet.getString("ALERT_ID"));
		}
		System.out.println("No of Records : " + rouCounter);
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (Exception e) {
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception e) {
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
			}
		}

	}

}
