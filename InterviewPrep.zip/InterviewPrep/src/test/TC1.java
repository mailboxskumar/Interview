package test;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.ObjectRepo;

public class TC1 {

	public static WebDriver driver;
	public static TestData TD = new TestData();
	public static ObjectRepo OR = new ObjectRepo();

	public static void main(String[] args) throws Exception {
		intiDriver(TD.testBrowser);
		googleSearch("automation", "automation testing");

		// navigateToAppURL(TD.appURL);
		// spiceJetTravelAgentLogin("xyz","xyz");

		// loginToApp(TD.userName, TD.password);
		// seachCustomer(TD.searchType, TD.searchVal);

		// handelAlert();

		// closeDriver();
	}

	public static void intiDriver(String stBrowserName) {
		switch (stBrowserName) {
		case "chrome":
			System.setProperty("webdriver.chrome.driver", TD.chromeDriverPath); // Sets Chrome Driver
			driver = new ChromeDriver();
//		case "firefox":
//			System.setProperty("webdriver.firefox.driver", TD.firefoxDriverPath); // Sets Firefox Driver
//			driver = new FirefoxDriver();
		}
	}

	public static void navigateToAppURL(String strURL) {
		driver.manage().window().maximize(); // Maximize Browser Window
		// driver.navigate().to(strURL); // Open application URL- Option 1
		driver.get(strURL); // Open application URL- Option 2
	}

	public static void spiceJetTravelAgentLogin(String strUser, String strPassword) throws InterruptedException {
		WebElement element = driver.findElement(By.id("ctl00_HyperLinkLogin"));
		// Use action class to mouse hover on Text box field
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.linkText("Travel Agent Login")).click();
	}

	public static void loginToApp(String strUser, String strPassword) {
		driver.findElement(By.xpath(OR.txtUserName)).sendKeys(strUser);
		driver.findElement(By.xpath(OR.txtPassword)).sendKeys(strPassword);
		driver.findElement(By.xpath(OR.btnLogin)).click();
	}

	public static void seachCustomer(String searchType, String searchVal) {
		driver.findElement(By.xpath(OR.txtSearchType)).click();
		new Select(driver.findElement(By.xpath(OR.lstSearchType))).selectByVisibleText(searchType);
		// driver.findElement(By.xpath(OR.txtSearchType)).sendKeys(searchType);
		driver.findElement(By.xpath(OR.txtSearchVal)).sendKeys(searchVal);
		driver.findElement(By.xpath(OR.btnSeach)).click();
	}

	public static void handelAlert() throws Exception {
		driver.get("http://demo.guru99.com/test/delete_customer.php");
		driver.findElement(By.name("cusid")).sendKeys("53920");
		driver.findElement(By.name("submit")).submit();

		Alert alert = driver.switchTo().alert();

		String alertText = alert.getText();
		System.out.println(alertText);

		Thread.sleep(5000);

		// Implicit wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Explicit wait
		WebDriverWait wait = new WebDriverWait(driver, 20);
		WebElement custId = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cusid")));
		custId.clear();

		// Fluent Wait
		Wait wait1 = new FluentWait(driver).withTimeout(30, TimeUnit.SECONDS).pollingEvery(10, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		alert.accept();

	}

	// Take screenshot
	public static void takeScreenShot(String fileWithPath) throws Exception {
		TakesScreenshot screenShot = ((TakesScreenshot) driver);
		File srcFile = screenShot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(fileWithPath);
		FileUtils.copyFile(srcFile, destFile);
	}

	// Handle Scrolling in Selenium
	public static void handleWebPageScrolling() {

		// Scenario 1: To scroll down the web page by pixel

		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.get("https://timesofindia.com");

		js.executeScript("window.scrollBy(0,1000)"); // This will scroll down the page by 1000 pixel vertical
		js.executeScript("window.scrollBy(1000,0)"); // This will scroll down the page by 1000 pixel horizontally

		// Scenario 2: To scroll down the web page by the visibility of the element.

		// Find element by link text and store in variable "Element"
		WebElement Element = driver.findElement(By.linkText("Linux"));

		// This will scroll the page till the element is found
		js.executeScript("arguments[0].scrollIntoView();", Element);

		// Scenario 3: To scroll down the web page at the bottom of the page.

		// This will scroll the web page till end.
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

	}

	// Handling dynamic xpath in google search
	public static void googleSearch(String strSearchText , String strClickText) {
		driver.get("https://google.co.in");
		driver.findElement(By.id("lst-ib")).sendKeys(strSearchText);

		List<WebElement> list = driver
				.findElements(By.xpath("//ul[@role='listbox']//li/descendant::div[@class='sbqs_c']"));
		System.out.println("Total Suggestion Count :: " + list.size());
		for (int i = 0; i < list.size(); i++) {
			System.out.println("Element: " + i + " is : " + list.get(i).getText());
			if (list.get(i).getText().contains(strClickText)) {
				list.get(i).click();
				break;
			}
		}
	}
	

	public static void closeDriver() {
		driver.close();
		driver.quit();
	}

}
