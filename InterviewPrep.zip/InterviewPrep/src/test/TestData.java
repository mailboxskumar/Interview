package test;

public class TestData {
	String testBrowser = "chrome";
	String chromeDriverPath = "C:\\Sanjay\\drivers\\chromedriver_win32\\chromedriver_2.33.exe";
	String firefoxDriverPath = "C:\\Sanjay\\drivers\\firefox\\geckodriver.exe";
	
	String appURL = "http://spicejet.com/";
			//"https://iservesit.corp.dbs.com:8543/idiserve/login";
	
	String userName = "CCACSO2";
	String password = "Password1";
	
	String searchType = "CIF No.";
	String searchVal = "6042618";
	
	
}
