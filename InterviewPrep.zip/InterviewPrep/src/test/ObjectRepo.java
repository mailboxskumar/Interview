package test;

public class ObjectRepo {

	String txtUserName = "//*[@id='userName']";
	String txtPassword = "//*[@id='password']";
	String btnLogin = "//*[@id='login_Login_button']";
	
	String txtSearchType = "//*[@id=\'headerSearch_select\']";
	String lstSearchType = "//*[@id=\'search_Option_Container\']";
	String txtSearchVal = "//*[@id='headerSearch_text']";
	String btnSeach = "//*[@id='headerSearch_button']";
}
