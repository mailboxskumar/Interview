package com.wb.java_af.web.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.wb.java_af.qc.QCDetails;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LogingPageSteps {
	
	
	@Given("^I am in Webster online login page$")
	@QCDetails(testCaseId = 23949357)
	public void i_am_in_Webster_online_login_page() {
		System.out.println(ConcurrentEngines.getEngine().getWebDriver().getTitle());
				
	}
	
	@Then("^I enter username \"(.*?)\"$")
	public void i_enter_username(String username) {
		EventFiringWebDriver driver = ConcurrentEngines.getEngine().getWebDriver();
		System.out.println("Driver is "+driver);
		System.out.println("browser" + ConcurrentEngines.getEngine().getBrowser());
		System.out.println("Version" + ConcurrentEngines.getEngine().getBrowserVersion());
		ExtentTest report = ExtentTestManager.getTest();
		
		report.info("WOL application is launched.");
		driver.findElement(By.name("username")).sendKeys(username);
		report.info("Entered the username");
		ConcurrentEngines.getEngine().getWait().waitForPageReadyState();
		driver.findElement(By.name("submit1")).click();
		report.info("Clicked on the go button");
	}
	
	@And("^I enter the security \"(.*?)\"$")
	public void i_enter_security_the_answer(String answer) {
		EventFiringWebDriver driver = ConcurrentEngines.getEngine().getWebDriver();
		ExtentTest report = ExtentTestManager.getTest();
		ConcurrentEngines.getEngine().getWait().waitForPageReadyState();
		driver.findElement(By.id("answer__input")).sendKeys(answer);
		report.info("Entered the answer as" +answer);
	}
	
	@And("^I enter the password as \"(.*?)\"$")
	public void i_enter_password(String password) {
		ConcurrentEngines.getEngine().getWait().waitForPageReadyState();
		EventFiringWebDriver driver = ConcurrentEngines.getEngine().getWebDriver();
		ExtentTest report = ExtentTestManager.getTest();
		driver.findElement(By.id("password__input")).sendKeys(password);
		report.info("Entered the password as" +password);
	}
	
	@When("^I click on Login button$")
	public void i_click_on_login_button() {
		EventFiringWebDriver driver = ConcurrentEngines.getEngine().getWebDriver();
		ExtentTest report = ExtentTestManager.getTest();
		driver.findElement(By.id("continueButton_ff__buttonText")).click();
		report.info("Clicked on the Continue button.");
		ConcurrentEngines.getEngine().getWait().waitForPageReadyState();
	}
	
	@Then("^I see username and password textbox$")
	public void i_see_username_and_password_textbox() throws Throwable {
		ExtentTest report = ExtentTestManager.getTest();
		WebDriver driver = ConcurrentEngines.getEngine().getWebDriver();
		try {
			driver.findElement(By.name("username")).isDisplayed();
			driver.findElement(By.name("password")).isDisplayed();
			report.info("Username and password fields are found.");
		} catch (NoSuchElementException | NullPointerException ne) {
			report.fail("Username and password fields are not found.");
			LogUtility.logInfo("Test could not find the username and or password fields.");
		}
	}

	@Then("^I see login button$")
	public void i_see_login_button() throws Throwable {
		ExtentTest report = ExtentTestManager.getTest();
		WebDriver driver = ConcurrentEngines.getEngine().getWebDriver();
		try {
			driver.findElement(By.id("continueButton_ff__buttonText")).isDisplayed();
			report.info("Username and password fields are found.");
		} catch (NoSuchElementException | NullPointerException ne) {
			report.fail("Username and password fields are not found.");
			LogUtility.logInfo("Test could not find the username and or password fields.");
		}
	}

}
