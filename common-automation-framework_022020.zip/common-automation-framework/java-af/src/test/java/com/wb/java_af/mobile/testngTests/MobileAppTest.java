package com.wb.java_af.mobile.testngTests;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.testbases.TestNgBase;

import io.appium.java_client.AppiumDriver;

public class MobileAppTest extends TestNgBase {

	@Test
	public void loginToWOLApplication() {
		AppiumDriver<RemoteWebElement> appiumDriver = ConcurrentEngines.getEngine().getAppiumDriver();
		ExtentTest report = ExtentTestManager.getTest();
		
		appiumDriver.launchApp();
		report.info("WOL application is launched.");
		appiumDriver.findElement(By.xpath("//*[@resourceid='com.malauzai.websterbank:id/username_entry']")).sendKeys("webuser1007");
		report.info("Entered the username");
		appiumDriver.findElement(By.id("passwordFieldAccessibilityIdentifier")).sendKeys("password");
		report.info("Entered the password");
		appiumDriver.findElement(By.id("LoginButtonAccessibilityIdentifier")).click();
		report.info("Clicked on the login button.");
	}

}
