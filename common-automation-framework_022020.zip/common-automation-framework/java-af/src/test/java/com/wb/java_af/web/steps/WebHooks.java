package com.wb.java_af.web.steps;

import java.util.List;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.testbases.CucumberTestBase;
import com.wb.java_af.utilities.LogUtility;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class WebHooks extends CucumberTestBase {

	@Before(order = 0)
	public void beforeHook(Scenario scenario) throws Exception {
		LogUtility.startScenario(scenario.getName());

	}

	@After(order = 0)
	public void afterHook(Scenario scenario) {
		boolean softAssertionFlag = false;
		List<String> errorList = ConcurrentEngines.getEngine().getSoftErrors();
		softAssertionFlag = (errorList != null && errorList.size() > 0) ? true : softAssertionFlag;
		reportTearDownMethod(scenario, softAssertionFlag);
		LogUtility.endScenario(scenario.getName());

	}
}
