package com.wb.java_af.mobile.steps;

import com.aventstack.extentreports.ExtentTest;
import com.wb.java_af.pages.UnitTestLoginPage;
import com.wb.java_af.pages.UnitTestTransactionsHistoryPage;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.utilities.LogUtility;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TransactionDetailsSettingsSteps{
	
	UnitTestLoginPage obj = new UnitTestLoginPage();
	UnitTestTransactionsHistoryPage trans = new UnitTestTransactionsHistoryPage();
	ExtentTest report = ExtentTestManager.getTest();
	
	@When("^I click on Aux-gear button$")
	public void i_click_on_Aux_gear_button() throws Throwable {
		LogUtility.logInfo("User is in Menu page ");
		trans.clickSettingbtn();
        report.info("Succsessfully clicked on Aux-gear button");
		LogUtility.logInfo("User able to click on Aux-gear button");	
	}
	
	@Then("^I verify Menu page is displayed$")
	public void i_verify_Menu_page_is_displayed() throws Throwable {
		LogUtility.logInfo("***********User is in Menu page********** ");
		trans.verifyMenuHead();
		report.info("User able to see the menu head text in the page");
		LogUtility.logInfo("User able to see the menu head text");
	}

	
	@When("^I click on Preferences button$")
	public void i_click_on_Preferences_button() throws Throwable {
		trans.clickOnPreferencebtn();
		report.info("User able to click on preferences button in Menu page");
		LogUtility.logInfo("User able to click on preferences button");
	}

	@Then("^I Verify required settings available like prefrences,change accountorder,set startpage,passcode login,account preferences$")
	public void i_Verify_required_settings_available() throws Throwable {
		LogUtility.logInfo("User is able to verify the settings options");
		report.info("User is able to verify the settings options like prefrences,change accountorder,set startpage,passcode login,account preferences ");
		trans.verifypreferencesPage();	
	}

	
	@Then("^I Navigate back to preference menu screen$")
	public void i_Navigate_back_to_preference_menu_screen() throws Throwable {
		trans.clickOnBackbtn();
		LogUtility.logInfo("User is ableto click on back button and navigate to preferences menu screen");
		report.info("User is ableto click on back button and navigate to preferences menu screen");
	}
	
	
	@When("^I click on Change Account Order$")
	public void i_click_on_Change_Account_Order() throws Throwable {
		trans.clickOnChangeAccountOrder();
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^I need to verify all the accounts should display with CLOSE and SAVE buttons$")
	public void i_need_to_verify_all_the_accounts_should_display_with_CLOSE_and_SAVE_buttons() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		trans.listOfAccountsDisplayed();
	}

	@When("^I Tap on Close or Change Account Order Button$")
	public void i_Tap_on_Close_or_Change_Account_Order_Button() throws Throwable {
		trans.clickOnCloseButton();
	    // Write code here that turns the phrase above into concrete actions
	    
	}
    }
