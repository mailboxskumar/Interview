package com.wb.java_af.mobile.steps;

import com.aventstack.extentreports.ExtentTest;
import com.perfecto.reportium.client.ReportiumClient;
import com.wb.java_af.pages.UnitTestLoginPage;
import com.wb.java_af.qc.QCDetails;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {

	ExtentTest report = ExtentTestManager.getTest();
	UnitTestLoginPage login = new UnitTestLoginPage();
	ReportiumClient reportiumClient = ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance();

	
	@Given("^I am in Webster Mobile login page$")
	@QCDetails(testCaseId = 23949357)
	public void i_am_in_Webster_online_login_page() throws Exception {
		reportiumClient.stepStart("I am in Webster Mobile login page");
		try {
			login.verifyWebsterMobileLoginPage();
			report.createNode("WebsterBank Mobile App is launched");
			report.pass("WebsterBank Mobile App is launched");
		}catch(Exception e) {
			report.fail("WebsterBank Mobile App not launched "+e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}
	
	@Then("^I see username and password textbox$")
	public void i_see_username_and_password_textbox() throws Throwable {
		reportiumClient.stepStart("I see username and password textbox");
		try {
			login.verifyUserNameTextField();
			login.verifyPasswordTextField();
			report.createNode("Webster bank app Username and Password are displayed");
			report.pass("Webster bank app Username and Password are displayed");
		}catch(Exception e) {
			report.fail("Username/Password fields did not verified" +e);
			e.printStackTrace();
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^I see login button$")
	public void i_see_login_button() throws Throwable {
		reportiumClient.stepStart("I see login button");
		try {
			login.verifyLogInButton();
			report.pass("LogIn button displayed");
			report.createNode("LogIn button displayed");
		}catch(Exception e) {
			report.fail("Login button did not verified "+e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}
	
	@When("^I enter username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void i_enter_username_and_password(String userName, String password) throws Throwable {
		reportiumClient.stepStart("I enter username "+userName+" and password "+password);
		try {
			login.enterUserName(userName);
			report.info("Entered the user name as "+userName);
			report.createNode("Entered the user name as "+userName);
			login.enterPassword(password);
			report.createNode("Entered the user name as "+userName);
			report.info("Entered the password as "+password);
			report.pass("Username "+userName+ " and Password entered into text field");
		}catch(Exception e) {
			report.fail("Issue while entering the Username/Password "+e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@And("^I clicked on login button$")
	public void i_clicked_on_login_button() throws Throwable {
		reportiumClient.stepStart("I clicked on login button");
		try {
			login.clickLogin();
			report.createNode("Application successfully logged in");
			report.pass("Application successfully logged in");
		}catch(Exception e) {
			report.fail("App did not logged in "+e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}
}
