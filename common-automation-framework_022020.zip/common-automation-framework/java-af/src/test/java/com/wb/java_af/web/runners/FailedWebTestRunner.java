package com.wb.java_af.web.runners;

import com.wb.java_af.testbases.CucumberTestBase;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = "@target/rerun.txt", glue = "com.wb.java_af.web.steps", plugin = { "pretty",
		"json:target/cucumber-reports/cucumber.json",
		"rerun:target/cucumber-reports/rerun.txt" }, monochrome = true, strict = false, dryRun = false)

public class FailedWebTestRunner extends CucumberTestBase {
}