package com.wb.java_af.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class UnitTestTransactionsHistoryPage {

	UnitTestLoginPage loginPage = new UnitTestLoginPage();
	UnitTestViewAccountsPage viewAccountsPage = new UnitTestViewAccountsPage();

	public UnitTestTransactionsHistoryPage() {
		PageFactory.initElements(new AppiumFieldDecorator(ConcurrentEngines.getEngine().getAppiumDriver()), this);
	}

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_auxmenu")
	@iOSFindBy(xpath = "//*[@label=\"Auxiliary Menu\"]")
	@CacheLookup
	protected MobileElement btnAux;

	// preferences Menu locators

	@AndroidFindBy(xpath = "//*[text()=\"Preferences\"]")
	@iOSFindBy(xpath = "//*[@label=\"MENU\"]")
	@CacheLookup
	protected MobileElement backbutton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Set Start Page' and @enabled='true']")
	@iOSFindBy(xpath = "//*[@label=\"Set Start Page\"]")
	@CacheLookup
	protected MobileElement setStartPageButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Change Account Order' and @enabled='true']")
	@iOSFindBy(xpath = "//*[@label=\"Change Account Order\"]")
	@CacheLookup
	protected MobileElement changeAccountOrderButon;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeOther[@name = 'PREFERENCES' and @enabled = 'true']")
	@CacheLookup
	protected MobileElement preferencestext;

	@AndroidFindBy(xpath = "//*[text()=\"Login Type\"]")
	@iOSFindBy(xpath = "//*[@value=\"Touch ID\"]")
	@CacheLookup
	protected MobileElement touchIdButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Login Type' and @enabled='true']")
	@iOSFindBy(xpath = "//*[@value=\"Passcode Login\"]")
	@CacheLookup
	protected MobileElement passCodeLoginButton;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label=\"MENU\"]")
	@CacheLookup
	protected MobileElement MenuHead;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_personalize")
	@iOSFindBy(xpath = "//*[@label=\"Preferences\"]")
	@CacheLookup
	protected MobileElement preferenceButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Account Preferences' and @enabled='true']")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	@CacheLookup
	protected MobileElement accountpreferencesTxt;

	// change account order mobile elements

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Change Account Order' and @enabled='true']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Change Account Order' and @enabled ='true']")
	protected MobileElement changeAccountOrderbutton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Change Account Order' and @enabled='true']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name = 'Change Account Order' and @enabled ='true']")
	@CacheLookup
	protected MobileElement changeAccountOrderHeadTxt;

	// @AndroidFindBy(xpath = "//android.widget.TextView[@text = 'CLOSE' and
	// @enabled='true']")
	// @iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	// @CacheLookup
	// protected MobileElement closeButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'CLOSE' and @enabled='true']")
	@iOSFindBy(xpath = "//*[@label=\"Close\"]")
	@CacheLookup
	protected List<RemoteWebElement> closeButton1;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'SAVE' and @clickable='true']")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	@CacheLookup
	protected MobileElement saveButton;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id, 'com.malauzai.websterbank') and @enabled = 'true']")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	@CacheLookup
	protected List<RemoteWebElement> listofAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/accounts")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	@CacheLookup
	protected MobileElement displayedAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_cancel")
	// @iOSFindBy(xpath = "//*[@label=\"Change Account Order\"]")
	@CacheLookup
	protected MobileElement AccountCloseButton;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_accept")
	@iOSFindBy(xpath = "//*[@label=\"Account Preferences\"]")
	@CacheLookup
	protected MobileElement AccountSaveButton;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_drag_item")
	@iOSFindBy(xpath = "//*[@label=\"Change Account Order\"]")
	@CacheLookup
	protected MobileElement DragButton;

	public boolean verifyMenuHead() {
		String menuheadtxt = MenuHead.getText();
		LogUtility.logInfo("Menu head text is" +  MenuHead.getText());
		String exp_Menuheadtxt = "MENU";
		return menuheadtxt.contains(exp_Menuheadtxt);
	}

	public void clickSettingbtn() {
		ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
		btnAux.click();
		ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
	}

	public void clickOnPreferencebtn() {
		ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
		try {
			LogUtility.logInfo("user tried to click on the preference button");
			preferenceButton.click();
		} catch (Exception e) {
			ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
			LogUtility.logInfo("user tried to click on the preference button");
			preferenceButton.click();
		}
	}

	public void clickOnBackbtn() {
		ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
		try {
			LogUtility.logInfo("user tried to click on BACK button in android device");
			ConcurrentEngines.getEngine().getAppiumDriver().navigate().back();
			ConcurrentEngines.getEngine().getWait().staticWait(3);
			LogUtility.logInfo("user  clicked on BACK button in android device");
		} catch (Exception e) {
			if (backbutton.isDisplayed())
				LogUtility.logInfo("user tried to click on BACK button in ios device");
			backbutton.click();
			ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
			LogUtility.logInfo("user  clicked on BACK button in ios device");
		}
	}

	public boolean verifypreferencesPage() {
		ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
		String preferenceheadtxt = preferencestext.getText();
		String exp_preferenceheadtxt = "PREFERENCES";
		System.out.println("prefernces text is" + preferenceheadtxt);
		ConcurrentEngines.getEngine().getWait().staticWait(14);
		String accountorder = changeAccountOrderButon.getText();
		String exp_accountorder = "Change Account Order";
		System.out.println("change order text is:  " + accountorder);

		String startpage = setStartPageButton.getText();
		String exp_setstart = "Set Start Page";
		System.out.println("set startbutton text is: " + startpage);

		String passcode = passCodeLoginButton.getText();
		System.out.println("passcodelogin  text is: " + passcode);
		String exp_passcode = "Passcode Login";

		String accountpreferncetxt = accountpreferencesTxt.getText();
		String exp_accpreferencetxt = "Account Preferences";
		System.out.println("account prefernce  text is" + accountpreferncetxt);

		return preferenceheadtxt.equals(exp_preferenceheadtxt) && accountorder.equals(exp_accountorder)
				&& startpage.equals(exp_setstart) && passcode.contains(exp_passcode)
				&& accountpreferncetxt.equals(exp_accpreferencetxt);
	}

	public void clickOnChangeAccountOrder() {
		ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
		try {
			LogUtility.logInfo("user tried to click on change account order button");
			changeAccountOrderbutton.click();
		} catch (Exception e) {
			ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
			LogUtility.logInfo("user tried to click on change account order button");
			changeAccountOrderbutton.click();
		}
		viewAccountsPage.delay(2000);
	}

	public boolean listOfAccountsDisplayed() throws InterruptedException {
		String value = changeAccountOrderHeadTxt.getText();
		LogUtility.logInfo("Account order text is :" + value);
		Thread.sleep(4000);
		if (closeButton1.size() == 0) {
			int i;
			for (i = 1; i > 0;) {
				String list = ConcurrentEngines.getEngine().getAppiumDriver()
						.findElement(By.xpath("(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])["
								+ i + "]"))
						.getText();
				String hidden_value = ConcurrentEngines.getEngine().getAppiumDriver()
						.findElement(By.id("com.malauzai.websterbank:id/btn_drag_item"))
						.getAttribute("hidden");
				LogUtility.logInfo("name of the accounts displayed is :" + list);
				if (hidden_value.contains("false")) {
					i++;
					if (i == 8) {
						break;
					}
				} else {
					break;
				}

			}
			LogUtility.logInfo("close button is enabled because the test is executed in android device");
			String close = AccountCloseButton.getText();
			String exp_closetext = "CLOSE";
			System.out.println("Close Button text is:  " + close);

			String save = AccountSaveButton.getText();
			String exp_save = "SAVE";
			System.out.println("save button text is: " + save);

			return close.equals(exp_closetext) && save.equals(exp_save) && displayedAccounts.isEnabled();
		} else if (preferencestext.isEnabled()) {
			int i;
			for (i = 1; i > 0;) {
				String ele = ConcurrentEngines.getEngine().getAppiumDriver()
						.findElement(By.xpath("//XCUIElementTypeCell[" + i + "]/XCUIElementTypeStaticText[1]"))
						.getText();
				LogUtility.logInfo("name of the accounts displayed is :" + ele);
				RemoteWebElement button = ConcurrentEngines.getEngine().getAppiumDriver()
						.findElement(By.xpath("//XCUIElementTypeCell[" + i + "]/XCUIElementTypeButton[1]"));
				if (button.isEnabled()) {
					i++;
				} else {
					break;
				}

			}
			return preferencestext.isEnabled();
		}
		return preferencestext.isEnabled();
	}

	public void clickOnCloseButton() {
		ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
		if (closeButton1.size() == 0) {
			LogUtility.logInfo("user tried to click on Account Close button");
			AccountCloseButton.click();
		} else {
			ConcurrentEngines.getEngine().getWait().getDefaultWaitSeconds();
			LogUtility.logInfo("user tried to click on Accounts Close button");
			viewAccountsPage.delay(3000);
			changeAccountOrderbutton.click();
		}

	}

}