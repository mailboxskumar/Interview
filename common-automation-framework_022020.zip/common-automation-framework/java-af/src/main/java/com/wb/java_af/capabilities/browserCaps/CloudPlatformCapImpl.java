package com.wb.java_af.capabilities.browserCaps;

import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONObject;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

public class CloudPlatformCapImpl implements BrowserCaps{

	public InternetExplorerOptions options;
	String filePath, env, platformHost;
	
	public CloudPlatformCapImpl(String filePath, String env, String platformHost) {
		this.filePath = filePath;
		this.env = env;
		this.platformHost = platformHost;
	}
	
	/**
	 *  
	 * Sets up chrome options to launch chrome with specified capabilities passed in json.
	 * Add args, extensions, encodedExtensions to chrome
	 * 
	 * @return Chrome Options
	 * @author Bharat Pandey
	 * 
	 * @see com.wb.java_af.capabilities.browserCaps.BrowserCaps#getCaps()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public DesiredCapabilities getCaps() {
		JSONObject environment = BrowserCaps.parseJsonFile(filePath, env);
		String defaultPlatformHost = (String) environment.keySet().stream().findFirst().orElse(null);
		Map<String, Object> envCapabilities = null;

		DesiredCapabilities capabilities = new DesiredCapabilities();
		if (platformHost == null || platformHost == "") {
			platformHost = defaultPlatformHost;
		}
		try {
			envCapabilities = (Map<String, Object>) environment.get(platformHost);

			Iterator<Map.Entry<String, Object>> it = envCapabilities.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, Object> pair = it.next();
				String value = pair.getValue().toString();
				boolean boxedValue = false;
				if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
					boxedValue = Boolean.parseBoolean(value);
					capabilities.setCapability(pair.getKey().toString(), boxedValue);
				} else {
					capabilities.setCapability(pair.getKey().toString(), pair.getValue().toString());
				}
			}
		} catch (Exception e) {
			LogUtility.logException(
					"parseBrowserCapabilities", "Error parsing the browser capability. Please see if the browser : "
							+ env + ", Version:" + platformHost + " is setup properly at " + filePath,
					e, LoggingLevel.ERROR, true);
		}

	return capabilities;
	}
	
	public static void main(String[] args) {
		new CloudPlatformCapImpl("capabilities/browserCapabilities.json", "onFutureCloud", "Windows 10:Chrome latest").getCaps();
	}
}
