package com.wb.java_af.reporting;

import java.io.File;
import java.util.Properties;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.wb.java_af.setup.testparameters.EnvironmentParameters;
import com.wb.java_af.testbases.CucumberTestBase;
import com.wb.java_af.testbases.TestBase;
import com.wb.java_af.utilities.TestConstants;

public class ExtentManager {

	private static ExtentHtmlReporter htmlReporter;
	private static ExtentReports extent;
	private static Properties props;
	public static String reportPath, reportDirectoryName, reportFileName, seleniumVersion, reportingConfig,
			applicationName;

	public synchronized static ExtentReports getInstance(String directoryName) {
		String os = EnvironmentParameters.getShortOsName();
		if (TestBase.props != null) {
			props = TestBase.props;
		} else {
			props = CucumberTestBase.props;
		}

		reportFileName = System.getProperty("environment") + "-" + props.getProperty("report.file.name");
		seleniumVersion = props.getProperty("selenium.version");
		applicationName = props.getProperty("application.name");
		reportDirectoryName = props.getProperty("report.directory." + os);
		reportingConfig = props.getProperty("reporting.config.name." + os);

		reportPath = new File(System.getProperty(TestConstants.USER_DIR)) + reportDirectoryName;

		if (extent == null) {
			htmlReporter = new ExtentHtmlReporter(reportPath + directoryName + reportFileName);
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Application", applicationName);
			extent.setSystemInfo("Run Platform", props.getProperty("run.type"));
			extent.setSystemInfo("Environment", System.getProperty("environment"));
			htmlReporter.config().setDocumentTitle(applicationName + " Execution Test Report");
			htmlReporter.config().setReportName(applicationName.toUpperCase() + " Script Execution Report");
			htmlReporter.config().setTheme(Theme.DARK);
			htmlReporter.config().enableTimeline(true);
		}
		return extent;
	}

	public synchronized static ExtentReports getInstance() {
		return extent;
	}

}
