package com.wb.java_af.perfecto;

import java.util.HashMap;
import java.util.Map;

/**
 * Instantiates the Perfecto params to be passed to a javascript executor
 * 
 * @author Bharat Pandey
 *
 */
public class PerfectoParameters {

	private Map<String, Object> params;
	
	public PerfectoParameters() {
		params = new HashMap<String, Object>();
	}
	
	public <T extends Object> PerfectoParameters(String parameterType, T parameterValue) {
		params = new HashMap<String, Object>();
		params.put(parameterType, parameterValue);
	}
	
	public <T extends Object> void addParameter(String parameterType, String parameterValue) {
		params.put(parameterType, parameterValue);
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}
	
}
