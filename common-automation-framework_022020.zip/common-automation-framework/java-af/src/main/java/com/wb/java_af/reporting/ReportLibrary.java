package com.wb.java_af.reporting;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.testbases.CucumberTestBase;
import com.wb.java_af.utilities.LogUtility;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class ReportLibrary {

	private Engine engine;
	private String runType = CucumberTestBase.props.getProperty("run.type");
	private boolean takeScreenshotPassFlag = Boolean
			.parseBoolean(CucumberTestBase.props.getProperty("screenshot.passed.step"));

	private boolean takeScreenshotFailFlag = Boolean
			.parseBoolean(CucumberTestBase.props.getProperty("screenshot.failed.step"));

	private SoftAssert softAssert = new SoftAssert();

	public SoftAssert getSoftAssert() {
		return softAssert;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public ReportLibrary(Engine engine) {
		this.engine = engine;
	}

	/**
	 * Adds Report Info status to extent report logger.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */

	public void reportInfo(String message) {
		ExtentTestManager.getTest().log(Status.INFO, message);
		LogUtility.logInfo(message);
		if (runType.equals("perfectoMobile"))
			reportComment(message);
	}

	/**
	 * Adds Report Pass status to extent report logger and captures page visible
	 * area screenshot
	 * 
	 * @author Sanjay Samantaray
	 * @param message
	 */

	public void reportPass(String message) {
		LogUtility.logInfo(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					true);
		if (takeScreenshotPassFlag)
			passedLogWithScreenshot(message);
		else
			ExtentTestManager.getTest().log(Status.PASS, message);
	}

	/**
	 * Adds Report pass status to extent report logger and captures complete page
	 * screenshot by scrolling
	 * 
	 * @author Sanjay Samantaray
	 * @param message
	 */

	public void reportPassWithFullPageScreenshot(String message) {
		LogUtility.logInfo(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					true);
		if (takeScreenshotPassFlag)
			passedLogWithScreenshotByAShot(message);
		else
			ExtentTestManager.getTest().log(Status.PASS, message);
	}

	/**
	 * Adds Report pass status to extent report logger and captures page visible
	 * area screenshot,if the takeScreenshot flag is true.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 * @param takeScreenshot
	 */

	public void reportPass(String message, boolean takeScreenshot) {
		LogUtility.logInfo(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					true);
		if (takeScreenshotPassFlag && takeScreenshot)
			passedLogWithScreenshot(message);
		else
			ExtentTestManager.getTest().log(Status.PASS, message);
	}

	/**
	 * Adds Report pass status to extent report logger and captures complete page
	 * screenshot by scrolling, if the takeScreenshot flag is true.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 * @param takeScreenshot
	 */

	public void reportPassWithFullPageScreenshot(String message, boolean takeScreenshot) {
		LogUtility.logInfo(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					true);
		if (takeScreenshotPassFlag && takeScreenshot)
			passedLogWithScreenshotByAShot(message);
		else
			ExtentTestManager.getTest().log(Status.PASS, message);
	}

	/**
	 * Adds Report Fail status to extent report logger and captures page visible
	 * area screenshot
	 * 
	 * @author Sanjay Samantaray
	 * @param message
	 */

	public void reportFail(String message) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag)
			failedLogWithScreenshot(message);
		else
			ExtentTestManager.getTest().log(Status.FAIL, message);
		softAssert.assertTrue(false);
	}

	/**
	 * Adds Report Fail status to extent report logger and captures complete page
	 * screenshot by scrolling
	 * 
	 * @author Sanjay Samantaray
	 * @param message
	 */

	public void reportFailWithFullPageScreenshot(String message) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag)
			failedLogWithScreenshotByAShot(message);
		else
			ExtentTestManager.getTest().log(Status.FAIL, message);
		softAssert.assertTrue(false);
	}

	/**
	 * Adds Report Fail status to extent report logger and captures page visible
	 * area screenshot,if the takeScreenshot flag is true.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 * @param takeScreenshot
	 */

	public void reportFail(String message, boolean takeScreenshot) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag && takeScreenshot)
			failedLogWithScreenshot(message);
		else
			ExtentTestManager.getTest().log(Status.FAIL, message);
		softAssert.assertTrue(false);
	}

	/**
	 * Adds Report Fail status to extent report logger and captures complete page
	 * screenshot by scrolling, if the takeScreenshot flag is true.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 * @param takeScreenshot
	 */

	public void reportFailWithFullPageScreenshot(String message, boolean takeScreenshot) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag && takeScreenshot)
			failedLogWithScreenshotByAShot(message);
		else
			ExtentTestManager.getTest().log(Status.FAIL, message);
		softAssert.assertTrue(false);
	}

	/**
	 * Adds Report fail status to extent report logger and stops script execution
	 * and captures page visible area screenshot.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */
	public void reportHardFail(String message) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag) {
			failedLogWithScreenshot(message);
			Assert.fail();
		} else {
			ExtentTestManager.getTest().log(Status.FAIL, message);
			Assert.fail();
		}
	}

	/**
	 * Adds Report fail status to extent report logger and stops script execution
	 * and captures complete page screenshot by scrolling
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */
	public void reportHardFailWithFullPageScreenshot(String message) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag) {
			failedLogWithScreenshotByAShot(message);
			Assert.fail();
		} else {
			ExtentTestManager.getTest().log(Status.FAIL, message);
			Assert.fail();
		}
	}

	/**
	 * Adds Report fail status to extent report logger and stops script execution
	 * and captures page visible area screenshot,if the takeScreenshot flag is true.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 * @param takeScreenshot
	 */

	public void reportHardFail(String message, boolean takeScreenshot) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag && takeScreenshot) {
			failedLogWithScreenshot(message);
			Assert.fail();
		} else {
			ExtentTestManager.getTest().log(Status.FAIL, message);
			Assert.fail();
		}
	}

	/**
	 * Adds Report fail status to extent report logger and stops script execution
	 * and captures complete page screenshot by scrolling,if the takeScreenshot flag
	 * is true.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 * @param takeScreenshot
	 */

	public void reportHardFailWithFullPageScreenshot(String message, boolean takeScreenshot) {
		LogUtility.logInfo(message);
		ConcurrentEngines.getEngine().addSoftError(message);
		if (runType.equals("perfectoMobile"))
			ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance().reportiumAssert(message,
					false);
		if (takeScreenshotFailFlag && takeScreenshot) {
			failedLogWithScreenshotByAShot(message);
			Assert.fail();
		} else {
			ExtentTestManager.getTest().log(Status.FAIL, message);
			Assert.fail();
		}
	}

	/**
	 * Takes base64 screenshot for Failed steps.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */

	private void failedLogWithScreenshot(String message) {
		String base64String = captureBase64();
		try {
			ExtentTestManager.getTest().log(Status.FAIL, message,
					MediaEntityBuilder.createScreenCaptureFromBase64String(base64String).build());
		} catch (IOException e) {
			LogUtility.logError("failedLogWithScreenshot",
					"Screenshot could not be captured. Possible causes are directory not found or access to it.");
			e.printStackTrace();
		}
	}

	/**
	 * Takes base64 screenshot for Passed steps.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */

	private void passedLogWithScreenshot(String message) {
		String base64String = captureBase64();
		try {
			ExtentTestManager.getTest().log(Status.PASS, message,
					MediaEntityBuilder.createScreenCaptureFromBase64String(base64String).build());
		} catch (IOException e) {
			LogUtility.logError("passedLogWithScreenshot",
					"Screenshot could not be captured. Possible causes are directory not found or access to it.");
			e.printStackTrace();
		}
	}

	/**
	 * Takes base64 complete page screenshot for Failed steps.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */

	private void failedLogWithScreenshotByAShot(String message) {
		String base64String = takeBase64ScreenshotByAShot();
		try {
			ExtentTestManager.getTest().log(Status.FAIL, message,
					MediaEntityBuilder.createScreenCaptureFromBase64String(base64String).build());
		} catch (IOException e) {
			LogUtility.logError("failedLogWithScreenshot",
					"Screenshot could not be captured. Possible causes are directory not found or access to it.");
			e.printStackTrace();
		}
	}

	/**
	 * Takes base64 complete page screenshot for Passed steps.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */

	private void passedLogWithScreenshotByAShot(String message) {
		String base64String = takeBase64ScreenshotByAShot();
		try {
			ExtentTestManager.getTest().log(Status.PASS, message,
					MediaEntityBuilder.createScreenCaptureFromBase64String(base64String).build());
		} catch (IOException e) {
			LogUtility.logError("passedLogWithScreenshot",
					"Screenshot could not be captured. Possible causes are directory not found or access to it.");
			e.printStackTrace();
		}
	}

	/**
	 * Captures base64 screenshot.
	 * 
	 * @author Bharat Pandey
	 * 
	 * @param name
	 * @return base64Screenshot
	 */
	private String captureBase64() {
		File source = takeScreenShot();
		String base64Screenshot = "";
		try {
			byte[] fileContent = FileUtils.readFileToByteArray(source);
			base64Screenshot = Base64.getEncoder().encodeToString(fileContent);
		} catch (IOException io) {
			LogUtility.logError("Screenshot file not found or inaccessible.");
			io.printStackTrace();
		}
		return base64Screenshot;
	}

	/**
	 * Captures screenshot.
	 * 
	 * @author Bharat Pandey
	 * 
	 * @return image source file
	 */
	private File takeScreenShot() {
		File srcFile = null;
		if (ConcurrentEngines.getEngine() != null) {
			if (ConcurrentEngines.getEngine().getWebDriver() != null) {
				try {
					srcFile = ((TakesScreenshot) ConcurrentEngines.getEngine().getWebDriver())
							.getScreenshotAs(OutputType.FILE);
				} catch (Exception e) {
					LogUtility.logException("takeScreenShot", "Could not capture screenshot", e, LoggingLevel.ERROR,
							true);
				}
			}
		}
		return srcFile;
	}

	/**
	 * Captures Complete page screenshot by scrolling.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @return base64Encoded image String
	 */

	private String takeBase64ScreenshotByAShot() {
		String base64Encoded = "";
		if (ConcurrentEngines.getEngine() != null) {
			if (ConcurrentEngines.getEngine().getWebDriver() != null) {
				Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(50))
						.takeScreenshot(ConcurrentEngines.getEngine().getWebDriver());
				try {
					ByteArrayOutputStream byteOutput = new ByteArrayOutputStream();
					ImageIO.write(screenshot.getImage(), "PNG", byteOutput);
					byteOutput.flush();
					byte[] encodeBase64 = Base64.getEncoder().encode(byteOutput.toByteArray());
					base64Encoded = new String(encodeBase64);
					byteOutput.close();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					LogUtility.logException("takeScreenByAShot-->", "Could not capture screenshot", e,
							LoggingLevel.ERROR, true);
				}
			}
		}
		return base64Encoded;
	}

	/**
	 * Captures Complete monitor screenshot.
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @return base64Encoded image String
	 */
	public String captureCompleteMonitorScreenToBase64() {
		Rectangle screenSize = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
		BufferedImage screenCapture = null;
		String base64Encoded = "";
		try {
			screenCapture = new Robot().createScreenCapture(screenSize);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(screenCapture, "png", baos);
			baos.flush();
			byte[] encodeBase64 = Base64.getEncoder().encode(baos.toByteArray());
			base64Encoded = new String(encodeBase64);
			baos.close();
		} catch (AWTException | IOException e) {
			e.getMessage();
		}
		return base64Encoded;
	}

	/***
	 * @description: Method to write comment in reportium client
	 * 
	 * @author Sanjay Samantaray
	 * 
	 * @param message
	 */
	public void reportComment(String message) {
		Map<String, Object> params = new HashMap<>();
		params.put("text", message);
		ConcurrentEngines.getEngine().getAppiumDriver().executeScript("mobile:comment", params);
	}

	/**
	 * 
	 * @param path
	 * @param name
	 * @return image file
	 */
	public File takeScreenShot(String path, String name) {
		File srcFile = null;
		if (ConcurrentEngines.getEngine() != null) {
			if (ConcurrentEngines.getEngine().getWebDriver() != null) {
				// String imagePath = path + name + ".png";

				try {
					srcFile = ((TakesScreenshot) ConcurrentEngines.getEngine().getWebDriver())
							.getScreenshotAs(OutputType.FILE);
				} catch (Exception e) {
					LogUtility.logException(name, "Could not capture screenshot", e, LoggingLevel.ERROR, true);
				}

				// Commented by Sanjay: No need to save screenshot in local as image converted
				// to base64

				/*
				 * try { FileUtils.copyFile(srcFile, new File(imagePath)); } catch (IOException
				 * e) { LogUtility.logException(name, "Could not capture screenshot", e,
				 * LoggingLevel.ERROR, true); }
				 */
			}
		}
		return srcFile;
	}
}
