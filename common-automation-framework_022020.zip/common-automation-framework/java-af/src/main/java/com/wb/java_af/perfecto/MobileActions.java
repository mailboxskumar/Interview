package com.wb.java_af.perfecto;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.setup.Enums.PerfectoTap;
import com.wb.java_af.utilities.LogUtility;

/**
 * Performs drags and gestures on the mobile device
 * 
 * @author Bharat Pandey
 *
 */
public class MobileActions {

	public Engine engine;

	public MobileActions(Engine engine) {
		this.engine = engine;
	}

	/**
	 * Performs the drag gesture
	 * 
	 * @param location - The touch event coordinates.
	 *                 Format - either "x1,y1,x2,y2" or "x1%,y1%,x2%,y2%"
	 *                 Coordinate value can be in pixels or in percentage of screen
	 *                 size (0-100).
	 *                 For percentage use the % sign. Example - "20%, 25%"
	 *                 It is recommended to use the percentage value as it
	 *                 translates to the screen resolution.
	 * 
	 * @author Bharat Pandey
	 */
	public void performDrag(String location) {
		PerfectoParameters params = new PerfectoParameters("location", location);
		try {
			new PerfectoActionExecutor(engine).executeAction("mobile:touch:drag", params);
		} catch (Exception e) {
			LogUtility.logException("performDrag", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	
	/**
	 * Performs the drag gesture
	 * 
	 * @param location - The touch event coordinates.
	 *                 Format - either "x1,y1,x2,y2" or "x1%,y1%,x2%,y2%"
	 *                 Coordinate value can be in pixels or in percentage of screen
	 *                 size (0-100).
	 *                 For percentage use the % sign. Example - "20%, 25%"
	 *                 It is recommended to use the percentage value as it
	 *                 translates to the screen resolution.
	 * @param duration - The duration, in seconds, for performing the drag operation.
	 */
	public void performDrag(String location, String duration) {
		PerfectoParameters params = new PerfectoParameters();
		params.addParameter("location", location);
		params.addParameter("duration", duration);
		try {
			new PerfectoActionExecutor(engine).executeAction("mobile:touch:drag", params);
		} catch (Exception e) {
			LogUtility.logException("performDrag", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Performs the drag gesture
	 * 
	 * @param location - The touch event coordinates.
	 *                 Format - either "x1,y1,x2,y2" or "x1%,y1%,x2%,y2%"
	 *                 Coordinate value can be in pixels or in percentage of screen
	 *                 size (0-100).
	 *                 For percentage use the % sign. Example - "20%, 25%"
	 *                 It is recommended to use the percentage value as it
	 *                 translates to the screen resolution.
	 * @param duration - The duration, in seconds, for performing the drag operation.
	 * @param tapBehavior - 1. Tap - Touch down at the beginning and touch up at the end
							2. No Tap - No auxiliary operation
							3. Down - Touch down at the beginning
							4. Up - Touch up at the end
		
							
		@author Bharat Pandey
		
	 */
	public void performDrag(String location, String duration, PerfectoTap tapBehavior) {
		PerfectoParameters params = new PerfectoParameters();
		params.addParameter("location", location);
		params.addParameter("duration", duration);
		params.addParameter("auxillary", tapBehavior.getProperty());
		try {
			new PerfectoActionExecutor(engine).executeAction("mobile:touch:drag", params);
		} catch (Exception e) {
			LogUtility.logException("performDrag", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

}
