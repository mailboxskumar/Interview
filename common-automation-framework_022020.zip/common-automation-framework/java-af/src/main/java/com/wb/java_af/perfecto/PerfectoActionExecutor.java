package com.wb.java_af.perfecto;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Executes an action on Perfecto passed to the javascript executor
 * 
 * @author Bharat Pandey
 *
 */
public class PerfectoActionExecutor {

	Engine engine;
	
	public PerfectoActionExecutor(Engine engine) {
		this.engine = engine;
	}
	
	public String executeAction(String action, PerfectoParameters param) {
		String resultString = null;
		
		try {
			resultString = engine.getJavaScript().<String>execute(action, param.getParams());
		} catch (Exception e) {
			LogUtility.logException("executeAction", e, LoggingLevel.ERROR, true);
		}
		return resultString;
	}
}
