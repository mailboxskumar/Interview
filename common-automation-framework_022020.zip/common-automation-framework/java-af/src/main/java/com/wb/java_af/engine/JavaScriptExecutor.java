package com.wb.java_af.engine;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;
/**
 * Extends selenium’s javascript library. Exposes a number of methods to inject javascript in the test code.
 * 
 * @see JavaScriptExecutor
 * 
 * @author Bharat Pandey
 *
 */
public class JavaScriptExecutor {

	private Engine engine;
	public JavaScriptExecutor(Engine engine) {
		this.engine = engine;
	}
	
	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	/**
	 * Executes script passed in the method argument
	 * @param javaScript - Script to be executed e.g "window.open('"https://qa-public.websterbank.com/personal"', '_blank');"
	 * @param safemode - boolean flag to indicate the behaviour if the script fails.
	 * 
	 */
	public void executeJavaScript(String javaScript, boolean safemode){
		try {
			((JavascriptExecutor) getEngine().getWebDriver()).executeScript(javaScript);
		} catch (UnhandledAlertException e){
			LogUtility.logException("executeJavaScript",e, LoggingLevel.ERROR, true);
			if(!safemode) {
				throw e;
			}
		}
	}
	
	/**
	 * Executes script passed in the method argument
	 * @param javaScript - Script to be executed e.g "window.open('"https://qa-public.websterbank.com/personal"', '_blank');"
	 * 
	 */
	public void executeJavaScript(String javaScript){
		executeJavaScript(javaScript, false);
	}
	
	
	/**
	 * Executes script passed in the method argument
	 * @param javaScript - Script to be executed e.g "window.open('"https://qa-public.websterbank.com/personal"', '_blank');"
	 * @param safemode - boolean flag to indicate the behaviour if the script fails.
	 * @param args
	 * 
	 */
	public void executeJavaScript(String javaScript, boolean safemode, Object... args){
		try {
			((JavascriptExecutor) getEngine().getWebDriver()).executeScript(javaScript, args);
		} catch (UnhandledAlertException e){
			LogUtility.logException("executeJavaScript",e, LoggingLevel.ERROR, true);
			if(!safemode) {
				throw e;
			}
		}
	}
	
	/**
	 * Executes script passed in the method argument
	 * @param javaScript - Script to be executed e.g "window.open('"https://qa-public.websterbank.com/personal"', '_blank');"
	 * @param args
	 * 
	 */
	public void executeJavaScript(String javaScript, Object... args){
		executeJavaScript(javaScript, false, args);
	}
	
	/**
	 * Selenium javascript method wrapper to execute javascripts
	 * @param webDriver - Driver instance
	 * @param script - Script to be executed e.g "window.open('"https://qa-public.websterbank.com/personal"', '_blank');"
	 * @return
	 * 
	 */
	public <T> T execute(EventFiringWebDriver webDriver, String script) {
		@SuppressWarnings("unchecked")
		T returnValue = (T) (webDriver.executeScript(script));
		return returnValue;
	}

	/**
	 * Selenium javascript method wrapper to execute javascripts
	 * @param script - Script to be executed e.g "window.open('"https://qa-public.websterbank.com/personal"', '_blank');"
	 * @param args
	 * @return
	 * 
	 */
	public <T> T execute(String script, Object... args) {
		return execute(getEngine().getWebDriver(), script, args);
	}
	
	/**
	 * Selenium javascript method wrapper to execute javascripts
	 * @param webDriver - Driver instance
	 * @param script - Script to be executed e.g "window.open('"https://qa-public.websterbank.com/personal"', '_blank');"
	 * @param args
	 * @return
	 * 
	 */
	public <T> T execute(EventFiringWebDriver webDriver, String script, Object... args) {
		@SuppressWarnings("unchecked")
		T returnValue = (T) (webDriver.executeScript(script, args));
		return returnValue;
	}
}