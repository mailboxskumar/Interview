package com.wb.java_af.perfecto;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Executes various browser functions on the mobile browser
 * 
 * @author Bharat Pandey
 *
 */
public class MobileBrowser {

	public Engine engine;

	public MobileBrowser(Engine engine) {
		this.engine = engine;
	}

	/**
	 * Opens the browser. This is done with a direct native command to the device
	 * OS, and not with navigation. Supported for - Chrome, Safari, Instrumented
	 * hybrid apps.
	 * 
	 * @param automation - Possible values simulated - os, chrome, safari
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String openMobileBrowser(String automation) {
		PerfectoParameters params = new PerfectoParameters("automation", automation);
		String resultStr = null;

		try {
			resultStr = new PerfectoActionExecutor(engine).executeAction("mobile:browser:open", params);
		} catch (Exception e) {
			LogUtility.logException("openMobileBrowser", e, LoggingLevel.ERROR, true);
		}

		return resultStr;
	}

	/**
	 * Cleans all data and opens a Chrome Terms and Services page that needs a
	 * manual click to accept. After running Browser clean, the Webpage functions do
	 * not work because the Chrome Terms and Services agreement does not load as a
	 * regular web page.
	 * 
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String cleanMobileBrowser() {
		PerfectoParameters params = new PerfectoParameters();
		String resultStr = null;

		try {
			resultStr = new PerfectoActionExecutor(engine).executeAction("mobile:browser:clean", params);
		} catch (Exception e) {
			LogUtility.logException("cleanMobileBrowser", e, LoggingLevel.ERROR, true);
		}

		return resultStr;
	}
	
	/**
	 * Verifies the browser application is running and page is loaded.
	 * As a best practice, this function should follow a command such as a button click to ensure that the page is loaded following the command. 
	 * 
	 * @param timeout
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String syncMobileBrowser(String timeout) {
		PerfectoParameters params = new PerfectoParameters("timeout", timeout);
		String resultStr = null;
		
		try {
			resultStr = new PerfectoActionExecutor(engine).executeAction("mobile:browser:sync", params);
		} catch (Exception e) {
			LogUtility.logException("syncMobileBrowser", e, LoggingLevel.ERROR, true);
		}
		
		return resultStr;
	}

}
