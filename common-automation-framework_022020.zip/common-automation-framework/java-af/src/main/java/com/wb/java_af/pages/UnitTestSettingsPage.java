package com.wb.java_af.pages;

import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class UnitTestSettingsPage {

	UnitTestViewAccountsPage viewAccountsPage = new UnitTestViewAccountsPage();

	public UnitTestSettingsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(ConcurrentEngines.getEngine().getAppiumDriver()), this);
	}

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_auxmenu")
	@iOSFindBy(xpath = "//*[@label='Auxiliary Menu']")
	@CacheLookup
	protected MobileElement settingsIcon;

	@AndroidFindBy(xpath = "//*[text()='MENU']")
	@iOSFindBy(xpath = "//*[@label='MENU']")
	@CacheLookup
	protected MobileElement menuTitle;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_alerts")
	@iOSFindBy(xpath = "//*[@label='Manage Alerts']")
	@CacheLookup
	protected MobileElement manageAlertsText;

	/**
	 * Method to click on Settings Icon
	 * 
	 * @throws Exception
	 */
	public void clickSettingsIcon() throws Exception {
		try {
			settingsIcon.click();
			LogUtility.logInfo("Settings Icon clicked");
			viewAccountsPage.isElementPresent(menuTitle, 3);
		} catch (Exception e) {
			throw new Exception("Unable to click on Settings Icon " + e);
		}
	}

	/**
	 * Method to click on Manage Alerts Text
	 * 
	 * @throws Exception
	 */
	public void clickManageAlerts() throws Exception {
		try {
			manageAlertsText.click();
			LogUtility.logInfo("Manage Alerts Option clicked");
		} catch (Exception e) {
			throw new Exception("Unable to click on Manage Alerts Option " + e);
		}
	}
}
