package com.wb.java_af.appium;

import java.time.Duration;

import org.openqa.selenium.WebDriverException;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

public class AppiumIos {

	private Engine engine;

	public AppiumIos(Engine engine) {
		this.engine = engine;
	}

	public void runAppInBackground(Duration seconds) {
		try {
			engine.getIosDriver().runAppInBackground(seconds);
		} catch (Exception e) {
			LogUtility.logException("runAppInBackground", "There was a problem running the app in the background.", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public void hideKeyboard(Duration seconds) {
		try {
			engine.getIosDriver().hideKeyboard();
		} catch (Exception e) {
			LogUtility.logException("hideKeyboard", "There was a problem hinding keyboard.", e, LoggingLevel.ERROR,
					true);
			throw e;
		}
	}

	public void lockDevice() {
		try {
			engine.getIosDriver().lockDevice();
		} catch (WebDriverException e) {
			LogUtility.logException("lockDevice", "There was a problem locking device.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public void shakeDevice() {
		try {
			engine.getIosDriver().shake();
		} catch (WebDriverException e) {
			LogUtility.logException("shakeDevice", "There was a problem shaking device.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

}
