package com.wb.java_af.pages;

import java.util.List;

import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author spothula-adm
 *
 */
public class UnitTestLoginPage {

//	AppiumDriver<RemoteWebElement> driver = ConcurrentEngines.getEngine().getAppiumDriver();
	UnitTestViewAccountsPage viewAccountsPage = new UnitTestViewAccountsPage();

	public UnitTestLoginPage() {
		PageFactory.initElements(new AppiumFieldDecorator(ConcurrentEngines.getEngine().getAppiumDriver()), this);
	}

	@AndroidFindBy(xpath = "//android.widget.Button[@text='FORGOT PASSCODE']")
	@iOSFindBy(xpath = "//*[@label='Forgot Pin']")
	@CacheLookup
	protected List<RemoteWebElement> ForgotPasscode;

	@AndroidFindBy(xpath = "//*[@resourceid='com.malauzai.websterbank:id/passcode_view']/view")
	@iOSFindBy(xpath = "//*[@label=\"Pin Number One of Four\"]")
	@CacheLookup
	protected MobileElement radioBtnPasscodeView;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/iv_logo")
	@iOSFindBy(xpath = "//*[@label='About Us']")
	@CacheLookup
	protected MobileElement logoWebsterBank;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/username_entry")
	@iOSFindBy(xpath = "//*[@label='Username']")
	@CacheLookup
	protected MobileElement txtUserName;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/password_entry")
	@iOSFindBy(xpath = "//*[@label='Password']")
	@CacheLookup
	protected MobileElement txtPassword;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/b_submit")
	@iOSFindBy(xpath = "//*[@label='LOG IN']")
	@CacheLookup
	protected MobileElement btnLogIn;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='VIEW ACCOUNTS']")
	@CacheLookup
	protected MobileElement titleViewAccounts;

	@AndroidFindBy(xpath = "//*[@resourceid=\"android:id/alertTitle\"]")
	/** Need to provide the locator for iOS **/
	// @iOSFindBy(")
	@CacheLookup
	protected MobileElement titleAlertQuestion;

	/** --MPrashant-- **/
	@AndroidFindBy(xpath = "//*[@resourceid=\"com.malauzai.websterbank:id/answer\"]")
	// @iOSFindBy(xpath = "2")
	@CacheLookup
	protected MobileElement txtAlertAnswer;

	@AndroidFindBy(xpath = "//*[@resourceid=\"android:id/button1\"]")
	// @iOSFindBy(xpath = "3")
	@CacheLookup
	protected MobileElement btnAlertOk;

	/**
	 * Method to verify the Webster Mobile Login Page
	 * 
	 * @throws Exception
	 */
	public void verifyWebsterMobileLoginPage() throws Exception {
		try {
			viewAccountsPage.isElementPresent(logoWebsterBank, 6);
			logoWebsterBank.isDisplayed();
			LogUtility.logInfo("--->WebsterBank Logo displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Webster Logo is not verified<--- " + e.getStackTrace());
			throw new Exception("Webster Logo is not verified " + e);
		}
	}

	/**
	 * Method to verify the mobile login username field
	 * 
	 * @throws Exception
	 */
	public void verifyUserNameTextField() throws Exception {
		try {
			if (ForgotPasscode.size() != 0) {
				((RemoteWebElement) ForgotPasscode).click();
				LogUtility.logInfo("--->Forgot Passcode button is displayed<---");
			} else {
				txtUserName.isDisplayed();
				LogUtility.logInfo("--->UserName field is displayed<---");
			}
		} catch (Exception e) {
			LogUtility.logError(
					"--->Unable to verify the Username Text Field or forgotpasscode button<--- " + e.getStackTrace());
			throw new Exception("Unable to verify the Username Text Field or forgotpasscode button " + e);
		}
	}

	/**
	 * Method to verify the mobile login password
	 * 
	 * @throws Exception
	 */
	public void verifyPasswordTextField() throws Exception {
		try {
			txtPassword.isDisplayed();
			LogUtility.logInfo("--->Password field is displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the Password field<--- " + e.getStackTrace());
			throw new Exception("Unable to verify the password field " + e);
		}
	}

	/**
	 * Method verify the mobile login button
	 * 
	 * @throws Exception
	 */
	public void verifyLogInButton() throws Exception {
		try {
			btnLogIn.isDisplayed();
			LogUtility.logInfo("--->LogIn button is displayed<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the logIn Button<--- " + e.getStackTrace());
			throw new Exception("Unable to verify the logIn Button " + e);
		}
	}

	/**
	 * Method to enter userName in the text field
	 * 
	 * @param userName
	 * @throws Exception
	 */
	public void enterUserName(String userName) throws Exception {
		try {
			txtUserName.clear();
			txtUserName.sendKeys(userName);
			LogUtility.logInfo("--->UserName entered as " + userName);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter Username in Username Text field<--- " + e.getStackTrace());
			throw new Exception("Unable to enter Username in Username Text field " + e);
		}
	}

	/**
	 * Method to enter password in the text field
	 * 
	 * @param password
	 * @throws Exception
	 */
	public void enterPassword(String password) throws Exception {
		try {
			txtPassword.sendKeys(password);
			LogUtility.logInfo("Password entered");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter Password in password Text field<--- " + e.getStackTrace());
			throw new Exception("Unable to enter Password in password Text field " + e);
		}
	}

	/**
	 * Method to click on log in button
	 * 
	 * @throws Exception
	 */
	public void clickLogin() throws Exception {
		try {
			btnLogIn.click();
			LogUtility.logInfo("--->Clicked on Login button<---");
			viewAccountsPage.isElementPresent(titleViewAccounts, 80);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on LogIn button<--- " + e.getStackTrace());
			throw new Exception("Unable to click on LogIn button " + e);
		}
	}

}
