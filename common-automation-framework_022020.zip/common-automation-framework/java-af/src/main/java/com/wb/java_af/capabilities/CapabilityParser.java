package com.wb.java_af.capabilities;

import java.io.FileReader;
import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.wb.java_af.capabilities.browserCaps.ChromePlatformCapsImpl;
import com.wb.java_af.capabilities.browserCaps.CloudPlatformCapImpl;
import com.wb.java_af.capabilities.browserCaps.EdgePlatformCapImpl;
import com.wb.java_af.capabilities.browserCaps.FirefoxPlatformCapsImpl;
import com.wb.java_af.capabilities.browserCaps.IePlatformCapsImpl;

public class CapabilityParser {


	@SuppressWarnings("unchecked")
	public static DesiredCapabilities parseMobileCapabilities(String filePath, String env, String device)
			throws Exception {
		JSONParser parser = new JSONParser();
		JSONObject config = (JSONObject) parser.parse(new FileReader("src/test/resources/" + filePath));
		JSONObject envs = (JSONObject) config.get(env);

		DesiredCapabilities capabilities = new DesiredCapabilities();

		Map<String, String> envCapabilities = (Map<String, String>) envs.get(device);
		Iterator<Map.Entry<String, String>> it = envCapabilities.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> pair = it.next();
			String value = pair.getValue().toString();
			boolean boxedValue = false;
			if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
				boxedValue = Boolean.parseBoolean(value);
				capabilities.setCapability(pair.getKey().toString(), boxedValue);
			} else {
				capabilities.setCapability(pair.getKey().toString(), pair.getValue().toString());
			}
		}

		return capabilities;

	}

	public static Capabilities parseBrowserCapabilities(String filePath, String env, String platformHost) {
		Capabilities caps = null;
		if (env.equals("onFutureCloud")) {
			caps = new CloudPlatformCapImpl(filePath, env, platformHost).getCaps();
		} else {
			switch (platformHost) {
			case "chrome": {
				caps = new ChromePlatformCapsImpl(filePath, env, platformHost).getCaps();
				break;
			}
			case "firefox": {
				caps = new FirefoxPlatformCapsImpl(filePath, env, platformHost).getCaps();
				break;
			}
			case "ie": {
				caps = new IePlatformCapsImpl(filePath, env, platformHost).getCaps();
				break;
			}
			case "edge": {
				caps = new EdgePlatformCapImpl(filePath, env, platformHost).getCaps();
				break;
			}
			default:
				caps = new ChromePlatformCapsImpl(filePath, env, platformHost).getCaps();
				break;
			}
		}
		return caps;
	}

	@SuppressWarnings("unchecked")
	public static String getDeviceID(String filePath, String env, String device) throws Exception {
		JSONParser parser = new JSONParser();
		JSONObject config = (JSONObject) parser.parse(new FileReader("src/test/resources/" + filePath));
		JSONObject envs = (JSONObject) config.get(env);
		String deviceID = null;

		Map<String, String> envCapabilities = (Map<String, String>) envs.get(device);
		Iterator<Map.Entry<String, String>> it = envCapabilities.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> pair = it.next();
			if (pair.getKey().equals("udid") || pair.getKey().equals("deviceName")) {
				deviceID = pair.getValue();
				break;
			}
		}

		return deviceID;

	}
}
