package com.wb.java_af.engine;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Library of methods to action on handling windows, iFrames and pop ups.
 * 
 * @author Bharat Pandey
 * 
 * @see MultiWindowManager
 */
public class MultiWindowManager {

	private Engine engine;
	
	public MultiWindowManager(Engine engine){
		this.engine = engine;
		handles = new LinkedHashMap<>();
	}
	
	public LinkedHashMap<String, String> handles;
	
	public LinkedHashMap<String, String> getHandles() {
		return handles;
	}
	public void setHandles(LinkedHashMap<String, String> handles) {
		this.handles = handles;
	}
	
	/**
	 * Switches to an iframe
	 * @param nameOrId - Name or id of the iframe element
	 * 
	 * @see MultiWindowManager
	 * 
	 */
	public void switchToiframe(String nameOrId){
		engine.getWebDriver().switchTo().frame(nameOrId);
	}
	
	/**
	 * Gets the total number of frames
	 * @return count
	 * 
	 * @see MultiWindowManager
	 * 
	 */
	public int getiframeCount(){
		List<WebElement> frameElements = engine.getWebDriver().findElements(By.tagName("iFrame"));
		return frameElements.size();
	}
	
	/**
	 * Returns iframe elements
	 * @return
	 * 
	 * @see MultiWindowManager
	 * 
	 */
	public Collection<WebElement> getFrameElements(){
		List<WebElement> frameElements = engine.getWebDriver().findElements(By.tagName("iFrame"));
		return frameElements;
	}
	/**
	 * Switches to the last window opened
	 * 
	 * @see MultiWindowManager
	 * 
	 */
	public void switchToWindowLastOpened() {
		String currentHandle = engine.getWebDriver().getWindowHandle();
		Set<String> windowHandles = engine.getWebDriver().getWindowHandles();
		
		for(String handle : windowHandles) {
			if(!handle.equals(currentHandle)) {
				switchToWindowHandle(handle);
			}
		}
	}
	/**
	 * Switches to the window specified by the handle
	 * @param handle - window handle
	 * 
	 * @see MultiWindowManager
	 * 
	 */
	public void switchToWindowHandle(String handle) {
		try {
			engine.getWebDriver().switchTo().window(handle);
		} catch (Exception e) {
			LogUtility.logException("switchToWindowHandle", e, LoggingLevel.ERROR, true);
		}
	}
	
	/**
	 * Switches to the window specified by the handle
	 * @param handle - window handle
	 * 
	 * @see MultiWindowManager
	 * 
	 */
	public void switchToWindow(String handle) {
		switchToWindow(handle);
	}
	
	/**
	 * Switches to the pop up window specified by the handle
	 * @param handle - window handle
	 * 
	 * @see MultiWindowManager
	 * 
	 */
	public void switchToPopUpWindow(String handle) {
		String subWindowHandler = null;
		Set<String> windowHandles = engine.getWebDriver().getWindowHandles();
		Iterator<String> iterator = windowHandles.iterator();
		while (iterator.hasNext()) {
			subWindowHandler = iterator.next();
		}
		engine.getWebDriver().switchTo().window(subWindowHandler);
	}
	
	/**
	 * Closes all open tabs except the current tab
	 * 
	 * @see MultiWindowManager
	 */
	public void closeAllOtherTabs() {
		String currentHandle = engine.getWebDriver().getWindowHandle();
		Set<String> windowHandles = engine.getWebDriver().getWindowHandles();
		windowHandles.remove(currentHandle);
		for (String handle : windowHandles){
			engine.getWebDriver().switchTo().window(handle);
			engine.getWebDriver().close();
			engine.getWebDriver().switchTo().window(currentHandle);
		}
	}
	
	/**
	 * Closes the current tab
	 * 
	 * @see MultiWindowManager
	 */
	public void closeCurrentTab() {
		Set<String> windowHandles = engine.getWebDriver().getWindowHandles();
		String currentHandle = engine.getWebDriver().getWindowHandle();
		engine.getWebDriver().switchTo().window(currentHandle);
		engine.getWebDriver().close();
		engine.getWebDriver().switchTo().window(windowHandles.iterator().next());
	}
	/**
	 * Maximizes the window
	 * 
	 * @see MultiWindowManager
	 */
	public void maximizeWindow(){
		engine.getWebDriver().manage().window().maximize();
	}
}
