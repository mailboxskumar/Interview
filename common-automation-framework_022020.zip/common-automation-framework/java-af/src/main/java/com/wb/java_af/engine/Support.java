package com.wb.java_af.engine;

public class Support {

	public Support(Engine engine) {
		// TODO Auto-generated constructor stub
	}

}
