package com.wb.java_af.capabilities.browserCaps;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.MutableCapabilities;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

public interface BrowserCaps {

	public <T extends MutableCapabilities> T getCaps();

	/**
	 * Parses the json file containing the browser caps and gets the Json object
	 * containing the environemt passed
	 * 
	 * @param filePath
	 * @param env
	 * @return JSON Object containing the env objects
	 * @author Bharat Pandey
	 */
	public static JSONObject parseJsonFile(String filePath, String env) {
		JSONParser parser = new JSONParser();
		JSONObject config = null;
		try {
			config = (JSONObject) parser.parse(new FileReader("src/test/resources/" + filePath));
		} catch (IOException e) {
			LogUtility.logException("parseJsonFile", "The file was not found or was inaccessible", e, LoggingLevel.ERROR, true);
			e.printStackTrace();
		} catch (ParseException e) {
			LogUtility.logException("parseJsonFile", "The json file could not be parsed. Please check the json syntax", e, LoggingLevel.ERROR, true);
			e.printStackTrace();
		}
		JSONObject environment = (JSONObject) config.get(env);
		return environment;
	}
	
	/**
	 * Converts a given Json array to a list
	 * @param array
	 * @return
	 * @author Bharat Pandey
	 * @param <T>
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> convertJsonArrayToList(JSONArray array) {
		List<T> list = new ArrayList<>();
		JSONArray jArray = (JSONArray) array;
		if (jArray != null) {
			for (int i = 0; i < jArray.size(); i++) {
				list.add((T) jArray.get(i));
			}
		}
		return list;
	}

}
