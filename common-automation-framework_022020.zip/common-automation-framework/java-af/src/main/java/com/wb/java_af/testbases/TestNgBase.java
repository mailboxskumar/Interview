package com.wb.java_af.testbases;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.IExecutionListener;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.wb.java_af.capabilities.CapabilityParser;
import com.wb.java_af.reporting.ExtentManager;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

@Listeners(TestNgBase.class)
public class TestNgBase extends TestBase implements IExecutionListener {

	public static boolean onlyStartOnce;
	public static boolean onlyFinishOnce;
	public boolean useDefaultEngine = true;
	public boolean configError;
	public Integer iterationCount = 1;
	String device;
	String browser;

	@Override
	public void onExecutionStart() {
		defaultOnExecutionStart();
	}

	public void defaultOnExecutionStart() {
		if (!onlyStartOnce) {
			loadProperties();
			setLogPath();
			initEnvironmentalParams();
			setUpExtent();
			onlyStartOnce = true;
		}
	}

	@BeforeSuite
	public void beforeSuite(ITestContext context) throws Exception {

	}

	@BeforeTest
	public void beforeTest(ITestContext context) throws Exception {
		initEnvironmentalParams();
	}

	@BeforeClass
	public void beforeClass(ITestContext context) throws Exception {
	}

	@BeforeMethod
	public void beforeMethod(ITestContext context, Method method) throws Exception {
		try {
			setRemoteExecution();
			setMobileRun();
			setPerfectoRun();
			logDividerSetup(method);
			engineSetUp(context);
			methodSetup();
			reportSetup(method);
			//setReportium(method);
		} catch (Exception e) {
			LogUtility.logException("BeforeMethod", "There was a configuration issue.", e, LoggingLevel.ERROR, true);
			configError = true;
			throw e;
		}
	}

	public void setRemoteExecution() {
		if ((props.getProperty("run.type").equalsIgnoreCase("perfectoMobile"))
				|| props.getProperty("run.type").equalsIgnoreCase("grid")) {
			remoteExecution = true;
		}
	}

	public void setPerfectoRun() {
		if ((props.getProperty("run.type").equalsIgnoreCase("perfectoMobile"))) {
			perfecto = true;
		}
	}

	public void setMobileRun() {
		String runType = props.getProperty("run.type");
		if ((runType.equalsIgnoreCase("localMobile")) || (runType.equalsIgnoreCase("perfectoMobile"))) {
			mobile = true;
		}
	}

	private void logDividerSetup(Method method) {
		LogUtility.startTestCase(method.getName());
	}

	private void engineSetUp(ITestContext context) throws Exception {
		String deviceLocation = props.getProperty("run.type");
		setTestParameters(context);
		DesiredCapabilities caps = null;
		if(mobile) {
			caps = CapabilityParser.parseMobileCapabilities("capabilities/deviceCapabilities.json", deviceLocation, device);
		}
		ConcurrentEngines.createEngine(caps, browser, remoteExecution, perfecto, mobile);
	}
	
	private void setTestParameters(ITestContext context){
		browser = System.getProperty("browser");
		device = System.getProperty("device");
		Map<String, String> allParameters = context.getCurrentXmlTest().getAllParameters();
		for (Map.Entry<String, String> entry : allParameters.entrySet()) {
			if (entry.getKey().equals("device")) {
				device = entry.getValue();
			} else if (entry.getKey().equals("browser")) {
				browser = entry.getValue();
			}
		} 
	}

	private void methodSetup() {
		if(!(mobile || perfecto)) {
			getApp();
			maximizeWindow();
		}
	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod(ITestResult result) throws Throwable {
		if (configError) {
			result.setStatus(3);
			configError = false;
		}
		driverTearDown();
		reportTearDownMethod(result);
		flushExtentManager();
		logDividerTearDown(result);
		//stopReportium(result);
	}

	@AfterClass
	public void afterClass() {

	}

	@AfterTest
	public final void afterTest() throws Exception {

	}

	@AfterSuite
	public final void afterSuite() throws Exception {

	}

	@Override
	public void onExecutionFinish() {
		// flushExtentManager();
		if (!onlyFinishOnce) {
			System.out.println("Finished at " + new SimpleDateFormat("yyy_MM-dd HH:mm:ss").format(new Date()));
			onlyFinishOnce = true;
		}
	}

	public void reportSetup(Method method) {
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentManager.getInstance(reportDirectoryName);
			ExtentTestManager.createTest(method.getName());
		}
	}

	public void flushExtentManager() {
		if (extentReport.equalsIgnoreCase("true")) {
			if (ExtentManager.getInstance() != null) {
				ExtentManager.getInstance().flush();
			}
		}
	}

	private void reportTearDownMethod(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE || result.getStatus() == ITestResult.SUCCESS_PERCENTAGE_FAILURE) {
			testFail(result);
		} else if (result.getStatus() == ITestResult.SKIP) {
			testSkip(result);
		} else {
			testPass(result);
		}
	}

	public void driverTearDown() {
		ConcurrentEngines.destroyEngine();
	}

	public void logDividerTearDown(ITestResult result) {
		LogUtility.endTestCase(result.getMethod().getMethodName());
	}

	public void testPass(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		System.out.println(methodName + "()--Passed");
		LogUtility.logInfo("Test Passed: " + methodName);
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentTestManager.getTest().log(Status.PASS, "Test Passed");
		}
	}

	public void testSkip(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		System.out.println(methodName + "()--Skipped");
		LogUtility.logInfo("Test Skipped: " + methodName);
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentTestManager.getTest().log(Status.SKIP, "Test Skipped");
		}
	}

	public void testFail(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		System.out.println(methodName + "()--Failed");
		LogUtility.logInfo("Test Failed: " + methodName);
		if (extentReport.equalsIgnoreCase("true")) {
			try {
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed", MediaEntityBuilder.createScreenCaptureFromBase64String(takeScreenShot(methodName)).build());
			} catch (IOException e) {
				LogUtility.logError(methodName, "Screenshot could not be captured. Possible causes are directory not found or access to it.");
				e.printStackTrace();
			}
		}
	}

	public String takeScreenShot(String name) {
		String screenshotBase64 = null;
		if (!ConcurrentEngines.getEngine().getWebDriver().toString().contains(null)) {
			if (ConcurrentEngines.getEngine().getWebDriver() != null) {
				screenshotBase64 = ((TakesScreenshot) ConcurrentEngines.getEngine().getWebDriver())
						.getScreenshotAs(OutputType.BASE64);

			}
		}
		return screenshotBase64;
	}

	public void takeScreenShot(String path, String name) {
		if (ConcurrentEngines.getEngine() != null) {
			if (ConcurrentEngines.getEngine().getWebDriver() != null) {
				String imagePath = path + name + ".png";
				File srcFile = ((TakesScreenshot) ConcurrentEngines.getEngine().getWebDriver())
						.getScreenshotAs(OutputType.FILE);

				try {
					FileUtils.copyFile(srcFile, new File(imagePath));
				} catch (IOException e) {
					LogUtility.logException(name, "Could not capture screenshot", e, LoggingLevel.ERROR, true);
				}
			}
		}
	}

	public void getApp() {
		try {
			ConcurrentEngines.getEngine().getNavigator().goToUrl(ConcurrentEngines.envParams.getAppUrl());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	public void maximizeWindow() {
		ConcurrentEngines.getEngine().getWindows().maximizeWindow();
	}
}
