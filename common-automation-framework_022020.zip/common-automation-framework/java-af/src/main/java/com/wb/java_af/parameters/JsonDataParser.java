package com.wb.java_af.parameters;

import static com.wb.java_af.utilities.TestConstants.FP;

import java.io.FileReader;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

public class JsonDataParser {

	private Engine engine;

	private final String filePath = "src" + FP + "main" + FP + "resources" + FP + "data" + FP;
	private final String testDataListName = "testDataList";
	private Map<String, String> testDataMap;

	public Map<String, String> getTestDataMap() {
		return testDataMap;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public JsonDataParser(Engine engine) {
		this.engine = engine;
	}

	/**
	 * Parses test data set for a test case
	 * 
	 * @param: fileName: JSON file to fetch the data from : e.g : test.json
	 * @param: testCaseName: Test Case name to fetch the test data ; e.g : test case
	 *         1
	 * 
	 * @return: Test Data map
	 * 
	 * @author:Sanjay Samantaray
	 *
	 */
	@SuppressWarnings({ "unchecked" })
	public Map<String, String> parseJsonTestData(String fileName, String testCaseName) throws Exception {
		try {
			JSONParser parser = new JSONParser();
			JSONObject config = (JSONObject) parser.parse(new FileReader(filePath + fileName));
			JSONObject data = (JSONObject) config.get(testDataListName);
			testDataMap = (Map<String, String>) data.get(testCaseName);
			LogUtility.logInfo(" : Loaded test data from file: " + fileName + " : " + testDataMap);
		} catch (JsonSyntaxException jse) {
			LogUtility.logException("parseJsonTestData", "Incorrect Json syntax. Please check the json " + fileName,
					jse, LoggingLevel.ERROR, true);
		} catch (JsonIOException jio) {
			LogUtility.logException("parseJsonTestData", "Json File not found or inaccessible at " + fileName, jio,
					LoggingLevel.ERROR, true);
			jio.printStackTrace();
		}
		return testDataMap;
	}

	/**
	 * Parses single set of test data from a test case which contains multiple data
	 * set.
	 * 
	 * @param: fileName : JSON file to fetch the data from : e.g : test.json
	 * @param: testCaseName : Test Case name to fetch the data from ; e.g : test
	 *         case 1
	 * @param: testDataName : Test data name to fetch the test data : e.g : test
	 *         data 1
	 * 
	 * @return: Test Data map
	 * 
	 * @author:Sanjay Samantaray
	 *
	 */
	@SuppressWarnings({ "unchecked" })
	public Map<String, String> parseJsonTestData(String fileName, String testCaseName, String testDataName)
			throws Exception {
		try {
			JSONParser parser = new JSONParser();
			JSONObject config = (JSONObject) parser.parse(new FileReader(filePath + fileName));
			JSONObject data = (JSONObject) config.get(testDataListName);
			JSONObject testName = (JSONObject) data.get(testCaseName);
			testDataMap = (Map<String, String>) testName.get(testDataName);
			LogUtility.logInfo(" : Loaded test data from file: " + fileName + " : " + testDataMap);
		} catch (JsonSyntaxException jse) {
			LogUtility.logException("parseJsonTestData", "Incorrect Json syntax. Please check the json " + fileName,
					jse, LoggingLevel.ERROR, true);
		} catch (JsonIOException jio) {
			LogUtility.logException("parseJsonTestData", "Json File not found or inaccessible at " + fileName, jio,
					LoggingLevel.ERROR, true);
			jio.printStackTrace();
		}
		return testDataMap;
	}

	/**
	 * Parses environment specific test data set for a test case
	 * 
	 * @param: fileName : JSON file to fetch the data from : e.g : test.json
	 * @param: testCaseName : Test Case name to fetch the data from ; e.g : test
	 *         case 1
	 * @param: environment : Test environment name to fetch the test data : e.g : qa
	 * 
	 * @return: Test Data map
	 * 
	 * @author:Sanjay Samantaray
	 *
	 */

	@SuppressWarnings({ "unchecked" })
	public Map<String, String> parseJsonTestDataByEnvironment(String fileName, String testCaseName, String environment)
			throws Exception {
		try {
			JSONParser parser = new JSONParser();
			JSONObject config = (JSONObject) parser.parse(new FileReader(filePath + fileName));
			JSONObject testListData = (JSONObject) config.get(testDataListName);
			JSONObject testCaseData = (JSONObject) testListData.get(testCaseName);
			testDataMap = (Map<String, String>) testCaseData.get(environment);
			LogUtility.logInfo(" : Loaded test data from file: " + fileName + " : " + testDataMap);
		} catch (JsonSyntaxException jse) {
			LogUtility.logException("parseJsonTestDataByEnvironment",
					"Incorrect Json syntax. Please check the json " + fileName, jse, LoggingLevel.ERROR, true);
		} catch (JsonIOException jio) {
			LogUtility.logException("parseJsonTestDataByEnvironment",
					"Json File not found or inaccessible at " + fileName, jio, LoggingLevel.ERROR, true);
			jio.printStackTrace();
		}
		return testDataMap;
	}

	/**
	 * Parses environment specific single set of test data from a test case which
	 * contains multiple data set.
	 * 
	 * @param: fileName : JSON file to fetch the data from : e.g : test.json
	 * @param: testCaseName : Test Case name to fetch the data from ; e.g : test
	 *         case 1
	 * @param: enviornment : Test environment name to fetch the test data : e.g : qa
	 * @param: testDataName : Test data name to fetch the test data : e.g : test
	 *         data 1
	 * 
	 * @return: Test Data map
	 * 
	 * @author:Sanjay Samantaray
	 *
	 */

	@SuppressWarnings({ "unchecked" })
	public Map<String, String> parseJsonTestDataByEnvironment(String fileName, String testCaseName, String enviornment,
			String testDataName) throws Exception {
		try {
			JSONParser parser = new JSONParser();
			JSONObject config = (JSONObject) parser.parse(new FileReader(filePath + fileName));
			JSONObject testListData = (JSONObject) config.get(testDataListName);
			JSONObject testCaseData = (JSONObject) testListData.get(testCaseName);
			JSONObject testEnvData = (JSONObject) testCaseData.get(enviornment);
			testDataMap = (Map<String, String>) testEnvData.get(testDataName);
			LogUtility.logInfo(" : Loaded test data from file: " + fileName + " : " + testDataMap);
		} catch (JsonSyntaxException jse) {
			LogUtility.logException("parseJsonTestDataByEnvironment",
					"Incorrect Json syntax. Please check the json " + fileName, jse, LoggingLevel.ERROR, true);
		} catch (JsonIOException jio) {
			LogUtility.logException("parseJsonTestDataByEnvironment",
					"Json File not found or inaccessible at " + fileName, jio, LoggingLevel.ERROR, true);
			jio.printStackTrace();
		}
		return testDataMap;
	}
}
