package com.wb.java_af.perfecto;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.perfecto.reportium.ReportiumClientBuilder;

public class Perfecto {
	
	private Engine engine;
	private ReportiumClientBuilder perfectoReportiumBuilder;
	private MobileBrowser mobileBrowser;
	private MobileActions mobileActions;
	private MobileAppilication mobileAppilication;
	

	public Perfecto(Engine engine) {
		this.engine = engine;
		initializeReportium(engine);
		initializeMobileBrowser(engine);
		initializeMobileActions(engine);
		initializeMobileApplication(engine);
	}
	
	private void initializeMobileBrowser(Engine engine) {
		mobileBrowser = new MobileBrowser(engine);
	}
	
	private void initializeMobileActions(Engine engine) {
		mobileActions = new MobileActions(engine);
	}
	
	private void initializeMobileApplication(Engine engine) {
		mobileAppilication = new MobileAppilication(engine);
	}
	
	private void initializeReportium(Engine engine) {
		perfectoReportiumBuilder = new ReportiumClientBuilder(engine);
	}


	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	

	public ReportiumClientBuilder getReportiumClient() {
		return perfectoReportiumBuilder;
	}

	public void setPerfectoReportiumBuilder(ReportiumClientBuilder perfectoReportiumBuilder) {
		this.perfectoReportiumBuilder = perfectoReportiumBuilder;
	}

	public MobileBrowser getMobileBrowser() {
		return mobileBrowser;
	}

	public void setMobileBrowser(MobileBrowser mobileBrowser) {
		this.mobileBrowser = mobileBrowser;
	}

	public MobileActions getMobileActions() {
		return mobileActions;
	}

	public void setMobileActions(MobileActions mobileActions) {
		this.mobileActions = mobileActions;
	}

	public MobileAppilication getMobileAppilication() {
		return mobileAppilication;
	}

	public void setMobileAppilication(MobileAppilication mobileAppilication) {
		this.mobileAppilication = mobileAppilication;
	}
	
}
