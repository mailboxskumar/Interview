package com.wb.java_af.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author spothula-adm
 *
 */
public class UnitTestManageAlertsPage {
	UnitTestViewAccountsPage viewAccountsPage = new UnitTestViewAccountsPage();
	int count;
	private String accountPageTitle;
	private String selectAccount;

	public UnitTestManageAlertsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(ConcurrentEngines.getEngine().getAppiumDriver()), this);
	}

	@AndroidFindBy(xpath = "//*[@resourceid='com.malauzai.websterbank:id/btn_alerts']")
	@iOSFindBy(xpath = "//*[@label='Manage Alerts']")
	@CacheLookup
	protected MobileElement txtManageAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Account Alerts']")
	@iOSFindBy(xpath = "//*[@label='Account Alerts']")
	@CacheLookup
	protected MobileElement txtAccountAlerts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='Select Account']")
	@CacheLookup
	protected MobileElement titleSelectAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/account_info")
	@iOSFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell")
	protected List<RemoteWebElement> accountsListedCount;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//XCUIElementTypeNavigationBar/XCUIElementTypeOther")
	@CacheLookup
	protected MobileElement titleAccountNameNavigationBar;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy()
	@iOSFindBy(xpath = "//*[@label='Close']")
	@CacheLookup
	protected MobileElement btnClose;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Choose an account to configure alerts']")
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Choose an account to configure alerts']")
	@CacheLookup
	protected MobileElement lblNameConfigureAlerts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='TEXT']")
	@iOSFindBy(xpath = "//*[@label='Phone']")
	@CacheLookup
	protected MobileElement textIcon;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/configure_delivery_options_config_message")
	@iOSFindBy(xpath = "//*[@label='Enter the phone number(s) where you wish to receive text alerts']")
	@CacheLookup
	protected MobileElement lblEnterPhoneNumberMessage;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/configure_delivery_options_config_message")
	@iOSFindBy(xpath = "//*[@label='*Message and data rates may apply']")
	@CacheLookup
	protected MobileElement lblDataRatesApplyMessage;

	@AndroidFindBy(xpath = "//android.widget.EditText[@text='(224) 623-2626']")
	@iOSFindBy(xpath = "//*[@label='Primary Phone Number' and @value='(224) 623-2626']")
	@CacheLookup
	protected MobileElement lblPrimaryPhoneNumber;

	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Secondary Phone Number']")
	@iOSFindBy(xpath = "//*[@value='Secondary Phone Number']")
	@CacheLookup
	protected MobileElement lblSecondaryPhoneNumber;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy()
	@iOSFindBy(xpath = "//*[@label='Text Alerts']")
	@CacheLookup
	protected MobileElement textAlertsTitle;

	/** Need to provide the locator for Android **/
	// @AndroidFindBy(xpath = "")
	@iOSFindBy(xpath = "//XCUIElementTypeTextView[starts-with(@value, 'Available balance of')]")
	@CacheLookup
	protected MobileElement availableBalanceAmountLess;

	@iOSFindBy(xpath = "//XCUIElementTypeTextView[starts-with(@value, 'Available balance of')]")
	@CacheLookup
	protected MobileElement availableBalanceAmountMore;

	@iOSFindBy(xpath = "//XCUIElementTypeTextView[starts-with(@value, 'Credit transaction of')]")
	@CacheLookup
	protected MobileElement creditTransactionAmountMore;

	@iOSFindBy(xpath = "//XCUIElementTypeTextView[starts-with(@value, 'Debit transaction of')]")
	@CacheLookup
	protected MobileElement debitTransactionAmountMore;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Enter Amount']")
	@CacheLookup
	protected MobileElement enterAmountPopup;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Save']")
	@CacheLookup
	protected MobileElement btnSave;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Close']")
	@CacheLookup
	protected MobileElement closeButtonPopup;

	@iOSFindBy(xpath = "//XCUIElementTypeTextField[contains(@value,'.00')]")
	@CacheLookup
	protected MobileElement txtAmountField;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@label='Amount should be greater than zero']")
	@CacheLookup
	protected MobileElement lblThresholdErrorMessage;

	@iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Ok']")
	@CacheLookup
	protected MobileElement btnOk;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Sorry, none of your accounts are eligible to use this feature.']")
	@iOSFindBy(xpath = "//*[@label='Sorry, none of your accounts are eligible to use this feature.']")
	@CacheLookup
	protected MobileElement errorMessageClosedAccount;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Error']")
	@iOSFindBy(xpath = "//*[@value='Error']")
	@CacheLookup
	protected MobileElement errorTitle;

	/**
	 * Method to click on Manage Alerts Text
	 * 
	 * @throws Exception
	 */
	public void clickManageAlerts() throws Exception {
		try {
			txtManageAlerts.click();
			LogUtility.logInfo("--->Manage Alerts Option clicked<---");
			viewAccountsPage.isElementPresent(txtManageAlerts, 4);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Manage Alerts Text Option<---" +e.getStackTrace());
			throw new Exception("Unable to click on Manage Alerts Text Option " + e);
		}
	}

	/**
	 * Method to click on Account Alerts Text and verify the select account title
	 * 
	 * @throws Exception
	 */
	public void clickAccountAlertsOption() throws Exception {
		try {
			txtAccountAlerts.click();
			LogUtility.logInfo("--->Account Alerts Option clicked<---");
			viewAccountsPage.isElementPresent(titleSelectAccounts, 4);
		} catch (Exception e) {
			LogUtility.logError("--->Failed while clicking on Account Alerts option<--- " + e.getStackTrace());
			throw new Exception("Failed while clicking on Account Alerts option " + e);
		}
	}

	/**
	 * Method to click on Account Alerts Text and verify the select account title
	 * 
	 * @throws Exception
	 */
	public void clickAccountAlerts() throws Exception {
		try {
			txtAccountAlerts.click();
			LogUtility.logInfo("--->Account Alerts Option clicked<---");
			viewAccountsPage.isElementPresent(errorTitle, 4);
		} catch (Exception e) {
			LogUtility.logError("--->Failed while clicking on Account Alerts option<---" + e.getStackTrace());
			throw new Exception("Failed while clicking on Account Alerts option " + e);
		}
	}

	/**
	 * Method to return number of accounts displayed in Alerts Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getCountOfAccounts() throws Exception {
		try {
			ConcurrentEngines.getEngine().getWait().staticWait(10);
			return accountsListedCount.size();
		} catch (Exception e) {
			LogUtility.logError("--->Unable to the count of accounts listed<---" + e.getStackTrace());
			throw new Exception("Unable to the count of accounts listed " + e);
		}
	}

	/**
	 * Method to get list of accounts after selecting Account Alerts in Manage
	 * alerts page
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<String> getListOfAccounts() throws Exception {
		try {
			String accountName = null;
			List<String> accts = new ArrayList<String>();
			int count = getCountOfAccounts();
			for (int i = 1; i <= count; i++) {
				accountName = ConcurrentEngines.getEngine().getAppiumDriver()
						.findElement(By.xpath("//XCUIElementTypeCell[" + i + "]/XCUIElementTypeStaticText[2] | "
								+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])["
								+ i + "]"))
						.getText();
				accts.add(accountName);
			}
			return accts;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to get the accounts listed<---" + e.getStackTrace());
			throw new Exception("Unable to get the accounts listed " + e);
		}
	}

	/**
	 * Method to select any account from the list of accounts displayed in alerts
	 * page Will verify the account selected is opened
	 * 
	 * @throws Exception
	 */
	public String clickOnAnyAccount() throws Exception {
		for (int i = 1; i <= accountsListedCount.size(); i++) {
			selectAccount = ConcurrentEngines.getEngine().getAppiumDriver()
					.findElement(By.xpath("//XCUIElementTypeCell[" + i + "]/XCUIElementTypeStaticText[2] | "
							+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])["
							+ i + "]"))
					.getText();
			WebElement clickOnAccount = ConcurrentEngines.getEngine().getAppiumDriver()
					.findElement(By.xpath("//XCUIElementTypeCell[" + i + "]/XCUIElementTypeStaticText[2] | "
							+ "(//android.widget.TextView[@resource-id='com.malauzai.websterbank:id/account_name'])["
							+ i + "]"));
			LogUtility.logInfo("Account selected " + selectAccount);
			clickOnAccount.click();
			break;
		}
		// isElementPresent(closeButton, 4);
		Thread.sleep(4000);
		accountPageTitle = titleAccountNameNavigationBar.getText();
		if (accountPageTitle.contains(selectAccount)) {
			LogUtility.logInfo("Account selected and Navigated to " + selectAccount + " & " + accountPageTitle);
		}
		return accountPageTitle;
	}

	/**
	 * Method to verify the account last four digits displayed
	 * 
	 * @throws Exception
	 */
	public void verifyLastFourDigitsDisplayed() throws Exception {
		String accountDisplayed = accountPageTitle;
		String replaceTitle = accountDisplayed.replace(selectAccount + " (...", "");
		replaceTitle = replaceTitle.replace(")", "");
		int acctLength = replaceTitle.length();
		if (acctLength == 4) {
			LogUtility.logInfo("Account displayed with last four digits " + replaceTitle);
		} else {
			throw new Exception("Account not displayed with last four digits " + replaceTitle);
		}
	}

	/**
	 * Method to verify the label name in alerts page
	 * 
	 * @param label
	 * @throws Exception
	 */
	public void verifyLabelName(String label) throws Exception {
		try {
			String labelNameDisplayed = lblNameConfigureAlerts.getText();
			Assert.assertEquals(label, labelNameDisplayed);
			LogUtility.logInfo("Label displayed as " + labelNameDisplayed + " and verified with expected label name");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the label name "+label+ " due to " +e.getStackTrace());
			throw new Exception("Unable to verify the label name " + e);
		}
	}

	/**
	 * Method to click on Text Icon in Manage alerts page
	 * 
	 * @throws Exception
	 */
	public void clickOnTextIcon() throws Exception {
		try {
			textIcon.click();
			LogUtility.logInfo("Clicked on text icon");
			viewAccountsPage.isElementPresent(textAlertsTitle, 5);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to click on Text Icon "+e.getStackTrace());
			throw new Exception("Unable to click on Text Icon " + e);
		}
	}

	/**
	 * Method to verify the message on Text Alerts screen
	 * 
	 * @param message
	 * @throws Exception 
	 */
	public void verifyTextAlertsScreenMessage(String message) throws Exception {
		try {
			String messageDisplayed = lblEnterPhoneNumberMessage.getText();
			LogUtility.logInfo("Message displayed as " + messageDisplayed);
			// Assert.assertEquals(messageDisplayed, message);
			if (messageDisplayed.contains(message)) {
				LogUtility.logInfo("Message displayed as " + messageDisplayed);
			} else {
				throw new Exception("Message displayed is not matched with the expected message " + messageDisplayed);
			}
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the label Enter Phone Number/Message displayed "+e.getStackTrace());
			throw new Exception("Unable to verify the label Enter Phone Number "+e);
		}
	}

	/**
	 * Method to verify the data rates apply message on alerts page
	 * 
	 * @param message
	 */
	public void verifyDataRatesMessage(String message) {
		try {
			String ratesMessage = lblDataRatesApplyMessage.getText();
			LogUtility.logInfo("Message displayed as " + ratesMessage);
			if (ratesMessage.contains(message)) {
				LogUtility.logInfo("Message displayed as " + ratesMessage);
			} else {
				throw new Exception("Message displayed is not matched with the expected message " + ratesMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to verify Primary and Secondary phone numbers text field
	 * 
	 * @throws Exception
	 */
	public void verifyNumberTextFields() throws Exception {
		try {
			lblPrimaryPhoneNumber.isDisplayed();
			lblSecondaryPhoneNumber.isDisplayed();
		} catch (Exception e) {
			throw new Exception("Unable to verify the phone number text fields " + e);
		}
	}

	/**
	 * Methos to verify the Threshold amount options in alerts page
	 * 
	 * @throws Exception
	 */
	public void verifyThresholdAmountOptions() throws Exception {
		try {
			availableBalanceAmountLess.isDisplayed();
			availableBalanceAmountMore.isDisplayed();
			creditTransactionAmountMore.isDisplayed();
			debitTransactionAmountMore.isDisplayed();
			LogUtility.logInfo("Displayed");
		} catch (Exception e) {
			throw new Exception("Unable to verify the Threshold amount options " + e);
		}
	}

	/**
	 * Methos to click on any tHreshold amount alert option
	 * 
	 * @throws Exception
	 */
	public void clickOnAnyThresholdAmount() throws Exception {
		try {
			availableBalanceAmountLess.click();
			viewAccountsPage.isElementPresent(enterAmountPopup, 4);
			LogUtility.logInfo("Enter amount popup displayed");
		} catch (Exception e) {
			throw new Exception("Unable to click on threshold amount option in alerts page " + e);
		}
	}

	/**
	 * Method to verify the enter amount popup display
	 * 
	 * @throws Exception
	 */
	public void enterAmountPopupDisplay() throws Exception {
		try {
			enterAmountPopup.isDisplayed();
			btnSave.isDisplayed();
			btnClose.isDisplayed();
		} catch (Exception e) {
			throw new Exception("Unable to verify the enter amount popup " + e);
		}
	}

	/**
	 * Method to enter the amount in amount text field
	 * 
	 * @param amount
	 * @throws Exception
	 */
	public void enterAmount(String amount) throws Exception {
		try {
			txtAmountField.clear();
			txtAmountField.sendKeys(amount);
			LogUtility.logInfo("--->Amount entered as "+amount);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to enter the "+amount+ "in text field  "+e.getStackTrace());
			throw new Exception("Unable to enter the amount in text field " + e);
		}
	}

	/**
	 * Method to click on Save button
	 * 
	 * @throws Exception
	 */
	public void clickSaveButton() throws Exception {
		try {
			btnSave.click();
			LogUtility.logInfo("--->Clicked on Save butto<---");
		} catch (Exception e) {
			LogUtility.logError("--->Unble click on save button "+e.getStackTrace());
			throw new Exception("Unble click on save button " + e);
		}
	}

	/**
	 * Method to verify the threshold error message when amount enter $0.00
	 * 
	 * @param error
	 * @throws Exception
	 */
	public void verifyThresholdErrorMessage(String error) throws Exception {
		try {
			String errorMessage = lblThresholdErrorMessage.getText();
			Assert.assertEquals(errorMessage, error);
			btnOk.isDisplayed();
			LogUtility.logInfo("Error message and OK button verified " + errorMessage);
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message "+error+" "+e.getStackTrace());
			throw new Exception("Unable to verify the error message " + error + " due to " + e);
		}
	}

	/**
	 * Method to verify the error message in alerts page for closed accounts
	 * 
	 * @param errorMessage
	 * @return
	 * @throws Exception
	 */
	public String verifyErrorMessageForClosedAccounts(String errorMessage) throws Exception {
		try {
			String errorMsg = errorMessageClosedAccount.getText();
			LogUtility.logInfo(errorMsg);
			Assert.assertEquals(errorMsg, errorMessage);
			LogUtility.logInfo("--->Error message displayed as " +errorMsg);
			return errorMsg;
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the message "+errorMessage+" "+e.getStackTrace());
			throw new Exception("Unable to verify the error message " + errorMessage + " due to " + e);
		}
	}

}
