package com.wb.java_af.perfecto;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Performs operations on a mobile application
 * 
 * @author Bharat Pandey
 *
 */
public class MobileAppilication {

	public Engine engine;

	public MobileAppilication(Engine engine) {
		this.engine = engine;
	}
	
	/**
	 * Opens an application by name
	 * 
	 * @param name - 	The application name as it is displayed on the device screen.
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String openApplication(String name) {
		String reStr;
		PerfectoParameters params = new PerfectoParameters("name", name);
		try {
			reStr = new PerfectoActionExecutor(engine).executeAction("mobile:application:open", params);
		} catch (Exception e) {
			LogUtility.logException("closeApplication", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return reStr;
	}
	
	/**
	 * Opens an application by identifier
	 * 
	 * @param identifier - The identifier of the application.
	 * @param timeout - 
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String openApplicationByIdentifier(String identifier) {
		String reStr;
		PerfectoParameters params = new PerfectoParameters("identifier", identifier);
		try {
			reStr = new PerfectoActionExecutor(engine).executeAction("mobile:application:open", params);
		} catch (Exception e) {
			LogUtility.logException("closeApplication", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return reStr;
	}


	/**
	 * Closes an application on the device by name. Application process is killed, not
	 * minimized. If you reopen the application, the application will launch from
	 * the start page. (If you minimize the application, e.g. using the Home button,
	 * the application will launch from the last page previously open.)
	 * 
	 * @param name - The application name as it is displayed on the device screen
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String closeApplication(String name) {
		String reStr;
		PerfectoParameters params = new PerfectoParameters("name", name);
		try {
			reStr = new PerfectoActionExecutor(engine).executeAction("mobile:application:close", params);
		} catch (Exception e) {
			LogUtility.logException("closeApplication", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return reStr;
	}


	/**
	 * Closes an application on the device by identifier. Application process is killed, not
	 * minimized. If you reopen the application, the application will launch from
	 * the start page. (If you minimize the application, e.g. using the Home button,
	 * the application will launch from the last page previously open.)
	 * 
	 * @param name - The identifier of the application (ex. com.malauzai.app.login.splashscreen.SplashScreen)
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String closeApplicationByIdentifier(String identifier) {
		String reStr;
		PerfectoParameters params = new PerfectoParameters("identifier", identifier);
		try {
			reStr = new PerfectoActionExecutor(engine).executeAction("mobile:application:close", params);
		} catch (Exception e) {
			LogUtility.logException("closeApplicationByIdentifier", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return reStr;
	}

	/**
	 * The command identifies the active application automatically and then moves it to the background for the timeout defined and then returns it to the foreground.
	 * @param timeout - The time, in seconds, to run the current application as a background application. (Default 20 seconds)
	 * @return
	 * 
	 * @author Bharat Pandey
	 */
	public String runAppInBackground(String timeout) {
		String reStr;
		PerfectoParameters params = new PerfectoParameters("timeout", timeout);
		try {
			reStr = new PerfectoActionExecutor(engine).executeAction("mobile:application:back", params);
		} catch (Exception e) {
			LogUtility.logException("closeApplicationByIdentifier", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return reStr;
	}

}
