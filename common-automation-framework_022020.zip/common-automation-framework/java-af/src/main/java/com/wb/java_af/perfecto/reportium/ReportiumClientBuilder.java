package com.wb.java_af.perfecto.reportium;

import java.util.Properties;

import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.CustomField;
import com.perfecto.reportium.model.Job;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.wb.java_af.engine.Engine;
import com.wb.java_af.testbases.CucumberTestBase;

public class ReportiumClientBuilder {

	private Engine engine;
	private Properties props = CucumberTestBase.props;
	private ReportiumClient reportiumClient = null;
	private String jenkinsJobName;
	private String jenkinsBuildNumber;
	private String jenkinsBranchName;

	public ReportiumClientBuilder(Engine engine) {
		this.engine = engine;
	}

	public ReportiumClient getInstance() {
		if (reportiumClient == null) {
			jenkinsJobName = System.getProperty("jenkinsJobName");
			jenkinsBuildNumber = System.getProperty("jenkinsBuildNumber");
			jenkinsBranchName = System.getProperty("jenkinsGitBranch");
			if (jenkinsJobName.equals("local") || jenkinsBranchName.equals("local")
					|| jenkinsBuildNumber.equals("local")) {
				PerfectoExecutionContext perfectoExecutionContext = new PerfectoExecutionContext.PerfectoExecutionContextBuilder()
						.withProject(new Project(props.getProperty("reportium.project.name"),
								props.getProperty("reportium.project.version")))
						.withCustomFields(new CustomField("programmer", "Webster Automation Team"))
						.withWebDriver(engine.getAppiumDriver()).build();
				reportiumClient = new ReportiumClientFactory().createPerfectoReportiumClient(perfectoExecutionContext);
			} else {
				PerfectoExecutionContext perfectoExecutionContext = new PerfectoExecutionContext.PerfectoExecutionContextBuilder()
						.withProject(new Project(props.getProperty("reportium.project.name"),
								props.getProperty("reportium.project.version")))
						.withJob(new Job(jenkinsJobName, Integer.parseInt(jenkinsBuildNumber))
								.withBranch(jenkinsBranchName))
						.withCustomFields(new CustomField("Group", "Webster Automation Team")).withContextTags("Smoke")
						.withWebDriver(engine.getWebDriver()).build();
				reportiumClient = new ReportiumClientFactory().createPerfectoReportiumClient(perfectoExecutionContext);
			}
		}
		return reportiumClient;
	}

}
