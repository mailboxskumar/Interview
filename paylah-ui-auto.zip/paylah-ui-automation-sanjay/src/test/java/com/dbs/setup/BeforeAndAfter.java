package com.dbs.setup;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.AfterStories;
import org.jbehave.core.annotations.AfterStory;
import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.BeforeStories;
import org.jbehave.core.annotations.BeforeStory;

import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

public class BeforeAndAfter {

	private static final Logger logger = Logger.getLogger(BeforeAndAfter.class);
	
	@BeforeStories
	public void beforeStories() throws Exception {
		logger.info("@BeforeStories method of JBehave");
		try {/*
			String value = DriverManagerFactory.driverData.get("RunTestOn").trim();
			switch (value.toUpperCase()) {

			case "BOTH":
				DriverManagerFactory.getMobileManager().getMobileDriver();
				DriverManagerFactory.getManager().getWebDriver().get(Config.IB_URL);
				DriverManagerFactory.updateAsInUse();
				break;

			case "IB":
				DriverManagerFactory.getManager().getWebDriver().get(Config.IB_URL);
				DriverManagerFactory.updateAsInUse();
				break;

			case "MB":
				DriverManagerFactory.getMobileManager().getMobileDriver();
				DriverManagerFactory.updateAsInUse();
				break;
			}
			*/
		logger.info("End of @BeforeStories method of JBehave");	
		} catch (Throwable e) {
			logger.error("Exception occurred "+e.getLocalizedMessage());
			Config.gracefulEnd(e,logger);
		}
	}

	@AfterStories
	public void afterStories() {
		logger.info("@AfterStories method of JBehave");
		try {
			DriverManagerFactory.getMobileManager().quitMobileDriver();
			DriverManagerFactory.getManager().quitWebDriver();
			DriverManagerFactory.updateAsNotInUse();
		logger.info("End of @AfterStories method of JBehave");
		} catch (Exception e) {
			DriverManagerFactory.updateAsNotInUse();
			logger.error("Exception occurred "+e.getLocalizedMessage());
			Config.gracefulEnd(e,logger);
		}

	}

	@BeforeStory
	public void beforeStory() throws Exception {
		logger.info("@BeforeStory method of JBehave");
		
		// your code
		
		logger.info("End of @BeforeStory method of JBehave");
	}

	@AfterStory
	public void afterStory() throws Exception {
		logger.info("@AfterStory method of JBehave");
		
		// your code
		
		logger.info("End of @AfterStory method of JBehave");
	}

	@BeforeScenario
	public void beforeScenario() {
		logger.info("Before Scenario :::");
		
	}

	@AfterScenario
	public void afterScenario() {
		logger.info("After Scenario :::");
		/*try {
			if (DriverManagerFactory.getManager().getWebDriver() != null
					|| (DriverManagerFactory.getManager().getMobileDriver() != null)) {
				
				DriverManagerFactory.getMobileManager().getMobileDriver().closeApp();
				//DriverManagerFactory.getManager().quitWebDriver();
				logger.info("End of After Scenario :::");
			} else {
				logger.info("Both drivers are null");
				logger.info("End of After Scenario :::");
			}
		} catch(Throwable e) {
			if(e.getLocalizedMessage().contains("null"))
				logger.warn("Driver can't be closed as the driver is not initialized");
			else {
				logger.error("Exception occurred "+e.getLocalizedMessage());
				Config.gracefulEnd(e,logger);
			}
			
		}*/

	}

}
