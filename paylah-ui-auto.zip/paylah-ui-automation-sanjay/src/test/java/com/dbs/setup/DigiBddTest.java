package com.dbs.setup;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.anarsoft.vmlens.concurrent.junit.ConcurrentTestRunner;
import com.anarsoft.vmlens.concurrent.junit.ThreadCount;
import org.junit.runners.BlockJUnit4ClassRunner;
import com.dbs.commons.ConnectDB;
import com.dbs.commons.RunDetails;
import com.dbs.config.Config;
import com.dbs.controller.TestConfiguration;

@RunWith(ConcurrentTestRunner.class)
public class DigiBddTest {
	public static final Logger logger = Logger.getLogger(DigiBddTest.class);
	public static final int THREAD_COUNT = 1;
	//public static String metaFilter = "+billpayE2E+ +SendMoney+ +createQR+ +Requestforfund+ +InviteAndEarn+ +changeWalletLimit+ +changeDailyLimit+ +topupFromManagePayLah";
	//public static String metaFilter = "+TopupthoughMANAGE+ +WithdrawThoughMANAGE+ +DonationThroughPay";
	public static String metaFilter = "+DonationThroughPay";
	public static String customJiraLabel = "HealthCheck";
	public static String[] packageNames = { "com.dbs.in.mb.steps", "com.dbs.in.ib.steps" };
	/*
	 * For JiraTabName, device description from config is used by default, however
	 * custom name can be specified in below variable If any value OTHER THAN "" or
	 * null is specified then it will be used.Use this ONLY when you're running with
	 * single thread, otherwise all thread report will be overwritten in single jira
	 * tab
	 */
	public static String jiraTabName = "";

	@ThreadCount(THREAD_COUNT)
	@Test
	public void run() throws Throwable {

		if (THREAD_COUNT == Config.deviceList.size()) {
			TestConfiguration testConfig = new TestConfiguration(metaFilter, packageNames, customJiraLabel,
					jiraTabName);
			Thread executor = new Thread(testConfig);
			executor.start();
			try {
				executor.join();
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		} else {
			System.out.println(
					"EXECUTION WILL NOT BE PERFORMED, NO.OF DEVICES IN THE CONFIG.XLSX IS NOT MATCHING WITH THREAD_COUNT");
		}
	}

	@Before
	public void before() throws Exception {
		Config.Logger();
		logger.info("@Before method of JUNIT");
		logger.info("Generating RunID....");
		RunDetails.runStartTime = RunDetails.getCurrentTime();
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		RunDetails.runID = formatter.format(today);
		logger.info("RunID ::" + RunDetails.runID);
		try {
			ConnectDB.connectToDB();
			if (!Config.LOCAL_RUN)
				RunDetails.insertRunDetailsIntoDB(RunDetails.runID, Config.COUNTRY, Config.ENVIRONMENT,
						Config.EXECUTION_MODE, Config.RELEASE, Config.SPRINT_NO, RunDetails.runStartTime);
		} catch (Exception e) {
			logger.info("Error in ConnectDB.connectToDB");
		}
		logger.info("End of @Before method of JUNIT");
	}

	@After
	public void after() throws Exception {
		logger.info("@After method of JUNIT");
		ConnectDB.close();
		RunDetails.runEndTime = RunDetails.getCurrentTime();
		// RunDetails.insertRunDetailsIntoDB(RunDetails.runID, Config.COUNTRY,
		// Config.ENVIRONMENT, Config.EXECUTION_MODE, Config.RELEASE, Config.SPRINT_NO,
		// RunDetails.totalScenarios, RunDetails.totalExamples,
		// RunDetails.getTotalExamplesPassed(), RunDetails.getTotalExamplesFailed(),
		// RunDetails.getTotalExamplesSkipped(), RunDetails.getTotalExamplesPending(),
		// RunDetails.runStartTime, RunDetails.runEndTime);
		logger.info("End of @After method of JUNIT");
	}
}