package com.dbs.in.ib.steps;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;

import com.dbs.drivers.DriverManager;
import com.dbs.drivers.DriverManagerFactory;
import com.dbs.in.ib.pages.AdminLoginPage;
import com.dbs.setup.BeforeAndAfter;
//import com.dbs.ib.steps.DryRunModuleStepsIB;

public class IBDryRun2Test extends BeforeAndAfter{
	
	private static final Logger logger=Logger.getLogger(IBDryRun2Test.class); 
	
	public static WebDriver driver ;
	
	AdminLoginPage mp = new AdminLoginPage();
	
	//private DryRunModuleStepsIB IBSteps = new DryRunModuleStepsIB();
	
	@Given("i opened Admin module application and User enters $username and $password")
	public void givenIBApplicationIsOpened(@Named("username")String userName, @Named("password")String password) throws Throwable {
		driver = DriverManagerFactory.getManager().getWebDriver();
		mp.txt_username().enterText("username");
		mp.txt_password().enterText("password");
		mp.btn_submit().click();
	}


	@When("User IB enters")
	public void whenUserEntersusernameAndpassword(@Named("username")String userName, @Named("password")String pwd) throws Exception {
		//IBSteps.logintoIB("usernmae", "pwd");
	}

	@Then("User should be able to see Dashboard page")
	public void thenUserShouldBeAbleToSeeDashboardPage() {
		
	}
	

}
