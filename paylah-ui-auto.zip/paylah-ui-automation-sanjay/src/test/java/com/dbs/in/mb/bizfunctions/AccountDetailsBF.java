package com.dbs.in.mb.bizfunctions;

public class AccountDetailsBF {

}
