package com.dbs.in.mb.bizfunctions;

import org.jbehave.core.steps.Steps;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.pages.LoginPage;
import com.dbs.in.mb.pages.RequestForFundPage;

import junit.framework.Assert;
import net.masterthought.cucumber.ValidationException;

public class RequestForFundBF{

	RequestForFundPage requestforfund = new RequestForFundPage();
	CommonActions commonactions = new CommonActions();
	LoginPage loginPage = new LoginPage();

	public void bf_clickRequestbutton() throws Throwable {
		requestforfund.btn_request().click();
		requestforfund.btn_tryIt().click();
	}

	public void bf_enterRequestDetails(String amount) throws Throwable {
		requestforfund.txt_totalAmount().enterText(amount);
	}

	public void bf_selectSavedmobilenumber() throws Throwable {
		Thread.sleep(3000);
		commonactions.clickBasedOnCoordinates(504, 504);
		if (requestforfund.btn_connectContacts().exists()) {
			requestforfund.btn_connectContacts().click();
			requestforfund.txt_allow().click();
		}
		requestforfund.txt_selectFromContact().click();
		requestforfund.btn_done().click();
	}

	public void bf_enterMessage(String message) throws Throwable {
		requestforfund.txt_message().enterText(message);
		Reporter.takeScreenshot();
		loginPage.btn_nexLogin().click();
		Thread.sleep(5000);
	}

	public void bf_verifyTheTransaction(String Expectedmessage) throws Throwable {
		Thread.sleep(4000);
		String popupText = requestforfund.lbl_verificationPopUp().getText();
		if (popupText.contains(Expectedmessage)) {
			Reporter.takeScreenshot();
			System.out.println(popupText);
			Thread.sleep(3000);
			requestforfund.lbl_ok().click();
		} else {
			Reporter.takeScreenshot();
			throw new ValidationException("Verification text mismatch" + popupText + "" + Expectedmessage);
		}
	}

}
