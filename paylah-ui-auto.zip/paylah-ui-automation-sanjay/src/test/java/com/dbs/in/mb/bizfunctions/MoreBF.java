package com.dbs.in.mb.bizfunctions;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.LoginPage;
import com.dbs.in.mb.pages.MorePage;

import net.masterthought.cucumber.ValidationException;

public class MoreBF {

	MorePage morepage = new MorePage();
	LoginPage loginPage = new LoginPage();
	HomePage homepage = new HomePage();

	public void bf_verifyTheProfilePercentage(String percentage) throws Throwable {
		homepage.btn_more().click();
		String percentageText = morepage.txt_profilePercentage().getText();
		System.out.println("The actual percentage " + percentageText);
		if (percentageText.contains(percentage)) {
			Reporter.takeScreenshot();
		} else {
			Reporter.takeScreenshot();
			throw new ValidationException(
					"Verification text mismatch" + morepage.txt_profilePercentage().getText() + "" + percentage);
		}
	}
  
	public void bf_clicktheAddGiftCode() throws Throwable{
		homepage.btn_more().click();
		Thread.sleep(3000);
		Reporter.takeScreenshot();
		morepage.lbl_addPromo().click();
	}
	
	public void bf_enterTheinValidPromoCode(String giftcode, String expectedAlertText) throws Throwable{
		morepage.txt_gitCode().enterText(giftcode);
		morepage.btn_submit().click();
		Thread.sleep(4000);
		if(morepage.lbl_invalidPromoCode().getText().contains(expectedAlertText)){
			Reporter.takeScreenshot();
		}else{
		Reporter.takeScreenshot();
		throw new ValidationException("Verification text mismatch" + morepage.lbl_invalidPromoCode().getText() + "" + expectedAlertText);	
	}
}
	
	public void bf_enterTheValidPromoCode(String giftcode, String expectedAlertText) throws Throwable{
		morepage.txt_gitCode().enterText(giftcode);
		morepage.btn_submit().click();
		Thread.sleep(4000);
		if(morepage.lbl_invalidPromoCode().getText().contains(expectedAlertText)){
			Reporter.takeScreenshot();
		}else{
		Reporter.takeScreenshot();
		throw new ValidationException("Verification text mismatch" + morepage.lbl_invalidPromoCode().getText() + "" + expectedAlertText);	
	}
}
}
