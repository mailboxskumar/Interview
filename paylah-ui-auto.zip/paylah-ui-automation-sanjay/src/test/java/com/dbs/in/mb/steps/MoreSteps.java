package com.dbs.in.mb.steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import com.dbs.in.mb.bizfunctions.MoreBF;

public class MoreSteps {

	MoreBF morebf = new MoreBF();

	@Then("I verify the profile complete percentage <percentage>")
	public void Iverifytheprofilecompletepercentagepercentage(@Named("percentage") String percentage) throws Throwable {
		morebf.bf_verifyTheProfilePercentage(percentage);
	}
	
	@Then("I navigate to add promo gift code page")
	public void thenINavigateToAddPromoGiftCodePage() throws Throwable {
		morebf.bf_clicktheAddGiftCode();
	}

	@Then("I verify the <promocode> and <expecteAlertMessage>")
	public void thenIVerifyThepromocodeAndexpecteAlertMessage(@Named("promocode") String promocode, @Named("expecteAlertMessage") String expecteAlertMessage) throws Throwable {
		morebf.bf_enterTheValidPromoCode(promocode,expecteAlertMessage);
	}

}
