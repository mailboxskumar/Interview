package com.dbs.in.mb.bizfunctions;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.pages.ReviewTransactionPage;

import net.masterthought.cucumber.ValidationException;

public class QRTransactionReviewBF {

	ReviewTransactionPage reviewtransactionpage = new ReviewTransactionPage();

	public void bf_reviewTheQRTransaction(String payto, String amount) throws Throwable {
		Thread.sleep(7000);
		if (reviewtransactionpage.txt_payto_lbl().getText().contains(payto)) {
			reviewtransactionpage.txt_payfromAmount().exists();
			if (reviewtransactionpage.txt_totalAmount().getText().contains(amount)) {
				Reporter.takeScreenshot();
				reviewtransactionpage.btn_letsGo().click();
				Thread.sleep(7000);
				reviewtransactionpage.txt_transactionSuccessMessage().exists();
				Reporter.takeScreenshot();
			}
		} else {
			Reporter.takeScreenshot();
			throw new Exception("Review page Verification element is missing");
		}

	}

}
