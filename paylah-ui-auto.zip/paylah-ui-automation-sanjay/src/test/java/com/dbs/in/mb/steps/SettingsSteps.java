package com.dbs.in.mb.steps;

import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.pages.ChangeWalletLimitPage;
import com.dbs.in.mb.pages.CommonPageObjects;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.ManagePayLahPage;
import com.dbs.in.mb.pages.MorePage;

import junit.framework.Assert;

public class SettingsSteps {

	HomePage homePage = new HomePage();
	MorePage morePage = new MorePage();
	ManagePayLahPage managePaylahPage = new ManagePayLahPage();
	CommonPageObjects commonObjPage = new CommonPageObjects();
	ChangeWalletLimitPage walletLimitPage = new ChangeWalletLimitPage();
	Reporter reporter = Reporter.getCurrentReporter();
	public static int walletLimitBeforeChange = 0;
	public static int walletLimitAfterChange = 0;

	@Then("I tap on More Button")
	public void thenITapOnMoreButton() throws Throwable {
		homePage.btn_more().click();
	}

	@Then("I click on Manage Paylah")
	public void thenIClickOnManagePaylah() throws Throwable {
		morePage.lbl_managePayalh().click();
	}

	@Then("I read currentWallet Limit")
	public void thenIReadwalletLimitBeforeChange() throws Throwable {
		walletLimitBeforeChange = Integer.parseInt(managePaylahPage.lbl_walletLimit().getText().substring(2));
		Reporter.takeScreenshot();

	}

	@When("I click on CurrentWallet Limit")
	public void whenIClickOnwalletLimitBeforeChange() throws Throwable {
		managePaylahPage.lbl_walletLimit().click();
	}

	@Then("I change WalletLimit")
	public void thenIChangeWalletLimit() throws Throwable {
		int count = walletLimitPage.wbLst_walletLimits().size();
		for (int i = 1; i < count; i++) {

			if (walletLimitBeforeChange != Integer
					.parseInt(walletLimitPage.wbLst_walletLimits().get(i).getText().substring(2))) {
				walletLimitPage.wbLst_walletLimits().get(i).click();
				break;
			}

		}
	}

	@Then("I click on Submit Button")
	public void thenIClickOnSubmitButton() throws Throwable {
		commonObjPage.btn_Submit().click();
	}

	@Then("I verify WalletLimit After change")
	public void thenIVerifyWalletLimitAfterChange() throws NumberFormatException, Throwable {
		walletLimitAfterChange = Integer.parseInt(managePaylahPage.lbl_walletLimit().getText().substring(2));
		Reporter.takeScreenshot();
		reporter.childlog.info("Wallet Limit Before Change:" + walletLimitBeforeChange);
		reporter.childlog.info("Wallet Limit After Change:" + walletLimitAfterChange);
		if (walletLimitBeforeChange != walletLimitAfterChange) {
			reporter.childlog.info("Wallet Limit Changed successfully");
		} else {
			reporter.childlog.error("Wallet Limit not Changed -- Verify the report and Raise a Bug");
			Assert.assertTrue(false);
		}

	}
}
