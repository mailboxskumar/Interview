package com.dbs.in.mb.bizfunctions;

import com.dbs.commons.Reporter;
import com.dbs.in.ib.bizfunctions.MerchantPageLogin;
import com.dbs.in.mb.pages.CameraPage;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.LoginPage;

import net.masterthought.cucumber.ValidationException;

public class CameraBF {

	LoginPage loginPage = new LoginPage();
	MerchantPageLogin weblogin = new MerchantPageLogin();
	HomePage homepage = new HomePage();
	CameraPage camerapage = new CameraPage();

	public void bf_navigateToCameraPageForQRScanning() throws Throwable {
		homepage.btn_scanQR().click();
		homepage.btn_tryIT().click();
		if (camerapage.btn_allow().exists()) {
			camerapage.btn_allow().click();
			camerapage.btn_album().click();
		} else {
			Reporter.takeScreenshot();
			camerapage.btn_album().click();
		}
	}

	public void bf_selectTheQRFromImages() throws Throwable {
		Reporter.takeScreenshot();
		camerapage.txt_QRName().click();
	}

	public void bf_enterTheAmountAndProceed(String expected, String amount) throws Throwable {
		Thread.sleep(7000);
		String qrScanningText = camerapage.txt_qrVerificationtext().getText();
		if (qrScanningText.contains(expected)) {
			Reporter.takeScreenshot();
			System.out.println(qrScanningText);
			Thread.sleep(3000);
			camerapage.txt_qrAmount().enterText(amount);
			Reporter.takeScreenshot();
			loginPage.btn_nexLogin().click();
		} else {
			Reporter.takeScreenshot();
			throw new ValidationException("Verification text mismatch" + qrScanningText + "" + expected);
		}
	}
}
