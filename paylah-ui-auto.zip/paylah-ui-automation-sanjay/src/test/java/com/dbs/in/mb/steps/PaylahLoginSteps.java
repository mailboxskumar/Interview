package com.dbs.in.mb.steps;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import com.dbs.commons.Reporter;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;
import com.dbs.in.mb.bizfunctions.CreateQrBF;
import com.dbs.in.mb.bizfunctions.LoginBF;
import com.dbs.in.mb.pages.AccountDetailsPage;

public class PaylahLoginSteps {

	LoginBF loginBf = new LoginBF();

	private static final Logger logger = Logger.getLogger(PaylahLoginSteps.class);

	@Given("I launch the app and select AUT environment")
	public void ILaunchNewAppAndSelectAutEnvironment() throws Throwable {
		loginBf.bf_launchApp();
		Reporter.takeScreenshot();
	}

	@Then("I am on Login Page  <username> with <password>")
	public void paylahLogin(@Named("username") String username, @Named("password") String password) throws Throwable {
		loginBf.bf_NavigateOtpPage(username, password);
		Reporter.takeScreenshot();
	}

	@Given("I am on Homepage With <username> and a <pin> and a <otp> with <password>")
	public void givenIAmOnHomepageWithusernameAndApinAndAotpWithpassword(@Named("username") String username,
			@Named("pin") String pin, @Named("otp") String otp, @Named("password") String password) throws Throwable {

		loginBf.bf_LoginEnd2End(username, pin, otp, password);
	}

	@Given("I am on Login Page with <mobilenumber>")
	public void paylahLogin(@Named("mobilenumber") String mobilenumber) throws Throwable {
		loginBf.bf_reactivationLaunchApp(mobilenumber);
		Reporter.takeScreenshot();
	}

	@Then("I enter the sms otp <smsotp>")
	public void enterthesmsOtp(@Named("smsotp") String smsotp) throws Throwable {
		loginBf.bf_enterOTP(smsotp);
		Reporter.takeScreenshot();
	}

	@Then("I enter the pll sms otp <smsotp>")
	public void enterthepllsmsOtp(@Named("smsotp") String smsotp) throws Throwable {
		loginBf.bf_enterPllOTP(smsotp);
		Reporter.takeScreenshot();
	}

	@Then("I enter the paylahpassword <paylahpassword>")
	public void enterThePaylahpassword(@Named("paylahpassword") String paylahpassword) throws Throwable {
		loginBf.bf_enterPaylahpassword(paylahpassword);
		Reporter.takeScreenshot();
	}

	@Given("I launch the app for pll")
	public void ILaunchNewAppforpll() throws Throwable {
		loginBf.bf_pllLaunchApp();
		Reporter.takeScreenshot();
	}

	@Then("I create the pll wallet with <name> and <mobilenumber> with <email>")
	public void thenICreateThePllWalletWithnameAndmobilenumberWithemail(@Named("name") String name,
			@Named("mobilenumber") String mobilenumber, @Named("email") String email) throws Throwable {
		loginBf.bf_pllWalletSignUp(name, mobilenumber, email);
	}

	@Then("I create the paylahpassword <paylahpassword>")
	public void thenICreateThePaylahpasswordpaylahpassword(@Named("paylahpassword") String paylahpassword)
			throws Throwable {
		loginBf.bf_createThePaylahPassword(paylahpassword);
	}

	@Then("I click the promo code option NO")
	public void thenIclickthepromocodeoptionNO() throws Throwable {
		loginBf.bf_clickedReferalCodeNoOption();
	}
}
