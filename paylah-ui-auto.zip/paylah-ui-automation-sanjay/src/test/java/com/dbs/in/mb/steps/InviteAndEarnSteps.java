package com.dbs.in.mb.steps;

import org.jbehave.core.annotations.Then;

import com.dbs.in.mb.bizfunctions.InviteAndEarnBF;

public class InviteAndEarnSteps {

	InviteAndEarnBF inviteandearnsteps = new InviteAndEarnBF();

	@Then("I navigate to invite and earn page")
	public void thenINavigateToInviteAndEarnPage() throws Throwable {
		inviteandearnsteps.bf_navigateToinviteAndEatnPage();

	}

	@Then("I verify the MGM code is present")
	public void thenIVerifyTheMGMCodeIsPresent() throws Throwable {
		inviteandearnsteps.bf_verifyTheMgmCode();
	}

	@Then("I share the mgm code in message")
	public void thenIShareTheMgmCodeInMessage() throws Throwable {
		inviteandearnsteps.bf_shareTheMgmCodeInMessage();
	}

}
