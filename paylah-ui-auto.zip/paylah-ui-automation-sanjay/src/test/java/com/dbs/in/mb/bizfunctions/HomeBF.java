package com.dbs.in.mb.bizfunctions;

import org.jbehave.core.steps.Steps;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.dbs.commons.ElementFinder;
import com.dbs.commons.Reporter;
import com.dbs.drivers.DriverManagerFactory;
import com.dbs.in.ib.bizfunctions.MerchantPageLogin;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.LoginPage;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class HomeBF extends Steps {

	LoginPage loginPage = new LoginPage();
	MerchantPageLogin weblogin = new MerchantPageLogin();
	HomePage homepage = new HomePage();
	Reporter reporter = Reporter.getCurrentReporter();

	public void bf_NavigateHomePage() throws Throwable {
		if (homepage.btn_home().exists()) {
			// Reporter.takeScreenshot();
		} else {
			// Reporter.takeScreenshot();
		}
	}

	public void bf_ValidateBalance() throws Throwable {
		System.err.println("ENTERED INTO METHOD");
		if (homepage.lbl_walletBalance().getText().equalsIgnoreCase("S$15.00")) {
			System.err.println("Wallet balance is validated");
		}
	}

	public double bf_getWalletBalance() throws Throwable {
		return Double.parseDouble(homepage.lbl_walletBalance().getText().substring(2));
	}

	public void bf_verifyHomepagePartnersAndServices() throws Exception, Throwable {
		int totalIconCount = homepage.wbLst_servicesIcons().size();
		for (int i = 0; i < totalIconCount; i++) {
			if (homepage.wbLst_servicesIcons().get(i).isDisplayed()) {
				reporter.childlog.info(homepage.wbLst_servicesIcons().get(i).getText());
			} else {
				Reporter.takeScreenshot();
				throw new Exception(
						"Homepage Verification element is missing :" + homepage.wbLst_servicesIcons().get(i).getText());
			}

		}
	}

	public void bf_verifyHomepageMainButtons() throws Exception, Throwable {
		int totalIconCount = homepage.wbLst_homePageMainIcons().size();
		for (int i = 0; i < totalIconCount; i++) {
			if (homepage.wbLst_homePageMainIcons().get(i).isDisplayed()) {
				reporter.childlog.info(homepage.wbLst_homePageMainIcons().get(i).getText());
			} else {
				Reporter.takeScreenshot();
				throw new Exception(
						"Homepage Verification element is missing :" + homepage.wbLst_homePageMainIcons().get(i).getText());
			}

		}
	}

	public void bf_verifyHomepagePartnersAndServicesAreSortByAlphabeticalOrder() throws Exception, Throwable {
		int totalIconCount = homepage.wbLst_servicesIcons().size();
		for (int i = 0; i < totalIconCount; i++) {
			if (homepage.wbLst_homePageMainIcons().get(i).isDisplayed()) {
				reporter.childlog.info(homepage.wbLst_servicesIcons().get(i).getText());
				ArrayList<String> orderedIcons = new ArrayList<String>();
				orderedIcons.add(homepage.wbLst_servicesIcons().get(i).getText());
				if (isSorted(orderedIcons)) {
					reporter.childlog.info("Homepage Icons Is Sort By Alphabetical Order");
				} else {
					reporter.childlog.info("Homepage Icons Is NOT Sort By Alphabetical Order");
				}
			} else {
				Reporter.takeScreenshot();
				throw new Exception(
						"Homepage Verification element is missing :" + homepage.wbLst_servicesIcons().get(i).getText());
			}

		}
	}

	public static boolean isSorted(List<String> orderedIcons) {
		String previous = "";
		for (String current : orderedIcons) {
			if (current.compareTo(previous) < 0)
				return false;
			previous = current;
		}
		return true;
	}

}
