package com.dbs.in.mb.bizfunctions;

import org.jbehave.core.annotations.Then;
import org.openqa.selenium.WebDriver;

import com.dbs.commons.Reporter;
import com.dbs.in.ib.bizfunctions.MerchantPageLogin;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.InviteAndEarnPage;
import com.dbs.in.mb.pages.LoginPage;
import com.dbs.in.mb.pages.MorePage;

public class InviteAndEarnBF {

	LoginPage loginPage = new LoginPage();
	MerchantPageLogin weblogin = new MerchantPageLogin();
	HomePage homepage = new HomePage();
	InviteAndEarnPage inviteandearn = new InviteAndEarnPage();
	MorePage morepage = new MorePage();

	public void bf_navigateToinviteAndEatnPage() throws Throwable {
		homepage.btn_more().click();
		morepage.lbl_inviteAndEarn().click();
		if (inviteandearn.lbl_pageHeader().exists()) {
			Reporter.takeScreenshot();
		} else {
			Reporter.takeScreenshot();
		}
	}

	@Then("I verify the MGM code is present")
	public void bf_verifyTheMgmCode() throws Throwable {
		if (inviteandearn.txt_referralCode().exists()) {
			Reporter.takeScreenshot();
		} else {
			Reporter.takeScreenshot();
		}
	}

	@Then("I share the mgm code in message")
	public void bf_shareTheMgmCodeInMessage() throws Throwable {
		inviteandearn.btn_share().click();
		inviteandearn.lbl_messaging().click();
		Reporter.takeScreenshot();
	}

}
