package com.dbs.in.mb.steps;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.bizfunctions.LoginBF;
import com.dbs.in.mb.bizfunctions.RequestForFundBF;

public class RequestForFundSteps {

	LoginBF login = new LoginBF();
	RequestForFundBF request = new RequestForFundBF();
	private static final Logger logger = Logger.getLogger(PaylahLoginSteps.class);

	@Then("I enter the <amount>")
	public void iEnterTheamount(@Named("amount") String amount) throws Throwable {
		Thread.sleep(5000);
		request.bf_clickRequestbutton();
		request.bf_enterRequestDetails(amount);
		Reporter.takeScreenshot();
	}

	@Then("I select any contact from contacts")
	public void selectTheMobilecontact() throws Throwable {
		request.bf_selectSavedmobilenumber();
		Reporter.takeScreenshot();
	}

	@Then("I enter the <message>")
	public void enterMessage(@Named("message") String message) throws Throwable {
		request.bf_enterMessage(message);
		Thread.sleep(4000);
	}

	@Then("I should be able to review <transactiondetails>")
	public void verifytheTransaction(@Named("transactiondetails") String Expectedmessage) throws Throwable {
		request.bf_verifyTheTransaction(Expectedmessage);
		Reporter.takeScreenshot();

	}

}
