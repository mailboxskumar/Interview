package com.dbs.in.mb.steps;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.bizfunctions.CommonActions;
import com.dbs.in.mb.bizfunctions.LoginBF;
import com.dbs.in.mb.pages.CommonPageObjects;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.PayBillsPage;
import com.dbs.in.mb.pages.SendMoneyPage;

public class BillPayment {
	
	LoginBF loginbf = new LoginBF();
	HomePage homepage=new HomePage();
	SendMoneyPage sendmoney = new SendMoneyPage();
	PayBillsPage billpay=new PayBillsPage();
	CommonPageObjects com=new CommonPageObjects();
	private static final Logger logger = Logger.getLogger(BillPayment.class);
	
	@Given("I am on Home Page with <username> and <password>")
	public void givenIAmOnHomePageWithusernameAndpassword(@Named("username") String username, @Named("password") String password) throws Throwable {
				loginbf.bf_LoginEnd2End(username,password,"111111", "qwerty");
		
	}
	
	@When("I tap on Pay Button")
	public void whenITapOnPayButton() throws Throwable {
		homepage.btn_pay().click();
	}

	@Then("I tap on Try Button")
	public void thenITapOnTryButton() throws Throwable {
		sendmoney.btn_TryIt().click();
	}

	@Then("I tap on Bill Tab")
	public void thenITapOnBillTab() throws Throwable {
		billpay.lbl_Bills().click();
	}

	@Then("I enter Billamount in Amount Text Field with <amountValue>")
	public void thenIEnterBillamountInAmountTextFieldWithamountValue(@Named("amountValue") String amountValue) throws Throwable {
		billpay.txt_payBills_amount().enterText(amountValue);
	}

	@When("I tap on payto Button")
	public void whenITapOnPaytoButton() throws Throwable {
		billpay.lbl_payBills_payTo().click();
	}

	@Then("I enter Organisation <SelectOrganisation>")
	public void thenIEnterOrganisationSelectOrganisation(@Named("SelectOrganisation") String org) throws Throwable {
	  if(billpay.lbl_payTo_selectOrgTitle().exists())
			  {
		  			billpay.txt_searchOrg().click();
		  			billpay.txt_searchOrg().enterText(org);
		  			billpay.lbl_payTo_org(org).click();
			  }
	}

	@Then("I See Selected Organisation in BillPayment Page <SelectOrganisation>")
	public void thenISeeSelectedOrganisationInBillPaymentPageSelectOrganisation() {
	 
	}

	@When("I enter BillReference No In BillReferenceNo TextField <BillRefNo>")
	public void whenIEnterBillReferenceNoInBillReferenceNoTextFieldBillRefNo(@Named("BillRefNo") String billRef) throws Throwable {
	 billpay.txt_billRef().enterText(billRef);
	}

	@Then("I tap on Next Button")
	public void thenITapOnNextButton() throws Throwable {
		billpay.btn_Next().click();
	}

	@Then("I am on Review Transaction Page")
	public void thenIAmOnReviewTransactionPage() throws Throwable {
		if (billpay.lbl_reviewTransaction_Title().exists()) {
			logger.info("Able to Navigate to BillPayment Review Page");
			Reporter.takeScreenshot();
		}
	}

	@Then("I tap LetsGo Button")
	public void thenITapLetsGoButton() throws Throwable {
		billpay.btn_payBills_letsGo().click();
	}

	

	@Then("I see BillPayment Successfull Message")
	public void thenISeeBillPaymentSuccessfullMessage() throws Throwable {
		if(com.btn_Ok().exists())
			{
				Reporter.takeScreenshot();
				com.btn_Ok().click();
			}
	  
	}

	@Then("I tap on BackToHome Button")
	public void thenITapOnBackToHomeButton() throws Throwable {
	  billpay.btn_completion_BackToHome().click();
	  Reporter.takeScreenshot();
	}

	

}
