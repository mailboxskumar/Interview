package com.dbs.in.mb.steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import com.dbs.in.mb.bizfunctions.CameraBF;
import com.dbs.in.mb.bizfunctions.MoreBF;

public class CameraSteps {
	
	MoreBF morebf = new MoreBF();
	CameraBF camerabf = new CameraBF();

	@Then("I verify click the scanqr button and scan the qr image")
	public void Iverifyclickthescanqrbuttonandscantheqrimage() throws Throwable {
		camerabf.bf_navigateToCameraPageForQRScanning();
		camerabf.bf_selectTheQRFromImages();
	}
	
	@Then("I verify the <expected> label and amount <amount> to proceed the transaction")
	public void Iverifytheexpectedlabelandamountamounttoproceedthetransaction(@Named("expected") String expected,@Named("amount") String amount) throws Throwable {
		camerabf.bf_enterTheAmountAndProceed(expected, amount);
	}
	

}
