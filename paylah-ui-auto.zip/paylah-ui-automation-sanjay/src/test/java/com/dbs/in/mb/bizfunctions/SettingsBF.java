package com.dbs.in.mb.bizfunctions;

import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.LoginPage;
import com.dbs.in.mb.pages.MorePage;
import com.dbs.in.mb.pages.RequestForFundPage;

public class SettingsBF {
	
	RequestForFundPage requestforfund = new RequestForFundPage();
	CommonActions commonactions = new CommonActions();
	LoginPage loginPage = new LoginPage();
	HomePage homepage = new HomePage();
	MorePage morepage = new MorePage();
	public void bf_navigateToManagepaylahpage() throws Throwable {
		homepage.btn_more().click();
		morepage.lbl_managePayalh().click();	
	}
	
	public void bf_chnageTheWalletLimit() throws Throwable {
			
	}

}
