package com.dbs.in.mb.bizfunctions;

import org.apache.log4j.Logger;
import org.junit.Assert;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.pages.CameraPage;
import com.dbs.in.mb.pages.MyQrCreationPage;
import com.dbs.in.mb.pages.SendMoneyPage;
import com.dbs.commons.Reporter;

public class CreateQrBF {
	
	MyQrCreationPage myqr =new MyQrCreationPage();
	SendMoneyPage sendmoneypage = new SendMoneyPage();

	
	
	public void bf_clickMyqrButton() throws Throwable{
		 myqr.lbl_homepage_myQR().click();
		 Reporter.takeScreenshot();
	}
	
	
	public void bf_verifyTheMyQRPage() throws Throwable{
		
		if(myqr.lbl_MyQr_title().exists())
		{
			sendmoneypage.btn_TryIt().click();
			Reporter.takeScreenshot();
		}
		else
		{
			Assert.assertTrue(false);
		}
	 
	}
	
	public void bf_VerifyTheMyQRPageElements() throws Throwable{
		if(myqr.lbl_MyQRCode_myWalletQrCode().exists()|myqr.lbl_MyQRCode_myOtherQrCodes().exists()|myqr.img_MyQRCode_qrCodeImg().exists()|myqr.img_MyQRCode_qrCodeCreation().exists()|myqr.lbl_MyQrCode_qrLink().exists()|myqr.btn_MyQrCode_shareVia().exists()){
		Reporter.takeScreenshot();
	}else{
		throw new Exception("My QR Code page element is missing");
	}	
	}
	
	public void bf_iTabPlus() throws Throwable{
		myqr.img_MyQRCode_qrCodeCreation().click();
		Reporter.takeScreenshot();
	}
	
	
	public void bf_createQRCodeWithDetails(String amount,String title, String expiry, String description) throws Throwable{
		myqr.txt_CreateQrCode_amount().enterText(amount);
		myqr.txt_CreateQrCode_title().enterText(title);
		Reporter.takeScreenshot();
		myqr.txt_CreateQrCode_expiryDate().click();
		myqr.txt_CreateQrCode_expiresIn(expiry).click();
		myqr.txt_itemDescription().enterText(description);
		
	}
	
	public void bf_clickCreateQRButton() throws Throwable{
		 myqr.btn_CreateQrCode_createQrCode().click();
		 Reporter.takeScreenshot();
	}
	
	
	
	
}
