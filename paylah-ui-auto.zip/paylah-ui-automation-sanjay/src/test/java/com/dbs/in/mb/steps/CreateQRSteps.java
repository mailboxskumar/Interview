package com.dbs.in.mb.steps;
import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.bizfunctions.CreateQrBF;
import com.dbs.in.mb.pages.MyQrCreationPage;

import cucumber.api.java.en.And;
public class CreateQRSteps {
	
	CreateQrBF createqrbf = new CreateQrBF();
	//private static final Logger logger = Logger.getLogger(CreateQRSteps.class);
	
	
	@Then("I tap on MyQR")
	public void whenITapOnMyQR() throws Throwable {
		createqrbf.bf_clickMyqrButton();
		Reporter.takeScreenshot();
	}

	@Then("I should land on My QR Code page")
	public void thenIShouldLandOnMyQRCodePage() throws Throwable{
		
		createqrbf.bf_verifyTheMyQRPage();
		Reporter.takeScreenshot();
	}

	@Then("I verify objects in the MY QR Code")
	public void thenIVerifyObjectsInTheMYQRCode()throws Throwable {
		createqrbf.bf_VerifyTheMyQRPageElements();
		
	 
	}

	@Then("I tap on plus image to create QR Code")
	public void ItaponplusimagetocreateQRCode() throws Throwable{
		createqrbf.bf_iTabPlus();
		Reporter.takeScreenshot();
	}
	
	@Then("I input <amountValue> and <title> with <expirytimeInDays> and <itemdescription> on the fileds")
	public void thenIInputamountValueAndtitleWithexpirytimeInDaysAnditemdescriptionOnTheFileds(@Named("amountValue") String amountValue,@Named("title") String title,@Named("expirytimeInDays") String timeInDays,@Named("itemdescription") String des) throws Throwable {
		createqrbf.bf_createQRCodeWithDetails(amountValue, title,timeInDays,des);
		Reporter.takeScreenshot();
	}
	
	@Then("I click on Create QR Code Button")
	public void thenIClickOnCreateQRCodeButton() throws Throwable {
		createqrbf.bf_clickCreateQRButton();
		Reporter.takeScreenshot();
	}


}
