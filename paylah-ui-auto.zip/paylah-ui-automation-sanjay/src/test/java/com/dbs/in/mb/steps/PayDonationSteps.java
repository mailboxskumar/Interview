package com.dbs.in.mb.steps;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.bizfunctions.HomeBF;
import com.dbs.in.mb.pages.CommonPage;
import com.dbs.in.mb.pages.PayBillsPage;
import com.dbs.in.mb.pages.PayDonationPage;

public class PayDonationSteps {

	public static double walletBalance_BeforeDonation = 0.00;
	public static double walletBalance_AfterDonation = 0.00;

	PayDonationPage donationPage = new PayDonationPage();
	HomeBF homeBf = new HomeBF();
	CommonPage commonPage = new CommonPage();
	PayBillsPage billPayPage = new PayBillsPage();

	private static final Logger logger = Logger.getLogger(TopupSteps.class);

	@Then("I read Wallet Balance Before Donation")
	public void thenIReadWalletBalanceBeforeDonation() throws Throwable {
		walletBalance_BeforeDonation = homeBf.bf_getWalletBalance();
		Reporter.takeScreenshot();
		logger.info("Current wallet Balance is:" + walletBalance_BeforeDonation);
	}

	@Then("I tap on Donation Tab")
	public void thenITapOnDonationTab() throws Throwable {
		donationPage.lbl_DonationTab().click();

	}

	@Then("I enter Donation amount in Amount Text Field with <amountValue>")
	public void thenIEnterDonationAmountInAmountTextFieldWithamountValue(@Named("amountValue") String amountValue)
			throws Throwable {
		donationPage.txt_DonationAmount().enterText(amountValue);
	}

	@When("I tap on DonateTo field")
	public void whenITapOnDonateToField() throws Throwable {
		donationPage.lbl_DonationTo().click();
	}

	@Then("I See Selected Organisation in Donation Page <SelectOrganisation>")
	public void thenISeeSelectedOrganisationInDonationPageSelectOrganisation(
			@Named("SelectOrganisation") String SelectOrganisation) throws Throwable {
		donationPage.lbl_DonateTo_Org(SelectOrganisation.trim()).click();
	}

	@Then("I enter valid NRIC number <NRICNumber>")
	public void thenIEnterValidNRICNumberNRICNumber(@Named("NRICNumber") String NRICNumber) throws Throwable {
		String defaultNRICNo = donationPage.txt_NRIC().getText();
		if (!defaultNRICNo.equals(NRICNumber)) {
			donationPage.txt_NRIC().enterText(NRICNumber);
		}
	}

	@Then("I see Donation Successfull Message")
	public void thenISeeDonationSuccessfullMessage() throws Throwable {
		if (commonPage.btn_Ok().exists()) {
			Reporter.takeScreenshot();
			commonPage.btn_Ok().click();
		}
	}

	@Then("I verify Wallet Balance after donation paid of amount <amountValue>")
	public void thenIVerifyWalletBalanceAfterDonationPaidOfAmountamountValue(@Named("amountValue") String amountValue)
			throws Throwable {
		walletBalance_AfterDonation = homeBf.bf_getWalletBalance();
		Reporter.takeScreenshot();
		logger.info("Current wallet Balance After Donation:" + walletBalance_AfterDonation);

		if (walletBalance_AfterDonation == (walletBalance_BeforeDonation - Double.parseDouble(amountValue))) {
			Reporter.getCurrentReporter().childlog
					.info("Wallet balance debited with amount : S$" + amountValue + " for donation");
		} else {
			Reporter.getCurrentReporter().childlog
					.error("Wallet balance is not debited with amount : S$" + amountValue + " for donation");
			Assert.assertTrue(false);
		}
	}

}
