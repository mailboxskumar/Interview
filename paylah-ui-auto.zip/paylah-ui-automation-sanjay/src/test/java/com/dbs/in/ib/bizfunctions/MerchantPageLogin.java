package com.dbs.in.ib.bizfunctions;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.io.IOException;

import org.jbehave.core.steps.Steps;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dbs.drivers.DriverManagerFactory;
import com.dbs.in.mb.pages.LoginPage;



public class MerchantPageLogin extends Steps {
	
	
	public void MerchantLogin()throws Throwable {
		 /*
			System.setProperty("webdriver.chrome.driver", "resources\\chromedriver.exe");
		

			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--disable-extensions");
			chromeOptions.addArguments("--disable-web-security");
			chromeOptions.addArguments("--test-type");
			capabilities.setCapability("chrome.verbose", false);

			capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
			WebDriver driver = new ChromeDriver(capabilities);
			driver.get("https://intsrp.uat.dbs.com:444/cloudemiddleware/kdw");
			driver.manage().window().maximize();
			WebDriverWait wait = new WebDriverWait(driver, 15000);
			driver = DriverManagerFactory.getManager().getWebDriver();
		*/
		
		}
	}


	
	 /*LoginPage loginPage=new LoginPage();
	
	
	public void givenILaunchNewApp() throws Throwable {
		//DriverManagerFactory.getMobileManager().getMobileDriver().closeApp();
		System.out.println("Driver is: "+DriverManagerFactory.getMobileManager().getMobileDriver());
		DriverManagerFactory.getMobileManager().getMobileDriver().launchApp();
		//DriverManagerFactory.getMobileManager().getMbDriver().launchApp();
		//DriverManagerFactory.getMobileManager().getMbDriver().installApp(appPath);
		//DriverManagerFactory.getManager().getWebDriver().get(arg0);
		loginPage.txt_env().click();
		loginPage.btn_newInstallation().click();
		loginPage.btn_register().click();
		loginPage.lbl_yesiam().click();
	  //  login.getMBActions().SwipeTillFound(direction)
	}
	
	public void logintheApp(String userName, String password) throws Throwable{
		loginPage.txt_username().enterText(userName);
		loginPage.txt_password().enterText(password);
		loginPage.btn_next().click();
		
	}
	
	public void ienterOTP(String otp) throws Throwable{
		loginPage.txt_otp().enterText(otp);
	}

	public void ienterPaylahpassword(String paylahpassword) throws Throwable{
		loginPage.txt_paylahPassword().enterText(paylahpassword);
		loginPage.btn_login().click();
		Thread.sleep(1500);
		if(loginPage.btn_Skip().exists()){
			System.out.println("Skip button is displayed");
			loginPage.btn_Skip().click();
			if(loginPage.lbl_home().exists()){
			System.out.println("Login Verified");
			}
		}else{
			System.out.println("Skip button is NOT displayed");
		}
	
		}

public void LoginPyalah(String userName, String password,String otp,String paylahpassword) throws Throwable{
	givenILaunchNewApp();
	logintheApp(userName,password);
	ienterOTP(otp);
	ienterPaylahpassword(paylahpassword);
	
}
}*/


