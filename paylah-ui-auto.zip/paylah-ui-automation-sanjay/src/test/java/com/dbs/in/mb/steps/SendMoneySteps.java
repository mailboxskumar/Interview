package com.dbs.in.mb.steps;


import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import com.dbs.in.mb.bizfunctions.CommonActions;
import com.dbs.in.mb.bizfunctions.HomeBF;
import com.dbs.in.mb.bizfunctions.LoginBF;
import com.dbs.in.mb.bizfunctions.SendMoneyBF;
import com.dbs.in.mb.pages.SendMoneyPage;

public class SendMoneySteps {

	SendMoneyBF sendmoneybf = new SendMoneyBF();
	LoginBF loginbf = new LoginBF();
	SendMoneyPage sendmoney = new SendMoneyPage();
	HomeBF homebf = new HomeBF();
	CommonActions commonactions = new CommonActions();

	@Given("I have sufficient Balance")
	public void thenIHaveSufficientBalance() throws Throwable {
		homebf.bf_ValidateBalance();
	}

	@Given("I am on Pay Anyone page")
	public void givenIAmOnPayAnyonePage() throws Throwable {
		sendmoneybf.bf_navigate_PayAnyone();

	}

	@Then("I enter the amount <amount> on Payanyone")
	public void thenIEnterTheamount(@Named("amount") String amount) throws Throwable {
		sendmoney.txt_payAnyone_amount().enterText(amount);
	}

	@Then("I select the payee <mobile>")
	public void thenISelectThecontacts(@Named("mobile") String mobile) throws Throwable {
		sendmoneybf.bf_selectContact(mobile);
	}

	@Then("I type a message <message>")
	public void whenITypeAMessagemessage(@Named("message") String message) throws Throwable {
		sendmoney.txt_payAnyone_typeMessage().enterText(message);
	}

	@Then("I should be able to review transaction")
	public void thenIShouldBeAbleToReviewTransaction() throws Throwable {
		sendmoneybf.bf_navigate_reviewTransaction();
		
	}

	@Then("I should be able to send money")
	public void thenIShouldBeAbleToSendMoney() throws Throwable {
		sendmoneybf.bf_navigate_sendMoneyCompletion();
	}

}
