package com.dbs.in.mb.bizfunctions;

import com.dbs.in.mb.pages.AddPromoPage;
import com.dbs.in.mb.pages.MorePage;

public class AddPromoBF {
	MorePage morepage = new MorePage();
	AddPromoPage addpromocode = new AddPromoPage();

	public void bf_navigateToAddPromoPage() throws Throwable {
		morepage.lbl_addPromo().click();
	}

	public void bf_validateThePromoCode(String promocode) throws Throwable {
		addpromocode.txt_referralCode().enterText(promocode);

	}
}