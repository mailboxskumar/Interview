package com.dbs.in.mb.steps;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.bizfunctions.HomeBF;
import com.dbs.in.mb.bizfunctions.LoginBF;

public class HomePageSteps {

	LoginBF login = new LoginBF();
	HomeBF home = new HomeBF();
	private static final Logger logger = Logger.getLogger(HomePageSteps.class);

	@Then("I verify the homepage navigation")
	public void navigateToHomePage() throws Throwable {
		home.bf_NavigateHomePage();
	}
	
	@Then("I verify homepage 8 buttons are displayed")
	public void thenIVerifyHomepage8ButtonsAreDisplayed() throws Exception, Throwable {
		home.bf_verifyHomepageMainButtons();
	}
	
	@Then("I verify the homepage 7 services with 1 MORE serives")
	public void thenIVerifyTheHomepage7ServicesWith1MORESerives() throws Exception, Throwable {
		home.bf_verifyHomepagePartnersAndServices();
	}

	@Then("I verify the homepage services are sort by alphabetical order")
	public void thenIVerifyTheHomepageServicesAreSortByAlphabeticalOrder() throws Exception, Throwable {
		home.bf_verifyHomepagePartnersAndServicesAreSortByAlphabeticalOrder();
	}
}
