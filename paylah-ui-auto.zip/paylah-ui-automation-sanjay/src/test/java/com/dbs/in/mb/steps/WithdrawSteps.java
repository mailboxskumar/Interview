package com.dbs.in.mb.steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.junit.Assert;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.bizfunctions.HomeBF;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.WithdrawPage;

public class WithdrawSteps {

	HomePage homepage = new HomePage();
	WithdrawPage withdrawpage = new WithdrawPage();
	HomeBF homebf = new HomeBF();

	public static double walletBalance_BeforeWithdraw = 0.00;
	public static double walletBalance_AfterWithdraw = 0.00;

	@Then("I capture the wallet balance before withdraw")
	public void thenICaptureTheWalletBalanceBeforeWithdraw() throws Throwable {
		walletBalance_BeforeWithdraw = homebf.bf_getWalletBalance();
		System.err.println("Wallet Balance before withdraw: " + walletBalance_BeforeWithdraw);
		Reporter.takeScreenshot();
	}

	@Then("I select Send to account option")
	public void thenISelectSendToAccountOption() throws Throwable {
		homepage.lbl_SendToAccount().click();
	}

	@Then("I enter withdraw <amount> to be withdrawn from my wallet balance")
	public void thenIEnterWithdrawamountToBeWithdrawnFromMyWalletBalance(@Named("amount") String amount)
			throws Throwable {
		withdrawpage.txt_WithdrawAmount().enterText(amount);
		Reporter.takeScreenshot();
	}

	@Then("I tap on Next button")
	public void thenITapOnNextButton() throws Throwable {
		withdrawpage.btn_Next().click();
	}

	@Then("I verify the wallet balance after withdraw")
	public void thenIVerifyTheWalletBalanceAfterWithdraw() throws Throwable {
		walletBalance_AfterWithdraw = homebf.bf_getWalletBalance();
		System.err.println("Wallet Balance After withdraw: " + walletBalance_AfterWithdraw);
		Reporter.takeScreenshot();
	}

	@Then("I should see the <amount> debited from my wallet balance")
	public void thenIShouldSeeTheamountDebitedFromMyWalletBalance(@Named("amount") String amount) {

		if (walletBalance_AfterWithdraw == (walletBalance_BeforeWithdraw - Double.parseDouble(amount))) {
			Reporter.getCurrentReporter().childlog.info("Wallet balance debited with amount : S$" + amount);
		} else {
			Reporter.getCurrentReporter().childlog.error("Wallet balance is not debited with amount : S$" + amount);
			Assert.assertTrue(false);
		}

	}

}
