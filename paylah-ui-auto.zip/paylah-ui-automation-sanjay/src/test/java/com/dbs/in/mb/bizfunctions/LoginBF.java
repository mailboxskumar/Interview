package com.dbs.in.mb.bizfunctions;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.dbs.commons.Reporter;
import com.dbs.drivers.DriverManagerFactory;
import com.dbs.in.ib.bizfunctions.MerchantPageLogin;
import com.dbs.in.ib.pages.AdminLoginPage;
import com.dbs.in.mb.pages.AccountDetailsPage;
import com.dbs.in.mb.pages.LoginPage;

import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.AndroidKeyMetastate;

public class LoginBF {

	LoginPage loginPage = new LoginPage();
	MerchantPageLogin weblogin = new MerchantPageLogin();
	AccountDetailsPage accountdetailspage = new AccountDetailsPage();
	CommonActions commonactions = new CommonActions();

	public void bf_launchApp(String env) throws Throwable {
		
		DriverManagerFactory.getMobileManager().getMobileDriver().launchApp();
		loginPage.txt_env_dynamic(env).click();
		loginPage.btn_newInstallation().click();
		loginPage.btn_register().click();
		loginPage.lbl_yesiam().click();
		// login.getMBActions().SwipeTillFound(direction)
	}
	
	public void bf_launchApp() throws Throwable {
		
		DriverManagerFactory.getMobileManager().getMobileDriver().launchApp();
		loginPage.txt_env().click();
		loginPage.btn_newInstallation().click();
		loginPage.btn_register().click();
		loginPage.lbl_yesiam().click();
		// login.getMBActions().SwipeTillFound(direction)
	}

	public void bf_reactivationLaunchApp(String mobilenumber) throws Throwable {
		// System.out.println("Driver is:
		// "+DriverManagerFactory.getMobileManager().getMobileDriver());
		DriverManagerFactory.getMobileManager().getMobileDriver().launchApp();
		loginPage.txt_env().click();
		loginPage.btn_newInstallation().click();
		loginPage.btn_loginReactivation().click();
		loginPage.txt_mobile().enterText(mobilenumber);
		loginPage.btn_nexLogin().click();
		// login.getMBActions().SwipeTillFound(direction)
	}

	public void bf_pllLaunchApp() throws Throwable {
		// System.out.println("Driver is:
		// "+DriverManagerFactory.getMobileManager().getMobileDriver());
		DriverManagerFactory.getMobileManager().getMobileDriver().launchApp();
		loginPage.txt_env().click();
		loginPage.btn_newInstallation().click();
		loginPage.btn_register().click();
		loginPage.lbl_noiamnot().click();
		// login.getMBActions().SwipeTillFound(direction)
	}

	public void bf_NavigateOtpPage(String userName, String password) throws Throwable {
		loginPage.txt_username().enterText(userName);
		loginPage.txt_password().enterText(password);
		loginPage.getMBActions().hideKeyboard();
		Thread.sleep(3000);
		loginPage.btn_nexLogin().click();

	}

	public void bf_enterOTP(String otp) throws Throwable {
		loginPage.txt_otp().enterText(otp);
	}

	public void bf_enterPllOTP(String otp) throws Throwable {
		loginPage.txt_pllOtp().click();
		Thread.sleep(4000);
		for (int i = 0; i < 6; i++) {
			Thread.sleep(500);
			new CommonActions().clickPllSmsCode();
		}
	}

	public void bf_enterPaylahpassword(String paylahpassword) throws Throwable {
		loginPage.txt_paylahPassword().enterText(paylahpassword);
		loginPage.getMBActions().hideKeyboard();
		loginPage.btn_login().click();
		Thread.sleep(7000);
		new CommonActions().skipButtonClick();
	}

	public void bf_createThePaylahPassword(String paylahpassword) throws Throwable {
		loginPage.txt_setUp_password().enterText(paylahpassword);
		loginPage.txt_setUp_confirmPassword().enterText(paylahpassword);
		Reporter.takeScreenshot();
		loginPage.btn_nexLogin().click();
	}

	public void bf_clickedReferalCodeNoOption() throws Throwable {
		loginPage.btn_referalcode_No_popup().click();
		Reporter.takeScreenshot();
		new CommonActions().skipButtonClick();
	}

	public void bf_pllWalletSignUp(String Name, String number, String mail) throws Throwable {
		accountdetailspage.txt_name().enterText(Name);
		accountdetailspage.txt_mobileNumber().enterText(number);
		accountdetailspage.txt_email().enterText(mail);
		Reporter.takeScreenshot();
		loginPage.btn_nexLogin().click();
	}

	public void bf_LoginEnd2End(String userName, String password, String otp, String paylahpassword) throws Throwable {
		bf_NavigateOtpPage(userName, password);
		bf_enterOTP(otp);
		bf_enterPaylahpassword(paylahpassword);

	}

}
