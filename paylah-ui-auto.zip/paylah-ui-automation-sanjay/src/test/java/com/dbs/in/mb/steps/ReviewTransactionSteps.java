package com.dbs.in.mb.steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import com.dbs.in.mb.bizfunctions.QRTransactionReviewBF;

public class ReviewTransactionSteps {

	QRTransactionReviewBF transactionpage = new QRTransactionReviewBF();

	@Then("I verify the review page transaction details <payto> and <amount>")
	public void thenIVerifyTheReviewPageTransactionDetailspaytoAndamount(@Named("payto") String payto,
			@Named("amount") String amount) throws Throwable {
		transactionpage.bf_reviewTheQRTransaction(payto, amount);
	}

}
