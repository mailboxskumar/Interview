package com.dbs.in.mb.bizfunctions;

import java.util.List;
import java.util.Random;

import org.jbehave.core.steps.Steps;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

import com.dbs.drivers.DriverManagerFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class CommonActions extends Steps {
	public static AppiumDriver driver;
	public TouchAction touchAction;

	public void skipButtonClick() throws Throwable {
		driver = DriverManagerFactory.getMobileManager().getMbDriver();
		System.out.println("-----------" + driver);
		Dimension windowSize = driver.manage().window().getSize();
		System.err.println("Window dimensions=" + windowSize);
		int height = (int) ((windowSize.height) * 0.75);
		int width = (int) ((windowSize.width) * 0.52);
		//clickBasedOnCoordinates(width, height);
		clickBasedOnCoordinates(560, 1360);
	}
	
	public void clickPllSmsCode() throws Throwable {
		driver = DriverManagerFactory.getMobileManager().getMbDriver();
		System.out.println("-----------" + driver);
		Dimension windowSize = driver.manage().window().getSize();
		int height = (int) ((windowSize.height) * 0.75);
		int width = (int) ((windowSize.width) * 0.52);
		clickBasedOnCoordinates(width, height);
	}

	public void clickBasedOnCoordinates(int x, int y) throws Throwable {
		try {
			touchAction = new TouchAction(DriverManagerFactory.getMobileManager().getMbDriver());
			touchAction.tap(PointOption.point(x, y)).perform();
			System.out.println("Element is clicked");
		} catch (Throwable t) {
			System.out.println("Exception in clickBasedOnCoordinates " + t.getLocalizedMessage());
		}
	}
    // Click based on the random value
	public void randomClick(String options) throws Throwable {
		List<WebElement> listings = DriverManagerFactory.getMobileManager().getMbDriver()
				.findElements((By.xpath(options)));
		Random r = new Random();
		int randomValue = r.nextInt(listings.size()); // Getting a random value
														// that is between 0 and
														// (list's size)-1
		listings.get(randomValue).click();

	}

}
