package com.dbs.in.ib.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.dbs.actions.IB_Actions;
import com.dbs.commons.ElementFinder;
import com.dbs.commons.Reporter;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

public class AdminLoginPage {
	
	private static final Logger logger=Logger.getLogger(AdminLoginPage.class); 
	WebElement element ;
	String pagename = this.getClass().getSimpleName();
	String text = "";
	List<WebElement> elementsList;
	ElementFinder elementFinder = new ElementFinder();
	Reporter reporter = Reporter.getCurrentReporter();
	public IB_Actions elementBasedOnText(String objectName, String text) throws Throwable {
		try {
			element = elementFinder.verify_IB_Element(DriverManagerFactory.getManager().getWebDriver(),pagename,objectName,"");
			logger.info(pagename+">>"+objectName+">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+">>"+objectName+">>Object not found");
           return new IB_Actions(null, DriverManagerFactory.getManager().getWebDriver());
		}

		return new IB_Actions(element,DriverManagerFactory.getManager().getWebDriver());
	}
	public IB_Actions btn_submit() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_IB_Element(DriverManagerFactory.getManager().getWebDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename + ">>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+ e.getLocalizedMessage();
			IB_Actions.driverForScreenshot = DriverManagerFactory.getManager().getWebDriver();
			Reporter.takeScreenshot();
           return new IB_Actions(null, DriverManagerFactory.getManager().getWebDriver());
		}
		return new IB_Actions(element, DriverManagerFactory.getManager().getWebDriver());
	}

	public IB_Actions txt_password() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_IB_Element(DriverManagerFactory.getManager().getWebDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename + ">>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+ e.getLocalizedMessage();
			IB_Actions.driverForScreenshot = DriverManagerFactory.getManager().getWebDriver();
			Reporter.takeScreenshot();
           return new IB_Actions(null, DriverManagerFactory.getManager().getWebDriver());
		}
		return new IB_Actions(element, DriverManagerFactory.getManager().getWebDriver());
	}

	public IB_Actions txt_username() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_IB_Element(DriverManagerFactory.getManager().getWebDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename + ">>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+ e.getLocalizedMessage();
			IB_Actions.driverForScreenshot = DriverManagerFactory.getManager().getWebDriver();
			Reporter.takeScreenshot();
           return new IB_Actions(null, DriverManagerFactory.getManager().getWebDriver());
		}
		return new IB_Actions(element, DriverManagerFactory.getManager().getWebDriver());
	}

}
