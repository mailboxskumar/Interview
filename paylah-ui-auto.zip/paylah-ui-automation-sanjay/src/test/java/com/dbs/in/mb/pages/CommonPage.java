package com.dbs.in.mb.pages;

import org.apache.log4j.Logger;

import java.util.List;

import com.dbs.actions.MB_Actions;
import com.dbs.commons.ElementFinder;
import com.dbs.commons.Reporter;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

import io.appium.java_client.MobileElement;


public class  CommonPage {

	private static final Logger logger=Logger.getLogger( CommonPage.class); 
	String pagename = this.getClass().getSimpleName();
	MobileElement element;
    List<MobileElement> elementsList;
	ElementFinder elementFinder = new ElementFinder();
	Reporter reporter = Reporter.getCurrentReporter();
	
	
	public MB_Actions getMBActions() throws Throwable{
        return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

	public MB_Actions btn_Ok() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+ " >>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+e.getLocalizedMessage();
			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();
			Reporter.takeScreenshot();
           return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
		}
		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

	public MB_Actions btn_backToHome() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+ " >>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+e.getLocalizedMessage();
			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();
			Reporter.takeScreenshot();
           return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
		}
		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

	public MB_Actions lbl_sna() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+ " >>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+e.getLocalizedMessage();
			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();
			Reporter.takeScreenshot();
           return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
		}
		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

	public MB_Actions btn_tryIt() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+ " >>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+e.getLocalizedMessage();
			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();
			Reporter.takeScreenshot();
           return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
		}
		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

	public MB_Actions btn_Submit() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+ " >>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+e.getLocalizedMessage();
			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();
			Reporter.takeScreenshot();
           return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
		}
		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

	public MB_Actions btn_completion_addToFavourites() throws Throwable{
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();
		try {
			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),
					pagename, objectName,"");
			logger.info(pagename + ">>" + objectName + ">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+ " >>" + objectName + ">>Object not found"
					+ e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+e.getLocalizedMessage();
			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();
			Reporter.takeScreenshot();
           return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
		}
		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

}
