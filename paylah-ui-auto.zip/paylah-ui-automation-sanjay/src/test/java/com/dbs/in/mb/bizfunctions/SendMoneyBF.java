package com.dbs.in.mb.bizfunctions;

import org.apache.log4j.Logger;
import org.jbehave.core.steps.Steps;
import com.dbs.commons.Reporter;
import com.dbs.in.mb.pages.CommonPageObjects;
import com.dbs.in.mb.pages.LoginPage;
import com.dbs.in.mb.pages.SendMoneyPage;
import com.dbs.in.mb.steps.SendMoneySteps;

import junit.framework.Assert;

public class SendMoneyBF extends Steps {

	private static final Logger logger = Logger.getLogger(SendMoneyBF.class);
	SendMoneyPage sendmoney = new SendMoneyPage();
	LoginPage login = new LoginPage();
	CommonPageObjects commonobjects = new CommonPageObjects();
	Reporter reporter = Reporter.getCurrentReporter();

	public void bf_navigate_PayAnyone() throws Throwable {
		login.btn_pay().click();
		sendmoney.btn_TryIt().click();
		if (sendmoney.lbl_payAnyone_Title().exists()) {

			logger.info("Able to Navigate to PayAnyone Page");
			Reporter.takeScreenshot();
		}
	}

	public void bf_selectContact(String MobileNum) throws Throwable {
		sendmoney.lbl_payAnyone_payTo().click();
		sendmoney.txt_addPayee_enterNum().click();
		sendmoney.txt_addPayee_enterNum().enterText(MobileNum);
		sendmoney.btn_addPayee_selectContact().click();
		sendmoney.btn_addPayee_done().click();
	}

	public void bf_navigate_reviewTransaction() throws Throwable {

		sendmoney.btn_payAnyone_next().click();
		if (sendmoney.lbl_reviewTransaction_Title().exists()) {
			reporter.childlog.info("Able to Navigate to PayAnyone Review Page");

			Reporter.takeScreenshot();
		}

	}

	@SuppressWarnings("deprecation")
	public void bf_navigate_sendMoneyCompletion() throws Throwable {
		try {
			sendmoney.btn_reviewTransaction_LetsGo().click();

			if (commonobjects.btn_Ok().exists()) {
				do {
					commonobjects.btn_Ok().click();
				} while (commonobjects.btn_Ok().exists());

				if (sendmoney.lbl_completion_Message().exists()) {
					reporter.childlog.info("Able to Navigate to PayAnyone Completion Page");
					Assert.assertTrue("Able to Complete Send Money", true);
					Reporter.takeScreenshot();
				}
			}
		} catch (Exception e) {
			Assert.assertTrue("Unable to Complete Send Money", false);
		}

		/*
		 * if (!sendmoney.lbl_completion_Message().exists()) {
		 * Reporter.takeScreenshot();
		 * reporter.childlog.error("Unable to complete Send Money"); if
		 * (commonobjects.lbl_sna().exists()){
		 * Assert.assertTrue("SNA error is displayed", false);
		 * reporter.childlog.error("SNA error is displayed");
		 * commonobjects.btn_Ok().click(); } } else
		 * if(commonobjects.btn_Ok().exists()){
		 * 
		 * do { commonobjects.btn_Ok().click(); } while
		 * (commonobjects.btn_Ok().notExists());
		 * 
		 * if(sendmoney.lbl_completion_Message().exists()){ reporter.childlog.
		 * info("Able to Navigate to PayAnyone Completion Page");
		 * Assert.assertTrue("Able to Complete Send Money", true);
		 * Reporter.takeScreenshot(); }
		 * 
		 * }
		 */
	}

}
