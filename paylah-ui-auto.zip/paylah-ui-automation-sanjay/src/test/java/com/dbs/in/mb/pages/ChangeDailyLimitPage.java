package com.dbs.in.mb.pages;

import org.apache.log4j.Logger;

import java.util.List;

import com.dbs.actions.MB_Actions;
import com.dbs.commons.ElementFinder;
import com.dbs.commons.Reporter;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

import io.appium.java_client.MobileElement;


public class  ChangeDailyLimitPage {

	private static final Logger logger=Logger.getLogger( ChangeDailyLimitPage.class); 
	String pagename = this.getClass().getSimpleName();
	MobileElement element;
    List<MobileElement> elementsList;
	ElementFinder elementFinder = new ElementFinder();
	Reporter reporter = Reporter.getCurrentReporter();
	
	
	public MB_Actions getMBActions() throws Throwable{
        return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());
	}

	public List<MobileElement> wbLst_dailytLimits() throws Throwable {
		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName();
		try {
			elementsList = elementFinder.verify_MB_Elements(DriverManagerFactory.getMobileManager().getMobileDriver(), pagename, objectName,"");
			logger.info(pagename+">>"+objectName+">>Object found and returned");
		} catch (Throwable e) {
			logger.error("Exception in returning the element of page : "+pagename+">>"+objectName+">>Object not found");
			reporter.currentStep = "Action can not be performed at the page : "+pagename+ ">> on element :" + objectName + " due to Object is "+ e.getLocalizedMessage();
			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();
			Reporter.takeScreenshot();
			return null;
		}
			return this.elementsList;

	}

}
