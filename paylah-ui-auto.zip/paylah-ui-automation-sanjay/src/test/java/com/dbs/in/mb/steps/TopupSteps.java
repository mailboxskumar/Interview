package com.dbs.in.mb.steps;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.dbs.commons.Reporter;
import com.dbs.in.mb.bizfunctions.CommonActions;
import com.dbs.in.mb.bizfunctions.HomeBF;
import com.dbs.in.mb.bizfunctions.LoginBF;
import com.dbs.in.mb.pages.HomePage;
import com.dbs.in.mb.pages.TopupPage;

public class TopupSteps {
	
	LoginBF loginbf = new LoginBF();
	HomePage homepage = new HomePage();
	TopupPage topuppage = new TopupPage();
	HomeBF homebf = new HomeBF();

	public static double walletBalance_BeforeTopup = 0.00;
	public static double walletBalance_AfterTopup = 0.00;

	private static final Logger logger = Logger.getLogger(TopupSteps.class);

	@Then("I enter the paylah password <paylahpassword>")
	public void thenIEnterThePaylahPasswordpaylahpassword(@Named("paylahpassword") String paylahpassword)
			throws Throwable {
		loginbf.bf_enterPaylahpassword(paylahpassword);
		new CommonActions().skipButtonClick();
		Reporter.takeScreenshot();
	}

	@Then("I capture the top up balance before top up")
	public void thenICaptureTheTopUpBalanceBeforeTopUp() throws Throwable {
		walletBalance_BeforeTopup = homebf.bf_getWalletBalance();
		System.err.println("Before top up " + walletBalance_BeforeTopup);
		Reporter.takeScreenshot();
		logger.info("Current wallet Balance is:" + walletBalance_BeforeTopup);
	}

	@When("I tap on Manage button in home page")
	public void whenITapOnManageButtonInHomePage() throws Throwable {
		homepage.btn_Manage().click();
	}

	@Then("I select Top Up option")
	public void thenISelectTopUpOption() throws Throwable {
		homepage.lbl_TopUp().click();
	}

	@Then("I enter top up <amount> from my linked account")
	public void thenIEnterTopUpamountFromMyLinkedAccount(@Named("amount") String amount) throws Throwable {
		topuppage.txt_TopupAmount().enterText(amount);
		Reporter.takeScreenshot();
	}

	@Then("I tap on Submit button")
	public void thenITapOnSubmitButton() throws Throwable {
		topuppage.btn_Submit().click();
	}

	@Then("I verify the top up balance after top up")
	public void thenIVerifyTheTopUpBalanceAfterTopUp() throws Throwable {
		walletBalance_AfterTopup = homebf.bf_getWalletBalance();
		System.err.println("After top up: " + walletBalance_AfterTopup);
		Reporter.takeScreenshot();
		logger.info("Current wallet Balance Aftertop:" + walletBalance_AfterTopup);
	}

	@Then("I should see the <amount> credited to my wallet balance")
	public void thenIShouldSeeTheamountCreditedToMyWalletBalance(@Named("amount") String amount) {

		if (walletBalance_AfterTopup == (walletBalance_BeforeTopup + Double.parseDouble(amount))) {
			Reporter.getCurrentReporter().childlog.info("Wallet balance credited with amount : S$" + amount);
		} else {
			Reporter.getCurrentReporter().childlog.error("Wallet balance is not credited with amount : S$" + amount);
			Assert.assertTrue(false);
		}

	}

}
