package com.dbs.config;

public class AppConstants {

	public static final String IB_URL="https://uat-internet-banking.dbsbank.in/";
	public static final String IB_HomePage_Element="//input[@name='username']";
}
