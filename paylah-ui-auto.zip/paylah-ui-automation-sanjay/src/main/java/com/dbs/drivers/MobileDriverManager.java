package com.dbs.drivers;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.dbs.config.Config;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class MobileDriverManager extends DriverManager {

	DesiredCapabilities dCapbls;
	HashMap<String, String> driverData;
	private static final Logger logger = Logger.getLogger(MobileDriverManager.class);

	public MobileDriverManager(HashMap<String, String> driverData) {
		this.driverData = driverData;
	}

	@Override
	protected void startService() {
		logger.info("starting mobile driver service");
	}

	@Override
	protected void stopService() {

	}

	@Override
	protected void createDriver() {
		try {
			
			String serverUrl = null;
			
			//Parsing the URL to check the http/https
			if(driverData.get("ServerURL").trim().toLowerCase().startsWith("https://")) {
				serverUrl = driverData.get("ServerURL").trim();
				System.out.println("Start SetUP");
				System.setProperty("proxy.authentication.mode","NTLM");
				System.setProperty("http.auth.ntlm.domain","REG1");
				System.setProperty("https.proxyHost","bcproxy.sgp.dbs.com"); 
				System.setProperty("https.proxyPort","8080");
				System.setProperty("https.proxyUser",System.getProperty("user.name"));
				System.setProperty("http.proxyHost","bcproxy.sgp.dbs.com");
				System.setProperty("http.proxyPort","8080");
				System.setProperty("http.proxyUser",System.getProperty("user.name"));
				// System.setProperty("javax.net.ssl.trustStrore", "resources\\jssecacerts");
				// System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
				System.out.println("\nProvided Proxy Details:\n"
						+ "https.proxyHost: " + System.getProperty("https.proxyHost") +"\n"
						+ "https.proxyPort: " + System.getProperty("https.proxyPort") +"\n"
						+ "https.proxyUser: " + System.getProperty("https.proxyUser") +"\n"
						+ "http.proxyHost: " + System.getProperty("http.proxyHost") +"\n"
						+ "http.proxyPort: " + System.getProperty("http.proxyPort") +"\n"
						+ "http.proxyUser: " + System.getProperty("http.proxyUser") +"\n"
						+ "javax.net.ssl.trustStrore: " + System.getProperty("javax.net.ssl.trustStrore") +"\n");
			}
			else if(driverData.get("ServerURL").trim().toLowerCase().startsWith("http://"))
				serverUrl = driverData.get("ServerURL").trim();
			else
				serverUrl = "http://" + driverData.get("ServerURL").trim();

			logger.info("Creating mobile driver (ANDROID/IOS): " + driverData.get("Platform Name") +" <--");
			logger.info("Driver WILL BE STARTED on :: " + serverUrl + ":"
					+ driverData.get("Port").trim() + " mobile driver service with Device: "+ driverData.get("Device Name"));
			if (driverData.get("Platform Name").trim().equalsIgnoreCase("ANDROID")) {
				// System.out.println("http://"+driverData.get("ServerURL").trim()+":"+driverData.get("Port").trim()+"/wd/hub");
				logger.info(serverUrl + ":" + driverData.get("Port").trim()
						+ "/wd/hub");
				setMbDriver(new AndroidDriver(new URL(serverUrl + ":"
						+ driverData.get("Port").trim() + "/wd/hub"), getAndroidDesiredCapabilities()));
				logger.info("Android driver started on :: " + serverUrl + ":"
						+ driverData.get("Port").trim() + " mobile driver service with Device: "+ driverData.get("Device Name"));
			} else if (driverData.get("Platform Name").trim().equalsIgnoreCase("IOS")) {
				setMbDriver(new IOSDriver(new URL(serverUrl + ":"
						+ driverData.get("Port").trim() + "/wd/hub"), getIOSDesiredCapabilities()));
				logger.info("IOS driver started on :: " +serverUrl + ":"
						+ driverData.get("Port").trim() + "mobile driver service with Device: "+ driverData.get("Device Name"));
			}
		} catch (Throwable t) {
			Config.gracefulEnd(t, logger);
		}
	}

	private DesiredCapabilities getIOSDesiredCapabilities() {

		dCapbls = new DesiredCapabilities();

		try {
			if (driverData.get("Run On Cloud").equalsIgnoreCase("true")) {
				dCapbls.setCapability("deviceQuery", "@os='ios' and @serialnumber='" + driverData.get("Udid") + "'");
				dCapbls.setCapability("accessKey", driverData.get("AccessKey").trim());
				logger.info("Running the tests on SeeTest cloud setting IOS capabilities");
			}

			logger.info("Platform is " + driverData.get("Platform Name").trim());
			logger.info("Devicename " + driverData.get("Device Name").trim());

			dCapbls.setCapability("udid", driverData.get("Udid").trim());
			dCapbls.setCapability("platformName", driverData.get("Platform Name").trim());
			// dCapbls.setCapability("appPackage", driverData.get("BundleID").trim());
			dCapbls.setCapability("platformVersion", driverData.get("Platform Version").trim());
			dCapbls.setCapability("bundleId", driverData.get("BundleID").trim());
			dCapbls.setCapability(CapabilityType.BROWSER_NAME, "");
			dCapbls.setCapability("showXcodeLog", "true");
			dCapbls.setCapability("clearSystemFiles", "true");
			dCapbls.setCapability("usePrebuiltWDA", true);
			dCapbls.setCapability("automationName", "XCUITest");
			dCapbls.setCapability("app", "");
			dCapbls.setCapability("interKeyDelay", "500");
			dCapbls.setCapability("newCommandTimeout", "180");
			dCapbls.setCapability("sendKeyStrategy", "setValue");
			dCapbls.setCapability("maxTypingFrequency", "30");
			dCapbls.setCapability("realDeviceLogger", "/usr/local/lib/node_modules/deviceconsole/deviceconsole");
			dCapbls.setCapability("deviceName", driverData.get("Device Name").trim());
			dCapbls.setCapability("agentPath",
					"/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent/WebDriverAgent.xcodeproj");
			dCapbls.setCapability("bootstrapPath",
					"/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent");
			dCapbls.setCapability("noReset", false);

		} catch (Exception e) {
			logger.error("Exception while setting IOS capabilities :: " + e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			return null;
		}
		return dCapbls;
	}

	private DesiredCapabilities getAndroidDesiredCapabilities() {

		dCapbls = new DesiredCapabilities();
		try {
			if (driverData.get("Run On Cloud").equalsIgnoreCase("true")) {
				dCapbls.setCapability("deviceQuery",
						"@os='android' and @serialnumber='" + driverData.get("Udid") + "'");
				dCapbls.setCapability("accessKey", driverData.get("AccessKey").trim());
				logger.info("Running the tests on SeeTest cloud setting Android capabilities");
			}

			logger.info("Platform is " + driverData.get("Platform Name").trim());
			logger.info("Devicename " + driverData.get("Device Name").trim());

			dCapbls.setCapability("deviceName", driverData.get("Udid").trim());
			dCapbls.setCapability("udid", driverData.get("Udid").trim());
			dCapbls.setCapability("platformName", "Android");
			// dCapbls.setCapability("app",
			// "C:\\IBID\\digibdd\\digi-nextgen\\resources\\DBIN_SIT_350115_2018-06-20_20-55.apk");
			dCapbls.setCapability("appPackage", driverData.get("App Package").trim()); // Test env package name
			dCapbls.setCapability("platformVersion", driverData.get("Platform Version").trim());
			// dCapbls.setCapability("bundleId", "com.dbs.in.digibank");
			dCapbls.setCapability("appActivity", driverData.get("App Activity").trim());
			dCapbls.setCapability("clearSystemFiles", true);
			// dCapbls.setCapability("automationName", "uiautomator2");
			dCapbls.setCapability("automationName", "UiAutomator2");
			dCapbls.setCapability("commandTimeouts", 5000);
			dCapbls.setCapability("newCommandTimeout", 240);
			dCapbls.setCapability("noReset", true);
			dCapbls.setCapability("fullReset", false);

		} catch (Exception e) {
			logger.error("Exception while setting Android capabilities :: " + e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
			return null;
		}
		return dCapbls;
	}

}
