import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

/*Add below 2 jars files to project for XML file Reading
 * jaxen.jar
 * dom4j-1.6.jar
 * */

public class ReadingTestDataFromExternalSource {

	static String xmlFile = "C:\\paylahworkspace\\CopyFile\\src\\files\\repo.xml";
	static String excelFile = "C:\\paylahworkspace\\CopyFile\\src\\files\\testData.xlsx";
	static String propertiesFile = "C:\\paylahworkspace\\CopyFile\\src\\files\\config.properties";

	public static void main(String[] args) throws DocumentException, IOException, ClassNotFoundException, SQLException {
		readXMLFile();
		readExcelFile();
		readPropertiesFile();
		// readDataFromDataBase();

	}

	/*
	 * Add below 2 jars files to project build path for XML file Reading jaxen.jar
	 * dom4j-1.6.jar
	 */

	public static void readXMLFile() throws DocumentException {
		File inputFile = new File(xmlFile); // To Open xml file
		SAXReader saxReader = new SAXReader();
		Document document = saxReader.read(inputFile); // To read the xml file
		String userNameLoc = document.selectSingleNode("//username/locatorType").getText();
		String userNameVal = document.selectSingleNode("//username/locatorValue").getText();
		System.out.println(userNameLoc);
		System.out.println(userNameVal);
		System.out.println("XML:=============================");
	}

	/*
	 * Add below jar file to project build path for excel file Reading/Writing
	 * Download the jar file from apache website apache poi jar [poi-3.9.jar]
	 */

	public static void readExcelFile() throws IOException {
		File file = new File(excelFile); // To open xl file
		FileInputStream fileInputStream = new FileInputStream(file); // To Read the xl file

		Workbook workBook = null;
		String fileExt = excelFile.substring(excelFile.indexOf("."));

		if (fileExt.equals(".xlsx")) {
			workBook = new XSSFWorkbook(fileInputStream); // Code for .xlsx file extension
		} else if (fileExt.equals(".xls")) {
			workBook = new HSSFWorkbook(fileInputStream); //// Code for .xls file extension
		}

		Sheet sheet = workBook.getSheet("Sheet1"); // Provide the sheet name find data from

		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		System.out.println("No of Rows :: " + rowCount);

		int colCount = sheet.getRow(0).getLastCellNum();
		System.out.println("No of Columns :: " + colCount);

		// Read Data from Excel File
		for (int i = 0; i < rowCount + 1; i++) {
			Row row = sheet.getRow(i);

			for (int j = 0; j < colCount; j++) {
				String cellValue = row.getCell(j).getStringCellValue();
				System.out.println(cellValue);
			}
		}

		System.out.println("Excel:=============================");
	}

	public void writeDataToExcelFile() throws IOException {

		// Write Data into excel file
		XSSFWorkbook workbook1 = new XSSFWorkbook();
		XSSFSheet sheet1 = workbook1.createSheet("TestData");
		Row row = sheet1.createRow(0);
		Cell cell = row.createCell(0);
		cell.setCellValue("Test");

		try {
			FileOutputStream outputStream = new FileOutputStream(excelFile);
			workbook1.write(outputStream);
			workbook1.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

	public static void readPropertiesFile() throws IOException {
		File file = new File(propertiesFile); // To open properties file
		FileInputStream fileInputStream = new FileInputStream(file); // To Read the properties File

		Properties properties = new Properties();
		properties.load(fileInputStream); // Load the properties file

		String user = properties.getProperty("username");
		System.out.println(user);

		String password = properties.getProperty("password");
		System.out.println(password);

		String loginButton = properties.getProperty("loginButton");
		System.out.println(loginButton);

		System.out.println("PROPERTIES:=============================");
	}

	public static void readDataFromDataBase() throws SQLException, ClassNotFoundException {

		String query = "select * from employee";
		String dbSchema = "";
		String dbUser = "testDB";
		String dbPassword = "password";
		String dbType = "mysql";

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;

		if (dbType.equalsIgnoreCase("mysql")) {
			Class.forName("com.mysql.jdbc.Driver");
			dbSchema = "jdbc:mysql://10.91.134.133:6603/dbname";
		} else if (dbType.equalsIgnoreCase("mariadb")) {
			Class.forName("org.mariadb.jdbc.Driver");
			dbSchema = "jdbc:mariadb://10.91.134.133:6603/dbname";
		}

		connection = DriverManager.getConnection(dbSchema, dbUser, dbPassword);

		statement = connection.createStatement();
		resultSet = statement.executeQuery(query);

		int colCnt = resultSet.getMetaData().getColumnCount();
		resultSet.getFetchSize();
		System.out.println(colCnt);

		int rowCnt = resultSet.getInt(1);
		System.out.println(rowCnt);

		int rouCounter = 0;

		while (resultSet.next()) {
			rouCounter++;
			System.out.println(resultSet.getString(1) + "� " + resultSet.getString(2)); // Get Value By ColumnIndex
			System.out.println(resultSet.getString("ALERT_ID")); // Get Value By Column Name
		}

		System.out.println("Total No of Records : " + rouCounter);

		resultSet.close();
		statement.close();
		connection.close();

	}

}
