// REST : Representation State Transfer
//JSON : JavaScript Object Notation

// REST constraints
	//1 : Client - Server Architecture Style
	//2 : Stateless
	//3 : Cache
	//4 : Uniform Interface
	//5 : Layered System
	//6 : Code on demand

public class RestAssured {

	public static void main(String[] args) {
		

	}

}
