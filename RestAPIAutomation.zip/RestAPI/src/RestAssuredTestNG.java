import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAssuredTestNG {

	String baseURI = "http://restapi.demoqa.com/utilities/weather/city";
	String cityWeather = "/Hyderabad";

	int iStatusCode = 200;
	String statusLine = "HTTP/1.1 200 OK";
	String contentType = "application/json";
	String serverType = "nginx/1.12.1";
	String contentEncoding = "gzip";

	ArrayList<String> al = new ArrayList<String>();

	Response response;
	Response response1;

	@Test
	public void executeAPITest() {
		postRequest();
		/*ArrayList<String> al = new ArrayList<String>();
		getResponse(cityWeather);
		validateResponseStatusCode(iStatusCode);
		validateResponseStatusLine(statusLine);
		validateHeaderContentType(contentType);
		validateHeaderServer(serverType);
		validateHeaderContentEncoding(contentEncoding);*/
	}

	public void getResponse(String sCityName) {
		// Specify the base URI for REST full service

		// Get the RequestSpecification of the request that you want to sent
		RequestSpecification httpRequest = RestAssured.given();

		// Make a Request to server and capture Response
		response = httpRequest.request(Method.GET, sCityName); // Trick 1
		response1 = httpRequest.get(sCityName); // Trick 2

	}

	public void validateResponseStatusCode(int stsCode) {
		int statusCode = response.getStatusCode();
		System.out.println("Status Code" + statusCode);
		Assert.assertEquals(statusCode, stsCode, "Correct Status code returned");
	}

	public void validateResponseStatusLine(String stsLine) {
		String statusline = response.getStatusLine();
		System.out.println("Status Line" + statusline);
		Assert.assertEquals(statusline, stsLine, "Correct Status line returned");
	}

	public void validateHeaderContentType(String exptdContentType) {
		String actlContentType = response.header("Content-Type");
		Assert.assertEquals(actlContentType, exptdContentType, "Correct Content Type returned");
	}

	public void validateHeaderServer(String exptdServerType) {
		String serverType = response.header("Server");
		Assert.assertEquals(serverType, exptdServerType, "Correct Server Type returned");
	}

	public void validateHeaderContentEncoding(String exptdContentEncoding) {
		String contentEncoding = response.header("Content-Encoding");
		Assert.assertEquals(contentEncoding, exptdContentEncoding, "Correct Content Encoding returned");
	}

	public void validateResponseHeaders(ArrayList<String> headerValues) {
		Headers allHeaders = response.headers();
		for (Header header : allHeaders) {
			System.out.println("Key Name:=" + header.getName());
			System.out.println("Key Value:=" + header.getValue());
		}
	}

	public void validateResponseBody() {

	}
	
	/*POST Request :
	Step 1 : Create a Request pointing to the Service Endpoint
	Step 2 : Create Json Request which contains all the fields
	Step 3 : Add JSON body in the request and send the Request
	Step 4 : Post the request and verify the response
	*
	*/

	public void postRequest() {
		String baseURI = "http://restapi.demoqa.com/customer";

		// Create a Request pointing to the Service Endpoint
		RestAssured.baseURI = baseURI;
		RequestSpecification request = RestAssured.given();
		// add a header stating the request body is json
		request.header("content-type", "application/json");


		// Create Json Request which contains all the fields
		JSONObject requestParams = new JSONObject();
		requestParams.put("FirstName", "Sanjay");
		requestParams.put("LastName", "Singh");
		requestParams.put("email", "sanjay@gmya.com");

		
		// add the json to the body of the request
		request.body(requestParams.toJSONString());

		// Post the request and verify the response;

		Response res = request.post("/register");

		// Get and validate status code
		int stsCode = res.getStatusCode();
		Assert.assertEquals(stsCode, "201");
		System.out.println(stsCode);

		// get and validate Success code
		String susCode = res.jsonPath().get("SuccssCode");
		System.out.println(susCode);
		Assert.assertEquals("Correct Status code returned",susCode, "OPERATION_SUCCESS");

	}
}
