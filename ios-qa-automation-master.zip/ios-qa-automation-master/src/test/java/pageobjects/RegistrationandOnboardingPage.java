/**
 * 
 */
package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author ravibadugu
 *
 */
public class RegistrationandOnboardingPage {
	
	public  RegistrationandOnboardingPage(IOSDriver<WebElement> driver) 
	{
		
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	// Registration screen
	@iOSFindBy(id="Create an account")
	public WebElement CreateAnAccountButton;
	
	@iOSFindBy(id="Sign up")
	public WebElement SignupButton;
	
	// Terms and conditions
	@iOSFindBy(xpath="//XCUIElementTypeLink[@name=\"Terms and Conditions\"]")
	public WebElement TandCLink;
	
	@iOSFindBy(id="Accept and continue")
	public WebElement AcceptAndContinueButton;
	
	// Data Policy
	@iOSFindBy(id="I consent")
	public WebElement IConsentButton;
	
	@iOSFindBy(xpath="//XCUIElementTypeLink[@name=\"Privacy Policy\"]")
	public WebElement PrivacyPolicyLink;
	
	//Your Location Page
	
	@iOSFindBy(id="Find location")
	public WebElement FindLocationButton;
	
	//Your name locators
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"First name\"]/following-sibling::XCUIElementTypeTextField")
	public WebElement firstNameInput;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Last name\"]/following-sibling::XCUIElementTypeTextField")
	public WebElement lastNameInput;
	
	//Get Notified locators
	@iOSFindBy(id="Get notified!")
	public WebElement GetNotifiedTitle;
	
	@iOSFindBy(id="Get personalized updates of your progress and achievements.")
	public WebElement GetNotifiedPText;
	
	@iOSFindBy(id="Not right now")
	public WebElement NotRightNowButton;
	
	@iOSFindBy(id="Discover more")
	public WebElement DiscoverMoreButtonInGtngStrdBanner;

	
	

}
