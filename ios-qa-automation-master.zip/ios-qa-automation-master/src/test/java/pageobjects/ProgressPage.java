package pageobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.SwipeElementDirection;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class ProgressPage {

//	private static final SwipeElementDirection Right = null;
//	private static final SwipeElementDirection left = null;
	IOSDriver driver;

	public ProgressPage(IOSDriver<WebElement> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver, 25, TimeUnit.SECONDS), this);
	}
	
	// Navigation

	@iOSFindBy(id = "Progress")
	public WebElement NavProgressButton;
	
	// Major buttons

	@iOSFindBy(id = "Add goal")
	public WebElement AddGoalButton;

	@iOSFindBy(id = "Set goal")
	public WebElement SetGoalButton;

	@iOSFindBy(id = "Back")
	public WebElement BackButton;

	@iOSFindBy(id = "Close")
	public WebElement CloseButton;
	
	@iOSFindBy(id = "Done")
	public WebElement DoneButton;
	
	@iOSFindBy(id = "Edit")
	public WebElement EditButton;
	
	// Progress page

	@iOSFindBy(xpath = "//XCUIElementTypeNavigationBar/XCUIElementTypeOther[@name='Progress']")
	public WebElement ProgressPageHeaderTitle;

	@iOSFindBy(xpath = "//XCUIElementTypeCell[@visible='true']")
	public WebElement ProgressWidget;

	// Selecting widgets 
	
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Weight']/preceding-sibling::XCUIElementTypeImage")
	public WebElement WeightInSelectingWidgetScreen;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapSleepInSelectingWidgetScreen;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Calories Intake']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapCaloriesIntakeInSelectingWidgetScreen;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Activity']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapActivityInSelectingWidgetScreen;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Steps']/preceding-sibling::XCUIElementTypeImage")
	public IOSElement TapStepsInSelectAnActivityScreen;
	
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Swimming']/preceding-sibling::XCUIElementTypeImage")
	public WebElement SwimmingInSelectAnActivityScreen;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Duration']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapDurationToTrackYourProgress;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Distance']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapDistanceToTrackYourProgress;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Workout']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapWorkoutInSelectAnActivityScreen;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Cycling']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapCyclingInSelectAnActivityScreen;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Running']/preceding-sibling::XCUIElementTypeImage")
	public WebElement TapRunningInSelectAnActivityScreen;
	
	// Widgets on Progress page
	
	@iOSFindBy(id = "Weight")
	public WebElement WeightInSelectWidgetScreenOption;
	
	@iOSFindBy(id = "Sleep")
	public WebElement SleepInSelectWidgetScreenOption;
	
	@iOSFindBy(id = "Calories Intake")
	public WebElement CaloriesIntakeInSelectWidgetScreenOption;
	
	@iOSFindBy(id = "Activity")
	public WebElement ActivityInSelectWidgetScreenOption;
	
	@iOSFindBy(id = "Steps")
	public WebElement StepsInSelectWidgetScreenOption;

	public ProgressPage VerifyingTargetOnWidget(String txt) {
		switch (txt) {
		case "Weight":
			TargetOnWeightWidget.isDisplayed();
			break;
		case "Sleep":
			TargetOnSleepWidget.isDisplayed();
			break;
		case "Calories Intake":
			TargetOnCaloriesWidget.isDisplayed();
			break;
		}
		return this;
	}

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Weight']/following-sibling::XCUIElementTypeStaticText[@name='Target']")
	public WebElement TargetOnWeightWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep']/following-sibling::XCUIElementTypeStaticText[@name='Target']")
	public WebElement TargetOnSleepWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Calories Intake']/following-sibling::XCUIElementTypeStaticText[@name='Target']")
	public WebElement TargetOnCaloriesWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Weight']/following-sibling::XCUIElementTypeStaticText[@name='Latest']")
	public WebElement LastPeriodTextWeightWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep']/following-sibling::XCUIElementTypeStaticText[@name='Last night']")
	public WebElement LastPeriodTextSleepWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Calories Intake']/following-sibling::XCUIElementTypeStaticText[@name='Latest']")
	public WebElement LastPeriodTextCaloriesWidget;
	
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Steps']/following-sibling::XCUIElementTypeStaticText[@name='Today']")
	public WebElement LastPeriodTextStepsWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Weight']/following-sibling::XCUIElementTypeStaticText[1]")
	public WebElement LastPeriodWeightValue;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep']/following-sibling::XCUIElementTypeStaticText[1]")
	public WebElement LastPeriodSleepValue;

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Calories Intake']/following-sibling::XCUIElementTypeStaticText[1]")
	public WebElement LastPeriodCaloriesValue;
	
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Steps']/following-sibling::XCUIElementTypeStaticText[1]")
	public WebElement LastPeriodStepsValue;
	
	// Context menu Progress page

	@iOSFindBy(xpath = "//XCUIElementTypeOther[.//XCUIElementTypeStaticText[@name='Sleep']]/following-sibling::XCUIElementTypeButton[@name='icon more']")
	public WebElement ContextMenuSleepWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeOther[.//XCUIElementTypeStaticText[@name='Weight']]/following-sibling::XCUIElementTypeButton[@name='icon more']")
	public WebElement ContextMenuWeightWidget;

	@iOSFindBy(xpath = "//XCUIElementTypeOther[.//XCUIElementTypeStaticText[@name='Calories Intake']]/following-sibling::XCUIElementTypeButton[@name='icon more']")
	public WebElement ContextMenuCaloriesWidget;
	
	@iOSFindBy(xpath = "//XCUIElementTypeOther[.//XCUIElementTypeStaticText[@name='Steps']]/following-sibling::XCUIElementTypeButton[@name='icon more']")
	public WebElement ContextMenuStepsWidget;

	@iOSFindBy(id = "icon more")
	public WebElement IconMoreOnWidget;
	
	@iOSFindBy(id = "Log Data")
	public WebElement TapLogDataOptionInConMenuOnWidget;
	
	@iOSFindBy(id = "Connect Tracker")
	public WebElement TapConnectTrackerOptionInConMenuOnWidget;

	@iOSFindBy(id = "Edit goal")
	public WebElement TapEditgoalOptionInConMenuOnWidget;

	@iOSFindBy(id = "Remove")
	public WebElement TapRemoveOptionInConMenuOnWidget;

	@iOSFindBy(id = "Cancel")
	public WebElement TapCancelOptionInConMenuOnWidget;
	
	// Weight widget

	@iOSFindBy(id = "ruler-segment")
	public IOSElement GoalSlider;

	public ProgressPage SlidingGoal() {
		TouchAction myAction = new TouchAction(driver);
		// mention the X,Y offset and start and end points
		myAction.press(0, 225).moveTo(-20, 225).release().perform();
		System.out.println(GoalSlider.getAttribute("value"));
		// GoalSlider.swipe(Right, 6000);
		System.out.println(GoalSlider.getCenter());
		return this;
	}

	// public void currentSlider() throws InterruptedException {
	// Thread.sleep(2000);
	// IOSElement currentGoalSlider = (IOSElement)
	// driver.findElement(By.id("ruler-segment"));
	// IOSElement currentValue = (IOSElement) driver.findElement(By.id("75 kg"));
	//
	// moveSliderInDirection(currentValue, currentGoalSlider, 60);
	// }
	//
	// private void moveSliderInDirection(IOSElement currentValue, IOSElement
	// currentGoalSlider, int desiredTestValue) {
	// Actions move = new Actions(driver);
	// move.click(currentGoalSlider).build().perform();
	//
	// do { Integer.parseInt(currentValue.getText());
	// if (Integer.parseInt(currentValue.getText()) != desiredTestValue &&
	// (Integer.parseInt(currentValue.getText()) > desiredTestValue)) {
	// move.sendKeys(Keys.ARROW_RIGHT).build().perform();
	// } else if (Integer.parseInt(currentValue.getText()) != desiredTestValue &&
	// (Integer.parseInt(currentValue.getText()) < desiredTestValue)) {
	// move.sendKeys(Keys.ARROW_LEFT).build().perform();
	// }
	// } while (Integer.parseInt(currentValue.getText())!=desiredTestValue);
	// }

	// Calories widget

	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"CALORIES\"]/preceding-sibling::XCUIElementTypeTextField")
	public WebElement LogCaloriesInputField;
	
	// Steps widget
	
	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"STEPS\"]/preceding-sibling::XCUIElementTypeTextField")
	public WebElement LogStepsInputField;
	
	// Log data

	@iOSFindBy(id = "Save")
	public WebElement SaveBtnInLogDataScreen;

	@iOSFindBy(id = "Change day / time")
	public WebElement ChangeDayTimeInLogDataScreen;
	
	// Sleep widget

	@iOSFindBy(id = "WENT TO SLEEP YESTERDAY")
	public WebElement VerifyText1InLogSleepScreen;

	@iOSFindBy(id = "WOKE UP TODAY")
	public WebElement VerifyText2InLogSleepScreen;

	// Widget details screen

	@iOSFindBy(id = "Week")
	public WebElement WeekSwitchInGraphViewScreen;

	@iOSFindBy(id = "2 Months")
	public WebElement TwoMonthsSwitchInGraphViewScreen;

	@iOSFindBy(id = "Log data")
	public WebElement LogdataBTNInGraphViewScreen;

	@iOSFindBy(id = "Connect tracker")
	public WebElement ConnecttrackerBTNInGraphViewScreen;

	@iOSFindBy(id = "Edit goal")
	public WebElement EditgoalBTNInWidgetDetScrnConMenu;

	@iOSFindBy(id = "View all data")
	public WebElement ViewalldataBTNInWidgetDetScrnConMenu;

	@iOSFindBy(id = "Cancel")
	public WebElement CancelBTNInWidgetDetScrnConMenu;
	
	@iOSFindBy(xpath = "//XCUIElementTypeCell/XCUIElementTypeStaticText[contains(@label,'a Fact')]")
	public WebElement FactSectionOnWidgetDetail;
	
	@iOSFindBy(xpath = "(//XCUIElementTypeButton[@label='Edit'])[1]")
	public WebElement FirstEditDatapointButton;
	
	@iOSFindBy(id = "Delete")
	public WebElement DeleteDatapointButton;

}
