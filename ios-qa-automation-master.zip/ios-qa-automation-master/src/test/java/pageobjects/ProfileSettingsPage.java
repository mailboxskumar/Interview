/**
 * 
 */
package pageobjects;

/**
 * @author ravibadugu
 *
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;


public class ProfileSettingsPage {
	
	public ProfileSettingsPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@iOSFindBy(xpath="//XCUIElementTypeTextField[../XCUIElementTypeStaticText[@label='Email']]")
	public WebElement EmailInputField;
	
	@iOSFindBy(xpath="//XCUIElementTypeTextField[../XCUIElementTypeStaticText[@label='First name']]")
	public WebElement FirstNameInputField;
	
	@iOSFindBy(xpath="//XCUIElementTypeTextField[../XCUIElementTypeStaticText[@label='Last name']]")
	public WebElement LastNameInputField;
	
	@iOSFindBy(xpath="//XCUIElementTypeTextField[../XCUIElementTypeStaticText[@label='Display name']]")
	public WebElement DisplayNameInputField;
	
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"Change photo\"]")
	public WebElement ChangePhotoButton;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[../XCUIElementTypeStaticText[@label='Birthday']]")
	public WebElement BirthdayProfileSettings;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[../XCUIElementTypeStaticText[@label='Gender']]")
	public WebElement GenderProfileSettings;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[../XCUIElementTypeStaticText[@label='Location']]")
	public WebElement LocationProfileSettings;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[../XCUIElementTypeStaticText[@label='Height']]")
	public WebElement HeightProfileSettings;
	
	@iOSFindBy(id="Update location")
	public WebElement UpdateLocationButton;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"Motivation\"]")
	public WebElement UpdateMotivationLabel;

}
