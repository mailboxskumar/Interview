package pageobjects;



import io.appium.java_client.ios.IOSDriver;



	
		public abstract class BaseClass {
			public static IOSDriver driver;
			public static boolean bResult;
			public  BaseClass(IOSDriver driver){
				BaseClass.driver = driver;
				BaseClass.bResult = true;
		}

		}


