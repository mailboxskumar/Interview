/**
 * 
 */
package pageobjects;

/**
 * @author ravibadugu
 *
 */

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class ActionPlanPage {
	
	
	public  ActionPlanPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(id="Plans")
	public WebElement navPlansButton;
	
	@iOSFindBy(id="Start new plan")
	public WebElement startNewPlanButton;
	
	@iOSFindBy(id="Join Action Plan")
	public WebElement JoinActionPlanButton;
	
	@iOSFindBy(id="Share")
	public WebElement ShareActionPlanButton;
	
	@iOSFindBy(id="Done today")
	public WebElement DoneTodayButton;
	
	@iOSFindBy(id="Change habit")
	public WebElement ChangeHabitButton;
	
	@iOSFindBy(id="Show description")
	public WebElement ShowDescriptionButton;
	
	@iOSFindBy(id="Hide description")
	public WebElement HideDescriptionButton;
	
	@iOSFindBy(id="Leave Action Plan")
	public WebElement LeaveActionPlanText;

	@iOSFindBy(id="Are you sure you want to leave the Action Plan?")
	public WebElement LeaveAPPopUpText;
	
	@iOSFindBy(id="Leave")
	public WebElement LeavePopUpButton;
	
	@iOSFindBy(id="Checked off today")
	public WebElement checkedOffTodayButton;
	
	@iOSFindBy(id="tick")
	public WebElement tickButton;
	
	@iOSFindBy(id="Commit to this")
	public WebElement CommitToThisButton;

}