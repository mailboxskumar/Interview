package pageobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class StepsLogData {


public StepsLogData(IOSDriver<WebElement> driver) 
    
    {
		
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	

		@iOSFindBy(className="TextField")
		public WebElement logSteps;
		public StepsLogData enterSteps(String txt) {
			logSteps.sendKeys(txt);	
			return this;
	
		}	
	
		@iOSFindBy(xpath="//XCUIElementTypeApplication[1]"
			+ "/XCUIElementTypeWindow[1]"
			+ "/XCUIElementTypeOther[1]"
			+ "/XCUIElementTypeOther[1]"
			+ "/XCUIElementTypeOther[1]"
			+ "/XCUIElementTypeOther[1]"
			+ "/XCUIElementTypeButton[3]")
		public WebElement button;
		public StepsLogData tapSave() {
			button.click();
			return this;
		}	
  
		@iOSFindBy(xpath="/XCUIElementTypeApplication[1]"
				+ "/XCUIElementTypeWindow[1]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeOther[2]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeTable[1]"
				+ "/XCUIElementTypeCell[1]"
				+ "/XCUIElementTypeStaticText[2]")
		public WebElement clickDay;
		public StepsLogData selectDay() {
			clickDay.sendKeys("15");		
			return this;	
		}
	
		@iOSFindBy(id = "Close")
		public WebElement selectClose;
		public StepsLogData userselectClose() {
			selectClose.click();
			return this;
		} 
	
		public int delay(int time) {
			long endTime = System.currentTimeMillis() + time;
	   	 	while (System.currentTimeMillis() < endTime);
	   	 	return time;
		}
	
		@iOSFindBy(xpath="//XCUIElementTypeApplication[1]"
				+ "/XCUIElementTypeWindow[1]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeOther[1]"
				+ "/XCUIElementTypeButton[2]")
		public WebElement clickBack;
		public StepsLogData userselectBackword() {
			clickBack.click();
			return this;
		}		
	
		@iOSFindBy(id="Close")
		public WebElement clickClose;
		public StepsLogData selectCloseBack() {
			clickClose.click();
			return this;
		}
	
		}
