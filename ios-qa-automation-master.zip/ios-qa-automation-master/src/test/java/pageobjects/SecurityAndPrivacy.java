/**
 * 
 */
package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author ravibadugu
 * 
 *
 */
public class SecurityAndPrivacy {
	
	public SecurityAndPrivacy(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
		@iOSFindBy(xpath="//XCUIElementTypeSwitch")
		public WebElement PrivacySwitcher;
		
		@iOSFindBy(xpath="//XCUIElementTypeSecureTextField[../XCUIElementTypeStaticText[@label='Current password']]")
		public WebElement CurrentPasswordInputField;
		
		@iOSFindBy(xpath="//XCUIElementTypeSecureTextField[../XCUIElementTypeStaticText[@label='New password']]")
		public WebElement NewPasswordInputField;
		
		@iOSFindBy(xpath="//XCUIElementTypeSecureTextField[../XCUIElementTypeStaticText[@label='Confirm password']]")
		public WebElement ConfirmPasswordInputField;

}
