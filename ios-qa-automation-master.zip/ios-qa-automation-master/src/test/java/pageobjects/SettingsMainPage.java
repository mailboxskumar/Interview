/**
 * 
 */
package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author rado
 *
 */
public class SettingsMainPage {
	
	public IOSDriver driver;
	
	public SettingsMainPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(xpath="//XCUIElementTypeTable/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeImage")
	public WebElement AccountMainUserAvatar;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@label,'My motivation')]/preceding-sibling::XCUIElementTypeStaticText")
	public WebElement AccountMainUsername;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@label,'My motivation')]")
	public WebElement AccountMainUserMotivation;
	
	@iOSFindBy(id="Connected trackers")
	public WebElement AccountMainConnectedTrackersNavButton;
	
	@iOSFindBy(id="Friends")
	public WebElement AccountMainFriendsNavButton;
	
	@iOSFindBy(id="Help and support")
	public WebElement AccountMainHelpNavButton;
	
	@iOSFindBy(xpath="//*[@name='Account']/parent::XCUIElementTypeCell")
	public WebElement AccountEditButton;
	
	@iOSFindBy(id="Security and privacy")
	public WebElement SecurityAndPrivacyButton;
	
	@iOSFindBy(id="Notifications")
	public WebElement NotificationsButton;
	
	@iOSFindBy(xpath="(//XCUIElementTypeButton[../XCUIElementTypeButton[contains(@label,'edit profile')]])[1]")
	public WebElement ProfileEditButton;
}
