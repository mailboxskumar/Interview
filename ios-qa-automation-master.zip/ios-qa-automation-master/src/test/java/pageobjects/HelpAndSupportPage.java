package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class HelpAndSupportPage {
	
	public HelpAndSupportPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(id="Help and support")
	public WebElement HelpAndSupportButton;
	
	@iOSFindBy(id="FAQs")
	public WebElement FAQsButton;
	
	@iOSFindBy(id="T&C's and Privacy Policy")
	public WebElement TandCsAndPrivacyPolicysButton;
	
}
