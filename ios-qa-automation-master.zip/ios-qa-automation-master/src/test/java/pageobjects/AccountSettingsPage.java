package pageobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class AccountSettingsPage {
	
	
	public AccountSettingsPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

		@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name='Height']")
		public WebElement AccountSettingsHeightLabel;
		
		@iOSFindBy(xpath="//XCUIElementTypeSegmentedControl/child::XCUIElementTypeButton[@name='cm']/following-sibling::XCUIElementTypeButton[@name='ft']")
		public WebElement AccountSettingsHeightUnitsSwitcher;
		
		@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name='Weight']")
		public WebElement AccountSettingsWeightLabel;
		
		@iOSFindBy(xpath="//XCUIElementTypeSegmentedControl/child::XCUIElementTypeButton[@name='kg']/following-sibling::XCUIElementTypeButton[@name='lb']/following-sibling::XCUIElementTypeButton[@name='st']")
		public WebElement AccountSettingsWeightUnitsSwitcher;
		
		@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name='Distance']")
		public WebElement AccountSettingsDistanceLabel;
		
		@iOSFindBy(xpath="//XCUIElementTypeSegmentedControl/child::XCUIElementTypeButton[@name='km']/following-sibling::XCUIElementTypeButton[@name='mi']")
		public WebElement AccountSettingsDistanceUnitsSwitcher;
		
		@iOSFindBy(id="account")
		public WebElement AccountIcon;
		
		@iOSFindBy(id="Export data")
		public WebElement ExportDataButton;
		
		@iOSFindBy(id="Close account")
		public WebElement CloseAccountButton;
		
		@iOSFindBy(id="Log out")
		public WebElement LogOutButton;
		
}
