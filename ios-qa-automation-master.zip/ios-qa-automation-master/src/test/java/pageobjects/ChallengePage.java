package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class ChallengePage {
	
	
	public  ChallengePage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(id="Join Challenge")
	public WebElement joinChallengeButton;
	
	// Challenge overflow menu
	
	@iOSFindBy(id="Rules")
	public WebElement challengeMenuRules;
	
	@iOSFindBy(id="Share Challenge")
	public WebElement challengeMenuShare;
	
	@iOSFindBy(id="View trackers")
	public WebElement challengeMenuTrackers;
	
	@iOSFindBy(id="Leave Challenge")
	public WebElement challengeMenuLeave;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name='Leave Challenge']")
	public WebElement challengeAlertLeave;
	
	// Team challenge UI
	
	@iOSFindBy(id="View team members")
	public WebElement teamChallengeTeamMembers;
	
	@iOSFindBy(id="View Leaderboard")
	public WebElement teamChallengeViewLeaderboard;
	
	@iOSFindBy(id="All posts")
	public WebElement teamChallengeAllPostsTab;
	
	@iOSFindBy(id="Team posts")
	public WebElement teamChallengeTeamPostsTab;

	@iOSFindBy(id="Challenges")
	public WebElement challengesbutton;	
	
}
