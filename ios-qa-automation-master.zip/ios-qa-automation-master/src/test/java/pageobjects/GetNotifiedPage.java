/**
 * 
 */
package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author ravibadugu
 *
 */
public class GetNotifiedPage {
	
	
	public GetNotifiedPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	IOSDriver<?> driver;
	
	@iOSFindBy(id="Get notified!")
	public WebElement VerifyGetNotifiedTittle;
	
	@iOSFindBy(id="Sounds good")
	public WebElement TapOnSoundsgoodButton;
	
	@iOSFindBy(id="“Wellbeing” Would Like to Send You Notifications")
	public WebElement VerifyTextInNotifiedPopUp;
	
	@iOSFindBy(id="Don’t Allow")
	public WebElement TapOnDontAllowButtonInNotifiedPopUp;
	
	@iOSFindBy(id="Allow")
	public WebElement TapOnAllowButtonInNotifiedPopUp;
	
	@iOSFindBy(id="Track your exercise")
	public WebElement TapBackArrowFromGetNotifiedScreen;

}
