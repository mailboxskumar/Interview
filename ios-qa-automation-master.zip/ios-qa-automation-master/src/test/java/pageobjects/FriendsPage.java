/**
 * 
 */
package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author ravibadugu
 *
 */
public class FriendsPage {
	
	public FriendsPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
//	@iOSFindBy(id="Following")
//	public WebElement VerifyFollowingPageTittle;
//	public FriendsPage VerifyingFollowingPageTittle() {
//		VerifyFollowingPageTittle.getText();
//		VerifyFollowingPageTittle.isDisplayed();
//		return this;
//	}
	
	@iOSFindBy(id="Edit settings")
	public WebElement TapOnAccountIcon;
	public FriendsPage TappingOnAccountIcon() {
		TapOnAccountIcon.click();
		return this;
	}
	
	@iOSFindBy(id="Friends")
	public WebElement TapOnFriends;
	public FriendsPage TappingOnFriends() {
		TapOnFriends.click();
		return this;
	}
	
	@iOSFindBy(id="Account")
	public WebElement TapOnBackButtonToAccount;
	public FriendsPage TappingOnBackButtonToAccount() {
		TapOnBackButtonToAccount.click();
		return this;
	}
	
	@iOSFindBy(id="Close")
	public WebElement TapOnCloseButtonFromAccount;
	public FriendsPage TappingOnCloseButtonFromAccount() {
		TapOnCloseButtonFromAccount.click();
		return this;
	}
	
	@iOSFindBy(id="Following")
	public WebElement TapOnFollowingButton;
	public FriendsPage TappingOnFollowingButton() {
		TapOnFollowingButton.click();
		return this;
	}
	
	@iOSFindBy(id="Followers")
	public WebElement TapOnFollowersButton;
	public FriendsPage TappingOnFollowersButton() {
		TapOnFollowersButton.click();
		return this;
	}
	
	@iOSFindBy(id="Requests")
	public WebElement TapOnRequestsButton;
	public FriendsPage TappingOnRequestsButton() {
		TapOnRequestsButton.click();
		return this;
	}
	
	@iOSFindBy(id="Add")
	public WebElement TapOnAddButton;
	public FriendsPage TappingOnAddButton() {
		TapOnAddButton.click();
		return this;
	}
	
	@iOSFindBy(id="Following")
	public WebElement TapOnBackButtonToFriendsPage;
	public FriendsPage TappingOnBackButtonToFriendsPage() {
		TapOnBackButtonToFriendsPage.click();
		return this;
	}
	
	@iOSFindBy(id="Find People")
	public WebElement VerifyFindPeoplePageTittle;
	public FriendsPage VerifyingFindPeoplePageTittle() {
		VerifyFindPeoplePageTittle.getText();
		VerifyFindPeoplePageTittle.isDisplayed();
		return this;
	}
	
	@iOSFindBy(id="Find people to follow")
	public WebElement TapOnFindPeopleTextBox;
	public FriendsPage TappingOnFindPeopleTextBox() {
		TapOnFindPeopleTextBox.click();
		return this;
	}
	
	@iOSFindBy(id="Find people to follow")
	public WebElement ClearOnFindPeopleTextBox;
	public FriendsPage ClearingOnFindPeopleTextBox() {
		ClearOnFindPeopleTextBox.clear();
		return this;
	}
	
	@iOSFindBy(id="Find people to follow")
	public WebElement EnterFindPeopleTextBox;
	public FriendsPage EnteringFindPeopleTextBox() {
		EnterFindPeopleTextBox.sendKeys("Ravi Badugu");
		return this;
	}
	
	@iOSFindBy(id="Done")
	public WebElement TapOnDoneNextToFindPeopleTextBox;
	public FriendsPage TappingOnDoneNextToFindPeopleTextBox() {
		TapOnDoneNextToFindPeopleTextBox.click();
		return this;
	}
	
	@iOSFindBy(id="add")
	public WebElement TapOnAddButtonNextToResult;
	public FriendsPage TappingOnAddButtonNextToResult() {
		TapOnAddButtonNextToResult.click();
		return this;
	}
	
	@iOSFindBy(id="Ravi Badugu")
	public WebElement VerifySearchResult;
	public FriendsPage VerifyingSearchResult() {
		VerifySearchResult.getText();
		VerifySearchResult.isDisplayed();
		return this;
	}


}
