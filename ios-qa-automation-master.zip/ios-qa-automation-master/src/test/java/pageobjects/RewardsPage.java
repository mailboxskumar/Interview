package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author ravibadugu
 *
 */
public class RewardsPage {
	
	public RewardsPage(IOSDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[@name=\"REWARD POINTS\"]")
	public WebElement RewardPointsLabel;
	
	@iOSFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'How do I earn more')]")
	public WebElement HowToRewardExpander;
	
	@iOSFindBy(xpath="(//XCUIElementTypeCell)[1]")
	public WebElement RewardTile;
	
	@iOSFindBy(id="Get this reward")
	public WebElement GetRewardButton;
	
	@iOSFindBy(xpath="//XCUIElementTypeButton[@name=\"You don’t have enough points yet\"]")
	public WebElement notEnoughPointsButton;
	
	@iOSFindBy(xpath="//XCUIElementTypeOther/XCUIElementTypeOther[XCUIElementTypeImage[@name=\"reward-icon\"]]")
	public WebElement RewardEntryHeader;
}
