package step_definitions;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(dotcucumber = ".cucumber", 
 	features = { "src/main/resources/HealthLabiOS/FeatureFiles" },
 	dryRun = false,
 	strict = false,
 	monochrome = false,
 	format = {"pretty", "html:target/cucumber", "json:target/cucumber.json" },
		//glue = {"iOSAutomation/src/test/java/step_definitions"},

	tags = "@C17484")



public class Runner {
	

}
