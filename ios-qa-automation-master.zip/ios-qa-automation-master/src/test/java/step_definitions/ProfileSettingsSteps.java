/**
 * 
 */
package step_definitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.ios.IOSDriver;
import pageobjects.*;


/**
 * @author ravibadugu
 *
 */
public class ProfileSettingsSteps {
	
	public IOSDriver driver;
	AccountSettingsPage AccountSettings;
	ProfileSettingsPage profile;
	CommonMethods common;
	//InAppNotificationSettingsPage NotificationSettings;
	
	public ProfileSettingsSteps()
    {
		driver = Launcher.driver;
    	AccountSettings = new AccountSettingsPage(driver);
    	profile = new ProfileSettingsPage(driver);
    	common = new CommonMethods(driver);
    	//NotificationSettings = new InAppNotificationSettingsPage(driver);
    }
		
	// ToDo - extend it in the future
	@When("^I update (.*?) on profile page$")
	public void I_update_field_on_profile_page(String field) throws Throwable {
		System.out.println("Executing: When I update "+field+" on profile page");
		switch (field) {
		case "Date Of Birth": 
			profile.BirthdayProfileSettings.click();
			break;
		case "Gender": 
			profile.GenderProfileSettings.click();
			break;
		case "Height": 
			profile.HeightProfileSettings.click();
			common.scroll(driver, "vertically", 0.8, 0.7);
			common.DoneButton.click();
			break;
		case "Location": 
			profile.LocationProfileSettings.click();
			profile.UpdateLocationButton.click();
			int isAllowed = driver.findElementsById("Allow").size();
			if (isAllowed > 0) {
				common.TapOn(common.AllowButton);
			}
			break;
		}
	}
	
	// ToDo
	@When("^I set Motivation to (.*?)$")
	public void I_set_motivation_in_settings(String motivation) throws Throwable {
		System.out.println("Executing: When I set Motivation to "+motivation);
		profile.UpdateMotivationLabel.click();
		switch (motivation) {
		case "Get Fit":			
			break;
		case "Live Healthy":			
			break;
		case "Sleep Better":			
			break;
		case "Lose Weight":			
			break;
		case "Manage my Diabetes":			
			break;
		case "Diabetes Prevention":			
			break;
		}
	}

}
