package com.dbs.controller;

import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.HTML;
import static org.jbehave.core.reporters.Format.XML;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.jbehave.core.Embeddable;
import org.jbehave.core.annotations.AfterStories;
import org.jbehave.core.annotations.BeforeStory;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.embedder.EmbedderControls;
import org.jbehave.core.embedder.StoryControls;
import org.jbehave.core.i18n.LocalizedKeywords;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.model.ExamplesTableFactory;
import org.jbehave.core.model.TableTransformers;
import org.jbehave.core.parsers.RegexStoryParser;
import org.jbehave.core.reporters.CrossReference;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.ParameterConverters;
import org.jbehave.core.steps.ScanningStepsFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.anarsoft.vmlens.concurrent.junit.ConcurrentTestRunner;
import com.anarsoft.vmlens.concurrent.junit.ThreadCount;
import com.dbs.commons.ConnectDB;
import com.dbs.commons.DataBaseActions;
import com.dbs.commons.Reporter;
import com.dbs.commons.RunDetails;
import com.dbs.commons.ScenarioAggregator;
import com.dbs.commons.StepListener;
import com.dbs.config.AppConstants;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;
import com.jbehaveforjira.javaclient.JiraStepDocReporter;
import com.jbehaveforjira.javaclient.JiraStoryLoader;
import com.jbehaveforjira.javaclient.JiraStoryPathsFinder;
import com.jbehaveforjira.javaclient.JiraStoryPathsFinder.IssueFilterParam;
import com.jbehaveforjira.javaclient.JiraStoryReporter;


public class TestConfiguration extends JUnitStories implements Runnable{

	public Embedder embedder;
	private static InjectableStepsFactory stepsFactory;
	public Reporter reporter;
	public StepListener listener;

	private Configuration configuration;
	private static final CrossReference xref = new CrossReference();
	public static String metaFilter;
	public static String[] stepPackages;
	public static String customLabel="";
	private String jiraTabName;
	private String paramVal;
	private IssueFilterParam param;
	private static final Logger logger = Logger.getLogger(TestConfiguration.class);
	
	public TestConfiguration(String meta,String[] packageNames,IssueFilterParam LabelOrKey,String paramVal, String jiraTab) {
		metaFilter = meta;
		stepPackages = packageNames;
		param = LabelOrKey;
		this.paramVal=paramVal;
		jiraTabName = jiraTab;
		listener = new StepListener();	
		embedder = new Embedder();
	}
	
	public TestConfiguration(String meta,String[] packageNames,String customJiraLabel,String jiraTab) {
		metaFilter = meta;
		stepPackages = packageNames;
		customLabel = customJiraLabel;
		jiraTabName = jiraTab;
		listener = new StepListener();	
		embedder = new Embedder();
	}	
	@Override @Test
	public void run(){
		embedder = configuredEmbedder();
		try {
	        	DriverManagerFactory.setDriverData(Config.getDeviceData()); 
	        	DataBaseActions.setDbActions();
	        	StepListener.setListener(listener);
				String runTestsOn = DriverManagerFactory.getDriverData("RunTestOn");
				
				if(runTestsOn.equalsIgnoreCase("MB")) {
					String devName = DriverManagerFactory.getDriverData("Device Name");
					String devDesc = DriverManagerFactory.getDriverData("Description");
					logger.info("SYNC: setting Reporter for Device: "+devName);	
					if(jiraTabName.equals("") || jiraTabName == null)
						jiraTabName = devDesc;
					reporter = new Reporter(devName+":"+devDesc.toUpperCase());
					logger.info("SYNC: Reporter has been set for Device: "+devName);					
				}
				else if(runTestsOn.equalsIgnoreCase("IB")) {
					String browser = DriverManagerFactory.getDriverData("Browser");
					if(jiraTabName.equals("") || jiraTabName == null)					
						jiraTabName = browser;
					reporter = new Reporter(browser+":"+browser.toUpperCase());
					logger.info("SYNC: Reporter has been set up for Browser: "+browser);							
				}
				listener.setReporter(reporter);
				logger.info("SYNC: Listener is initialized with Reporter: "+reporter);
				embedder.runStoriesAsPaths(storyPaths());
		} catch (Throwable e) {
			Config.gracefulEnd(e, logger);
		} finally {
			reporter.extent.flush();
			logger.info("Reports have been flushed for Device/Browser: "+jiraTabName);			
			embedder.generateCrossReference();
		}
	}

	@Override
	public Embedder configuredEmbedder() {
		if (configuration == null) {
			configuration = configuration();
		}
		//configuration.storyControls().doMetaByRow(true);
		embedder.useConfiguration(configuration);
		embedder.useMetaFilters(Arrays.asList(metaFilter));
		embedder.useEmbedderControls(new EmbedderControls().useStoryTimeoutInSecs(6000));
		
		 /* if (candidateSteps == null) { candidateSteps = candidateSteps(); }
		  embedder.useCandidateSteps(candidateSteps);*/
		 
		if (stepsFactory == null) {
			stepsFactory = stepsFactory();
		}
		embedder.useStepsFactory(stepsFactory);

		return embedder;
	}

	@Override
	public Configuration configuration() {
		JiraStepDocReporter stepDocReporter = null;
		JiraStoryLoader jiraLoader = null;
		Class<? extends Embeddable> embeddableClass = this.getClass();
		Properties viewResources = new Properties();
		viewResources.put("decorateNonHtml", "true");
		viewResources.put("reports", "ftl/jbehave-reports-with-totals.ftl");
		// Start from default ParameterConverters instance
		ParameterConverters parameterConverters = new ParameterConverters();
		// factory to allow parameter conversion and loading from external resources
		// (used by StoryParser too)
		ExamplesTableFactory examplesTableFactory = new ExamplesTableFactory(new LocalizedKeywords(),
				new LoadFromClasspath(embeddableClass), parameterConverters);
		/*TableTransformers tableTransformers = new TableTransformers();
		ExamplesTableFactory examplesTableFactory = new ExamplesTableFactory(new LocalizedKeywords(),
				new LoadFromClasspath(embeddableClass), tableTransformers);*/
		
		try {
			jiraLoader = new JiraStoryLoader(Config.JIRA_URL, Config.JIRA_PROJECT, Config.JIRA_USER,
					Config.JIRA_PASSWORD, "src/test/resources", true);
			stepDocReporter = new JiraStepDocReporter(Config.JIRA_URL, Config.JIRA_PROJECT, Config.JIRA_USER,
					Config.JIRA_PASSWORD);
		} catch (Throwable t) {
			logger.error("Exception in JIRASetUP class story loader "+t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
		stepDocReporter.includeStepJavaDocs(true);
		return new MostUsefulConfiguration().useStoryLoader(jiraLoader).useStepdocReporter(stepDocReporter)
				.useStoryParser(new RegexStoryParser(examplesTableFactory))
				.useStoryReporterBuilder(new StoryReporterBuilder() {
					public StoryReporter reporterFor(String storyPath, org.jbehave.core.reporters.Format format) {
						if (format.equals(org.jbehave.core.reporters.Format.HTML)) {
							Keywords keywords = keywords();
							return new JiraStoryReporter(new File("target", "story_report.xml"), keywords,
									Config.JIRA_URL, Config.JIRA_PROJECT, Config.JIRA_USER, Config.JIRA_PASSWORD,
									jiraTabName);
						} else {
							return super.reporterFor(storyPath, format);
						}
					}
				}.withCodeLocation(CodeLocations.codeLocationFromClass(embeddableClass))
						.withReporters(listener).withDefaultFormats().withViewResources(viewResources)
						.withFormats(CONSOLE, HTML, XML).withFailureTrace(true).withFailureTraceCompression(true)
						.withCrossReference(xref))
				.useParameterConverters(parameterConverters)
				// use '%' instead of '$' to identify parameters
				
				// * .useStepPatternParser(new RegexPrefixCapturingPatternParser( "%"))
				 
				.useStepMonitor(xref.getStepMonitor());
	}

	@Override
	public InjectableStepsFactory stepsFactory() {
		// return new
		// InstanceStepsFactory(configuration(),listOfSteps());//"com.dbs.steps.mb",
		// "com.dbs.steps.ib"
		return new ScanningStepsFactory(configuration(), stepPackages);

	}

	@Override
	public List<String> storyPaths() {
		List<String> paths =null;
		try {
			String jira_label=System.getProperty("jira.filter.label");
			if(jira_label == null)
				jira_label=customLabel;
				//jira_label="Manual_Execution";
			JiraStoryPathsFinder storyFinder = new JiraStoryPathsFinder(Config.JIRA_URL, Config.JIRA_PROJECT,
					Config.JIRA_USER, Config.JIRA_PASSWORD);
			logger.info("User Label :" +customLabel + ", param :" + param + ", paramVal :" + paramVal);
			if(customLabel.equalsIgnoreCase("") || customLabel == null)
				storyFinder.setIssueFieldFilterParam(param, paramVal);
			else 
				storyFinder.setIssueFieldFilterParam(JiraStoryPathsFinder.IssueFilterParam.LABELS, jira_label);
				
			paths = storyFinder.findPaths();
			logger.info("Number of stories : " + paths.size());
			if(paths.size()<1)
				System.err.println("Number of stories matching the label criteria :"+ paths.size() + ", Label =" + jira_label);
			for(int i=0; i<paths.size();i++)
				System.out.println("Path :"+ paths.get(i));
		}catch (Throwable e) {
			Config.gracefulEnd(e, logger);
		}
		return paths;
	}
}