package com.dbs.controller;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.AfterStories;
import org.jbehave.core.annotations.AfterStory;
import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.BeforeStories;
import org.jbehave.core.annotations.BeforeStory;

import com.dbs.commons.TestDataHandler;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

public class BeforeAndAfter {

	private static final Logger logger = Logger.getLogger(BeforeAndAfter.class);
	
	@BeforeStories
	public void beforeStories() {
		logger.info("@BeforeStories method of JBehave");
		try {
			/*String value = DriverManagerFactory.driverData.get("RunTestOn").trim();
			switch (value.toUpperCase()) {

			case "BOTH":
				DriverManagerFactory.getMobileManager().getMobileDriver();
				DriverManagerFactory.getManager().getWebDriver().get(Config.IB_URL);
				DriverManagerFactory.updateAsInUse();
				break;

			case "IB":
				DriverManagerFactory.getManager().getWebDriver().get(Config.IB_URL);
				DriverManagerFactory.updateAsInUse();
				break;

			case "MB":
				DriverManagerFactory.getMobileManager().getMobileDriver();
				DriverManagerFactory.updateAsInUse();
				break;
			}*/
			/*logger.info("Getting device info");
			String deviceName = Config.getDeviceData().get("Device Name");
			if(Config.GENERATE_DATATABLE_FILES) {
				new TestDataHandler(deviceName).createDataFiles();
			}*/
		logger.info("End of @BeforeStories method of JBehave");	
		} catch (Throwable t) {
			logger.error("Exception occurred in BeforeAfter class beforeStories method "+t.getLocalizedMessage());
			Config.gracefulEnd(t,logger);
		}
	}

	@AfterStories
	public void afterStories() {
		try {
			logger.info("@AfterStories method of JBehave");
			DriverManagerFactory.getMobileManager().quitMobileDriver();
			DriverManagerFactory.getManager().quitWebDriver();
			DriverManagerFactory.updateAsNotInUse();
		logger.info("End of @AfterStories method of JBehave");
		} catch (Throwable t) {
			DriverManagerFactory.updateAsNotInUse();
			logger.error("Exception occurred in BeforeAfter class afterStories method "+t.getLocalizedMessage());
			Config.gracefulEnd(t,logger);
		}

	}

	@BeforeStory
	public void beforeStory() throws Exception {
		logger.info("@BeforeStory method of JBehave");		
		logger.info("End of @BeforeStory method of JBehave");
	}

	@AfterStory
	public void afterSotry() throws Exception {
		logger.info("@AfterStory method of JBehave");
		
		// your code
		
		logger.info("End of @AfterStory method of JBehave");
	}

	@BeforeScenario
	public void beforeScenario() {
		logger.info("Before Scenario :::");
		try {
			//DriverManagerFactory.getMobileManager().getMobileDriver().launchApp();
			//DriverManagerFactory.getManager().getWebDriver().get(Config.IB_URL);
			logger.info("End of Before Scenario :::");
		} catch (Throwable t) {
			logger.error("Exception occurred in BeforeAfter class beforeScenario method "+t.getLocalizedMessage());
			Config.gracefulEnd(t,logger);
		}

	}

	@AfterScenario
	public void afterScenario() {
		logger.info("After Scenario :::");
		try {
			/*if (DriverManagerFactory.getManager().getWebDriver() != null
					|| (DriverManagerFactory.getManager().getMobileDriver() != null)) {*/
				
				DriverManagerFactory.getMobileManager().getMobileDriver().closeApp();
				DriverManagerFactory.getManager().quitWebDriver();
				logger.info("End of After Scenario :::");
			/*} else {
				logger.info("Both drivers are null");
				logger.info("End of After Scenario :::");
			}*/
		} catch (Throwable t) {
			logger.error("Exception occurred in BeforeAfter class afterScenario method "+t.getLocalizedMessage());
			Config.gracefulEnd(t,logger);
		}

	}

}
