package com.dbs.drivers;

import java.io.File;
import java.net.URL;

import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.dbs.config.Config;

public class WebDriverManager extends DriverManager {

	private ChromeDriverService chromeService;
	private String browser;
	private static final Logger logger = Logger.getLogger(WebDriverManager.class);

	public WebDriverManager(String browser) {
		super();
		this.browser = browser;
	}

	@Override
	protected void startService() {

		if (chromeService == null) {
			try {
				chromeService = new ChromeDriverService.Builder()
						.usingDriverExecutable(new File(Config.CHROME_DRIVER_PATH)).usingAnyFreePort().build();
				chromeService.start();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	protected void stopService() {
		if (chromeService != null && chromeService.isRunning()) {
			chromeService.stop();
		}

	}

	@Override
	protected void createDriver() {

		if (DriverManagerFactory.getDriverData("RunTest MobileBrowser").equalsIgnoreCase("true")) {
			MobileWebDriverManager mobileWebManager = new MobileWebDriverManager();
			setIbDriver(mobileWebManager.createMobileWebDriver());
		} else {

			String os = System.getProperty("os.name").toLowerCase();

			if (os.contains("windows")) {
				setIbDriver(returnDriver(browser, ".exe"));

			} else if (os.contains("mac")) {
				setIbDriver(returnDriver(browser, ""));

			}
		}

	}

	private WebDriver returnDriver(String browser, String holder) {
		WebDriver driver = null;

		try {
			switch (browser.toLowerCase()) {

			case "firefox":
				System.setProperty(Config.FIREFOX_DRIVER,
						Config.CURRENT_DIR + File.separator + Config.DRIVER_PATH + "geckodriver" + holder);
				// logging();
				driver = new FirefoxDriver();
				driver.manage().deleteAllCookies();
				break;

			case "chrome":

				System.setProperty(Config.CHROME_DRIVER,
						Config.CURRENT_DIR + File.separator + Config.DRIVER_PATH + "chromedriver" + holder);
				ChromeOptions options = new ChromeOptions();
				// options.addArguments("headless");
				options.addArguments("window-size=1400,600");
				driver = new ChromeDriver(options);
				driver.manage().deleteAllCookies();
				break;

			case "ie":
				System.setProperty(Config.IE_DRIVER,
						Config.CURRENT_DIR + File.separator + Config.DRIVER_PATH + Config.IE_DRIVER_NAME + holder);
				// logging();
				/*
				 * InternetExplorerOptions ieOPtions = new InternetExplorerOptions();
				 * ieOPtions.setCapability(InternetExplorerDriver.
				 * INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				 */

				DesiredCapabilities IEcap = DesiredCapabilities.internetExplorer();
				IEcap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				driver = new InternetExplorerDriver(IEcap);
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				break;

			case "safari":
				System.setProperty(Config.FIREFOX_DRIVER,
						Config.CURRENT_DIR + File.separator + Config.DRIVER_PATH + "geckodriver" + holder);
				driver = new FirefoxDriver();
				driver.manage().deleteAllCookies();
				break;

			case "edge":
				System.setProperty(Config.EDGE_DRIVER,
						Config.CURRENT_DIR + File.separator + Config.DRIVER_PATH + "MicrosoftWebDriver" + holder);
				driver = new EdgeDriver();
				break;

			}
		} catch (Exception e) {
			logger.info("Exception occured " + e.getLocalizedMessage());
			Config.gracefulEnd(e, logger);
		}
		driver.manage().window().maximize();
		driver.get(Config.IB_URL);
		return driver;
	}
}
