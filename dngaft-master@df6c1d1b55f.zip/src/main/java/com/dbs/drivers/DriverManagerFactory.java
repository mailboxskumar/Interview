package com.dbs.drivers;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.dbs.config.Config;


public class DriverManagerFactory {
	static Fillo fillo = new Fillo();
	static Connection conn;
	static Recordset rs;
	private static final Logger logger = Logger.getLogger(DriverManagerFactory.class);
	private static final ThreadLocal<HashMap<String, String>> driverData = new InheritableThreadLocal<>();
	
/*	public static Map<String, String> getDriverData(){
		return driverData.get();
	}*/
	
	public static String getDriverData(String key){
		return driverData.get().get(key);
	}	
	
	public static void setDriverData(HashMap<String, String> device){
		driverData.set(device);
	}
	
	protected static HashMap<String, String> getDriverData(){
		return driverData.get();
	}	

	public static void updateAsInUse() {
		String updateQuery = "Update " + Config.MOBILE_DEVICES_SHEET + " Set Status ='inuse' where Udid='"
				+ getDriverData("Udid").trim() + "'";
		String query = "select * from " + Config.MOBILE_DEVICES_SHEET + " where Udid='" + getDriverData("Udid").trim()
				+ "'";
		try {
			conn = fillo.getConnection(Config.APP_CONFIG_PATH);
			conn.executeUpdate(updateQuery);
			logger.info(updateQuery);
			rs = conn.executeQuery(query);
			rs.next();
			logger.info("Driver status of device " + rs.getField("Udid") + " updated to " + rs.getField("Status"));
			System.out
					.println("Driver status of device " + rs.getField("Udid") + " updated to " + rs.getField("Status"));
			rs.close();
			conn.close();
		} catch (FilloException e) {
			logger.info("Exception occured "+e.getLocalizedMessage());
			Config.gracefulEnd(e,logger);
		}
	}

	public static void updateAsNotInUse() {
		String updateQuery = "Update " + Config.MOBILE_DEVICES_SHEET + " Set Status ='notinuse' where Udid='"
				+ getDriverData("Udid").trim() + "'";
		String query = "select * from " + Config.MOBILE_DEVICES_SHEET + " where Udid='" + getDriverData("Udid").trim()
				+ "'";
		try {
			conn = fillo.getConnection(Config.APP_CONFIG_PATH);
			conn.executeUpdate(updateQuery);
			logger.info("Running query "+updateQuery);
			rs = conn.executeQuery(query);
			rs.next();
			logger.info("Driver status of device " + rs.getField("Udid") + " updated to " + rs.getField("Status"));
			rs.close();
			conn.close();
		} catch (FilloException e) {
			logger.info("Exception occured "+e.getLocalizedMessage());
			Config.gracefulEnd(e,logger);
		}
	}

	public static DriverManager getManager() {
		DriverManager driverManager = null;
		try {
			String browser = getDriverData("Browser");
			if (browser.equalsIgnoreCase("chrome")) {
				driverManager = new WebDriverManager("chrome");
			} else if (browser.equalsIgnoreCase("firefox")) {
				driverManager = new WebDriverManager("firefox");
			} else if (browser.equalsIgnoreCase("ie")) {
				driverManager = new WebDriverManager("ie");
			} else if(browser.equalsIgnoreCase("safari")) {
				driverManager = new WebDriverManager("safari");
			}
		} catch (Throwable e) {
			logger.info("Exception occured "+e.getLocalizedMessage());
			Config.gracefulEnd(e,logger);
		}
		return driverManager;
	}

	public static DriverManager getMobileManager() { 
		try {
			logger.info(":: driverData :" + getDriverData().size());
		}catch (Throwable e) {
			logger.info("Exception occured "+e.getLocalizedMessage());
			Config.gracefulEnd(e,logger);
		}
		
		return new MobileDriverManager(getDriverData());
	}

}