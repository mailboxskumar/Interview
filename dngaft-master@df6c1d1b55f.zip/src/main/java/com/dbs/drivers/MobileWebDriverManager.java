package com.dbs.drivers;

import java.net.URL;

import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.dbs.config.Config;

public class MobileWebDriverManager {

	RemoteWebDriver driver;
	static DesiredCapabilities caps;
	private static final Logger logger = Logger.getLogger(MobileWebDriverManager.class);

	public RemoteWebDriver createMobileWebDriver() {
		try {
			if (DriverManagerFactory.getDriverData("Platform Name").equalsIgnoreCase("Android")) {
				driver = new RemoteWebDriver(new URL("http://" + DriverManagerFactory.getDriverData("ServerURL").trim() + ":"
						+ DriverManagerFactory.getDriverData("Port").trim() + "/wd/hub"), getAndroidCapabilities());
				logger.info("Android driver started on :: " + DriverManagerFactory.getDriverData("ServerURL").trim() + ":"
						+ DriverManagerFactory.getDriverData("Port").trim() + " mobile web driver service");
			} else {
				driver = new RemoteWebDriver(new URL("http://" + DriverManagerFactory.getDriverData("ServerURL").trim() + ":"
						+ DriverManagerFactory.getDriverData("Port").trim() + "/wd/hub"), getIOSCapabilities());
				logger.info("IOS driver started on :: " + DriverManagerFactory.getDriverData("ServerURL").trim() + ":"
						+ DriverManagerFactory.getDriverData("Port").trim() + " mobile web driver service");
			}
		} catch (Throwable t) {
			logger.error("Exception occured in createMobileWebDriver " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
		//driver.manage().window().maximize();
		driver.get(Config.IB_URL);
		return driver;

	}

	private static DesiredCapabilities getIOSCapabilities() {
		logger.info("Setting IOS device Capabilities for Mobile web");
		caps = new DesiredCapabilities();
		if (DriverManagerFactory.getDriverData("Run On Cloud").equalsIgnoreCase("true")) {
			caps.setCapability("accessKey", "eyJ4cC51Ijo5LCJ4cC5wIjoyLCJ4cC5tIjoiTVRVeE5qZzBPVE0zTnpFMU5RIiwiYWxnIjoiSFMyNTYifQ.eyJleHAiOjE4NDY2NTgzMTYsImlzcyI6ImNvbS5leHBlcml0ZXN0In0.WSK_OIi5BXJCnTd1xJCODluGSOjpUWqSHA2EpdHLI7k");
		}
		caps.setCapability("app", "");
		caps.setCapability("browserName",DriverManagerFactory.getDriverData("Browser"));
		/*caps.setCapability("appPackage", DriverManagerFactory.getDriverData(DriverManagerFactory.getDriverData("Browser") + " PackageName"));
		caps.setCapability("appActivity", DriverManagerFactory.getDriverData(DriverManagerFactory.getDriverData("Browser") + " ActivityName"));*/
		caps.setCapability("automationName", "XCUITest");
		caps.setCapability("platformName", DriverManagerFactory.getDriverData("Platform Name"));
		caps.setCapability("platformVersion", DriverManagerFactory.getDriverData("Platform Version"));
		caps.setCapability("UDID", DriverManagerFactory.getDriverData("Udid"));
		caps.setCapability("deviceName", DriverManagerFactory.getDriverData("Device Name"));
	
		return caps;
	}

	private static DesiredCapabilities getAndroidCapabilities() {
		logger.info("Setting Android device Capabilities for Mobile web");
		caps = new DesiredCapabilities();
		if (DriverManagerFactory.getDriverData("Run On Cloud").equalsIgnoreCase("true")) {
			caps.setCapability("accessKey", DriverManagerFactory.getDriverData("Access Key"));
		}
		caps.setCapability("app", "");
		caps.setCapability("appPackage", DriverManagerFactory.getDriverData(DriverManagerFactory.getDriverData("Browser") + " PackageName"));
		caps.setCapability("appActivity", DriverManagerFactory.getDriverData(DriverManagerFactory.getDriverData("Browser") + " ActivityName"));
		caps.setCapability("automationName", "appium");
		caps.setCapability("platformName", DriverManagerFactory.getDriverData("Platform Name"));
		caps.setCapability("platformVersion", DriverManagerFactory.getDriverData("Platform Version"));
		caps.setCapability("udid", DriverManagerFactory.getDriverData("udid"));
		caps.setCapability("browserName",DriverManagerFactory.getDriverData("Browser"));
		caps.setCapability("chromedriverExecutable",Config.CURRENT_DIR+Config.fp+Config.CHROME_DRIVER_PATH); 
		caps.setCapability("deviceName", DriverManagerFactory.getDriverData("Device Name"));
		return caps;
	}
}
