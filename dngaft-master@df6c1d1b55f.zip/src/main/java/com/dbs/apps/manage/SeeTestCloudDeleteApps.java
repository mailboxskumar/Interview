package com.dbs.apps.manage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SeeTestCloudDeleteApps {
    private static final String APPLICATIONS_URL = "/applications/";
    private static final String ACTION = "/delete";
    private String host = "ServerIP";//TODO: IP goes here
    private String port = "port";//TODO: open port goes here
    private String webPage= "http://" + host + ":" + port + "/api/v1";
    private String authStringEnc;
   
    @Before
    public void setup() {
        String name = "admin";//TODO: admin user name is here
        String password = "va1idPassword";//TODO: admin password is here
           
        String authString = name + ":" + password;
        authStringEnc = Base64.getEncoder().encodeToString(authString.getBytes());
    }
   
   
    @Test
    public void testPostNewApplication() throws IOException {
        String postURL = prepareURL();
        doPost(postURL, "", webPage, authStringEnc);
    }
     
    private String prepareURL() {
        String applicationID = "appID";//TODO: applicationID
        return APPLICATIONS_URL + applicationID + ACTION;
    }
    protected void printPost(URL url, HttpURLConnection httpURLConnection, String query) throws IOException {
        int responseCode = httpURLConnection.getResponseCode();
        System.out.println("\nSending 'POST' request to URL : " + url);
        System.out.println("Sending Query : " + query);
        System.out.println("Response Code : " + responseCode);
    }
   
    /**
     * @param entity can be "/users" / "/projects" / "/devices" etc
     * String query = String.format("param1=%s&param2=%s", URLEncoder.encode(param1, charset), URLEncoder.encode(param2, charset));
     */
    protected String doPost(String entity , String query, String webPage, String authStringEnc) throws IOException {
        URL url = new URL(webPage+entity);
        URLConnection urlConnection = url.openConnection();
        urlConnection.setDoOutput(true);
        urlConnection.setRequestProperty("Accept", "application/json");
        urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=" + StandardCharsets.UTF_8.name());
        urlConnection.setRequestProperty("Authorization", "Basic " + authStringEnc);
   
        OutputStream output = urlConnection.getOutputStream();
        output.write(query.getBytes(StandardCharsets.UTF_8.name()));
           
        HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
          
        printPost(url, httpURLConnection, query);
  
        InputStream stream = null;
          
        if (httpURLConnection.getResponseCode() >= 400) {
            stream = httpURLConnection.getErrorStream();
              
        } else {
            stream = httpURLConnection.getInputStream();      
        }
          
        BufferedReader in = new BufferedReader(new InputStreamReader(stream));
        String inputLine;
        StringBuffer responseBuffer = new StringBuffer();
  
        while ((inputLine = in.readLine()) != null) {
            responseBuffer.append(inputLine);
        }
        in.close();
          
        //print result
        System.out.println(responseBuffer.toString());
        boolean isResponseValid = httpURLConnection.getResponseCode() < 300;
        Assert.assertTrue("Did not get valid response", isResponseValid);
        return responseBuffer.toString();
           
    }
}