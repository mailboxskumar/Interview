package com.dbs.commons;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.dbs.config.Config;

public class RunDetails {

	private static final Logger logger = Logger.getLogger(RunDetails.class);

	// RunLevel :-

	public static String runID;
	public static Timestamp runStartTime;
	public static Timestamp runEndTime;
	static PreparedStatement pstmt;
	static ResultSet rs;

	public static Timestamp getCurrentTime() {
		return new Timestamp(System.currentTimeMillis());
	}
	// Totals :-

	public static int totalStories;
	public static int totalScenarios;
	public static int totalExamples;
	public static int totalExamplesPassed;
	public static int totalExamplesFailed;
	public static int totalExamplesSkipped;
	public static int totalExamplesPending;

	// Story Level :-

	public static String jiraID;
	public static String scenarioID;
	private static String scenarioSeq;
	private static String stepSeq;
	public static String stepID;
	public static String currentStepSeqId;	
	

	private static DataBaseActions dbBaseActions = DataBaseActions.getDbActions();

	public static void insertActionsIntoDB(String stepSeq, String actionName, String actionInput, String imgData) {
		String query = "INSERT INTO `ib_reports`.`t_actions` (`step_seq`, `action_name`, `action_input`, `action_output`, `resource_1`, `resource_2`, `resource_3`) "
    			+ "VALUES ('"+stepSeq+"', '"+actionName+"', '"+actionInput+"', '"+""+"','"+ imgData+"', 0x330000, 0x3300);";
		logger.info("Async call to save screenshot started");
		if(!Config.LOCAL_RUN) {
			logger.info("Executing the query =>" + "INSERT INTO `ib_reports`.`t_actions` (`step_seq`, `action_name`, "
					+ "`action_input`, `action_output`, `resource_1`, `resource_2`, `resource_3`) "
    			+ "VALUES ('"+stepSeq+"', '"+actionName+"', '"+actionInput+"', '"+""+"','"+ imgData.length()+"', 0x330000, 0x3300)");
			dbBaseActions.executeUpdate(query);	
		}
	};

	public static void insertStepDetailsIntoDB(String scenarioSeq, String stepID, String scenarioID, String stepName,
			String status) {
		String query = "INSERT INTO `ib_reports`.`t_step_details` (`scenario_seq`, `step_id`, `scenario_id`, `step_name`, `status`) "
				+ "VALUES ('" + scenarioSeq + "','" + stepID + "', '" + scenarioID + "', '" + stepName.replace("'", "''") + "', '"
				+ status + "');";
		if(!Config.LOCAL_RUN) {
			logger.info("Executing the query => " + "INSERT INTO `ib_reports`.`t_step_details` (`scenario_seq`, `step_id`,"
					+ " `scenario_id`, `step_name`, `status`) VALUES ('" + scenarioSeq + "','" + stepID + "', '" + scenarioID 
					+ "', '" + stepName.replace("'", "''") + "', '" + status + "');");
			dbBaseActions.executeUpdate(query);
		}
	};

	public static void insertScenarioDetailsIntoDB(String runID, String JiraID, String scenarioID, int exampleID,
			String scenarioName, String executionDevice, String scenarioStatus, String scenarioTags) {
		String query = "INSERT INTO `ib_reports`.`t_scenario_details` (`run_id`, `jira_no`, `scenario_id`, `example_id`, `Scenario_name`, `execution_device`, `status`,`scenarios_tags`) "
				+ "VALUES ('" + runID + "', '" + JiraID + "', '" + scenarioID + "', '" + exampleID + "', '"
				+ scenarioName.replace("'", "''") + "', '" + executionDevice + "', '" + scenarioStatus + "', '" + scenarioTags + "');";
		if(!Config.LOCAL_RUN) {
			logger.info("Executing the query => " + "INSERT INTO `ib_reports`.`t_scenario_details` "
					+ "(`run_id`, `jira_no`, `scenario_id`, `example_id`, `Scenario_name`, `execution_device`, `status`,"
					+ "`scenarios_tags`) VALUES ('" + runID + "', '" + JiraID + "', '" + scenarioID + "', '" + exampleID + "', '"
					+ scenarioName.replace("'", "''") + "', '" + executionDevice + "', '" + scenarioStatus + "', '" + scenarioTags + "');" );
			dbBaseActions.executeUpdate(query);
		}
			
		}

	public static void insertRunDetailsIntoDB(String runID, String country, String environment, String exec_mode,
			String releaseName, String sprintNo, Timestamp runStart) {

		try {
		
		String query = "INSERT INTO `ib_reports`.`run_details` (`Run_id`, `Country`, `Environment`, `Exec_mode`, `Release_name`, `Sprint_no`, `scenarios_total`, `examples_total`, `tests_total`, `tests_passed`, `tests_failed`, `tests_skipped`, `tests_Pending`, `run_start`) "
				+ "		VALUES ('" + runID + "','" + country + "', '" + environment + "', '" + exec_mode + "', '"
				+ releaseName + "', '" + sprintNo + "', 0, 0, 0, 0, 0, 0, 0,'" + runStart + "');";
		if(!Config.LOCAL_RUN) {
			logger.info("Executing the query =>" + "INSERT INTO `ib_reports`.`run_details` (`Run_id`, `Country`, `Environment`, "
					+ "`Exec_mode`, `Release_name`, `Sprint_no`, `scenarios_total`, `examples_total`, `tests_total`, `tests_passed`,"
					+ " `tests_failed`, `tests_skipped`, `tests_Pending`, `run_start`) VALUES ('" + runID + "','" + country + "', '" 
					+ environment + "', '" + exec_mode + "', '" + releaseName + "', '" + sprintNo + "', 0, 0, 0, 0, 0, 0, 0,'" + runStart + "');");
			dbBaseActions.executeUpdate(query);
		}
			
		}catch(Throwable t) {
			Config.gracefulEnd(t, logger);
		}
	}

	public static void updateRunDetails(int totalScenarios, int totalExamples, int totalExamplesPassed,
			int totalExamplesFailed, int totalExamplesSkipped, int totalExamplesPending) {
		try {
		
			String query = "UPDATE `ib_reports`.`run_details` SET `scenarios_total`='" + totalScenarios
				+ "', `examples_total`='" + totalExamples + "', `tests_total`='" + totalExamples + "', `tests_passed`='"
				+ totalExamplesPassed + "', `tests_failed`='" + totalExamplesFailed + "', `tests_skipped`='"
				+ totalExamplesSkipped + "', `tests_Pending`='" + totalExamplesPending + "' " + "WHERE  `Run_id`='"
				+ runID + "' AND `Country`='" + Config.COUNTRY + "' AND `Environment`='" + Config.ENVIRONMENT
				+ "' AND `Exec_mode`='" + Config.EXECUTION_MODE + "' AND `Release_name`='" + Config.RELEASE + "';";
			if(!Config.LOCAL_RUN) {
				logger.info("Executing the query :" + "UPDATE `ib_reports`.`run_details` SET `scenarios_total`='" + totalScenarios
					+ "', `examples_total`='" + totalExamples + "', `tests_total`='" + totalExamples + "', `tests_passed`='"
					+ totalExamplesPassed + "', `tests_failed`='" + totalExamplesFailed + "', `tests_skipped`='"
					+ totalExamplesSkipped + "', `tests_Pending`='" + totalExamplesPending + "' " + "WHERE  `Run_id`='"
					+ runID + "' AND `Country`='" + Config.COUNTRY + "' AND `Environment`='" + Config.ENVIRONMENT
					+ "' AND `Exec_mode`='" + Config.EXECUTION_MODE + "' AND `Release_name`='" + Config.RELEASE + "';" );
				dbBaseActions.executeUpdate(query);
			}
			
		}catch(Throwable t) {
			Config.gracefulEnd(t, logger);
		}
	}

	public static void updateScenarioDetails(String JiraID, String scenarioID, int exampleID, String scenarioStatus,
			String scenarioTags) {
		try {	
		String query = "UPDATE `ib_reports`.`t_scenario_details` SET `example_id`='" + exampleID + "', `status`='"
				+ scenarioStatus + "', `scenarios_tags`='" + scenarioTags + "'" + " WHERE  `run_id`='" + runID
				+ "' AND `jira_no`='" + JiraID + "' AND `scenario_id`='" + scenarioID + "';";
			if(!Config.LOCAL_RUN) {
				logger.info("Executing the query ==>" + "UPDATE `ib_reports`.`t_scenario_details` SET `example_id`='" 
						+ exampleID + "', `status`='" + scenarioStatus + "', `scenarios_tags`='" + scenarioTags + "'" 
						+ " WHERE  `run_id`='" + runID 	+ "' AND `jira_no`='" + JiraID + "' AND `scenario_id`='" + scenarioID + "';");
				dbBaseActions.executeUpdate(query);
			}
			
		}catch(Throwable t) {
			Config.gracefulEnd(t, logger);
		}
	}

	public static void updateStepDetails(String stepName, String stepID, String status, String scenarioID) {
		try {
		String query = "UPDATE `ib_reports`.`t_step_details` SET `step_name`='" + stepName.replace("'", "''") + "', `status`='" + status
				+ "' " + "WHERE  `step_id`='" + stepID + "' AND `scenario_id`='" + scenarioID + "';";
		if(!Config.LOCAL_RUN) {
			logger.info("Executing the query : " + "UPDATE `ib_reports`.`t_step_details` SET `step_name`='" + stepName.replace("'", "''") 
			+ "', `status`='" + status 	+ "' " + "WHERE  `step_id`='" + stepID + "' AND `scenario_id`='" + scenarioID + "';" );
			dbBaseActions.executeUpdate(query);
		}
		}catch(Throwable t) {
			Config.gracefulEnd(t, logger);
		}
	}
	
	public static void updateActionDetails(String stepSeq, String imgData) {
		String query = "UPDATE `ib_reports`.`t_actions` SET `resource_1` = '" + imgData + "' WHERE `step_seq` = " + stepSeq + " AND `action_seq` = (SELECT MAX(`action_seq`) FROM `ib_reports`.`t_actions` WHERE `step_seq` = " + stepSeq + ")";
		   	
		logger.info("Async call to save screenshot started");
		if(!Config.LOCAL_RUN) {
			logger.info("Executing the query =>" + query);
			dbBaseActions.executeUpdate(query);	
		}
	}

	public static String getScenarioSeqonRunID() {
		try {
			String query = "select scenario_seq from t_scenario_details where run_id = '" + runID + "' and jira_no = '"
					+ jiraID + "' and scenario_id ='" + scenarioID + "';";
			ResultSet rs = dbBaseActions.executeOnReportingDB(query);
			while (rs.next()) {
				scenarioSeq = rs.getString("scenario_seq");
			}
		} catch (SQLException e) {
			Config.gracefulEnd(e, logger);
		}
		return scenarioSeq;
	}

	public static String getStepSeqonScenarioSeq() {
		try {
			String query = "select step_seq from t_step_details where scenario_seq = '" + scenarioSeq
					+ "' and step_id = '" + stepID + "';";
			ResultSet rs = dbBaseActions.executeOnReportingDB(query);

			while (rs.next()) {
				stepSeq = rs.getString("step_seq");
			}
		} catch (SQLException e) {
			Config.gracefulEnd(e, logger);
		}

		return stepSeq;
	}

	public static void resetValues() {
		logger.info("Resetting all the run details");
		totalExamples = 0;
		totalScenarios = 0;
		totalExamples = 0;
		totalExamplesPassed = 0;
		totalExamplesFailed = 0;
		totalExamplesSkipped = 0;
		totalExamplesPending = 0;

	}

}