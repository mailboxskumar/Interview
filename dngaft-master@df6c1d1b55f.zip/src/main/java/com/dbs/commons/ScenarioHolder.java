package com.dbs.commons;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * @author nagendrapai
 * @version 1.0 Holds the properties for a Scenario - used for listing different types of scenarios
 */

public class ScenarioHolder {
	
	private static final Logger logger = Logger.getLogger(ScenarioHolder.class);
	public String storyNum;
	public int serialNo;
	public String scenario;	
	public List<String> stepsList;
	
	public ScenarioHolder(String story,int serial, String scenr) {
		this.storyNum = story;
		this.serialNo = serial;
		this.scenario = scenr;
		this.stepsList = new ArrayList<String>();
	}

}
