package com.dbs.commons;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.dbs.config.Config;

public class Localization {
	private static final Logger logger = Logger.getLogger(Localization.class);


	public void switchLanguage(String language) {
		boolean isWin = true;
		String[] cmnCmd = {"adb.exe", "-P", "5037", "-s", "3297e2519804", "shell", "am", "broadcast", "-a", "io.appium.settings.locale", "-n", "io.appium.settings/.receivers.LocaleSettingReceiver", "--es", "lang"};

		String os = System.getProperty("os.name").toLowerCase();

		if (os.contains("windows")) {
			isWin = true;
		} else if (os.contains("mac")) {
			isWin = false;
		}
		if (Config.previousLanguage != language) {
			logger.info("Language changed switching the locale of device "+Config.locale);
			//need to run below command 
			/*adb.exe -P 5037 -s 3297e2519804 shell am broadcast -a io.appium.settings.locale -n io.appium.settings/.receivers.LocaleSettingReceiver --es lang zh --es country HK*/

			switch(language.toUpperCase()) {

			case "EN":
				/*adb.exe -P 5037 -s 3297e2519804 shell am broadcast -a io.appium.settings.locale -n io.appium.settings/.receivers.LocaleSettingReceiver --es lang en --es country US*/
				String[] engCmnd = {"en","--es", "country", "US"};
				if(isWin)
					CommandRunner.runProcess(isWin, concatAll(cmnCmd,engCmnd));
				else
					logger.info("Localization: Can't run command, Not Windows Platform");
				break;
			case "CN":
				/*adb.exe -P 5037 -s 3297e2519804 shell am broadcast -a io.appium.settings.locale -n io.appium.settings/.receivers.LocaleSettingReceiver --es lang zh --es country HK*/
				String[] hkCmnd = {"zh","--es", "country", "HK"};
				if(isWin)
					CommandRunner.runProcess(isWin, concatAll(cmnCmd,hkCmnd));		
				else
					logger.info("Localization: Can't run command, Not Windows Platform");				
				break;		
			}

		}

		Config.previousLanguage = language;
	}

	public String setLocale(String language) {

		try {
			if (language.equalsIgnoreCase("CN")) {
				Config.language = "zh";
				Config.locale = "TW";
				logger.info("values are assigned language :: " + Config.language);
				logger.info("values are assigned  locale :: " + Config.locale);
			} else if (language.equalsIgnoreCase("EN")) {
				Config.language = "en";
				Config.locale = "US";
				logger.info("values are assigned language :: " + Config.language);
				logger.info("values are assigned  locale :: " + Config.locale);

			}

		} catch (Throwable t) {

		}
		return Config.language;
	}

	/*Concatenate two String arrays */
	public String[] concatAll(String[]... jobs) {
		int len = 0;
		for (final String[] job : jobs) {
			len += job.length;
		}

		final String[] result = new String[len];

		int currentPos = 0;
		for (final String[] job : jobs) {
			System.arraycopy(job, 0, result, currentPos, job.length);
			currentPos += job.length;
		}

		return result;
	}




}
