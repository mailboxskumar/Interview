package com.dbs.commons;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.dbs.actions.IB_Actions;
import com.dbs.actions.MB_Actions;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

import io.appium.java_client.AppiumDriver;

public class Reporter {
	public ExtentHtmlReporter htmlReporter;
	public ExtentReports extent;
	public ExtentTest log;
	public ExtentTest childlog;
	private String reporterPath;
	static long currentTime;
	public static String currentStep;
	private static final ThreadLocal<Reporter> currentReporter = new InheritableThreadLocal<>();
	private static final Logger logger = Logger.getLogger(Reporter.class);
	
	public Reporter(String deviceName) {
		logger.info("Setting up reports...");
		try {
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String baseFolder = sdf.format(Calendar.getInstance().getTime());
			String[] device = deviceName.split(":");
			File folder = new File(
					Config.CURRENT_DIR + Config.fp + "target" + Config.fp + "extentreport" + Config.fp + baseFolder + Config.fp + device[1]);
			if (!folder.exists()) {
				folder.mkdirs();
			}
			
			reporterPath = Config.EXTENT_REPORTS_PATH;
			logger.info("Reporter path from config file :" + Config.EXTENT_REPORTS_PATH);
			Date today = Calendar.getInstance().getTime();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss");
			String folderName = formatter.format(today);
			//reporterPath = reporterPath.replace("$timestamp", folderName);
			
			reporterPath = reporterPath.replace("$timestamp", baseFolder + Config.fp + device[1] + Config.fp + folderName + "_" + device[0]);

			htmlReporter = new ExtentHtmlReporter(reporterPath);
			InetAddress ipAddress = InetAddress.getLocalHost();
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			// log = extent.createTest(TestCaseName);
			extent.setSystemInfo("OS", System.getProperty("osname"));
			extent.setSystemInfo("Host Name", ipAddress.getHostName());
			extent.setSystemInfo("Environment", Config.ENVIRONMENT);
			extent.setSystemInfo("User Name", Config.REPORTS_USERNAME);
			htmlReporter.config().setChartVisibilityOnOpen(true);
			htmlReporter.config().setDocumentTitle(Config.REPORTS_DOCUMENT_NAME);
			htmlReporter.config().setReportName(Config.REPORTS_NAME);
			htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
			htmlReporter.config().setTheme(Theme.DARK);
			setCurrentReporter(this);
			logger.info("End of Reporter setUp method");
		} catch (Throwable t) {
			logger.error("Error occured " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}	

	public static Reporter getCurrentReporter(){
		return currentReporter.get();
	}	
	
	public static void setCurrentReporter(Reporter report){
		currentReporter.set(report);
	}
	
	protected  void takeScreenshot(WebDriver driver, String step, String dataInput) {

		/*	ReporterActions repoActions = new ReporterActions(step, dataInput, null, driver, "web");
		repoActions.start();*/
		currentTime = System.currentTimeMillis();
		String base64="";
		try {
			base64 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			String filePath = Config.SCREENSHOTS_PATH + currentTime + ".png";
			MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromBase64String(base64)
					.build();
			childlog.info(step, mediaModel);
			logger.info("ScreenShot taken on " + driver + "for step " + step);
		} catch (Throwable t) {
			logger.error("Error occured " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
		if(!Config.LOCAL_RUN && Config.TAKESCREENSHOT_FOREACH_ACTION) {
			String stepSeqId = RunDetails.getStepSeqonScenarioSeq();
			RunDetails.insertActionsIntoDB(stepSeqId,step,dataInput,base64);
			logger.info("Call to save screenshot completed");
		}
	}

	protected  void takeScreenshot(AppiumDriver driver, String step, String dataInput) {

		/*	ReporterActions repoActions = new ReporterActions(step, dataInput, driver, null, "mobile");
		repoActions.start();*/
		currentTime = System.currentTimeMillis();
		String base64="";
		try {
			base64 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			String filePath = Config.SCREENSHOTS_PATH + currentTime + ".png";
			MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromBase64String(base64)
					.build();
			//childlog.info(step, mediaModel);
			childlog.info(step,mediaModel);
			logger.info("ScreenShot taken on " + driver + "for step " + step);
		} catch (Throwable t) {
			logger.error("Error occured " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
		if(!Config.LOCAL_RUN && Config.TAKESCREENSHOT_FOREACH_ACTION) {
			String stepSeqId = RunDetails.getStepSeqonScenarioSeq();
			RunDetails.insertActionsIntoDB(stepSeqId,step,dataInput,base64);
			logger.info("Call to save screenshot completed");
		}

		/*
		currentTime = System.currentTimeMillis();
		try {
			String base64 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			// File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			String filePath = Config.SCREENSHOTS_PATH + currentTime + ".png";
			// String uploadPath = uploadScreenShotPath + System.currentTimeMillis() +
			// ".png";
			// FileUtils.copyFile(scrFile, new File(filePath));
			// MediaEntityModelProvider mediaModel =
			// MediaEntityBuilder.createScreenCaptureFromPath( currentTime +
			// ".png").build();
			MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromBase64String(base64)
					.build();
			childlog.info(step, mediaModel);
			// childlog.addScreenCaptureFromPath(currentTime + ".png");
			logger.info("ScreenShot taken on " + driver + "for step " + step);
			// RunDetails.insertActionsIntoDB(RunDetails.getScenarioSeqonRunID(),step,dataInput,filePath);
		} catch (Throwable t) {
			logger.error("Error occured " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}*/
	}
	
	public static void takeScreenshot() {
		Reporter reporter = getCurrentReporter();
		if(MB_Actions.mobileDriverForScreenshot != null && IB_Actions.driverForScreenshot == null)
			reporter.takeScreenshot(MB_Actions.mobileDriverForScreenshot,currentStep,"");
		else if(IB_Actions.driverForScreenshot != null && MB_Actions.mobileDriverForScreenshot == null)
			reporter.takeScreenshot(IB_Actions.driverForScreenshot,currentStep,"");
		else if(MB_Actions.mobileDriverForScreenshot != null && IB_Actions.driverForScreenshot != null) {
			reporter.takeScreenshot(MB_Actions.mobileDriverForScreenshot,currentStep,"");
			reporter.takeScreenshot(IB_Actions.driverForScreenshot,currentStep,"");
		}
	}

	private static String img2Text(String file) {
		logger.info("Converting Image to String to embed in the report");
		String base64 = "";
		try {
			InputStream iSteamReader = new FileInputStream(file);
			byte[] imageBytes = IOUtils.toByteArray(iSteamReader);
			base64 = Base64.encodeBase64String(imageBytes);
			// System.out.println(base64);
		} catch (Throwable t) {
			logger.error("Error while converting image to string");
			Config.gracefulEnd(t, logger);
		}
		return "data:image/png;base64," + base64;
	}

	private class ReporterActions extends Thread {

		String step,type,dataInput,base64;
		AppiumDriver driver;
		WebDriver webdriver;

		public ReporterActions(String step,String dataInput,AppiumDriver driver,WebDriver webDriver,String type) {
			this.step = step;
			this.dataInput = dataInput;
			this.driver = driver;
			this.webdriver = webDriver;
			this.type=type;
		}

		@Override
		public void run() {

			logger.info("Async call to take screenShot started...");

			if(type.equalsIgnoreCase("mobile")) {

				currentTime = System.currentTimeMillis();
				try {
					base64 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
					String filePath = Config.SCREENSHOTS_PATH + currentTime + ".png";
					MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromBase64String(base64)
							.build();
					childlog.info(step, mediaModel);
					logger.info("ScreenShot taken on " + driver + "for step " + step);
				} catch (Throwable t) {
					logger.error("Error occured " + t.getLocalizedMessage());
					Config.gracefulEnd(t, logger);
				}
			}else if(type.equalsIgnoreCase("web")) {

				currentTime = System.currentTimeMillis();
				try {
					base64 = ((TakesScreenshot) webdriver).getScreenshotAs(OutputType.BASE64);
					String filePath = Config.SCREENSHOTS_PATH + currentTime + ".png";
					MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromBase64String(base64)
							.build();
					childlog.info(step, mediaModel);
					logger.info("ScreenShot taken on " + driver + "for step " + step);
				} catch (Throwable t) {
					logger.error("Error occured " + t.getLocalizedMessage());
					Config.gracefulEnd(t, logger);
				}

			}
			if(!Config.LOCAL_RUN) {
				String stepSeqId = RunDetails.getStepSeqonScenarioSeq();
				RunDetails.insertActionsIntoDB(stepSeqId,step,dataInput,base64);
				logger.info("Async call to save screenshot completed");
			}

		}

	}


}