package com.dbs.commons;

import java.io.*;
import java.util.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class FileOps {

	public boolean saveToFile(String str) {

		try {
			File newTextFile = new File("C:/IBID/responsefile.txt");
			FileWriter fw = new FileWriter(newTextFile);
			fw.write(str);
			fw.close();


		} catch (IOException iox) {
			//do stuff with exception
			iox.printStackTrace();
		}
		return true;
	}

	public HashMap<String, AccountDetails> formatToFile(String str) {
		List<String> list = new ArrayList<String>();
		HashMap<String, AccountDetails> accounts = new HashMap<String, AccountDetails>();
		
		try {
			
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
		/*	StringBuilder xmlStringBuilder = new StringBuilder();
			xmlStringBuilder.append(str);
			ByteArrayInputStream input = new ByteArrayInputStream(xmlStringBuilder.toString().getBytes("UTF-8"));*/
			  FileInputStream fis = new FileInputStream(str);
			Document doc = builder.parse(fis);
			doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			list.add("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("GenUnifiedAcctsDtls");
			System.out.println("----------------------------");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				//System.out.println("\nCurrent Element :" + nNode.getNodeName());
				AccountDetails adtls = new AccountDetails();
				String AccountsKey = null;
				list.add("\nCurrent Element :" + nNode.getNodeName());
			//	System.out.println(nNode.getChildNodes().item(0).getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					int sizeofSaleDtls = eElement.getChildNodes().item(0).getChildNodes().getLength();
					int sizeofSaleChannelDtls = eElement.getChildNodes().item(1).getChildNodes().getLength();
				//	System.out.println("Size of SaleDtls "+sizeofSaleDtls);
				//	System.out.println("Size of SaleDtls "+sizeofSaleChannelDtls);
					
					for (int i = 0;i<sizeofSaleDtls;i++) {
						//System.out.println(eElement.getChildNodes().item(0).getChildNodes().item(i).getNodeName()+" :: "+eElement.getChildNodes().item(0).getChildNodes().item(i).getNodeValue());
						//System.out.println(eElement.getElementsByTagName(eElement.getChildNodes().item(0).getChildNodes().item(i).getNodeName()).item(0).getTextContent());
						String key = eElement.getChildNodes().item(0).getChildNodes().item(i).getNodeName();
						//String value = 	( eElement.getElementsByTagName(key).item(0)).getTextContent();	
						String value= eElement.getElementsByTagName(key).item(0).getNodeValue().toString();
						//System.out.println(key+"::"+value);
						
						switch (key) {
						case "AcctId":
							AccountsKey = value.substring(5).trim();
							adtls.setAcctId(value);
							System.out.println("AccountKey "+AccountsKey);
							break;
						case "IsMultiCurrAcct":
							adtls.setIsMultiCurrAcct(value);
							//System.out.println("AvailableBal  "+value);
							break;
						case "ProductCategory":
							adtls.setProductCategory(value);
							//System.out.println("LedgerBal "+value);
							break;
						case "ProductCode":
							adtls.setProductCode(value);
							//System.out.println("Currency "+value);
							break;
							
						case "AcctName":
							adtls.setAcctName(value);
							//System.out.println("Currency "+value);
							break;
						case "LedgerBal":
							adtls.setLedgerBal(value);
							//System.out.println("Currency "+value);
							break;
						case "AvailBal":
							adtls.setAvailBal(value);
							//System.out.println("Balance :: "+value);
							//System.out.println("Currency "+value);
							break;
						case "BankCode":
							adtls.setBankCode(value);
							//System.out.println("Currency "+value);
							break;
						case "SAcctStatus":
							adtls.setSAcctStatus(value);
							//System.out.println("Currency "+value);
							break;
						case "SchemeName":
							adtls.setSchemeName(value);
							//System.out.println("Currency "+value);
							break;
						case "MultiCcyAcctID":
							adtls.setMultiCcyAcctID(value);
							//System.out.println("Currency "+value);
							break;
							
						}
						
					}
					
					for (int j = 0;j<sizeofSaleChannelDtls;j++) {
						//System.out.println(eElement.getChildNodes().item(1).getChildNodes().item(j).getNodeName()+" :: "+eElement.getChildNodes().item(1).getChildNodes().item(j).getNodeValue());
						//System.out.println(eElement.getElementsByTagName(eElement.getChildNodes().item(0).getChildNodes().item(j).getNodeName()).item(0).getTextContent());
						String key = eElement.getChildNodes().item(1).getChildNodes().item(j).getNodeName();
						//String value = 	eElement.getElementsByTagName(key).item(0).getTextContent();
						
						String value= eElement.getElementsByTagName(key).item(0).getNodeValue().toString();
						
						//System.out.println(key+"::"+value);
					
						switch (key) {
						case "AcctCurrCode":
							adtls.setAcctCurrCode(value);
							//System.out.println("AccountNumber "+value);
							//System.out.println("Currency Code :: "+value);
							break;
						case "AcctOpeningDt":
							adtls.setAcctOpeningDt(value);
							//System.out.println("AvailableBal  "+value);
							break;
						case "ModeOfOperation":
							adtls.setModeOfOperation(value);
							//System.out.println("LedgerBal "+value);
							break;
						
						}
					
					}
					
					
					
					
			
					/*System.out.println(eElement.getChildNodes().item(temp).getChildNodes().item(sizeofSaleDtls).getNodeName());
					System.out.println(eElement.getChildNodes().item(temp).getChildNodes().item(sizeofSaleChannelDtls).getNodeName());*/
					
					
					
					//eElement.getElementsByTagName("AcctId").item(0).getTextContent();
					
					
					
					
					
					/*
					System.out.println("AccountId : " 
							+ eElement
							.getElementsByTagName("AcctId")
							.item(0)
							.getTextContent());
					System.out.println("Product Category : " 
							+ eElement
							.getElementsByTagName("ProductCategory")
							.item(0)
							.getTextContent());
					System.out.println("Product Code : " 
							+ eElement
							.getElementsByTagName("ProductCode")
							.item(0)
							.getTextContent());
					System.out.println("Avail Balance : " 
							+ eElement
							.getElementsByTagName("AvailBal")
							.item(0)
							.getTextContent());
					System.out.println("Scheme Name : " 
							+ eElement
							.getElementsByTagName("SchemeName")
							.item(0)
							.getTextContent());
					System.out.println("Currency : " 
							+ eElement
							.getElementsByTagName("AcctCurrCode")
							.item(0)
							.getTextContent());
					System.out.println("Account Status : " 
							+ eElement
							.getElementsByTagName("SAcctStatus")
							.item(0)
							.getTextContent());*/
				}
				
				accounts.put(AccountsKey, adtls);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accounts;
	}

	public void updateCIFinRequest(String CIF) {
		
		System.out.println("Updating the CIF in BalXML :: " +CIF);
		
		try {
			File file = new File("C:\\IBID\\finServices\\src\\test\\java\\digiSuite\\finacle\\payload\\BalRqst.xml");
			String currentLine = "";
			String formattedXMl="";
		BufferedReader br = new BufferedReader(new FileReader(file));
		while((currentLine = br.readLine())!=null) {
			formattedXMl = formattedXMl+currentLine.replace("$CIF", CIF);
		}
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write(formattedXMl);
		bw.flush();
		
		bw.close();
		br.close();
		}catch(Throwable t) {
			
		}
	}
	
	   public void resetBalReqXml(){

		   System.out.println("Resetting the BalXml file....");
		   
		      try{

		      File file = new File("C:\\IBID\\finServices\\src\\test\\java\\digiSuite\\finacle\\payload\\BalRqst.xml");
		      BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		      String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
		            "<FIXML xmlns=\"http://www.finacle.com/fixml\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.finacle.com/fixml executeFinacleScript.xsd\">\n" +
		            "   <Header>\n" +
		            "      <RequestHeader>\n" +
		            "         <MessageKey>\n" +
		            "            <RequestUUID>#(msgUID)</RequestUUID>\n" +
		            "            <ServiceRequestId>executeFinacleScript</ServiceRequestId>\n" +
		            "            <ServiceRequestVersion>1</ServiceRequestVersion>\n" +
		            "            <ChannelId>DIB</ChannelId>\n" +
		            "         </MessageKey>\n" +
		            "         <RequestMessageInfo>\n" +
		            "            <BankId>01</BankId>\n" +
		            "            <TimeZone />\n" +
		            "            <EntityId />\n" +
		            "            <EntityType />\n" +
		            "            <ArmCorrelationId />\n" +
		            "            <MessageDateTime>2016-01-16T11:30:12.227</MessageDateTime>\n" +
		            "         </RequestMessageInfo>\n" +
		            "      </RequestHeader>\n" +
		            "   </Header>\n" +
		            "   <Body>\n" +
		            "      <executeFinacleScriptRequest>\n" +
		            "         <ExecuteFinacleScriptInputVO>\n" +
		            "            <requestId>intp4ribCAINmn01.scr</requestId>\n" +
		            "         </ExecuteFinacleScriptInputVO>\n" +
		            "         <executeFinacleScript_CustomData>\n" +
		            "            <CustAcctInqRq>\n" +
		            "               <CustId>$CIF</CustId>\n" +
		            "            </CustAcctInqRq>\n" +
		            "         </executeFinacleScript_CustomData>\n" +
		            "      </executeFinacleScriptRequest>\n" +
		            "   </Body>\n" +
		            "</FIXML>";

		      bw.write(xml);
		      bw.flush();
		      bw.close();

		   }catch(Throwable t){
		      t.printStackTrace();
		      }
		   }


	
	public static void main(String [] args) {
		
		//updateCIFinRequest("1234567");
	}

}
