package com.dbs.commons;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import com.dbs.actions.MB_Actions;
import com.dbs.config.Config;

public class POMCreater {
	public static String fs=File.separator;	
	private static final String strMBMethodTemplate = "\tpublic MB_Actions <objectName>() throws Throwable{\r\n"
			+ "		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();\r\n"
			+ "		try {\r\n"
			+ "			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),\r\n"
			+ "					pagename, objectName,\"\");\r\n"
			+ "			logger.info(pagename + \">>\" + objectName + \">>Object found and returned\");\r\n"
			+ "		} catch (Throwable e) {\r\n"
			+ "			logger.error(\"Exception in returning the element of page : \"+pagename+ \" >>\" + objectName + \">>Object not found\"\r\n"
			+ "					+ e.getLocalizedMessage());\r\n" + "			Config.gracefulEnd(e, logger);\r\n"
			+ "			reporter.currentStep = \"Action can not be performed at the page : \"+pagename+ \">> on element :\" + objectName + \" due to Object is \"+e.getLocalizedMessage();\r\n" 
			+ "			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();\r\n"
			+ "			Reporter.takeScreenshot();\r\n"
			+ "           return new MB_Actions(null,elementFinder.getElementProperty(), DriverManagerFactory.getMobileManager().getMobileDriver());\r\n"
			+ "		}\r\n"
			+ "		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());\r\n"
			+ "	}\r\n\r\n";

	private static final String strIBMethodTemplate = "\tpublic IB_Actions <objectName>() throws Throwable{\r\n"
			+ "		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();\r\n"
			+ "		try {\r\n"
			+ "			element = elementFinder.verify_IB_Element(DriverManagerFactory.getManager().getWebDriver(),\r\n"
			+ "					pagename, objectName,\"\");\r\n"
			+ "			logger.info(pagename + \">>\" + objectName + \">>Object found and returned\");\r\n"
			+ "		} catch (Throwable e) {\r\n"
			+ "			logger.error(\"Exception in returning the element of page : \"+pagename + \">>\" + objectName + \">>Object not found\"\r\n"
			+ "					+ e.getLocalizedMessage());\r\n" + "			Config.gracefulEnd(e, logger);\r\n"
			+ "			reporter.currentStep = \"Action can not be performed at the page : \"+pagename+ \">> on element :\" + objectName + \" due to Object is \"+ e.getLocalizedMessage();\r\n" 
			+ "			IB_Actions.driverForScreenshot = DriverManagerFactory.getManager().getWebDriver();\r\n"
			+ "			Reporter.takeScreenshot();\r\n"
			+ "           return new IB_Actions(null, elementFinder.getElementProperty(),DriverManagerFactory.getManager().getWebDriver());\r\n"
			+ "		}\r\n"
			+ "		return new IB_Actions(element, DriverManagerFactory.getManager().getWebDriver());\r\n"
			+ "	}\r\n\r\n";

	private static final String strIBListMethodTemplate = "\tpublic List<WebElement> <objectName>() throws Throwable {\r\n"
			+ "		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName();\r\n"
			+ "		try {\r\n"
			+ "			elementsList = elementFinder.verify_IB_Elements(DriverManagerFactory.getManager().getWebDriver(), pagename, objectName,\"\");\r\n"
			+ "			logger.info(pagename+\">>\"+objectName+\">>Object found and returned\");\r\n"
			+ "		} catch (Throwable e) {\r\n"
			+ "			logger.error(\"Exception in returning the element of page : \"+pagename+\">>\"+objectName+\">>Object not found\");\r\n"
			+ "			reporter.currentStep = \"Action can not be performed at the page : \"+pagename+ \">> on element :\" + objectName + \" due to Object is \"+ e.getLocalizedMessage();\r\n"
			+ "			IB_Actions.driverForScreenshot = DriverManagerFactory.getManager().getWebDriver();\r\n"
			+ "			Reporter.takeScreenshot();\r\n"			
			+ "			return null;\r\n" + "		}\r\n" + "			return this.elementsList;\r\n" + "\r\n"
			+ "	}\r\n\r\n";
	
	private static final String strMBListMethodTemplate = "\tpublic List<MobileElement> <objectName>() throws Throwable {\r\n"
			+ "		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName();\r\n"
			+ "		try {\r\n"
			+ "			elementsList = elementFinder.verify_MB_Elements(DriverManagerFactory.getMobileManager().getMobileDriver(), pagename, objectName,\"\");\r\n"
			+ "			logger.info(pagename+\">>\"+objectName+\">>Object found and returned\");\r\n"
			+ "		} catch (Throwable e) {\r\n"
			+ "			logger.error(\"Exception in returning the element of page : \"+pagename+\">>\"+objectName+\">>Object not found\");\r\n"
			+ "			reporter.currentStep = \"Action can not be performed at the page : \"+pagename+ \">> on element :\" + objectName + \" due to Object is \"+ e.getLocalizedMessage();\r\n"
			+ "			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();\r\n"
			+ "			Reporter.takeScreenshot();\r\n"
			+ "			return null;\r\n" + "		}\r\n" + "			return this.elementsList;\r\n" + "\r\n"
			+ "	}\r\n\r\n";

	private static final String strMBVariableTextMethod = "\tpublic MB_Actions <objectName>(String textToReplace) throws Throwable{\r\n"
			+ "		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName().trim();\r\n"
			+ "		try {\r\n"
			+ "			element = elementFinder.verify_MB_Element(DriverManagerFactory.getMobileManager().getMobileDriver(),\r\n"
			+ "					pagename, objectName,textToReplace);\r\n"
			+ "			logger.info(pagename + \">>\" + objectName + \">>Object found and returned\");\r\n"
			+ "		} catch (Throwable e) {\r\n"
			+ "			logger.error(\"Exception in returning the element of page : \" +pagename +  \" >>\" + objectName + \">>Object not found\"\r\n"
			+ "					+ e.getLocalizedMessage());\r\n" + "			Config.gracefulEnd(e, logger);\r\n"
			+ "			reporter.currentStep = \"Action can not be performed at the page : \"+pagename+ \">> on element :\" + objectName + \" due to Object is \"+ e.getLocalizedMessage();\r\n" 
			+ "			MB_Actions.mobileDriverForScreenshot = DriverManagerFactory.getMobileManager().getMobileDriver();\r\n"
			+ "			Reporter.takeScreenshot();\r\n"
			+ "           return new MB_Actions(null, elementFinder.getElementProperty(),DriverManagerFactory.getMobileManager().getMobileDriver());\r\n"
			+ "		}\r\n"
			+ "		return new MB_Actions(element, DriverManagerFactory.getMobileManager().getMobileDriver());\r\n"
			+ "	}\r\n\r\n";

	private static final String strIBVariableTextMethod = "\tpublic IB_Actions <objectName>(String textToReplace) throws Throwable{\r\n"
			+ "		String objectName = Thread.currentThread().getStackTrace()[1].getMethodName();\r\n"
			+ "		try {\r\n"
			+ "			element = elementFinder.verify_IB_Element(DriverManagerFactory.getManager().getWebDriver(),pagename,objectName,textToReplace);\r\n"
			+ "		} catch (Throwable e) {\r\n"
			+ "           return new IB_Actions(null,elementFinder.getElementProperty(), DriverManagerFactory.getManager().getWebDriver());\r\n"
			+ "		}\r\n" + "\r\n"
			+ "		return new IB_Actions(element,DriverManagerFactory.getManager().getWebDriver());\r\n"
			+ "	}\r\n\r\n";

	private static final String strIBPagesTemplate = "package com.dbs."+ Config.COUNTRY.toLowerCase()+".ib.pages;\r\n" 
			+ "\r\n" 
			+ "import java.util.List;\r\n" + "\r\n" + "import org.apache.log4j.Logger;\r\n"
			+ "import org.openqa.selenium.WebElement;\r\n" + "\r\n" + "import com.dbs.actions.IB_Actions;\r\n"
			+ "import com.dbs.commons.ElementFinder;\r\n" + "import com.dbs.commons.Reporter;\r\n"
			+ "import com.dbs.config.Config;\r\n" + "import com.dbs.drivers.DriverManagerFactory;\r\n" + "\r\n"
			+ "public class <className> {\r\n" + "	\r\n"
			+ "	private static final Logger logger=Logger.getLogger(<className>.class); \r\n"
			+ "	WebElement element ;\r\n" + "	String pagename = this.getClass().getSimpleName();\r\n"
			+ "	String text = \"\";\r\n" + "	List<WebElement> elementsList;\r\n"
			+ "	ElementFinder elementFinder = new ElementFinder();\r\n" + "	Reporter reporter = Reporter.getCurrentReporter();\r\n"
			+ "	public IB_Actions elementBasedOnText(String objectName, String text) throws Throwable {\r\n"
			+ "		try {\r\n"
			+ "			element = elementFinder.verify_IB_Element(DriverManagerFactory.getManager().getWebDriver(),pagename,objectName,\"\");\r\n"
			+ "			logger.info(pagename+\">>\"+objectName+\">>Object found and returned\");\r\n"
			+ "		} catch (Throwable e) {\r\n"
			+ "			logger.error(\"Exception in returning the element of page : \"+pagename+\">>\"+objectName+\">>Object not found\");\r\n"
			+ "           return new IB_Actions(element,null, DriverManagerFactory.getManager().getWebDriver());\r\n"
			+ "		}\r\n" + "\r\n"
			+ "		return new IB_Actions(element,DriverManagerFactory.getManager().getWebDriver());\r\n" + "	}\r\n";

	private static final String strMBPagesTemplate = "package com.dbs."+ Config.COUNTRY.toLowerCase() +".mb.pages;\r\n" 
			+ "\r\n" + "import org.apache.log4j.Logger;\r\n" + "\r\n"
			+ "import java.util.List;\r\n" + "\r\n"
			+ "import com.dbs.actions.MB_Actions;\r\n"
			+ "import com.dbs.commons.ElementFinder;\r\n" + "import com.dbs.commons.Reporter;\r\n"
			+ "import com.dbs.config.Config;\r\n" + "import com.dbs.drivers.DriverManagerFactory;\r\n" + "\r\n"
			+ "import io.appium.java_client.MobileElement;\r\n" + "\r\n" + "\r\n" + "public class  <className> {\r\n"
			+ "\r\n" + "	private static final Logger logger=Logger.getLogger( <className>.class); \r\n"
			+ "	String pagename = this.getClass().getSimpleName();\r\n" + "	MobileElement element;\r\n" + "    List<MobileElement> elementsList;\r\n"			
			+ "	ElementFinder elementFinder = new ElementFinder();\r\n" + "	Reporter reporter = Reporter.getCurrentReporter();\r\n"
			+ "	\r\n" + "	\r\n" + "	public MB_Actions getMBActions() throws Throwable{\r\n"
			+ "        return new MB_Actions(null, DriverManagerFactory.getMobileManager().getMobileDriver());\r\n"
			+ "	}\r\n" + "\r\n";

	String strPageName = "", strMethod = "";
	String strPageObjectsCode = null;
	ConnectDB conDB = new ConnectDB();
	static POMCreater pom = new POMCreater();
	BufferedWriter bw;
	FileWriter fw;
	File dir;
	List<String> pageObjs;

	public static void main(String[] args) throws IOException {
		try {
			Config.Logger();
			String[] choices = { "Create_MB_POM", "Create_IB_POM", "Create_Both" };
			String input = (String) JOptionPane.showInputDialog(null, "Select the operation type", "DropDown",
					JOptionPane.QUESTION_MESSAGE, null, choices, choices[0]);
			switch (input) {
			case ("Create_MB_POM"):
				if (pom.createPOMforMB())
					JOptionPane.showMessageDialog(null, "POM created successfully!!", "Generate Page Object for MB!",
							JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null, "Gloabl Util and POM created successfully!!",
							"Generate Page Object MB!", JOptionPane.INFORMATION_MESSAGE);
				break;
			case ("Create_IB_POM"):
				if (pom.createPOMforIB())
					JOptionPane.showMessageDialog(null, "POM created successfully!!", "Generate Page Object for IB!",
							JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null, "POM creation failed!!", "Generate Page Object  IB!",
							JOptionPane.INFORMATION_MESSAGE);
				break;

			case ("Create_Both"):
				if (pom.createPOMforIB() && pom.createPOMforMB())
					JOptionPane.showMessageDialog(null, "POM created successfully for MB&IB!!",
							"Generate Page Object & Global Util Code!", JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null, "POM creation failed!!", "Generate Page Object  IB!",
							JOptionPane.INFORMATION_MESSAGE);
				break;
			case (""):
				JOptionPane.showMessageDialog(null, "Invalid Option : Exiting...");
				break;
			}
		} catch (Throwable e) {
			JOptionPane.showMessageDialog(null, "Invalid Option : Exiting...");
		}
	}

	public boolean createPOMforIB() {
		boolean pomStatus = false;
		//dir = new File(Config.IB_POM_DIRECTORY+fs+Config.COUNTRY.toLowerCase()+ fs +"ib"+fs+"pages");
		dir = new File("src"+fs+"test"+fs+"java"+fs+"com"+fs+"dbs"+ fs+Config.COUNTRY.toLowerCase()+fs+"ib"+fs+"pages");
		pageObjs = new ArrayList<String>();
		String sql1 = "select distinct Page_Name from " + Config.DB_IB_REPO_TABLE;
		String sql2 = "";
		try {
			dir.mkdirs();
			ConnectDB.connectToDB();
			ResultSet rs1 = ConnectDB.execute(sql1);
			ResultSet rs2 = null;
			while (rs1.next()) {
				pageObjs.add(rs1.getString(1));
			}
			System.out.println("Page Objects : " + pageObjs.size());
			for (int i = 0; i < pageObjs.size(); i++) {
				strPageName = pageObjs.get(i);
				strPageObjectsCode = strIBPagesTemplate.replace("<className>", strPageName);
				sql2 = "select page_Name, object_NAME, isdynamic, Description from " + Config.DB_IB_REPO_TABLE
						+ " where Page_name=\"" + strPageName + "\"";
				rs2 = ConnectDB.execute(sql2);
				String elementName = "";
				String varText = "";
				File pomFile = new File(dir+fs+strPageName + ".java");
				while (rs2.next()) {
					elementName = rs2.getString("object_NAME");
					varText = rs2.getString("isDYNAMIC");
					if (elementName.equalsIgnoreCase("")) {
						System.out.println("Element name is null in DB for Page : " + strPageName);

					} else if (elementName.startsWith("wbLst")) {
						strMethod = strIBListMethodTemplate.replace("<objectName>", elementName);
					} else if (varText.equalsIgnoreCase("Y")) {
						strMethod = strIBVariableTextMethod.replace("<objectName>", elementName);
					} else {
						strMethod = strIBMethodTemplate.replace("<objectName>", elementName);
					}
					strPageObjectsCode = strPageObjectsCode + strMethod;
				}

				strPageObjectsCode = strPageObjectsCode + "}\n";
				strPageObjectsCode = strPageObjectsCode.replace("<className>", strPageName);

				if (strPageObjectsCode.contains("<wblstImport>"))
					strPageObjectsCode = strPageObjectsCode.replace("<wblstImport>", "");
				// pomFile = POMDIR + File.separator + pomName;
				fw = new FileWriter(pomFile);
				bw = new BufferedWriter(fw);
				bw.write(strPageObjectsCode);
				bw.flush();
			}
			rs1.close();
			rs2.close();
			if (/* createGlobalUtilforIB(pageObjs) */true)
				pomStatus = true;
		} catch (SQLException e) {
			e.printStackTrace();
			pomStatus = false;
		} catch (Exception e) {
			e.printStackTrace();
			pomStatus = false;
		} finally {
			try {
				ConnectDB.close();
				bw.close();
				fw.close();
			} catch (Exception e) {
				e.printStackTrace();
				return pomStatus;
			}
		}
		return pomStatus;
	}

	public boolean createPOMforMB() {

		boolean pomStatus = false;
		String sql1 = "select distinct Page_Name from " + Config.DB_MB_REPO_TABLE;
		String sql2 = "";
		//dir = new File(Config.MB_POM_DIRECTORY+fs+Config.COUNTRY.toLowerCase()+fs+"mb"+fs+"pages");
		dir = new File("src"+fs+"test"+fs+"java"+fs+"com"+fs+"dbs"+fs+Config.COUNTRY.toLowerCase()+fs+"mb"+fs+"pages");
		
		pageObjs = new ArrayList<String>();
		try {
			dir.mkdirs();
			ConnectDB.connectToDB();
			ResultSet rs1 = ConnectDB.execute(sql1);
			ResultSet rs2 = null;
			while (rs1.next()) {
				pageObjs.add(rs1.getString(1));
			}
			System.out.println("Page Objects : " + pageObjs.size());
			for (int i = 0; i < pageObjs.size(); i++) {
				strPageName = pageObjs.get(i);
				strPageName = strPageName.substring(0, 1).toUpperCase() + strPageName.substring(1);
				strPageObjectsCode = strMBPagesTemplate.replace("<className>", strPageName);
				sql2 = "select * from " + Config.DB_MB_REPO_TABLE + " where Page_name=\"" + strPageName + "\"";
				rs2 = ConnectDB.execute(sql2);
				String elementName = "";
				String varText = ""; 
				File pomFile = new File(dir+fs+ strPageName + ".java");
				while (rs2.next()) {
					elementName = rs2.getString("object_NAME");
					varText = rs2.getString("isDYNAMIC");
					if (elementName.equalsIgnoreCase("")) {
						System.out.println("Element name is null in DB for Page : " + strPageName);
					} else if (elementName.startsWith("wbLst")){
						strMethod = strMBListMethodTemplate.replace("<objectName>", elementName);
					} else if (varText.equalsIgnoreCase("Y")) {
						strMethod = strMBVariableTextMethod.replace("<objectName>", elementName);
					} else {
						strMethod = strMBMethodTemplate.replace("<objectName>", elementName);
					}
					strPageObjectsCode = strPageObjectsCode + strMethod;
				}
				strPageObjectsCode = strPageObjectsCode + "}\n";
				strPageObjectsCode = strPageObjectsCode.replace("<className>", strPageName);

				if (strPageObjectsCode.contains("<wblstImport>"))
					strPageObjectsCode = strPageObjectsCode.replace("<wblstImport>", "");
				fw = new FileWriter(pomFile);
				bw = new BufferedWriter(fw);
				bw.write(strPageObjectsCode);
				bw.flush();
			}
			rs1.close();
			rs2.close();
			if (/* createGlobalUtilforMB(pageObjs) */true)
				pomStatus = true;
		} catch (SQLException e) {
			e.printStackTrace();
			pomStatus = false;
		} catch (Exception e) {
			e.printStackTrace();
			pomStatus = false;
		} finally {
			try {
				ConnectDB.close();
				bw.close();
				fw.close();
			} catch (Exception e) {
				e.printStackTrace();
				return pomStatus;
			}
		}
		return pomStatus;
	}

}