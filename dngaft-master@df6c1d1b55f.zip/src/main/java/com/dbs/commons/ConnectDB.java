package com.dbs.commons;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;
import com.dbs.config.Config;


public class ConnectDB {
	final static String JDBC_DRIVER = Config.DB_AUTOMATION_DRIVER;
	final static String DB_URL = Config.DB_AUTOMATION_CONNECTION;
	
	//  Database credentials
	final static String USER = Config.DB_AUTOMATION_USER;
	final static String PASS = Config.DB_AUTOMATION_PASSWORD;
	public static ResultSet rs ;
	public static Connection conn,reportCnctn ;
	public static Statement stmt ;
	
	// Reporting connection
	final static String DB_REPO_URL = Config.DB_REPORTING_CONNECTION;	
	final static String REPO_USER = Config.DB_REPORTING_USER;
	final static String REPO_PASS = Config.DB_REPORTING_PASSWORD;	
	
	private static final Logger logger=Logger.getLogger(ConnectDB.class);
/*	public ResultSet createDBConnection(String sql){
	    try {
	        Class.forName(JDBC_DRIVER);
	        conn = DriverManager.getConnection(DB_URL, USER, PASS);
	        stmt = conn.createStatement();
	        rs = stmt.executeQuery(sql);
	        conn.close();
	    }catch (Throwable t) {
	    	Config.gracefulEnd(t,logger);
		}
	    return rs;
	}*/
	
	public static Connection connectToDB() throws Exception{
		
		try{
			if ((JDBC_DRIVER == null) || (DB_URL == null)) {
				logger.error("'para.mter driver or url is null could not connect to database. driver|url" + JDBC_DRIVER + "'|" + DB_URL);
				throw new Exception("'para.mter driver or url is null could not connect to database. driver|url" + JDBC_DRIVER + "'|" + DB_URL);
			}
			Class.forName (JDBC_DRIVER).newInstance ();
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			logger.info(":: Connected to Database : " + DB_URL);
			if(!Config.LOCAL_RUN) {
				//reportCnctn = DriverManager.getConnection(DB_REPO_URL, REPO_USER, REPO_PASS);
				//logger.info(":: Connected to Database : " + DB_REPO_URL);
			}
			conn.setAutoCommit (false);
			return conn;
		}catch (Throwable t) {
			logger.error("Exception in connectToDB "+t.getLocalizedMessage());
			Config.gracefulEnd(t,logger);
			throw new Exception("Exception while connecting to database using " + JDBC_DRIVER + "'|" + DB_URL);
		}
	}
	
	public static ResultSet execute(String sql){
		ResultSet rs =null;
		Statement stmt = null;
		try{
			stmt = conn.createStatement();
			logger.info(":: Running query -" + sql);
			rs = stmt.executeQuery(sql);
		}catch (Throwable t) {
			logger.error("Exception while running query:: "+sql+ t.getLocalizedMessage());
			Config.gracefulEnd(t,logger);
		}
		return rs;
	}
	
	public static void close()	throws Exception{
		try{
			if (conn != null ) {
				conn.close();
				if(!Config.LOCAL_RUN)
					reportCnctn.close();
				logger.info(":: DB Connection closed ");
			}
		}catch (Throwable t) {
			logger.error("Exception while closing DBconnections"+ t.getLocalizedMessage());
			Config.gracefulEnd(t,logger);
		}
	}
	
	public static ResultSet saveResults(String sql){
		ResultSet rs =null;
		Statement stmt = null;
		try{
			stmt = reportCnctn.createStatement();
			logger.info(":: Running query to save Execution Results-" + sql);
			rs = stmt.executeQuery(sql);
		}catch (Throwable t) {
			logger.error("Exception occured :- " + t);
			logger.error("could not execute . driver|url" + JDBC_DRIVER + "'|" + DB_REPO_URL);
			Config.gracefulEnd(t,logger);
		}
		return rs;
	}
	
    
    public static void writeBlob(String stepSeq, String actioName, String actionInput,String filePath) {
        // update sql
       //String query="INSERT INTO `reportsdb`.`t_actions` (`action_name`, `action_input`, `action_output`, `resource_1`) VALUES ('', '', 'sdfdsfd', 'sdfdf', 'sdffds', 0x3300);";
    	
    	DataBaseActions dbBaseActions = new DataBaseActions();
   
    	logger.info("Creating Blob on "+filePath);
        	try
        	{
            File file = new File(filePath);
            FileInputStream input = new FileInputStream(file);
            logger.info("Reading file " + file.getAbsolutePath());
            logger.info("Store file in the database.");
            
            String query = "INSERT INTO `ib_reports`.`t_actions` (`step_seq`, `action_name`, `action_input`, `action_output`, `resource_1`, `resource_2`, `resource_3`) "
        			+ "VALUES ('"+stepSeq+"', '"+actioName+"', '"+actionInput+"', '"+""+"', 0x330000, 0x330000, 0x3300);";
            logger.info("Executing the query : " + "INSERT INTO `ib_reports`.`t_actions` (`step_seq`, `action_name`,"
            		+ " `action_input`, `action_output`, `resource_1`, `resource_2`, `resource_3`) "
        			+ "VALUES ('"+stepSeq+"', '"+actioName+"', '"+actionInput+"', '"+""+"', 0x330000, 0x330000, 0x3300);");
            dbBaseActions.executeUpdate(query);
           // pstmt.executeUpdate();
        } catch (FileNotFoundException e) {
        	logger.error("Exception occured"+e.getMessage());
            Config.gracefulEnd(e, logger);
        }
    }
	
}
