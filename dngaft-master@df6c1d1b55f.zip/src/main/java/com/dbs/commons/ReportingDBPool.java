package com.dbs.commons;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.mariadb.jdbc.MariaDbPoolDataSource;

import com.dbs.config.Config;

/**
 *
 * @author 
 */

public class ReportingDBPool {

	public static Connection connection = null;
	public static int connectionCount = 0;
	public static MariaDbPoolDataSource pool;
	private static final Logger logger=Logger.getLogger(ReportingDBPool.class);
	public  Connection getConnection() {

		try {

			if (pool == null) {
				
				// String driver = "com.mysql.jdbc.Driver";
				try {
					logger.info("Connecting to DB URL :: "+Config.DB_REPORTING_CONNECTION);
					String dbUrl = Config.DB_REPORTING_CONNECTION;
					String host = dbUrl.substring(dbUrl.indexOf("//")+2, dbUrl.lastIndexOf(":"));
					int port = Integer.parseInt(dbUrl.substring(dbUrl.lastIndexOf(":")+1, dbUrl.lastIndexOf("/")));
					String db= dbUrl.substring(dbUrl.lastIndexOf("/")+1);
					logger.info("Initializing pool with Host: "+host+", Port: "+port+", Database: "+db);
					pool = new MariaDbPoolDataSource(host,port,db);
					//pool = new MariaDbPoolDataSource(Config.DB_REPORTING_CONNECTION);
					//pool.setUrl(Config.DB_REPORTING_CONNECTION);
					pool.setUser(Config.DB_REPORTING_USER);
					pool.setPassword(Config.DB_REPORTING_PASSWORD);
					pool.setMaxPoolSize(30);
					pool.setMaxIdleTime(240);
//					/pool.setPoolName("ReportingDB Pool");
					pool.initialize();
					logger.info("\nDetails of pool \n"+ "DB NAME : "+pool.getDatabaseName() +"\nPOOL NAME :"+pool.getPoolName()+"\nSERVER NAME :"+pool.getServerName()
					+"\nPORT NUM : "+pool.getPortNumber()+"\nDB UserName :: "+pool.getUser()+"\nDB POOL SIZE :: "+pool.getMaxPoolSize()+"\nDB POOL :: "+pool.testGetPool());
					if (connection == null || connection.isClosed()) {
						System.out.println(" requeition CONNECTION WITH FIRST SERVER.");
						//connection = pool.getConnection(Config.REPORTS_USERNAME,Config.DB_REPORTING_PASSWORD);
						connection = pool.getConnection();
						connectionCount++;
					}
				} catch (SQLException e) {
					logger.error("***Connection Requisition*** Could not connect to the database msg :" + e.getMessage());
					System.out.println(
							"***Connection Requisition*** Could not connect to the database msg :" + e.getMessage());
					Config.gracefulEnd(e, logger);
				}
			} else {
				//connection = pool.getConnection(Config.REPORTS_USERNAME,Config.DB_REPORTING_PASSWORD);
				connection = pool.getConnection();
				connectionCount++;
			}
		} catch (Exception e) {
			logger.error("open connection exception" + e.getLocalizedMessage());
			System.out.println("open connection exception" + e);
			e.printStackTrace();
		}
		return connection;
	}

	public static void close(ResultSet c) {
		try {
			if (c != null) {
				c.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(Statement c) {
		try {
			if (c != null) {
				c.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(Connection c) {
		try {
			if (c != null) {
				c.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}