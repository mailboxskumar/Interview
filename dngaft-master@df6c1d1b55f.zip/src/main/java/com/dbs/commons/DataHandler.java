package com.dbs.commons;

import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

/**
 * @author nagendrapai
 * @version 1.0 Stores and retrieves the data required for test execution
 *          
 */

public class DataHandler {

	private static DataBaseActions dba = DataBaseActions.getDbActions();
	private static final Logger logger = Logger.getLogger(DataBaseActions.class);

	public static String retrieveData(String ScenarioId,String param_name) {
		String execSystem,dataValue=null,query = null,country = Config.COUNTRY.toLowerCase();

		try {

			if(DriverManagerFactory.getDriverData("RunTestOn").equalsIgnoreCase("MB") || DriverManagerFactory.getDriverData("RunTestOn").equalsIgnoreCase("BOTH"))
				execSystem = DriverManagerFactory.getDriverData("Device Name");
			else
				execSystem = DriverManagerFactory.getDriverData("Browser");
			
			query = "SELECT Param_value FROM "+country+"_testdata USE INDEX(Module_name) WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Execution_system = '"+execSystem+"' AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+param_name+"' AND Iteration_no = "+StepListener.getListener().getCurrentIteration()+";";
			
			/*Query for simple retrieval without Iteration and device Id
			query = "SELECT Param_value FROM "+country+"_testdata USE INDEX(Module_name) WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+param_name+"' AND Iteration_no = 1;";*/
	
			/*Query for Iteration and device specific data retrieval
			 * query = "SELECT Param_value FROM in_testdata USE INDEX(Module_name) WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Execution_system = '"+execSystem+"' AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+param_name+"' AND Iteration_no = "+StepListener.getCurrentIteration()+";";*/


			logger.info("Retrieving Test Data using DATAHANDLER by running Query: "+query);
			ResultSet rs = dba.execute(query);	

			while(rs.next()) {
				dataValue = rs.getString("Param_value");
				logger.info("Data is retrieved by DATAHANDLER: Param = "+param_name+" , Value = "+dataValue);
			}
		} catch (Throwable t) {
			logger.error("Exception occured while retrieving data using DATAHANDLER from DB with query :: "+query +"\n"+ t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}

		return dataValue;		
	}
	
	public static String retrieveGenericData(String ScenarioId,String param_name) {
		String execSystem,dataValue=null,query = null,country = Config.COUNTRY.toLowerCase();

		try {

			if(DriverManagerFactory.getDriverData("RunTestOn").equalsIgnoreCase("MB") || DriverManagerFactory.getDriverData("RunTestOn").equalsIgnoreCase("BOTH"))
				execSystem = DriverManagerFactory.getDriverData("Device Name");
			else
				execSystem = DriverManagerFactory.getDriverData("Browser");
			
			query = "SELECT Param_value FROM "+country+"_testdata USE INDEX(Module_name) WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+param_name+"'";
			
			/*Query for simple retrieval without Iteration and device Id
			query = "SELECT Param_value FROM "+country+"_testdata USE INDEX(Module_name) WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+param_name+"' AND Iteration_no = 1;";*/
	
			/*Query for Iteration and device specific data retrieval
			 * query = "SELECT Param_value FROM in_testdata USE INDEX(Module_name) WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Execution_system = '"+execSystem+"' AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+param_name+"' AND Iteration_no = "+StepListener.getCurrentIteration()+";";*/


			logger.info("Retrieving Test Data using DATAHANDLER by running Query: "+query);
			ResultSet rs = dba.execute(query);	

			while(rs.next()) {
				dataValue = rs.getString("Param_value");
				logger.info("Data is retrieved by DATAHANDLER: Param = "+param_name+" , Value = "+dataValue);
			}
		} catch (Throwable t) {
			logger.error("Exception occured while retrieving data using DATAHANDLER from DB with query :: "+query +"\n"+ t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}

		return dataValue;		
	}	

	public static void storeData(String ModuleName, String ScenarioId,String Param_name, String Param_value) {

		String execSystem,query = null,country = Config.COUNTRY.toLowerCase();
		boolean isDataInserted;

		if(DriverManagerFactory.getDriverData("RunTestOn").equalsIgnoreCase("MB") || DriverManagerFactory.getDriverData("RunTestOn").equalsIgnoreCase("BOTH"))
			execSystem = DriverManagerFactory.getDriverData("Device Name");
		else
			execSystem = DriverManagerFactory.getDriverData("Browser");

		try {

			if(retrieveData(ScenarioId, Param_name) == null) {
				query = "INSERT INTO "+country+"_testdata (Project_name,Execution_system,Module_name,Screen_name,Scenario_id,Param_name,Param_value,Last_updated_by) VALUES('"+Config.JIRA_PROJECT+"', '"+execSystem+"', '"+ModuleName+"', 'InsertValidScreenNameHere', '"+ScenarioId+"', '"+Param_name+"', '"+Param_value+"', '"+Config.DB_AUTOMATION_USER+"');";
				/* Query for plain insertion
				 * query = "INSERT INTO "+country+"_testdata (Project_name,Execution_system,Iteration_no,Module_name,Screen_name,Scenario_id,Param_name,Param_value,Last_updated_by) VALUES('"+Config.JIRA_PROJECT+"', 'DefaultValue', 1,'"+ModuleName+"', 'InsertValidScreenNameHere', '"+ScenarioId+"', '"+Param_name+"', '"+Param_value+"', '"+Config.DB_AUTOMATION_USER+"');";*/
				/*Query for Iteration and device based data insertion 
				 * query = "INSERT INTO in_testdata (Project_name,Execution_system,Iteration_no,Module_name,Screen_name,Scenario_id,Param_name,Param_value,Last_updated_by) VALUES('"+Config.JIRA_PROJECT+"', '"+execSystem+"', "+StepListener.getCurrentIteration()+", '"+ModuleName+"', 'InsertValidScreenNameHere', '"+ScenarioId+"', '"+Param_name+"', '"+Param_value+"', '"+Config.DB_AUTOMATION_USER+"');";*/
				isDataInserted = true;
			}
			else {
				query = "UPDATE "+country+"_testdata SET Param_value = '"+Param_value+"' WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Execution_system = '"+execSystem+"' AND Iteration_no = 1 AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+Param_name+"';";
				/*Query for Iteration and device based data updation
				 *query = "UPDATE in_testdata SET Param_value = '"+Param_value+"' WHERE Project_name = '"+Config.JIRA_PROJECT+"' AND Execution_system = '"+execSystem+"' AND Iteration_no = "+StepListener.getCurrentIteration()+" AND Scenario_id = '"+ScenarioId+"' AND Param_name = '"+Param_name+"';"; 
				 */				
				isDataInserted = false;
			}

			ResultSet rs = dba.execute(query);

			if(isDataInserted)
				logger.info("Data INSERTED successfully by DATAHANDLER using Query: "+query);
			else if(isDataInserted == false)
				logger.info("Data UPDATED successfully by DATAHANDLER using Query: "+query);
			else
				logger.info("Data NOT STORED using Query: "+query);

		} catch (Throwable t) {
			logger.error("Exception occured while storing data using DATAHANDLER in DB using query :: "+query +"\n"+ t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}

	}

/*	public static void main(String[] args) {
		Config.Logger();
		Config.getDeviceData();
		DataHandler.storeData("Global", "Generic", "mobile", "9876543211");
		String data = DataHandler.retrieveData("Generic", "mobile");
		System.out.println("Retrieved data: "+data);

	}*/

}
