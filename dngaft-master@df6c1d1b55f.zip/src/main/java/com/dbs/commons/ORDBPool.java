package com.dbs.commons;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.mariadb.jdbc.MariaDbPoolDataSource;

import com.dbs.config.Config;

public class ORDBPool {

	/**
	 *
	 * @author
	 */

	public static Connection connection = null;
	public static int connectionCount = 0;
	public static MariaDbPoolDataSource pool;
	private static final Logger logger = Logger.getLogger(ORDBPool.class);
	public Connection getConnection() {

		try {

			if (pool == null) {
				pool = new MariaDbPoolDataSource(Config.DB_AUTOMATION_CONNECTION);
				// String driver = "com.mysql.jdbc.Driver";
				try {

					pool.setUser(Config.DB_AUTOMATION_USER);
					pool.setPassword(Config.DB_AUTOMATION_PASSWORD);
					pool.setMaxPoolSize(30);
					pool.setMaxIdleTime(120);
					pool.setPoolName("");

					if (connection == null || connection.isClosed()) {
						System.out.println(" requeition CONNECTION WITH FIRST SERVER.");
						connection = pool.getConnection();
						connectionCount++;
					}
				} catch (Throwable e) {
					System.out.println(
							"***Connection Requisition*** Could not connect to the database msg :" + e.getMessage());
					Config.gracefulEnd(e, logger);
				}
			} else {
				connection = pool.getConnection();
				connectionCount++;
			}
		} catch (Exception e) {
			System.out.println("open connection exception" + e);
		}
		return connection;
	}

	public static void close(ResultSet c) {
		try {
			if (c != null) {
				c.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(Statement c) {
		try {
			if (c != null) {
				c.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(Connection c) {
		try {
			if (c != null) {
				c.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
