package com.dbs.commons;

import java.io.File;


public class BatchRun {
	public static final String fp = File.separator;
	public static final String CURRENT_DIR = System.getProperty("user.dir");
	public static final String APP_CONFIG_PATH =  "resources" +fp+ "Config" + fp + "Config.xlsx";

	public static void main(String[] args) {
		System.out.println("Starting ..." );
		test2(CURRENT_DIR+fp+"src//test//resources//");
	}

	public static void test2(String folderPath) {
		try {
			File folder2Scan = new File(folderPath);
			String target_file;
			File[] listOfFiles = folder2Scan.listFiles();
			System.out.println("Searching at "+ folderPath );
		     for (int i = 0; i < listOfFiles.length; i++) {
		            if (listOfFiles[i].isFile()) {
		                target_file = listOfFiles[i].getName();
		                System.out.println("file -- " + " " + target_file); 
		                if (target_file.contains("serenity")
		                     && target_file.endsWith(".properties")) {
		                //You can add these files to fileList by using "list.add" here
		                     System.err.println("found : " + " " + target_file); 
		                }
		           }
		     }
		}catch(Exception e) {
			e.printStackTrace();
		}
 
	}

}
