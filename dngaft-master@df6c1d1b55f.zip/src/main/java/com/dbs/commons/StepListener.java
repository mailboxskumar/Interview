package com.dbs.commons;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.Meta;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.jbehave.core.reporters.NullStoryReporter;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

/**
 * @author nagendrapai
 * @version 1.0 Listens to the various jbehave events and logs them to database
 *          for reporting
 */

public class StepListener extends NullStoryReporter {

	private static final Logger logger = Logger.getLogger(StepListener.class);
	// public static String currentStepName;
	private String stepName;
	private String currentTestName;
	private String scenarioId;
	private String currentScenario;
	private String currentStoryName;
	private String currentStoryDescription;
	private Meta metaTagsforCurrentScenario;
	private int scenarioCounter;
	private int scenarioTotalIterations;
	private int scenarioIterator;
	private HashMap<String, String> examples;
	private List<String> exampleSteps;
	private List<String> scenarioStatus = new ArrayList<String>();
	private ExamplesTable examplesTable;
	private int examplesCounter;
	private String formattedStepName;
	private String stepID;
	private int stepCounter;
	private ScenarioHolder scenHolder;
	private List<ScenarioHolder> ScenarioList = null;
	public static Map<String,List<ScenarioHolder>> scenarioTagMap = new HashMap<String,List<ScenarioHolder>>();
	private Reporter reporter;
	private static final ThreadLocal<StepListener> listener = new InheritableThreadLocal<>();
	
	public static void setListener(StepListener listen) {
		listener.set(listen);
	}
	
	public static StepListener getListener() {
		return listener.get();
	}
	
	public void setReporter(Reporter reporter) {
		this.reporter = reporter;
	}	

	public void beforeStep(String step) {
		logger.info(":: before Step ::");
		stepID = scenarioId + "-" + stepCounter++;
		RunDetails.stepID = stepID;
		stepName = stepFormatter(step);
		// currentStepName = step;
		logger.info("~~Listener~~Step STARTED :" + step);
		reporter.childlog.log(Status.DEBUG, MarkupHelper.createLabel("EXECUTING : : " + step, ExtentColor.ORANGE));
		if(!Config.LOCAL_RUN)
			RunDetails.insertStepDetailsIntoDB(RunDetails.getScenarioSeqonRunID(), stepID, RunDetails.scenarioID, step, "");
	}

	public void successful(String step) {
		logger.info(":: Successful ::");
		logger.info("~~Listener~~Step marked as PASSED :" + step);
		for(ScenarioHolder scen: ScenarioList) {
			scen.stepsList.add(step);
		}		
		updateReporting("PASS", null);
	}

	public void beforeStory(Story story, boolean givenStory) {
		try {
			logger.info(":: Before Story ::");
			scenarioCounter = 0;
			logger.info("Before story resetting scenarioCounter :: " + scenarioCounter);
			currentStoryDescription = story.getDescription().asString();
			currentStoryName = story.getName();
			if (currentStoryDescription.contains(Config.JIRA_PROJECT)) {
				RunDetails.jiraID = currentStoryName.substring(currentStoryName.indexOf("-") + 1,
						currentStoryName.indexOf("."));
				logger.info("Story ID : " + RunDetails.jiraID);
				logger.info("Executing story :: " + currentStoryDescription);
				reporter.log = reporter.extent.createTest(currentStoryDescription);
			}
		} catch (Throwable t) {
			logger.error("Exception in StepListner beforeStory method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}
	
    public void afterStory(boolean givenStory) {
    	logger.info(":: After Story ::");
    }

	public void ignorable(String step) {
		logger.info(":: Ignorable ::");
		logger.info("~~Listener~~Step marked IGNORED :" + step);
		for(ScenarioHolder scen: ScenarioList) {
			scen.stepsList.add(step);
		}
		updateReporting("IGNORE", null);
	}

	public void pending(String step) {
		logger.info(":: Pending ::");
		logger.info("~~Listener~~Step marked IGNORED :" + step);
		for(ScenarioHolder scen: ScenarioList) {
			scen.stepsList.add(step);
		}
		updateReporting("PENDING", null);
		
	}

	public void notPerformed(String step) {
		logger.info(":: Not performed ::");
		logger.info("~~Listener~~Step marked IGNORED :" + step);
		for(ScenarioHolder scen: ScenarioList) {
			scen.stepsList.add(step);
		}
		updateReporting("NOTPERFORM", null);
	}

	public void failed(String step, Throwable cause) {
		logger.info(":: failed ::");
		logger.info("~~Listener~~Step marked as FAILED :" + step + " due to" + cause.getMessage());
		for(ScenarioHolder scen: ScenarioList) {
			scen.stepsList.add(step);
		}
		updateReporting("FAIL", cause);
	}

	/*
	 * 
	 * */
	public void beforeScenario(String title) {
		try {
			examplesCounter = 0;
			scenarioIterator = 1;
			scenarioStatus.clear();			
			logger.info("Before story resetting examplesCounter :: " + examplesCounter);
			RunDetails.totalScenarios++;
			scenarioCounter++;
			logger.info("~~Listener~~Step marked SCENARIO :" + title + "\n scenarioCounter :: " + scenarioCounter);
			currentScenario = title;
			reporter.childlog = reporter.log.createNode(currentScenario);			
			scenarioId = RunDetails.jiraID + "_0" + scenarioCounter;
			RunDetails.scenarioID = scenarioId;
			logger.info(scenarioId + " --> is the scenarioID of " + currentScenario);
			setScenarioId(scenarioId);
			if(!Config.LOCAL_RUN) {
				RunDetails.insertScenarioDetailsIntoDB(RunDetails.runID, RunDetails.jiraID, scenarioId, examplesCounter,
					currentScenario, DriverManagerFactory.getDriverData("Description"), "", "");
			}
			logger.info("before scenario activities completed");
		} catch (Throwable t) {
			logger.error("Exception in beforeScenario Method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}
	public void beforeScenario(Scenario scenario) {
		try {
			logger.info(":: before Scenario ::");
			examplesCounter = 0;
			scenarioIterator = 1;
			scenarioStatus.clear();			
			logger.info("Before story resetting examplesCounter :: " + examplesCounter);
			RunDetails.totalScenarios++;
			scenarioCounter++;
			logger.info("~~Listener~~Step marked SCENARIO :" + scenario.getTitle() + "\n scenarioCounter :: " + scenarioCounter);
			currentScenario = scenario.getTitle();
			reporter.childlog = reporter.log.createNode(currentScenario);
			scenarioId = RunDetails.jiraID + "_0" + scenarioCounter;
			RunDetails.scenarioID = scenarioId;
			logger.info(scenarioId + " --> is the scenarioID of " + currentScenario);
			logger.info(" is this local run ? ( Config.LOCAL_RUN ) :" + Config.LOCAL_RUN);
			if(!Config.LOCAL_RUN) {
				setScenarioId(scenarioId);
				RunDetails.insertScenarioDetailsIntoDB(RunDetails.runID, RunDetails.jiraID, scenarioId, examplesCounter,
					currentScenario, DriverManagerFactory.getDriverData("Description"), "", "");
			}
			logger.info("before scenario activities completed");
		} catch (Throwable t) {
			logger.error("Exception in beforeScenario Method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}
	public void scenarioMeta(Meta meta) {
		
		System.out.println("META " + meta);
		metaTagsforCurrentScenario = meta;
		ScenarioList = new ArrayList<ScenarioHolder>();
    	try {
    		String storyId = currentStoryName.substring(currentStoryName.indexOf("-")+1, currentStoryName.indexOf("."));
			
    		if(!meta.getPropertyNames().isEmpty()) {
    			Set<String> tags= meta.getPropertyNames();
    			Iterator<String> iter = tags.iterator();
    			String tag;
    			while(iter.hasNext()) {
    				tag = iter.next();
    				if(!scenarioTagMap.containsKey(tag)) {
    					scenarioTagMap.put(tag, new ArrayList<ScenarioHolder>());    					
    				}
    				List<ScenarioHolder> scenList = scenarioTagMap.get(tag);
   					scenHolder = new ScenarioHolder(storyId, (scenList==null?1:scenList.size()+1), currentScenario);   					
   					scenList.add(scenHolder);
   					ScenarioList.add(scenHolder);
    			}
    		}
    		
    	}catch (Throwable t) {
			logger.error("Exception in StepListner beforeStory method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}

	public void afterScenario() {
		logger.info("::After Scenario :: no actitivies to perform");
		if(scenarioStatus.size()==0) {
			//reporter.childlog.log(Status.SKIP, "Scenario")
			reporter.childlog.log(Status.SKIP,
				MarkupHelper.createLabel("NOT PERFORMED : : Scenario is excluded by the Filter", ExtentColor.AMBER));
		}
	}

	/**
	 * @author nagendrapai
	 * @return String
	 * @param returns
	 *            the name of the current step under execution
	 */
	public String getStepName() {
		return stepName;
	}

	/**
	 * @author nagendrapai
	 * @return String
	 * @param returns
	 *            the name of the current test under execution
	 */
	public String getTestName() {
		return currentTestName;
	}

	/**
	 * @author nagendrapai
	 * @param saves
	 *            the scenario id of current execution
	 */
	public void setScenarioId(String scenId) {
		scenarioId = scenId;
	}

	/**
	 * @author nagendrapai
	 * @param returns
	 *            the scenario id of current execution
	 */
	public String getScenarioId() {
		return scenarioId;
	}

	public String getCurrentStoryDescription() {
		return currentStoryDescription;
	}

	public String getCurrentStoryName() {
		return currentStoryName;
	}

	public Meta getMetaTagsforCurrentScenario() {
		return metaTagsforCurrentScenario;
	}

	public void beforeExamples(List<String> steps, ExamplesTable table) {
		logger.info(":: before example ::");
		scenarioStatus.clear();
		scenarioIterator = 0;
		logger.info("scenarioStatus is cleared and flushed\n current status list size :: " + scenarioStatus.size());
		stepCounter = 1;
		logger.info("stepCounter is reset and current counter is :: " + stepCounter);
		exampleSteps = steps;
		examplesTable = table;
		scenarioTotalIterations = table.getRowCount();
		// System.out.println(currentScenario + " has " + scenarioTotalIterations + "
		// iterations");
		logger.info("Before examples :: " + currentScenario + " has " + scenarioTotalIterations + " iterations");

	}

	public void example(Map<String, String> tableRow) {
		try {
			logger.info(":: Example ::");
			RunDetails.totalExamples++;
			logger.info("Total examples executed till now :: " + RunDetails.totalExamples);
			examplesCounter++;
			scenarioIterator++;
			logger.info("Example no for scenarioID :: " + scenarioId + " :: " + examplesCounter);
			examples = (HashMap<String, String>) tableRow;
			for (String step : exampleSteps) {
				logger.info("Examples No: " + scenarioIterator + " for steps " + stepFormatter(step));
				logger.info("Step ID : " + stepID);
			}

		} catch (Throwable t) {
			logger.error("Exception at example method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}

	public void afterExamples() {
		try {
			logger.info(":: after Examples ::");
			if (scenarioIterator == scenarioTotalIterations) {
				scenarioIterator = 0;
			}
			if (scenarioStatus.contains("FAIL")) {
				
				RunDetails.totalExamplesFailed++;
				if(!Config.LOCAL_RUN)
					RunDetails.updateScenarioDetails(RunDetails.jiraID, RunDetails.scenarioID, examplesCounter, "FAILED", metaTagsforCurrentScenario.toString());
				
				/*(RunDetails.runID, RunDetails.jiraID, scenarioId, examplesCounter,
						currentScenario, DriverManagerFactory.getDriverData("Description"), "FAILED", "");*/
			} else if (scenarioStatus.contains("NOT PERFORMED") || scenarioStatus.contains("PENDING")) {
				RunDetails.totalExamplesSkipped++;
				RunDetails.totalExamplesPending++;
				if(!Config.LOCAL_RUN)
					RunDetails.updateScenarioDetails(RunDetails.jiraID, RunDetails.scenarioID, examplesCounter, "NOT PERFORMED", metaTagsforCurrentScenario.toString());
				/*RunDetails.insertScenarioDetailsIntoDB(RunDetails.runID, RunDetails.jiraID, scenarioId, examplesCounter,
						currentScenario, DriverManagerFactory.getDriverData("Description"), "SKIPPED", "");*/
			} else if (scenarioStatus.contains("PASS")) {
				RunDetails.totalExamplesPassed++;
				if(!Config.LOCAL_RUN)
					RunDetails.updateScenarioDetails(RunDetails.jiraID, RunDetails.scenarioID, examplesCounter, "PASSED", metaTagsforCurrentScenario.toString());
			/*	RunDetails.insertScenarioDetailsIntoDB(RunDetails.runID, RunDetails.jiraID, scenarioId, examplesCounter,
						currentScenario, DriverManagerFactory.getDriverData("Description"), "PASSED", "");*/
			}
		} catch (Throwable t) {
			logger.error("Exception at afterExamples method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}

	public String stepFormatter(String step) {
		try {
			logger.info(":: steps Formatter ::");
			logger.info(":: step =" + step );
			logger.info(" \n examplesTable " + examplesTable);
			formattedStepName = step;
			if(getListener().examplesTable != null) {
				for (String header : getListener().examplesTable.getHeaders()) {
					if (getListener().formattedStepName.contains("$" + header)) {
						getListener().formattedStepName = getListener().formattedStepName.replaceAll("\\$" + header, examples.get(header));
					}
				}
			}

		} catch (Throwable t) {
			logger.error("Exception at afterExamples method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
		return formattedStepName;
	}

	private void updateReporting(String status, Throwable t) {

		try {
			logger.info(":: update Reporting ::");
			if (status.equalsIgnoreCase("pass")) {
				scenarioStatus.add(status);
				reporter.childlog.log(Status.PASS,
						MarkupHelper.createLabel("PASSED : : " + stepName, ExtentColor.GREEN));
				if(!Config.LOCAL_RUN)
					RunDetails.updateStepDetails(stepName, stepID, status, RunDetails.scenarioID);
				/*RunDetails.insertStepDetailsIntoDB(RunDetails.getScenarioSeqonRunID(), stepID, scenarioId, stepName,
						status);*/
			} else if (status.equalsIgnoreCase("fail")) {
				scenarioStatus.add(status);
				reporter.childlog.log(Status.FAIL, MarkupHelper.createLabel("FAILED : : " + stepName, ExtentColor.RED));
				if(!Config.LOCAL_RUN)
					RunDetails.updateStepDetails(stepName, stepID, status, RunDetails.scenarioID);
				/*RunDetails.insertStepDetailsIntoDB(RunDetails.getScenarioSeqonRunID(), stepID, scenarioId, stepName,
						status);*/
				reporter.childlog.fail(t.fillInStackTrace());
			} else if (status.equalsIgnoreCase("pending")) {
				scenarioStatus.add(status);
				reporter.childlog.log(Status.SKIP,
						MarkupHelper.createLabel("PENDING : : " + stepName, ExtentColor.ORANGE));
				if(!Config.LOCAL_RUN)
					RunDetails.updateStepDetails(stepName, stepID, status, RunDetails.scenarioID);
				/*RunDetails.insertStepDetailsIntoDB(RunDetails.getScenarioSeqonRunID(), stepID, scenarioId, stepName,
						status);*/
			} else if (status.equalsIgnoreCase("not performed")) {
				scenarioStatus.add(status);
				reporter.childlog.log(Status.WARNING,
						MarkupHelper.createLabel("NOT PERFORMED : : " + stepName, ExtentColor.AMBER));
				if(!Config.LOCAL_RUN)
					RunDetails.updateStepDetails(stepName, stepID, status, RunDetails.scenarioID);
				/*RunDetails.insertStepDetailsIntoDB(RunDetails.getScenarioSeqonRunID(), stepID, scenarioId, stepName,
						status);*/
			}
		} catch (Throwable t1) {
			logger.info("Exception occured in StepListerner updating the reports " + t1.getLocalizedMessage());
			Config.gracefulEnd(t1, logger);
		}

	}
	
	//Returns current scenario-example iteration
	public int getCurrentIteration() {
		return scenarioIterator;
	}

}
