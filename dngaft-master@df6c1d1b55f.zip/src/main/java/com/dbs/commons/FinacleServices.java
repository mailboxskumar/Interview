package com.dbs.commons;

import java.util.HashMap;
import java.util.Map;

import com.intuit.karate.cucumber.CucumberRunner;

/**
 *
 * @author pthomas3
 */
public class FinacleServices {
    
	
    public Map<String, Object> getRequestFeatureFromJava() {
    	 Map<String, Object> result=null;
    	try {
        Map<String, Object> args = new HashMap(); 
       // args.put("name", "World");
       result = CucumberRunner.runFeature(this.getClass(), "Balance.feature", args, false);
       // result = CucumberRunner.runClasspathFeature("C:\\IBID\\digibdd\\digi-nextgen\\src\\main\\java\\com\\dbs\\services\\Balance.feature", args, false);
      
    	}catch(Throwable t) {
    		t.printStackTrace();
    	}
       // assertEquals("Hello World", result.get("greeting"));
    	 return result;
    }
    
}