package com.dbs.commons;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.dbs.config.Config;

/**
*
* @author Main.org
*/
public class ClobBlob {

    /**
     * Read resume of a candidate and write it into a file
     *
     * @param candidateId
     * @param filename
     */
	
	private static final Logger logger=Logger.getLogger( ClobBlob.class); 
    public static void readBlob(String run_id, String testid, String resourceRef, String resourceType,String filename) {
        // update sql
        String selectSQL = "SELECT run_id,testid,resourceRef,resourcetype, resource1 FROM test_evidences WHERE " +
        "run_id=? and testid=? and resourceRef=? and resourcetype=? ";
        ResultSet rs = null;

        try (Connection conn = connectToDB();
                PreparedStatement pstmt = conn.prepareStatement(selectSQL);) {
            // set parameter;
             pstmt.setString(1, run_id);
            pstmt.setString(2, testid);
            pstmt.setString(3, resourceRef);
            pstmt.setString(4, resourceType);
            rs = pstmt.executeQuery();

            // write binary stream into file
            File file = new File(filename);
            FileOutputStream output = new FileOutputStream(file);

           logger.info("Writing to file " + file.getAbsolutePath());
            while (rs.next()) {
                InputStream input = rs.getBinaryStream("resource1");
                byte[] buffer = new byte[1024];
                while (input.read(buffer) > 0) {
                    output.write(buffer);
                }
            }
            output.close();
        } catch (SQLException | IOException e) {
           logger.error(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                logger.error("SQL Exception occurred "+e.getMessage());
                Config.gracefulEnd(e, logger);
            }
        }
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       writeBlob("2","1","1","image","C:\\DigiBank\\Trash\\ib_1.png");
       writeBlob("3","2","1","image","C:\\DigiBank\\Trash\\mb_1.png");
        readBlob("2","1","1","image","C:\\DigiBank\\Trash\\ib_3.png");
    }
    
    
    public static void writeBlob(String run_id, String testid, String resourceRef, String resourceType,String filename) {
        // update sql
       
        String updateSQL = "INSERT INTO test_evidences (run_id,testid,resourceRef,resourcetype, resource1) " + 
                    "VALUES (?,?,?,?,?); "; 
        try (Connection conn = connectToDB();
                PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {

            // read the file
            File file = new File(filename);
            FileInputStream input = new FileInputStream(file);

            // set parameters
            pstmt.setString(1, run_id);
            pstmt.setString(2, testid);
            pstmt.setString(3, resourceRef);
            pstmt.setString(4, resourceType);
            pstmt.setBinaryStream(5, input);

            // store the resume file in database
            logger.info("Reading file " + file.getAbsolutePath());
            logger.info("Store file in the database.");
            pstmt.executeUpdate();
        } catch (SQLException | FileNotFoundException e) {
            logger.error(e.getMessage());
            Config.gracefulEnd(e, logger);
        }
    }
       public static Connection connectToDB(){
              Connection conn = null;
              try{
                     Class.forName ("org.mariadb.jdbc.Driver").newInstance ();
                     conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/reports", "app_digi", "dbs123");
                     conn.setAutoCommit (true);
                           return conn;
              }catch (Throwable t) {
                     logger.error("Exception occured :- " + t);
                     Config.gracefulEnd(t, logger);
                     }
              
              return conn;
       }

}
