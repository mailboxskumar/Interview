package com.dbs.commons;

public class AccountDetails {
	
	private String AcctId;
	private String IsMultiCurrAcct;
	private String ProductCategory;
	private String ProductCode;
	private String AcctName;
	private String LedgerBal;
	private String AvailBal;
	private String BankCode;
	private String SAcctStatus;
	private String SchemeName;
	private String AcctCurrCode;
	private String AcctOpeningDt;
	private String ModeOfOperation;
	private String MultiCcyAcctID;

	
	public void setAcctId(String value) {
		this.AcctId=value;
	}
	
	public String getAcctId() {
		return this.AcctId;
	}
	
	public void setIsMultiCurrAcct(String value) {
		this.IsMultiCurrAcct=value;
	}
	
	public String getIsMultiCurrAcct() {
		return this.IsMultiCurrAcct;
	}
	
	public void setProductCategory(String value) {
		this.ProductCategory=value;
	}
	
	public String getProductCategory() {
		return this.ProductCategory;
	}
	
	public void setProductCode(String value) {
		this.ProductCode=value;
	}
	
	public String getProductCode() {
		return this.ProductCode;
	}
	
	public void setAcctName(String value) {
		this.AcctName=value;
	}
	
	public String getAcctName() {
		return this.AcctName;
	}
	
	
	public void setLedgerBal(String value) {
		this.LedgerBal=value;
	}
	
	public String getLedgerBal() {
		return this.LedgerBal;
	}
	
	public void setAvailBal(String value) {
		this.AvailBal=value;
	}
	
	public String getAvailBal() {
		return this.AvailBal;
	}
	
	public void setBankCode(String value) {
		this.BankCode=value;
	}
	
	public String getBankCode() {
		return this.BankCode;
	}
	
	public void setSAcctStatus(String value) {
		this.SAcctStatus=value;
	}
	
	public String getSAcctStatus() {
		return this.SAcctStatus;
	}
	
	public void setSchemeName(String value) {
		this.SchemeName=value;
	}
	
	public String getSchemeName() {
		return this.SchemeName;
	}
	
	public void setAcctCurrCode(String value) {
		this.AcctCurrCode=value;
	}
	
	public String getAcctCurrCode() {
		return this.AcctCurrCode;
	}
	
	public void setAcctOpeningDt(String value) {
		this.AcctOpeningDt=value;
	}
	
	public String getAcctOpeningDt() {
		return this.AcctOpeningDt;
	}
	
	public void setModeOfOperation(String value) {
		this.ModeOfOperation=value;
	}
	
	public String getModeOfOperation() {
		return this.ModeOfOperation;
	}
	
	public void setMultiCcyAcctID(String value) {
		this.MultiCcyAcctID=value;
	}
	
	public String getMultiCcyAcctID() {
		return this.MultiCcyAcctID;
	}
	
	
	
	
}
