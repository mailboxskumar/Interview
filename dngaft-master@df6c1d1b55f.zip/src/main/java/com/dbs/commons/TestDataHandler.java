package com.dbs.commons;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;

/**
 * @author nagendrapai
 * @version 1.0 Collects and Saves the tag wise scenario count, story wise tag count and stores manual scenarios to excel
 *          for reporting
 */

public class TestDataHandler {
	
	private static final Logger logger = Logger.getLogger(TestDataHandler.class);
	public String deviceName;
	Fillo fillo;
	Connection conn;
	Recordset rs;
	
	public TestDataHandler(String deviceName) {
		this.deviceName = deviceName;
	}
	
	public void createDataFiles() {
		try {
			String filePath = Config.TESTDATA_FILE_PATH+deviceName+".xlsx";
			fillo = new Fillo();
			conn = fillo.getConnection(filePath);
			
			List<String> storyList = conn.getMetaData().getTableNames();
			
			for(String story:storyList) {
				List<List<String>> fileDataWriteList = null;
				List<String> columnList = null;
				String intermedfileName = story.substring(story.indexOf("_")+1);
				rs = conn.executeQuery("select *from "+story);
				columnList = rs.getFieldNames();
				System.out.println("Field names: "+rs.getFieldNames());
				System.out.println("Count: "+rs.getCount());
				List<String> dupScenList = new ArrayList<String>();
				while(rs.next()) {
					dupScenList.add(rs.getField("ScenarioNo"));
					System.out.println(rs.getField("ScenarioNo"));
				}
				List<String> deDupedScenList = dupScenList.stream().distinct().collect(Collectors.toList());
				System.out.println("Deduped: "+deDupedScenList);
				
				for(String scen:deDupedScenList) {
					fileDataWriteList = new ArrayList<List<String>>();
					fileDataWriteList.add(columnList);
					rs = conn.executeQuery("select *from "+story+" where ScenarioNo = '"+scen+"'");

					while(rs.next()) {
						List<String> tempList = new ArrayList<String>();
						for(int i = 0; i<rs.getFieldNames().size();i++) {
							tempList.add(rs.getField(rs.getFieldNames().get(i)));
						}
						fileDataWriteList.add(tempList);
				
					}
					String fileName = intermedfileName+"-"+scen;
					saveDataInFile(fileDataWriteList,fileName);
					
				}
			}			
			
		}catch(Throwable t) {
			logger.error("Exception in TestDataHandler:createDataFiles method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
		finally {
			conn.close();
		}
	}
	
	private void saveDataInFile(List<List<String>> dataToWrite, String fileName) {
		String path = Config.TESTDATA_FILE_PATH+deviceName+File.separator+fileName+".table";
		BufferedWriter bw = null;
		FileWriter fw = null;
		
		try {
			fw = new FileWriter(path);
			bw = new BufferedWriter(fw);
			
			for(List<String> list:dataToWrite) {
				String eachRowData = "| ";
				for(int i=1;i<list.size();i++) {
					eachRowData = eachRowData+" "+list.get(i)+" |";
				}
				bw.write(eachRowData+"\n");		
				eachRowData = null;
			}
			
		}catch(Throwable t) {
			logger.error("Exception in saveDataInFile method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
		finally {
			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (Throwable t) {

				logger.error("Exception in saveDataInFile method " + t.getLocalizedMessage());
				Config.gracefulEnd(t, logger);

			}
		}			
		
	}
	
/*	public static void main(String[] args) {
		new TestDataHandler().createDataFiles();
	}*/

}
