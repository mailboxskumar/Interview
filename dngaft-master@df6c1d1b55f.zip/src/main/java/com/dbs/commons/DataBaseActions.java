package com.dbs.commons;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.dbs.config.Config;

public class DataBaseActions {

	String query;
	private Statement stmt;
	private ResultSet rs;

	private static  ReportingDBPool rdbpool = new ReportingDBPool();
	private static ORDBPool ordbpool = new ORDBPool();
	private static final ThreadLocal<DataBaseActions> dbActions = new InheritableThreadLocal<>();
	private static final Logger logger = Logger.getLogger(DataBaseActions.class);
	
	public static void setDbActions() {
		dbActions.set(new DataBaseActions());		
	}
	
	public static DataBaseActions getDbActions() {
		return dbActions.get();
	}

	public void executeUpdate(String query) {

		DBActions db = new DBActions(query);
		db.start();

	}

	public ResultSet execute(String query) {
		
		Connection conn = ordbpool.getConnection();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
		} catch (Throwable t) {
			logger.error("Exception occured while executing queries " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				Config.gracefulEnd(e, logger);
			}
		}
		return this.rs;
	}
	
	public ResultSet executeOnReportingDB(String query) {
		
		Connection conn = rdbpool.getConnection();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
		} catch (Throwable t) {
			logger.error("Exception occured while executing queries " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		} finally {
			try {
				logger.info("Closing Async DB connection :: "+conn);
				conn.close();
			} catch (SQLException e) {
				logger.error("Error in closing Async DB connection :: "+conn);
				Config.gracefulEnd(e, logger);
			}
		}
		return this.rs;
	}

	private class DBActions extends Thread {

		String query;
		public DBActions(String query) {
			this.query = query;
		}

		@Override
		public void run() {
			logger.info("Async DB calling :: "+query);
			Connection conn = rdbpool.getConnection();
			//Connection conn = ConnectDB.reportCnctn;
			System.out.println("Connection details: "+conn);
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate(query);
			} catch (Throwable t) {
				logger.error("Exception occured while updating reports DB executing queries :: "+query +"\n"+ t.getLocalizedMessage());
				Config.gracefulEnd(t, logger);
			} finally {
				/*try {
					conn.close();
				} catch (SQLException e) {
					Config.gracefulEnd(e, logger);
				}*/

			}
		}

	}

}
