package com.dbs.commons;

import java.io.FileOutputStream;
import java.util.*;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.dbs.config.Config;

/**
 * @author nagendrapai
 * @version 1.0 Collects and Saves the tag wise scenario count, story wise tag count and stores manual scenarios to excel
 *          for reporting
 */

public class ScenarioAggregator {

	private static final Logger logger = Logger.getLogger(ScenarioAggregator.class);
	Fillo fillo;
	Connection conn;
	private Map<String,Map<String,Integer>> storyHolder = new HashMap<String,Map<String,Integer>>();

	public void saveScenariosInExcel(Map<String,List<ScenarioHolder>> storyMap) {
		try {
			String filePath = Config.SCENARIO_SUMMARY_PATH;
			fillo = new Fillo();
			conn = fillo.getConnection(filePath);

			List<String> tableList = conn.getMetaData().getTableNames();
			String metaTagSheet = "MetaTagSummary";
			//String firstSheet = "Summary_"+Config.SPRINT_NO;

			if(tableList.contains(metaTagSheet)) {
				conn.executeUpdate("DELETE from "+metaTagSheet);
			}
			else {
				conn.createTable(metaTagSheet, new String[] {"SlNo","MetaTag","Count","Sprint"});
			}
			
			String manualSheet = "ManualScenarios";
			
			if(tableList.contains(manualSheet)) {
				conn.executeUpdate("DELETE from "+manualSheet);
			}
			else {
				conn.createTable(manualSheet, new String[] {"StoryId","Scenario","StepNumber","StepDescription"});
			}
			
			String storySheet = "StorySummary";
			if(tableList.contains(storySheet)) {
				conn.executeUpdate("DELETE from "+storySheet);
			}
			else {
				conn.createTable(storySheet, new String[] {"StoryId","TotalScenarios","Automation","Manual","Ignored","Clarification"});
			}
			/*for(String table:tableList) {
				conn.deleteTable(table);
			}*/			

			int tagCnt = 0;		

			for(String tag:storyMap.keySet()) {
				tagCnt++;
				if(Config.SPRINT_NO == null) {
					conn.executeUpdate("INSERT INTO "+metaTagSheet+"(SlNo,MetaTag,Count) VALUES('"+tagCnt+"','"+tag.toUpperCase()+"','"+storyMap.get(tag).size()+"')");
				}else {
					conn.executeUpdate("INSERT INTO "+metaTagSheet+"(SlNo,MetaTag,Count,Sprint) VALUES('"+tagCnt+"','"+tag.toUpperCase()+"','"+storyMap.get(tag).size()+"','"+Config.SPRINT_NO+"')");
				}
				
			
				for(ScenarioHolder scen: storyMap.get(tag)) {

					if(tag.equalsIgnoreCase("ResetPIN")) {
						
						int i = 1;String query;

						for(String step:scen.stepsList) {
							if(i==1) {
								query = "INSERT INTO "+manualSheet+"(StoryId,Scenario,StepNumber,StepDescription) VALUES('" + scen.storyNum + "','" + scen.scenario + "','" + i + "','" + step + "')";

							}else {
								query = "INSERT INTO "+manualSheet+"(StepNumber,StepDescription) VALUES('"+i+"','"+step+"')";
							}						
							conn.executeUpdate(query);
							i++;
						}						

					}

					if(!storyHolder.containsKey(scen.storyNum)) {
						storyHolder.put(scen.storyNum, new HashMap<String,Integer>());
					}
					Map tempHold = storyHolder.get(scen.storyNum);
					if(!tempHold.keySet().contains(tag)) {
						tempHold.put(tag, 0);
					}
					int currentCnt = (int) tempHold.get(tag);
					tempHold.put(tag, currentCnt+1);
					storyHolder.put(scen.storyNum, tempHold);

				}	

			}

			System.out.println(storyHolder);

			for(String storyNo:storyHolder.keySet()) {
				int auto=0,manual=0,ignore=0,totalCnt=0;
				Map scenMap = storyHolder.get(storyNo);

				Set<Entry> entries = scenMap.entrySet();
				for (Iterator<Entry> i = entries.iterator(); i.hasNext(); ) {
					Entry e = (Entry) i.next();
					switch(e.getKey().toString().toLowerCase()) {
					case "automation":
						auto = (int) e.getValue();
						totalCnt++;
						break;
					case "manual":
						manual = (int) e.getValue();
						totalCnt++;
						break;
					case "ignore":
						ignore = (int) e.getValue();
						totalCnt++;
						break;
					default:
						totalCnt++;
					}
				}

				String query = "INSERT INTO "+storySheet+"(StoryId,TotalScenarios,Automation,Manual,Ignored) VALUES('" + storyNo + "','" + totalCnt + "','" + auto + "','" + manual + "','" + ignore + "')";
				conn.executeUpdate(query);
			}

		} catch (Throwable t) {
			logger.error("Exception in ScenarioAggregator method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}finally {
			conn.close();
		}
	}

/*	public static void main(String[] args) {

		List<String> steps = new ArrayList<String>();
		steps.add("Given User in App login");
		steps.add("When User enters credentials");
		steps.add("Then User should be able to see Home page");

		ScenarioHolder scen1 = new ScenarioHolder("1300", 1, "01 - Xelerate login Screen with Admin Credentials");
		scen1.stepsList = steps;

		ScenarioHolder scen2 = new ScenarioHolder("1300", 2, "02 - App login Screen with LSA Credentials");
		scen2.stepsList = steps;	

		ScenarioHolder scen3 = new ScenarioHolder("1301", 1, "01 - App login Screen with LSA Credentials");
		scen3.stepsList = steps;

		ScenarioHolder scen4 = new ScenarioHolder("1301", 2, "01 - App login Screen with LSA Credentials");
		scen4.stepsList = steps;

		ScenarioHolder scen5 = new ScenarioHolder("1301", 3, "01 - App login Screen with LSA Credentials");
		scen5.stepsList = steps;

		List<ScenarioHolder> list1 = new ArrayList<ScenarioHolder>();
		list1.add(scen1);

		list1.add(scen4);

		List<ScenarioHolder> list2 = new ArrayList<ScenarioHolder>();
		list2.add(scen3);
		list2.add(scen2);

		List<ScenarioHolder> list3 = new ArrayList<ScenarioHolder>();
		list3.add(scen5);

		Map<String,List<ScenarioHolder>> tagMap = new HashMap<String,List<ScenarioHolder>>();
		tagMap.put("manual", list1);
		tagMap.put("automation", list2);
		tagMap.put("ignored", list3);

				List<Map<String,List<ScenarioHolder>>> storyList = new ArrayList<Map<String,List<ScenarioHolder>>>();
		storyList.add(story1);
		storyList.add(story2);		

		ScenarioAggregator sc = new ScenarioAggregator();
		sc.saveScenariosInExcel(tagMap);
	}*/
}
