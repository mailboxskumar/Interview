package com.dbs.actions;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.dbs.commons.ElementFinder;
import com.dbs.commons.Reporter;
import com.dbs.commons.RunDetails;
import com.dbs.commons.StepListener;
import com.dbs.config.Config;
import com.dbs.drivers.DriverManagerFactory;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class MB_Actions {

	MobileElement element;
	AppiumDriver appiumDriver;
	MobileDriver mobileDriver;
	IOSDriver iosDriver;
	AndroidDriver androidDriver;
	WebDriver proxiedDriver;
	TouchAction touchAction;
	Dimension dim;
	private By elementProperty;
	int Y_AXIS;
	int X_AXIS;
	ElementFinder elementFinder = new ElementFinder();
	Reporter reporter = Reporter.getCurrentReporter();
	public static MobileDriver mobileDriverForScreenshot = null;
	private static final Logger logger = Logger.getLogger(MB_Actions.class);

	public MB_Actions(MobileElement object, AppiumDriver driver) {
		this.element = object;
		this.mobileDriver = (MobileDriver) driver;
		this.touchAction = new TouchAction(driver);
		this.dim = getScreenResolution();
		this.Y_AXIS = dim.height;
		this.X_AXIS = dim.width;
		mobileDriverForScreenshot = (MobileDriver) driver;
	}

	public MB_Actions(MobileElement object, By objProp, AppiumDriver driver) {
		this.element = object;
		this.elementProperty = objProp;
		this.mobileDriver = (MobileDriver) driver;
		this.touchAction = new TouchAction(driver);
		this.dim = getScreenResolution();
		this.Y_AXIS = dim.height;
		this.X_AXIS = dim.width;
		mobileDriverForScreenshot = (MobileDriver) driver;
	}
	public void click() throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		try {
			if (isStale(element)) {
				updateReporterLog(StepListener.getListener().getStepName(), "clicked", "");
				element.click();
				logger.info("Clicked on object" + element);
			} else
				logger.error("Element is stale and not clickable");
		} catch (Throwable t) {
			logger.error("Exception in click method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			throw t;
		}
	}
	
	public void clickBasedOnElementLocation(int xplus, int yplus) throws Throwable {
		int x=getElementLocation().getX();
		int y=getElementLocation().getY();
		if(null == element)
			throw new Throwable(": MB Actions : Element is null");
		try {
			if (isStale(element)) {
				touchAction = new TouchAction(mobileDriver);
				//touchAction.tap(x+xplus, y+yplus).perform();
				touchAction.tap(PointOption.point(x+xplus, y+yplus));
				updateReporterLog(StepListener.getListener().getStepName(), "clicked", "");				
				logger.info("Clicked on object" + element);
			} else
				logger.error("Element is stale and not clickable");
		} catch (Throwable t) {
			logger.error("Exception in click method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			throw t;
		}
	}

	public void enterText(String value) throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		String actionName = "entered '" + value + "' ";
		try {
			element.clear();
			element.sendKeys(value);
			logger.info("Entered text" + value + "on object" + element);
			updateReporterLog(StepListener.getListener().getStepName(), actionName, value);
		} catch (Throwable t) {
			logger.error("Exception in enterText method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			throw t;
		}
	}

	public void hideKeyboard() throws Throwable {
		/*if (null == element)
			throw new Throwable(": MB Actions : Element is null");*/
		try {
			
			if(DriverManagerFactory.getDriverData("Platform Name").equalsIgnoreCase("Android")) {
					mobileDriver.hideKeyboard();
			}else {
				if(DriverManagerFactory.getDriverData("Run On Cloud").equalsIgnoreCase("true")) {
					mobileDriver.hideKeyboard();
				}else {
					try {
						elementFinder.verify_MB_Element(appiumDriver, "commonObjects", "lblReturn", "").click();
					}catch(Throwable t){
						elementFinder.verify_MB_Element(appiumDriver, "OtpPage", "lblDone", "").click();	
					}
				}
					
			}
			
		} catch (Exception e) {
			/* If the exception is thrown, then keyboard is not present */
			return;
		}
		return;
	}

	/*
	 * This method will return true if the element is enabled(Stale)
	 */
	public boolean isEnabled() throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		try {
			for (int i = 0; i <= Config.WAIT_FOR_ELEMENT_COUNTER; i++) {
				try {
					updateReporterLog(StepListener.getListener().getStepName(), "isEnabled", "");
					element.isEnabled();
					return true;
				} catch (StaleElementReferenceException e) {
					logger.error("Element is stale and not clickable " + e.getLocalizedMessage()
							+ "\r\n trying again... for " + i + " times");
				}
			}
			return false;
		} catch (Throwable t) {
			logger.error("Exception in isStale method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			return false;
		}
	}

	public String getText() throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		String elem_txt = "";
		try {
			elem_txt = element.getText();
			return elem_txt;
		} catch (Throwable t) {
			logger.error("Exception in enterText method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			return elem_txt;
		}
	}

	public boolean notExists() {
		if (null == element)
			return true;
		try {
			String actionName = Thread.currentThread().getStackTrace()[1].getMethodName();
			updateReporterLog(StepListener.getListener().getStepName(), actionName, "");
			element.isDisplayed();
			return false;
		} catch (Throwable t) {
			return true;
		}
	}

	public boolean isDisabled() throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		try {
			if (!element.isEnabled()) {
				updateReporterLog(StepListener.getListener().getStepName(), "isDisabled", "");
				return true;
			}
		} catch (Throwable e) {
			logger.error("Element is not available/null ");
			updateReporterLog(StepListener.getListener().getStepName(), "isDisabled", "");
			return false;
		}
		return false;
	}

	public boolean exists() {
		if (null == element)
			return false;
		try {
			String actionName = Thread.currentThread().getStackTrace()[1].getMethodName();
			updateReporterLog(StepListener.getListener().getStepName(), actionName, "");
			element.isDisplayed();
			logger.info("object exists " + element);
			return true;
		} catch (Throwable t) {
			logger.error("Exception in enterText method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			return false;
		}
	}

	public void swipeBasedOnText(String strText) throws Throwable {
		try {
			if (DriverManagerFactory.getDriverData("Platform Name").trim().equalsIgnoreCase("ANDROID")) {
				appiumDriver.findElement(MobileBy.AndroidUIAutomator(
						"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textMatches(\""
								+ strText + "\").instance(0))"));
				logger.info("scrolled to the element with text :: " + strText);
			} else if (DriverManagerFactory.getDriverData("Platform Name").trim().equalsIgnoreCase("IOS")) {
				appiumDriver.findElement(MobileBy.IosUIAutomation(
						"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textMatches(\""
								+ strText + "\").instance(0))"));
				logger.info("scrolled to the element with text :: " + strText);
			}
		} catch (Throwable t) {
			logger.error(
					"Error while scrolling to the element with text :: " + strText + " " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}

	public void SwipeScreenOnDirecton(String direction) throws Throwable {

		try {
			Thread.sleep(Config.SHORT_WAIT * 1000);
			switch (direction.toUpperCase()) {
			case "UP":
				logger.info(":SwipeScreenOnDirecton: Scrolling up the screen by half");
				Swipe(2, 2, 4, 2);
				break;
			case "DOWN":
				logger.info(":SwipeScreenOnDirecton: Scrolling down the screen by half");
				Swipe(1, 2, 2, 2);
				break;
			case "RIGHT":
				logger.info(":SwipeScreenOnDirecton: Scrolling right the screen by half");
				Swipe(2, 1, 2, 4);
				break;
			case "LEFT":
				logger.info(":SwipeScreenOnDirecton: Scrolling right the screen by half");
				Swipe(2, 4, 2, 1);
				break;
			}
		} catch (Throwable t) {
			logger.error("Exception in SwipeScreenOnDirecton method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
		}
	}

	 /* Operation performed on center of screen co-ordinates For swiping on a
	 * specific element use swipteBasedOnText
	 */
	public boolean SwipeTillFound(String direction) throws Exception {
		try {
			for (int i = 0; i <= Config.SWIPE_COUNTER; i++) {
				try {
					logger.info("Swiping on " + direction + " for " + i + " time(s)");
					SwipeScreenOnDirecton(direction);
					List<MobileElement> mbelst = elementFinder.find_MB_Elmtns((AppiumDriver) mobileDriver,
							this.elementProperty, Config.SHORT_WAIT / 3);
					if (mbelst == null)
						continue;
					element = mbelst.get(0);
					logger.info("After swiping " + i + " time(s), element exists ? " + exists());
				} catch (Exception e) {
					logger.error("SwipeTillFound : exception " + i + " /" + Config.SWIPE_COUNTER);
					logger.error(e.getLocalizedMessage());
					continue;
				}
			}
			return true;
		} catch (Throwable t) {
			logger.error("Exception in SwipeTillFound method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			return false;
		}
	}

	public MobileDriver getMobileDriver() {
		return this.mobileDriver;
	}

	public Point getElementLocation() {
		return element.getLocation();
	}
	
	
	
	
	
	public AppiumDriver getAppiumDriverDriver() {
		return this.appiumDriver;
	}

	public boolean isStale(WebElement element) throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		try {
			for (int i = 0; i <= Config.WAIT_FOR_ELEMENT_COUNTER; i++) {
				try {
					element.isEnabled();
					return true;
				} catch (StaleElementReferenceException e) {
					logger.error("Element is stale and not clickable " + e.getLocalizedMessage()
							+ "\r\n trying again... for " + i + " times");
				}
			}
			return false;
		} catch (Throwable t) {
			logger.error("Exception in isStale method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			return false;
		}
	}

	public void selectDropDownbyValue(String textToIdentify) throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		Select dropDown = new Select(element);
		// dropDown.selectByVisibleText(textToIdentify);
		dropDown.selectByValue(textToIdentify);
	}

	public void enterNumericsOnNumPad(String number) throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		logger.info("Entering numerics on " + element + " " + number);
		try {
			// String numArray[] = number.split("(?!^)");
			char[] numArray = number.toCharArray();
			for (char eachNumber : numArray) {
				enterNumber(Character.toString(eachNumber));
			}
		} catch (Throwable t) {
			logger.error("Error while entering numerics " + number);
			Config.gracefulEnd(t, logger);
		}
	}

	// android
	public boolean scroll_and_tap_byText_Android(String text) throws Throwable {
		try {
			mobileDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
							+ "new UiSelector().text(\"" + text + "\"));"));
			// tap on it
		} catch (Throwable t) {
			logger.error("Exception in scroll_and_tap_byText_Android method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			return false;
		}
		return true;
	}

	public boolean isKeyboardOpen() throws Throwable {
		try {
			DriverManagerFactory.getMobileManager().getMobileDriver().hideKeyboard();
		} catch (Exception e) {
			/* If the exception is thrown, then keyboard is not present */
			return true;
		}
		return false;
	}

	// ios
	public boolean scroll_and_tap_byText_IOS(String text) { // works ONLY inside scrollView
		JavascriptExecutor js = (JavascriptExecutor) iosDriver;
		HashMap<String,String> scrollObject = new HashMap<>();
		scrollObject.put("predicateString", "value == '" + text + "'");
		js.executeScript("mobile: scroll", scrollObject);
		WebElement el = iosDriver.findElementByIosUIAutomation("value = '" + text + "'");
		el.click();
		// iosDriver.tap(1, el, 500);
		return true;
	}

	/**
	 * <h4>Swipe</h4> This method performs swipe action based on co-ordinates be
	 * cautious while passing params
	 * 
	 * @param startHeightFrom
	 *            : Height of the screen resolution is divided by this value to form
	 *            a starting Y-Axis point
	 * @param startWidthFrom
	 *            : Width of the screen resolution is divided by this value to form
	 *            a starting X-Axis point
	 * @param endHeightAt
	 *            : Height of the screen resolution is divided by this value to form
	 *            a ending Y-Axis point
	 * @param entWidthAt
	 *            : Width of the screen resolution is divided by this value to form
	 *            a ending X-Axis point
	 * @return boolean
	 */

	protected boolean Swipe(int startHeightFrom, int startWidthFrom, int endHeightAt, int entWidthAt) {
		try {
			//mobileDriver.swipe(X_AXIS / startWidthFrom, Y_AXIS / startHeightFrom, X_AXIS / entWidthAt,Y_AXIS / endHeightAt, 750);
			new TouchAction(mobileDriver)
			.press(PointOption.point(startWidthFrom, startHeightFrom))
			.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750)))
			.moveTo(PointOption.point(entWidthAt, endHeightAt))
			.release()
			.perform();
		} catch (Throwable t) {
			Config.gracefulEnd(t, logger);
			logger.error("Returning 'false', Error while swiping :: " + t.getLocalizedMessage());
			return false;
		}
		return true;
	}

	private Dimension getScreenResolution() {
		Dimension resolution = mobileDriver.manage().window().getSize();
		return resolution;
	}

	/*
	 * private void updateReporter(String ActionName) { String sql =
	 * "INSERT INTO `reports`.`t_step_exec_details` \r\n" +
	 * "(`runId`, `TestCaseID`, `TestStepName`, `TestStepID`, `Status`, `referencePath`, `requestDetail`, `responseDetail`, `stepStart`, `stepEnd`) \r\n"
	 * + "VALUES \r\n" +
	 * "('autoNum', 'autoNum', 'ValidStepName', 'sequenceStepId', 'Pass', 'paht to screenshots', 'request XML or JSON etc', 'response XML or JSON etc', '2018-06-18 16:26:37', '2018-06-18 16:26:38');\r\n"
	 * + ""; }
	 */

	public void updateReporterLog(String stepName, String Action, String value) {
		logger.info("Performed " + Action + " on object : " + this.element.getId() + "," + this.element.toString()
				+ " Text : " + element.getText() + "," + element.getTagName());

		String step = "Performed " + Action + " on object : " + element.getTagName() + "~" + element.getText();
		reporter.currentStep = step;
		if (Config.TAKESCREENSHOT_FOREACH_ACTION) {
			reporter.takeScreenshot();
		} else {
			reporter.childlog.info(step);

			if (!Config.LOCAL_RUN) {
				String stepSeqId = RunDetails.getStepSeqonScenarioSeq();
				RunDetails.currentStepSeqId = stepSeqId;
				RunDetails.insertActionsIntoDB(stepSeqId, step, value, "");
				logger.info("Call to save screenshot completed");
			}

		}

		// reporter.takeScreenshot(mobileDriver, "Performed "+ Action + " on object : "
		// +element.getTagName()+"~"+element.getText() , value);

	}

	private void enterNumber(String number) throws Throwable {
		if (null == element)
			throw new Throwable(": MB Actions : Element is null");
		if (DriverManagerFactory.getDriverData("Platform Name").equalsIgnoreCase("ANDROID")) {
			switch (number) {
			case "1":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_1);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_1));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "2":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_2);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_2));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "3":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_3);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_3));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "4":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_4);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_4));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "5":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_5);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_5));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "6":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_6);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_6));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "7":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_7);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_7));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "8":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_8);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_8));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "9":
				//(AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_9);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_9));
				logger.info("Entered :: " + number + " on " + element);
				break;
			case "0":
				//((AndroidDriver) mobileDriver).pressKeyCode(AndroidKeyCode.KEYCODE_NUMPAD_0);
				((AndroidDriver) mobileDriver).pressKey(new KeyEvent(AndroidKey.NUMPAD_0));
				logger.info("Entered :: " + number + " on " + element);
				break;
			}
		} else if (DriverManagerFactory.getDriverData("Platform Name").equalsIgnoreCase("IOS")) {
		}
	}
	/*
	 * <h1>swipeFromElement</h1> This method begin swiping from an element end co-orndiates to
	 * end of the screen
	 *
	 * @author sudharsanRaju
	 * @version 1.0
	 */
	public void swipeFromElement(String direction) throws Throwable {
		if (element == null)
			throw new Throwable(": MB Actions : Element is null");
		int leftX = element.getLocation().getX();
		int rightX = leftX + element.getSize().getWidth();
		int middleX = (rightX + leftX) / 2;
		int upperY = element.getLocation().getY();
		int lowerY = upperY + element.getSize().getHeight();
		int middleY = (upperY + lowerY) / 2;

		Dimension size = getScreenResolution();
		// point which is at right side of screen
		int width = (int) (size.width);
		int height = (int) (size.height);

		switch (direction.toUpperCase()) {
		case "RIGHT":
			logger.info(" :swipeFromElement: Swiping from [" + rightX + "," + middleY + "] to [" + leftX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(leftX, middleY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750)))
					.moveTo(PointOption.point(size.getWidth(), middleY)).release().perform();
			break;
		case "LEFT":
			logger.info(" :swipeFromElement: Swiping from [" + leftX + "," + middleY + "] to [" + rightX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(rightX, middleY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750))).moveTo(PointOption.point(0, middleY))
					.release().perform();
			break;
		case "UP":
			logger.info(" :swipeFromElement: Swiping from [" + leftX + "," + middleY + "] to [" + rightX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(middleX, middleY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750))).moveTo(PointOption.point(middleX, 0))
					.release().perform();
			break;
		case "DOWN":
			logger.info(" :swipeFromElement: Swiping from [" + leftX + "," + middleY + "] to [" + rightX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(middleX, middleY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750)))
					.moveTo(PointOption.point(middleX, size.getHeight())).release().perform();
			break;
		default:
			logger.error(" :swipeFromElement: Unknown direction");

		}
	}

	/*
	 * <h1>swipeWithInElement</h1> This method begin swiping from an element end co-orndiates to
	 * end of the screen
	 *
	 * @author sudharsanRaju
	 * @version 1.0
	 */
	public void swipeWithInElement(String direction) throws Throwable {
		if (element == null)
			throw new Throwable(": MB Actions : Element is null");
		int leftX = element.getLocation().getX();
		int rightX = leftX + element.getSize().getWidth();
		int middleX = (rightX + leftX) / 2;
		int upperY = element.getLocation().getY();
		int lowerY = upperY + element.getSize().getHeight();
		int middleY = (upperY + lowerY) / 2;

		Dimension size = getScreenResolution();
		// point which is at right side of screen
		int width = (int) (size.width);
		int height = (int) (size.height);

		switch (direction.toUpperCase()) {
		case "RIGHT":
			logger.info(" :swipeFromElement: Swiping from [" + rightX + "," + middleY + "] to [" + leftX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(leftX, middleY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750)))
					.moveTo(PointOption.point(rightX, middleY))
					.release().perform();
			break;
		case "LEFT":
			logger.info(" :swipeFromElement: Swiping from [" + leftX + "," + middleY + "] to [" + rightX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(rightX, middleY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750)))
					.moveTo(PointOption.point(leftX, middleY))
					.release().perform();
			break;
		case "UP":
			logger.info(" :swipeFromElement: Swiping from [" + leftX + "," + middleY + "] to [" + rightX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(middleX, lowerY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750)))
					.moveTo(PointOption.point(middleX, upperY))
					.release().perform();
			break;
		case "DOWN":
			logger.info(" :swipeFromElement: Swiping from [" + leftX + "," + middleY + "] to [" + rightX + "," + middleY
					+ "]");
			new TouchAction(mobileDriver).press(PointOption.point(middleX, upperY))
					.waitAction(WaitOptions.waitOptions(Duration.ofMillis(750)))
					.moveTo(PointOption.point(middleX, lowerY))
					.release().perform();
			break;
		default:
			logger.error(" :swipeFromElement: Unknown direction");

		}
	}	
	public void swipeHorizontal(String direction) throws Throwable {
		if(element == null)
			throw new Throwable(": MB Actions : Element is null");
		try {
		Dimension size = getScreenResolution();
		// point which is at right side of screen
		int rightdim = (int) (size.width * 0.20);
		// point which is at left side of screen.
		int leftdim = (int) (size.width * 0.80);

		switch (direction.toUpperCase()) {
		case "RIGHT":
			//touchAction.longPress(element).moveTo(rightdim, 580).release().perform();
			//touchAction.longPress(PointOption.point(rightdim, rightdim)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(500))).release().perform();
			touchAction.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(element))).moveTo(PointOption.point(rightdim, 580)).release().perform();
			break;

		case "LEFT":
			//touchAction.longPress(element).moveTo(leftdim, 580).release().perform();
			touchAction.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(element))).moveTo(PointOption.point(leftdim, 580)).release().perform();
			break;
		}
		}catch(Throwable t) {
			logger.error("Exception in swipeHorizontal method " + t.getLocalizedMessage());
			Config.gracefulEnd(t, logger);
			throw t;
		}

	}

}
