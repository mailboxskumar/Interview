package com.dbs.actions;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.dbs.commons.Reporter;
import com.dbs.commons.RunDetails;
import com.dbs.commons.StepListener;
import com.dbs.config.Config;

public class IB_Actions{
	WebElement element;
	WebDriver driver;
	String params;
	private By elementProperty;
	Reporter reporter = Reporter.getCurrentReporter();
	public static WebDriver driverForScreenshot;
	private static final Logger logger=Logger.getLogger(IB_Actions.class);

	public IB_Actions( WebElement strelement, WebDriver driver) {
		this.element = strelement;	
		this.driver = driver;
		driverForScreenshot = driver;
	}
	public IB_Actions( WebElement strelement, By elementProp, WebDriver driver) {
		this.element = strelement;
		this.elementProperty = elementProp;	
		this.driver = driver;
		driverForScreenshot = driver;
	}	
	public void click() {
		//element(element).waitUntilClickable();
		//clickOn(element);
		String actionName = Thread.currentThread().getStackTrace()[1].getMethodName();
		element.click();
		logger.info("Clicked on object"+element);
		updateReporterLog(StepListener.getListener().getStepName(), actionName,"");
	}
		
	public void enterText(String data) {
		element.clear();
		element.sendKeys(data);
		String actionName = "entered '"+data+"' ";
		logger.info("Entered text"+ data +"on object"+element);
		updateReporterLog(StepListener.getListener().getStepName(), actionName,"");
//		typeInto(element, data);
	}
	public boolean isEnabled(){
		boolean checkVal=element.isEnabled();
		if(checkVal){
			return checkVal;
		}
		else{
			return checkVal;
		}
	}
	public void clearText(String field){
		try{
			element.clear();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public boolean isDisabled(){
		boolean checkVal=element.isEnabled();
		if(!checkVal){
			//logMessage(elementName+ " should be disabled.", elementName+ " is disabled.", "Pass");
			return true;
		}
		else{
			//logMessage(elementName+ " should be disabled.", elementName+ " is not disabled.", "Fail");
			return false;
		}
	}
	public String getText() {
		return element.getText();
	}

	public boolean verifyText(String expectedValue) {
		return element.getText().equals(expectedValue);
	}

	public boolean ifExists() {
		return element.isDisplayed();
	}

	public void refreshPage(){
		driver.navigate().refresh();
	}
	public WebElement getElement() {
		return element;
	}
	public void doubleClick(){
		if ((driver != null) && (element != null))
			(new Actions(driver)).doubleClick(element).build().perform();	
	}
	
	public Map<String, String> getAttribute() {
		Map<String, String> attributeList = new LinkedHashMap<String, String>();
		try {
			if (element.isDisplayed()) {
				String[] parameters = { "tagName", "name", "type", "id",
						"value", "class", "src", "text", "href", "title" };
				String attributeValue = "";
				for (int i = 0; i < 10; i++) {
					attributeValue = element.getAttribute(parameters[i]);
					if (attributeValue == null || attributeValue.equals("")) {
						continue;
					} else {
						attributeList.put(parameters[i], attributeValue);
					}
				}
			} else {
				throw new Exception("Element does not exist");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return attributeList;
	}
	public void updateReporterLog(String stepName,String Action, String value) {
		//reporter.takeScreenshot(driver,Action +" performed on object : "+element,value);
		String step = Action +" performed on object : "+element;
		Reporter.currentStep = step;
		if(Config.TAKESCREENSHOT_FOREACH_ACTION) {
			reporter.takeScreenshot();
		}
		else {
			reporter.childlog.info(step);
			
			if(!Config.LOCAL_RUN) {
				String stepSeqId = RunDetails.getStepSeqonScenarioSeq();
				RunDetails.currentStepSeqId = stepSeqId;
				RunDetails.insertActionsIntoDB(stepSeqId,step,value,"");
				logger.info("Call to save screenshot completed");
			}			
		}
	}
	public boolean isExists(String checkField){
		boolean value=true;
		value=driver.getPageSource().contains(checkField);
		if(value){
			//logMessage(checkField+ " should not be present in page.",checkField+ " is present in page.", "Fail");
			value=false;
		}
		return value;
	}
	
	public void handleProgressBar() throws InterruptedException{
		int iSize = driver.getWindowHandles().size();
		while (iSize >= 2){
			Thread.sleep(10000);
			iSize    = driver.getWindowHandles().size();
		}
	}

	public void waitForElement() throws InterruptedException{
		for(int i=0;i<60;i++){
			if(element!=null || element != null)
				return;
			Thread.sleep(3000);
			System.out.println("Waiting");
		}
	}	
}
