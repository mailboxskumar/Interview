package com.dbs.util;

import javax.swing.JOptionPane;
import com.dbs.commons.POMCreater;
import com.dbs.config.Config;

public class CreatePageObjects {
	public static void main(String[] args){
		try {
			POMCreater pom = new POMCreater();
			Config.Logger();
			String[] choices = { "Create_Mobile_PageObjects", "Create_Browser_PageObjects", "Create_Both" };
			String input = (String) JOptionPane.showInputDialog(null, "Select the operation type", "DropDown",
					JOptionPane.QUESTION_MESSAGE, null, choices, choices[0]);
			switch (input) {
			case ("Create_Mobile_PageObjects"):
				if (pom.createPOMforMB())
					JOptionPane.showMessageDialog(null, "POM created successfully!!", "Generate Page Object for MB!",
							JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null, "Gloabl Util and POM created successfully!!",
							"Generate Page Object MB!", JOptionPane.INFORMATION_MESSAGE);
				break;
			case ("Create_Browser_PageObjects"):
				if (pom.createPOMforIB())
					JOptionPane.showMessageDialog(null, "POM created successfully!!", "Generate Page Object for IB!",
							JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null, "POM creation failed!!", "Generate Page Object  IB!",
							JOptionPane.INFORMATION_MESSAGE);
				break;

			case ("Create_Both"):
				if (pom.createPOMforIB() && pom.createPOMforMB())
					JOptionPane.showMessageDialog(null, "POM created successfully for MB&IB!!",
							"Generate Page Object & Global Util Code!", JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null, "POM creation failed!!", "Generate Page Object  IB!",
							JOptionPane.INFORMATION_MESSAGE);
				break;
			case (""):
				JOptionPane.showMessageDialog(null, "Invalid Option : Exiting...");
				break;
			}
		} catch (Throwable e) {
			JOptionPane.showMessageDialog(null, "Invalid Option : Exiting...");
		}
	}
}
