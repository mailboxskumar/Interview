package javaprograming.string;

public class SwapObjectsInJava {

	public static void main(String[] args) {
		
	}

}
