package javaprograming.string;

public class MethodOverridingWithCovariantReturnType {

	// Child Return type should be the Sub Type of Parent

	public static void main(String[] args) {


	}


}
