package javaprograming.exception;

public class ConceptsExpection {

	public static void main(String[] args) {
		

	}

}
