package javaprograming.abstraction;

public interface InterfaceExample {

	int testdata = 0;
	String interfaceString = "";
	boolean flag = false;
	double salary = 0.00;

	void add();

	void substarct();

	void multiple();

	String division();

	boolean isTrue();

}
