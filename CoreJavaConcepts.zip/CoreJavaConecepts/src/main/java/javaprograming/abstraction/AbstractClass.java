package javaprograming.abstraction;

public abstract class AbstractClass {

}
