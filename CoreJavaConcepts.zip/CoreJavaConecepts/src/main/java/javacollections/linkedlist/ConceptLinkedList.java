package javacollections.linkedlist;

public class ConceptLinkedList {

	public static void main(String[] args) {
		

	}

}
