package com.wb.java_af.mobile.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.RemoteWebElement;

import com.aventstack.extentreports.ExtentTest;
import com.perfecto.reportium.client.ReportiumClient;
import com.wb.java_af.qc.QCDetails;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;
import junit.framework.Assert;

public class LoginPageSteps {
	
	AppiumDriver<RemoteWebElement> appiumDriver = ConcurrentEngines.getEngine().getAppiumDriver();
	ExtentTest report = ExtentTestManager.getTest();
	ReportiumClient reportiumClient = ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance();
	
	@Given("^I am on the retail application$")
	@QCDetails(testCaseId = 23949357)
	public void i_am_in_Webster_online_login_page() {
		reportiumClient.stepStart("I am on the retail application");
		appiumDriver.launchApp();
		String appPackage = (String) appiumDriver.getCapabilities().getCapability("appPackage");
		Assert.assertEquals("com.malauzai.websterbank", appPackage);
		report.info("App package is "+appPackage);
		LogUtility.logInfo("App package is "+appPackage);
		try {
			RemoteWebElement forgotPasswordLink = appiumDriver.findElement(By.id("com.malauzai.websterbank:id/b_revert"));
			if(forgotPasswordLink.isDisplayed()) {
				forgotPasswordLink.click();
			}
		} catch (NoSuchElementException ne) {
			LogUtility.logInfo("User is taken to the username page");
		}
		reportiumClient.stepEnd();
				
	}
	
	@Then("^I see the username and password textboxes$")
	public void i_see_the_username_and_password_textboxes() {
		reportiumClient.stepStart("I see the username and password textboxes");
		Assert.assertTrue(appiumDriver.findElement(By.id("com.malauzai.websterbank:id/username_entry")).isDisplayed());
		report.info("User name field is displayed.");
		Assert.assertTrue(appiumDriver.findElement(By.id("com.malauzai.websterbank:id/password_entry")).isDisplayed());
		report.info("Password field is displayed.");
		LogUtility.logInfo("UserName and Password field is displayed!");
		reportiumClient.stepEnd();
	}
	
	@Then("^I also see login button$")
	public void i_also_see_login_button() {
		reportiumClient.stepStart("I also see login button");
		Assert.assertTrue(appiumDriver.findElement(By.id("com.malauzai.websterbank:id/b_submit")).isDisplayed());
		report.info("Login field is displayed.");
		LogUtility.logInfo("Login field is displayed!");
		reportiumClient.stepEnd();
	}
	
	@Then("^I enter the username as \"(.*?)\"$")
	public void i_enter_username(String userName) {
		reportiumClient.stepStart("I enter the username as "+userName);
		appiumDriver.findElement(By.id("com.malauzai.websterbank:id/username_entry")).clear();
		appiumDriver.findElement(By.id("com.malauzai.websterbank:id/username_entry")).sendKeys(userName);
		report.info("Entered the username as "+userName);
		LogUtility.logInfo("Entered the username as "+userName);
		reportiumClient.stepEnd();
	}
	
	@Then("^I enter the password as \"(.*?)\"$")
	public void i_enter_password(String password) {
		reportiumClient.stepStart("I enter the password as "+password);
		appiumDriver.findElement(By.id("com.malauzai.websterbank:id/password_entry")).sendKeys(password);
		report.info("Entered the username as "+password);
		LogUtility.logInfo("Entered the username as "+password);
		reportiumClient.stepEnd();
	}
	
	
	@Then("^I enter the verification answer as \"(.*?)\" and click on OK$")
	public void i_enter_the_verification_answer(String answer) {
		reportiumClient.stepStart("I enter the verification answer as "+answer);
		try {
			RemoteWebElement securityAnswer = appiumDriver.findElement(By.id("//*[@resourceid='com.malauzai.websterbank:id/answer']"));
			if(securityAnswer.isDisplayed()) {
				securityAnswer.sendKeys(answer);
				appiumDriver.findElement(By.xpath("//*[@resourceid='android:id/button1']")).click();
				report.info("Entered the security answer as "+answer);
				LogUtility.logInfo("Entered the security answer as "+answer);
			}
		} catch (NoSuchElementException ne) {
			LogUtility.logInfo("User is logged in!!");
		}
		reportiumClient.stepEnd();
	}
	
	@When("^I click on Login button$")
	public void i_click_on_login_button() {
		reportiumClient.stepStart("I click on Login button");
		appiumDriver.findElement(By.id("com.malauzai.websterbank:id/b_submit")).click();
		report.info("Clicked on the Login button.");
		reportiumClient.stepEnd();
	}
	
	@Then("^I see View Accounts page$")
	public void i_see_View_Accounts_page() throws Throwable {
		try {
			reportiumClient.stepStart("I see View Accounts page");
			RemoteWebElement viewAccountsText = appiumDriver.findElement(By.id("com.malauzai.websterbank:id/title"));
			Assert.assertTrue(viewAccountsText.isDisplayed());
			report.info("View Accounts page is displayed.");
		} catch (NoSuchElementException ne) {
			report.fail("View Accounts element was not found");
		}
		reportiumClient.stepEnd();
	}
}
