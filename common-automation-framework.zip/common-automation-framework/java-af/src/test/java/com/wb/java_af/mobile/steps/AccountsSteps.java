package com.wb.java_af.mobile.steps;

import com.aventstack.extentreports.ExtentTest;
import com.wb.java_af.pages.UnitTestAccountsPage;
import com.wb.java_af.reporting.ExtentTestManager;

import cucumber.api.java.en.Then;

public class AccountsSteps{
	UnitTestAccountsPage account = new UnitTestAccountsPage();
	ExtentTest report = ExtentTestManager.getTest();
	
	  @Then("^I see account summary page$") public void
	  i_see_account_summary_page() throws Throwable { account.verifyAccountsPage();
	  report.info("User able to see the accounts text in accounts summary page");
	  
	  }
	 

}
