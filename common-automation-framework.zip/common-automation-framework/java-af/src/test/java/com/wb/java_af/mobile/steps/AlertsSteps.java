package com.wb.java_af.mobile.steps;

import java.util.List;

import com.aventstack.extentreports.ExtentTest;
import com.perfecto.reportium.client.ReportiumClient;
import com.wb.java_af.pages.UnitTestManageAlertsPage;
import com.wb.java_af.pages.UnitTestSettingsPage;
import com.wb.java_af.pages.UnitTestViewAccountsPage;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AlertsSteps {
	
	ExtentTest extentReport = ExtentTestManager.getTest();
	UnitTestViewAccountsPage viewAccountsPage = new UnitTestViewAccountsPage();
	UnitTestManageAlertsPage manageAlertsPage = new UnitTestManageAlertsPage();
	UnitTestSettingsPage settingsPage = new UnitTestSettingsPage();
	ReportiumClient reportiumClient = ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance();

	@Then("^View Accounts page is displayed$")
	public void accounts_page_is_displayed() throws Throwable {
		reportiumClient.stepStart("View Accounts page is displayed");
		try {
			viewAccountsPage.verifyViewAccountsPageTitle();
			extentReport.pass("View Account Page is displayed");
		} catch (Exception e) {
			extentReport.fail("View Accounts Page not displayed after login " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I clicked on Settings icon$")
	public void i_clicked_on_Settings_icon() throws Throwable {
		reportiumClient.stepStart("I clicked on Settings icon");
		try {
			viewAccountsPage.clickSettingsIcon();
			extentReport.pass("Clicked on Settings Icon");
		} catch (Exception e) {
			extentReport.fail("Unable to click on settings icon " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I clicked on Manage Alerts text$")
	public void i_clicked_on_Manage_Alerts_text() throws Throwable {
		reportiumClient.stepStart("I clicked on Manage Alerts text");
		try {
			settingsPage.clickManageAlerts();
			extentReport.pass("Clicked on Manage Alerts option");
		} catch (Exception e) {
			extentReport.fail("Unable to click Manage Alerts Option " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I clicked on Account Alerts text$")
	public void i_clicked_on_Account_Alerts_text() throws Throwable {
		reportiumClient.stepStart("I clicked on Account Alerts text");
		try {
			manageAlertsPage.clickAccountAlertsOption();
			extentReport.pass("Clicked on Account alerts option");
		} catch (Exception e) {
			extentReport.fail("Unable to click on Account Alerts Option " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I clicked on Account Alerts text to verify error message$")
	public void i_clicked_on_Account_Alerts_text_to_verify_error_message() throws Throwable {
		reportiumClient.stepStart("I clicked on Account Alerts text to verify error message");
		try {
			manageAlertsPage.clickAccountAlerts();
			extentReport.pass("Clicked on Account alerts option");
		} catch (Exception e) {
			extentReport.fail("Unable to click on Account Alerts Option " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^All accounts should display with balances$")
	public void all_accounts_should_display_with_balances() throws Throwable {
		reportiumClient.stepStart("All accounts should display with balances");
		try {
			manageAlertsPage.getListOfAccounts();
			extentReport.pass("Accounts displayed");
		} catch (Exception e) {
			extentReport.fail("Unable to retrieve the accounts displayed " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I select any Account$")
	public void i_select_any_Account() throws Throwable {
		reportiumClient.stepStart("I select any Account");
		try {
			String accountClicked = manageAlertsPage.clickOnAnyAccount();
			extentReport.pass("Clicked on any Account " + accountClicked);
		} catch (Exception e) {
			extentReport.fail("Unable to click on any account " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^I verify selected account is displayed with last four digits of account number$")
	public void i_verify_selected_account_is_displayed_with_last_four_digits_of_account_number() throws Throwable {
		reportiumClient.stepStart("I verify selected account is displayed with last four digits of account number");
		try {
			manageAlertsPage.verifyLastFourDigitsDisplayed();
			extentReport.pass("Verified last four digits displayed");
		} catch (Exception e) {
			extentReport.fail("Unable to verify the account number displayed with last four digits " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^I see \"([^\"]*)\"$")
	public void i_see(String labelName) throws Throwable {
		reportiumClient.stepStart("I see "+labelName);
		try {
			manageAlertsPage.verifyLabelName(labelName);
			extentReport.pass("Verified label name " + labelName);
		} catch (Exception e) {
			extentReport.fail("Unable to verify the label name " + labelName + " due to " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I clicked on Text icon in alerts page$")
	public void i_clicked_on_Text_icon_in_alerts_page() throws Throwable {
		reportiumClient.stepStart("I clicked on Text icon in alerts page");
		try {
			manageAlertsPage.clickOnTextIcon();
			extentReport.pass("Clicked on Text Icon in alerts page");
		} catch (Exception e) {
			extentReport.fail("Unable to click on Text Icon " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^I verify Text Alerts screen display \"([^\"]*)\"$")
	public void i_verify_Text_Alerts_screen_display(String textIconMessage) throws Throwable {
		reportiumClient.stepStart("I verify Text Alerts screen display "+textIconMessage);
		try {
			manageAlertsPage.verifyTextAlertsScreenMessage(textIconMessage);
			extentReport.pass("Verified the Message of Text Icon in Alerts Screen");
		} catch (Exception e) {
			extentReport.fail("Unable to verify the Text Alerts Screen Message " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^I verify \"([^\"]*)\"$")
	public void i_verify(String dataRatesMessage) throws Throwable {
		reportiumClient.stepStart("I verify "+dataRatesMessage);
		try {
			manageAlertsPage.verifyDataRatesMessage(dataRatesMessage);
			extentReport.pass("Verified the data rates may apply message");
		} catch (Exception e) {
			extentReport.fail("Unable to verify the message " + dataRatesMessage);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^I verify Primary Phone and Secondary Phone number should display$")
	public void i_verify_Primary_Phone_and_Secondary_Phone_number_should_display() throws Throwable {
		reportiumClient.stepStart("I verify Primary Phone and Secondary Phone number should display");
		try {
			manageAlertsPage.verifyNumberTextFields();
			extentReport.pass("Verified the Primary and Secondary Phone number text fields");
		} catch (Exception e) {
			extentReport.fail("Unable to verify the Primary phone or Secondary phone number " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^Selected account displays threshold amount options$")
	public void selected_account_displays_threshold_amount_options() throws Throwable {
		reportiumClient.stepStart("Selected account displays threshold amount options");
		try {
			manageAlertsPage.verifyThresholdAmountOptions();
			extentReport.pass("Verified the threshold amount options");
		} catch (Exception e) {
			extentReport.fail("Unable to verify the Threashold amounts Options " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I clicked on any threshold amount type alert$")
	public void i_clicked_on_any_threshold_amount_type_alert() throws Throwable {
		reportiumClient.stepStart("I clicked on any threshold amount type alert");
		try {
			manageAlertsPage.clickOnAnyThresholdAmount();
			extentReport.pass("Clicked on Threshold amount option");
		} catch (Exception e) {
			extentReport.fail("Unable to click on Threshold amount option " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^Enter Amount Popup displays$")
	public void popup_displays() throws Throwable {
		reportiumClient.stepStart("Enter Amount Popup displays");
		try {
			manageAlertsPage.enterAmountPopupDisplay();
			extentReport.pass("Enter amount popup displayed and verified the elements on it");
		} catch (Exception e) {
			extentReport.fail("Enter amountPopup is not displayed " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I enter \"([^\"]*)\" balance$")
	public void i_enter_balance(String amount) throws Throwable {
		reportiumClient.stepStart("I enter "+amount);
		try {
			manageAlertsPage.enterAmount(amount);
			extentReport.pass("Entered amount" + amount);
		} catch (Exception e) {
			extentReport.fail("Unable to enter amount " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@When("^I clicked on Save button$")
	public void i_clicked_on_Save_button() throws Throwable {
		reportiumClient.stepStart("I clicked on Save button");
		try {
			manageAlertsPage.clickSaveButton();
			extentReport.pass("Clicked on Save button");
		} catch (Exception e) {
			extentReport.fail("Unable to click on Save button " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^System should display \"([^\"]*)\" with ok button$")
	public void system_should_display_with_ok_button(String error) throws Throwable {
		reportiumClient.stepStart("System should display "+error);
		try {
			manageAlertsPage.verifyThresholdErrorMessage(error);
			extentReport.pass("Error message displayed when entered amount zero with ok button as " + error);
		} catch (Exception e) {
			extentReport.fail("Error message is not displayed " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^Error message displayed \"([^\"]*)\"$")
	public void error_message_displayed(String errorMessage) throws Throwable {
		reportiumClient.stepStart("Error message displayed "+errorMessage);
		try {
			manageAlertsPage.verifyErrorMessageForClosedAccounts(errorMessage);
			extentReport.pass("Error message displayed in alerts page for closed accounts " + errorMessage);
		} catch (Exception e) {
			extentReport.fail("Error message is not displayed " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^List of accounts displayed$")
	public void list_of_accounts_displayed() throws Throwable {
		reportiumClient.stepStart("List of accounts displayed");
		try {
			manageAlertsPage.getListOfAccounts();
			extentReport.pass("List of accounts displayed");
		} catch (Exception e) {
			extentReport.fail("List of account not displayed " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^Ineligible accounts should not display like Loan and Credit Card$")
	public void ineligible_accounts_should_not_display_like_Loan_and_Credit_Card() throws Throwable {
		reportiumClient.stepStart("Ineligible accounts should not display like Loan and Credit Card");
		try {
			List<String> verifyaccts = manageAlertsPage.getListOfAccounts();
			verifyaccts.size();

			extentReport.pass("Verified loan and credit card accounts are not diplayes");
		} catch (Exception e) {
			extentReport.fail("Loan and Credit Card accounts are also displayed " + e);
			throw new Exception();
		}
		reportiumClient.stepEnd();
	}

	@Then("^Ineligible accounts should not display like Closed and NA accounts$")
	public void ineligible_accounts_should_not_display_like_Closed_and_NA_accounts() throws Throwable {
		reportiumClient.stepStart("Ineligible accounts should not display like Closed and NA accounts");
		reportiumClient.stepEnd();
	}
}
