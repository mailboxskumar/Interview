package com.wb.java_af.web.testngTests;

import org.testng.annotations.Test;

import com.wb.java_af.qc.QCDetails;
import com.wb.java_af.testbases.TestNgBase;

public class LoginPageTests extends TestNgBase{

	@Test
	@QCDetails(testCaseId = 76327437)
	public void login() {
		
	/*	EventFiringWebDriver driver = ConcurrentEngines.getEngine().getWebDriver();
		ExtentTest report = ExtentTestManager.getTest();
		
		report.info("WOL application is launched.");
		driver.findElement(By.name("username")).sendKeys(envParams.getUsername());
		report.info("Entered the username");
		ConcurrentEngines.getEngine().getWait().waitForPageReadyState();
		driver.findElement(By.name("submit1")).click();
		report.info("Clicked on the go button");
		driver.findElement(By.id("password__input")).sendKeys(envParams.getPassword());
		report.info("Entered the password as" +envParams.getPassword());
		driver.findElement(By.id("continueButton_ff__buttonText")).click();
		report.info("Clicked on the Continue button.");
		ConcurrentEngines.getEngine().getWait().waitForPageReadyState();
		ConcurrentEngines.getEngine().getNavigator();
		*/
	}
}
