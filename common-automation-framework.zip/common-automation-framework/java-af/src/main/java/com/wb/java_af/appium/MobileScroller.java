package com.wb.java_af.appium;

import java.time.Duration;

import org.openqa.selenium.Dimension;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.utilities.LogUtility;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class MobileScroller {

	private Engine engine;
	MobileElement element;

	public MobileScroller(Engine engine) {
		
		this.engine=engine;
	
	}
	//AppiumDriver<RemoteWebElement> mobiledriver = engine.getAppiumDriver();

	public Dimension getScreenResolution() {
			Dimension resolution = engine.getAppiumDriver().manage().window().getSize();
			return resolution;
		}
	 
	 
	 
	 public int[] getScreenCoordinates() throws InterruptedException {

			int startx = 0;
			int endx = 0;
			int starty = 0;
			int[] co_ordinates = { startx, endx, starty };
			// Get the size of screen.
			Dimension size = engine.getAppiumDriver().manage().window().getSize();
			LogUtility.logInfo("Screen size is...." + size);

			// Find swipe start and end point from screen's width and height.
			// Find startx point which is at right side of screen.

			startx = (int) (size.width * 0.70);
			// Find endx point which is at left side of screen.
			endx = (int) (size.width * 0.30);
			// Find vertical point where you wants to swipe. It is in middle of
			// screen height.
			starty = size.height / 2;
			// Find endy point which is at top side of screen.
			int endy = (int) (size.height * 0.20);
			// Find horizontal point where you wants to swipe. It is in middle of
			// screen width.

			LogUtility.logInfo("startx = " + startx + " ,endx = " + endx + " , starty = " + starty + ",endy = " + endy);
			return co_ordinates;
		}
	 
	 
	 
	 public void swipeHorizontally(String direction) throws Throwable {
			try {
				if (element == null)
					throw new Throwable(": Mobile Actions : Element is null");
				
				Dimension size = getScreenResolution();
				// point which is at right side of screen
				int rightdim = (int) (size.width * 0.20);
				// point which is at left side of screen.
				int leftdim = (int) (size.width * 0.80);
				
				switch (direction.toUpperCase()) {
				case "RIGHT":
					
					new TouchAction<>(engine.getAppiumDriver()).longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(element)))
							.moveTo(PointOption.point(rightdim, 580)).release().perform();
					break;

				case "LEFT":
					new TouchAction<>(engine.getAppiumDriver()).longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(element)))
							.moveTo(PointOption.point(leftdim, 580)).release().perform();
					break;
				}
			} catch (Throwable t) {
				LogUtility.logInfo("Exception in swipeHorizontal method " + t.getLocalizedMessage());
				throw t;
			}

	 
	 }
	 
	 protected boolean Swipe(int startHeightX, int startWidthX, int endHeightY, int entWidthY ,long duration) {
			try {
				new TouchAction<>(engine.getAppiumDriver()).press(PointOption.point(startWidthX, startHeightX))
						.waitAction(WaitOptions.waitOptions(Duration.ofMillis(duration)))
						.moveTo(PointOption.point(entWidthY, endHeightY)).release().perform();
			} catch (Throwable t) {
				LogUtility.logError("Returning 'false', Error while swiping :: " + t.getLocalizedMessage());
				return false;
			}
			return true;
		}

	
	public enum DIRECTION {
	    DOWN, UP, LEFT, RIGHT;
	}
	
	public void swipe(DIRECTION direction, long time) {
	    Dimension size = engine.getAppiumDriver().manage().window().getSize();

	    int startX = 0;
	    int endX = 0;
	    int startY = 0;
	    int endY = 0;

	    switch (direction) {
	        case RIGHT:
	            startY = (int) (size.height / 2);
	            startX = (int) (size.width * 0.90);
	            endX = (int) (size.width * 0.05);
	            new TouchAction<>(engine.getAppiumDriver()).press(PointOption.point(startX, startY))
	            .waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
	            .moveTo(PointOption.point(startX, startY)).release().perform();
                LogUtility.logInfo("Swipe action is successfully done to RIGHT direction");
	            break;

	        case LEFT:
	            startY = (int) (size.height / 2);
	            startX = (int) (size.width * 0.05);
	            endX = (int) (size.width * 0.90);
	            new TouchAction<>(engine.getAppiumDriver()).press(PointOption.point(startX, startY))
	            .waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
	            .moveTo(PointOption.point(endX, startY)).release().perform();
	            LogUtility.logInfo("Swipe action is successfully done to LEFT direction");
	            break;
                
	        case UP:
	            endY = (int) (size.height * 0.70);
	            startY = (int) (size.height * 0.30);
	            startX = (size.width / 2);
	            new TouchAction<>(engine.getAppiumDriver()).press(PointOption.point(startX, startY))
	            .waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
	            .moveTo(PointOption.point(endX, startY)).release().perform();
	            LogUtility.logInfo("Swipe action is successfully done to UP direction");
	            break;


	        case DOWN:
	            startY = (int) (size.height * 0.70);
	            endY = (int) (size.height * 0.30);
	            startX = (size.width / 2);
	            new TouchAction<>(engine.getAppiumDriver()).press(PointOption.point(startX, startY))
	            .waitAction(WaitOptions.waitOptions(Duration.ofMillis(time)))
	            .moveTo(PointOption.point(startX, endY)).release().perform();
	            LogUtility.logInfo("Swipe action is successfully done to DOWN direction");
	            break;
	    }
	}
          
	public void scroll(int startx, int starty, int endx, int endy) {

		new TouchAction<>(engine.getAppiumDriver()).longPress(PointOption.point(startx, starty))
		.moveTo(PointOption.point(endx, endy))
		.release()
		.perform();
		}
	
	
	public void scrollDown() {

		//The viewing size of the device
		Dimension size = engine.getAppiumDriver().manage().window().getSize();

		//Starting y location set to 80% of the height (near bottom)
		int starty = (int) (size.height * 0.80);
		//Ending y location set to 20% of the height (near top)
		int endy = (int) (size.height * 0.20);
		//x position set to mid-screen horizontally
		int startx = (int) size.width / 2;

		scroll(startx, starty, startx, endy);
		LogUtility.logInfo("It is scroll down to the screen");
	}
	
}
