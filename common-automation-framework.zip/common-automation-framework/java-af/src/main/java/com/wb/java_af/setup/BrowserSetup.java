package com.wb.java_af.setup;

import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.Platform;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class BrowserSetup {
	
	public static DesiredCapabilities getGridCapabilities(Properties props){
		return getCapabilities("grid.capability", props);
	}
	
	private final static DesiredCapabilities getCapabilities(String prefix, Properties props) {
		DesiredCapabilities caps = new DesiredCapabilities();
		Set<Object> set = props.keySet();
		for(Object key : set) {
			String keyString = key.toString();
			if(keyString.startsWith(prefix)){
				if(props.getProperty(keyString).equalsIgnoreCase("true")) {
					caps.setCapability(keyString.substring(keyString.lastIndexOf(".")+1), true);
				} else if(props.getProperty(keyString).equalsIgnoreCase("false")) {
					caps.setCapability(keyString.substring(keyString.lastIndexOf(".")+1), false);
				}
			} else {
				caps.setCapability(keyString.substring(keyString.lastIndexOf(".")+1), props.getProperty(keyString));
			}
		}
		return caps;
	}

	public static DesiredCapabilities getSetupChrome(){
		DesiredCapabilities capability = DesiredCapabilities.chrome();
		capability.setCapability(CapabilityType.SUPPORTS_ALERTS, true);
		return capability;
	}
	
	public static DesiredCapabilities getSetupRemoteFirefox(){
		DesiredCapabilities capability = DesiredCapabilities.firefox();
		capability.setBrowserName("firefox");
		return capability;
	}
	

	public static DesiredCapabilities getSetupLocalFirefox(){
		DesiredCapabilities capability = DesiredCapabilities.firefox();
		capability.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
		capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capability.setCapability(CapabilityType.SUPPORTS_ALERTS, true);
		return capability;
	}
	

	public static FirefoxProfile getFirefoxProfile(){
		FirefoxProfile ffProfile = new FirefoxProfile();
		ffProfile.setPreference("webdriver.firefox.useExisting", true);
		ffProfile.setPreference("browser.cache.disk.enable", false);
		ffProfile.setPreference("browser.cache.memory.enable", false);
		return ffProfile;
	}

	public static DesiredCapabilities getSetupInternetExplorer(){
		DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
		capability.setCapability(CapabilityType.VERSION, "10");
		capability.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
		capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capability.setCapability(CapabilityType.SUPPORTS_ALERTS, true);
		return capability;
	}
	
	public static Platform getPlatform(String platform){
		switch(platform) {
		case "WINDOWS": return Platform.WINDOWS;
		case "MAC": return Platform.MAC;
		case "LINUX": return Platform.LINUX;
		default: throw new UnsupportedOperationException(platform + " is not supported.");
		}
	}
	
}