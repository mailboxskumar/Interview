package com.wb.java_af.setup;

public class Enums {
	
	public enum LoggingLevel {
		DEBUG(0),
		INFO(1),
		WARN(2),
		ERROR(3),
		FATAL(4),
		FORMATTING(5);
		
		private int value;
		
		private LoggingLevel(int value) {
			this.value = value;
		}
		
		public int getLoggingLevel(){
			return value;
		}
	}
	
	public enum Browser {
		
		CHROME,
		FIREFOX,
		IE,
		EDGE,
		SAFARI;
	}
	
	public enum DeviceType {
		Apple,
		Google;
	}
	
	public enum TestOutcome {
		PASSED,
		FAILED,
		INCONCLUSIVE,
		TIMEOUT,
		ABORTED
	}
	
	public enum PerfectoTap {
		TAP("tap"), NONE("notap"), DOWN("down"), UP("up");
		
		private String property;
		
		private PerfectoTap(String property) {
			this.property = property;
		}
		
		public String getProperty(){
			return property;
		}
	}
	
}
