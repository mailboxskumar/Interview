package com.wb.java_af.engine;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;

/**
 * Provides a library of methods to perform scroll actions on a web page. 
 *
 * <p>
 * Scrolling functions for top, bottom, edge on a webpage.
 * </p>
 *
 * @see	  	Scroller
 * 
 * @author Bharat Pandey
 */
public class Scroller {

	public Scroller(Engine engine) {
		this.engine = engine;
	}

	private Engine engine;

	/**
	 * Scolls to the top of the page
	 * 
	 */
	public void scrollToTopOfPage() {
		scrollTo("document.body.offsetLeft", "0");
	}

	/**
	 * Scrolls to the bottom of the page
	 * 
	 */
	public void scrollToBottomOfPage() {
		scrollTo("document.body.offsetLeft", "document.body.scrollHeight");
	}

	/**
	 * Scrolls to the left of the page
	 * 
	 */
	public void scrollToLeftEdgeOfPage() {
		scrollTo("0", "document.body.offsetTop");
	}

	/**
	 * Scrolls to the right edge of the page
	 * 
	 */
	public void scrollToRightEdgeOfPage() {
		scrollTo("document.body.scrollWidth", "document.body.offsetTop");
	}

	/**
	 * Scrolls to a new point represented by the WebElement
	 * 
	 * @param element
	 * 
	 */
	public void scrollWindowToElement(WebElement element) {
		Point point = null;
		int x = element.getLocation().getX();
		int y = element.getLocation().getY();
		point = new Point(x, y);
		scrollTo(point.x, point.y);
	}

	public void scrollTo(int horizontal, int vertical) {
		engine.getJavaScript().execute("window.scrollTo(" + horizontal + "," + vertical + ");");
	}

	public void scrollTo(String horizontal, String vertical) {
		engine.getJavaScript().execute("window.scrollTo(" + horizontal + "," + vertical + ");");
	}

	public void scrollBy(int horizontal, int vertical) {
		engine.getJavaScript().execute("window.scrollBy(" + horizontal + "," + vertical + ");");
	}

	public void scrollInnerScrollerToTop(WebElement element) {
		scrollInnerScrollerTo(element, "arguments[0].scrollLeft", "0");
	}

	public void scrollInnerScrollerToBottom(WebElement element) {
		scrollInnerScrollerTo(element, "arguments[0].scrollLeft", "arguments[0].scrollHeight");
	}

	public void scrollInnerScrollerToLeftEdge(WebElement element) {
		scrollInnerScrollerTo(element, "0", "arguments[0].scrollTop");
	}

	public void scrollInnerScrollerToRightEdge(WebElement element) {
		scrollInnerScrollerTo(element, "arguments[0].scrollWidth", "arguments[0].scrollTop");
	}

	public void scrollInnerScrollerTo(WebElement element, String horizontal, String vertical) {
		engine.getJavaScript().execute("arguments[0].scrollLeft = " + horizontal, element);
		engine.getJavaScript().execute("arguments[0].scrollTop = " + vertical, element);
	}

	public void scrollInnerScrollerBy(WebElement element, String horizontal, String vertical) {
		engine.getJavaScript().execute("arguments[0].scrollLeft += " + horizontal, element);
		engine.getJavaScript().execute("arguments[0].scrollTop += " + vertical, element);
	}

	/**
	 * scroll the current windows to a certain element
	 * 
	 * @param element
	 */
	public void scrollToElement(WebElement element) {
		engine.getWait().staticWait(3);
		try {
			engine.getJavaScript().execute("arguments[0].scrollIntoView(true);", element);
			engine.getWait().waitUntilElementIsPresent(element);
		} catch (Exception e) {

		}
	}

	/**
	 * scroll the screen all the way to the top
	 * 
	 */
	public void scrollUp() {
		engine.getWait().staticWait(3);
		engine.getJavaScript().execute("window.scrollTo(document.body.scrollHeight,0)");
		engine.getWait().staticWait(3);
	}

	
	/**
	 * scroll the screen about 800 pixels down, attempting to get in the middle of
	 * the screen or close, assuming the screen is initially on top
	 * 
	 */
	public boolean scrollMiddle() {
		// screen resolution Wide 1920 x height 1080
		// Return the total height of the screen
		Long num = (Long) engine.getJavaScript().execute("var num = document.body.scrollHeight; return num;");
		boolean b = false;

		if (num > 2200) {
			engine.getWait().staticWait(3);
			engine.getJavaScript().execute("window.scrollBy(0,980)", "");
			engine.getWait().staticWait(3);
			b = true;
		}

		return b;
	}

	/**
	 * scroll the screen all the way to the bottom
	 * 
	 */
	public boolean scrollDown() {
		Long num = (Long) engine.getJavaScript().execute("var num = document.body.scrollHeight; return num;");
		boolean b = false;

		if (num > 1200) {
			engine.getWait().staticWait(3);
			engine.getJavaScript().execute("window.scrollTo(0,document.body.scrollHeight)");
			engine.getWait().staticWait(3);
			b = true;
		}
		return b;
	}
}
