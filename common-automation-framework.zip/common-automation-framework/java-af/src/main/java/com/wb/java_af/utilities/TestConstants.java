package com.wb.java_af.utilities;

import java.io.File;

public class TestConstants {
	
	public static final String OS_NAME = "os.name";
	public static final String WINDOWS = "Windows";
	public static final String MAC = "Mac";
	public static final String LINUX = "Linux";
	
	public static final String FIREFOX = "firefox";
	public static final String CHROME = "chrome";
	public static final String IE = "ie";
	
	public static final String CHROME_WEB_DRIVER = "webdriver.chrome.driver";
	public static final String GECKO_WEB_DRIVER = "webdriver.gecko.driver";
	public static final String IE_WEB_DRIVER = "webdriver.ie.driver";
	public static final String TRUE_SETTINGS = "true";
	public static final String USER_DIR = "user.dir";
	public static final long WAIT_THREAD = 1000;
	
	public static final char FP = File.separatorChar;
}
