package com.wb.java_af.pages;

import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class UnitTestAccountsPage {

	public UnitTestAccountsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(ConcurrentEngines.getEngine().getAppiumDriver()), this);
	}

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label=\"VIEW ACCOUNTS\"]")
	@CacheLookup
	protected MobileElement lblAccountPageText;

	public boolean verifyAccountsPage() {
		LogUtility.logInfo("Verification of Account title in accounts page");
		ConcurrentEngines.getEngine().getWait().staticWait(18);
		if (lblAccountPageText.isDisplayed()) {
			LogUtility.logInfo("Acconts head text displayed as : " + lblAccountPageText.getText());
			return true;
		} else
			return false;
	}
}
