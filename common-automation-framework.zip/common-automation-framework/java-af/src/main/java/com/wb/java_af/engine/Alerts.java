package com.wb.java_af.engine;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Holder class for alerts.
 * 
 * <p>
 * Extends selenium’s capability to handle alert in a failsafe mode. 
 * </p>
 * 
 * @author Bharat Pandey
 * @see Alerts
 */
public class Alerts {

	private Engine engine;
	private Alert alert;

	public Alerts(Engine engine) {
		this.engine = engine;
	}

	/**
	 * Accepts alert on a webpage.
	 * 
	 * @see Alerts
	 * 
	 */
	public void acceptAlert() {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getWebDriver().switchTo().alert();
			alert.accept();
		} catch (NoAlertPresentException e) {
			LogUtility.logException("acceptAlert", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Checks to verify if an alert is present on a webpage.
	 * 
	 * @return true or false
	 * 
	 * @see Alerts
	 */
	public boolean isAlertPresent() {
		boolean presentFlag = false;
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getWebDriver().switchTo().alert();
			presentFlag = true;
		} catch (NoAlertPresentException e) {
			LogUtility.logException("isAlertPresent", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			presentFlag = false;
		}
		return presentFlag;
	}

	/**
	 * Dismisses an alert.
	 * 
	 * @see Alerts
	 */
	public void dismissAlert() {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getWebDriver().switchTo().alert();
			alert.dismiss();
		} catch (NoAlertPresentException e) {
			LogUtility.logException("acceptDismiss", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Enters text in an alert.
	 * 
	 * @param keysToSend
	 * 
	 * @see Alerts
	 */
	public void sendKeysToAlert(String keysToSend) {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getWebDriver().switchTo().alert();
			alert.sendKeys(keysToSend);
		} catch (NoAlertPresentException e) {
			LogUtility.logException("sendKeysToAlert", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Gets text from alert.
	 * 
	 * @see Alerts
	 */
	public String getTextFromAlert() {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getWebDriver().switchTo().alert();
			return alert.getText();
		} catch (NoAlertPresentException e) {
			LogUtility.logException("getTextFromAlert", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	
	
	/**
	 * authenticate an alert by passing the credentials
	 * 
	 * @param userName
	 * @param password
	 * 
	 * @see Alerts
	 */
	public void authenticateAlert(String userName, String password) {
		alert = engine.getWebDriver().switchTo().alert();
		if (alert != null) {
			alert.sendKeys(userName);
			alert.sendKeys(password);
		}
	}

}
