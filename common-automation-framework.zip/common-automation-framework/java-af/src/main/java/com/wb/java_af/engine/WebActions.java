package com.wb.java_af.engine;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Contains all basic Selenium commands to perform actions against web elements
 * to support functionality on multiple browsers: IE, Chrome, Firefox
 */

public class WebActions {

	private Engine engine;
	private Actions actions = null;

	public WebActions(Engine engine) {
		this.engine = engine;
	}

	/* ####################### Basic Actions ####################### */

	
	
	/**
	 * perform a click on the WebElement
	 * 
	 * @param element
	 */
	public void clickElement(WebElement element) {
		try {
			element.click();
		} catch (Exception e) {
			LogUtility.logException("clickElement", "Unable to click on element", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * perform a click on the element using javaScript function is sometimes used
	 * when the regular Selenium click() does not work on the WebElement.
	 * 
	 * @param element
	 */
	public void clickElementJS(WebElement element) {
		engine.getJavaScript().execute("arguments[0].click();", element);
	}

	/**
	 * Perform a click on an element using the Actions forcing the click method to
	 * be executed. This is best used when the regular Selenium click() hangs
	 * 
	 * @param element
	 */
	public void clickElementWithActions(WebElement element) {
		engine.getWait().staticWait(1);
		actions = new Actions(engine.getWebDriver());
		actions.moveToElement(element).click().perform();
	}

	/**
	 * perform click two times on some elements that requires
	 * 
	 * @param element
	 * 
	 */
	public void clickElementTwice(WebElement element) {
		engine.getWait().staticWait(1); // require or it will go to fast
		try {
			element.click();
			engine.getWait().staticWait(1);
			element.click();
		} catch (Exception e) {
			LogUtility.logException("clickElementTwice", "Unable to click on element", e, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * Submit a form
	 * 
	 * @param element
	 */
	public void submitForm(WebElement element) {
		engine.getWait().staticWait(1); // require or it will go to fast
		try {
			element.submit();
		} catch (StaleElementReferenceException e) {
			LogUtility.logException("submitForm", "-->Element is Stale.Unable to submit form", e, LoggingLevel.ERROR,
					true);
		} catch (Exception e) {
			LogUtility.logException("submitForm", "-->Exception in element.Unable to submit form", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * set a value in an element. usually text fields
	 * 
	 * @param element
	 * @param value   to enter in text box
	 */
	public void setValue(WebElement element, String value) {
		try {
			element.clear();
			element.sendKeys(value);
		} catch (Exception e) {
			LogUtility.logException("setValue", "-->Exception in element.Unable to Set value", e, LoggingLevel.ERROR,
					true);
		}
	}

	public void setValueJs(WebElement element, String value) {
		try {
			((JavascriptExecutor) engine.getWebDriver()).executeScript("arguments[0].value = arguments[1]", element, value);
		} catch (Exception e) {
			LogUtility.logException("setValueJs", "-->Exception in element.Unable to Set value with JavaScript", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * set a value in an element. usually text fields by using the Actions
	 * 
	 * @param element
	 * @param value   To enter into textbox
	 */
	public void setValueActions(WebElement element, String value) {

		try {
			engine.getWait().staticWait(1);
			actions = new Actions(engine.getWebDriver());
			actions.moveToElement(element).click().perform();
			actions.moveToElement(element).sendKeys(value).perform();
		} catch (Exception e) {
			LogUtility.logException("setValueActions", "-->Exception in element.Unable to Set value with Actions", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * clear the value, works for input textBox and textArea
	 * 
	 * @param element
	 */
	public void clearValue(WebElement element) {
		engine.getWait().staticWait(1);
		try {
			element.clear();
		} catch (Exception e) {
			LogUtility.logException("clearValue", "-->Exception in element.Unable to clear value", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * clear the with javaScript value, works for input textBox and textArea
	 *
	 * @param element
	 */
	public void clearValueJs(WebElement element) {
		try {
			engine.getWait().staticWait(1);
			engine.getJavaScript().execute("arguments[0].value = ''", element);
		} catch (Exception e) {
			LogUtility.logException("clearValue", "-->Exception in element.Unable to clear value with JS", e,
					LoggingLevel.ERROR, true);
		}
	}

	/**
	 * return the value of the attribute VALUE in the element common for input
	 * fields
	 * 
	 * @param element
	 * @return the text of the value property
	 */
	public String getValue(WebElement element) {
		return element.getAttribute("value");
	}

	/**
	 * return the value of an specified attribute name in the element
	 * 
	 * @param element
	 * @param         attributeName- name of the attribute you want to get the value
	 *                of
	 */
	public String getAttributeValue(WebElement element, String attributeName) {
		return element.getAttribute(attributeName);
	}

	/**
	 * return the text of that element
	 * 
	 * @param element
	 */
	public String getText(WebElement element) {
		String text = element.getText();
		if (text.equals(""))
			text = (String) engine.getJavaScript().execute("return arguments[0].value", element);

		if (text.equals(""))
			text = (String) engine.getJavaScript().execute("return arguments[0].textContent", element);

		return text;
	}

	/**
	 * return the text of that element using JavaScript
	 * 
	 * @param element
	 */

	public String getTextJS(WebElement element) {
		return engine.getJavaScript().execute("return arguments[0].innerText;", element).toString().trim();
	}

	/**
	 * return if the CheckBox is checked
	 * 
	 * @param element
	 */
	public boolean isChecked(WebElement element) {
		return element.isSelected();
	}

	/**
	 * return if the CheckBox is checked using JavaScript
	 * 
	 * @param element
	 */
	public boolean isCheckedJS(WebElement element) {
		return (Boolean) engine.getJavaScript().execute("return arguments[0].checked", element);
	}

	/**
	 * return if the element is displayed
	 * 
	 * @param element
	 */
	public boolean isDisplayed(WebElement element) {
		return element.isDisplayed();
	}

	/**
	 * return if the element is Enabled
	 * 
	 * @param element
	 */
	public boolean isEnabled(WebElement element) {
		return element.isEnabled();
	}

	/**
	 * return if the element is Disabled
	 * 
	 * @param element
	 */
	public boolean isDisabled(WebElement element) {
		return element.isEnabled() ? false : true;
	}

	/**
	 * select an item in a drop down element by the value
	 * 
	 * @param element
	 * @param value   - name of the item, value of the item
	 */
	public void selectDropDownByValue(WebElement element, String value) {
		new Select(element).selectByValue(value);
	}

	/**
	 * select an item in a drop down element by the value
	 * 
	 * @param element
	 * @param         value- name of the item, value of the item
	 */
	public void selectDropDownByValueJs(WebElement element, String value) {
		engine.getJavaScript().execute("arguments[0].value = arguments[1]", element, value);
	}

	/**
	 * select an item in a drop down element by the index
	 * 
	 * @param element
	 * @param         index- index of the item
	 */
	public void selectDropDownByIndex(WebElement element, int index) {
		new Select(element).selectByIndex(index);
	}

	/**
	 * select an item in a drop down element by the text visible
	 * 
	 * @param element
	 * @param text
	 */
	public void selectDropDownByText(WebElement element, String text) {
		new Select(element).selectByVisibleText(text);
	}

	/**
	 * Returns the first visible element on a list of Elements
	 */
	public WebElement getVisibleElement(List<WebElement> elements) {
		for (WebElement element : elements) {
			if (element.isDisplayed())
				return element;
		}
		return null;
	}

	/**
	 * Use the Robot class to perform keypress actions -NOTE: this do not work on
	 * Virtual Machines
	 * 
	 * @param keyCode - int value of the key
	 */
	public void pressKey(int keyCode) {
		try {
			Robot robot = new Robot();
			robot.keyPress(keyCode); // Press Key
			robot.keyRelease(keyCode); // Release the Key

		} catch (AWTException e) {
			e.printStackTrace();
		}

	}
}
