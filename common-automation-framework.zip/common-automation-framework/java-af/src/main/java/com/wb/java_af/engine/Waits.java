package com.wb.java_af.engine;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Provides a library of synchronization methods.
 * 
 * @author Bharat Pandey
 *
 * @see Waits
 */
public class Waits {

	private Boolean flag;
	private Engine engine;
	private long defaultWaitSeconds = 20;
	private Duration defaultWaitInSeconds = Duration.ofSeconds(defaultWaitSeconds);
	WebDriverWait wait;

	public void staticWait(int seconds) {
		try {
			if (seconds > 5)
				seconds = 5;
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void waitForElementExistence(By by) {
		waitForElementExistence(by, defaultWaitSeconds);
	}

	public void waitForElementExistence(By by, long timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), timeoutInSeconds);
		try {
			// wait.until(ExpectedConditions.presenceOfElementLocated(by));
			wait.until((WebDriver driver) -> driver.findElement(by));
		} catch (TimeoutException e) {
			LogUtility.logException("waitForElementExistence", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
	}

	public WebElement waitForExistence(By by) {
		return waitForExistence(by, defaultWaitSeconds);
	}

	public WebElement waitForExistence(By by, long timeoutInSeconds) {
		try {
			return waitUntilElementIsPresent(by, timeoutInSeconds);
		} catch (TimeoutException e) {
			LogUtility.logException("waitForElementExistence", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			throw e;
		} catch (Exception e) {
			LogUtility.logException("waitUntilElementIsPresent", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
		}
		return null;
	}
	
	public boolean waitUntilElementExistence(WebElement element) {
		return waitUntilElementExistence(element, defaultWaitSeconds);
	}
	
	public boolean waitUntilElementExistence(WebElement element, long timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), timeoutInSeconds);
		try {
			wait.until(x -> element);
			return true;
		} catch (TimeoutException e) {
			LogUtility.logException("waitUntilElementExistence", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return false;
		} catch (Exception e) {
			LogUtility.logException("waitUntilElementExistence", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	public boolean waitUntilElementIsPresent(WebElement element) {
		return waitUntilElementIsPresent(element, defaultWaitSeconds);
	}

	public boolean waitUntilElementIsPresent(WebElement element, long timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), timeoutInSeconds);
		try {
			wait.until(x -> element.isDisplayed());
			return true;
		} catch (TimeoutException e) {
			LogUtility.logException("waitUntilElementIsPresent", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return false;
		} catch (Exception e) {
			LogUtility.logException("waitUntilElementIsPresent", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	public boolean waitUntilElementIsPresent(WebElement element, String timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), Long.parseLong(timeoutInSeconds));
		try {
			wait.until(x -> element.isDisplayed());
			return true;
		} catch (TimeoutException e) {
			LogUtility.logException("waitUntilElementIsPresent", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return false;
		} catch (Exception e) {
			LogUtility.logException("waitUntilElementIsPresent", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return false;
		}
	}

	public WebElement waitUntilElementIsPresent(By by, long timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), timeoutInSeconds);
		try {
			return wait.until((WebDriver driver) -> driver.findElement(by));
		} catch (TimeoutException e) {
			LogUtility.logException("waitUntilElementIsPresent", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return null;
		} catch (Exception e) {
			LogUtility.logException("waitUntilElementIsPresent", "FAIL: The element was not located.", e,
					LoggingLevel.ERROR, true);
			return null;
		}
	}

	public void waitForPageReadyState() {
		waitForPageReadyState(defaultWaitSeconds);
	}

	public void waitForPageReadyState(long timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), timeoutInSeconds);

		try {
			wait.until(x -> engine.getJavaScript().execute(engine.getWebDriver(), "return document.readyState")
					.toString().equals("complete"));
		} catch (Throwable e) {
			LogUtility.logException("waitForPageReadyState", "FAIL: Java script load not found.", e, LoggingLevel.ERROR,
					true);
		}
	}

	public void waitForPageToLoad(long timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), timeoutInSeconds);
		try {
			wait.until((WebDriver driver) -> ((long) ((JavascriptExecutor) engine.getWebDriver())
					.executeScript("return jQuery.active") == 0));
		} catch (Throwable e) {
			LogUtility.logException("waitForPageReadyState", "FAIL: Java script load not found.", e, LoggingLevel.ERROR,
					true);
		}
		waitForPageReadyState();
	}

	public void waitUntilAlertIsPresent(long timeoutInSeconds) {
		wait = new WebDriverWait(engine.getWebDriver(), timeoutInSeconds);
		try {
			wait.until((WebDriver driver) -> driver.switchTo().alert() != null);
		} catch (Throwable e) {
			LogUtility.logException("waitUntilAlertIsPresent", "FAIL: Java script load not found.", e,
					LoggingLevel.ERROR, true);
		}
	}

	/*
	 * ######## Wait Helpers ######### /* Added By : Sanjay Samantaray Date: 5th
	 * April 2019
	 */

	/**
	 * @param time max time set for the element to be found
	 * @return the wait instance to be use in custom situations
	 */
	public WebDriverWait customWait(int time) {
		wait = new WebDriverWait(engine.getWebDriver(), time);
		return wait;
	}

	/**
	 * wait for the HTML DOM to be ready, all elements loaded
	 * 
	 * note: Does not guarantee the full page has loaded, sometimes DOM can return
	 * complete, but some elements are still loading dynamically.
	 */
	public void waitForDOMready() {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		try {
			wait.until(expectation);
		} catch (Exception e) {
			LogUtility.logException("waitForDOMready", "FAIL: Timeout waiting for Page Load Request to complete.", e,
					LoggingLevel.ERROR, true);
		}
	}

	public void waitAttributeToBeNotEmpty(WebElement element, String value) {
		WebDriverWait waiting = new WebDriverWait(engine.getWebDriver(), 15);
		try {
			waiting.until(ExpectedConditions.attributeToBeNotEmpty(element, value));
		} catch (StaleElementReferenceException ex) {
			LogUtility.logException("waitAttributeToBeNotEmpty", "FAIL: Element is stale. No longer present in DOM", ex,
					LoggingLevel.ERROR, true);
		} catch (Exception e) {
			LogUtility.logException("waitAttributeToBeNotEmpty", "FAIL: Found empty attribute for the element.", e,
					LoggingLevel.ERROR, true);
		}
	}

	public void waitAttributeValueToBePresent(WebElement element, String attribute, String value) {
		WebDriverWait waiting = new WebDriverWait(engine.getWebDriver(), 15);
		try {
			waiting.until(ExpectedConditions.attributeToBe(element, attribute, value));
		} catch (StaleElementReferenceException e) {
			LogUtility.logException("waitAttributeValueToBePresent", "FAIL: Element is stale. No longer present in DOM",
					e, LoggingLevel.ERROR, true);
		} catch (Exception ex) {
			LogUtility.logException("waitAttributeValueToBePresent", "FAIL: Attribute not present for the element.", ex,
					LoggingLevel.ERROR, true);
		}
	}

	public void waitVisibilityOfAllElements(List<WebElement> elements) {
		waitVisibilityOfAllElements(elements, 60);
	}

	public void waitVisibilityOfAllElements(List<WebElement> elements, int time) {
		WebDriverWait waiting = new WebDriverWait(engine.getWebDriver(), time);
		try {
			waiting.until(ExpectedConditions.visibilityOfAllElements(elements));
		} catch (StaleElementReferenceException e) {
			LogUtility.logException("waitVisibilityOfAllElements", "FAIL: Element is stale. No longer present in DOM",
					e, LoggingLevel.ERROR, true);
		} catch (Exception ex) {
			LogUtility.logException("waitVisibilityOfAllElements", "FAIL: Elements are not present for the element.",
					ex, LoggingLevel.ERROR, true);
		}
	}

	/**
	 * wait for the element to be clickable
	 * 
	 * @param element
	 * @param time
	 */
	public void waitToBeClickable(WebElement element, int time) {
		WebDriverWait waiting = new WebDriverWait(engine.getWebDriver(), time);
		waiting.until(ExpectedConditions.elementToBeClickable(element));
	}

	/**
	 * wait for the invisibility of some element find by Xpath
	 */
	public void waitInvisibilityOf(String xpath, int time) {
		WebDriverWait waiting = new WebDriverWait(engine.getWebDriver(), time);
		waiting.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
	}

	/**
	 * wait for a desire amount of minutes for an element polling every desire
	 * amount of minutes. returns the element if is found
	 * 
	 * @param locator  A Webdriver locator, like By.Id
	 * @param timeOut  the total time to wait for the element in Minutes
	 * @param pollTime the time for polling in Minutes
	 */
	public WebElement fluentWait(final By locator, long timeOut, long pollTime) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(engine.getWebDriver()).withTimeout(Duration.ofSeconds(5))
				.pollingEvery(Duration.ofSeconds(1)).ignoring(NoSuchElementException.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(locator);
			}
		});
		return element;
	};

	public void waitUntilAlertIsPresent() {
		waitUntilAlertIsPresent(defaultWaitSeconds);
	}

	public Waits(Engine engine) {
		this.engine = engine;
	}

	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public long getDefaultWaitSeconds() {
		return defaultWaitSeconds;
	}

	public void setDefaultWaitSeconds(long defaultWaitSeconds) {
		this.defaultWaitSeconds = defaultWaitSeconds;
	}

	public Duration getDefaultWaitInSeconds() {
		return defaultWaitInSeconds;
	}

	public void setDefaultWaitInSeconds(Duration defaultWaitInSeconds) {
		this.defaultWaitInSeconds = defaultWaitInSeconds;
	}

	public WebDriverWait getWait() {
		return wait;
	}

	public void setWait(WebDriverWait wait) {
		this.wait = wait;
	}

}
