package com.wb.java_af.capabilities.browserCaps;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromePlatformCapsImpl implements BrowserCaps {

	public ChromeOptions options;
	String filePath, env, platformHost;

	public ChromePlatformCapsImpl(String filePath, String env, String platformHost) {
		this.filePath = filePath;
		this.env = env;
		this.platformHost = platformHost;
	}

	/**
	 * 
	 * Sets up chrome options to launch chrome with specified capabilities passed in
	 * json. Add args, extensions, encodedExtensions to chrome
	 * 
	 * @return Chrome Options
	 * @author Bharat Pandey
	 * 
	 * @see com.wb.java_af.capabilities.browserCaps.BrowserCaps#getCaps()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ChromeOptions getCaps() {
		JSONObject environment = BrowserCaps.parseJsonFile(filePath, env);
		String defaultPlatformHost = (String) environment.keySet().stream().findFirst().orElse(null);
		Map<String, Object> envCapabilities = null;
		if (platformHost == null || platformHost == "") {
			platformHost = defaultPlatformHost;
		}
		if (env.equalsIgnoreCase("local") && platformHost.contains("chrome")) {
			options = new ChromeOptions();
			envCapabilities = (Map<String, Object>) environment.get(platformHost);

			Iterator<Map.Entry<String, Object>> it = envCapabilities.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, Object> pair = it.next();
				String key = pair.getKey().toString();
				String value = pair.getValue().toString();
				if (key.equalsIgnoreCase("chromeOptions")) {
					JSONObject platformObject = (JSONObject) environment.get(platformHost);
					JSONObject chromeOptions = (JSONObject) platformObject.get("chromeOptions");
					if (chromeOptions.get("args") != null) {
						JSONArray argsArray = (JSONArray) chromeOptions.get("args");
						List<String> argList = BrowserCaps.convertJsonArrayToList(argsArray);
						options.addArguments(argList);
					}
					if (chromeOptions.get("extensions") != null) {
						JSONArray extensionsArray = (JSONArray) chromeOptions.get("extensions");
						List<String> extensionList = BrowserCaps.convertJsonArrayToList(extensionsArray);
						List<File> files = extensionList.stream().map(s -> new File(s)).collect(Collectors.toList());
						options.addExtensions(files);
					}
					if (chromeOptions.get("encodedExtensions") != null) {
						JSONArray encodedExtensionsArray = (JSONArray) chromeOptions.get("encodedExtensions");
						List<String> encodedExtensionList = BrowserCaps.convertJsonArrayToList(encodedExtensionsArray);
						options.addEncodedExtensions(encodedExtensionList);
					}
				} else if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
					options.setCapability(key, Boolean.parseBoolean(value));
				} else {
					options.setCapability(key, value);
				}
			}
		}
		return options;
	}

	public static void main(String[] args) {
		new ChromePlatformCapsImpl("capabilities/browserCapabilities.json", "local", "chrome").getCaps();
	}

}
