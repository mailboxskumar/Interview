package com.wb.java_af.testbases;

import java.io.File;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.testng.ITestResult;

import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResultFactory;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.setup.testparameters.EnvironmentParameters;
import com.wb.java_af.setup.testparameters.EnvironmentParametersInit;
import com.wb.java_af.utilities.LogUtility;
import com.wb.java_af.utilities.TestConstants;

public class TestBase {

	public static Properties props;
	String propertiesFile = "testparameters.properties";
	public EnvironmentParameters envParams;
	public static String loggingFilePath;
	public boolean remoteExecution;
	public boolean perfecto;
	public boolean mobile;
	public static String extentReport;
	public static String reportPath, screenShotDir, dateFormat, reportDirectoryEnvironmentSeparator, reportFilePrefix,
			separator, reportDirectoryName, reportDirName;
	public ReportiumClient reportiumClient;

	public void loadProperties() {

		try {
			props = new Properties();

			InputStreamReader input = new InputStreamReader(
					getClass().getClassLoader().getResourceAsStream(propertiesFile));

			if (input != null) {
				props.load(input);
			}
		} catch (Exception e) {
			LogUtility.logException("loadProperties", "There was a problem loading properties file.", e,
					LoggingLevel.ERROR, true);
		}
	}

	public void setLogPath() {
		loggingFilePath = System.getProperty(TestConstants.USER_DIR) + File.separator + "logs" + File.separator;
		System.setProperty("logPath", loggingFilePath);
	}

	public void initEnvironmentalParams() {
		envParams = EnvironmentParametersInit.intialize();
	}

	public void setUpExtent() {
		extentReport = props.getProperty("extent.report", "false");

		if (extentReport.equals("true")) {
			String os = EnvironmentParameters.getShortOsName();
			dateFormat = props.getProperty("date.format");
			reportDirectoryEnvironmentSeparator = props.getProperty("report.directory.environment.separator");
			reportFilePrefix = props.getProperty("reporting.directory.prefix");
			reportDirName = props.getProperty("report.directory." + os);
			screenShotDir = props.getProperty("screenshots.directory." + os);
			separator = props.getProperty("separator." + os);
			reportPath = new File(System.getProperty(TestConstants.USER_DIR)) + reportDirName;

			DateFormat currentDate = new SimpleDateFormat(dateFormat);
			reportDirectoryName = System.getProperty("environment") + reportDirectoryEnvironmentSeparator
					+ reportFilePrefix + currentDate.format(new Date()).toString() + separator;
			File screenshotDirectory = new File(reportPath + reportDirectoryName + screenShotDir);
			screenshotDirectory.mkdirs();
			
		}
	}
	
	public void setReportium(Method method) {
		if(mobile && perfecto) {
			reportiumClient = ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance();
			reportiumClient.testStart(method.getName(), new TestContext("smoke"));
		}
	}
	
	public void stopReportium(ITestResult result) {
		if(reportiumClient !=null) {
			if (result.getStatus() == ITestResult.FAILURE || result.getStatus() == ITestResult.SUCCESS_PERCENTAGE_FAILURE) {
				reportiumClient.testStop(TestResultFactory.createFailure("Test Failed"));
			} else {
				reportiumClient.testStop(TestResultFactory.createSuccess());
			}
		}
	}

}
