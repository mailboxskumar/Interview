package com.wb.java_af.appium;

import org.openqa.selenium.remote.RemoteWebElement;

import com.wb.java_af.engine.Engine;

import io.appium.java_client.AppiumDriver;

public class Appium {
	
	private AppiumDriver<RemoteWebElement> driver;
	private AppiumAndroid android;
	private AppiumIos ios;
	private MobileActions mobileActions;
	private MobileScroller mobileScroller;
	
	public Appium(Engine engine, String platform) {
		this.driver = engine.getAppiumDriver();
		mobileActions = new MobileActions(engine);
		mobileScroller = new MobileScroller(engine);
		
		switch (platform) {
		case "android" :
			android = new AppiumAndroid(engine);
			break;
		case "ios" : 
			ios = new AppiumIos(engine);
			break;
		default : throw new UnsupportedOperationException("The framework does not support creating the Appium object with "+platform);
		}
	}

	public AppiumDriver<RemoteWebElement> getDriver() {
		return driver;
	}

	public void setDriver(AppiumDriver<RemoteWebElement> driver) {
		this.driver = driver;
	}

	public AppiumAndroid getAndroid() {
		return android;
	}

	public void setAndroid(AppiumAndroid android) {
		this.android = android;
	}

	public AppiumIos getIos() {
		return ios;
	}

	public void setIos(AppiumIos ios) {
		this.ios = ios;
	}

	public MobileActions getMobileActions() {
		return mobileActions;
	}

	public void setMobileActions(MobileActions mobileActions) {
		this.mobileActions = mobileActions;
	}

	public MobileScroller getMobileScroller() {
		return mobileScroller;
	}

	public void setMobileScroller(MobileScroller mobileScroller) {
		this.mobileScroller = mobileScroller;
	}
	
}
