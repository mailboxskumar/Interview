package com.wb.java_af.capabilities.browserCaps;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.firefox.FirefoxDriverLogLevel;
import org.openqa.selenium.firefox.FirefoxOptions;

public class FirefoxPlatformCapsImpl implements BrowserCaps {

	public FirefoxOptions options;
	String filePath, env, platformHost;

	public FirefoxPlatformCapsImpl(String filePath, String env, String platformHost) {
		this.filePath = filePath;
		this.env = env;
		this.platformHost = platformHost;
	}

	/**
	 * 
	 * Sets up firefox options to launch firefox with specified capabilities passed
	 * in json. Add args, prefs, logs to firefox
	 * 
	 * @return Firefox Options
	 * @author Bharat Pandey
	 * 
	 * @see com.wb.java_af.capabilities.browserCaps.BrowserCaps#getCaps()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public FirefoxOptions getCaps() {
		JSONObject environment = BrowserCaps.parseJsonFile(filePath, env);
		String defaultPlatformHost = (String) environment.keySet().stream().findFirst().orElse(null);
		Map<String, Object> envCapabilities = null;
		if (platformHost == null || platformHost == "") {
			platformHost = defaultPlatformHost;
		}
		if (env.equalsIgnoreCase("local") && platformHost.contains("firefox")) {
			options = new FirefoxOptions();
			envCapabilities = (Map<String, Object>) environment.get(platformHost);

			Iterator<Map.Entry<String, Object>> it = envCapabilities.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, Object> pair = it.next();
				String key = pair.getKey().toString();
				String value = pair.getValue().toString();
				if (key.equalsIgnoreCase("firefoxOptions")) {
					JSONObject platformObject = (JSONObject) environment.get(platformHost);
					JSONObject firefoxOptions = (JSONObject) platformObject.get("firefoxOptions");
					if (firefoxOptions.get("args") != null) {
						JSONArray argsArray = (JSONArray) firefoxOptions.get("args");
						List<String> argList = BrowserCaps.convertJsonArrayToList(argsArray);
						options.addArguments(argList);
					}
					if (firefoxOptions.get("prefs") != null) {
						Map<String, Object> prefsArray = (Map<String, Object>) firefoxOptions.get("prefs");
						Iterator<Map.Entry<String, Object>> iteratorOverPrefs = prefsArray.entrySet().iterator();
						while (iteratorOverPrefs.hasNext()) {
							Object prefValue = iteratorOverPrefs.next().getValue();
							if (prefValue instanceof Boolean) {
								options.addPreference(iteratorOverPrefs.next().getKey(), (Boolean) prefValue);
							} else if (prefValue instanceof Number) {
								options.addPreference(iteratorOverPrefs.next().getKey(),
										((Number) prefValue).intValue());
							} else {
								options.addPreference(iteratorOverPrefs.next().getKey(), (String) prefValue);
							}
						}

					}
					if (firefoxOptions.get("log") != null) {
						Map<String, Object> logsArray = (Map<String, Object>) firefoxOptions.get("log");
						Iterator<Map.Entry<String, Object>> iteratorOverlog = logsArray.entrySet().iterator();
						while (iteratorOverlog.hasNext()) {
							Object logValue = iteratorOverlog.next().getValue();
							options.setLogLevel(FirefoxDriverLogLevel.fromString((String) logValue));
						}
					}
				} else if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
					options.setCapability(key, Boolean.parseBoolean(value));
				} else {
					options.setCapability(key, value);
				}
			}
		}
		return options;
	}

	public static void main(String[] args) {
		new FirefoxPlatformCapsImpl("capabilities/browserCapabilities.json", "local", "firefox").getCaps();
	}

}
