package com.wb.java_af.setup.testparameters;

import java.io.Serializable;

import com.wb.java_af.setup.Enums.Browser;
import com.wb.java_af.utilities.TestConstants;

public class EnvironmentParameters implements Serializable {

	private static final long serialVersionUID = -83479494934940943L;

	private String appUrl;
	private String username;
	private String password;
	private Browser browser;
	private String environment;
	private String suite;

	public EnvironmentParameters() {
		super();
	}

	public EnvironmentParameters(String appUrl, String username, String password, String environment,
			Browser browser, String suite) {
		super();
		this.appUrl = appUrl;
		this.username = username;
		this.password = password;
		this.environment = environment;
		this.browser = browser;
		this.suite = suite;
	}

	public String getAppUrl() {
		return appUrl;
	}

	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Browser getBrowser() {
		return browser;
	}

	public void setBrowser(Browser browser) {
		this.browser = browser;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getSuite() {
		return suite;
	}

	public void setSuite(String suite) {
		this.suite = suite;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		if (getSuite() == null) {
			suite = "src/test/resources/suites/defaultTestSuite.xml";
			builder.append("Test Parameters: [env=").append(environment).append(",browser=").append(browser)
					.append(", suite=").append(suite).append(",appUrl=").append(appUrl).append(", initialUrl=")
					.append(", username=").append(username).append(", password=").append(password)
					.append("]");
		}
		return appUrl;
	}
	
	public static String getShortOsName() {
		String os = System.getProperty(TestConstants.OS_NAME);
		String shortOs = null;
		
		if(os.startsWith(TestConstants.WINDOWS)) {
			shortOs = TestConstants.WINDOWS.toLowerCase();
		} else if(os.startsWith(TestConstants.MAC)) {
			shortOs = TestConstants.MAC.toLowerCase();
		} else if(os.startsWith(TestConstants.LINUX)) {
			shortOs = TestConstants.LINUX.toLowerCase();
		} else {
			return os;
		}
		return shortOs;
	}

}
