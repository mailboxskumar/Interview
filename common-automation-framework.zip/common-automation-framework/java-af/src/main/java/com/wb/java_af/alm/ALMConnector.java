package com.wb.java_af.alm;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.xml.sax.SAXException;

import com.wb.java_af.testbases.CucumberTestBase;
import com.wb.java_af.utilities.LogUtility;

public class ALMConnector extends LocalParseUtils {

	public static String ALM_URL = CucumberTestBase.props.getProperty("alm.url").trim();
	public static String USERNAME = CucumberTestBase.props.getProperty("alm.login.username").trim();
	public static String PASSWORD = CucumberTestBase.props.getProperty("alm.login.password").trim();
	public static String PROJECT_NAME = CucumberTestBase.props.getProperty("alm.project.name").trim();
	public static String DOMAIN_NAME = CucumberTestBase.props.getProperty("alm.domain.name").trim();

	public static String SIGNIN_URI = ALM_URL + "/api/authentication/sign-in";
	public static String TEST_INSTANCES_URI = ALM_URL + "/rest/domains/" + DOMAIN_NAME + "/projects/" + PROJECT_NAME
			+ "/test-instances";
	public static String TEST_RUNS_URI = ALM_URL + "/rest/domains/" + DOMAIN_NAME + "/projects/" + PROJECT_NAME
			+ "/runs";
	public static String SIGNOUT_URI = ALM_URL + "/api/authentication/sign-out";
	public static String LOGOUT_URI = ALM_URL + "/authentication-point/logout";
	public static String SITE_SESSION = ALM_URL + "/rest/site-session";
	public static int HTTP_UNAUTHORIZED = 401;

	/**
	 * Sign-in to ALM and get the CookiesList
	 * 
	 * @return cookiesList
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	public List<Cookie> signin() throws ClientProtocolException, URISyntaxException, IOException {
		String encoding = Base64.getEncoder().encodeToString((USERNAME + ":" + PASSWORD).getBytes());
		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
		Map<String, Object> apiData = httpGetRequest(SIGNIN_URI, new HashMap<String, String>(), headers,
				new BasicCookieStore());
		int statusCode = ((HttpResponse) apiData.get("response")).getStatusLine().getStatusCode();

		if (statusCode == HTTP_UNAUTHORIZED) {
			LogUtility.logError("User Authentication Failed!!. ALM Signin status code - " + statusCode);
			return null;
		} else {
			LogUtility.logInfo("User Authentication Success!!. ALM Signin status code - " + statusCode);
			return (List<Cookie>) apiData.get("cookiesList");
		}

	}

	/**
	 * 
	 * @param testSetId
	 * @param cookiesList
	 * @return
	 * 
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 * @throws XPathExpressionException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */

	public Map<String, Map<String, String>> getTestCaseIdList(String testSetId, List<Cookie> cookiesList)
			throws ClientProtocolException, URISyntaxException, IOException, XPathExpressionException,
			ParserConfigurationException, SAXException {

		BasicCookieStore cookieStore = getCookieStore(cookiesList);

		Map<String, String> params = new HashMap<String, String>();
		params.put("query", "{cycle-id[" + testSetId + "]}");
		Map<String, Object> apiData = httpGetRequest(TEST_INSTANCES_URI, params, new HashMap<String, String>(),
				cookieStore);

		// Parse the response to fetch the list of test case IDs
		String respStr = IOUtils
				.toString(new InputStreamReader(((HttpResponse) apiData.get("response")).getEntity().getContent()));

		Map<String, Map<String, String>> mapTestEntityList = getTestEntityDetails(respStr);
		return mapTestEntityList;
	}

	/**
	 * 
	 * @param testCaseDetailsMap
	 * @param cookiesList
	 * @return
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 * @throws XPathExpressionException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */

	public String createTestRun(Map<String, String> testCaseDetailsMap, List<Cookie> cookiesList)
			throws ClientProtocolException, URISyntaxException, IOException, XPathExpressionException,
			ParserConfigurationException, SAXException {

		String createTestRunBody = convertXMLToString("ALMCreateTestRun.xml");

		// Create Static TestRun body for new TestRun for the TestSet in TestLab
		createTestRunBody = createTestRunBody.replace("@TESTCASENAME", testCaseDetailsMap.get("name"))
				.replace("@TESTCYCLID", testCaseDetailsMap.get("testcycl-id"))
				.replace("@CYCLEID", testCaseDetailsMap.get("cycle-id"))
				.replace("@TESTID", testCaseDetailsMap.get("test-id"))
				.replace("@OWNER", testCaseDetailsMap.get("owner"))
				.replace("@TESTCONFIGID", testCaseDetailsMap.get("test-config-id"))
				.replace("@CYCLENAME", testCaseDetailsMap.get("user-03"))
				.replace("@SPRINT", testCaseDetailsMap.get("user-04"));

		/*
		 * LogUtility.logInfo("Test Run Create Body : " + createTestRunBody);
		 * LogUtility.logInfo("============================================");
		 */

		BasicCookieStore cookieStore = getCookieStore(cookiesList);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.CONTENT_TYPE, "application/xml");
		Map<String, Object> apiData = httpPostRequest(TEST_RUNS_URI, new HashMap<String, String>(), headers,
				cookieStore, createTestRunBody);

		String respStr = IOUtils
				.toString(new InputStreamReader(((HttpResponse) apiData.get("response")).getEntity().getContent()));

		return respStr.split("<Field Name=\"id\"><Value>")[1].split("<")[0];
	}

	/**
	 * 
	 * @param testCaseDetailsMap
	 * @param cookiesList
	 * @param testRunId
	 * @param testCaseUpdateStatus
	 * @return Test Run ID
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 * @throws XPathExpressionException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	public String updateTestRun(Map<String, String> testCaseDetailsMap, List<Cookie> cookiesList, String testRunId,
			String testCaseUpdateStatus) throws ClientProtocolException, URISyntaxException, IOException,
			XPathExpressionException, ParserConfigurationException, SAXException {

		BasicCookieStore cookieStore = getCookieStore(cookiesList);

		String updateTestRunBody = convertXMLToString("ALMUpdateTestRun.xml");
		updateTestRunBody = updateTestRunBody.replace("@TESTCASENAME", testCaseDetailsMap.get("name"))
				.replace("@TESTCYCLID", testCaseDetailsMap.get("testcycl-id"))
				.replace("@CYCLEID", testCaseDetailsMap.get("cycle-id"))
				.replace("@TESTID", testCaseDetailsMap.get("test-id"))
				.replace("@OWNER", testCaseDetailsMap.get("owner"))
				.replace("@TESTCONFIGID", testCaseDetailsMap.get("test-config-id"))
				.replace("@VERSTAMP", testCaseDetailsMap.get("ver-stamp"))
				.replace("@HASLINKAGE", testCaseDetailsMap.get("has-linkage")).replace("@STATUS", testCaseUpdateStatus);

		/*
		 * LogUtility.logInfo("Test Run Update Body : " + updateTestRunBody);
		 * LogUtility.logInfo("============================================");
		 */

		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.CONTENT_TYPE, "application/xml");
		headers.put(HttpHeaders.ACCEPT, "application/xml");

		String UPDATE_TEST_RUN_URI = TEST_RUNS_URI + "/" + testRunId;

		Map<String, Object> apiData = httpPutRequest(UPDATE_TEST_RUN_URI, new HashMap<String, String>(), headers,
				cookieStore, updateTestRunBody);

		String respStr = IOUtils
				.toString(new InputStreamReader(((HttpResponse) apiData.get("response")).getEntity().getContent()));

		return respStr;
	}

	/**
	 * 
	 * @param testInstanceId
	 * @param cookieStore
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 */

	public void updateTestInstance(String testInstanceId, List<Cookie> cookiesList, boolean flag, String deviceBrowser,
			String elapsedTime) throws ClientProtocolException, URISyntaxException, IOException {

		BasicCookieStore cookieStore = getCookieStore(cookiesList);

		String testInstanceBody = convertXMLToString("ALMUpdateTestInstance.xml");
		String actualTester = CucumberTestBase.props.getProperty("alm.login.username");

		if (!flag) {
			String browserVersion = deviceBrowser;
			String osVersion = System.getProperty("os.name") + " " + System.getProperty("os.version");
			testInstanceBody = testInstanceBody.replace("@ID", testInstanceId).replace("@OSVERSION", osVersion)
					.replace("@BROWSERVERSION", browserVersion).replace("@DEVICENAME", "")
					.replace("@ELAPSEDTIME", elapsedTime).replace("@ACTUALTESTER", actualTester);
		} else {
			String mobileOSVersion = "";
			testInstanceBody = testInstanceBody.replace("@ID", testInstanceId).replace("@OSVERSION", mobileOSVersion)
					.replace("@BROWSERVERSION", "").replace("@DEVICENAME", deviceBrowser)
					.replace("@ELAPSEDTIME", elapsedTime).replace("@ACTUALTESTER", actualTester);
		}

		/*
		 * LogUtility.logInfo("Test Instance Update Body : " + testInstanceBody);
		 * LogUtility.logInfo("============================================");
		 */

		String TEST_INSTANCE_URI = TEST_INSTANCES_URI + "/" + testInstanceId;

		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.CONTENT_TYPE, "application/xml");

		Map<String, Object> apiData = httpPutRequest(TEST_INSTANCE_URI, new HashMap<String, String>(), headers,
				cookieStore, testInstanceBody);

		String respStr = IOUtils
				.toString(new InputStreamReader(((HttpResponse) apiData.get("response")).getEntity().getContent()));
	}

	/**
	 * 
	 * @param cookieStore
	 * @param testRunId
	 * @param status
	 * 
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 * @throws XPathExpressionException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */

	public void updateTestRunSteps(List<Cookie> cookiesList, String testRunId, String status) {
		try {
			BasicCookieStore cookieStore = getCookieStore(cookiesList);

			Map<String, String> headers = new HashMap<String, String>();
			headers.put(HttpHeaders.CONTENT_TYPE, "application/xml");

			String UPDATE_TEST_RUN_STEPS_URI = TEST_RUNS_URI + "/" + testRunId + "/run-steps";

			Map<String, Object> apiData = httpGetRequest(UPDATE_TEST_RUN_STEPS_URI, new HashMap<String, String>(),
					new HashMap<String, String>(), cookieStore);

			String respStr = IOUtils.toString(
					new InputStreamReader(((HttpResponse) apiData.get("response")).getEntity().getContent(), "UTF-8"));

			List<String> mapTestEntityList = getRunStepIDDetails(respStr);

			String stepsBody = "<Entity Type='run-step'>\r\n" + " <Fields>\r\n" + "  <Field Name='status'><Value>"
					+ status + "</Value></Field>\r\n" + " </Fields>\r\n" + "</Entity>";

			for (String stepId : mapTestEntityList) {
				String STEPS_URI = UPDATE_TEST_RUN_STEPS_URI + "/" + stepId;
				httpPutRequest(STEPS_URI, new HashMap<String, String>(), headers, cookieStore, stepsBody);
			}
		} catch (IOException | URISyntaxException | XPathExpressionException | ParserConfigurationException
				| SAXException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param cookiesList
	 * @return
	 */
	public BasicCookieStore getCookieStore(List<Cookie> cookiesList) {
		BasicCookieStore cookieStore = new BasicCookieStore();
		for (Cookie cookie : cookiesList)
			cookieStore.addCookie(cookie);
		return cookieStore;
	}

	/**
	 * 
	 * @param body
	 * @param cookiesList
	 * @return : TestRun ID
	 * 
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 * @throws XPathExpressionException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */

	public String createTestRun(String body, List<Cookie> cookiesList) throws ClientProtocolException,
			URISyntaxException, IOException, XPathExpressionException, ParserConfigurationException, SAXException {

		BasicCookieStore cookieStore = getCookieStore(cookiesList);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.CONTENT_TYPE, "application/xml");
		Map<String, Object> apiData = httpPostRequest(TEST_RUNS_URI, new HashMap<String, String>(), headers,
				cookieStore, body);
		String respStr = IOUtils.toString(
				new InputStreamReader(((HttpResponse) apiData.get("response")).getEntity().getContent(), "UTF-8"));
		// LogUtility.logInfo("Test run create RESPONSE STRING - " + respStr);
		return respStr.split("<Field Name=\"id\"><Value>")[1].split("<")[0];
	}

	/**
	 * 
	 * @param body
	 * @param cookiesList
	 * @param testRunId
	 * @return
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 * @throws XPathExpressionException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */

	public String updateTestRun(String testRunBody, List<Cookie> cookiesList, String testRunId,
			String testCaseUpdateStatus) throws ClientProtocolException, URISyntaxException, IOException,
			XPathExpressionException, ParserConfigurationException, SAXException {

		BasicCookieStore cookieStore = getCookieStore(cookiesList);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.CONTENT_TYPE, "application/xml");
		headers.put(HttpHeaders.ACCEPT, "application/xml");
		String UPDATE_TEST_RUN_URI = TEST_RUNS_URI + "/" + testRunId;
		Map<String, Object> apiData = httpPutRequest(UPDATE_TEST_RUN_URI, new HashMap<String, String>(), headers,
				cookieStore, testRunBody);
		String respStr = IOUtils.toString(
				new InputStreamReader(((HttpResponse) apiData.get("response")).getEntity().getContent(), "UTF-8"));

		return respStr;
	}

	/**
	 * SignOut from ALM
	 * 
	 * @throws ClientProtocolException
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public void signout(List<Cookie> cookiesList) throws ClientProtocolException, URISyntaxException, IOException {

		String encoding = Base64.getEncoder().encodeToString((USERNAME + ":" + PASSWORD).getBytes());
		Map<String, String> headers = new HashMap<String, String>();
		headers.put(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
		Map<String, Object> apiData = httpGetRequest(LOGOUT_URI, new HashMap<String, String>(), headers,
				new BasicCookieStore());

		httpDeleteRequest(SITE_SESSION, getCookieStore(cookiesList));

		/*
		 * Map<String, Object> apiData = httpGetRequest(SIGNOUT_URI, new HashMap<String,
		 * String>(), headers, new BasicCookieStore());
		 */

		LogUtility.logInfo("ALM Sign Out status code - "
				+ ((HttpResponse) apiData.get("response")).getStatusLine().getStatusCode());
	}

	/**
	 * This method is used to generate HTTP GET requests for ALM Rest Services.
	 * 
	 * @param endpoint - Mention the endpoint of the service url
	 * @param params   - Map of Parameters to pass to request the service.
	 * @return
	 * @throws URISyntaxException
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public Map<String, Object> httpGetRequest(String endpoint, Map<String, String> params, Map<String, String> headers,
			BasicCookieStore cookieStore) throws URISyntaxException, ClientProtocolException, IOException {

		Map<String, Object> returnMap = new HashMap<String, Object>();
		URIBuilder uriBuilder = new URIBuilder(endpoint);

		for (String key : params.keySet()) {
			uriBuilder.addParameter(key, params.get(key));
		}
		HttpGet httpGet = new HttpGet(uriBuilder.build());
		for (String header : headers.keySet()) {
			httpGet.setHeader(header, headers.get(header));
		}
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCookieStore(cookieStore).build();
		HttpResponse response = httpClient.execute(httpGet);
		returnMap.put("response", response);
		returnMap.put("cookiesList", cookieStore.getCookies());
		return returnMap;
	}

	/**
	 * 
	 * @param endpoint
	 * @param params
	 * @param headers
	 * @param cookieStore
	 * @param body
	 * @return
	 * @throws URISyntaxException
	 * @throws ClientProtocolException
	 * @throws IOException
	 */

	public Map<String, Object> httpPostRequest(String endpoint, Map<String, String> params, Map<String, String> headers,
			BasicCookieStore cookieStore, String body) throws URISyntaxException, ClientProtocolException, IOException {
		Map<String, Object> returnMap = new HashMap<String, Object>();

		URIBuilder uriBuilder = new URIBuilder(endpoint);
		for (String key : params.keySet()) {
			uriBuilder.addParameter(key, params.get(key));
		}
		HttpPost httpPost = new HttpPost(uriBuilder.build());
		for (String header : headers.keySet()) {
			httpPost.setHeader(header, headers.get(header));
		}
		StringEntity se = new StringEntity(body);
		se.setContentType("text/xml");
		httpPost.setEntity(se);

		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCookieStore(cookieStore).build();
		HttpResponse response = httpClient.execute(httpPost);
		returnMap.put("response", response);
		returnMap.put("cookiesList", cookieStore.getCookies());
		return returnMap;
	}

	public void httpDeleteRequest(String endpoint, BasicCookieStore cookieStore)
			throws URISyntaxException, ClientProtocolException, IOException {

		URIBuilder uriBuilder = new URIBuilder(endpoint);
		HttpDelete httpDelete = new HttpDelete(uriBuilder.build());

		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCookieStore(cookieStore).build();
		HttpResponse response = httpClient.execute(httpDelete);
	}

	/**
	 * 
	 * @param endpoint
	 * @param params
	 * @param headers
	 * @param cookieStore
	 * @param body
	 * @return
	 * @throws URISyntaxException
	 * @throws ClientProtocolException
	 * @throws IOException
	 */

	public Map<String, Object> httpPutRequest(String endpoint, Map<String, String> params, Map<String, String> headers,
			BasicCookieStore cookieStore, String body) throws URISyntaxException, ClientProtocolException, IOException {
		Map<String, Object> returnMap = new HashMap<String, Object>();

		URIBuilder uriBuilder = new URIBuilder(endpoint);
		for (String key : params.keySet()) {
			uriBuilder.addParameter(key, params.get(key));
		}
		HttpPut httpPut = new HttpPut(uriBuilder.build());
		for (String header : headers.keySet()) {
			httpPut.setHeader(header, headers.get(header));
		}
		StringEntity se = new StringEntity(body);
		se.setContentType("text/xml");
		httpPut.setEntity(se);

		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCookieStore(cookieStore).build();
		HttpResponse response = httpClient.execute(httpPut);
		returnMap.put("response", response);
		returnMap.put("cookiesList", cookieStore.getCookies());
		return returnMap;
	}

}
