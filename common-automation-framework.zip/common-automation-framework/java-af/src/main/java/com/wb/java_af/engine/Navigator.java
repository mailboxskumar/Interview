package com.wb.java_af.engine;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import org.openqa.selenium.NoSuchWindowException;

import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

/**
 * Provides a library of methods to navigate to a url in a fail safe way, refresh a page, open url in a new tab etc.
 * 
 * @author Bharat Pandey
 *
 * @see Navigator
 */
public class Navigator {
	
	public Navigator(Engine engine){
		this.engine = engine;
	}
	
	private Engine engine;
	
	/**
	 * Navigates to the url specified
	 * @param url
	 * @return Current url
	 * @throws MalformedURLException
	 * 
	 * @see Navigator
	 * 
	 * @author Bharat Pandey
	 */
	public String goToUrl(String url) throws MalformedURLException {
		try {
			return goToUrl(new URL(url));
		} catch (MalformedURLException e){
			LogUtility.logException("goToUrl", e, LoggingLevel.ERROR, true);
			try {
				throw e;
			} catch (MalformedURLException me) {
				// TODO Auto-generated catch block
				throw me;
			}
		}
	}
	
	
	/**
	 * Navigates to the url specified
	 * @param url
	 * @return Current url
	 * @throws MalformedURLException
	 * 
	 * @see Navigator
	 * 
	 * @author Bharat Pandey
	 */
	private String goToUrl(URL url){
		return goToUrl(url, true);
	}
	
	/**
	 * Navigates to the url specified
	 * @param url
	 * @param waitForPageReadyState - boolean flag to indicate to wait untill page load is complete
	 * @return Current url
	 * 
	 * @see Navigator
	 * 
	 * @author Bharat Pandey
	 */
	public String goToUrl(URL url, boolean waitForPageReadyState) {
		try {
			engine.getWebDriver().navigate().to(url);
			
			if(waitForPageReadyState) {
				engine.getWait().waitForPageReadyState(20);
			}
			return engine.getWebDriver().getCurrentUrl();
		} catch (NoSuchWindowException e) {
			Set<String> windowHandles = engine.getWebDriver().getWindowHandles();
			if(windowHandles.size() > 0) {
				engine.getWebDriver().switchTo().window(windowHandles.stream().findFirst().get());
				LogUtility.logException("goToUrl", "Auto recovery to first window", e, LoggingLevel.ERROR, true);
				if(waitForPageReadyState) {
					engine.getWait().waitForPageReadyState(20);
				}
				return engine.getWebDriver().getCurrentUrl();
			}
			
			try {
				Thread.sleep(10000);
			} catch (InterruptedException ie) {
				LogUtility.logException("goToUrl", "A sleep was attempted but was inturrupted.", ie, LoggingLevel.ERROR, true);
			}
			
			windowHandles = engine.getWebDriver().getWindowHandles();
			
			if(windowHandles.size() > 0) {
				engine.getWebDriver().switchTo().window(windowHandles.stream().findFirst().get());
				LogUtility.logException("goToUrl", "Auto recovery to first window", e, LoggingLevel.ERROR, true);
				if(waitForPageReadyState) {
					engine.getWait().waitForPageReadyState(20);
				}
				return engine.getWebDriver().getCurrentUrl();
			}
			LogUtility.logException("goToUrl", "No windowhandles at all", e, LoggingLevel.ERROR, true);
			throw e;
		}
		
	}
	
	/**
	 * Opens a url in a new tab
	 * @param endpoint - Url endpoint
	 * @param baseUrl - Base url
	 * 
	 * @see Navigator
	 * 
	 * @author Bharat Pandey
	 */
	public void openUrlInNewTab(String endpoint, String baseUrl){
		baseUrl = baseUrl !=null? baseUrl : "";
		URL uri;
		
		try {
			uri = new URL(baseUrl+endpoint);
			engine.getJavaScript().executeJavaScript("window.open('"+uri+"', '_blank');");
			
			try {
				Thread.sleep(10000);
			} catch (InterruptedException ie) {
				LogUtility.logException("openUrlInNewTab", "A sleep was attempted but was inturrupted.", ie, LoggingLevel.ERROR, true);
			}
			LogUtility.logInfo("openUrlInNewTab", "There are now "+engine.getWebDriver().getWindowHandles().size()+" windows open.");
			engine.getWindows().switchToWindowLastOpened();
			engine.getWait().waitForPageReadyState();
		} catch(MalformedURLException e) {
			LogUtility.logException("openUrlInNewTab", "The url provided was not in the correct format.", e, LoggingLevel.ERROR, true);
		}
	}
	
	/**
	 * Refreshes the current page.
	 * 
	 * @see Navigator
	 * 
	 * @author Bharat Pandey
	 */
	public void refreshPage(){
		LogUtility.logDebug("refreshPage", "Refreshing/reloading the web page.");
		engine.getWebDriver().navigate().refresh();
	}
}
