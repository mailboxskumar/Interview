package com.wb.java_af.appium;

import java.time.Duration;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.support.ui.Select;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

import io.appium.java_client.MobileElement;

public class MobileActions {

	private Engine engine;
	private Alert alert;
	MobileElement element;
	
	public MobileActions(Engine engine) {
		this.engine = engine;
	}


	// get the status of the switch whether it is on or off state

	public String getSwitchStatus(int index) {

		String switchstatus = null; // String Switchcls = "android.widget.Switch";
		String Switchcls = null;
		Switchcls = System.getProperty(Switchcls);

		try {

			LogUtility.logInfo("Entered into Try Block...");
			MobileElement ele = (MobileElement) engine.getAndroidDriver().findElementByAndroidUIAutomator(
					"new UiSelector().className(\"" + Switchcls + "\").enabled(true).instance(" + index + ")");
			LogUtility.logInfo("........" + ele);
			String index_text = ele.getText().toString();
			LogUtility.logInfo("index0 text..." + index_text);

			if ((index_text.equalsIgnoreCase("on"))) {
				switchstatus = "ON";
			} else {
				switchstatus = "OFF";
			}
		} catch (Exception e) {

			LogUtility.logInfo("Exception while getting button status...");

		}
		return switchstatus;
	}

	/**
	 * Method will accept the alerts in the application
	 */

	public void acceptAlert() {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getAppiumDriver().switchTo().alert();
			alert.accept();
			LogUtility.logInfo("Successfully accepted the alert");
		} catch (NoAlertPresentException e) {
			LogUtility.logException("acceptAlert", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * It will verify whether the alert is present if it present it will true or
	 * else false
	 */

	public boolean isAlertPresent() {
		boolean presentFlag = false;
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getAppiumDriver().switchTo().alert();
			presentFlag = true;
			LogUtility.logInfo("Alert is present in the page");
		} catch (NoAlertPresentException e) {
			LogUtility.logException("isAlertPresent", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			presentFlag = false;
		}
		return presentFlag;
	}

	/**
	 * It will Dismiss the alert
	 **/

	public void DismissAlert() {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getAppiumDriver().switchTo().alert();
			alert.dismiss();
			LogUtility.logInfo("Successfully Dismissed the alert");
		} catch (NoAlertPresentException e) {
			LogUtility.logException("acceptDismiss", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * 
	 * Indicates that can pass the text to the alerts in the application.
	 */

	public void sendKeysToAlert(String keysToSend) {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getAppiumDriver().switchTo().alert();
			alert.sendKeys(keysToSend);
			LogUtility.logInfo("Successfully value is passed to the alert");
		} catch (NoAlertPresentException e) {
			LogUtility.logException("sendKeysToAlert", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * Indicates get the text from the alert
	 */

	public void getTextFromAlert() {
		try {
			engine.getWait().waitUntilAlertIsPresent();
			alert = engine.getAppiumDriver().switchTo().alert();
			alert.getText();
			LogUtility.logInfo("Successfully accepted the alert");
		} catch (NoAlertPresentException e) {
			LogUtility.logException("getTextFromAlert", "FAIL: Alert not found.", e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

	/**
	 * To hide keyboard.
	 * 
	 */

	public void hideKeyboard() throws Throwable {
		try {
			engine.getAppiumDriver().hideKeyboard();
			System.out.println("key board is hide in the device");
		} catch (Exception e) {
			System.out.println("Unable to hide the keyBoard in the device");
		}
	}

	/**
	 * 
	 * select value from the dropdown list
	 */

	public void selectDropDownbyValue(String textToIdentify) throws Throwable {
		if (null == element)
			throw new Throwable(": Mobile Actions : Element is null");
		Select dropDown = new Select(element);
		dropDown.selectByValue(textToIdentify);

	}
	
	public void closeApp(){
		try {
			engine.getAppiumDriver().closeApp();
		} catch (Exception e) {
			LogUtility.logException("closeApp", "Failed to close app.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
	
	public String getContext(){
		String result;
		try {
			result = engine.getAppiumDriver().getContext();
		} catch (Exception e) {
			LogUtility.logException("getContext", "Failed to get context.",e, LoggingLevel.ERROR, true);
			throw e;
		}
		return result;
	}
	
	
	public void switchContext(String name){
		try {
			engine.getAppiumDriver().context(name);
		} catch (Exception e) {
			LogUtility.logException("switchContext", "Unable to switch to a context.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
	
	
	public Map<String, String> getAppStringMap(){
		Map<String, String> result;
		try {
			result = engine.getAppiumDriver().getAppStringMap();
		} catch (Exception e) {
			LogUtility.logException("getAppStringMap", "Failed to retrieve appStringMap for the default language.",e, LoggingLevel.ERROR, true);
			throw e;
		}
		return result;
	}
	
	
	public Map<String, String> getAppStringMap(String language){
		Map<String, String> result;
		try {
			result = engine.getAppiumDriver().getAppStringMap(language);
		} catch (Exception e) {
			LogUtility.logException("getAppStringMap", "Failed to retrieve appStringMap for the language "+language,e, LoggingLevel.ERROR, true);
			throw e;
		}
		return result;
	}
	
	public Map<String, String> getAppStringMap(String language, String stringFile){
		Map<String, String> result;
		try {
			result = engine.getAppiumDriver().getAppStringMap(language, stringFile);
		} catch (Exception e) {
			LogUtility.logException("getAppStringMap", "Failed to retrieve appStringMap for the language "+language,e, LoggingLevel.ERROR, true);
			throw e;
		}
		return result;
	}
	
	public Set<String> getContextHandles(){
		Set<String> result;
		try {
			result = engine.getAppiumDriver().getContextHandles();
		} catch (Exception e) {
			LogUtility.logException("getContextHandles", "Failed to retrieve context handles.",e, LoggingLevel.ERROR, true);
			throw e;
		}
		return result;
	}
	
	public boolean isAppInstalled(String bundleId){
		boolean result;
		try {
			result = engine.getAppiumDriver().isAppInstalled(bundleId);
		} catch (Exception e) {
			LogUtility.logException("isAppInstalled", "Failed to check if app is installed",e, LoggingLevel.ERROR, true);
			throw e;
		}
		return result;
	}
	
	public void installApp(String appPath){
		try {
			engine.getAppiumDriver().installApp(appPath);
		} catch (Exception e) {
			LogUtility.logException("installApp", "Failed to install app with path: " + appPath,e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
	
	public void launchApp(){
		try {
			engine.getAppiumDriver().launchApp();
		} catch (Exception e) {
			LogUtility.logException("launchApp", "Failed to launch app in desiredCapabilities.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
	
	public void removeApp(String bundleId){
		try {
			engine.getAppiumDriver().removeApp(bundleId);
		} catch (Exception e) {
			LogUtility.logException("removeApp", "Failed to remove app.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
	
	public void resetApp(){
		try {
			engine.getAppiumDriver().resetApp();
		} catch (Exception e) {
			LogUtility.logException("resetApp", "Failed to reset app.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
	
	public void runAppInBackground(Duration seconds){
		try {
			//engine.getAppiumDriver().runAppInBackground(seconds);
		} catch (Exception e) {
			LogUtility.logException("resetApp", "App could not be run in background.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}

}
