package com.wb.java_af.appium;

import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;

public class AppiumAndroid {
	
	public Engine engine;
	
	public AppiumAndroid(Engine engine) {
		this.engine = engine;
	}
	
	public void openNotification(){
		try {
			engine.getAndroidDriver().openNotifications();
		} catch (Exception e) {
			LogUtility.logException("openNotification", "Failed to open notifications.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
	
	
	public String getCurrentActivity(){
		String result;
		try {
			result = engine.getAndroidDriver().currentActivity();
		} catch (Exception e) {
			LogUtility.logException("getCurrentActivity", "Failed to get current activity.",e, LoggingLevel.ERROR, true);
			throw e;
		}
		return result;
	}
	
	public void ignoreUnimportantViews(boolean compress){
		try {
			engine.getAndroidDriver().ignoreUnimportantViews(compress);
		} catch (Exception e) {
			LogUtility.logException("ignoreUnimportantViews", "There was a problem ignoring the unimportant views.",e, LoggingLevel.ERROR, true);
			throw e;
		}
	}
}

