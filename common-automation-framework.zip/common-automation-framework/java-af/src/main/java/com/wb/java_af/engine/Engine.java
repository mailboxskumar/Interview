package com.wb.java_af.engine;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ThreadGuard;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.wb.java_af.appium.Appium;
import com.wb.java_af.parameters.JsonDataParser;
import com.wb.java_af.perfecto.Perfecto;
import com.wb.java_af.reporting.ReportLibrary;
import com.wb.java_af.setup.Enums.Browser;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.setup.testparameters.EnvironmentParameters;
import com.wb.java_af.testbases.CucumberTestBase;
import com.wb.java_af.testbases.TestBase;
import com.wb.java_af.utilities.LogUtility;
import com.wb.java_af.utilities.TestConstants;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

/**
 * Configures the executions for Web, Mobile tests to be run locally, on grid or
 * on a cloud environment
 * 
 * <p>
 * Instantiates all library objects for developing scripts on Web or Mobile
 * platforms.
 * </p>
 * 
 * @author Bharat Pandey
 *
 * @see Engine
 */
public class Engine {

	private EventFiringWebDriver webDriver;
	private Cookies cookies;
	private AppiumDriver<RemoteWebElement> appiumDriver;
	private IOSDriver<RemoteWebElement> iosDriver;
	private AndroidDriver<RemoteWebElement> androidDriver;
	private JavaScriptExecutor javaScript;
	private Scroller scroller;
	private Support support;
	private Waits wait;
	private Properties props;
	private Perfecto perfecto;
	private Appium appium;
	private String sessionId = "";
	private boolean perfectoRun;
	private MultiWindowManager windows;
	private Navigator navigator;
	private Alerts alerts;
	private WebActions webActions;
	private List<String> softErrors;
	private JsonDataParser jsonDataParser;
	private ReportLibrary reportLibrary;
	private String browser, browserVersion;

	public List<String> getSoftErrors() {
		return softErrors;
	}

	public void addSoftError(String softError) {
		if (this.softErrors == null) {
			this.softErrors = new ArrayList<String>();
		}
		this.softErrors.add(softError);
	}

	public void clearSoftErrors() {
		this.softErrors = new ArrayList<String>();
	}

	public Engine() {
		initialize();
	}

	public void initialize() {
		initalizeWebActions();
		initalizeCookies();
		initalizeJavaScriptExecutor();
		initalizeScroller();
		initalizeSupport();
		initalizeWaits();
		initializeMultiWindowManager();
		initializeNavigator();
		initializeAlerts();
		initalizeProperties();
		initalizeJsonDataParser();
		initalizeReportLibrary();
	}

	/**
	 * Sets up the webdriver instance.
	 * 
	 * @param browserType
	 * @param caps
	 * @param remoteExecution
	 * @param perfecto
	 * @param mobile
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public void setUpWebDriver(Browser browserType, Capabilities caps, boolean remoteExecution, boolean perfecto,
			boolean mobile) throws Exception {
		selectDriverType(browserType, caps, remoteExecution, perfecto, mobile);
	}

	/**
	 * Creates a remote webdriver instance if remoteExecution is set to true,
	 * otherwise creates a local instance of the driver.
	 * 
	 * 
	 * @param browserType     - Browser name e.g CHROME, FIREFOX, IE, SAFARI
	 * @param caps            - Capabilities object passed to the method
	 * @param remoteExecution - Flag to set remote execution run
	 * @param perfecto        - Flag to set perfecto lab run
	 * @param mobile          - Flag to indicate if a mobile run
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public final void selectDriverType(Browser browserType, Capabilities caps, boolean remoteExecution,
			boolean perfecto, boolean mobile) throws Exception {
		if (remoteExecution) {
			setUpRemoteWebDriver(caps, perfecto);
		} else {
			setUpLocalWebDriver(browserType, caps, mobile);
		}
	}

	/**
	 * Sets up the remote webdriver. Sets up perfecto connection if perfecto flag is
	 * true otherwise sets up a grid for remote execution.
	 * <p>
	 * 
	 * @note Grid setup yet to be implemented.
	 *       </p>
	 * @param caps     - Capabilities object passed to the method
	 * @param perfecto - Flag to set perfecto run
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public void setUpRemoteWebDriver(Capabilities caps, boolean perfecto) throws Exception {
		try {
			if (perfecto) {
				webDriver = new EventFiringWebDriver(ThreadGuard.protect(createPerfectoMobileDriver(caps)));
			} else {
				webDriver = new EventFiringWebDriver(ThreadGuard.protect(createRemoteDriver(caps)));
			}

		} catch (MalformedURLException e) {
			LogUtility.logException("setUpRemoteWebDriver", "The url provided was malformed.", e, LoggingLevel.ERROR,
					true);
			throw e;
		} catch (SessionNotCreatedException e) {
			LogUtility.logException("setUpRemoteWebDriver", "The session could not be created.", e, LoggingLevel.ERROR,
					true);
			throw e;
		} catch (WebDriverException e) {
			LogUtility.logException("setUpRemoteWebDriver",
					"The webdriver created on one thread was accessed by another thread or the session could not be created",
					e, LoggingLevel.ERROR, true);
			throw e;

		}
	}

	/**
	 * Creates grid setup
	 * 
	 * @param caps - Capability object to be passed
	 * @return Remote web driver instance
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	private RemoteWebDriver createRemoteDriver(Capabilities caps) throws Exception {
		RemoteWebDriver remoteWebDriver;
		switch (props.getProperty("run.type").toLowerCase()) {
		case "grid":
			remoteWebDriver = new RemoteWebDriver(new URL(props.getProperty("grid.hub", "none")), caps);
			break;
		default:
			LogUtility.logInfo(
					"an attempt to create a remote web driver was made and run.type did not match perfecto or grid. defaulted to grid");
			remoteWebDriver = new RemoteWebDriver(new URL(props.getProperty("grid.hub", "none")), caps);
		}
		return remoteWebDriver;
	}

	/**
	 * Creates perfecto mobile driver
	 * 
	 * @param caps - Capability object to be passed
	 * @return Remote web driver instance
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	private RemoteWebDriver createPerfectoMobileDriver(Capabilities caps) throws Exception {
		RemoteWebDriver remoteWebDriver;
		initializePerfecto();
		initializeAppium(caps.getPlatform().name().toLowerCase());
		((MutableCapabilities) caps).setCapability("securityToken", props.getProperty("perfecto.securityToken"));
		URL perfectoHub = new URL(props.getProperty("perfecto.mobile.hub", "none"));
		switch (caps.getPlatform().name().toLowerCase()) {
		case "ios":
			iosDriver = new IOSDriver<>(perfectoHub, caps);
			remoteWebDriver = iosDriver;
			appiumDriver = iosDriver;
			break;
		case "android":
			androidDriver = new AndroidDriver<>(perfectoHub, caps);
			remoteWebDriver = androidDriver;
			appiumDriver = androidDriver;
			break;
		default:
			remoteWebDriver = new RemoteWebDriver(perfectoHub, caps);
			break;
		}
		return remoteWebDriver;
	}

	/**
	 * Create a local Webdriver. If mobile, creates a appium driver else creates a
	 * webdriver
	 * 
	 * @param browserType
	 * @param caps
	 * @param mobile
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public void setUpLocalWebDriver(Browser browserType, Capabilities caps, boolean mobile) throws Exception {
		if (mobile) {
			webDriver = new EventFiringWebDriver(ThreadGuard.protect(createLocalMobileDriver(caps)));
		} else {
			switch (browserType) {
			case CHROME: {
				if (caps == null) {
					webDriver = setUpLocalChromeDriver();
					break;
				} else {
					webDriver = setUpLocalChromeDriver(caps);
					break;
				}

			}
			case FIREFOX:
				if (caps == null) {
					webDriver = setUpLocalFirefoxDriver();
					break;
				} else {
					webDriver = setUpLocalFirefoxDriver(caps);
					break;
				}
			case IE:
				if (caps == null) {
					webDriver = setUpLocalIeDriver();
					break;
				} else {
					webDriver = setUpLocalIeDriver(caps);
					break;
				}
			default:
				throw new IllegalArgumentException(browserType + " is not supported. Please choose another browser.");
			}
			// Commented by Sanjay
			// setBrowser(caps.getBrowserName());
			// setBrowserVersion(caps.getVersion());
			setBrowser(webDriver.getCapabilities().getBrowserName());
			setBrowserVersion(webDriver.getCapabilities().getVersion());

		}
	}

	/**
	 * Generates the binary path based on the browser type specified
	 * 
	 * @param browser
	 * @return Binary path of the browser
	 * 
	 * @author Bharat Pandey
	 */
	public String getDriverBinaryPath(Browser browser) {
		String os = EnvironmentParameters.getShortOsName();
		String driverName = browser.name().toLowerCase();
		String driverPath = "";
		if (driverName.equals("firefox")) {
			driverName = "gecko";
		}
		driverPath = System.getProperty(TestConstants.USER_DIR) + props.getProperty("driver.directory." + os)
				+ props.getProperty(driverName + ".driver.exe" + "." + os);
		return driverPath;
	}

	/**
	 * Creates a local ios or android driver if the run.type is localMobile
	 * 
	 * @param caps
	 * @return
	 * @throws MalformedURLException
	 * 
	 * @author Bharat Pandey
	 */
	private RemoteWebDriver createLocalMobileDriver(Capabilities caps) throws MalformedURLException {
		RemoteWebDriver remoteWebDriver;
		String platform = caps.getPlatform().name().toLowerCase();
		initializeAppium(platform);
		URL localAppiumHubUrl = new URL(props.getProperty("local.appium.hub", "none"));
		switch (platform) {
		case "ios":
			iosDriver = new IOSDriver<>(localAppiumHubUrl, caps);
			remoteWebDriver = iosDriver;
			appiumDriver = iosDriver;
			break;
		case "android":
			androidDriver = new AndroidDriver<>(localAppiumHubUrl, caps);
			remoteWebDriver = androidDriver;
			appiumDriver = androidDriver;
			break;
		default:
			remoteWebDriver = new RemoteWebDriver(localAppiumHubUrl, caps);
			break;
		}
		return remoteWebDriver;
	}

	/**
	 * Create a local chrome driver with in build chromeoptions. This is called when
	 * no capabilities are provided.
	 * 
	 * @return EventFiringWebDriver
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public EventFiringWebDriver setUpLocalChromeDriver() throws Exception {
		EventFiringWebDriver webDriver;

		String downloadFilepath = System.getProperty("user.dir") + File.separatorChar
				+ props.getProperty("file.download.directory");
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadFilepath);

		ChromeOptions chromeOptions;
		chromeOptions = new ChromeOptions();
		chromeOptions.setExperimentalOption("prefs", chromePrefs);

		System.setProperty(TestConstants.CHROME_WEB_DRIVER, getDriverBinaryPath(Browser.CHROME));
		webDriver = new EventFiringWebDriver(ThreadGuard.protect(new ChromeDriver(chromeOptions)));
		return webDriver;
	}

	/**
	 * Create a local chrome driver with capabilities provided from the json
	 * browserCapabilities.json
	 * 
	 * @param caps
	 * @return EventFiringWebDriver
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public EventFiringWebDriver setUpLocalChromeDriver(Capabilities caps) throws Exception {
		EventFiringWebDriver webDriver;

		String downloadFilepath = System.getProperty("user.dir") + File.separatorChar
				+ props.getProperty("file.download.directory");
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadFilepath);

		ChromeOptions chromeOptions;
		chromeOptions = new ChromeOptions();
		chromeOptions.setExperimentalOption("prefs", chromePrefs);
		chromeOptions.merge(caps);

		// chromeOptions = (ChromeOptions) caps;

		System.setProperty(TestConstants.CHROME_WEB_DRIVER, getDriverBinaryPath(Browser.CHROME));
		webDriver = new EventFiringWebDriver(ThreadGuard.protect(new ChromeDriver(chromeOptions)));
		return webDriver;
	}

	/**
	 * Create a local firefox driver. This is called when no capabilities are
	 * provided.
	 * 
	 * @return EventFiringWebDriver
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public EventFiringWebDriver setUpLocalFirefoxDriver() throws Exception {
		EventFiringWebDriver webDriver;
		try {
			System.setProperty(TestConstants.GECKO_WEB_DRIVER, getDriverBinaryPath(Browser.FIREFOX));
		} catch (SecurityException e) {
			LogUtility.logException("setUpLocalFirefoxDriver",
					"A property was not allowed to be set by the security manager", e, LoggingLevel.ERROR, true);
			throw e;
		} catch (NullPointerException e) {
			LogUtility.logException("setUpLocalFirefoxDriver", "A property was not set. Check system properties", e,
					LoggingLevel.ERROR, true);
			throw e;
		} catch (IllegalArgumentException e) {
			LogUtility.logException("setUpLocalFirefoxDriver", "A key was not set. Check system properties", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		webDriver = new EventFiringWebDriver(ThreadGuard.protect(new FirefoxDriver()));
		return webDriver;
	}

	/**
	 * Create a local firefox driver with capabilities provided from the json
	 * browserCapabilities.json
	 * 
	 * @param caps
	 * @return EventFiringWebDriver
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public EventFiringWebDriver setUpLocalFirefoxDriver(Capabilities caps) throws Exception {
		EventFiringWebDriver webDriver;
		FirefoxOptions options = (FirefoxOptions) caps;
		try {
			System.setProperty(TestConstants.GECKO_WEB_DRIVER, getDriverBinaryPath(Browser.FIREFOX));
		} catch (SecurityException e) {
			LogUtility.logException("setUpLocalFirefoxDriver",
					"A property was not allowed to be set by the security manager", e, LoggingLevel.ERROR, true);
			throw e;
		} catch (NullPointerException e) {
			LogUtility.logException("setUpLocalFirefoxDriver", "A property was not set. Check system properties", e,
					LoggingLevel.ERROR, true);
			throw e;
		} catch (IllegalArgumentException e) {
			LogUtility.logException("setUpLocalFirefoxDriver", "A key was not set. Check system properties", e,
					LoggingLevel.ERROR, true);
			throw e;
		}
		webDriver = new EventFiringWebDriver(ThreadGuard.protect(new FirefoxDriver(options)));
		return webDriver;
	}

	/**
	 * Create a local internet explorer driver. This is called when no capabilities
	 * are provided.
	 * 
	 * @return EventFiringWebDriver
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public EventFiringWebDriver setUpLocalIeDriver() throws Exception {
		EventFiringWebDriver webDriver;
		System.setProperty(TestConstants.IE_WEB_DRIVER, getDriverBinaryPath(Browser.IE));
		DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
		ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		ieCapabilities.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR, "accept");
		ieCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, false);
		webDriver = new EventFiringWebDriver(ThreadGuard.protect(new InternetExplorerDriver()));
		return webDriver;
	}

	/**
	 * Create a local internet explorer driver with capabilities provided from the
	 * json browserCapabilities.json
	 * 
	 * @param caps
	 * @return EventFiringWebDriver
	 * @throws Exception
	 * 
	 * @author Bharat Pandey
	 */
	public EventFiringWebDriver setUpLocalIeDriver(Capabilities caps) throws Exception {
		EventFiringWebDriver webDriver;
		InternetExplorerOptions options = (InternetExplorerOptions) caps;
		System.setProperty(TestConstants.IE_WEB_DRIVER, getDriverBinaryPath(Browser.IE));
		webDriver = new EventFiringWebDriver(ThreadGuard.protect(new InternetExplorerDriver(options)));
		return webDriver;
	}

	private void initalizeReportLibrary() {
		reportLibrary = new ReportLibrary(this);
	}

	private void initalizeJsonDataParser() {
		jsonDataParser = new JsonDataParser(this);
	}

	private void initalizeWaits() {
		wait = new Waits(this);
	}

	private void initalizeSupport() {
		support = new Support(this);
	}

	private void initalizeScroller() {
		scroller = new Scroller(this);
	}

	private void initalizeJavaScriptExecutor() {
		javaScript = new JavaScriptExecutor(this);
	}

	private void initalizeCookies() {
		cookies = new Cookies(this);
	}

	private void initalizeWebActions() {
		webActions = new WebActions(this);
	}

	private void initalizeProperties() {
		if (TestBase.props != null) {
			props = TestBase.props;
		} else {
			props = CucumberTestBase.props;
		}
	}

	private void initializePerfecto() {
		perfecto = new Perfecto(this);
	}

	private void initializeAppium(String platform) {
		appium = new Appium(this, platform);
	}

	public void initializeMultiWindowManager() {
		windows = new MultiWindowManager(this);
	}

	public void initializeNavigator() {
		navigator = new Navigator(this);
	}

	public void initializeAlerts() {
		alerts = new Alerts(this);
	}

	public ReportLibrary getReportLibrary() {
		return reportLibrary;
	}

	public EventFiringWebDriver getWebDriver() {
		return webDriver;
	}

	public void setWebDriver(EventFiringWebDriver webDriver) {
		this.webDriver = webDriver;
	}

	public Cookies getCookies() {
		return cookies;
	}

	public void setCookies(Cookies cookies) {
		this.cookies = cookies;
	}

	public AppiumDriver<RemoteWebElement> getAppiumDriver() {
		return appiumDriver;
	}

	public void setAppiumDriver(AppiumDriver<RemoteWebElement> appiumDriver) {
		this.appiumDriver = appiumDriver;
	}

	public IOSDriver<RemoteWebElement> getIosDriver() {
		return iosDriver;
	}

	public void setIosDriver(IOSDriver<RemoteWebElement> iosDriver) {
		this.iosDriver = iosDriver;
	}

	public AndroidDriver<RemoteWebElement> getAndroidDriver() {
		return androidDriver;
	}

	public void setAndroidDriver(AndroidDriver<RemoteWebElement> androidDriver) {
		this.androidDriver = androidDriver;
	}

	public JavaScriptExecutor getJavaScript() {
		return javaScript;
	}

	public void setJavaScript(JavaScriptExecutor javaScript) {
		this.javaScript = javaScript;
	}

	public Scroller getScroller() {
		return scroller;
	}

	public void setScroller(Scroller scroller) {
		this.scroller = scroller;
	}

	public Support getSupport() {
		return support;
	}

	public void setSupport(Support support) {
		this.support = support;
	}

	public Waits getWait() {
		return wait;
	}

	public void setWait(Waits wait) {
		this.wait = wait;
	}

	public JsonDataParser getJsonDataParser() {
		return jsonDataParser;
	}

	public void setJsonDataParser(JsonDataParser jsonDataParser) {
		this.jsonDataParser = jsonDataParser;
	}

	public Properties getProps() {
		return props;
	}

	public void setProps(Properties props) {
		this.props = props;
	}

	public Perfecto getPerfecto() {
		return perfecto;
	}

	public void setPerfecto(Perfecto perfecto) {
		this.perfecto = perfecto;
	}

	public Appium getAppium() {
		return appium;
	}

	public void setAppium(Appium appium) {
		this.appium = appium;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public boolean isPerfectoRun() {
		return perfectoRun;
	}

	public void setPerfectoRun(boolean perfectoRun) {
		this.perfectoRun = perfectoRun;
	}

	public MultiWindowManager getWindows() {
		return windows;
	}

	public void setWindows(MultiWindowManager windows) {
		this.windows = windows;
	}

	public Navigator getNavigator() {
		return navigator;
	}

	public void setNavigator(Navigator navigator) {
		this.navigator = navigator;
	}

	public Alerts getAlerts() {
		return alerts;
	}

	public void setAlerts(Alerts alerts) {
		this.alerts = alerts;
	}

	public WebActions getWebActions() {
		return webActions;
	}

	public void setWebActions(WebActions webActions) {
		this.webActions = webActions;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getBrowserVersion() {
		return browserVersion;
	}

	public void setBrowserVersion(String browserVersion) {
		this.browserVersion = browserVersion;
	}

}
