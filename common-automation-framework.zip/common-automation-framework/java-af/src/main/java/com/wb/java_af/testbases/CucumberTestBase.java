package com.wb.java_af.testbases;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.http.cookie.Cookie;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Capabilities;
import org.testng.IExecutionListener;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResult;
import com.perfecto.reportium.test.result.TestResultFactory;
import com.wb.java_af.capabilities.CapabilityParser;
import com.wb.java_af.cucmber.CucumberFeatureWrapper;
import com.wb.java_af.cucmber.PickleEventWrapper;
import com.wb.java_af.cucmber.TestNGCucumberRunner;
import com.wb.java_af.reporting.ExtentManager;
import com.wb.java_af.reporting.ExtentTestManager;
import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.setup.testparameters.EnvironmentParameters;
import com.wb.java_af.setup.testparameters.EnvironmentParametersInit;
import com.wb.java_af.utilities.LogUtility;
import com.wb.java_af.utilities.TestConstants;

import cucumber.api.Result;
import cucumber.api.Result.Type;
import cucumber.api.Scenario;
import gherkin.pickles.PickleTag;

@Listeners(CucumberTestBase.class)
public class CucumberTestBase implements IExecutionListener {

	public static Properties props;
	public static Properties envProps;
	String propertiesFile = "testparameters.properties";
	public EnvironmentParameters envParams;
	private static String loggingFilePath;
	private boolean remoteExecution;
	private boolean perfecto;
	private boolean mobile;
	private static String extentReport;
	private static String reportPath, screenShotDir, dateFormat, reportDirectoryEnvironmentSeparator, reportFilePrefix,
			separator, reportDirectoryName, reportDirName;
	private static boolean onlyStartOnce;
	private static boolean onlyFinishOnce;
	private boolean configError;
	private String device;
	private String browser;
	String browserVersion;
	private ReportiumClient reportiumClient;
	private String envPlatform;
	private TestNGCucumberRunner testNGCucumberRunner;
	int numberOfTags = 0;

	private static int totalSceanariosExecuted = 1;
	private static int numberOfIterationsCurrentSceanario = 1;
	private static String previousScenarioName = "";
	private static String currentScenarioName = "";

	private static boolean updateALMTestRunStatus;

	@Override
	public void onExecutionStart() {
		defaultOnExecutionStart();
	}

	public void defaultOnExecutionStart() {
		if (!onlyStartOnce) {
			System.out.println(
					"Script Execution Started at " + new SimpleDateFormat("yyy_MM-dd HH:mm:ss").format(new Date()));
			loadProperties();
			loadEnvironmentalProperties();
			setLogPath();
			initEnvironmentalParams();
			setUpExtent();
			setUpdateALMTestRunStatus();
			onlyStartOnce = true;
		}
	}

	@BeforeSuite
	public void beforeSuite(ITestContext context) throws Exception {
	}

	@BeforeTest
	public void beforeTest(ITestContext context) throws Exception {
		initEnvironmentalParams();
		if (updateALMTestRunStatus)
			almConnectionSetup(context);
	}

	@BeforeClass()
	public void beforeClass(ITestContext context) throws Exception {
		setRemoteExecution();
		setMobileRun();
		setPerfectoRun();
		testNGCucumberRunner = new TestNGCucumberRunner(context, this.getClass());
	}

	@BeforeMethod
	public void beforeMethod(ITestContext context, Method method) throws Exception {
		try {
			logDividerSetup(method);
			engineSetUp(context);
			methodSetup();
		} catch (Exception e) {
			LogUtility.logException("BeforeMethod", "There was a configuration issue.", e, LoggingLevel.ERROR, true);
			configError = true;
			throw e;
		}
	}

	@Test(groups = { "cucumber" }, description = "Runs Cucumber Scenarios", dataProvider = "scenarios")
	public void runScenario(PickleEventWrapper pickleWrapper, CucumberFeatureWrapper featureWrapper) throws Throwable {
		try {
			String featureFileTopTag = pickleWrapper.getPickleEvent().pickle.getTags().get(0).getName();
			currentScenarioName = pickleWrapper.getPickleEvent().pickle.getName().toString();
			String almTestCaseIDs = getALMScenarioTags(pickleWrapper);

			if (totalSceanariosExecuted == 1) {
				previousScenarioName = currentScenarioName;
				reportSetup(currentScenarioName, almTestCaseIDs);
				assignReportTag(featureFileTopTag);
			} else if (!currentScenarioName.equals(previousScenarioName)) {
				previousScenarioName = currentScenarioName;
				numberOfIterationsCurrentSceanario = 1;
				reportSetup(currentScenarioName, almTestCaseIDs);
				assignReportTag(featureFileTopTag);
			}

			reportNodeSetup("Iteration: " + numberOfIterationsCurrentSceanario + "  " + getTestMetaData()
					+ getUniqueScenarioTag(pickleWrapper));

			numberOfIterationsCurrentSceanario = numberOfIterationsCurrentSceanario + 1;
			totalSceanariosExecuted = totalSceanariosExecuted + 1;

			testNGCucumberRunner.runScenario(pickleWrapper.getPickleEvent());

		} catch (Exception e) {
			numberOfIterationsCurrentSceanario = numberOfIterationsCurrentSceanario + 1;
			LogUtility.logException("runScenario", "There was an issue with the test run.", e, LoggingLevel.ERROR,
					true);
			ExtentTestManager.getTest().fail(e);
			// ExtentTestManager.getParentTest().fail(currentScenarioName);
			e.printStackTrace();
			throw e;
		}
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Features", dataProvider = "features", enabled = false)
	public void runFeatures(PickleEventWrapper pickleWrapper) throws Throwable {
		try {
			testNGCucumberRunner.runScenario(pickleWrapper.getPickleEvent());
		} catch (Exception e) {
			LogUtility.logException("runFeatures", e, LoggingLevel.ERROR, true);
			ExtentTestManager.getTest().fail(e);
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod(ITestResult result) throws Throwable {
		if (configError) {
			result.setStatus(3);
			configError = false;
		}
		driverTearDown();
		flushExtentManager();
		logDividerTearDown(result);
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() {
		if (this.testNGCucumberRunner == null) {
			return;
		}
		testNGCucumberRunner.finish();
	}

	@AfterTest
	public final void afterTest() throws Exception {
		if (updateALMTestRunStatus)
			updateTestRunStatusInALM();
	}

	@AfterSuite
	public final void afterSuite() throws Exception {

	}

	@DataProvider(parallel = true)
	public Object[][] scenarios() {
		return testNGCucumberRunner.provideScenarios();
	}

	@Override
	public void onExecutionFinish() {
		if (!onlyFinishOnce) {
			System.out.println(
					"Script Execution Finished at " + new SimpleDateFormat("yyy_MM-dd HH:mm:ss").format(new Date()));
			onlyFinishOnce = true;
		}
	}

	public boolean isUpdateALMTestRunStatus() {
		return updateALMTestRunStatus;
	}

	public void setUpdateALMTestRunStatus() {
		if (props.getProperty("alm.run.status.update").equals("true"))
			updateALMTestRunStatus = true;
	}

	public void setRemoteExecution() {
		if ((props.getProperty("run.type", "local").equalsIgnoreCase("perfectoMobile"))
				|| props.getProperty("run.type", "local").equalsIgnoreCase("grid")) {
			remoteExecution = true;
		}
	}

	public void setPerfectoRun() {
		if ((props.getProperty("run.type", "local").equalsIgnoreCase("perfectoMobile"))) {
			perfecto = true;
		}
	}

	public void setMobileRun() {
		String runType = props.getProperty("run.type", "local");
		if ((runType.equalsIgnoreCase("localMobile")) || (runType.equalsIgnoreCase("perfectoMobile"))) {
			mobile = true;
		}
	}

	public void logDividerSetup(Method method) {
		LogUtility.startTestCase(method.getName());
	}

	protected void engineSetUp(ITestContext context) throws Exception {
		envPlatform = props.getProperty("run.type");
		setTestParameters(context);
		Capabilities caps = null;
		if (mobile) {
			caps = CapabilityParser.parseMobileCapabilities("capabilities/deviceCapabilities.json", envPlatform,
					device);
		} else {
			caps = CapabilityParser.parseBrowserCapabilities("capabilities/browserCapabilities.json", envPlatform,
					browser);
		}

		ConcurrentEngines.createEngine(caps, browser, remoteExecution, perfecto, mobile);
	}

	private void setTestParameters(ITestContext context) {
		browser = System.getProperty("browser");
		device = System.getProperty("device");
		Map<String, String> allParameters = context.getCurrentXmlTest().getAllParameters();
		for (Map.Entry<String, String> entry : allParameters.entrySet()) {
			if (entry.getKey().equals("device")) {
				device = entry.getValue();
			} else if (entry.getKey().equals("browser")) {
				browser = entry.getValue();
			}
		}
	}

	protected void methodSetup() {
		if (!(mobile || perfecto)) {
			getApp();
			maximizeWindow();
		}
	}

	/**
	 * To create ALM Connection
	 * 
	 * @author Sanjay Samantaray
	 * @param context
	 */

	public void almConnectionSetup(ITestContext context) {
		try {
			List<Cookie> cookiesList;
			if (context.getCurrentXmlTest().getAllParameters().containsKey("testSetId")) {
				String testSetID = context.getCurrentXmlTest().getParameter("testSetId");
				if (testSetID != null && testSetID != "") {
					cookiesList = ConcurrentEngines.getAlmConnector().signin();
					Map<String, Map<String, String>> testEntityList = ConcurrentEngines.getAlmConnector()
							.getTestCaseIdList(testSetID, cookiesList);
					ConcurrentEngines.setALMTestEntityList(testEntityList);
					ConcurrentEngines.getAlmConnector().signout(cookiesList);
				} else
					LogUtility.logInfo(
							"Invalid or Blank TestSet ID is provided. TestCase list cannot be fetched from the TestSet.");
			} else {
				updateALMTestRunStatus = false;
				System.err.println("ERROR: alm.run.status.update" + "=true in [" + propertiesFile
						+ "] file but ALM testSetId is not provided in the xml file for the test name : ["
						+ context.getCurrentXmlTest().getName() + "]");
			}
		} catch (Exception e) {
			LogUtility.logException("almConnectionSetup", e, LoggingLevel.ERROR, true);
			e.printStackTrace();
		}

	}

	public void addScenarioALMTags(Scenario scenario) {
		if (!(ConcurrentEngines.getScenarioALMTags().containsKey(scenario.getName()))) {
			for (String tag : scenario.getSourceTagNames()) {
				if (tag.startsWith("@ALM-")) {
					String testID = tag.replace("@ALM-", "");
					ConcurrentEngines.setScenarioALMTags(testID, scenario.getName());
				}
			}
			LogUtility.logInfo("ALM TestCase ID(s) fetched from Current Scenario tags : "
					+ ConcurrentEngines.getScenarioALMTags());
		}
	}

	public void addCurrentScenarioStatus(Scenario scenario, boolean softAssertionFlag) {
		String testCaseUpdateStatus = (scenario.getStatus() == Type.PASSED) && !softAssertionFlag ? "Passed" : "Failed";
		String scenarioName = scenario.getName();
		try {
			if (!ConcurrentEngines.getScenarioStatusMap().isEmpty()
					&& ConcurrentEngines.getScenarioStatusMap().containsKey(scenarioName)) {
				if (!ConcurrentEngines.getScenarioStatusMap().get(scenarioName).equals("Failed"))
					ConcurrentEngines.setScenarioStatusMap(scenarioName, testCaseUpdateStatus);
			} else
				ConcurrentEngines.setScenarioStatusMap(scenarioName, testCaseUpdateStatus);
		} catch (Exception e) {
			LogUtility.logInfo("Scenario Status map is null... ");
		}
	}

	public void updateTestRunStatusInALM() {

		long startTime = System.currentTimeMillis();
		String deviceORBrowser = "";
		boolean isMobile = false;

		Map<String, String> filterdMap = new HashMap<String, String>();
		for (Map.Entry<String, String> status : ConcurrentEngines.getScenarioStatusMap().entrySet()) {
			for (Map.Entry<String, String> tags : ConcurrentEngines.getScenarioALMTags().entrySet()) {
				if (tags.getValue().equals(status.getKey()))
					filterdMap.put(tags.getKey(), status.getValue());
			}
		}

		if (!(mobile || perfecto))
			deviceORBrowser = browser;
		else {
			deviceORBrowser = device;
			isMobile = true;
		}

		if (ConcurrentEngines.getALMTestEntityList() != null) {
			try {
				List<Cookie> cookiesList = ConcurrentEngines.getAlmConnector().signin();

				for (Map.Entry<String, String> testID : filterdMap.entrySet()) {

					String currentId = testID.getKey();
					String testStatus = testID.getValue();

					if (ConcurrentEngines.getALMTestEntityList().containsKey(currentId)
							&& !currentId.equalsIgnoreCase("")) {

						Map<String, String> testCaseDetailsMap = ConcurrentEngines.getALMTestEntityList()
								.get(currentId);
						LogUtility.logInfo(
								"ALM test case detail map for test id: " + currentId + " is " + testCaseDetailsMap);
						String runId = ConcurrentEngines.getAlmConnector().createTestRun(testCaseDetailsMap,
								cookiesList);
						String cycleId = testCaseDetailsMap.get("testcycl-id");
						// TODO : Sanjay: Need to update elapsed time for each scenario
						ConcurrentEngines.getAlmConnector().updateTestInstance(cycleId, cookiesList, isMobile,
								deviceORBrowser, "");
						ConcurrentEngines.getAlmConnector().updateTestRun(testCaseDetailsMap, cookiesList, runId,
								testStatus);
						ConcurrentEngines.getAlmConnector().updateTestRunSteps(cookiesList, runId, testStatus);
					} else {
						System.err.println("updateTestRunStatusInALM--> WARN: Test ID:" + currentId
								+ "Not found in Current TestSet ID OR Test ID is null.. ");
						LogUtility.logWarn("updateTestRunStatusInALM",
								"WARN: Test ID:" + currentId + "Not found in Current TestSet ID OR Test ID is null.. ");
					}
				}
				ConcurrentEngines.getAlmConnector().signout(cookiesList);
			} catch (Exception e) {
				LogUtility.logException("updateTestRunStatusInALM", e, LoggingLevel.ERROR, true);
				e.printStackTrace();
			}
		} else
			LogUtility.logError("updateTestRunStatusInALM-->",
					"Test EntityList is null or blank,Could not create/update test run status...");

		long endTime = System.currentTimeMillis();
		LogUtility.logInfo("Total Time taken for ALM Status update: " + (endTime - startTime) / 1000 + " seconds.");
	}

	public void flushExtentManager() {
		if (extentReport.equalsIgnoreCase("true")) {
			if (ExtentManager.getInstance() != null) {
				ExtentManager.getInstance().flush();
			}
		}
	}

	public void driverTearDown() {
		ConcurrentEngines.destroyEngine();
	}

	public void logDividerTearDown(ITestResult result) {
		LogUtility.endTestCase(result.getMethod().getMethodName());
	}

	public void testPass(Scenario scenario) {
		String methodName = scenario.getName();
		System.out.println(methodName + "()--Passed");
		LogUtility.logInfo("Test Passed: " + methodName);
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentTestManager.getTest().log(Status.PASS, "Test Passed");
		}
	}

	public void testSkip(Scenario scenario) {
		String methodName = scenario.getName();
		System.out.println(methodName + "()--Skipped");
		LogUtility.logInfo("Test Skipped: " + methodName);
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentTestManager.getTest().log(Status.SKIP, "Test Skipped");
		}
	}

	public void testFail(Scenario scenario) {
		String methodName = scenario.getName();
		System.out.println(methodName + "()--Failed");
		LogUtility.logInfo("Test Failed: " + methodName);
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");

			// Commented By Sanjay : 03rd Jun 2019

			/*
			 * String base64String = captureBase64(scenario.getName()); try {
			 * ExtentTestManager.getTest().log(Status.FAIL, "",
			 * MediaEntityBuilder.createScreenCaptureFromBase64String(base64String).build())
			 * ; } catch (IOException e) { LogUtility.logError(methodName,
			 * "Screenshot could not be captured. Possible causes are directory not found or access to it."
			 * ); e.printStackTrace(); }
			 */
		}
	}

	public void getApp() {
		try {
			ConcurrentEngines.getEngine().getNavigator().goToUrl(ConcurrentEngines.envParams.getAppUrl());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	public void maximizeWindow() {
		ConcurrentEngines.getEngine().getWindows().maximizeWindow();
	}

	public void loadProperties() {

		try {
			props = new Properties();

			InputStreamReader input = new InputStreamReader(
					getClass().getClassLoader().getResourceAsStream(propertiesFile));

			if (input != null) {
				props.load(input);
			}
		} catch (Exception e) {
			LogUtility.logException("loadProperties", "There was a problem loading properties file.", e,
					LoggingLevel.ERROR, true);
		}
	}

	public void setLogPath() {
		loggingFilePath = System.getProperty(TestConstants.USER_DIR) + File.separator + "logs" + File.separator;
		System.setProperty("logPath", loggingFilePath);
	}

	public void initEnvironmentalParams() {
		envParams = EnvironmentParametersInit.intialize();
	}

	public void loadEnvironmentalProperties() {
		envProps = EnvironmentParametersInit.loadEnvPropertiesFile();
	}

	public void setUpExtent() {
		extentReport = props.getProperty("extent.report", "false");

		if (extentReport.equals("true")) {
			String os = EnvironmentParameters.getShortOsName();
			dateFormat = props.getProperty("date.format");
			reportDirectoryEnvironmentSeparator = props.getProperty("report.directory.environment.separator");
			reportFilePrefix = props.getProperty("reporting.directory.prefix");
			reportDirName = props.getProperty("report.directory." + os);
			screenShotDir = props.getProperty("screenshots.directory." + os);
			separator = props.getProperty("separator." + os);
			reportPath = new File(System.getProperty(TestConstants.USER_DIR)) + reportDirName;

			DateFormat currentDate = new SimpleDateFormat(dateFormat);
			reportDirectoryName = System.getProperty("environment") + reportDirectoryEnvironmentSeparator
					+ reportFilePrefix + reportDirectoryEnvironmentSeparator + currentDate.format(new Date()).toString()
					+ separator;

			// Commented by Sanjay : No need to create Screenshot directory
			// File screenshotDirectory = new File(reportPath + reportDirectoryName +
			// screenShotDir);

			File screenshotDirectory = new File(reportPath + reportDirectoryName);
			screenshotDirectory.mkdirs();
		}
	}

	public void startReportium(Scenario scenario) {
		numberOfTags = scenario.getSourceTagNames().size();
		reportiumClient = ConcurrentEngines.getEngine().getPerfecto().getReportiumClient().getInstance();
		reportiumClient.testStart(scenario.getName(),
				new TestContext(scenario.getSourceTagNames().toArray(new String[numberOfTags])));
	}

	/**
	 * This method is used to find the failure reason from the given JSON file in
	 * location - src/main/resources/failureReasons.json
	 *
	 * @param actualExceptionMessage - The failure exception stacktrace from the
	 *                               test failure
	 * @return
	 */
	private static String findFailureReason(String actualExceptionMessage) {
		String jsonStr;
		String failureConfigLoc = "src/main/resources/failureReasons.json";
		try {
			jsonStr = FileUtils.readFileToString(new File(failureConfigLoc), "UTF-8");
			JSONArray frArr = new JSONArray(jsonStr);
			List<String> failureReasons = new ArrayList<String>();
			for (int i = 0; i < frArr.length(); i++) {
				JSONObject jsonObj = frArr.getJSONObject(i);
				String tempKey = "";
				for (String key : jsonObj.keySet()) {
					tempKey = key;
					failureReasons.add(key);
				}
				JSONArray tempArray = jsonObj.getJSONArray(tempKey);

				for (int j = 0; j < tempArray.length(); j++) {
					String excepMsg = tempArray.getString(j);
					if (actualExceptionMessage.contains(excepMsg)) {
						return tempKey;
					}
				}
			}
			return "";
		} catch (IOException e) {
			return "";
		}
	}

	public void stopReportium(Scenario scenario, boolean softAssertFlag) {
		int numberOfTags = scenario.getSourceTagNames().size();
		if (reportiumClient != null) {
			try {
				if (scenario.getStatus() == Type.PASSED && !softAssertFlag) {
					reportiumClient.testStop(TestResultFactory.createSuccess(),
							new TestContext(scenario.getSourceTagNames().toArray(new String[numberOfTags])));
				} else {
					if (softAssertFlag) {
						String errorMessage = "";
						List<String> errorList = ConcurrentEngines.getEngine().getSoftErrors();
						for (int i = 0; i < errorList.size(); i++) {
							errorMessage = errorMessage + "Soft Error Number - " + i + ": " + errorList.get(i);
						}
						Exception scenarioException = logError(scenario);
						if (scenarioException != null) {
							errorMessage = errorMessage + "Final Error was - " + scenarioException.getStackTrace();
						}

						reportiumClient.testStop(TestResultFactory.createFailure(errorMessage),
								new TestContext(scenario.getSourceTagNames().toArray(new String[numberOfTags])));
					} else {
						String errorMessage = "";
						Exception scenarioException = logError(scenario);
						if (scenarioException != null) {
							errorMessage = errorMessage + ExceptionUtils.getStackTrace(scenarioException);
						}
						System.out.println(errorMessage);
						String failureReason = findFailureReason(errorMessage);
						if (!failureReason.isEmpty()) {
							System.out.println("Adding a failure reaosn");
							TestResult reportiumResult = TestResultFactory.createFailure(
									errorMessage.isEmpty() ? "An error occurred" : errorMessage, scenarioException,
									failureReason);
							reportiumClient.testStop(reportiumResult);
						} else {
							System.out.println("FF not found");
							reportiumClient.testStop(TestResultFactory.createFailure(errorMessage),
									new TestContext(scenario.getSourceTagNames().toArray(new String[numberOfTags])));
						}

					}
				}
			} catch (RuntimeException re) {
				reportiumClient.testStop(TestResultFactory.createFailure("Error occurred running the scenario.", re),
						new TestContext(scenario.getSourceTagNames().toArray(new String[numberOfTags])));
				re.printStackTrace();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public Exception logError(Scenario scenario) {
		Field field = FieldUtils.getField(scenario.getClass(), "stepResults", true);
		field.setAccessible(true);
		try {
			ArrayList<Result> results = (ArrayList<Result>) field.get(scenario);
			for (Result result : results) {
				if (result.getError() != null) {
					return (Exception) result.getError();

				}
			}
		} catch (Exception e) {
			LogUtility.logException(scenario.getName(), "Error while logging error", e, LoggingLevel.ERROR, true);
		}
		return null;
	}

	public void reportSetup(String scenario) {
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentManager.getInstance(reportDirectoryName);
			ExtentTestManager.createTest("Scenario: " + scenario + getTestMetaData());
		}
	}

	public void reportSetup(String scenario, String almTestCaseID) {
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentManager.getInstance(reportDirectoryName);
			ExtentTestManager.createTest("Scenario: " + scenario + getTestCaseID(almTestCaseID));
		}
	}

	public String getALMScenarioTags(PickleEventWrapper pickleWrapper) {
		List<PickleTag> scenarioTags = pickleWrapper.getPickleEvent().pickle.getTags();
		List<String> scenarioTagList = new ArrayList<String>();
		for (PickleTag tag : scenarioTags) {
			if (tag.getName().startsWith("@ALM-"))
				scenarioTagList.add(tag.getName().split("-")[1]);
		}
		return scenarioTagList.toString();
	}

	public String getUniqueScenarioTag(PickleEventWrapper pickleWrapper) {
		List<String> scenarioTagList = new ArrayList<String>();
		List<PickleTag> scenarioTags = pickleWrapper.getPickleEvent().pickle.getTags();
		for (int i = scenarioTags.size() - 1; i >= 1; i--) {
			String tag = scenarioTags.get(i).getName();
			if (!tag.startsWith("@ALM") && !tag.toUpperCase().contains("REGRESSION")
					&& !tag.toUpperCase().contains("SMOKE") && !tag.toUpperCase().contains("STABILIZE"))
				scenarioTagList.add(tag);
		}
		return getScenarioTag(scenarioTagList.toString());
	}

	public String getScenarioTag(String scenarioTag) {
		return "<font size=\"-1.8\" color=\"orange\"><br />Scenario Tag(s) : " + scenarioTag + "</font>";
	}

	public String getTestCaseID(String almTestCaseID) {
		return "<font size=\"-1.8\" color=\"orange\"><br />ALM Test Case ID(s): " + almTestCaseID + "</font>";
	}

	public void reportNodeSetup(String nodeName) {
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentTestManager.createNode(nodeName);
		}
	}

	public void assignReportTag(String featureFileTopTag) {
		ExtentTestManager.assignCategory(ExtentTestManager.getParentTest(), featureFileTopTag);
	}

	private String getTestMetaData() {
		String deviceId = null;
		if (mobile) {
			try {
				deviceId = CapabilityParser.getDeviceID("capabilities/deviceCapabilities.json", envPlatform, device);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return mobile
				? "<font size=\"-1.8\" color=\"orange\"><br />Device: " + device + " Env: " + envPlatform + "<br />ID: "
						+ deviceId + "</font>"
				: "<font size=\"-1.8\" color=\"orange\"><br />Browser: " + browser + "</font>";

	}

	public void reportTearDownMethod(Scenario scenario, boolean flag) {
		if ((scenario.getStatus() == Type.PASSED) && !(flag)) {
			testPass(scenario);
		} else if ((scenario.getStatus() == Type.PASSED) && (flag)) {
			testFail(scenario);
		} else if (scenario.getStatus() == Type.SKIPPED || scenario.getStatus() == Type.PENDING) {
			testSkip(scenario);
		} else
			testFail(scenario);
	}

}
