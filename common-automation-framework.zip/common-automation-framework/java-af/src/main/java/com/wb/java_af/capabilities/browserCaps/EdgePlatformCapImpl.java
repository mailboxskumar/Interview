package com.wb.java_af.capabilities.browserCaps;

import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONObject;
import org.openqa.selenium.edge.EdgeOptions;

public class EdgePlatformCapImpl implements BrowserCaps {

	public EdgeOptions options;
	String filePath, env, platformHost;

	public EdgePlatformCapImpl(String filePath, String env, String platformHost) {
		this.filePath = filePath;
		this.env = env;
		this.platformHost = platformHost;
	}

	/**
	 * 
	 * Sets up edge options to launch edge with specified capabilities passed in
	 * json. 
	 * 
	 * @return Edge Driver Options
	 * @author Bharat Pandey
	 * 
	 * @see com.wb.java_af.capabilities.browserCaps.BrowserCaps#getCaps()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public EdgeOptions getCaps() {
		JSONObject environment = BrowserCaps.parseJsonFile(filePath, env);
		String defaultPlatformHost = (String) environment.keySet().stream().findFirst().orElse(null);
		Map<String, Object> envCapabilities = null;
		if (platformHost == null || platformHost == "") {
			platformHost = defaultPlatformHost;
		}
		if (env.equalsIgnoreCase("local") && platformHost.contains("edge")) {
			options = new EdgeOptions();
			envCapabilities = (Map<String, Object>) environment.get(platformHost);

			Iterator<Map.Entry<String, Object>> it = envCapabilities.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, Object> pair = it.next();
				String key = pair.getKey().toString();
				Object value = pair.getValue().toString();
				if (((String) value).equalsIgnoreCase("true") || ((String) value).equalsIgnoreCase("false")) {
					options.setCapability(key, Boolean.parseBoolean(((String) value)));
				} else {
					options.setCapability(key, value);
				}
			}
		}
		return options;
	}

	public static void main(String[] args) {
		new EdgePlatformCapImpl("capabilities/browserCapabilities.json", "local", "edge").getCaps();
	}

}
