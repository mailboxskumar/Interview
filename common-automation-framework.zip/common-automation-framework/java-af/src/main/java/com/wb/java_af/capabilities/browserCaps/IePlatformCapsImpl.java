package com.wb.java_af.capabilities.browserCaps;

import java.time.Duration;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONObject;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.ie.ElementScrollBehavior;
import org.openqa.selenium.ie.InternetExplorerOptions;

public class IePlatformCapsImpl implements BrowserCaps {

	public InternetExplorerOptions options;
	String filePath, env, platformHost;

	public IePlatformCapsImpl(String filePath, String env, String platformHost) {
		this.filePath = filePath;
		this.env = env;
		this.platformHost = platformHost;
	}

	/**
	 * 
	 * Sets up internet explorer options to launch ie with specified capabilities passed in
	 * json. 
	 * 
	 * @return InternetExplorer Options
	 * @author Bharat Pandey
	 * 
	 * @see com.wb.java_af.capabilities.browserCaps.BrowserCaps#getCaps()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public InternetExplorerOptions getCaps() {
		JSONObject environment = BrowserCaps.parseJsonFile(filePath, env);
		String defaultPlatformHost = (String) environment.keySet().stream().findFirst().orElse(null);
		Map<String, Object> envCapabilities = null;
		if (platformHost == null || platformHost == "") {
			platformHost = defaultPlatformHost;
		}
		if (env.equalsIgnoreCase("local") && platformHost.contains("ie")) {
			options = new InternetExplorerOptions();
			envCapabilities = (Map<String, Object>) environment.get(platformHost);

			Iterator<Map.Entry<String, Object>> it = envCapabilities.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, Object> pair = it.next();
				String key = pair.getKey().toString();
				Object value = pair.getValue().toString();
				if (key.equalsIgnoreCase("browserAttachTimeout")) {
					options.withAttachTimeout((Duration) value);
				}

				if (key.equalsIgnoreCase("elementScrollBehavior")) {
					options.elementScrollTo(ElementScrollBehavior.valueOf(((String) value).toUpperCase()));
				}

				if (key.equalsIgnoreCase("pageLoadStrategy")) {
					options.setPageLoadStrategy(PageLoadStrategy.fromString((String) value));
				}

				if (key.equalsIgnoreCase("unhandledPromptBehavior")) {
					options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.fromString((String) value));
				} else if (((String) value).equalsIgnoreCase("true") || ((String) value).equalsIgnoreCase("false")) {
					options.setCapability(key, Boolean.parseBoolean(((String) value)));
				} else {
					options.setCapability(key, value);
				}
			}
		}
		return options;
	}

	public static void main(String[] args) {
		new IePlatformCapsImpl("capabilities/browserCapabilities.json", "local", "ie").getCaps();
	}

}
