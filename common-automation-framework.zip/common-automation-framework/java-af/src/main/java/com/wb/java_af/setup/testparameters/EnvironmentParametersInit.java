package com.wb.java_af.setup.testparameters;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.wb.java_af.setup.Enums.Browser;
import com.wb.java_af.setup.Enums.LoggingLevel;
import com.wb.java_af.utilities.LogUtility;


public class EnvironmentParametersInit {

	public EnvironmentParametersInit() {

	}

	public static String getPropertiesFile() {

		String propsFileName = System.getProperty("propertiesFile", System.getProperty("environment") + "Setup");
		if (!propsFileName.endsWith(".properties")) {
			propsFileName = propsFileName + ".properties";
		}
		return propsFileName;
	}

	public static EnvironmentParameters intialize(){
		EnvironmentParameters testParameters = null;
		
		try{
			String envConfigFileLocation = getPropertiesFile();
			Properties props = new Properties();
			InputStream input = EnvironmentParametersInit.class.getClassLoader().getResourceAsStream(envConfigFileLocation);
			
			if(input != null) {
				props.load(input);
				
				testParameters = new EnvironmentParameters(props.getProperty("app.url"), props.getProperty("test.user"), 
						props.getProperty("test.password"), System.getProperty("environment"), translateBrowser(System.getProperty("browser")), 
						System.getProperty("suiteFile"));
			}
			
		} catch(IOException e) {
			LogUtility.logException("EnvironmentParamInit", "The Environment Parameters failed to be loaded. Check configuration.", e, LoggingLevel.ERROR, true);
		} catch (Exception e) {
			LogUtility.logException("EnvironmentParamInit", "The Environment Parameters failed tp be parsed. Check configuration.", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return testParameters;
	}

	public static Properties loadEnvPropertiesFile(){
		String envConfigFileLocation = getPropertiesFile();
		Properties props = new Properties();
		
		try{
			InputStream input = EnvironmentParametersInit.class.getClassLoader().getResourceAsStream(envConfigFileLocation);
			
			if(input != null) {
				props.load(input);
				
			}
			
		} catch(IOException e) {
			LogUtility.logException("EnvironmentParamInit", "The Environment Parameters failed to be loaded. Check configuration.", e, LoggingLevel.ERROR, true);
		} catch (Exception e) {
			LogUtility.logException("EnvironmentParamInit", "The Environment Parameters failed tp be parsed. Check configuration.", e, LoggingLevel.ERROR, true);
			throw e;
		}
		return props;
	}
  
  public static Browser translateBrowser(String browser) {
		switch (browser.toLowerCase()) {
		case "chrome":
			return Browser.CHROME;
		case "firefox":
			return Browser.FIREFOX;
		case "ie":
			return Browser.IE;
		case "edge":
			return Browser.EDGE;
		case "safari":
			return Browser.SAFARI;
		default:
			return Browser.CHROME;
		}
	}

}
