package com.wb.java_af.utilities;

import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wb.java_af.setup.Enums.LoggingLevel;

public class LogUtility {
	
	private static Logger logger = LoggerFactory.getLogger("log");
	
	public static void startTestCase(String testName){
		ThreadContext.put("ROUTINGKEY", Thread.currentThread().getName());
		logger.info("***************** Starting Test: " + testName + " *****************");
	}
	
	public static void endTestCase(String testName){
		logger.info("***************** End of Test: " + testName + " *****************");
		ThreadContext.remove("ROUTINGKEY");
	}
	
	public static void startScenario(String scenarioName){
		ThreadContext.put("ROUTINGKEY", Thread.currentThread().getName());
		logger.info("***************** Starting Scenario: " + scenarioName + " *****************");
	}
	
	public static void endScenario(String scenarioName){
		logger.info("***************** End of Scenario: " + scenarioName + " *****************");
		ThreadContext.remove("ROUTINGKEY");
	}
	
	public static void logInfo(String method, String message){
		logger.info("Method - " + method + " - " + message);
	}
	
	public static void logInfo(String message){
		logInfo(generateCallingMethodName(), message);
	}
	
	public static void logWarn(String method, String message){
		logger.warn("Method - " + method + " - " + message);
	}
	
	public static void logWarn(String message){
		logWarn(generateCallingMethodName(), message);
	}
	
	public static void logError(String method, String message){
		logger.error("Method - " + method + " - " + message);
	}
	
	public static void logError(String message){
		logError(generateCallingMethodName(), message);
	}
	
	public static void logDebug(String method, String message){
		logger.debug("Method - " + method + " - " + message);
	}
	
	public static void logDebug(String message){
		logDebug(generateCallingMethodName(), message);
	}
	
	public static void logException(String method, Exception e, LoggingLevel logLevel, Boolean writeToConsole){
		writeToConsole = writeToConsole !=null ? writeToConsole : false;
		printException(method, null, e, logLevel);
		
		if(writeToConsole)
			System.err.println("Failure in method: "+ method + ". Exception: "+e);
	}
	
	public static void logException(String method, String message, Exception e, LoggingLevel logLevel, Boolean writeToConsole){
		writeToConsole = writeToConsole !=null ? writeToConsole : false;
		printException(method, message, e, logLevel);
		
		if(writeToConsole)
			System.err.println("Failure in method: "+ method + ". Exception: "+e);
	}
	
	public static void logException(String method, Throwable output, LoggingLevel logLevel, Boolean writeToConsole){
		writeToConsole = writeToConsole !=null ? writeToConsole : false;
		printException(method, null, output, logLevel);
		
		if(writeToConsole)
			System.err.println("Failure in method: "+ method + ". Exception: "+ output);
	}
	
	public static void logException(String method, String message, Throwable output, LoggingLevel logLevel, Boolean writeToConsole){
		writeToConsole = writeToConsole !=null ? writeToConsole : false;
		printException(method, message, output, logLevel);
		
		if(writeToConsole)
			System.err.println("Failure in method: "+ method + ". Exception: "+ output);
	}
	
	public static void printException(String method, String message, Exception e, LoggingLevel logLevel){
		message = message == null ? "":message;
		
		switch(logLevel) {
		case INFO:
			logger.info("Failure in method: " + method + " occurred " + message + " Exception: " + e);
			break;
		case DEBUG:
			logger.debug("Failure in method: " + method + " occurred " + message + " Exception: " + e);
			break;
		case ERROR:
			logger.error("Failure in method: " + method + " occurred " + message + " Exception: " + e);
			break;
		case WARN:
			logger.warn("Failure in method: " + method + " occurred " + message + " Exception: " + e);
			break;
		default: logger.debug("Failure in method: " + method + " occurred " + message + " Exception: " + e);
		}
	}
	
	public static void printException(String method, String message, Throwable output, LoggingLevel logLevel){
		message = message == null ? "":message;
		
		switch(logLevel) {
		case INFO:
			logger.info("Failure in method: " + method + " occurred " + message + " Exception: " + output);
			break;
		case DEBUG:
			logger.debug("Failure in method: " + method + " occurred " + message + " Exception: " + output);
			break;
		case ERROR:
			logger.error("Failure in method: " + method + " occurred " + message + " Exception: " + output);
			break;
		case WARN:
			logger.warn("Failure in method: " + method + " occurred " + message + " Exception: " + output);
			break;
		default: logger.debug("Failure in method: " + method + " occurred " + message + " Exception: " + output);
		}
	}


	private static String generateCallingMethodName() {
		return Thread.currentThread().getStackTrace()[3].getMethodName();
	}

}
