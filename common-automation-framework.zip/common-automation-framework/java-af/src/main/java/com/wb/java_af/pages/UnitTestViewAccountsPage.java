package com.wb.java_af.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.wb.java_af.setup.ConcurrentEngines;
import com.wb.java_af.utilities.LogUtility;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

/**
 * @author spothula-adm
 *
 */
public class UnitTestViewAccountsPage {
	AppiumDriver<RemoteWebElement> driver = ConcurrentEngines.getEngine().getAppiumDriver();

	public UnitTestViewAccountsPage() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='VIEW ACCOUNTS']")
	@CacheLookup
	protected MobileElement titleViewAccounts;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/btn_auxmenu")
	@iOSFindBy(xpath = "//*[@label='Auxiliary Menu']")
	@CacheLookup
	protected MobileElement iconSettings;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/title")
	@iOSFindBy(xpath = "//*[@label='MENU']")
	@CacheLookup
	protected MobileElement titleMenu;

	@AndroidFindBy(id = "com.malauzai.websterbank:id/card_view")
	@iOSFindBy(xpath = "//*[@label='MENU']")
	@CacheLookup
	protected List<RemoteWebElement> listViewAccounts;

	/**
	 * Method to verify element using Explicit wait
	 * 
	 * @param elementName
	 * @param timeout
	 * @throws Exception
	 */
	public void isElementPresent(WebElement elementName, int timeout) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeout);
			wait.until(ExpectedConditions.visibilityOf(elementName));
			LogUtility.logInfo("--->Element is found<--- "+elementName);
		} catch (Exception e) {
			LogUtility.logError("--->Element not present on page "+e.getStackTrace());
			throw new Exception("Element not present on page " + elementName+ " "+e);
		}
	}

	/**
	 * Method to delay the execution based on the time
	 * 
	 * @param millis
	 */
	public void delay(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to verifying the view Accounts title after logged in
	 * 
	 * @throws Exception
	 */
	public void verifyViewAccountsPageTitle() throws Exception {
		try {
			titleViewAccounts.isDisplayed();
			LogUtility.logInfo("View Accounts Title page displayed");
		} catch (Exception e) {
			LogUtility.logError("--->Unable to verify the View Account Title "+e.getStackTrace());
			throw new Exception("Unable to verify the View Account Title " + e);
		}
	}

	/**
	 * Method to click on Settings Icon
	 * 
	 * @throws Exception
	 */
	public void clickSettingsIcon() throws Exception {
		try {
			iconSettings.click();
			LogUtility.logInfo("Settings Icon clicked");
			isElementPresent(titleMenu, 4);
		} catch (Exception e) {
			LogUtility.logError("--->Failed while/after clicking on settings icon "+e.getStackTrace());
			throw new Exception("Failed while/after clicking on settings icon " + e);
		}
	}

	/**
	 * Method to get count of elements
	 * 
	 * @return
	 * @throws Exception 
	 */
	public int listOfAccountsInViewPage() throws Exception {
		try {
			LogUtility.logInfo("Accounts displayed " + listViewAccounts.size());
			return listViewAccounts.size();
		}catch(Exception e) {
			LogUtility.logError("--->Unable to get the list of acounts"+e.getStackTrace());
			throw new Exception("Unable to get the list of acounts "+e);
		}
	}
}
