package com.wb.java_af.setup;

import static org.testng.Assert.assertNotNull;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.openqa.selenium.Capabilities;

import com.wb.java_af.alm.ALMConnector;
import com.wb.java_af.engine.Engine;
import com.wb.java_af.setup.Enums.Browser;
import com.wb.java_af.setup.testparameters.EnvironmentParameters;
import com.wb.java_af.setup.testparameters.EnvironmentParametersInit;

/**
 * Holder class for engine instances and renders them to calling methods in a
 * thread safe way
 * 
 * <p>
 * Ties engine instances to their own threads to run in a multi-threaded
 * environment in a thread safe way.
 * </p>
 * 
 * @see ConcurrentEngines
 * @author Bharat Pandey
 *
 */
public class ConcurrentEngines {

	private static ConcurrentHashMap<Long, Engine> engines = new ConcurrentHashMap<Long, Engine>();
	private static ConcurrentHashMap<Long, Engine> customEngines = new ConcurrentHashMap<Long, Engine>();
	public static EnvironmentParameters envParams = EnvironmentParametersInit.intialize();

	private static ThreadLocal<Map<String, Map<String, String>>> almTestEnttityList = new ThreadLocal<Map<String, Map<String, String>>>();
	private static ALMConnector almConnector = null;
	private static ConcurrentHashMap<String, String> scenarioALMTags = new ConcurrentHashMap<String, String>();
	private static ConcurrentHashMap<String, String> scenarioStatusMap = new ConcurrentHashMap<String, String>();

	/**
	 * Returns the engine associated with the current thread.
	 * 
	 * @return Engine
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static Engine getEngine() {
		return engines.get(Thread.currentThread().getId());
	}

	/**
	 * Returns the custom engine associated with the current thread.
	 * 
	 * @return Engine
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static Engine getCustomEngine() {
		return customEngines.get(Thread.currentThread().getId());
	}

	/**
	 * Creates a custom engine ato call in a.
	 * 
	 * @param caps
	 * @param browserName
	 * @param remoteExecution
	 * @param perfecto
	 * @param mobile
	 * @throws Exception
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static void createEngine(Capabilities caps, String browserName, boolean remoteExecution, boolean perfecto,
			boolean mobile) throws Exception {
		Engine engine = new Engine();
		Browser browser = EnvironmentParametersInit.translateBrowser(browserName);
		engine.setUpWebDriver(browser, caps, remoteExecution, perfecto, mobile);
		assertNotNull(engine.getWebDriver().getWrappedDriver(), "Webdriver was not set up correctly.");
		engines.putIfAbsent(Thread.currentThread().getId(), engine);
	}

	/**
	 * Creates a custom engine exposed to create an engine instance in the middle of
	 * another active engine.
	 * 
	 * @param caps            - Add capability object
	 * @param browserName     - If instanciating a browser, else pass chrome
	 *                        (default)
	 * @param remoteExecution - true, if perfectoMobile, cloud or grid
	 * @param perfecto        - true, if perfectoMobile
	 * @param mobile          - true, if mobile
	 * @throws Exception
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static void createCustomEngine(Capabilities caps, String browserName, boolean remoteExecution,
			boolean perfecto, boolean mobile) throws Exception {
		Engine engine = new Engine();
		Browser browser = EnvironmentParametersInit.translateBrowser(browserName);
		engine.setUpWebDriver(browser, caps, remoteExecution, perfecto, mobile);
		assertNotNull(engine.getWebDriver().getWrappedDriver(), "Webdriver was not set up correctly.");
		customEngines.putIfAbsent(Thread.currentThread().getId(), engine);
	}

	/**
	 * Quits the webdriver and removes the engine instance from the thread map.
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static void destroyEngine() {
		if (engines.containsKey(Thread.currentThread().getId())) {
			if (!getEngine().getWebDriver().toString().contains("null")) {
				cleanUpDriverProcesses();
			}
			engines.remove(Thread.currentThread().getId());
		}
	}

	/**
	 * Quits the webdriver and removes the engine instance from the thread map.
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static void destroyCustomEngine() {
		if (customEngines.containsKey(Thread.currentThread().getId())) {
			if (!getCustomEngine().getWebDriver().toString().contains("null")) {
				cleanUpCustomDriverProcesses();
			}
			customEngines.remove(Thread.currentThread().getId());
		}
	}

	/**
	 * Closes the driver. Runs webdriver.close() on the webdrivers current thread.
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static void closeDriver() {
		getEngine().getWebDriver().close();
	}

	/**
	 * Quits the driver. Runs webdriver.quit() on the webdrivers current thread.
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static void cleanUpDriverProcesses() {
		getEngine().getWebDriver().quit();
	}

	/**
	 * Quits the driver. Runs webdriver.quit() on the customs webdrivers current
	 * thread.
	 * 
	 * @see ConcurrentEngines
	 * 
	 * @author Bharat Pandey
	 */
	public static void cleanUpCustomDriverProcesses() {
		getCustomEngine().getWebDriver().quit();
	}

	/**
	 * @author Sanjay Samantaray
	 * 
	 * @return
	 */
	public static Map<String, Map<String, String>> getALMTestEntityList() {
		return almTestEnttityList.get();
	}
	
	/**
	 * @author Sanjay Samantaray
	 * 
	 * @param almTestEntityList
	 */

	public static void setALMTestEntityList(Map<String, Map<String, String>> almTestEntityList) {
		almTestEnttityList.set(almTestEntityList);
	}

	public static ConcurrentHashMap<String, String> getScenarioALMTags() {
		return scenarioALMTags;
	}

	public static void setScenarioALMTags(String scenarioName, String almTags) {
		scenarioALMTags.put(scenarioName, almTags);
	}

	public static ConcurrentHashMap<String, String> getScenarioStatusMap() {
		return scenarioStatusMap;
	}

	public static void setScenarioStatusMap(String scenarioName, String status) {
		scenarioStatusMap.put(scenarioName, status);
	}

	public static ALMConnector getAlmConnector() {
		if (almConnector == null)
			almConnector = new ALMConnector();
		return almConnector;
	}

}
