package com.wb.java_af.engine;

public class Cookies {

	public Cookies(Engine engine) {
		// TODO Auto-generated constructor stub
	}

}
