package com.qa.reports;

public class Reporter {

}
