package com.qa.utility;

public class Utility {

}
