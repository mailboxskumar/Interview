package com.qa.stepdefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;
import com.qa.utility.DriverManager;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	WebDriver driver;

	@When("^I enter username and password:$")
	public void i_enter_username_and_password(List<String> arg1) {
		for (String elemtn : arg1) {
			System.out.println(elemtn);
		}
	}

	@Then("^I see salesforce Testuser home page$")
	public void i_see_salesforce_Testuser_home_page() throws Throwable {
		System.out.println("Test");
	}

	@Then("^I see salesforce AdminUser home page$")
	public void i_see_salesforce_AdminUser_home_page() throws Throwable {
		System.out.println("test2");
	}

	@Given("^I navigate to salesforce login page through chrome browser \"([^\"]*)\"$")
	public void lohinApplication(String appUrl) throws Throwable {
		driver = DriverManager.getDriver("chrome");
		driver.get(appUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
	}

	@When("^I enter username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void i_enter_username_something_and_password_something(String userName, String password) throws Throwable {

		driver.findElement(By.id(LoginPage.userName_ID)).sendKeys(userName);
		driver.findElement(By.id(LoginPage.password_ID)).sendKeys(password);
	}

	@When("^I click login button$")
	public void i_click_login_button() throws Throwable {
		driver.findElement(By.xpath(LoginPage.login_Xpath)).click();

	}

	@Then("^I see username and password textbox$")
	public void i_see_username_and_password_textbox() throws Throwable {
		if (driver.findElement(By.id(LoginPage.userName_ID)).isDisplayed()) {
			System.out.println("Username Text box exist in login page");
		}

		if (driver.findElement(By.id(LoginPage.password_ID)).isDisplayed()) {
			System.out.println("password Text box exist in login page");
		}
	}

	@Then("^I see login button$")
	public void i_see_login_button() throws Throwable {
		if (driver.findElement(By.xpath(LoginPage.login_Xpath)).isDisplayed()) {
			System.out.println("login button box exist in login page");
		}
	}

	@Then("^I see salesforce home page$")
	public void i_see_salesforce_home_page() throws Throwable {
		if (driver.findElement(By.id(HomePage.homePage_Icon_ID)).isDisplayed()) {
			System.out.println("user successfuly landed into homepage");
		}

	}

}
