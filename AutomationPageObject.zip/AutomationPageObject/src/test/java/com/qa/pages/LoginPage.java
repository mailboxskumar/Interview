package com.qa.pages;

public class LoginPage {

	public static String userName_ID = "username";
	public static String password_ID = "password";
	public static String login_Xpath = "//input[@id='Login']";

}
