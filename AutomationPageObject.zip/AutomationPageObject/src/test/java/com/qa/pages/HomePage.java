package com.qa.pages;

public class HomePage {

	public static String homePage_Icon_ID = "HomePage";
}
