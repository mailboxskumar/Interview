$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login.feature");
formatter.feature({
  "line": 2,
  "name": "Login to Salesforce application as a user",
  "description": "",
  "id": "login-to-salesforce-application-as-a-user",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Login"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Login as Test user",
  "description": "",
  "id": "login-to-salesforce-application-as-a-user;login-as-test-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@TC1_Login_As_Test_User"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I navigate to salesforce login page through chrome browser \"https://login.salesforce.com/?locale\u003dau\"",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I see username and password textbox",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "I see login button",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "I enter username \"Test\" and password \"password\"",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I click login button",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "I see salesforce home page",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "https://login.salesforce.com/?locale\u003dau",
      "offset": 60
    }
  ],
  "location": "LoginSteps.lohinApplication(String)"
});
formatter.result({
  "duration": 10737709770,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_see_username_and_password_textbox()"
});
formatter.result({
  "duration": 664780892,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_see_login_button()"
});
formatter.result({
  "duration": 137069571,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test",
      "offset": 18
    },
    {
      "val": "password",
      "offset": 38
    }
  ],
  "location": "LoginSteps.i_enter_username_something_and_password_something(String,String)"
});
formatter.result({
  "duration": 707122461,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_click_login_button()"
});
formatter.result({
  "duration": 2336332101,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_see_salesforce_home_page()"
});
formatter.result({
  "duration": 910391645,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"id\",\"selector\":\"HomePage\"}\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHRAMESHREDDY\u0027, ip: \u0027192.168.1.244\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\RAMESH~1.CH\\AppDat...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:52644}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: 2a084284740495f0dda486bf717c7ec4\n*** Element info: {Using\u003did, value\u003dHomePage}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:368)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:188)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat com.qa.stepdefinitions.LoginSteps.i_see_salesforce_home_page(LoginSteps.java:78)\r\n\tat ✽.Then I see salesforce home page(Login.feature:11)\r\n",
  "status": "failed"
});
formatter.uri("LoginNew.feature");
formatter.feature({
  "line": 2,
  "name": "Login to Salesforce application as a user",
  "description": "",
  "id": "login-to-salesforce-application-as-a-user",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Login"
    }
  ]
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "I navigate to salesforce login page through chrome browser \"https://login.salesforce.com/?locale\u003dau\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I see username and password textbox",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "I see login button",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "I enter username and password:",
  "rows": [
    {
      "cells": [
        "Test"
      ],
      "line": 9
    },
    {
      "cells": [
        "Admin"
      ],
      "line": 10
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "I click login button",
  "keyword": "When "
});
formatter.match({
  "arguments": [
    {
      "val": "https://login.salesforce.com/?locale\u003dau",
      "offset": 60
    }
  ],
  "location": "LoginSteps.lohinApplication(String)"
});
formatter.result({
  "duration": 15128106341,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_see_username_and_password_textbox()"
});
formatter.result({
  "duration": 207696062,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_see_login_button()"
});
formatter.result({
  "duration": 76083684,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_enter_username_and_password(String\u003e)"
});
formatter.result({
  "duration": 2828663,
  "status": "passed"
});
formatter.match({
  "location": "LoginSteps.i_click_login_button()"
});
formatter.result({
  "duration": 11183570143549,
  "error_message": "org.openqa.selenium.TimeoutException: timeout\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHRAMESHREDDY\u0027, ip: \u0027192.168.1.244\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\RAMESH~1.CH\\AppDat...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:52688}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: e9fd156128553e8a0141c8ce679d25f6\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:276)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:83)\r\n\tat com.qa.stepdefinitions.LoginSteps.i_click_login_button(LoginSteps.java:54)\r\n\tat ✽.When I click login button(LoginNew.feature:11)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 14,
  "name": "Login as Test user",
  "description": "",
  "id": "login-to-salesforce-application-as-a-user;login-as-test-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 13,
      "name": "@TC1_Login_As_Test_User"
    }
  ]
});
formatter.step({
  "line": 15,
  "name": "I see salesforce Testuser home page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.i_see_salesforce_Testuser_home_page()"
});
formatter.result({
  "status": "skipped"
});
});